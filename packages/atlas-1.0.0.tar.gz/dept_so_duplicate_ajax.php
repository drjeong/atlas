<?php
/**
 * Duplicate Student Outcomes
 * Description: duplicating student outcomes.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2021 - initial version created
 * 11/10/2024 -- change SQL execution to address SQL injection
 */


include_once 'session_handler.php';


$AcademicYearIdxFrom='';
$AcademicYearIdxTo='';

if (array_key_exists('ayf', $_POST) && array_key_exists('ayt', $_POST) )
{
    $AcademicYearIdxFrom = trim($_POST['ayf']);
    $AcademicYearIdxTo = trim($_POST['ayt']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYearIdxFrom=="" || $AcademicYearIdxTo==""|| $AcademicProgram==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    /////////////////////////////////////////////////////////////////////////////////
    $query = "CALL SP_DuplicateSO(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$AcademicYearIdxFrom, $AcademicYearIdxTo, $AcademicProgram]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x09500011') !== false) {
        echo '0x09500011';  // The selected year does not have student outcomes.
    }
    else if (strpos($errorMessage, '0x09500012') !== false) {
        echo '0x09500012';  // The selected year has student outcomes already.
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

