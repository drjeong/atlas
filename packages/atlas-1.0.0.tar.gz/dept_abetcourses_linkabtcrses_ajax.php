<?php
/**
 * Update Course Reference AJAX Handler
 * Handles toggling course between Primary and Reference status
 *
 * Parameters:
 * - action: Must be 'toggle_reference'
 * - avcidx: Available Course Index
 * - reference_value: New reference value (0 = Primary, 1 = Reference)
 *
 * Response Codes:
 * - 0x11111111: Success
 * - 0x00000000: Illegal entry or unexpected error
 * - 0x00000101: Missing required information
 * - 0x00000102: Invalid action
 * - 0x00000103: Invalid course index
 * - 0x00000104: Invalid reference value
 * - 0x00000500: Database error
 *
 * 12/19/2025 - initial version created
 */

include_once 'session_handler.php';

$action = ''; 
$avcIdx = '';
$abcIdx_Reference = '';
$abcIdx_Primary = '';
$referenceValue = '';

// Validate request parameters
if (array_key_exists('action', $_POST) &&
    array_key_exists('avcIdx', $_POST) &&
    array_key_exists('abcIdx', $_POST) &&
    array_key_exists('reference_value', $_POST)) {

    $action = trim($_POST['action']);
    $avcIdx = trim($_POST['avcIdx']);
    $abcIdx_Reference = trim($_POST['abcIdx']);
    $abcIdx_Primary = trim($_POST['abcIdx_Primary']);
    $referenceValue = trim($_POST['reference_value']);
} else {
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

// Validate action
if ($action !== 'toggle_reference') {
    echo "0x00000102";
    exit;
}

// Validate required information
if ($avcIdx === "" || $abcIdx_Reference === "" || $referenceValue === "") {
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate course index
    $avcIdx = filter_var($avcIdx, FILTER_VALIDATE_INT);
    if ($avcIdx === false || $avcIdx <= 0) {
        echo "0x00000103";
        exit;
    }
    $abcIdx_Reference = filter_var($abcIdx_Reference, FILTER_VALIDATE_INT);
    if ($abcIdx_Reference === false || $abcIdx_Reference <= 0) {
        echo "0x00000103";
        exit;
    }

    // Validate reference value
    $referenceValue = filter_var($referenceValue, FILTER_VALIDATE_INT);
    if ($referenceValue === false || ($referenceValue !== 0 && $referenceValue !== 1)) {
        echo "0x00000104";
        exit;
    }

//    error_log("CALL SP_UpdateCourseReference($avcIdx, $abcIdx_Reference, $abcIdx_Primary, $referenceValue);");
    // Call stored procedure to update course reference status
    $result = $DBCONNECTION->callStoredProcedure('SP_UpdateCourseReference', [
        $avcIdx,
        $abcIdx_Reference,
        $abcIdx_Primary,
        $referenceValue
    ]);

//    error_log("CALL SP_UpdateCourseReference_DuplicateAssessmentMeasures($avcIdx, $abcIdx_Reference, $abcIdx_Primary);");
    // Call stored procedure to duplicate assessment measures
    $result = $DBCONNECTION->callStoredProcedure('SP_UpdateCourseReference_DuplicateAssessmentMeasures', [
        $avcIdx,
        $abcIdx_Reference,
        $abcIdx_Primary
    ]);

    // Success response
    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Database error
    echo "0x00000500";

    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'query' => '0x00000500'
    ]));

} catch (Exception $e) {
    // General error
    error_log($e->getMessage());
    echo "0x00000000";
}
?>