<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';

$_AY1 = '';
$_AY2 = '';

if (array_key_exists('_AY1', $_GET)
    && array_key_exists('_AY2', $_GET) )
{
    $_AY1 = trim($_GET['_AY1']);
    $_AY2 = trim($_GET['_AY2']);
}
else {
    // illegal entry
    exit;
}

require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();
$Data= array();

//----------------------------------------------------------------------------------------
// Initialize variables with default empty string
$data = null;

// Fetching abet syllabus information for different versions
$results = $DBCONNECTION->callStoredProcedure('SP_FetchPI_DiffInfo', [$_AY1, $_AY2, $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

// Check if results are returned
$data = null;
$_AY1Text = '';
$_AY2Text = '';
$AcademicProgramText = '';
if ($results) {
    // Fetch and display the results
    while ($row = $results->fetch_assoc()) {
        $data[] = $row;
        if ($_AY1Text == ''){
            $_AY1Text = $row['AcademicYear_1'];
            $_AY2Text = $row['AcademicYear_2'];
            $AcademicProgramText = $row['Name'] . " (".$row['Degree'].")";
        }
    }
}

$AcademicProgramText_Tmp = $AcademicProgramText;
$AcademicProgramText_Tmp = str_replace(" ","_",strtolower($AcademicProgramText_Tmp));
$AcademicProgramText_Tmp = str_replace("(","_",strtolower($AcademicProgramText_Tmp));
$AcademicProgramText_Tmp = str_replace(")","_",strtolower($AcademicProgramText_Tmp));

$Excel_FileName = 'abet_so';
$Excel_FileName .= '_'. $AcademicProgramText_Tmp;
$Excel_FileName .= '_'. str_replace(" ","_",strtolower($_AY1Text));
$Excel_FileName .= '_'. str_replace(" ","_",strtolower($_AY2Text));
$Excel_FileName .= '_diff.xls';

require_once(__DIR__ . '/php_include/listfunc.php');

// Function to escape XML/Excel content
function escapeExcelXml($value) {
    $value = html_entity_decode(strip_tags($value));
    $value = str_replace(['&', '<', '>', '"', "'"], ['&amp;', '&lt;', '&gt;', '&quot;', '&#39;'], $value);
    // Remove non-printable characters
    $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $value);
    return $value;
}

// Function to combine SO and PI for the first column with better handling
function formatSOPI($so, $pi) {
    // Clean and handle potential issues with PI field
    $so = trim($so ?? '');
    $pi = trim($pi ?? '');

    // Handle different possible field names or formats
    if (empty($pi)) {
        // If PI is empty, try other common field names or use a counter
        return $so; // Just return SO if PI is missing
    }

    return $so . '-' . $pi;
}

try {
    // Set headers for Excel download
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="' . $Excel_FileName . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');

    // Start Excel XML
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    echo '<?mso-application progid="Excel.Sheet"?>' . "\n";
    echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
    echo ' xmlns:o="urn:schemas-microsoft-com:office:office"' . "\n";
    echo ' xmlns:x="urn:schemas-microsoft-com:office:excel"' . "\n";
    echo ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
    echo ' xmlns:html="http://www.w3.org/TR/REC-html40">' . "\n";

    // Document Properties
    echo '<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">' . "\n";
    echo '<Title>SO Differences Report</Title>' . "\n";
    echo '<Author>ATLAS: Academic Tracking & Learning Assessment System</Author>' . "\n";
    echo '<Created>' . date('c') . '</Created>' . "\n";
    echo '</DocumentProperties>' . "\n";

    // Styles
    echo '<Styles>' . "\n";
    echo '<Style ss:ID="Default" ss:Name="Normal">' . "\n";
    echo '<Alignment ss:Vertical="Bottom"/>' . "\n";
    echo '<Borders/>' . "\n";
    echo '<Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>' . "\n";
    echo '<Interior/>' . "\n";
    echo '<NumberFormat/>' . "\n";
    echo '<Protection/>' . "\n";
    echo '</Style>' . "\n";

    // Header style
    echo '<Style ss:ID="HeaderStyle">' . "\n";
    echo '<Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/>' . "\n";
    echo '<Borders>' . "\n";
    echo '<Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2"/>' . "\n";
    echo '<Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2"/>' . "\n";
    echo '</Borders>' . "\n";
    echo '<Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="12" ss:Color="#000000" ss:Bold="1"/>' . "\n";
    echo '<Interior ss:Color="#4472C4" ss:Pattern="Solid"/>' . "\n";
    echo '</Style>' . "\n";

    // Title style
    echo '<Style ss:ID="TitleStyle">' . "\n";
    echo '<Alignment ss:Horizontal="Center" ss:Vertical="Center"/>' . "\n";
    echo '<Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="16" ss:Color="#000000" ss:Bold="1"/>' . "\n";
    echo '</Style>' . "\n";

    // Data style with borders
    echo '<Style ss:ID="DataStyle">' . "\n";
    echo '<Alignment ss:Vertical="Top" ss:WrapText="1"/>' . "\n";
    echo '<Borders>' . "\n";
    echo '<Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '</Borders>' . "\n";
    echo '<Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>' . "\n";
    echo '</Style>' . "\n";

    // SO-PI column style (first column)
    echo '<Style ss:ID="SOPIStyle">' . "\n";
    echo '<Alignment ss:Horizontal="Center" ss:Vertical="Top" ss:WrapText="1"/>' . "\n";
    echo '<Borders>' . "\n";
    echo '<Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '</Borders>' . "\n";
    echo '<Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000" ss:Bold="1"/>' . "\n";
    echo '<Interior ss:Color="#E7E6E6" ss:Pattern="Solid"/>' . "\n";
    echo '</Style>' . "\n";

    // Removed style (yellow background)
    echo '<Style ss:ID="RemovedStyle">' . "\n";
    echo '<Alignment ss:Vertical="Top" ss:WrapText="1"/>' . "\n";
    echo '<Borders>' . "\n";
    echo '<Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '</Borders>' . "\n";
    echo '<Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>' . "\n";
    echo '<Interior ss:Color="#FFFF00" ss:Pattern="Solid"/>' . "\n";
    echo '</Style>' . "\n";

    // Different style (light red background)
    echo '<Style ss:ID="DifferentStyle">' . "\n";
    echo '<Alignment ss:Vertical="Top" ss:WrapText="1"/>' . "\n";
    echo '<Borders>' . "\n";
    echo '<Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '<Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>' . "\n";
    echo '</Borders>' . "\n";
    echo '<Font ss:FontName="Calibri" x:Family="Swiss" ss:Size="11" ss:Color="#000000"/>' . "\n";
    echo '<Interior ss:Color="#FFE6E6" ss:Pattern="Solid"/>' . "\n";
    echo '</Style>' . "\n";

    echo '</Styles>' . "\n";

    // Worksheet
    echo '<Worksheet ss:Name="PI Differences">' . "\n";
    echo '<Table>' . "\n";

    // Column definitions for better width control
    echo '<Column ss:Width="120"/>' . "\n";  // Academic Year / SO-PI
    echo '<Column ss:Width="300"/>' . "\n";  // AcademicYear_1 content
    echo '<Column ss:Width="300"/>' . "\n";  // AcademicYear_2 content

    $rowNum = 1;

    // Title row
    echo '<Row ss:Index="' . $rowNum . '">' . "\n";
    echo '<Cell ss:MergeAcross="2" ss:StyleID="TitleStyle"><Data ss:Type="String">Student Outcomes Differences Report</Data></Cell>' . "\n";
    echo '</Row>' . "\n";
    $rowNum++;

    // Program info row
    echo '<Row ss:Index="' . $rowNum . '">' . "\n";
    echo '<Cell ss:MergeAcross="2" ss:StyleID="DataStyle"><Data ss:Type="String">Academic Program: ' . escapeExcelXml($AcademicProgramText) . '</Data></Cell>' . "\n";
    echo '</Row>' . "\n";
    $rowNum++;

    // Comparison info row
    echo '<Row ss:Index="' . $rowNum . '">' . "\n";
    echo '<Cell ss:MergeAcross="2" ss:StyleID="DataStyle"><Data ss:Type="String">Comparison: ' . escapeExcelXml($_AY1Text) . ' vs ' . escapeExcelXml($_AY2Text) . '</Data></Cell>' . "\n";
    echo '</Row>' . "\n";
    $rowNum += 2;

    // Headers
    echo '<Row ss:Index="' . $rowNum . '">' . "\n";
    echo '<Cell ss:StyleID="HeaderStyle"><Data ss:Type="String">Academic Year</Data></Cell>' . "\n";
    echo '<Cell ss:StyleID="HeaderStyle"><Data ss:Type="String">' . escapeExcelXml($_AY1Text) . '</Data></Cell>' . "\n";
    echo '<Cell ss:StyleID="HeaderStyle"><Data ss:Type="String">' . escapeExcelXml($_AY2Text) . '</Data></Cell>' . "\n";
    echo '</Row>' . "\n";
    $rowNum++;

    // Debug: Let's check what fields are available in the first row
    if ($data && is_array($data) && count($data) > 0) {
        // Add a debug comment to see available fields
        echo '<!-- Available fields: ' . implode(', ', array_keys($data[0])) . ' -->' . "\n";
    }

    // Data rows
    if ($data && is_array($data)) {
        $currentSO = '';
        $piCounter = 1; // Counter for PI within each SO

        foreach ($data as $key => $dataRow) {
            // Skip non-array elements or elements without 'SO'
            if (!is_array($dataRow) || !isset($dataRow['SO'])) {
                continue;
            }

            // Check if we've moved to a new SO
            if ($currentSO !== $dataRow['SO']) {
                $currentSO = $dataRow['SO'];
                $piCounter = 1; // Reset counter for new SO
            }

            // Debug: Check what's in the PI field and other possible field names
            $possiblePIFields = ['PI', 'pi', 'PerformanceIndicator', 'PI_ID', 'PICode', 'PI_Code'];
            $piValue = '';

            foreach ($possiblePIFields as $field) {
                if (isset($dataRow[$field]) && !empty(trim($dataRow[$field]))) {
                    $piValue = trim($dataRow[$field]);
                    break;
                }
            }

            // If still empty, use sequential letters starting from A for each SO
            if (empty($piValue)) {
                $piValue = chr(64 + $piCounter); // A, B, C, etc.
            }

            // Increment counter for next PI within this SO
            $piCounter++;

            // Create the SO-PI identifier for the first column
            $soPi = formatSOPI($dataRow['SO'], $piValue);

            // Determine removal flags
            $tobeRemoved1 = isset($dataRow['TobeRemoved_1']) && $dataRow['TobeRemoved_1'] == 1;
            $tobeRemoved2 = isset($dataRow['TobeRemoved_2']) && $dataRow['TobeRemoved_2'] == 1;

            // Check for differences in descriptions
            $description1Clean = html_entity_decode(strip_tags($dataRow['Description_1'] ?? ''));
            $description2Clean = html_entity_decode(strip_tags($dataRow['Description_2'] ?? ''));
            $hasDifferences = ($description1Clean !== $description2Clean);

            // Prepare content for each academic year
            $content1 = '';
            $content2 = '';

            // Build content for first academic year
            if (!empty($dataRow['Description_1'])) {
                if ($tobeRemoved1) {
                    $description = escapeExcelXml($dataRow['Description_1']);
                    $content1 = '[REMOVED] ' . $description;
                } elseif ($hasDifferences && !$tobeRemoved1 && !$tobeRemoved2) {
                    $description = escapeExcelXml($dataRow['Description_1']);
                    $content1 = '[REVISED] ' . $description;
                } else {
                    $content1 = escapeExcelXml($dataRow['Description_1']);
                }
            }

            // Add Comments on new line with label
            if (!empty($dataRow['Comments_1'])) {
                if (!empty($content1)) $content1 .= "&#10;";
                $content1 .= "Comments: " . escapeExcelXml($dataRow['Comments_1']);
            }

            // Add Approval on new line with label
            if (!empty($dataRow['Approval_1'])) {
                if (!empty($content1)) $content1 .= "&#10;";
                $content1 .= "Approval: " . escapeExcelXml($dataRow['Approval_1']);
            }

            // Build content for second academic year
            if (!empty($dataRow['Description_2'])) {
                if ($tobeRemoved2) {
                    $description = escapeExcelXml($dataRow['Description_2']);
                    $content2 = '[REMOVED] ' . $description;
                } elseif ($hasDifferences && !$tobeRemoved1 && !$tobeRemoved2) {
                    $description = escapeExcelXml($dataRow['Description_2']);
                    $content2 = '[REVISED] ' . $description;
                } else {
                    $content2 = escapeExcelXml($dataRow['Description_2']);
                }
            }

            // Add Comments on new line with label
            if (!empty($dataRow['Comments_2'])) {
                if (!empty($content2)) $content2 .= "&#10;";
                $content2 .= "Comments: " . escapeExcelXml($dataRow['Comments_2']);
            }

            // Add Approval on new line with label
            if (!empty($dataRow['Approval_2'])) {
                if (!empty($content2)) $content2 .= "&#10;";
                $content2 .= "Approval: " . escapeExcelXml($dataRow['Approval_2']);
            }

            // Determine cell styles
            $style1 = $tobeRemoved1 ? 'RemovedStyle' : ($hasDifferences ? 'DifferentStyle' : 'DataStyle');
            $style2 = $tobeRemoved2 ? 'RemovedStyle' : ($hasDifferences ? 'DifferentStyle' : 'DataStyle');

            echo '<Row ss:Index="' . $rowNum . '" ss:Height="60">' . "\n";

            // First column: SO-PI
            echo '<Cell ss:StyleID="SOPIStyle"><Data ss:Type="String">' . escapeExcelXml($soPi) . '</Data></Cell>' . "\n";

            // Second column: First academic year content
            echo '<Cell ss:StyleID="' . $style1 . '"><Data ss:Type="String">' . $content1 . '</Data></Cell>' . "\n";

            // Third column: Second academic year content
            echo '<Cell ss:StyleID="' . $style2 . '"><Data ss:Type="String">' . $content2 . '</Data></Cell>' . "\n";

            echo '</Row>' . "\n";
            $rowNum++;
        }
    }

    echo '</Table>' . "\n";
    echo '</Worksheet>' . "\n";
    echo '</Workbook>' . "\n";

} catch(Exception $e) {
    // If headers haven't been sent yet, we can still show an error
    if (!headers_sent()) {
        header('Content-Type: text/plain');
        echo $e->getMessage();
        echo ('0x23894723');    // Error
    }
    exit;
}
?>