<?php
/**
 * Removing Abet Syllabus
 * Description: removing the selected course's abet syllabus.
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$IDX='';
$AcademicYearInfo='';
$AbetCourseSyllabus='';

if (array_key_exists('idx', $_POST) && array_key_exists('ayinfo', $_POST) && array_key_exists('abetsyllabus', $_POST))
{
    $IDX = trim($_POST['idx']);
    $AcademicYearInfo = trim($_POST['ayinfo']);
    $AbetCourseSyllabus = trim($_POST['abetsyllabus']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

if ($IDX=="" || $AcademicYearInfo=="" || $AbetCourseSyllabus==""){
    // no IDX information
    echo "0x00000101";
    exit;
}

//---------------------------------------------------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Sanitize inputs
    $IDX = filter_var($IDX, FILTER_VALIDATE_INT);
    if ($IDX === false) {
        throw new Exception('Invalid IDX format');
    }

    // Validate and sanitize file path
    $AbetCourseSyllabiDirectory = rtrim(__DIRECTORY_ABETSYLLABI__, '/') . '/' . $AcademicYearInfo . '/';
    $fullFilePath = $AbetCourseSyllabiDirectory . $AbetCourseSyllabus;

    // remove the selected course syllabus if exists
    // File deletion
    if (file_exists($fullFilePath)) {
        if (!unlink($fullFilePath)) {
            throw new Exception("Failed to delete file");
        }
    } else {
        error_log("Warning: File not found - $fullFilePath");
    }

    // Escape strings for database
    $AbetCourseSyllabus = $DBCONNECTION->real_escape_string($AbetCourseSyllabus);

    // Database update
    $query = "CALL SP_RemoveAbetSyllabus(?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [
        $IDX, $AbetCourseSyllabus
    ]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Handle database-specific errors
    error_log("Database error: " . $e->getMessage());
    echo "0x00000500";  // DB error code

} catch (Exception $e) {
    error_log($e->getMessage());
    echo "0x00000000";
}