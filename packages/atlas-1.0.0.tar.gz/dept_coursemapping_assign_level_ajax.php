<?php
/**
 * Assign Level information to Abet Courses
 * Description: This is for assigning level information to the selected abet courses
 * level information - 1: Introductory / 2: Practice  / 3: Mastery
 *  - Initial version created.
 * Author: Dong Hyun Jeong
 *
 * 03/09/2023 - initial version created
 * 12/14/2025 - revise to handle course and year indexes
 *
 */
?>

<?php
include_once 'session_handler.php';

$coursePairs = '';
$LevelIndicator = '';

if (array_key_exists('coursePairs', $_POST) && array_key_exists('level', $_POST))
{
    $coursePairs = trim($_POST['coursePairs']);
    $LevelIndicator = trim($_POST['level']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'])) ? $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] : '';

if ($coursePairs == "" || $AcademicProgram == "" || $LevelIndicator == ""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate Academic Program
    $AcademicProgram = filter_var($AcademicProgram, FILTER_VALIDATE_INT);
    if ($AcademicProgram === false) {
        throw new Exception('Invalid Academic Program format');
    }

    // Validate Level Indicator
    $LevelIndicator = filter_var($LevelIndicator, FILTER_VALIDATE_INT);
    if ($LevelIndicator === false || $LevelIndicator < 1 || $LevelIndicator > 3) {
        throw new Exception('Invalid Level Indicator');
    }

    // Split the pipe-separated pairs
    $pairsArray = explode('|', $coursePairs);

    if (empty($pairsArray)) {
        throw new Exception('No course pairs provided');
    }

    $MultiQuery = "";
    foreach ($pairsArray as $pair) {
        // Split each pair by colon
        $parts = explode(':', $pair);

        if (count($parts) !== 2) {
            throw new Exception('Invalid course pair format');
        }

        // Decode and validate Course Idx
        $AbetCourseIdx = urldecode($parts[0]);
        $AbetCourseIdx = filter_var($AbetCourseIdx, FILTER_VALIDATE_INT);
        if ($AbetCourseIdx === false) {
            throw new Exception('Invalid course index');
        }

        // Decode and validate Academic Year
        $AcademicYearIdx = urldecode($parts[1]);
        $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
        if ($AcademicYearIdx === false) {
            throw new Exception('Invalid Academic Year');
        }

        $MultiQuery .= "CALL SP_UpdateCourseMapping_Levels($AbetCourseIdx, $LevelIndicator, $AcademicYearIdx, $AcademicProgram);";
    }

    // error_log($MultiQuery);
    $DBCONNECTION->sendmultiquery($MultiQuery);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage());
    echo "0x00000000";
}
