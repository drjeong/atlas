<?php
/**
 * Management of Academic Year
 * Description: manage academic years
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 08/07/2026 - Modified to use semester data from database
 * 08/09/2026 - Added Academic Year text input with validation
 *
 */

include('checker_programdirector.php');
include('header.php');

?>

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
    ?>

    <script type="text/javascript">

        // Constants
        const ErrorCodes = {
            SUCCESS: '0x11111111',
            SAME_ITEM_EXIST: '0x00200011',
            ITEM_NOT_EXIST: '0x00200012',
            CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
            CANNOT_REMOVE_ITEM_FOLDER_INUSE: '0x09000010',
        };

        async function RemoveAcademicYearInfo(id, dp){
            try {
                const willDelete = await async_commons.showConfirmDialog(
                    `Deleted content (<span style="color:red">${dp}</span>) cannot be restored!`
                );

                if (!willDelete.value) return;
                const result = await async_commons.makeApiCall('m_academicyearinfo_remove_ajax.php', {
                    id: id
                });

                const code = result.trim();
                switch (code) {
                    case ErrorCodes.SUCCESS: {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('DELETED', 'The selected academic year has been deleted!');
                        break;
                    }
                    case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                        await async_commons.showErrorMessage('ERROR', 'The selected academic year cannot be removed!! It has been used already!!');
                        break;
                    }
                    case ErrorCodes.CANNOT_REMOVE_ITEM_FOLDER_INUSE: {
                        await async_commons.showErrorMessage('ERROR', 'The selected academic year cannot be removed!! The academic year contain data records.');
                        break;
                    }
                    default: {
                        throw new Error('Unexpected server response');
                    }
                }
            } catch (error) {
                await async_commons.handleError(error);
            }
        }

        async function AddAcademicYear_Perform(_AcademicYear, _FromSemesterIdx, _ToSemesterIdx) {
            try {
                const result = await async_commons.makeApiCall('m_academicyearinfo_add_ajax.php', {
                    academicYear: _AcademicYear,
                    fromSemesterIdx: _FromSemesterIdx,
                    toSemesterIdx: _ToSemesterIdx
                });

                const code = result.trim();
                switch (code) {
                    case ErrorCodes.SUCCESS: {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('ADDED', 'Academic year is added successfully!');
                        break;
                    }
                    case ErrorCodes.SAME_ITEM_EXIST: {
                        await async_commons.showErrorMessage(
                            'ERROR',
                            `The entered academic year exists already!`
                        );
                        // Re-open the add dialog with existing values
                        await AddAcademicYearInfo(_AcademicYear, _FromSemesterIdx, _ToSemesterIdx);
                        break;
                    }
                    default: {
                        throw new Error('Unexpected server response');
                    }
                }
            } catch (error) {
                await async_commons.handleError(error);
            }
        }

        async function LoadSemesters() {
            try {
                const response = await fetch('ssps/get_semesters_ajax.php');
                const data = await response.json();
                return data;
            } catch (error) {
                console.error('Error loading semesters:', error);
                return [];
            }
        }

        async function AddAcademicYearInfo(_AcademicYear='', _FromSemesterIdx='', _ToSemesterIdx='') {
            // Load semester data
            const semesters = await LoadSemesters();

            if (semesters.length === 0) {
                await async_commons.showErrorMessage('ERROR', 'No semesters available. Please add semesters first!');
                return;
            }

            // Create options for dropdowns
            let fromOptions = '<option value="">-- Select From Semester --</option>';
            let toOptions = '<option value="">-- Select To Semester --</option>';

            semesters.forEach(sem => {
                const selected1 = (sem.Idx == _FromSemesterIdx) ? 'selected' : '';
                const selected2 = (sem.Idx == _ToSemesterIdx) ? 'selected' : '';
                fromOptions += `<option value="${sem.Idx}" ${selected1}>${sem.SemesterCode} - ${sem.Explanation}</option>`;
                toOptions += `<option value="${sem.Idx}" ${selected2}>${sem.SemesterCode} - ${sem.Explanation}</option>`;
            });

            const formContent =
                `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
             <div class="input-group" style="width:100%; margin-bottom:10px;">
                <span class="input-group-addon" style="width:200px;">Academic Year<span style="color:red">*</span></span>
                <input type="text" placeholder="e.g., 2026-2027, 2025-2026" class="input-sm form-control" id="_ACADEMIC_YEAR" name="_ACADEMIC_YEAR" value="${_AcademicYear}" maxlength="9"/>
             </div>
             <div class="input-group" style="width:100%; margin-bottom:10px;">
                <span class="input-group-addon" style="width:200px;">From Semester<span style="color:red">*</span></span>
                <select class="form-control input-sm" id="_FROM_SEMESTER" name="_FROM_SEMESTER">
                    ${fromOptions}
                </select>
             </div>
             <div class="input-group" style="width:100%;">
                <span class="input-group-addon" style="width:200px;">To Semester<span style="color:red">*</span></span>
                <select class="form-control input-sm" id="_TO_SEMESTER" name="_TO_SEMESTER">
                    ${toOptions}
                </select>
             </div>
             </td></tr>
             </table></form>`;

            createModalDialog({
                title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD ACADEMIC YEAR INFORMATION</span>',
                message: formContent,
                buttons: {
                    ok: {
                        label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;ADD",
                        className: 'btn-success',
                        callback: function(){
                            const popupForm = document.getElementById('popupfrm');
                            if (!ValidateItems(popupForm, semesters)) return false;
                            AddAcademicYear_Perform(
                                popupForm._ACADEMIC_YEAR.value.trim(),
                                popupForm._FROM_SEMESTER.value,
                                popupForm._TO_SEMESTER.value
                            );
                        }
                    },
                    cancel: {
                        label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                        className: 'btn-default',
                        callback: function(){
                        }
                    }
                }
            }).on('shown.bs.modal',function(){
                $("#_ACADEMIC_YEAR").focus();
            });
        }

        function ValidateItems(popupForm, semesters) {
            const academicYear = popupForm._ACADEMIC_YEAR.value.trim();
            const fromSemesterIdx = popupForm._FROM_SEMESTER.value.trim();
            const toSemesterIdx = popupForm._TO_SEMESTER.value.trim();

            // Validate Academic Year format
            if (!academicYear) {
                popupForm._ACADEMIC_YEAR.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Academic year is not entered!",
                    icon: "error"
                });
                return false;
            }

            // Validate format: YYYY-YYYY (Applied only to North America academic year)
            const academicYearRegex = /^(\d{4})-(\d{4})$/;
            const match = academicYear.match(academicYearRegex);

            if (!match) {
                popupForm._ACADEMIC_YEAR.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Please enter academic year in the format YYYY-YYYY (e.g., 2026-2027)!",
                    icon: "error"
                });
                return false;
            }

            const startYear = parseInt(match[1]);
            const endYear = parseInt(match[2]);

            // Validate year range
            const currentYear = new Date().getFullYear();
            if (startYear < currentYear - 30 || startYear > currentYear + 30) {
                popupForm._ACADEMIC_YEAR.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Start year must be within reasonable range (current year ± 30 years)!",
                    icon: "error"
                });
                return false;
            }

            // Check if From semester is selected
            if (!fromSemesterIdx) {
                popupForm._FROM_SEMESTER.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "From semester is not selected!",
                    icon: "error"
                });
                return false;
            }

            // Check if To semester is selected
            if (!toSemesterIdx) {
                popupForm._TO_SEMESTER.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "To semester is not selected!",
                    icon: "error"
                });
                return false;
            }

            // Find the selected semesters
            const fromSemester = semesters.find(s => s.Idx == fromSemesterIdx);
            const toSemester = semesters.find(s => s.Idx == toSemesterIdx);

            if (!fromSemester || !toSemester) {
                Swal.fire({
                    title: "ERROR",
                    text: "Invalid semester selection!",
                    icon: "error"
                });
                return false;
            }

            // Check if they are the same semester
            if (fromSemesterIdx === toSemesterIdx) {
                Swal.fire({
                    title: "ERROR",
                    text: "From and To semesters cannot be the same!",
                    icon: "error"
                });
                return false;
            }

            // Validate semester codes (To must be greater than From)
            // Convert to string for comparison
            const fromCode = String(fromSemester.SemesterCode);
            const toCode = String(toSemester.SemesterCode);

            if (parseInt(toCode) <= parseInt(fromCode)) {
                Swal.fire({
                    title: "ERROR",
                    text: "To semester must be after From semester!",
                    icon: "error"
                });
                return false;
            }

            return true;
        }
    </script>
    <?php
}
?>

    <script class="init">
        $(document).ready(function() {
            DataTable_AcademicYears = $("#academicyearinfo").DataTable({
                "processing": true,
                "serverSide": true,
                "lengthMenu": [ 30, 50, 75, 100, 150, 300, 500 ],
                "ajax": "ssps/m_academicyearinfo_ssps.php",
                "order": [[ 0, "desc" ]],
                "fnInitComplete": function(oSettings, json) {
                    // Add "Clear Filter" button to Filter
                    let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                    btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                    $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                        $('#' + oSettings.sTableId).dataTable().fnFilter('');
                    });
                },
                "fnDrawCallback": function() {
                    $('#academicyearinfo tr td:nth-child(1)').css('text-align', 'center');
                    $('#academicyearinfo tr td:nth-child(2)').css('text-align', 'center');
                    $('#academicyearinfo tr td:nth-child(3)').css('text-align', 'center');
                    <?php
                    if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                    ?>
                    $('#academicyearinfo tr td:nth-child(4)').css('text-align', 'center');
                    <?php
                    }
                    ?>
                },
                "columns": [
                    { "data": 'Idx', "visible": false }, // Hidden but still loaded
                    { "data": 'AcademicYear' },
                    { "data": 'FromCode' },
                    { "data": 'ToCode' },
                    <?php
                    if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                    ?>
                    { "data": "" } // used for representing menu options
                    <?php
                    }
                    ?>
                ],
                "columnDefs": [ {
                    "targets"  : 'no-sort',
                    "orderable": false,
                }
                    <?php
                    if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                    ?>
                    ,{
                        "targets": -1,
                        "data": null,
                        "orderable": false,
                        "defaultContent": "<div style=\"width:100%;text-align:center;\"><button id=\"remove\" class=\"btn btn-danger btn-xs glyphicon glyphicon-remove\" style=\"min-height: 20px;\"></button></div>"
                    }
                    <?php
                    }
                    ?>
                ]
            });

            <?php
            if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
            ?>
            async_commons.setDataTable(DataTable_AcademicYears);

            $('#academicyearinfo tbody').on( 'click', '#remove', function () {
                const data = DataTable_AcademicYears.row( $(this).parents('tr') ).data();
                RemoveAcademicYearInfo(data.Idx, data.AcademicYear);
            } );

            <?php
            }
            ?>
        } );

    </script>


    <div class="pagebacklayout">
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">ACADEMIC YEAR INFORMATION</span>&nbsp;</p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td width="80%"></td>
                    <td width="20%" align="right">
                        <?php
                        if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                            ?>
                            <button class="btn btn-danger btn-sm" onclick="AddAcademicYearInfo();return false;">ADD ACADEMIC YEAR</button>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
            </table>

            <div class="CSSTable_SSPSLIST">
                <table id="academicyearinfo" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th style="display:none;">IDX</th>
                        <th>ACADEMIC YEAR</th>
                        <th>FROM SEMESTER CODE</th>
                        <th>TO SEMESTER CODE</th>
                        <?php
                        if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                            ?>
                            <th class="no-sort">OPERATION</th>
                            <?php
                        }
                        ?>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>


<?php include('footer.php');?>