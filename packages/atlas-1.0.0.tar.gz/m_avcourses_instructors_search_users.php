<?php
include_once 'session_handler.php';

$searchTerm = isset($_POST['searchTerm']) ? trim($_POST['searchTerm']) : '';
$avcIdx = isset($_POST['avcIdx']) ? intval($_POST['avcIdx']) : 0;

if (empty($searchTerm) || $avcIdx <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Search term and course ID required'
    ]);
    exit;
}

try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Get list of already assigned instructors for this course
    $assignedQuery = "SELECT `Instructor` FROM `AVCoursesInstructors` WHERE `AVCourseIdx` = ?";
    $assignedResult = $DBCONNECTION->prepare_execute_catch_error($assignedQuery, [$avcIdx]);

    $assignedIds = [];
    while ($row = $assignedResult->fetch_assoc()) {
        $assignedIds[] = $row['Instructor'];
    }

    // Search for users, excluding already assigned instructors
    $query = "SELECT `Idx`, `Name`, `Email` 
              FROM `UserAccounts` 
              WHERE (`Name` LIKE ? OR `Email` LIKE ?) 
              AND `Disabled` = 0";

    // Add exclusion for already assigned instructors
    if (!empty($assignedIds)) {
        $placeholders = implode(',', array_fill(0, count($assignedIds), '?'));
        $query .= " AND `Idx` NOT IN ($placeholders)";
    }

    $query .= " ORDER BY `Name` ASC LIMIT 20";

    $searchPattern = '%' . $searchTerm . '%';
    $params = array_merge([$searchPattern, $searchPattern], $assignedIds);

    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = [
            'Idx' => $row['Idx'],
            'Name' => $row['Name'],
            'Email' => $row['Email']
        ];
    }

    echo json_encode([
        'success' => true,
        'users' => $users
    ]);

} catch (mysqli_sql_exception $e) {
    error_log("Error searching users: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred'
    ]);
} catch (Exception $e) {
    error_log("Error searching users: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error occurred'
    ]);
}
?>