<?php
require_once('../php_include/dbconnection_class.php');

class PerformanceIndicatorAnalyzer {
    private $db;

    public function __construct(Dbconnection $dbConnection) {
        $this->db = $dbConnection;
    }

    /**
     * Get Performance Indicator Analysis
     * Auto-saves to database after calculation
     *
     * @param int $abetCourseIdx
     * @param int $availableCourseIdx
     * @param int $academicProgramIdx
     * @param bool $autoSave Whether to automatically save to database (default: true)
     * @return array Analysis results
     */
    public function getAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx, $autoSave = true) {
        // Validate inputs
        if (empty($abetCourseIdx) || empty($availableCourseIdx) || empty($academicProgramIdx)) {
            throw new InvalidArgumentException('All parameters are required');
        }

        $piInfo = $this->getPerformanceIndicatorMeasures($abetCourseIdx, $availableCourseIdx, $academicProgramIdx);
        $studentScores = $this->getStudentScores($abetCourseIdx, $availableCourseIdx, $academicProgramIdx);

        $data = $this->calculateAnalysis($piInfo, $studentScores);

        // ⬇️ AUTO-SAVE TO DATABASE
        if ($autoSave && !empty($data)) {
            try {
                $this->db->autocommit(FALSE);
                $this->saveMainAnalysisViaSP($data, $abetCourseIdx, $availableCourseIdx, $academicProgramIdx);
                $this->db->commit();
                $this->db->autocommit(TRUE);
            } catch (Exception $e) {
                $this->db->rollback();
                $this->db->autocommit(TRUE);
                // Log error but don't fail the analysis display
                error_log("Failed to auto-save analysis: " . $e->getMessage());
            }
        }

        return $data;
    }

    /**
     * Get Performance Indicators and their measures
     */
    private function getPerformanceIndicatorMeasures($abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        $stmt = $this->db->prepare("
            SELECT 
                GPIS.Idx AS PIIdx,
                STNTOUTCMS.SO AS SO,
                GPIS.GPI AS PI,
                GPIS.Description AS Description,
                AM.Idx AS MeasureIdx,
                AM.Measure AS MeasureNumber
            FROM GeneralPerformanceIndicators AS GPIS
            INNER JOIN StudentOutcomes AS STNTOUTCMS 
                ON (GPIS.SOIdx = STNTOUTCMS.Idx AND STNTOUTCMS.AcademicProgram = ?)
            INNER JOIN AssessmentMeasures AS AM 
                ON (AM.GPI = GPIS.Idx AND AM.AvailableCourseIdx = ? AND AM.AbetCourseIdx = ?)
            WHERE GPIS.AcademicProgram = ?
            ORDER BY GPIS.Idx, AM.Measure
        ");

        $stmt->bind_param('iiii', $academicProgramIdx, $availableCourseIdx, $abetCourseIdx, $academicProgramIdx);
        $stmt->execute();
        $results = $stmt->get_result();

        $piInfo = array();
        while ($row = $results->fetch_assoc()) {
            $piIdx = $row['PIIdx'];

            if (!isset($piInfo[$piIdx])) {
                $piInfo[$piIdx] = array(
                    'SO' => $row['SO'],
                    'PI' => $row['PI'],
                    'Description' => $row['Description'],
                    'RequiredMeasures' => array()
                );
            }

            $piInfo[$piIdx]['RequiredMeasures'][] = $row['MeasureIdx'];
        }
        $stmt->close();

        return $piInfo;
    }

    /**
     * Get raw student scores
     */
    private function getStudentScores($abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        $stmt = $this->db->prepare("
            SELECT 
                GPIS.Idx AS PIIdx,
                SCSHEET.StudentNo,
                SCSHEET.AssessmentMeasureIdx,
                SCSHEET.LevelOfAttainment,
                AM.Measure
            FROM AssessmentMeasures AS ASSMNTMEASURES
            INNER JOIN GeneralPerformanceIndicators AS GPIS 
                ON (GPIS.Idx = ASSMNTMEASURES.GPI AND GPIS.AcademicProgram = ?)
            INNER JOIN Scoresheet AS SCSHEET 
                ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
            INNER JOIN AssessmentMeasures AS AM
                ON (SCSHEET.AssessmentMeasureIdx = AM.Idx)
            WHERE ASSMNTMEASURES.AvailableCourseIdx = ?
              AND ASSMNTMEASURES.AbetCourseIdx = ?
            ORDER BY GPIS.Idx, SCSHEET.StudentNo, SCSHEET.AssessmentMeasureIdx
        ");

        $stmt->bind_param('iii', $academicProgramIdx, $availableCourseIdx, $abetCourseIdx);
        $stmt->execute();
        $results = $stmt->get_result();

        $studentScores = array();
        while ($row = $results->fetch_assoc()) {
            $piIdx = $row['PIIdx'];
            $studentNo = $row['StudentNo'];
            $measureIdx = $row['AssessmentMeasureIdx'];

            if (!isset($studentScores[$piIdx])) {
                $studentScores[$piIdx] = array();
            }

            if (!isset($studentScores[$piIdx][$studentNo])) {
                $studentScores[$piIdx][$studentNo] = array(
                    'measureData' => array(),
                    'measureDetails' => array()
                );
            }

            if (!isset($studentScores[$piIdx][$studentNo]['measureData'][$measureIdx])) {
                $studentScores[$piIdx][$studentNo]['measureData'][$measureIdx] = floatval($row['LevelOfAttainment']);
                $studentScores[$piIdx][$studentNo]['measureDetails'][] = array(
                    'measureIdx' => $measureIdx,
                    'measure' => $row['Measure'],
                    'score' => floatval($row['LevelOfAttainment'])
                );
            }
        }
        $stmt->close();

        return $studentScores;
    }

    /**
     * Calculate analysis from Performance Indicator info and student scores
     */
    private function calculateAnalysis($piInfo, $studentScores) {
        $data = array();

        foreach ($piInfo as $piIdx => $piData) {
            $requiredMeasures = $piData['RequiredMeasures'];
            $totalMeasures = count($requiredMeasures);

            if ($totalMeasures == 0) continue;

            $validStudentAverages = array();
            $studentsAbove2 = 0;
            $studentsAbove3 = 0;
            $studentDetails = array();

            if (isset($studentScores[$piIdx])) {
                foreach ($studentScores[$piIdx] as $studentNo => $studentData) {
                    $studentMeasureData = $studentData['measureData'];
                    $studentMeasureIndices = array_keys($studentMeasureData);
                    $missingMeasures = array_diff($requiredMeasures, $studentMeasureIndices);

                    // Check for missing measures
                    if (count($missingMeasures) > 0) {
                        $studentDetails[] = array(
                            'studentNo' => $studentNo,
                            'measures' => $studentData['measureDetails'],
                            'average' => 0,
                            'included' => false,
                            'reason' => "Missing " . count($missingMeasures) . " required measure(s) for this PI"
                        );
                        continue;
                    }

                    // Check for zero scores
                    $hasZeroScore = false;
                    $zeroMeasures = array();
                    foreach ($requiredMeasures as $requiredMeasureIdx) {
                        if (isset($studentMeasureData[$requiredMeasureIdx]) && $studentMeasureData[$requiredMeasureIdx] == 0) {
                            $hasZeroScore = true;
                            foreach ($studentData['measureDetails'] as $detail) {
                                if ($detail['measureIdx'] == $requiredMeasureIdx) {
                                    $zeroMeasures[] = 'M' . $detail['measure'];
                                    break;
                                }
                            }
                        }
                    }

                    if ($hasZeroScore) {
                        $studentDetails[] = array(
                            'studentNo' => $studentNo,
                            'measures' => $studentData['measureDetails'],
                            'average' => 0,
                            'included' => false,
                            'reason' => "No submission for: " . implode(', ', $zeroMeasures)
                        );
                        continue;
                    }

                    // Calculate average
                    $scoresForAvg = array();
                    foreach ($requiredMeasures as $requiredMeasureIdx) {
                        $scoresForAvg[] = $studentMeasureData[$requiredMeasureIdx];
                    }

                    $studentAvg = array_sum($scoresForAvg) / count($scoresForAvg);
                    $validStudentAverages[] = $studentAvg;

                    if ($studentAvg >= 2.0) $studentsAbove2++;
                    if ($studentAvg >= 3.0) $studentsAbove3++;

                    $studentDetails[] = array(
                        'studentNo' => $studentNo,
                        'measures' => $studentData['measureDetails'],
                        'average' => round($studentAvg, 2),
                        'included' => true
                    );
                }
            }

            $overallAvg = count($validStudentAverages) > 0
                ? array_sum($validStudentAverages) / count($validStudentAverages)
                : 0;

            // Match the original field names from your code
            $data[] = array(
                'DT_RowId' => 'row_' . $piIdx,
                'GPIIdx' => $piIdx,
                'GPI' => $piData['SO'] . '-' . $piData['PI'],
                'GPIDescription' => $piData['Description'],
                'AVG' => round($overallAvg, 2),
                'TOTAL' => count($validStudentAverages),
                'TOPFIFTY' => $studentsAbove2,
                'TOPTWENTYFIVE' => $studentsAbove3,
                'TotalMeasures' => $totalMeasures,
                'StudentDetails' => $studentDetails
            );
        }

        return $data;
    }

    /**
     * Get analysis formatted for DataTables
     */
    public function getDataTablesResponse($abetCourseIdx, $availableCourseIdx, $academicProgramIdx, $draw = 0) {
        $data = $this->getAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx);

        return array(
            "draw" => intval($draw),
            "recordsTotal" => count($data),
            "recordsFiltered" => count($data),
            "data" => $data
        );
    }

    /**
     * Save analysis results to database using stored procedure
     *
     * @param int $abetCourseIdx
     * @param int $availableCourseIdx
     * @param int $academicProgramIdx
     * @return array Result with success status and message
     */
    public function saveAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        try {
            $analysisData = $this->getAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx);

            if (empty($analysisData)) {
                return array(
                    'success' => false,
                    'message' => 'No data to save',
                    'recordsSaved' => 0
                );
            }

            // Start transaction
            $this->db->autocommit(FALSE);

            // Save using stored procedure
            $recordsSaved = $this->saveMainAnalysisViaSP($analysisData, $abetCourseIdx, $availableCourseIdx, $academicProgramIdx);

            // Commit transaction
            $this->db->commit();
            $this->db->autocommit(TRUE);

            return array(
                'success' => true,
                'message' => 'Analysis saved successfully',
                'recordsSaved' => $recordsSaved,
                'timestamp' => date('Y-m-d H:i:s')
            );

        } catch (Exception $e) {
            // Rollback on error
            $this->db->rollback();
            $this->db->autocommit(TRUE);

            return array(
                'success' => false,
                'message' => 'Error saving analysis: ' . $e->getMessage(),
                'recordsSaved' => 0
            );
        }
    }

    /**
     * Save main analysis data using stored procedure
     */
    private function saveMainAnalysisViaSP($analysisData, $abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        $stmt = $this->db->prepare("
            CALL SP_SaveAnalyzedPerformanceIndicators(?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $recordsSaved = 0;

        foreach ($analysisData as $piData) {
            $stmt->bind_param(
                'iiissdiii',
                $availableCourseIdx,
                $abetCourseIdx,
                $academicProgramIdx,
                $piData['GPIIdx'],
                $piData['GPI'],
                $piData['AVG'],
                $piData['TOTAL'],
                $piData['TOPFIFTY'],
                $piData['TOPTWENTYFIVE']
            );

            if ($stmt->execute()) {
                $recordsSaved++;
            }

            // Clear result set (important for stored procedures)
            while ($stmt->more_results()) {
                $stmt->next_result();
                if ($result = $stmt->get_result()) {
                    $result->free();
                }
            }
        }

        $stmt->close();
        return $recordsSaved;
    }

    /**
     * Retrieve saved analysis from database
     *
     * @param int $abetCourseIdx
     * @param int $availableCourseIdx
     * @param int $academicProgramIdx
     * @param bool $calculateIfMissing If true, calculate and save if no data exists (default: true)
     * @return array Saved analysis data or calculated data
     */
    public function getSavedAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx, $calculateIfMissing = true) {
        $stmt = $this->db->prepare("
            SELECT * FROM Analyzed_PerformanceIndicators
            WHERE AvailableCourseIdx = ? 
              AND AbetCourseIdx = ? 
              AND AcademicProgramIdx = ?
            ORDER BY GPIIdx
        ");

        $stmt->bind_param('iii', $availableCourseIdx, $abetCourseIdx, $academicProgramIdx);
        $stmt->execute();
        $result = $stmt->get_result();

        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = array(
                'DT_RowId' => 'row_' . $row['GPIIdx'],
                'PIIdx' => $row['GPIIdx'],
                'PI' => $row['GPI'],
                'AVG' => floatval($row['AVG']),
                'TOTAL' => intval($row['TOTAL']),
                'TOPFIFTY' => intval($row['TOPFIFTY']),
                'TOPTWENTYFIVE' => intval($row['TOPTWENTYFIVE'])
            );
        }

        $stmt->close();

        // If no data found and calculateIfMissing is true, calculate and save
        if (empty($data) && $calculateIfMissing) {
            $data = $this->getAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx, true);
        }

        return $data;
    }

    /**
     * Check if analysis exists for given parameters
     */
    public function analysisExists($abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count FROM Analyzed_PerformanceIndicators
            WHERE AvailableCourseIdx = ? 
              AND AbetCourseIdx = ? 
              AND AcademicProgramIdx = ?
        ");

        $stmt->bind_param('iii', $availableCourseIdx, $abetCourseIdx, $academicProgramIdx);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();

        return $row['count'] > 0;
    }
}