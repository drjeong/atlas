/**
 * Attainment Level Styling and Configuration
 * Database-backed version - thresholds stored per program in MySQL
 * Version: 0.0.004
 */

const AttainmentConfig = {
    thresholds: {
        basic: {
            score: 2.0,
            green: 90,
            yellow: 80,
            label: 'Basic Competency (≥2.0)'
        },
        proficiency: {
            score: 3.0,
            green: 80,
            yellow: 70,
            label: 'Proficiency (≥3.0)'
        }
    },

    colors: {
        green: { bg: '#d4edda', text: '#155724', border: '#c3e6cb' },
        yellow: { bg: '#fff3cd', text: '#856404', border: '#ffeaa7' },
        red: { bg: '#f8d7da', text: '#721c24', border: '#f5c6cb' },
        gray: { bg: '#f9f9f9', text: '#333', border: '#ddd' }
    },

    // Load thresholds from database via AJAX
    loadThresholds: function(callback) {
        //console.log('→ Attempting to load thresholds from database...');
        //console.log('→ API URL: ssps/p_attainment_thresholds_ssps.php?action=get');

        $.ajax({
            url: 'ssps/p_attainment_thresholds_ssps.php?action=get',
            method: 'GET',
            dataType: 'json',
            success: (response) => {
                //console.log('← Server response received:', response);

                if (response.success && response.thresholds) {
                    this.thresholds = response.thresholds;
                    //console.log('✓ SUCCESS: Thresholds loaded from database');
                    //console.log('  Basic - Green:', this.thresholds.basic.green, '% Yellow:', this.thresholds.basic.yellow, '%');
                    //console.log('  Proficiency - Green:', this.thresholds.proficiency.green, '% Yellow:', this.thresholds.proficiency.yellow, '%');
                    if (callback) callback(true);
                } else {
                    console.error('✗ FAILED: Server returned error');
                    console.error('  Message:', response.message || 'Unknown error');
                    console.log('  Using default thresholds instead');
                    if (callback) callback(false);
                }
            },
            error: (xhr, status, error) => {
                console.error('✗ AJAX ERROR: Failed to load thresholds');
                console.error('  Status:', status);
                console.error('  Error:', error);
                console.error('  HTTP Status:', xhr.status);
                console.error('  Response Text:', xhr.responseText);
                console.log('  Using default thresholds instead');

                // Try to parse error response
                try {
                    const errorResponse = JSON.parse(xhr.responseText);
                    console.error('  Parsed Error:', errorResponse);
                } catch (e) {
                    console.error('  Could not parse error response');
                }

                if (callback) callback(false);
            }
        });
    },

    // Save thresholds to database via AJAX
    saveThresholds: function(callback) {
        //console.log('→ Saving thresholds to database...');
        //console.log('  Thresholds to save:', this.thresholds);

        $.ajax({
            url: 'ssps/p_attainment_thresholds_ssps.php?action=update',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                thresholds: this.thresholds
            }),
            dataType: 'json',
            success: (response) => {
                //console.log('← Save response:', response);

                if (response.success) {
                    //console.log('✓ SUCCESS: Thresholds saved to database');
                    if (callback) callback(true, response.message);
                } else {
                    console.error('✗ FAILED: Could not save thresholds');
                    console.error('  Message:', response.message);
                    if (callback) callback(false, response.message);
                }
            },
            error: (xhr, status, error) => {
                console.error('✗ AJAX ERROR: Failed to save thresholds');
                console.error('  Status:', status);
                console.error('  Error:', error);
                console.error('  Response:', xhr.responseText);
                if (callback) callback(false, error);
            }
        });
    },

    // Reset thresholds to defaults
    resetThresholds: function(callback) {
        //console.log('→ Resetting thresholds to defaults...');

        $.ajax({
            url: 'ssps/p_attainment_thresholds_ssps.php?action=reset',
            method: 'POST',
            dataType: 'json',
            success: (response) => {
                //console.log('← Reset response:', response);

                if (response.success) {
                    //console.log('✓ SUCCESS: Thresholds reset to defaults');
                    // Reload thresholds after reset
                    this.loadThresholds(callback);
                } else {
                    console.error('✗ FAILED: Could not reset thresholds');
                    console.error('  Message:', response.message);
                    if (callback) callback(false, response.message);
                }
            },
            error: (xhr, status, error) => {
                console.error('✗ AJAX ERROR: Failed to reset thresholds');
                console.error('  Status:', status);
                console.error('  Error:', error);
                console.error('  Response:', xhr.responseText);
                if (callback) callback(false, error);
            }
        });
    },

    // Update threshold values (in memory, call saveThresholds to persist)
    updateThresholds: function(type, greenValue, yellowValue) {
        if (this.thresholds[type]) {
            this.thresholds[type].green = parseFloat(greenValue);
            this.thresholds[type].yellow = parseFloat(yellowValue);
            //console.log('Updated', type, 'thresholds in memory:','green =', greenValue, '%, yellow =', yellowValue, '%');
        }
    }
};

/**
 * Apply cell styling to course assessment tables
 */
function applyCellStyling(tableSelector = '#courseAssessmentTable') {
    const $table = $(tableSelector);

    // Style regular score cells
    $table.find('tbody tr td[data-value]').each(function() {
        const cellValue = $(this).attr('data-value');
        $(this).css({
            'text-align': 'center',
            'padding': '10px'
        });

        if (cellValue && cellValue !== '') {
            const score = parseFloat(cellValue);
            if (!isNaN(score)) {
                if (score >= 3.0) {
                    $(this).css({
                        'background-color': AttainmentConfig.colors.green.bg,
                        'color': AttainmentConfig.colors.green.text,
                        'font-weight': 'bold'
                    });
                } else if (score >= 2.0) {
                    $(this).css({
                        'background-color': AttainmentConfig.colors.yellow.bg,
                        'color': AttainmentConfig.colors.yellow.text
                    });
                } else if (score > 0) {
                    $(this).css({
                        'background-color': AttainmentConfig.colors.red.bg,
                        'color': AttainmentConfig.colors.red.text
                    });
                }
            }
        } else {
            $(this).css('background-color', AttainmentConfig.colors.gray.bg);
        }
    });

    // Style attainment cells with configurable thresholds
    $table.find('tbody tr td[data-attainment]').each(function() {
        const attainmentValue = $(this).attr('data-attainment');
        const threshold = parseFloat($(this).attr('data-threshold'));

        if (attainmentValue && attainmentValue !== '') {
            const percent = parseFloat(attainmentValue);

            if (!isNaN(percent) && !isNaN(threshold)) {
                let config;

                if (threshold === AttainmentConfig.thresholds.basic.score) {
                    config = AttainmentConfig.thresholds.basic;
                } else if (threshold === AttainmentConfig.thresholds.proficiency.score) {
                    config = AttainmentConfig.thresholds.proficiency;
                }

                if (config) {
                    if (percent >= config.green) {
                        $(this).css({
                            'background-color': AttainmentConfig.colors.green.bg,
                            'color': AttainmentConfig.colors.green.text,
                            'font-weight': 'bold'
                        });
                    } else if (percent >= config.yellow) {
                        $(this).css({
                            'background-color': AttainmentConfig.colors.yellow.bg,
                            'color': AttainmentConfig.colors.yellow.text,
                            'font-weight': 'bold'
                        });
                    } else if (percent > 0) {
                        $(this).css({
                            'background-color': AttainmentConfig.colors.red.bg,
                            'color': AttainmentConfig.colors.red.text,
                            'font-weight': 'bold'
                        });
                    }
                }
            }
        }
    });
}

/**
 * Generate legend HTML with current thresholds
 */
function generateLegendHTML(editable = false) {
    const basic = AttainmentConfig.thresholds.basic;
    const proficiency = AttainmentConfig.thresholds.proficiency;

    let html = `
        <div class="color-legend">
            <h4>📊 Color Legend - Attainment Levels</h4>
            ${editable ? '<button id="editThresholdsBtn" class="btn-edit-thresholds">⚙️ Edit Thresholds</button>' : ''}
            
            <div class="legend-sections">
                <div class="legend-section">
                    <div class="legend-title">${basic.label}</div>
                    <div class="legend-items">
                        <div class="legend-item">
                            <div class="legend-color green"></div>
                            <span class="legend-text">≥${basic.green}%</span>
                        </div>
                        <div class="legend-item">
                            <div class="legend-color yellow"></div>
                            <span class="legend-text">${basic.yellow}-${basic.green - 1}%</span>
                        </div>
                        <div class="legend-item">
                            <div class="legend-color red"></div>
                            <span class="legend-text">&lt;${basic.yellow}%</span>
                        </div>
                    </div>
                </div>

                <div class="legend-section">
                    <div class="legend-title">${proficiency.label}</div>
                    <div class="legend-items">
                        <div class="legend-item">
                            <div class="legend-color green"></div>
                            <span class="legend-text">≥${proficiency.green}%</span>
                        </div>
                        <div class="legend-item">
                            <div class="legend-color yellow"></div>
                            <span class="legend-text">${proficiency.yellow}-${proficiency.green - 1}%</span>
                        </div>
                        <div class="legend-item">
                            <div class="legend-color red"></div>
                            <span class="legend-text">&lt;${proficiency.yellow}%</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    return html;
}

/**
 * Show threshold editing modal
 */
function showThresholdEditor(onUpdate) {
    const basic = AttainmentConfig.thresholds.basic;
    const proficiency = AttainmentConfig.thresholds.proficiency;

    Swal.fire({
        title: '⚙️ Configure Attainment Thresholds',
        html: `
            <div style="text-align: left; padding: 20px;">
                <h4 style="margin-bottom: 15px; color: #333;">Basic Competency (≥2.0)</h4>
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 5px;">Green threshold (%):</label>
                    <input type="number" id="basicGreen" value="${basic.green}" min="0" max="100" step="0.01"
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    
                    <label style="display: block; margin-top: 10px; margin-bottom: 5px;">Yellow threshold (%):</label>
                    <input type="number" id="basicYellow" value="${basic.yellow}" min="0" max="100" step="0.01"
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <h4 style="margin-bottom: 15px; color: #333;">Proficiency (≥3.0)</h4>
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 5px;">Green threshold (%):</label>
                    <input type="number" id="proficiencyGreen" value="${proficiency.green}" min="0" max="100" step="0.01"
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    
                    <label style="display: block; margin-top: 10px; margin-bottom: 5px;">Yellow threshold (%):</label>
                    <input type="number" id="proficiencyYellow" value="${proficiency.yellow}" min="0" max="100" step="0.01"
                           style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                
                <p style="font-size: 12px; color: #666; font-style: italic;">
                    Note: Values below yellow threshold will be shown in red. These settings are saved per program in the database.
                </p>
            </div>
        `,
        width: '500px',
        showCancelButton: true,
        showDenyButton: true,
        confirmButtonText: 'Apply & Save',
        denyButtonText: 'Reset to Defaults',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#28a745',
        denyButtonColor: '#6c757d',
        preConfirm: () => {
            const basicGreen = parseFloat(document.getElementById('basicGreen').value);
            const basicYellow = parseFloat(document.getElementById('basicYellow').value);
            const proficiencyGreen = parseFloat(document.getElementById('proficiencyGreen').value);
            const proficiencyYellow = parseFloat(document.getElementById('proficiencyYellow').value);

            // Validation - Check for valid numbers
            if (isNaN(basicGreen) || isNaN(basicYellow) || isNaN(proficiencyGreen) || isNaN(proficiencyYellow)) {
                Swal.showValidationMessage('Please enter valid numbers for all fields');
                return false;
            }

            // Validation - Check range (0-100)
            if (basicGreen < 0 || basicGreen > 100) {
                Swal.showValidationMessage('Basic green threshold must be between 0 and 100');
                return false;
            }
            if (basicYellow < 0 || basicYellow > 100) {
                Swal.showValidationMessage('Basic yellow threshold must be between 0 and 100');
                return false;
            }
            if (proficiencyGreen < 0 || proficiencyGreen > 100) {
                Swal.showValidationMessage('Proficiency green threshold must be between 0 and 100');
                return false;
            }
            if (proficiencyYellow < 0 || proficiencyYellow > 100) {
                Swal.showValidationMessage('Proficiency yellow threshold must be between 0 and 100');
                return false;
            }

            // Validation - Yellow must be less than green
            if (basicYellow >= basicGreen) {
                Swal.showValidationMessage('Basic: Yellow threshold must be less than green threshold');
                return false;
            }
            if (proficiencyYellow >= proficiencyGreen) {
                Swal.showValidationMessage('Proficiency: Yellow threshold must be less than green threshold');
                return false;
            }

            return { basicGreen, basicYellow, proficiencyGreen, proficiencyYellow };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const { basicGreen, basicYellow, proficiencyGreen, proficiencyYellow } = result.value;

            AttainmentConfig.updateThresholds('basic', basicGreen, basicYellow);
            AttainmentConfig.updateThresholds('proficiency', proficiencyGreen, proficiencyYellow);

            // Save to database
            AttainmentConfig.saveThresholds((success, message) => {
                if (success) {
                    Swal.fire({
                        title: 'Success!',
                        text: 'Thresholds updated and saved to database. Refreshing table...',
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        if (onUpdate) onUpdate();
                    });
                } else {
                    Swal.fire({
                        title: 'Error',
                        text: 'Failed to save thresholds to database: ' + message,
                        icon: 'error',
                        footer: 'Check browser console for details'
                    });
                }
            });
        } else if (result.isDenied) {
            // Reset to defaults
            Swal.fire({
                title: 'Reset to Defaults?',
                text: 'This will reset thresholds to: Basic (90%/80%), Proficiency (80%/70%)',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, reset',
                confirmButtonColor: '#dc3545'
            }).then((resetResult) => {
                if (resetResult.isConfirmed) {
                    AttainmentConfig.resetThresholds((success) => {
                        if (success) {
                            Swal.fire({
                                title: 'Reset Complete',
                                text: 'Thresholds have been reset to default values',
                                icon: 'success',
                                timer: 1500,
                                showConfirmButton: false
                            }).then(() => {
                                if (onUpdate) onUpdate();
                            });
                        } else {
                            Swal.fire({
                                title: 'Error',
                                text: 'Failed to reset thresholds',
                                icon: 'error',
                                footer: 'Check browser console for details'
                            });
                        }
                    });
                }
            });
        }
    });
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { applyCellStyling, generateLegendHTML, showThresholdEditor, AttainmentConfig };
}