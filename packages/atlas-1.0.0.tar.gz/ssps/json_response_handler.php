<?php
// Start output buffering
ob_start();

// Include session handler
include_once 'session_handler.php';

// Clear any captured output
ob_end_clean();

// Set JSON headers
header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
header('Content-Type: application/json; charset=utf-8');

// Optional: Set error handler to return JSON errors
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("PHP Error: $errstr in $errfile on line $errline");
    // Don't output directly, let the script handle errors
    return false;
});

// Function to send JSON response and exit
function sendJsonResponse($data) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Function to send JSON error and exit
function sendJsonError($message, $code = 400) {
    http_response_code($code);
    sendJsonResponse(['error' => $message]);
}
