<?php
/**
 * Listing all used functions
 * Description: frequently used functions
 *
 *
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 03/24/2024 - Add a function (sanitizeFileName) to replace special symbols to underscore when creating file name.
 * 09/22/2024 - Add functions (setPermissions and hasPermission) to check permissions
 */

function getAbetSyllabusFileName($Subject, $Num) {
    $AbetSyllabusPDF_FileName = 'abet_syllabus';
    $AbetSyllabusPDF_FileName .= '_'. str_replace(" ","_",strtolower($Subject));
    $AbetSyllabusPDF_FileName .= '_'. str_replace(" ","_",strtolower($Num));
    $AbetSyllabusPDF_FileName .= '.pdf';

    return $AbetSyllabusPDF_FileName;
}

function sanitizeFileName($fileName) {

    // replace all white space to underscore
    $fileName = preg_replace("/\s+/", "_", $fileName);


    // Define a list of special symbols that need to be replaced
    $specialSymbols = array("~", "`", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "[", "]", "{", "}", "|", "\\", ";", ":", "'", "\"", "<", ">", ",", ".", "?", "/");

    // Replace each special symbol with an underscore
    foreach ($specialSymbols as $symbol) {
        $fileName = str_replace($symbol, '_', $fileName);
    }

    // Return the sanitized file name
    return $fileName;
}

// --------------------------------------------------------------
// RECURSIVELY SET MULTI-LEVEL ARRAY VALUES TO DEFAULT VALUE:
function nullifyArray(&$arrayData, $defaultvalue) {
  if (is_array($arrayData)) {
    foreach ($arrayData as $aKey => &$aValue) {
      if (is_array($aValue)) {
        nullifyArray($aValue, $defaultvalue);
      } else {
        $aValue = $defaultvalue;
      }
    }
    return true;     // $arrayData IS an array, and has been processed.
  } else {
    return false;    // $arrayData is NOT an array, no action(s) were performed.
  }
}

// --------------------------------------------------------------
// RECURSIVELY CHANGE ARRAY VALUES TO STRING:
function ArrayValuestoString(&$arrayData) {
	$rtnvalue = "";
	if (is_array($arrayData)) {
		foreach ($arrayData as $aKey => &$aValue) {
			if (is_array($aValue)) {
				$rtnvalue .= ArrayValuestoString($aValue);
			} else {
				$rtnvalue .= $aValue;
			}
		}
	}
	return $rtnvalue;
}

function convertSpecialCharacters($data) {
    $data = htmlentities(
        replaceSpecialCharacters($data),
        ENT_QUOTES,
        'UTF-8'
    );
    return $data;
}

function replaceSpecialCharacters($data) {
    if (empty($data)) {
        return '';
    }

    // Convert to UTF-8 if not already
    if (!mb_check_encoding($data, 'UTF-8')) {
        $data = mb_convert_encoding($data, 'UTF-8');
    }

    // Quotes and typographic characters
    $quotes = array(
        // Common quotes
        "\xC2\x9D"     => '-',    // Convert control char to hyphen
        "\xC2\xAB"     => '"',    // « (U+00AB) LEFT-POINTING DOUBLE ANGLE QUOTATION MARK
        "\xC2\xBB"     => '"',    // » (U+00BB) RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK
        "\xE2\x80\x98" => "'",    // ' (U+2018) LEFT SINGLE QUOTATION MARK
        "\xE2\x80\x99" => "'",    // ' (U+2019) RIGHT SINGLE QUOTATION MARK
        "\xE2\x80\x9A" => "'",    // ‚ (U+201A) SINGLE LOW-9 QUOTATION MARK
        "\xE2\x80\x9B" => "'",    // ‛ (U+201B) SINGLE HIGH-REVERSED-9 QUOTATION MARK
        "\xE2\x80\x9C" => '"',    // " (U+201C) LEFT DOUBLE QUOTATION MARK
        "\xE2\x80\x9D" => '"',    // " (U+201D) RIGHT DOUBLE QUOTATION MARK
        "\xE2\x80\x9E" => '"',    // „ (U+201E) DOUBLE LOW-9 QUOTATION MARK
        "\xE2\x80\x9F" => '"',    // ‟ (U+201F) DOUBLE HIGH-REVERSED-9 QUOTATION MARK
        "\xE2\x80\xB9" => "'",    // ‹ (U+2039) SINGLE LEFT-POINTING ANGLE QUOTATION MARK
        "\xE2\x80\xBA" => "'",    // › (U+203A) SINGLE RIGHT-POINTING ANGLE QUOTATION MARK

        // Additional special characters
        "\xE2\x80\x93" => "-",    // – (U+2013) EN DASH
        "\xE2\x80\x94" => "-",    // — (U+2014) EM DASH
        "\xE2\x80\xA2" => "*",    // • (U+2022) BULLET
        "\xE2\x80\xA6" => "...",  // … (U+2026) HORIZONTAL ELLIPSIS
        "\xC2\xA0"     => " ",    // NON-BREAKING SPACE
        "\xC2\xAD"     => "-",    // SOFT HYPHEN
    );

    // Replace quotes and special characters
    $data = strtr($data, $quotes);

    // Replace common accented characters
    $accents = array(
        'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A', 'Å'=>'A', 'Æ'=>'AE',
        'Ç'=>'C', 'È'=>'E', 'É'=>'E', 'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I',
        'Î'=>'I', 'Ï'=>'I', 'Ð'=>'D', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O',
        'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U', 'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U',
        'Ý'=>'Y', 'Þ'=>'TH', 'ß'=>'ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a',
        'ä'=>'a', 'å'=>'a', 'æ'=>'ae', 'ç'=>'c', 'è'=>'e', 'é'=>'e', 'ê'=>'e',
        'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i', 'ï'=>'i', 'ð'=>'d', 'ñ'=>'n',
        'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o', 'ù'=>'u',
        'ú'=>'u', 'û'=>'u', 'ü'=>'u', 'ý'=>'y', 'þ'=>'th', 'ÿ'=>'y', 'Ś'=>'S',
        'ś'=>'s', 'Ź'=>'Z', 'ź'=>'z', 'Ż'=>'Z', 'ż'=>'z', 'Ł'=>'L', 'ł'=>'l',
        'Ć'=>'C', 'ć'=>'c', 'Ń'=>'N', 'ń'=>'n'
    );

    $data = strtr($data, $accents);

    // Replace any remaining non-ASCII characters except newlines and carriage returns to a white space character
    $data = preg_replace('/[^\x20-\x7E\r\n]/u', ' ', $data);

    return trim($data);
}

function w1250_to_utf8($text) {
    $map = array(
        chr(0x8A) => chr(0xA9),
        chr(0x8C) => chr(0xA6),
        chr(0x8D) => chr(0xAB),
        chr(0x8E) => chr(0xAE),
        chr(0x8F) => chr(0xAC),
        chr(0x9C) => chr(0xB6),
        chr(0x9D) => chr(0xBB),
        chr(0xA1) => chr(0xB7),
        chr(0xA5) => chr(0xA1),
        chr(0xBC) => chr(0xA5),
        chr(0x9F) => chr(0xBC),
        chr(0xB9) => chr(0xB1),
        chr(0x9A) => chr(0xB9),
        chr(0xBE) => chr(0xB5),
        chr(0x9E) => chr(0xBE),
        chr(0x80) => '&euro;',
        chr(0x82) => '&sbquo;',
        chr(0x84) => '&bdquo;',
        chr(0x85) => '&hellip;',
        chr(0x86) => '&dagger;',
        chr(0x87) => '&Dagger;',
        chr(0x89) => '&permil;',
        chr(0x8B) => '&lsaquo;',
        chr(0x91) => '&lsquo;',
        chr(0x92) => '&rsquo;',
        chr(0x93) => '&ldquo;',
        chr(0x94) => '&rdquo;',
        chr(0x95) => '&bull;',
        chr(0x96) => '&ndash;',
        chr(0x97) => '&mdash;',
        chr(0x99) => '&trade;',
        chr(0x9B) => '&rsquo;',
        chr(0xA6) => '&brvbar;',
        chr(0xA9) => '&copy;',
        chr(0xAB) => '&laquo;',
        chr(0xAE) => '&reg;',
        chr(0xB1) => '&plusmn;',
        chr(0xB5) => '&micro;',
        chr(0xB6) => '&para;',
        chr(0xB7) => '&middot;',
        chr(0xBB) => '&raquo;',
    );
    return html_entity_decode(mb_convert_encoding(strtr($text, $map), 'UTF-8', 'ISO-8859-1'), ENT_QUOTES, 'UTF-8');
}

function formatTextForDB($text) {
    try {
        // First apply any special character replacements
        $processed = replaceSpecialCharacters($text);

        // Convert to UTF-8 if not already
        if (!mb_check_encoding($processed, 'UTF-8')) {
            $processed = mb_convert_encoding($processed, 'UTF-8');
        }

        // Clean the text for database storage
        $processed = htmlspecialchars($processed, ENT_QUOTES, 'UTF-8');

        return $processed;
    } catch (Exception $e) {
        error_log("Text formatting failed: " . $e->getMessage());
        return $text; // Return original text if conversion fails
    }
}

function replaceBulletPoints(string $text): string
{
    if (empty($text)) {
        return '';
    }

    // Unicode bullet symbols and variations
    $bullets = [
        "\x{2022}",     // • BULLET
        "\x{2023}",     // ‣ TRIANGULAR BULLET
        "\x{2043}",     // ⁃ HYPHEN BULLET
        "\x{204C}",     // ⁌ BLACK LEFTWARDS BULLET
        "\x{204D}",     // ⁍ BLACK RIGHTWARDS BULLET
        "\x{2219}",     // ∙ BULLET OPERATOR
        "\x{25CB}",     // ○ WHITE CIRCLE
        "\x{25CF}",     // ● BLACK CIRCLE
        "\x{25D8}",     // ◘ INVERSE BULLET
        "\x{25E6}",     // ◦ WHITE BULLET
        "\x{2619}",     // ☙ REVERSED ROTATED FLORAL HEART BULLET
        "\x{2765}",     // ❥ ROTATED HEAVY BLACK HEART BULLET
        "\x{2767}",     // ❧ ROTATED FLORAL HEART BULLET
        "\x{29BE}",     // ⦾ CIRCLED WHITE BULLET
        "\x{29BF}",     // ⦿ CIRCLED BULLET
        'o',            // Lowercase letter o
        'O',            // Uppercase letter O
        '0',            // Zero
        '°',            // Degree symbol
        '∘',            // Ring operator
        '◦',            // White bullet
        '☺',            // White smiling face
        '☻',            // Black smiling face
        '♦',            // Diamond
        '♣',            // Club
        '♠',            // Spade
        '♥',            // Heart
        '»',            // Right-pointing double angle quotation mark
        '›',            // Single right-pointing angle quotation mark
        '−',            // Minus sign
        '–',            // En dash
        '—',            // Em dash
        '-',            // Hyphen-minus
        '•',
    ];

    // Convert text to UTF-8 if it's not already
    if (!mb_check_encoding($text, 'UTF-8')) {
        $text = mb_convert_encoding($text, 'UTF-8', mb_detect_encoding($text));
    }

    // Split text into lines while preserving empty lines
    $lines = explode("\n", $text);

    // Count non-empty lines
    $nonEmptyLines = array_filter($lines, fn($line) => trim($line) !== '');
    $lineCount = count($nonEmptyLines);

    // If no lines, return empty string
    if ($lineCount === 0) {
        return '';
    }

    // Create patterns
    $bulletPattern = '/^[ \t]*(' . implode('|', array_map('preg_quote', $bullets)) . ')[ \t]*/u';
    $numberPattern = '/^[ \t]*\d+\.[ \t]*/'; // Matches numbered lists (e.g., "1.", "2.", etc.)
    $alphaPattern = '/^[ \t]*[a-zA-Z]\.[ \t]*/'; // Matches alphabetical lists (e.g., "a.", "b.", etc.)

    // For single line, just remove the bullet point if it exists
    if ($lineCount === 1) {
        $processedLines = [];
        foreach ($lines as $line) {
            if (trim($line) === '') {
                $processedLines[] = $line; // Preserve empty lines
                continue;
            }
            // Get the indentation
            preg_match('/^(\s*)/', $line, $matches);
            $indentation = $matches[1];

            // Remove bullet point or number if exists
            $processedLine = preg_replace([$bulletPattern, $numberPattern], '', trim($line));
            $processedLines[] = $indentation . $processedLine;
        }
        return implode("\n", $processedLines);
    }

    // For multiple lines
    $processedLines = [];
    foreach ($lines as $line) {
        if (trim($line) === '') {
            $processedLines[] = $line; // Preserve empty lines
            continue;
        }

        // Get the indentation
        preg_match('/^(\s*)/', $line, $matches);
        $indentation = $matches[1];
        $trimmedLine = trim($line);

        // Check for alphabetical or numerical lists first
        if (preg_match($alphaPattern, $trimmedLine) || preg_match($numberPattern, $trimmedLine)) {
            // Preserve the original line
            $processedLine = $trimmedLine;
        } elseif (preg_match($bulletPattern, $trimmedLine)) {
            // Replace bullet with hyphen
            $processedLine = preg_replace($bulletPattern, '- ', $trimmedLine);
        } else {
            // Check if line already starts with a hyphen
            if (!preg_match('/^[ \t]*-[ \t]/', $trimmedLine)) {
                // Add hyphen if line doesn't start with one
                $processedLine = '- ' . $trimmedLine;
            } else {
                $processedLine = $trimmedLine;
            }
        }

        // Restore indentation
        $processedLines[] = $indentation . $processedLine;
    }

    return implode("\n", $processedLines);
}

function removeNewline($text) {
    // Replace all types of newlines with a single space
    $text = str_replace(["\r\n", "\r", "\n"], ' ', $text);

    // Convert multiple spaces (including double spaces) to a single space
    $text = preg_replace('/\s+/', ' ', $text);

    // Trim extra spaces from beginning and end
    return trim($text);
}

function cleanInput($input, $dbConnection) {
    // Check if input is null or empty
    if ($input === null || $input === '') {
        return '';
    }

    // Ensure input is string
    $input = (string)$input;

    // Remove invisible characters and standardize line endings
    $input = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $input);

    // Convert special characters to their HTML entities
    $input = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');

    // Escape string for MySQL to prevent SQL injection
    if ($dbConnection instanceof mysqli) {
        $input = $dbConnection->real_escape_string($input);
    }

    return $input;
}


function replaceNewlines($text) {
    $text = str_replace(["\r\n", "\n", "\r"], "||", $text);
//    $text = preg_replace('/\s*\|\|\s*/', '||', $text); // remove white space in each line
    return $text;
}

function replaceNewlines_removeWhiteSpace($text) {
    $text = str_replace(["\r\n", "\n", "\r"], "||", $text);
    $text = preg_replace('/\s*\|\|\s*/', '||', $text); // remove white space in each line
    return $text;
}

function convertTextList($text, $newline="\n") {
    $text = trim($text);
    $html = "";
    if (strlen($text)>0) {
        $items = explode('||', $text);
        foreach ($items as $item) {
//            $html .= htmlspecialchars($item) . $newline;
            $html .= ($item) . $newline;
        }
        $html .= "";
    }
    return trim($html);
}

function convertTextLatexList($text, $enumeration_style="enumerate" ) {
    $text = trim($text);
    $html = '';
    if (strlen($text)>0) {
        // Decode HTML entities
        $text = html_entity_decode($text);

        $items = explode('||', $text);
        if (count($items) > 1) {
            $html = "\begin{".$enumeration_style."}[nosep, leftmargin=*]";
            foreach ($items as $item) {
                // Remove leading "- " from each item
                $item = ltrim(trim($item), '- ');
                $html .= "\item " . ($item) . "\n"; // Add newline after each item
            }
            $html .= " \\end{".$enumeration_style."}";
        } else {
            $html = $text;
        }
    }
    return trim($html);
}

// Function to convert the input to LaTeX lists
function convertToLatexNestedList($input) {
    // Handle both single line and multiple lines
    $lines = strpos($input, "||") !== false ? explode("||", trim($input)) : [trim($input)];

    // Initialize output with enumerate environment
    $output = "\\begin{enumerate}[nosep, leftmargin=*, topsep=0pt, partopsep=0pt]\n";

    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;

        // Detect the format and convert accordingly
        if (preg_match('/^(\d+)\./', $line)) {
            // Numbered format (e.g., "1. Item")
            $text = preg_replace('/^\d+\.\s*/', '', $line);
            $output .= "  \\item " . $text . "\n";
        }
        elseif (preg_match('/^[a-z]\./', $line)) {
            // Alphabetical format (e.g., "a. Item")
            $text = preg_replace('/^[a-z]\.\s*/', '', $line);
            $output .= "  \\item " . $text . "\n";
        }
        elseif (preg_match('/^-/', $line)) {
            // Bullet format (e.g., "- Item")
            $text = preg_replace('/^-\s*/', '', $line);
            $output .= "  \\item " . $text . "\n";
        }
        else {
            // Plain text without formatting
            $output .= "  \\item " . $line . "\n";
        }
    }

    $output .= "\\end{enumerate}\n";
    return $output;
}

// Function to highlight differences between two strings
function highlightDifferences($str1, $str2) {
    $str1 = html_entity_decode($str1, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $str2 = html_entity_decode($str2, ENT_QUOTES | ENT_HTML5, 'UTF-8');

    $highlighted1 = '';
    $highlighted2 = '';

    if (strpos($str1, "<s>") !== false || strpos($str2, "<s>") !== false )
    {   // if the html tag <s> exists, finding differences is not applied.
        if (strpos($str1, "<s>") !== false) {
            $highlighted1 = '<span style="background-color: yellow;">' . $str1 . '</span>';
            $highlighted2 = $str2;
        }
        if (strpos($str2, "<s>") !== false) {
            $highlighted1 = $str1;
            $highlighted2 = '<span style="background-color: yellow;">' . $str2 . '</span>';
        }
        return [$highlighted1, $highlighted2];
    }


    // Split the strings into arrays of words
    $words1 = explode(' ', $str1);
    $words2 = explode(' ', $str2);

    $lcsMatrix = buildLCSMatrix($words1, $words2);
    $i = count($words1);
    $j = count($words2);

    // Traverse the LCS matrix from the bottom-right
    while ($i > 0 || $j > 0) {
        if ($i > 0 && $j > 0 && $words1[$i - 1] === $words2[$j - 1]) {
            // Common word found, add to both
            $highlighted1 = $words1[$i - 1] . ' ' . $highlighted1;
            $highlighted2 = $words2[$j - 1] . ' ' . $highlighted2;
            $i--;
            $j--;
        } elseif ($j > 0 && ($i == 0 || $lcsMatrix[$i][$j - 1] >= $lcsMatrix[$i - 1][$j])) {
            // Word in $str2 not in $str1, highlight it
            $highlighted2 = '<span style="background-color: yellow;">' . $words2[$j - 1] . '</span> ' . $highlighted2;
            $highlighted1 = '&nbsp;' . $highlighted1; // Add a space to keep alignment
            $j--;
        } elseif ($i > 0 && ($j == 0 || $lcsMatrix[$i][$j - 1] < $lcsMatrix[$i - 1][$j])) {
            // Word in $str1 not in $str2, highlight it
            $highlighted1 = '<span style="background-color: yellow;">' . $words1[$i - 1] . '</span> ' . $highlighted1;
            $highlighted2 = '&nbsp;' . $highlighted2; // Add a space to keep alignment
            $i--;
        }
    }
    return [$highlighted1, $highlighted2];
}

function highlightDifferencesLatex($str1, $str2) {

    $highlighted1 = '';
    $highlighted2 = '';

    if (strpos($str1, "<s>") !== false || strpos($str2, "<s>") !== false )
    {   // if the html tag <s> exists, finding differences is not applied.
        if (strpos($str1, "<s>") !== false) {
            $highlighted1 = '\hl{' . $str1 . '}';
            $highlighted2 = '\hl{' . $str2 . '}';
        }
        if (strpos($str2, "<s>") !== false) {
            $highlighted1 = '\hl{' . $str1 . '}';
            $highlighted2 = '\hl{' . $str2 . '}';
        }
        return [$highlighted1, $highlighted2];
    }

    // Check if either string contains || (item list indicator)
    if (strpos($str1, '||') !== false || strpos($str2, '||') !== false) {
        // Split by || and process each item separately
        $items1 = explode('||', $str1);
        $items2 = explode('||', $str2);

        $maxItems = max(count($items1), count($items2));

        for ($idx = 0; $idx < $maxItems; $idx++) {
            $item1 = isset($items1[$idx]) ? trim($items1[$idx]) : '';
            $item2 = isset($items2[$idx]) ? trim($items2[$idx]) : '';

            // Compare each item separately
            list($h1, $h2) = compareTextSegments($item1, $item2);

            // Add the || delimiter back (except for the first item)
            if ($idx > 0) {
                $highlighted1 .= ' || ';
                $highlighted2 .= ' || ';
            }

            $highlighted1 .= $h1;
            $highlighted2 .= $h2;
        }

        return [$highlighted1, $highlighted2];
    }

    // No || found, use regular comparison
    list($highlighted1, $highlighted2) = compareTextSegments($str1, $str2);
    return [$highlighted1, $highlighted2];
}

function compareTextSegments($str1, $str2) {
    $highlighted1 = '';
    $highlighted2 = '';

    // Split the strings into arrays of words
    $words1 = explode(' ', $str1);
    $words2 = explode(' ', $str2);

    $lcsMatrix = buildLCSMatrix($words1, $words2);
    $i = count($words1);
    $j = count($words2);

    // Traverse the LCS matrix from the bottom-right
    while ($i > 0 || $j > 0) {
        if ($i > 0 && $j > 0 && $words1[$i - 1] === $words2[$j - 1]) {
            // Common word found, add to both
            $highlighted1 = $words1[$i - 1] . ' ' . $highlighted1;
            $highlighted2 = $words2[$j - 1] . ' ' . $highlighted2;
            $i--;
            $j--;
        } elseif ($j > 0 && ($i == 0 || $lcsMatrix[$i][$j - 1] >= $lcsMatrix[$i - 1][$j])) {
            // Word in $str2 not in $str1, highlight it
            $highlighted2 = '\hl{' . $words2[$j - 1] . '} ' . $highlighted2;
            $highlighted1 = '~ ' . $highlighted1; // Add a space to keep alignment
            $j--;
        } elseif ($i > 0 && ($j == 0 || $lcsMatrix[$i][$j - 1] < $lcsMatrix[$i - 1][$j])) {
            // Word in $str1 not in $str2, highlight it
            $highlighted1 = '\hl{' . $words1[$i - 1] . '} ' . $highlighted1;
            $highlighted2 = '~ ' . $highlighted2; // Add a space to keep alignment
            $i--;
        }
    }

    return [trim($highlighted1), trim($highlighted2)];
}

// Helper function to build the LCS matrix
function buildLCSMatrix($words1, $words2) {
    $len1 = count($words1);
    $len2 = count($words2);
    $lcsMatrix = array_fill(0, $len1 + 1, array_fill(0, $len2 + 1, 0));

    for ($i = 1; $i <= $len1; $i++) {
        for ($j = 1; $j <= $len2; $j++) {
            if ($words1[$i - 1] === $words2[$j - 1]) {
                $lcsMatrix[$i][$j] = $lcsMatrix[$i - 1][$j - 1] + 1;
            } else {
                $lcsMatrix[$i][$j] = max($lcsMatrix[$i - 1][$j], $lcsMatrix[$i][$j - 1]);
            }
        }
    }

    return $lcsMatrix;
}

function validatePDFWithPDFBox($uploadedFilePath, $pdfboxJarPath = null): bool
{
    // If PDFBox path is not provided, use default path
    if ($pdfboxJarPath === null) {
        require_once(__DIR__ . '/../../config.php');
        $pdfboxJarPath = __PDFBOX_PATH__;
    }

    // Validate that both files exist
    if (!file_exists($pdfboxJarPath)) {
        error_log("PDFBox JAR file not found at: " . $pdfboxJarPath);
        return false;
    }

    if (!file_exists($uploadedFilePath)) {
        error_log("PDF file not found at: " . $uploadedFilePath);
        return false;
    }

    // Create a temporary file for output
    $tempFile = tempnam(sys_get_temp_dir(), 'pdfbox_');

    // Execute the PDFValidator tool using Java
    $command = "java -jar " . escapeshellarg($pdfboxJarPath) . " export:text -i " . escapeshellarg($uploadedFilePath) . " -o " . escapeshellarg($tempFile) . " 2>&1";
    $output = shell_exec($command);

    // Clean up the temporary file
    if (file_exists($tempFile)) {
        unlink($tempFile);
    }

    // Also clean up the .txt file that PDFBox creates
    $txtFile = $uploadedFilePath . ".txt";
    if (file_exists($txtFile)) {
        unlink($txtFile);
    }

    // Check the output for validation results
    if (str_contains($output, 'Error extracting text for document')) {
        return false;
    }

    return true;
}

function validateFileUpload($fileInputName, $maxSizeMB = 5): array
{
    // Check if file was uploaded
    if (!isset($_FILES[$fileInputName])) {
        error_log("File upload error: No file was uploaded for input '$fileInputName'");
        return ["success" => false, "error" => "0x00251500"]; // No file uploaded
    }

    // Get the file details
    $file = $_FILES[$fileInputName];
    $maxSizeBytes = $maxSizeMB * 1024 * 1024; // Convert MB to bytes

    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errorMessage = match($file['error']) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => "File exceeds size limit",
            UPLOAD_ERR_PARTIAL => "File was only partially uploaded",
            UPLOAD_ERR_NO_FILE => "No file was uploaded",
            UPLOAD_ERR_NO_TMP_DIR => "Missing temporary folder",
            UPLOAD_ERR_CANT_WRITE => "Failed to write file to disk",
            UPLOAD_ERR_EXTENSION => "PHP extension stopped the file upload",
            default => "Unknown upload error"
        };

        error_log("File upload error: $errorMessage for file '{$file['name']}'");
        return ["success" => false, "error" => "0x00251500"];
    }

    // Check if it's a valid-uploaded file
    if (!is_uploaded_file($file['tmp_name'])) {
        error_log("File upload error: Invalid upload attempt for file '{$file['name']}'");
        return ["success" => false, "error" => "0x00251500"];
    }

    // Check file size
    if ($file['size'] > $maxSizeBytes) {
        error_log("File size error: File '{$file['name']}' exceeds maximum size of {$maxSizeMB}MB");
        return ["success" => false, "error" => "0x00251400"];
    }

    // Check if it's a PDF file
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if ($mimeType !== 'application/pdf') {
        error_log("File type error: File '{$file['name']}' is not a PDF (detected type: $mimeType)");
        return ["success" => false, "error" => "0x00251600"];
    }

    // Additional PDF validation
    $pdfContent = file_get_contents($file['tmp_name']);
    if (stripos($pdfContent, '%PDF-') !== 0) {
        error_log("File validation error: File '{$file['name']}' is not a valid PDF");
        return ["success" => false, "error" => "0x00251500"];
    }

    return ["success" => true, "file" => $file];
}

function compressPDFDoc($uploadedFilePath): bool
{
    require_once 'PDFCompressor.php';
    $compressor = new PDFCompressor();
    $result = $compressor->compressAndReplace($uploadedFilePath, 'low');

    if ($result['success']) {
//        error_log("File compressed successfully\n");
//        error_log("Original size: " . $compressor->formatSize($result['original_size']) . "\n");
//        error_log("New size: " . $compressor->formatSize($result['compressed_size']) . "\n");
        error_log("Reduced by: " . $result['reduction_percent'] . "%\n");
        return true;
    } else {
        error_log("Error: " . $result['error'] . "\n");
        return false;
    }
}

function handleFileUploadAndValidation($fileInputName, $courseInfo, $assessmentType,
                                       $assessmentNum, $assessmentPreamble, $directoryPath): false|array
{
    try {
        // Get proper file name to be saved
        $fileName = getAssessmentFileName(
            $courseInfo,
            $assessmentType,
            $assessmentNum,
            $assessmentPreamble,
            $directoryPath
        );

        // Define the path to the uploaded PDF file
        $uploadedFilePath = $directoryPath . $fileName;

//        error_log($uploadedFilePath);

        // Check if file upload was successful
        if (!move_uploaded_file($_FILES[$fileInputName]["tmp_name"], $uploadedFilePath)) {
            error_log("Error uploading the file.". $uploadedFilePath);
            echo "0x00251100";  // file not uploaded due to unexpected error
            return false;
        }

        // Validate PDF
        if (validatePDFWithPDFBox($uploadedFilePath) === false) {
            error_log("Uploaded PDF $fileName is not valid.");
            echo "0x00251500";  // PDF is corrupted
            return false;
        }

        // Compress PDF
//        compressPDFDoc($uploadedFilePath);

        return [
            'fileName' => $fileName,
            'filePath' => $uploadedFilePath
        ];

    } catch (Exception $e) {
        error_log("Error in handleFileUploadAndValidation: " . $e->getMessage());
        echo "0x00251100";
        return false;
    }
}

function getAssessmentFileName($courseInfo, $assessmentType, $assessmentNum, $preamble, $directory = ''): string
{
    // format initial file name
    $baseFileName = $preamble . strtolower($courseInfo) . '_'. $assessmentType . '_' . $assessmentNum;

    // sanitize and convert to lowercase
    $baseFileName = strtolower(sanitizeFileName($baseFileName));

    $extension = '.pdf';

    $fileName = $baseFileName . $extension;

    return $fileName;
}


function convertPDFLayout($filePath): bool
{
    try {
        require_once 'PDFLayoutConverter.php';

        $converter = new PDFLayoutConverter();
        $success = $converter->convert($filePath);

        if ($success) {
            //echo "PDF conversion completed successfully";
            return true;
        } else {
//            echo "PDF conversion failed";
            return false;
        }
    } catch (Exception $e) {
        error_log("Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Converts multiply-encoded HTML to properly displayable HTML.
 *
 * This function handles the common problem of HTML content that has been
 * encoded multiple times (often through CMS systems, databases, or text editors),
 * resulting in entities like &amp;lt; instead of < characters.
 *
 * The function:
 * 1. Iteratively decodes HTML entities until no more changes occur
 * 2. Checks if the result contains actual HTML tags
 * 3. If no HTML tags are found, converts newlines to <br> tags for display
 *
 * @param string $text The potentially multiply-encoded HTML text
 * @return string Properly decoded HTML ready for display
 */
function convert_encoded_html_to_display($text) {
    // Initialize variables for our iterative approach
    $previous = '';  // Will store the text from the previous iteration
    $current = $text; // Start with the input text

    // Iteratively decode HTML entities until the string stops changing
    // This handles cases of multiple encoding (e.g., &amp;amp;lt; -> &amp;lt; -> &lt; -> <)
    while ($previous !== $current) {
        $previous = $current; // Store current state before transformation

        // Decode HTML entities with comprehensive options:
        // - ENT_QUOTES: Convert both double and single quotes
        // - ENT_HTML5: Use HTML5 entity rules
        // - UTF-8: Ensure proper handling of multibyte characters
        $current = html_entity_decode($previous, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    // After decoding, check if we have actual HTML tags
    // This heuristic looks for paragraph tags or their encoded equivalents
    if (strpos($current, '<p>') === false && strpos($current, '&lt;p&gt;') === false) {
        // If no paragraph tags found, we likely have plain text with newlines
        // Convert newlines to <br> tags to preserve formatting when displayed in HTML
        $current = nl2br($current);
    }

    // Return the fully processed text, ready for display in an HTML context
    return $current;
}

/**
 * Removes all newline characters from a string.
 *
 * This function removes all types of newline characters that might be present
 * in a string, including:
 * - \r\n (Windows-style line endings)
 * - \r (Mac OS classic line endings)
 * - \n (Unix/Linux-style line endings)
 *
 * This is useful for:
 * - Preparing text for single-line contexts (e.g., CSV fields, JSON values)
 * - Normalizing strings before pattern matching
 * - Removing unwanted line breaks from formatted content
 *
 * @param string $string The input string containing newlines to be removed
 * @return string The processed string with all newline characters removed
 */
function removeNewlines($string) {
    // We use str_replace with an array of search values for efficiency
    // The order of replacement is important as \r\n should be treated as a single entity
    // rather than as separate \r and \n characters
    return str_replace(
        [
            "\r\n", // Windows line endings (carriage return + line feed)
            "\r",   // Mac OS classic line endings (carriage return only)
            "\n"    // Unix/Linux line endings (line feed only)
        ],
        '', // Replace with empty string to remove completely
        $string
    );

    // Note: An alternative approach would be to use:
    // return preg_replace('/\R/', '', $string);
    // which handles all Unicode line endings, but is slightly less efficient
}

/**
 * Removes incomplete or empty HTML lists from a string.
 *
 * This function addresses various issues with HTML lists that would cause problems
 * when converting to other formats (like LaTeX):
 * - Removes completely empty lists (<ul></ul> or <ol></ol>)
 * - Removes lists that have no <li> elements
 * - Removes lists where all <li> elements are empty
 * - Cleans lists by removing empty <li> elements while preserving non-empty ones
 *
 * @param string $string The HTML content to process
 * @return string The processed HTML with incomplete lists removed
 */
function removeIncompleteList($string) {
    // First pass: remove completely empty lists (no content between tags)
    $string = preg_replace('/<ol[^>]*>\s*<\/ol>/i', '', $string);
    $string = preg_replace('/<ul[^>]*>\s*<\/ul>/i', '', $string);

    // Second pass: handle lists that might have whitespace or comments but no items
    $string = preg_replace_callback('/<(ol|ul)[^>]*>(.*?)<\/\1>/is', function($matches) {
        $listType = $matches[1]; // ol or ul
        $content = $matches[2];  // everything between the tags

        // Check if there are any <li> tags
        if (preg_match('/<li[^>]*>/i', $content)) {
            // Has list items, keep it
            return $matches[0];
        } else {
            // No list items, remove it
            return '';
        }
    }, $string);

    // Third pass: handle incomplete or empty list items
    $string = preg_replace_callback('/<(ol|ul)[^>]*>(.*?)<\/\1>/is', function($matches) {
        $listType = $matches[1]; // ol or ul
        $content = $matches[2];  // everything between the tags

        // Check if all list items are empty (e.g., <li></li>)
        $cleanedContent = preg_replace('/<li[^>]*>\s*<\/li>/i', '', $content);

        // Remove whitespace for comparison
        $trimmedCleanedContent = trim(preg_replace('/\s+/', '', $cleanedContent));

        // If after removing empty list items and whitespace there's nothing left, remove the whole list
        if (empty($trimmedCleanedContent) || !preg_match('/<li[^>]*>/i', $cleanedContent)) {
            return '';
        } else {
            // Otherwise, return the list with any empty items removed
            $processedContent = preg_replace('/<li[^>]*>\s*<\/li>/i', '', $content);
            return "<$listType>" . $processedContent . "</$listType>";
        }
    }, $string);

    // Final cleanup - if we've created any new empty lists, remove them
    $string = preg_replace('/<ol[^>]*>\s*<\/ol>/i', '', $string);
    $string = preg_replace('/<ul[^>]*>\s*<\/ul>/i', '', $string);

    return $string;
}


