<?php
/**
 * Listing The Courses for Collecting Course Materials
 * Desc: Listing the courses to get course materials collected
 *
 * 02/04/2025 - initial version created
 *
 */

include('header.php');

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');

$AcademicYearSelection = AcademicYearSelection();

?>

<script src="js/datatable-utils-holdsearch.min.js"></script>
<script src="js/api_pdfviewer.min.js?v=0.0.1"></script>
<script>
    let DataTable_UCourses = null;

    function UpdateCourseMaterials(_AY, _SEMTXT, _SUB, _NUM, _TITLE, _CREDITS,
                                   _ASST, _INSTRUCTOR, _ENROLLMENT, _AVCIDX,
                                   _SEM, _CRN, _CRSSYLLBUS)
    {
        if (_CRSSYLLBUS==='' || _CRSSYLLBUS===null)
        {
            Swal.fire({title:"ERROR", text: "Please Upload  Course Syllabus First!", icon:"error"});
            return;
        }

        let element;
        let form = document.createElement("form");

        form.method = "POST";
        form.action = "asst_crsmaterials_collect.php";

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_AVCIDX;
        element.name="_avcidx";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_SEMTXT;
        element.name="_semtxt";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_AY;
        element.name="_ay";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_SUB;
        element.name="_sub";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_NUM;
        element.name="_num";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_TITLE;
        element.name="_title";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_CREDITS;
        element.name="_credits";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_ASST;
        element.name="_asst";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_INSTRUCTOR;
        element.name="_instructor";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_ENROLLMENT;
        element.name="_enrollment";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_SEM;
        element.name="_sem";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_CRN;
        element.name="_crn";
        form.appendChild(element);

        document.body.appendChild(form);
        form.submit();
    }

    function UploadCourseSyllabus(_DIALOG_TITLE, _AVCIDX, _AYINFO, _SEMESTER, _SUBJECT, _NUM, _TITLE, _CRN)
    {
        const content = `
            <form enctype="multipart/form-data" name="popupfrm" id="popupfrm">
            <input type="hidden" name="_AYINFO" size="30" value="${_AYINFO}">
            <input type="hidden" name="_AVCIDX" size="30" value="${_AVCIDX}">
            <input type="hidden" name="_CINFO" size="30" value="${_SEMESTER}_${_SUBJECT}_${_NUM}_crn${_CRN}">
            <table style="border-spacing:0; padding:0; width:100%;">
            <tr><td colspan="2"><div class="input-group" style="width:100%">
             <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">COURSE INFO: ${_SEMESTER} ${_SUBJECT} ${_NUM} ${_TITLE}</span>
             </div>
             <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Syllabus<span style="color:red">* (PDF only, MAX: 2MB)</span></span>
             <input type="file" name="_FILE" id="_FILE" class="input-sm form-control" value="" placeholder="Select Syllabus File" accept=".pdf" onchange="FileSizeValidation('_FILE')" required>
             </div>
            </div></td></tr>
            </table></form>
            `;

        createModalDialog({
            title: `<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">${_DIALOG_TITLE} COURSE SYLLABUS</span>`,
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;UPLOAD",
                    className: 'btn-success',
                    callback: function(){
                        if (popupfrm._FILE.files.length === 0)
                        {
                            popupfrm._FILE.focus();
                            Swal.fire({title:"ERROR", text: "File is not selected!!", icon:"error"});
                            return false;
                        }
                        if (FileSizeValidation('_FILE') === false)
                            return false;

                        UploadCourseSyllabus_Perform();
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_FILE").focus();
        });
    }

    function UploadCourseSyllabus_Perform()
    {
        // Show the full page spinner
        showFullPageSpinner();

        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                // Hide spinner and show notification
                hideFullPageSpinner();

                switch(xmlhttp.responseText.trim())
                {
                    case"0x11111111": {
                        DataTable_UCourses.ajax.reload(null, false);

                        Swal.fire({
                            title: "UPLOADED",
                            text: "Course syllabus has been uploaded!",
                            icon: "success",
                            timer: 2000
                        });
                        break;
                    }
                    case "0x00251400": {
                        Swal.fire({title:"ERROR", text: "The file uploaded exceeds the limits (2MB)!", icon:"error"});
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }

        const formData = new FormData(document.forms.namedItem("popupfrm"));
        xmlhttp.open("POST", "u_courses_uploadsyllabus_ajax.php", true);
        xmlhttp.send(formData);
        // reference site: https://developer.mozilla.org/en-US/docs/Web/API/FormData/Using_FormData_Objects
    }
</script>

<script class="init">
    const szURL = 'ssps/asst_crsmaterials_ssps.php?_AY=';
    $(document).ready(function() {

        DataTable_UCourses = $("#coursematerials").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            processing: true,
            serverSide: false,
            lengthMenu: [ 30, 50, 100, 150, 200 ],
            ajax: `${szURL}<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>`,
            fnInitComplete: function(oSettings, json) {
                // Add "Clear Filter" button to Filter
                let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                    $('#' + oSettings.sTableId).dataTable().fnFilter('');
                });
            },
            oLanguage: {sInfoFiltered: ''},
            order: [[ 0, 'dsc' ], [ 1, 'asc' ]],
            columns: [
                { data: 'AcademicYearCustomInfo'},
                { data: 'CourseCustomInfo'},
                { data: 'Instructor' },
<?php if( $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true ) { ?>
                { data: 'Assistant' },
<?php } ?>
                {
                    data: 'CrsMaterialsCount',
                    render: (data, type, row) => {
                        const count = data || 0;
                        const badgeClass = count > 0 ? 'badge-success' : 'badge-secondary';
                        return `<span class="badge ${badgeClass}">${count}</span>`;
                    }
                },
                {
                    data: 'TotalStudentSamples',
                    render: function(data, type, row) {
                        const total = parseInt(data);
                        const expected = parseInt(row.ExpectedStudentSamples);
                        const percentage = expected > 0 ? Math.round((total / expected) * 100) : 0;

                        let className = 'badge-danger';
                        if (percentage === 100) className = 'badge-success';
                        else if (percentage >= 50) className = 'badge-warning';

                        return `<span class="badge ${className}">${total}/${expected} (${percentage}%)</span>`;
                    }
                },
                {
                    data: 'InstMaterialsCount',
                    render: (data, type, row) => {
                        const count = data || 0;
                        const badgeClass = count > 0 ? 'badge-success' : 'badge-secondary';
                        return `<span class="badge ${badgeClass}">${count}</span>`;
                    }
                },
                {
                    data: 'CourseSyllabus',
                    render: (data, type, row) => {
                        let html = '';
                        if (data !== '' && data !== null) {
                            html = `<button class="btn btn-primary btn-xs" id="coursesyllabus"
                                data-coursesyllabus="${row.CourseSyllabus}"
                                data-academicyearinfo="${row.AcademicYearInfo}"
                                title="Download COURSE Syllabus">
                                <i class="glyphicon glyphicon-floppy-save"></i> COURSE SYLLABUS PDF
                                </button>
                                <button id="replace"
                                class="btn btn-warning btn-xs glyphicon glyphicon-refresh"
                                style="min-height: 20px;"
                                title="Replace Course Syllabus">
                                </button>`;
                        } else {
                            html = `<button id="upload" class="btn btn-danger btn-xs glyphicon glyphicon-upload" style="min-height: 20px;" title="Upload Syllabus"></button>&nbsp;`;
                        }
                        return html;
                    }
                },
                {
                    data: '', // Operations column
                    render: (data, type, row) => {
                        let html = '<div style="width:100%;text-align:center;">';
                        html += `<button id="update" class="btn btn-danger btn-xs" style="min-height: 20px;" title="Perform Course Materials Collection">
                                 <span class="glyphicon glyphicon-pencil"></span> Materials
                                 </button>&nbsp;`;
                        html += '</div>';

                        return html;
                    }
                }
            ],
            columnDefs: [
                {
                    targets: [0,2,3,4,5],
                    className: 'dt-center'
                },
                {
                    targets  : 'no-sort',
                    orderable: false,
                },
                {
                    'searchable'    : false,
                    'targets'       : [4, 5]
                },
                {
                    targets: -1,
                    orderable: false
                }
            ],
            buttons: [
                {
                    extend: 'excelHtml5',
                    title: 'Course Materials COLLECTION',
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                    },
                    exportOptions: {
                        columns: [ 0, 1, 2, 3, 4, 5, 6]
                    }
                }
            ]
        });

        // Initialize the column search functionality
        new DataTableHoldSearch('#coursematerials', DataTable_UCourses, true, true);

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_UCourses.ajax.url(tmpURL).load();
        });

        $('#coursematerials tbody').on( 'click', '#coursesyllabus', function () {
            const coursesyllabus = this.getAttribute('data-coursesyllabus');
            const academicyearinfo = this.getAttribute('data-academicyearinfo');
            downloadPDF(coursesyllabus, 253438384, academicyearinfo);
            return false; // disable row selection action
        } );

        $('#coursematerials tbody').on( 'click', '#update', function () {
            const data = DataTable_UCourses.row( $(this).parents('tr') ).data();
            UpdateCourseMaterials(data.AcademicYearInfo, data.SemesterTxt, data.Subject, data.Num,
                data.Title, data.Credits, data.Assistant, data.Instructor, data.Enrollment,
                data.AVCourseIdx, data.Semester, data.CRN, data.CourseSyllabus
            );
        } );

        // Handle both upload and replace buttons
        $('#coursematerials tbody').on('click', '#upload, #replace', function () {
            const data = DataTable_UCourses.row($(this).parents('tr')).data();
            const dialog_title = $(this).attr('id') === 'upload' ? 'UPLOAD' : 'REPLACE';
            UploadCourseSyllabus(dialog_title, data.AVCourseIdx, data.AcademicYearInfo, data.SemesterTxt, data.Subject, data.Num, data.Title, data.CRN);
        });
    } );

    //function UpdateDataTablebyASST(option){
    //    const url = "ssps/asst_crsmaterials_ssps.php?_AY=<?php //echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>//&_ASST="+encodeURIComponent(option.value);
    //    DataTable_UCourses.ajax.url( url ).load();
    //}
</script>

<style>
    .badge {
        display: inline-block;
        padding: 4px 8px;
        font-size: 11px;
        font-weight: bold;
        line-height: 1;
        color: #fff;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: 10px;
    }
    .badge-success {
        background-color: #5cb85c;
    }
    .badge-secondary {
        background-color: #6c757d;
    }
</style>

<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;">
<?php
if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true) {
        // program director
?>
        <span class="largeheadline">COURSE MATERIALS COLLECTION <span class="largeheadline" style="color: red;">(PROGRAM DIRECTORS VIEW)</span></span>
<?php
    } else {
        ?>
        <span class="largeheadline">COURSE MATERIALS COLLECTION FOR (<span style="text-transform: uppercase"><?php echo($_SESSION['ATLAS_LOGIN_USERNAME']);?>)</span></span>
        <?php
    }
?>
        </p>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <?php
        if( $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true ) {
        ?>
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:80%; min-width:350px;">
                    <?php include('control_granted_alldepartments.php'); ?>
                    <script>
                        $(document).ready(function() {
                            // Add the change event handler using jQuery
                            $("#departmentSelect").on("change", function() {
                                const _AY = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].value;
                                url = szURL + _AY+"&_DEPT="+this.value;
                                DataTable_UCourses.ajax.url( url.toString() ).load();
                            });
                        });
                    </script>
                </td>
                <td style="width:20%; text-align: right">
                </td>
            </tr>
        </table>
        <?php  } ?>

        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:30%;">
                    <?php echo($AcademicYearSelection);?>
                </td>
                <td style="width:40%;">
                </td>
                <td style="width:30%; text-align: right">
                </td>
            </tr>
        </table>

        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="coursematerials" class="display break-word" style="border-spacing:0; padding:0;width:100%;">
                <thead>
                <tr>
                    <th>SEMESTER</th>
                    <th>COURSE INFO</th>
                    <th>INSTRUCTOR</th>
<?php if( $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true ) { ?>
                    <th>ASSISTANT (IF EXISTS)</th>
<?php } ?>
                    <th>CRS MATERIALS</th>
                    <th>TOTAL STUDENT SAMPLES</th>
                    <th>INST MATERIALS</th>
                    <th>COURSE SYLLABUS</th>
                    <th class="no-sort" style="width:100px">OPERATION</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th>SEMESTER</th>
                    <th>COURSE INFO</th>
                    <th>INSTRUCTOR</th>
<?php if( $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true ) { ?>
                    <th>ASSISTANT (IF EXISTS)</th>
<?php } ?>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
                </tfoot>
            </table>
        </div>


        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td><span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-upload" style="pointer-events: none;"></span>: Upload Course Syllabus
                    <span class="btn btn-warning btn-xs glyphicon glyphicon-refresh" style="pointer-events: none;"></span>: Replace Course Syllabus
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-pencil" style="pointer-events: none;"></span>: Update Course Materials
                </td>
            </tr>
        </table>

    </div>
</div>


<?php include('footer.php');?>

