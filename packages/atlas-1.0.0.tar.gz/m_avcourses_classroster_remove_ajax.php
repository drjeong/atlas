<?php
/**
 * Remove All Students AJAX Handler
 * Handles removing all students from a class roster
 *
 * Action:
 * - removeAllStudentsFromRoster: Removes all students from the specified course roster
 *
 * Parameters:
 * - action: Must be 'removeAllStudentsFromRoster'
 * - avcIdx: Available Course Index
 *
 * Response Format:
 * {
 *     "success": true/false,
 *     "message": "Description of result",
 *     "code": "0xXXXXXXXX"
 * }
 *
 * Response Codes:
 * - 0x11111111: Success
 * - 0x00000000: Illegal entry or unexpected error
 * - 0x00000101: Missing required information
 * - 0x00000102: Invalid action
 * - 0x00000103: Invalid course index
 * - 0x00000500: Database error
 *
 * 12/19/2025 - initial version created
 */

include_once 'session_handler.php';

$avcIdx = '';
// Validate request parameters
if (array_key_exists('avcIdx', $_POST)) {
    $avcIdx = trim($_POST['avcIdx']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

if ($avcIdx==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate course index
    $avcIdx = filter_var($avcIdx, FILTER_VALIDATE_INT);
    if ($avcIdx === false || $avcIdx <= 0) {
        throw new Exception('Invalid Available Course Index format');
    }

    // Call stored procedure to remove all students from roster
    $result = $DBCONNECTION->callStoredProcedure('SP_RemoveAllStudentsFromRoster', [$avcIdx]);

    // Success response
    echo ("0x11111111");

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    echo "0x00000500";  // other DB error

    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'query' => '0x00000500'
    ]));

} catch (Exception $e) {
    // General error
    error_log($e->getMessage());
    echo "0x00000000";
}
?>