<?php
/**
 * Check Abet Syllabus
 * Description: checking if master syllabus exists in the server.
 * Author: Dong Hyun Jeong
 *
 * 01/27/2025 - initial version created
 *
 */

include_once 'session_handler.php';

$AbetCourseIdx='';
$AcademicYearIdx='';       // index
$AcademicProgramIdx='';
$Subject='';
$Num='';

if (array_key_exists('ay', $_POST) && array_key_exists('sub', $_POST)
    && array_key_exists('num', $_POST) && array_key_exists('ap', $_POST) )
{
    $AbetCourseIdx = trim($_POST['idx']);
    $AcademicYearIdx = trim($_POST['ay']);
    $AcademicProgramIdx = trim($_POST['ap']);
    $Subject = trim($_POST['sub']);
    $Num = trim($_POST['num']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

//$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AbetCourseIdx==='' || $AcademicYearIdx==='' || $AcademicProgramIdx==='' || $Subject==='' || $Num===''){
    // no required information
    echo "0x00000101";
    exit;
}

try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AbetCourseIdx = filter_var($AbetCourseIdx, FILTER_VALIDATE_INT);
    if ($AbetCourseIdx === false) {
        throw new Exception('Invalid Index format');
    }
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Index format');
    }

    $query = "CALL SP_ChkAbetSyllabusExist(?, ?, ?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$AbetCourseIdx, $AcademicYearIdx, $AcademicProgramIdx, $Subject, $Num]);
    error_log($DBCONNECTION->formatQuery($query, [$AbetCourseIdx, $AcademicYearIdx, $AcademicProgramIdx, $Subject, $Num]));
//
    if ($result && $DBCONNECTION->num_rows() > 0) {
        $row = $DBCONNECTION->fetch_assoc();
        $data = $row["AbetSyllabus"];

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
    } else {

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'data' => ''
        ]);
    }
//    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    echo "0x00000500";  // other DB error
    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500'
    ]));

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
