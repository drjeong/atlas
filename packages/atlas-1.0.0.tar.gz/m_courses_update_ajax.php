<?php
/**
 * Management of Academic Degree Programs
 * Description: updating course information
 * Author: Dong Hyun Jeong
 *
 * 10/20/2024 - initial version created
 *
 */

include('checker_systemadmin.php');

$IDX = (isset($_POST['id'])) ? trim($_POST['id']) : '';
$Subject = (isset($_POST['subject'])) ? trim($_POST['subject']) : '';
$Num = (isset($_POST['num'])) ? trim($_POST['num']) : '';
$Title = (isset($_POST['title'])) ? trim($_POST['title']) : '';
$TitleUniv = (isset($_POST['titleuniv'])) ? trim($_POST['titleuniv']) : '';
$Credits = (isset($_POST['credits'])) ? trim($_POST['credits']) : '';

if ($IDX=="" || $Subject=="" || $Num=="" || $Title=="" || $TitleUniv=="" || $Credits==""){
	echo "0x00000011";
	exit;
}


//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $IDX = filter_var($IDX, FILTER_VALIDATE_INT);
    if ($IDX === false) {
        throw new Exception('Invalid Index format');
    }

    // convert unwanted escape strings
    $Subject = $DBCONNECTION->real_escape_string($Subject);
    $Title = $DBCONNECTION->real_escape_string($Title);

    /////////////////////////////////////////////////////////////////////////////////
    // insert PI
    $query = "CALL SP_UpdateCourse(?, ?, ?, ?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$IDX, $Subject, $Num, $Title, $TitleUniv, $Credits]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00200011') !== false) {
        echo '0x00200011';  // same item exists already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
