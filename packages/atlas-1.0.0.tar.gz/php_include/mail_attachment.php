<?php
/**
 * ============================================================================
 * EMAIL UTILITY MODULE
 * ============================================================================
 *
 * Description:
 *   Provides email sending functionality for the ABET Assessment System.
 *   Supports two email delivery methods:
 *   - Sendmail: Uses server's sendmail program (requires sendmail installed)
 *   - Gmail SMTP: Uses Gmail's SMTP server (requires PHPMailer library)
 *
 * Requirements:
 *   - For Sendmail method:
 *     * Sendmail must be installed: sudo apt-get install sendmail
 *     * Apache must be restarted: sudo service apache2 restart
 *     * Linux account specified in __SERVER_SENDMAIL must exist
 *
 *   - For Gmail method:
 *     * PHPMailer library (version 6.9.1 or higher)
 *     * Gmail account with App Password configured
 *     * Security settings configured at: https://myaccount.google.com/security
 *     * 2-Step Verification must be enabled to generate App Password
 *
 * Configuration:
 *   Set __EMAIL_METHOD__ in config.php to either 'sendmail' or 'gmail'
 *
 * References:
 *   - PHPMailer Documentation: https://mailtrap.io/blog/phpmailer/
 *   - Gmail SMTP Setup: https://aruljohn.com/blog/php-send-email/
 *   - Gmail App Password: https://myaccount.google.com/security
 *
 * Version History:
 *   02/21/2022 - Initial version created
 *   03/14/2024 - Added Gmail SMTP sending functionality
 *
 * ============================================================================
 */

// Load application configuration
require_once(__DIR__ . '/../../config.php');

// ============================================================================
// PHPMAILER LIBRARY IMPORTS
// ============================================================================
// PHPMailer is required for both sendmail and Gmail SMTP methods

/* Exception class for error handling */
require_once __DIRECTORY_WEBHOME__ . '/toolbox/PHPMailer-6.9.1/src/Exception.php';

/* Main PHPMailer class - core email functionality */
require_once __DIRECTORY_WEBHOME__ . '/toolbox/PHPMailer-6.9.1/src/PHPMailer.php';

/* SMTP class - required for Gmail SMTP authentication and transmission */
require_once __DIRECTORY_WEBHOME__ . '/toolbox/PHPMailer-6.9.1/src/SMTP.php';

// Import PHPMailer classes into the global namespace
// Note: These must be at the top of the script, not inside functions
use PHPMailer\PHPMailer\PHPMailer;
// Uncomment below if needed for explicit exception/SMTP handling:
// use PHPMailer\PHPMailer\Exception;
// use PHPMailer\PHPMailer\SMTP;


// ============================================================================
// ADMINISTRATIVE NOTIFICATION FUNCTIONS
// ============================================================================

/**
 * Send email notification to system administrator
 *
 * This function is used to notify the system administrator about important
 * events, errors, or system status updates. The email method (sendmail or Gmail)
 * is determined by the __EMAIL_METHOD__ configuration constant.
 *
 * @param string $subject    Email subject line
 * @param string $message    Email body content (HTML formatted)
 * @param string $attachment Optional file path to attach (default: none)
 *
 * @return bool True if email sent successfully, false otherwise
 *
 * @example
 * NotifyAdminByEmail(
 *     "System Error Alert",
 *     "<p>Database connection failed at " . date('Y-m-d H:i:s') . "</p>",
 *     "/var/log/error.log"
 * );
 */
function NotifyAdminByEmail($subject, $message, $attachment='')
{
    require_once(__DIR__ . '/../../config.php');

    // Choose email delivery method based on configuration
    if (__EMAIL_METHOD__ == 'gmail') {
        // Use Gmail SMTP for delivery
        SendGMailMessage(
            __ADMIN_EMAILADDRESS,  // To: admin email
            '',                     // CC: none
            '',                     // BCC: none
            $subject,
            $message,
            $attachment
        );
    } else {
        // Use sendmail for delivery
        sendmail_attachment(
            __SERVER_SENDMAIL,      // From: server sendmail account
            'Web-Master',           // From name
            __ADMIN_EMAILADDRESS,   // To: admin email
            '',                     // CC: none
            __ADMIN_EMAILADDRESS,   // Reply-to: admin email
            $subject,
            $message,
            '',                     // No attachment
            ''                      // No message tail
        );
    }
}

/**
 * Send email notification to a user
 *
 * This function sends notifications to system users (instructors, faculty, etc.).
 * It automatically includes a notice that the email is for notification purposes only
 * and should not be replied to. The email method is determined by __EMAIL_METHOD__.
 *
 * @param string $to_email  Recipient's email address
 * @param string $subject   Email subject line
 * @param string $message   Email body content (HTML formatted)
 *
 * @return bool True if email sent successfully, false otherwise
 *
 * @example
 * NotifyUserByEmail(
 *     "instructor@university.edu",
 *     "Assessment Deadline Reminder",
 *     "<p>Your course assessment is due in 3 days.</p>"
 * );
 */
function NotifyUserByEmail($to_email, $subject, $message)
{
    require_once(__DIR__ . '/../../config.php');

    // Choose email delivery method based on configuration
    if (__EMAIL_METHOD__ == 'gmail') {
        // Use Gmail SMTP - includes automatic "do not reply" notice
        SendGMailMessage(
            $to_email,              // To: user email
            '',                     // CC: none
            __ADMIN_EMAILADDRESS,   // BCC: admin (for record keeping)
            $subject,
            $message
        );
    } else {
        // Use sendmail - includes "do not reply" notice in message tail
        sendmail_attachment(
            __ADMIN_EMAILADDRESS,   // From: admin email
            'Web-Master',           // From name
            $to_email,              // To: user email
            '',                     // CC: none
            __ADMIN_EMAILADDRESS,   // Reply-to: admin email
            $subject,
            $message,
            '',                     // No attachment
            ''                      // No message tail
        );
    }
}

/**
 * Send a custom email message with specified sender information
 *
 * This function provides more control over email parameters, allowing you to
 * specify from address, from name, and CC recipients. Always uses Gmail SMTP.
 * Automatically appends a "do not reply" notice to the message.
 *
 * @param string $from_email  Sender's email address
 * @param string $from_name   Sender's display name
 * @param string $to_email    Recipient's email address
 * @param string $cc_email    CC recipients (semicolon-separated for multiple)
 * @param string $subject     Email subject line
 * @param string $message     Email body content (HTML formatted)
 *
 * @return bool True if email sent successfully, false otherwise
 *
 * @example
 * SendEmailMessage(
 *     "noreply@university.edu",
 *     "Assessment System",
 *     "instructor@university.edu",
 *     "dean@university.edu;chair@university.edu",
 *     "New Assessment Available",
 *     "<p>A new assessment form is ready for your review.</p>"
 * );
 */
function SendEmailMessage($from_email, $from_name, $to_email, $cc_email, $subject, $message)
{
    // Append standard "do not reply" notice to all outgoing messages
    $msgtail = "<br/><br/><br/>-----------------------------------------<br/>"
        . "PLEASE NOTE: This email is for notification purposes only. "
        . "Please do not reply to this email for any purpose.";

    // Use Gmail SMTP attachment function (even though no attachment is sent)
    GMail_attachment(
        $from_email,    // From email address
        $to_email,      // To email address
        $from_email,    // Reply-to email address (same as from)
        $cc_email,      // CC email address(es)
        '',             // BCC: none
        $subject,
        $message,
        '',             // No attachment
        $msgtail        // Add do-not-reply notice
    );
}


// ============================================================================
// CONTENT FORMATTING UTILITIES
// ============================================================================

/**
 * Format textarea content for proper display in HTML emails
 *
 * This function converts textarea elements in HTML content to properly formatted
 * div elements that preserve line breaks and styling when sent via email.
 * Standard textarea tags may not render correctly in email clients, so this
 * function replaces them with divs that mimic textarea appearance.
 *
 * Conversion process:
 * 1. Finds all <textarea> elements using regex
 * 2. Extracts the content from each textarea
 * 3. Converts line breaks to <br> tags
 * 4. Escapes HTML special characters
 * 5. Wraps content in a styled div that looks like a textarea
 *
 * @param string $content HTML content containing textarea elements
 *
 * @return string Modified HTML with textareas converted to formatted divs
 *
 * @example
 * $emailBody = "<textarea>Line 1\nLine 2\nLine 3</textarea>";
 * $formattedBody = formatTextareaForEmail($emailBody);
 * // Result: Content wrapped in a div with preserved line breaks
 */
function formatTextareaForEmail($content) {
    // Use regex to find all textarea elements and their content
    // The 's' modifier allows . to match newlines
    if (preg_match_all('/<textarea[^>]*>(.*?)<\/textarea>/s', $content, $matches)) {

        // Process each textarea found in the content
        foreach ($matches[0] as $index => $fullMatch) {
            // Extract the inner content of the textarea
            $textareaContent = $matches[1][$index];

            // Convert line breaks to HTML <br> tags
            // htmlspecialchars() escapes special HTML characters to prevent injection
            $formattedContent = nl2br(htmlspecialchars($textareaContent));

            // Create a div styled to look like a textarea
            // Styles match typical textarea appearance:
            // - Gray border and light background
            // - Monospace font for code/data
            // - pre-wrap to preserve whitespace and line breaks
            $replacement = '<div style="width: 98%; min-height: 150px; padding: 12px; '
                . 'border: 1px solid rgb(153, 153, 153); '
                . 'background-color: rgb(245, 245, 245); font-family: monospace; '
                . 'font-size: inherit; color: rgb(51, 51, 51); white-space: pre-wrap; '
                . 'border-radius: 0px 0px 4px 4px;">'
                . $formattedContent
                . '</div>';

            // Replace the original textarea with the formatted div
            $content = str_replace($fullMatch, $replacement, $content);
        }
    }

    return $content;
}


// ============================================================================
// GMAIL SMTP EMAIL FUNCTIONS
// ============================================================================

/**
 * Send email via Gmail SMTP with optional attachment
 *
 * This is a wrapper function that simplifies sending emails through Gmail's
 * SMTP server. It handles the common case of sending notification emails
 * with a standard "do not reply" notice.
 *
 * Gmail SMTP Requirements:
 * - Gmail account with 2-Step Verification enabled
 * - App Password generated (not regular Gmail password)
 * - Credentials stored in __SMTP_GMAILACCOUNT__ and __SMTP_GMAILAPPPWD__
 *
 * How to generate Gmail App Password:
 * 1. Go to https://myaccount.google.com/security
 * 2. Enable 2-Step Verification if not already enabled
 * 3. Navigate to "App passwords" section
 * 4. Generate a new app password for "Mail"
 * 5. Use this 16-character password in configuration
 *
 * @param string       $to_email      Recipient email address
 * @param string|array $cc_email      CC recipients (string with semicolons or array)
 * @param string|array $bcc_email     BCC recipients (string with semicolons or array)
 * @param string       $subject       Email subject line
 * @param string       $message       Email body (HTML formatted)
 * @param mixed        $attachment    Optional: single file path or array of paths
 * @param string|null  $replyto_email Optional: reply-to address (defaults to admin)
 *
 * @return bool True if email sent successfully, false otherwise
 *
 * @example
 * // Simple notification email
 * SendGMailMessage(
 *     "user@example.com",
 *     "",
 *     "",
 *     "Password Reset",
 *     "<p>Your password has been reset.</p>"
 * );
 *
 * // Email with CC and attachment
 * SendGMailMessage(
 *     "instructor@university.edu",
 *     "dean@university.edu",
 *     "admin@university.edu",
 *     "Assessment Report",
 *     "<p>Please review the attached report.</p>",
 *     "/path/to/report.pdf"
 * );
 */
function SendGMailMessage($to_email, $cc_email, $bcc_email, $subject, $message, $attachment='', $replyto_email=null)
{
    // Default message tail - added to all emails unless replyto_email is specified
    $msgtail = '';

    // If no reply-to address provided, use admin email and add "do not reply" notice
    // This maintains backward compatibility with older function calls
    if ($replyto_email === null) {
        $msgtail = "<br/><br/><br/>-----------------------------------------<br/>"
            . "PLEASE NOTE: This email is for notification purposes only. "
            . "Please do not reply to this email for any purpose.";
        $replyto_email = __ADMIN_EMAILADDRESS;
    }

    // Call the main Gmail sending function with all parameters
    return GMail_attachment(
        __SMTP_GMAILACCOUNT__,  // From: Gmail account configured in settings
        $to_email,              // To: recipient address
        $replyto_email,         // Reply-to: specified or default admin email
        $cc_email,              // CC: carbon copy recipients
        $bcc_email,             // BCC: blind carbon copy recipients
        $subject,               // Email subject
        $message,               // Email body
        $attachment,            // File attachment(s)
        $msgtail                // Footer message
    );
}

/**
 * Send email via Gmail SMTP with support for attachments and multiple recipients
 *
 * This is the core Gmail sending function that handles all SMTP communication
 * with Gmail's servers. It supports:
 * - Multiple TO, CC, and BCC recipients (semicolon-separated)
 * - Single or multiple file attachments
 * - HTML email formatting
 * - Custom reply-to addresses
 * - Comprehensive error logging
 *
 * SMTP Connection Details:
 * - Server: smtp.gmail.com
 * - Port: 587
 * - Encryption: TLS (STARTTLS)
 * - Authentication: Required (username/password)
 *
 * @param string       $from       Sender email address (displayed in "From" field)
 * @param string       $to         Recipient(s) - semicolon-separated for multiple
 * @param string       $replyto    Reply-to email address
 * @param string       $cc         CC recipient(s) - semicolon-separated for multiple
 * @param string       $bcc        BCC recipient(s) - semicolon-separated for multiple
 * @param string       $subject    Email subject line
 * @param string       $message    Email body content (HTML)
 * @param string|array $attachment File path(s) - string for single, array for multiple
 * @param string       $msgtail    Optional text to append to message (e.g., disclaimers)
 *
 * @return bool True if email sent successfully, false on failure
 *
 * Error Handling:
 * - All failures are logged to PHP error log with full details
 * - Returns false on any error (connection, authentication, sending)
 * - Check error_log for detailed PHPMailer error messages
 *
 * @example
 * // Send email with multiple recipients and attachments
 * GMail_attachment(
 *     "system@university.edu",
 *     "user1@example.com;user2@example.com",
 *     "noreply@university.edu",
 *     "supervisor@university.edu",
 *     "admin@university.edu",
 *     "Monthly Report",
 *     "<h1>Report</h1><p>Please review attached files.</p>",
 *     array("/path/to/report.pdf", "/path/to/data.xlsx"),
 *     "<p>This is an automated message.</p>"
 * );
 */
function GMail_attachment ($from, $to, $replyto, $cc, $bcc, $subject, $message, $attachment, $msgtail='')
{
    // Set timezone to UTC for consistent timestamp handling
    // PHPMailer requires accurate timestamps for SMTP communication
    date_default_timezone_set('Etc/UTC');

    // Initialize PHPMailer instance
    $mail = new PHPMailer;

    // ========================================================================
    // SMTP SERVER CONFIGURATION
    // ========================================================================

    $mail->isSMTP();                        // Use SMTP protocol
    $mail->SMTPDebug = 0;                   // Disable debug output (0=off, 1=client, 2=server)
    $mail->Debugoutput = 'html';            // Format debug output as HTML
    $mail->Host = 'smtp.gmail.com';         // Gmail SMTP server
    $mail->Port = 587;                      // Port for TLS/STARTTLS
    $mail->SMTPSecure = 'tls';              // Enable TLS encryption
    $mail->SMTPAuth = true;                 // Enable SMTP authentication
    $mail->Username = __SMTP_GMAILACCOUNT__; // Gmail account username
    $mail->Password = __SMTP_GMAILAPPPWD__;  // Gmail app password (not regular password)

    // ========================================================================
    // SENDER INFORMATION
    // ========================================================================

    // Set the "From" address and name
    $mail->SetFrom($from, $from);

    // Set the "Reply-To" address for responses
    $mail->AddReplyTo($replyto, $replyto);

    // ========================================================================
    // TO RECIPIENTS
    // ========================================================================

    // Process TO recipients - supports semicolon-separated email addresses
    if ($to != "")
    {
        // Split email addresses by semicolon
        $to_array = explode( ';', $to );

        // Add each valid email address to the recipient list
        foreach ($to_array as $toemail)
        {
            // Trim whitespace and only add non-empty addresses
            if (trim($toemail) != '')
                $mail->AddAddress($toemail);
        }
    }

    // ========================================================================
    // CC RECIPIENTS (Carbon Copy)
    // ========================================================================

    // Process CC recipients - visible to all recipients
    if ($cc != "")
    {
        // Split email addresses by semicolon
        $cc_array = explode( ';', $cc );

        // Add each valid email address to CC list
        foreach ($cc_array as $ccemail)
        {
            // Trim whitespace and only add non-empty addresses
            if (trim($ccemail) != '')
                $mail->AddCC($ccemail);
        }
    }

    // ========================================================================
    // BCC RECIPIENTS (Blind Carbon Copy)
    // ========================================================================

    // Process BCC recipients - hidden from other recipients
    if ($bcc != "")
    {
        // Split email addresses by semicolon
        $bcc_array = explode( ';', $bcc );

        // Add each valid email address to BCC list
        foreach ($bcc_array as $bccemail)
        {
            // Trim whitespace and only add non-empty addresses
            if (trim($bccemail) != '')
                $mail->AddBCC($bccemail);
        }
    }

    // ========================================================================
    // MESSAGE CONTENT
    // ========================================================================

    // Set email subject
    $mail->Subject = $subject;

    // Enable HTML email format
    $mail->IsHTML(true);

    // Append message tail if provided (e.g., disclaimers, signatures)
    if ($msgtail != '')
        $message .= $msgtail;

    // Set email body content
    $mail->Body = $message;

    // ========================================================================
    // FILE ATTACHMENTS
    // ========================================================================

    // Handle file attachments - supports both single file and array of files
    if ($attachment != '')
    {
        if (is_array($attachment)) {
            // Multiple attachments - iterate through array
            foreach ($attachment as $file) {
                // Only attach if file exists on server
                if (file_exists($file)) {
                    $mail->addAttachment($file);
                }
            }
        } else {
            // Single attachment - attach directly
            $mail->addAttachment($attachment);
        }
    }

    // ========================================================================
    // SEND EMAIL
    // ========================================================================

    // Attempt to send the email
    if (!$mail->send()) {
        // Log detailed error information for debugging
        // Includes all parameters to help diagnose issues
        error_log("Mailer Error: " . $mail->ErrorInfo
            . "[$from, $to, $bcc, $subject, $message, "
            . print_r($attachment, true) . ", $msgtail]");
        return false;
    }

    // Email sent successfully
    return true;
}


// ============================================================================
// SENDMAIL EMAIL FUNCTIONS
// ============================================================================

/**
 * Send email using server's sendmail program
 *
 * This function uses the server's sendmail mail transfer agent (MTA) to send
 * emails. It's an alternative to SMTP that relies on the server's mail
 * infrastructure rather than an external SMTP server.
 *
 * REQUIREMENTS:
 * - Sendmail must be installed on the server
 *   Installation: sudo apt-get install sendmail
 * - Apache/web server must be restarted after installation
 *   Restart: sudo service apache2 restart
 * - The Linux user account specified in __SERVER_SENDMAIL must exist
 * - Server must be configured to allow outgoing mail
 *
 * Features:
 * - Supports HTML formatted emails
 * - Handles multiple CC recipients
 * - Automatic CC to sender for record keeping
 * - File attachment support
 * - Custom reply-to addresses
 *
 * Limitations:
 * - May be blocked by some recipient email servers
 * - Less reliable than SMTP for external recipients
 * - Requires proper server mail configuration
 * - May end up in spam folders more often than SMTP
 *
 * @param string $from_email   Sender's email address
 * @param string $from_name    Sender's display name
 * @param string $to_email     Recipient's email address
 * @param string $cc_email     CC recipients (semicolon, comma, or space separated)
 * @param string $replyto_email Reply-to email address
 * @param string $subject      Email subject line
 * @param string $message      Email body content (HTML supported)
 * @param string $attachment   Optional file path for attachment
 * @param string $msgtail      Optional text to append to message
 *
 * @return bool True if email sent successfully, false otherwise
 *
 * Error Handling:
 * - Failures are logged to PHP error log with full parameter details
 * - Returns false on any error during sending
 *
 * @example
 * sendmail_attachment(
 *     "system@university.edu",
 *     "Assessment System",
 *     "instructor@university.edu",
 *     "dean@university.edu;chair@university.edu",
 *     "noreply@university.edu",
 *     "Course Assessment Due",
 *     "<p>Your assessment is due next week.</p>",
 *     "",
 *     "<p>Please do not reply to this automated message.</p>"
 * );
 */
function sendmail_attachment ($from_email, $from_name, $to_email, $cc_email, $replyto_email, $subject, $message, $attachment, $msgtail)
{
    // ========================================================================
    // TIMEZONE CONFIGURATION
    // ========================================================================

    // Set timezone to UTC for consistent timestamp handling
    // SMTP requires accurate times, should be set in php.ini but we set it here as fallback
    date_default_timezone_set('Etc/UTC');

    // ========================================================================
    // PHPMAILER INITIALIZATION
    // ========================================================================

    // Create a new PHPMailer instance
    $mail = new PHPMailer();

    // Configure PHPMailer to use sendmail transport instead of SMTP
    // This uses the server's sendmail program to deliver mail
    $mail->isSendmail();

    // ========================================================================
    // SENDER CONFIGURATION
    // ========================================================================

    // Set the "From" address using server sendmail account
    // Uses __SERVER_SENDMAIL constant (e.g., "web-master@university.edu")
    // This ensures emails come from a valid server account
    $mail->SetFrom(__SERVER_SENDMAIL, $from_name);

    // Alternative: Use the provided from_email instead of server account
    // Uncomment below line to use custom from address:
    // $mail->SetFrom($from_email, $from_email);

    // ========================================================================
    // REPLY-TO CONFIGURATION
    // ========================================================================

    // Set the reply-to address
    // When recipients reply, their response goes to this address
    $mail->AddReplyTo($replyto_email, $replyto_email);

    // ========================================================================
    // PRIMARY RECIPIENT
    // ========================================================================

    // Set the primary recipient (TO address)
    $mail->AddAddress($to_email, $to_email);

    // ========================================================================
    // EMAIL SUBJECT
    // ========================================================================

    // Set the email subject line
    $mail->Subject = $subject;

    // ========================================================================
    // EMAIL FORMAT
    // ========================================================================

    // Enable HTML email format
    // Allows rich formatting, links, images, etc.
    $mail->IsHTML(true);

    // ========================================================================
    // MESSAGE BODY
    // ========================================================================

    // Alternative approach: Load HTML from external file
    // Uncomment to use external HTML file:
    // $mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));

    // Append message tail if provided (disclaimers, signatures, etc.)
    if ($msgtail != '')
        $message .= $msgtail;

    // Set the email body content
    $mail->Body = $message;

    // Optional: Set plain text alternative body
    // Uncomment to provide fallback for non-HTML email clients:
    // $mail->AltBody = 'This is a plain-text message body';

    // ========================================================================
    // FILE ATTACHMENT
    // ========================================================================

    // Attach file if path provided
    if ($attachment!='')
        $mail->addAttachment($attachment);

    // ========================================================================
    // CARBON COPY (CC) RECIPIENTS
    // ========================================================================

    // Always CC the sender for record keeping
    $mail->AddCC($from_email);

    // Process additional CC recipients if provided
    if ($cc_email != '')
    {
        // Determine delimiter used in CC list and split accordingly
        // Supports three common delimiters:

        if (strpos($cc_email, ";") != FALSE)
            // Semicolon-separated: "email1@example.com;email2@example.com"
            $ccrecipients = explode(";",$cc_email);
        elseif (strpos($cc_email, ",") != FALSE)
            // Comma-separated: "email1@example.com,email2@example.com"
            $ccrecipients = explode(",",$cc_email);
        else
            // Space-separated: "email1@example.com email2@example.com"
            $ccrecipients = explode(" ",$cc_email);

        // Add each CC recipient to the email
        foreach($ccrecipients as $ccemail)
        {
            // Trim whitespace from email address
            $ccemail = trim($ccemail);

            // Only add non-empty email addresses
            if ($ccemail != '')
                $mail->AddCC($ccemail);
        }
    }

    // ========================================================================
    // SEND EMAIL
    // ========================================================================

    // Attempt to send the email
    if (!$mail->send()) {
        // Log detailed error information for debugging
        // Includes PHPMailer error info and all function parameters
        error_log("Mailer Error: " . $mail->ErrorInfo
            . "[$from_email, $to_email, $cc_email, $subject, $message, $attachment, $msgtail]");
        return false;
    }

    // Email sent successfully!
    return true;
}

