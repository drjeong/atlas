<?php
/**
 * Listing Courses
 * Description: listing performance indicators
 * Author: Dong Hyun Jeong
 *
 * 02/04/2025 - initial version created
 *
 */
include_once 'session_handler.php';

// Get parameters from session
$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// Handle academic years - convert from array to string if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
    // If it's an array, convert to comma-separated string
    if (is_array($academicYears)) {
        // Sanitize each value to prevent SQL injection
        $academicYears = array_map('intval', $academicYears);
        $IN_AcademicYears = implode(',', $academicYears);
    } else {
        $IN_AcademicYears = intval($academicYears);
    }
} else {
    // Fallback to single academic year
    $IN_AcademicYears = intval($IN_AcademicYear);
}

// If empty, use the current academic year
if (empty($IN_AcademicYears)) {
    $IN_AcademicYears = intval($IN_AcademicYear);
}

// Sanitize academic program to prevent SQL injection
$IN_AcademicProgram = intval($IN_AcademicProgram);

// Custom SQL query with UNION ALL
$customQuery = "
    SELECT
        AcademicYearIdx,
        AcademicYear,
        AVG,
        TOTAL,
        TOPFIFTY,
        TOPFIFTY_PERCENT,
        TOPTWENTYFIVE,
        TOPTWENTYFIVE_PERCENT,
        GPI,
        GPIIdx,
        GPIDescription
    FROM (
        SELECT
            `GPIS`.`AcademicYear` AS AcademicYearIdx,
            `AYS`.`AcademicYear` AS AcademicYear,
            AVG(`SCSHEET`.`LevelOfAttainment`) AS AVG,
            COUNT(`SCSHEET`.`LevelOfAttainment`) AS TOTAL,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE 0 END) AS TOPFIFTY,
            (SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE 0 END) / NULLIF(COUNT(`SCSHEET`.`LevelOfAttainment`), 0) * 100) AS TOPFIFTY_PERCENT,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE 0 END) AS TOPTWENTYFIVE,
            (SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE 0 END) / NULLIF(COUNT(`SCSHEET`.`LevelOfAttainment`), 0) * 100) AS TOPTWENTYFIVE_PERCENT,
            CONCAT_WS('-', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`) AS GPI,
            `GPIS`.`Idx` AS GPIIdx,
            `GPIS`.`Description` AS GPIDescription
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
            LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI`=`GPIS`.`Idx`)
            LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)
            LEFT JOIN `AcademicYears` AS `AYS` ON (`GPIS`.`AcademicYear` = `AYS`.`Idx`)
        WHERE `GPIS`.`AcademicProgram` = {$IN_AcademicProgram}
        AND `GPIS`.`AcademicYear` IN ({$IN_AcademicYears})
        AND `GPIS`.`TobeRemoved` = 0
        GROUP BY `GPIS`.`AcademicYear`, `AYS`.`AcademicYear`, `GPIS`.`Idx`, `GPIS`.`GPI`, `GPIS`.`Description`, `STNTOUTCMS`.`SO`

        UNION ALL

        SELECT
            'Overall' AS AcademicYearIdx,
            'Overall' AS AcademicYear,
            AVG(`SCSHEET`.`LevelOfAttainment`) AS AVG,
            COUNT(`SCSHEET`.`LevelOfAttainment`) AS TOTAL,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE 0 END) AS TOPFIFTY,
            (SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE 0 END) / NULLIF(COUNT(`SCSHEET`.`LevelOfAttainment`), 0) * 100) AS TOPFIFTY_PERCENT,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE 0 END) AS TOPTWENTYFIVE,
            (SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE 0 END) / NULLIF(COUNT(`SCSHEET`.`LevelOfAttainment`), 0) * 100) AS TOPTWENTYFIVE_PERCENT,
            CONCAT_WS('-', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`) AS GPI,
            MIN(`GPIS`.`Idx`) AS GPIIdx,
            MIN(`GPIS`.`Description`) AS GPIDescription
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
            LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI`=`GPIS`.`Idx`)
            LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)
        WHERE `GPIS`.`AcademicProgram` = {$IN_AcademicProgram}
        AND `GPIS`.`AcademicYear` IN ({$IN_AcademicYears})
        AND `GPIS`.`TobeRemoved` = 0
        GROUP BY CONCAT_WS('-', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`)
    ) AS combined_data
    ORDER BY AcademicYear, GPI
";

// Table's primary key for the derived table
$primaryKey = 'GPIIdx';

// Array of database columns which should be read and sent back to DataTables
$columns = array(
    array( 'db' => 'GPIIdx', 'dt' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_' . $d;
    }),
    array( 'db' => 'GPIIdx', 'dt' => 'GPIIdx'),
    array( 'db' => 'GPI', 'dt' => 'GPI'),
    array( 'db' => 'GPIDescription', 'dt' => 'desc'),
    array( 'db' => 'AcademicYear', 'dt' => 'ay'),
    array( 'db' => 'AVG', 'dt' => 'avg', 'formatter' => function($d, $row) {
        return number_format($d, 2);
    }),
    array( 'db' => 'TOTAL', 'dt' => 'tot'),
    array( 'db' => 'TOPFIFTY_PERCENT', 'dt' => 'top50', 'formatter' => function($d, $row) {
        return number_format($d, 1) . '%';
    }),
    array( 'db' => 'TOPTWENTYFIVE_PERCENT', 'dt' => 'top25', 'formatter' => function($d, $row) {
        return number_format($d, 1) . '%';
    })
);

// Include the custom SSP class
require('ssp.custom.class.php');

// Include your database connection
require_once(__DIR__ . '/../php_include/dbconnection.php');

// Call the complex_custom method with the custom query
echo json_encode(
    SSP::complex_custom($_GET, getSqlConnAttributes(), $customQuery, $primaryKey, $columns)
);