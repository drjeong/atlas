<?php
/**
 * Roster Operations AJAX Handler
 * Handles dropping and restoring students from class roster
 *
 * Actions:
 * - drop_students: Sets IsDropped = 1 for selected students
 * - undrop_students: Sets IsDropped = 0 for selected students
 *
 * Parameters:
 * - action: The operation to perform (drop_students|undrop_students)
 * - avcIdx: Available Course Index
 * - studentNos: Pipe-separated student numbers (e.g., "1|2|3")
 *
 * Response Codes:
 * - 0x11111111: Success
 * - 0x00000000: Illegal entry or unexpected error
 * - 0x00000101: Missing required information
 * - 0x00000102: Invalid action
 * - 0x00000103: Invalid course index
 * - 0x00000104: Invalid student numbers
 * - 0x00000500: Database error
 *
 * 12/18/2025 - initial version created
 */

include_once 'session_handler.php';
?>

<?php

$action = '';
$avcIdx = '';
$studentNos = '';

if (array_key_exists('action', $_POST) &&
    array_key_exists('avcIdx', $_POST) &&
    array_key_exists('studentNos', $_POST)) {

    $action = trim($_POST['action']);
    $avcIdx = trim($_POST['avcIdx']);
    $studentNos = trim($_POST['studentNos']);
} else {
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

if ($action == "" || $avcIdx == "" || $studentNos == "") {
    // no required information
    echo "0x00000101";
    exit;
}

// Validate action
if ($action !== 'drop' && $action !== 'undrop') {
    // no required information
    echo "0x00000102";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php'); // Adjust path as needed
    $DBCONNECTION = new Dbconnection();

    // Validate course index
    $avcIdx = filter_var($avcIdx, FILTER_VALIDATE_INT);
    if ($avcIdx === false || $avcIdx <= 0) {
        throw new Exception('Invalid course index format');
    }

    // Parse and validate student numbers (pipe-separated)
    $studentNosArray = explode('|', $studentNos);
    $studentNosArray = array_filter($studentNosArray, function($val) {
        return is_numeric($val) && intval($val) > 0;
    });

    if (empty($studentNosArray)) {
        throw new Exception('Invalid student number format');
    }

    // Validate each student number
    $validatedStudentNos = [];
    foreach ($studentNosArray as $studentNo) {
        $validated = filter_var($studentNo, FILTER_VALIDATE_INT);
        if ($validated === false || $validated <= 0) {
            throw new Exception('Invalid student number format');
        }
        $validatedStudentNos[] = $validated;
    }

    // Convert to comma-separated string for stored procedure
    $studentNosString = implode(',', $validatedStudentNos);

    // Determine drop value based on action
    $dropValue = ($action === 'drop') ? 1 : 0;

    // Fetching abet syllabus information for different versions
    $result = $DBCONNECTION->callStoredProcedure('SP_UpdateMultipleStudentsDropStatus', [$avcIdx, $studentNosString, $dropValue]);

    echo '0x11111111';

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    echo "0x00000500";  // other DB error

    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'query' => '0x00000500'
    ]));

} catch (Exception $e) {
    // General error
    error_log($e->getMessage());
    echo "0x00000000";
}
?>