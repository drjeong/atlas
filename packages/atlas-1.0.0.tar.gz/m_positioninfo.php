<?php
/**
 * Management of Faculty Positions
 * Description: Listing faculty position information
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 09/29/2023 - Add validation check if position name exists.
 * 09/22/2024 - Add access control of menus
 * 12/06/2024 - changed to address SQL injection
 *
 */

include('checker_systemadmin.php');
include('header.php');

?>


    <script type="text/javascript">

        // Constants
        const ErrorCodes = {
            SUCCESS: '0x11111111',
            SAME_ITEM_EXIST: '0x00200011',
            ITEM_NOT_EXIST: '0x00200012',
            CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
        };

        async function updatepositioninfo(_ID, _Name) {
            try {
                const result = await async_commons.makeApiCall('m_positioninfo_update_ajax.php', {
                    id: _ID,
                    name: _Name
                });

                const code = result.trim();
                switch (code) {
                    case ErrorCodes.SUCCESS: {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('UPDATED', 'Information has been updated!');
                        break;
                    }
                    case ErrorCodes.SAME_ITEM_EXIST: {
                        await async_commons.showErrorMessage(
                            'ERROR',
                            `The entered information exists already!`
                        );
                        // Re-open the add dialog
                        ModifyPosition(_ID, _Name);
                        break;
                    }
                    default: {
                        throw new Error('Unexpected server response');
                    }
                }
            } catch (error) {
                await async_commons.handleError(error);
            }
        }

        async function RemovePosition(id, dp){
            try {
                const willDelete = await async_commons.showConfirmDialog(
                    `Deleted position (<span style="color:red">${dp}</span>) cannot be restored!`
                );

                if (!willDelete.value) return;

                const result = await async_commons.makeApiCall('m_positioninfo_remove_ajax.php', {
                    id: id
                });

                const code = result.trim();
                switch (code) {
                    case ErrorCodes.SUCCESS: {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('DELETED', 'The selected Info has been deleted!');
                        break;
                    }
                    case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                        await async_commons.showErrorMessage('ERROR', 'The selected position information cannot be removed!! It has been used already!!');
                        break;
                    }
                    default: {
                        throw new Error('Unexpected server response');
                    }
                }
            } catch (error) {
                await async_commons.handleError(error);
            }
        }


        function ModifyPosition(_ID, _Name)
        {
            const formContent =
                `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
             <div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Position&nbsp;Name<span style="color:red">*</span></span>
                  <input type="text" name="_Name" id="_Name" class="input-sm form-control" value="${_Name}" placeholder="ex) Assistant Professor" required>
              </div>
             </div>
             </td></tr>
             </table></form>`;

            createModalDialog({
                title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">EDIT POSITION INFORMATION</span>',
                message: formContent,
                buttons: {
                    ok: {
                        label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;UPDATE",
                        className: 'btn-success',
                        callback: function(){
                            updatepositioninfo(_ID, popupfrm._Name.value);
                        }
                    },
                    cancel: {
                        label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                        className: 'btn-default',
                        callback: function(){
                        }
                    }
                }
            }).on('shown.bs.modal',function(){
                $("#_Name").focus();
            });
        }

        async function AddPosition_Perform(_Name) {
            try {
                const result = await async_commons.makeApiCall('m_positioninfo_add_ajax.php', {
                    name: _Name
                });

                const code = result.trim();
                switch (code) {
                    case ErrorCodes.SUCCESS: {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('ADDED', 'The entered position is added successfully!');
                        break;
                    }
                    case ErrorCodes.SAME_ITEM_EXIST: {
                        await async_commons.showErrorMessage(
                            'ERROR',
                            `The entered position exists already!`
                        );
                        // Re-open the add dialog
                        AddPosition(_Name);
                        break;
                    }
                    default: {
                        throw new Error('Unexpected server response');
                    }
                }
            } catch (error) {
                await async_commons.handleError(error);
            }
        }

        function AddPosition(_Name = '')
        {
            const formContent =
                `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
             <div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Position&nbsp;Name<span style="color:red">*</span></span>
                  <input type="text" name="_Name" id="_Name" class="input-sm form-control" value="${_Name}" placeholder="ex) Assistant Professor" required>
              </div>
             </div>
             </td></tr>
             </table></form>`;

            createModalDialog({
                title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD POSITION INFORMATION</span>',
                message: formContent,
                buttons: {
                    ok: {
                        label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;ADD",
                        className: 'btn-success',
                        callback: function(){
                            AddPosition_Perform(popupfrm._Name.value);
                        }
                    },
                    cancel: {
                        label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                        className: 'btn-default',
                        callback: function(){
                        }
                    }
                }
            }).on('shown.bs.modal',function(){
                $("#_Name").focus();
            });
        }

    </script>

    <script class="init">
        $(document).ready(function() {
            dataTable = $("#positioninfo").DataTable({
                "processing": true,
                "serverSide": true,
                "lengthMenu": [ 30, 50, 75, 100, 150, 300, 500 ],
                "ajax": "ssps/m_positioninfo_ssps.php",
                "oLanguage": {"sInfoFiltered": ""},
                "columns": [
                    { "data": 'Idx' },
                    { "data": 'Name' },
                    { "data": "" } // used for representing menu options
                ],
                "fnInitComplete": function(oSettings, json) {
                    // Add "Clear Filter" button to Filter
                    let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                    btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                    $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                        $('#' + oSettings.sTableId).dataTable().fnFilter('');
                    });
                },
                "fnDrawCallback": function() {
                    $('#positioninfo tr td:nth-child(1)').css('text-align', 'center');
                    $('#positioninfo tr td:nth-child(2)').css('text-align', 'center');
                },
                "columnDefs": [ {
                    "targets"  : 'no-sort',
                    "orderable": false,
                },
                    {
                        "targets": -1,
                        "data": null,
                        "orderable": false,
                        "defaultContent": "<div style=\"width:100%;text-align:center;\"><button id=\"modify\" class=\"btn btn-danger btn-xs glyphicon glyphicon-wrench\" style=\"min-height: 20px;\"></button>&nbsp;<button id=\"remove\" class=\"btn btn-danger btn-xs glyphicon glyphicon-remove\" style=\"min-height: 20px;\"></button></div>"
                    }
                ]
            });

            // Set the DataTable in AsyncCommons
            async_commons.setDataTable(dataTable);

            $('#positioninfo tbody').on( 'click', '#remove', function () {
                const data = dataTable.row( $(this).parents('tr') ).data();
                RemovePosition(data.Idx, data.Name);
            } );

            $('#positioninfo tbody').on( 'click', '#modify', function () {
                const data = dataTable.row( $(this).parents('tr') ).data();
                ModifyPosition(data.Idx, data.Name);
            } );

        } );
    </script>


    <div class="pagebacklayout">
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">&nbsp;ALL POSITION INFORMATION</span>&nbsp;</p>
        </div>

        <div class="pagebacklayout_inner_noborder" style="min-height:400px">
            <table width="100%" cellspacing="0" cellpadding="0" border="0" style="margin-bottom:0.1in;">
                <tr>
                    <td width="80%">
                    </td>
                    <td width="20%" align="right"><button class="btn btn-danger btn-sm" onclick="AddPosition();return false;">ADD POSITION INFO</button></td>
                </tr>
            </table>
            <div class="CSSTable_SSPSLIST">
                <table id="positioninfo" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th>IDX</th>
                        <th>POSITION NAME</th>
                        <th class="no-sort">OPERATION</th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

<?php include('footer.php');?>