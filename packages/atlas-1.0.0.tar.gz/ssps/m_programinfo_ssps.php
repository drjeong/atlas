<?php
/**
 * Listing Program Information
 * File: m_programinfo_ssps.php
 * Description: listing program information
 *
 *
 *
 */
include_once 'session_handler.php';


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */

// DB table to use
$table = 'AcademicPrograms'; 
$joinQuery = "FROM `{$table}` AS `APRGMS` LEFT JOIN `Affiliations` AS `dept` ON (`APRGMS`.`Department` = `dept`.`Idx`)";

// Table's primary key
$primaryKey = '`APRGMS`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`APRGMS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
            // Technically a DOM id cannot start with an integer, so we prefix
            // a string. This can also be useful if you have multiple tables
            // to ensure that the id is unique with a different prefix
            return 'row_'.$d;
		}
    ),
    array( 'db' => '`APRGMS`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`APRGMS`.`Name`', 'dt' => 'APName', 'field' => 'APName', 'as' => 'APName'),
    array( 'db' => '`APRGMS`.`Degree`', 'dt' => 'Degree', 'field' => 'Degree', 'as' => 'Degree'),
    array( 'db' => '`dept`.`Name`', 'dt' => 'DeptName', 'field' => 'DeptName', 'as' => 'DeptName'),
    array( 'db' => '`dept`.`Idx`', 'dt' => 'DeptIdx', 'field' => 'DeptIdx', 'as' => 'DeptIdx'),
    array( 'db' => '`APRGMS`.`Date`', 'dt' => 'Date', 'field' => 'Date', 'as' => 'Date'),
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$condition = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $condition)
);

