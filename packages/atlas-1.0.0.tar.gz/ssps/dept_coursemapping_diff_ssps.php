<?php
/**
 * Listing abet courses
 * Description: listing SO/PI differences across programs
 *
 * 02/07/2025 - initial version created
 *
 */
include_once 'session_handler.php';
?>


<?php
$AcademicYear = '';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// Get the filter parameter
$showOnlyUnmatched = isset($_GET['showOnlyUnmatched']) && $_GET['showOnlyUnmatched'] === 'true';

// DB table to use
$table = '';
$joinQuery = " FROM (
    SELECT 
        A.`Idx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`AcademicProgramName`, A.`Degree`,
        A.`Subject`, A.`Num`, A.`Title`, A.`Credits`, A.`AbetSyllabus`,
        A.`Requirement`, A.`CourseIdx`,
        GROUP_CONCAT(DISTINCT B.`SO` ORDER BY B.`SO` SEPARATOR ', ') as `StudentOutcomes`,
        GROUP_CONCAT(DISTINCT B.`SOIdx` ORDER BY B.`SO` SEPARATOR ', ') as `SOIdxes`,
        GROUP_CONCAT(DISTINCT B.`GPIIdx` ORDER BY B.`SO`, B.`GPI` SEPARATOR ', ') as `PIIdxes`,
        GROUP_CONCAT(DISTINCT CONCAT_WS('-', B.`SO`, B.`GPI`) ORDER BY B.`SO`, B.`GPI` SEPARATOR ', ') as `PIs`,
        -- Add discrepancy detection columns from pre-computed data
        COALESCE(DISC.`HasDiscrepancy`, 0) AS `HasDiscrepancy`,
        DISC.`OtherPrograms`,
        DISC.`OtherSOs`,
        DISC.`OtherPIs`
    FROM (
        SELECT 
            `CMCRSES`.`Idx`, 
            `CMCRSES`.`AcademicYear`, 
            `CMCRSES`.`Level`, 
            `CMCRSES`.`AcademicProgram`,
            `CMCRSES`.`AbetSyllabus`,
            `CMCRSES`.`Requirement`,
            `CMCRSES`.`CourseIdx`,
            `AYS`.`AcademicYear` AS `AcademicYearInfo`, 
            `CRSES`.`Subject`, 
            `CRSES`.`Num`, 
            `CRSES`.`Title`, 
            `CRSES`.`Credits`, 
            `ACDEMICPRMS`.`Name` AS `AcademicProgramName`,
            `ACDEMICPRMS`.`Degree`
        FROM `CourseMapping_Courses` AS `CMCRSES`
        INNER JOIN `Courses` AS `CRSES` 
            ON `CMCRSES`.`CourseIdx` = `CRSES`.`Idx`
        INNER JOIN `AcademicYears` AS `AYS` 
            ON `CMCRSES`.`AcademicYear` = `AYS`.`Idx`
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` 
            ON `CMCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`
        -- Only include courses that are offered by multiple programs
        WHERE EXISTS (
            SELECT 1
            FROM `CourseMapping_Courses` AS `CMCRSES2`
            INNER JOIN `Courses` AS `CRSES2` 
                ON `CMCRSES2`.`CourseIdx` = `CRSES2`.`Idx`
            WHERE `CRSES2`.`Subject` = `CRSES`.`Subject`
                AND `CRSES2`.`Num` = `CRSES`.`Num`
                AND `CMCRSES2`.`AcademicYear` = `CMCRSES`.`AcademicYear`
                AND `CMCRSES2`.`AcademicProgram` != `CMCRSES`.`AcademicProgram`
        )
    ) AS A
    LEFT JOIN (
        SELECT 
            `CMCRSES`.`Idx` AS `AbetCourseIdx`, 
            `CMCRSES`.`AcademicYear`, 
            `CMCRSES`.`AcademicProgram`, 
            `STNTOUTCMS`.`Idx` AS `SOIdx`, 
            `STNTOUTCMS`.`SO`, 
            `GPIS`.`Idx` AS `GPIIdx`, 
            `GPIS`.`GPI` 
        FROM `CourseMapping_Courses` AS `CMCRSES` 
        INNER JOIN `CourseMapping_SOs` AS `CMCRSES_SOS` 
            ON `CMCRSES`.`Idx` = `CMCRSES_SOS`.`AbetCourseIdx`
        LEFT JOIN `CourseMapping_GPIs` AS `CMCRSES_GPIS` 
            ON `CMCRSES_GPIS`.`SOIdx` = `CMCRSES_SOS`.`SOIdx` 
            AND `CMCRSES_GPIS`.`AbetCourseIdx` = `CMCRSES_SOS`.`AbetCourseIdx`
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` 
            ON `CMCRSES_SOS`.`SOIdx` = `STNTOUTCMS`.`Idx`
        LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON `GPIS`.`Idx` = `CMCRSES_GPIS`.`GPIIdx`
    ) AS B ON A.`Idx` = B.`AbetCourseIdx` 
        AND A.`AcademicYear` = B.`AcademicYear` 
        AND A.`AcademicProgram` = B.`AcademicProgram`
    -- Optimized discrepancy detection using pre-aggregated data
    LEFT JOIN (
        SELECT 
            CM1.`Idx` AS `AbetCourseIdx`,
            CM1.`AcademicYear`,
            CRS1.`Subject`,
            CRS1.`Num`,
            -- Check if discrepancies exist by comparing current course with ANY other course
            MAX(CASE 
                WHEN (SO_AGG2.`SOString` IS NOT NULL AND SO_AGG1.`SOString` != SO_AGG2.`SOString`)
                  OR (PI_AGG2.`PIString` IS NOT NULL AND PI_AGG1.`PIString` != PI_AGG2.`PIString`)
                THEN 1 
                ELSE 0 
            END) AS `HasDiscrepancy`,
            -- Get other programs (excluding current)
            GROUP_CONCAT(
                DISTINCT CASE 
                    WHEN CM2.`Idx` != CM1.`Idx` 
                    THEN CONCAT(AP2.`Name`, ' (', AP2.`Degree`, ')') 
                END 
                ORDER BY AP2.`Name` 
                SEPARATOR '; '
            ) AS `OtherPrograms`,
            -- Get SOs from other programs (only if different)
            GROUP_CONCAT(
                DISTINCT CASE 
                    WHEN CM2.`Idx` != CM1.`Idx` 
                      AND SO_AGG2.`SOString` != SO_AGG1.`SOString`
                    THEN CONCAT(AP2.`Name`, ': [', IFNULL(SO_AGG2.`SOString`, 'None'), ']')
                END
                ORDER BY AP2.`Name`
                SEPARATOR '; '
            ) AS `OtherSOs`,
            -- Get PIs from other programs (only if different)
            GROUP_CONCAT(
                DISTINCT CASE 
                    WHEN CM2.`Idx` != CM1.`Idx` 
                      AND PI_AGG2.`PIString` != PI_AGG1.`PIString`
                    THEN CONCAT(AP2.`Name`, ': [', IFNULL(PI_AGG2.`PIString`, 'None'), ']')
                END
                ORDER BY AP2.`Name`
                SEPARATOR '; '
            ) AS `OtherPIs`
        FROM `CourseMapping_Courses` CM1
        INNER JOIN `Courses` CRS1 ON CM1.`CourseIdx` = CRS1.`Idx`
        -- Join with other programs offering same course
        INNER JOIN `Courses` CRS2 
            ON CRS2.`Subject` = CRS1.`Subject`
            AND CRS2.`Num` = CRS1.`Num`
        INNER JOIN `CourseMapping_Courses` CM2 
            ON CM2.`CourseIdx` = CRS2.`Idx`
            AND CM2.`AcademicYear` = CM1.`AcademicYear`
            AND CM2.`AcademicProgram` != CM1.`AcademicProgram`
        INNER JOIN `AcademicPrograms` AP2 
            ON CM2.`AcademicProgram` = AP2.`Idx`
        -- Pre-aggregate SOs for current course (CM1)
        LEFT JOIN (
            SELECT 
                CMS.`AbetCourseIdx`,
                GROUP_CONCAT(DISTINCT SO.`SO` ORDER BY SO.`SO` SEPARATOR ', ') AS `SOString`
            FROM `CourseMapping_SOs` CMS
            INNER JOIN `StudentOutcomes` SO ON CMS.`SOIdx` = SO.`Idx`
            GROUP BY CMS.`AbetCourseIdx`
        ) SO_AGG1 ON SO_AGG1.`AbetCourseIdx` = CM1.`Idx`
        -- Pre-aggregate PIs for current course (CM1)
        LEFT JOIN (
            SELECT 
                CMS.`AbetCourseIdx`,
                GROUP_CONCAT(
                    DISTINCT CONCAT(SO.`SO`, '-', GPI.`GPI`) 
                    ORDER BY SO.`SO`, GPI.`GPI` 
                    SEPARATOR ', '
                ) AS `PIString`
            FROM `CourseMapping_SOs` CMS
            INNER JOIN `StudentOutcomes` SO ON CMS.`SOIdx` = SO.`Idx`
            LEFT JOIN `CourseMapping_GPIs` CMG 
                ON CMG.`AbetCourseIdx` = CMS.`AbetCourseIdx` 
                AND CMG.`SOIdx` = CMS.`SOIdx`
            LEFT JOIN `GeneralPerformanceIndicators` GPI ON CMG.`GPIIdx` = GPI.`Idx`
            GROUP BY CMS.`AbetCourseIdx`
        ) PI_AGG1 ON PI_AGG1.`AbetCourseIdx` = CM1.`Idx`
        -- Pre-aggregate SOs for comparison course (CM2)
        LEFT JOIN (
            SELECT 
                CMS.`AbetCourseIdx`,
                GROUP_CONCAT(DISTINCT SO.`SO` ORDER BY SO.`SO` SEPARATOR ', ') AS `SOString`
            FROM `CourseMapping_SOs` CMS
            INNER JOIN `StudentOutcomes` SO ON CMS.`SOIdx` = SO.`Idx`
            GROUP BY CMS.`AbetCourseIdx`
        ) SO_AGG2 ON SO_AGG2.`AbetCourseIdx` = CM2.`Idx`
        -- Pre-aggregate PIs for comparison course (CM2)
        LEFT JOIN (
            SELECT 
                CMS.`AbetCourseIdx`,
                GROUP_CONCAT(
                    DISTINCT CONCAT(SO.`SO`, '-', GPI.`GPI`) 
                    ORDER BY SO.`SO`, GPI.`GPI` 
                    SEPARATOR ', '
                ) AS `PIString`
            FROM `CourseMapping_SOs` CMS
            INNER JOIN `StudentOutcomes` SO ON CMS.`SOIdx` = SO.`Idx`
            LEFT JOIN `CourseMapping_GPIs` CMG 
                ON CMG.`AbetCourseIdx` = CMS.`AbetCourseIdx` 
                AND CMG.`SOIdx` = CMS.`SOIdx`
            LEFT JOIN `GeneralPerformanceIndicators` GPI ON CMG.`GPIIdx` = GPI.`Idx`
            GROUP BY CMS.`AbetCourseIdx`
        ) PI_AGG2 ON PI_AGG2.`AbetCourseIdx` = CM2.`Idx`
        GROUP BY CM1.`Idx`, CM1.`AcademicYear`, CRS1.`Subject`, CRS1.`Num`
    ) AS DISC ON A.`Idx` = DISC.`AbetCourseIdx`
    GROUP BY 
        A.`Idx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`AbetSyllabus`, A.`Degree`, A.`Requirement`,
        DISC.`HasDiscrepancy`, DISC.`OtherPrograms`, DISC.`OtherSOs`, DISC.`OtherPIs`
    ORDER BY A.`Subject` ASC, A.`Num` ASC, A.`AcademicProgramName` ASC
) AS combined";

// Table's primary key
$primaryKey = '`Idx`';

// Array of database columns
$columns = array(
    array(
        'db' => '`Idx`',
        'dt' => 'DT_RowId',
        'field' => 'DT_RowId',
        'as' => 'DT_RowId',
        'formatter' => function($d, $row) {
            return 'row_' . $d;
        }
    ),
    array('db' => '`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array('db' => '`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array('db' => '`AcademicYearInfo`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array('db' => 'FUNC_GetCourseLevel(`Level`)', 'dt' => 'Level', 'field' => 'Level', 'as' => 'Level'),
    array('db' => '`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array('db' => '`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array('db' => '`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array('db' => '`AcademicProgramName`', 'dt' => 'AcademicProgramName', 'field' => 'AcademicProgramName', 'as' => 'AcademicProgramName'),
    array('db' => '`Degree`', 'dt' => 'Degree', 'field' => 'Degree', 'as' => 'Degree'),
    array('db' => '`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array('db' => '`AbetSyllabus`', 'dt' => 'AbetSyllabus', 'field' => 'AbetSyllabus', 'as' => 'AbetSyllabus'),
    array('db' => '`Requirement`', 'dt' => 'Requirement', 'field' => 'Requirement', 'as' => 'Requirement'),
    array('db' => '`SOIdxes`', 'dt' => 'SOIdxes', 'field' => 'SOIdxes', 'as' => 'SOIdxes'),
    array('db' => '`StudentOutcomes`', 'dt' => 'StudentOutcomes', 'field' => 'StudentOutcomes', 'as' => 'StudentOutcomes'),
    array('db' => '`PIIdxes`', 'dt' => 'PIIdxes', 'field' => 'PIIdxes', 'as' => 'PIIdxes'),
    array('db' => '`PIs`', 'dt' => 'PIs', 'field' => 'PIs', 'as' => 'PIs'),
    // New discrepancy columns
    array(
        'db' => '`HasDiscrepancy`',
        'dt' => 'HasDiscrepancy',
        'field' => 'HasDiscrepancy',
        'as' => 'HasDiscrepancy',
        'formatter' => function($d) {
            return (int)$d;
        }
    ),
    array('db' => '`OtherPrograms`', 'dt' => 'OtherPrograms', 'field' => 'OtherPrograms', 'as' => 'OtherPrograms'),
    array('db' => '`OtherSOs`', 'dt' => 'OtherSOs', 'field' => 'OtherSOs', 'as' => 'OtherSOs'),
    array('db' => '`OtherPIs`', 'dt' => 'OtherPIs', 'field' => 'OtherPIs', 'as' => 'OtherPIs')
);

require('ssp.join.class.php');

$extraWhere = "1=1";

if (!empty($AcademicYear) && $AcademicYear !== "all") {
    $AcademicYear = filter_var($AcademicYear, FILTER_VALIDATE_INT);
    $extraWhere .= " AND combined.`AcademicYear` = $AcademicYear";
}

// Filter for unmatched courses only
if ($showOnlyUnmatched) {
    $extraWhere .= " AND HasDiscrepancy = 1";
}

$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery($_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
?>