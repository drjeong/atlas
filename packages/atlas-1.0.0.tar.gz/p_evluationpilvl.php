<?php
/**
 * Evaluation of Performance Indicators by Level
 * Description: Listing evaluation of performance indicators by levels
 *
 * 12/14/2025 - initial version created
 * 06/11/2026 - added dual attainment thresholds (>=2.0 and >=3.0)
 * 07/18/2026 - added database-backed attainment thresholds with access control
 */
?>

<?php
include('header.php');

if ( (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM']) || !isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'])) &&
        isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']) ) {
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearsSelection = AcademicYearsSelection($multipleSelection = true, $visibleTogglebutton = false);

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// determine if the user has access control privilege to the selected program.
$AccessControl = false;
if ($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']])
    $AccessControl = true;
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true)
    $AccessControl = true;
?>
    <!-- Add the new CSS and JS files -->
    <link rel="stylesheet" href="css/attainment-styling.css?v=0.0.004">
    <script src="js/attainment-styling.min.js?v=0.0.004"></script>

    <script type="text/javascript">

        function showNullLevelWarning(courses) {
            if (courses.length === 0) return;

            const courseList = courses.map(c => `${c.courseNo} - ${c.title}`).join('<br>');

            const warningHTML = `
        <div id="nullLevelWarning" style="
            background-color: #fff3cd;
            border: 2px solid #ffc107;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        ">
            <div style="display: flex; align-items: start; gap: 15px;">
                <div style="
                    background-color: #ffc107;
                    color: white;
                    border-radius: 50%;
                    width: 40px;
                    height: 40px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 24px;
                    flex-shrink: 0;
                ">⚠</div>
                <div style="flex: 1;">
                    <h4 style="margin: 0 0 10px 0; color: #856404; font-size: 18px;">
                        Warning: Courses with Missing Level Classification
                    </h4>
                    <p style="margin: 0 0 15px 0; color: #856404; font-size: 14px;">
                        The following <strong>${courses.length}</strong> course(s) have null/missing level classification and are not displayed in the table:
                    </p>
                    <div style="
                        background-color: white;
                        border: 1px solid #ffc107;
                        border-radius: 4px;
                        padding: 15px;
                        max-height: 200px;
                        overflow-y: auto;
                        font-size: 13px;
                        color: #333;
                        line-height: 1.8;
                    ">
                        ${courseList}
                    </div>
                    <p style="margin: 15px 0 0 0; color: #856404; font-size: 13px; font-style: italic;">
                        <strong>Action Required:</strong> Please update the level classification (Introductory/Practice/Mastery) for these courses in the system.
                    </p>
                </div>
                <button id="dismissLevelWarning" style="
                    background-color: #ffc107;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 13px;
                    height: fit-content;
                    white-space: nowrap;
                    align-self: flex-start;
                ">Dismiss</button>
            </div>
        </div>
    `;

            // Insert warning before the button/legend container
            $('#nullLevelWarning').remove(); // Remove any existing warning
            $('#buttonLegendContainer').before(warningHTML);

            // Add dismiss functionality
            $('#dismissLevelWarning').on('click', function() {
                $('#nullLevelWarning').fadeOut(300, function() {
                    $(this).remove();
                });
            });
        }


        $(document).ready(function() {

            // Add event listener to the select element
            $("#_AY").on('change', function() {
                document.academicyear.submit();
            });

            // Add event listeners for changes in both selects
            $("#_AY_FROM").on("change", function () {
                let fromYear = parseInt($("#_AY_FROM").val());
                let toYear = parseInt($("#_AY_TO").val());

                if (fromYear > toYear) {
                    Swal.fire({
                        title: "Warning",
                        text: "The 'From' year cannot be greater than the 'To' year. Setting 'To' year to match 'From' year.",
                        icon: "warning",
                        timer: 2000
                    }).then(() => {
                        $("#_AY_TO").val(fromYear); // Set "To" to match "From"
                        document.academicyear.submit();
                    });
                } else {
                    document.academicyear.submit();
                }
            });

            $("#_AY_TO").on("change", function () {
                let fromYear = parseInt($("#_AY_FROM").val());
                let toYear = parseInt($("#_AY_TO").val());

                if (toYear < fromYear) {
                    Swal.fire({
                        title: "Warning",
                        text: "The 'To' year cannot be less than the 'From' year. Setting 'From' year to match 'To' year.",
                        icon: "warning",
                        timer: 2000
                    }).then(() => {
                        $("#_AY_FROM").val(toYear); // Set "From" to match "To"
                        document.academicyear.submit();
                    });
                } else {
                    document.academicyear.submit();
                }
            });

        });
    </script>

    <div class="pagebacklayout">
        <div class="row">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">EVALUATION OF PERFORMANCE INDICATORS (BY LEVEL)</span></p>

            <p style="text-align:center;font-size:13px;color:#333;margin-top:5px;padding:10px;background-color:#fff3cd;border-left:4px solid #ffc107;font-style:italic;">
                <strong>Note:</strong> Average score is calculated as the sum of all level of attainment scores divided by the <span style="color:#d9534f;font-weight:bold;">total number of scores</span> (not the number of students).
            </p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <?php include('control_allprograms.php'); ?>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:100%;">
                        <?php echo($AcademicYearsSelection);?>
                    </td>
                </tr>
            </table>


            <div class='col-md-12'>
                <!-- Page Content -->
                <div id="pagebacklayout_inner_noborder">

                    <div class="CSSTable_SSPSLIST">
                        <?php
                        displayCoreElectiveData();
                        ?>
                    </div>
                    <!-- /#page-content-wrapper -->
                </div>


            </div>
        </div>

    </div>


<?php include('footer.php');?>

<?php
function displayCoreElectiveData() {
    global $AccessControl;
    ?>


    <!-- Add ExcelJS library -->
    <script src="https://cdn.jsdelivr.net/npm/exceljs@4.3.0/dist/exceljs.min.js"></script>

    <!-- Add your custom Excel export library -->
    <script src="js/excel-export.js"></script>

    <script>
        $(document).ready(function() {

            // Show loading indicator
            $('#legendContainer').html('<div style="padding:15px;background-color:#f0f0f0;border-radius:4px;text-align:center;"><i class="fa fa-spinner fa-spin"></i> Loading thresholds from database...</div>');

            // Load thresholds from database FIRST
            AttainmentConfig.loadThresholds(function(success) {
                // THEN load and build the table
                const varSelectedAcademicYear_From = $("#_AY_FROM option:selected").text();
                const varSelectedAcademicYear_To = $("#_AY_TO option:selected").text();

                const szURL = 'ssps/p_evluationpilvl_ssps.php';

                $.ajax({
                    url: szURL,
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (!response.data || response.data.length === 0) {
                            $('#courseAssessmentTable').html('<tbody><tr><td colspan="100" style="text-align:center;padding:20px;">No data available</td></tr></tbody>');
                            $('#exportToExcel').hide();
                            $('#legendContainer').html(window.thresholdSourceIndicator || '');
                            return;
                        }

                        $('#exportToExcel').show();
                        buildCoreElectiveTable(response, varSelectedAcademicYear_From, varSelectedAcademicYear_To);
                    },
                    error: function(xhr, status, error) {
                        console.error('Error loading course data:', error);
                        console.error('Response:', xhr.responseText);
                        $('#exportToExcel').hide();
                        $('#legendContainer').html(window.thresholdSourceIndicator || '');
                    }
                });
            });

            function buildCoreElectiveTable(response, yearFrom, yearTo) {
                const studentOutcomes = response.studentOutcomes;
                const data = response.data;
                const levelsData = response.levels || [];

                // Track courses with null or missing levels
                const coursesWithNullLevel = [];

                // Extract level labels for display (in order: Introductory, Practice, Mastery)
                const levelOrder = ['Introductory', 'Practice', 'Mastery'];
                const availableLevels = levelsData.map(l => l.label);

                // Use predefined order, but only include levels that exist in the data
                const orderedLevels = levelOrder.filter(level => availableLevels.includes(level));

                // Group courses by level (using display name)
                const coursesByLevel = {};
                orderedLevels.forEach(levelLabel => {
                    coursesByLevel[levelLabel] = [];
                });

                // Categorize courses and identify those with null levels
                data.forEach(course => {
                    if (course.level && orderedLevels.includes(course.level)) {
                        coursesByLevel[course.level].push(course);
                    } else {
                        coursesWithNullLevel.push(course);
                    }
                });

                // Show warning if there are courses with null levels
                if (coursesWithNullLevel.length > 0) {
                    showNullLevelWarning(coursesWithNullLevel);
                } else {
                    $('#nullLevelWarning').remove();
                }

                // Get unique PI codes for each SO
                const uniquePIs = getUniquePIs(studentOutcomes);

                // Build table headers
                let headerHTML = '<thead>';
                headerHTML += '<tr>';
                headerHTML += '<th rowspan="2" style="text-align:center;vertical-align:middle;background-color:#EFBD47;color:white;font-weight:bold;padding:12px;">Course #</th>';
                headerHTML += '<th rowspan="2" style="text-align:center;vertical-align:middle;background-color:#EFBD47;color:white;font-weight:bold;padding:12px;">Course Title</th>';

                // Build SO headers (first row)
                for (let so in uniquePIs) {
                    const piCount = uniquePIs[so].length;
                    headerHTML += `<th colspan="${piCount}" style="text-align:center;background-color:#4a5568;color:white;font-weight:bold;padding:12px;">${so}</th>`;
                }
                headerHTML += '</tr>';

                // Build PI headers (second row)
                headerHTML += '<tr>';
                for (let so in uniquePIs) {
                    for (let pi of uniquePIs[so]) {
                        headerHTML += `<th style="text-align:center;background-color:#718096;color:white;font-weight:bold;padding:10px;">${pi}</th>`;
                    }
                }
                headerHTML += '</tr>';
                headerHTML += '</thead>';

                // Build table body
                let bodyHTML = '<tbody>';
                const totalCols = Object.values(uniquePIs).reduce((sum, pis) => sum + pis.length, 0);

                let hasAnyCourses = false;

                // Build sections for each level in order
                orderedLevels.forEach(levelLabel => {
                    const courses = coursesByLevel[levelLabel];
                    if (courses && courses.length > 0) {
                        hasAnyCourses = true;
                        bodyHTML += `<tr><td colspan="${totalCols + 2}" style="font-weight:bold;background-color:#c1c1c1;padding:12px;font-size:12px;text-transform:uppercase;">${levelLabel}</td></tr>`;
                        bodyHTML += buildCourseRows(courses, studentOutcomes, uniquePIs);
                        bodyHTML += buildAverageRow(courses, studentOutcomes, uniquePIs, levelLabel);
                        bodyHTML += buildAttainmentRow2(courses, studentOutcomes, uniquePIs, levelLabel);
                        bodyHTML += buildAttainmentRow3(courses, studentOutcomes, uniquePIs, levelLabel);
                    }
                });

                if (!hasAnyCourses) {
                    bodyHTML += `<tr><td colspan="${totalCols + 2}" style="text-align:center;padding:20px;">No course data available with valid level classifications</td></tr>`;
                    $('#exportToExcel').hide();
                    $('#legendContainer').html(window.thresholdSourceIndicator || '');
                } else {
                    $('#exportToExcel').show();
                    $('#legendContainer').show();
                }

                bodyHTML += '</tbody>';

                // Insert into table
                $('#courseAssessmentTable').html(headerHTML + bodyHTML);

                // Apply cell styling
                if (typeof applyCellStyling === 'function') {
                    applyCellStyling('#courseAssessmentTable');
                } else {
                    console.error('applyCellStyling function not found! Make sure attainment-styling.min.js is loaded.');
                }

                // Render legend with edit capability
                renderLegendWithEdit();

                // Add export button click handler
                $('#exportToExcel').off('click').on('click', function() {
                    ExcelExporter.exportTableToExcel(
                        'courseAssessmentTable',
                        `Course_Assessment_By_Level_${yearFrom}_to_${yearTo}`
                    );
                });
            }

            <?php if ($AccessControl) { ?>
            // Function for authorized users - with edit button
            function renderLegendWithEdit() {
                if (typeof generateLegendHTML === 'function') {
                    const legendHTML = generateLegendHTML(true); // true = show edit button
                    $('#legendContainer').html(legendHTML + (window.thresholdSourceIndicator || ''));

                    // Attach edit button handler
                    $('#editThresholdsBtn').on('click', function() {
                        if (typeof showThresholdEditor === 'function') {
                            showThresholdEditor(function() {
                                renderLegendWithEdit(); // Refresh legend after update
                            });
                        }
                    });
                } else {
                    console.error('generateLegendHTML function not found!');
                }
            }
            <?php } else { ?>
            // Function for non-authorized users - WITHOUT edit button
            function renderLegendWithEdit() {
                if (typeof generateLegendHTML === 'function') {
                    const legendHTML = generateLegendHTML(false); // false = NO edit button
                    $('#legendContainer').html(legendHTML + (window.thresholdSourceIndicator || ''));
                } else {
                    console.error('generateLegendHTML function not found!');
                }
            }
            <?php } ?>

            // Get unique PI codes for each SO
            function getUniquePIs(studentOutcomes) {
                const uniquePIs = {};
                for (let so in studentOutcomes) {
                    const codes = studentOutcomes[so].gpis.map(gpi => gpi.code);
                    uniquePIs[so] = [...new Set(codes)];
                }
                return uniquePIs;
            }

            // Get GPI indices for a specific SO and PI code
            function getGPIIndicesForPI(studentOutcomes, so, piCode) {
                return studentOutcomes[so].gpis
                    .filter(gpi => gpi.code === piCode)
                    .map(gpi => gpi.gpiIdx);
            }

            function buildCourseRows(courses, studentOutcomes, uniquePIs) {
                let html = '';
                for (let course of courses) {
                    html += `<tr>`;
                    html += `<td style="font-weight:bold;padding:10px;">${course.courseNo}</td>`;
                    html += `<td style="padding:10px;">${course.title || ''}</td>`;

                    for (let so in uniquePIs) {
                        for (let piCode of uniquePIs[so]) {
                            const gpiIndices = getGPIIndicesForPI(studentOutcomes, so, piCode);
                            let sum = 0;
                            let count = 0;

                            for (let gpiIdx of gpiIndices) {
                                const columnKey = 'SO' + so + '_GPI' + gpiIdx;
                                const value = parseFloat(course[columnKey]);
                                if (!isNaN(value) && value > 0) {
                                    sum += value;
                                    count++;
                                }
                            }

                            const avgValue = count > 0 ? (sum / count).toFixed(2) : '';
                            html += `<td data-value="${avgValue}">${avgValue}</td>`;
                        }
                    }
                    html += '</tr>';
                }
                return html;
            }

            function buildAverageRow(courses, studentOutcomes, uniquePIs, levelLabel) {
                let html = '<tr style="background-color:#f8f9fa;border-top:2px solid #333;">';
                html += `<td colspan="2" style="font-weight:bold;padding:10px;">${levelLabel} Average</td>`;

                for (let so in uniquePIs) {
                    for (let piCode of uniquePIs[so]) {
                        const gpiIndices = getGPIIndicesForPI(studentOutcomes, so, piCode);
                        let totalSum = 0;
                        let totalCount = 0;

                        for (let course of courses) {
                            let courseSum = 0;
                            let courseCount = 0;

                            for (let gpiIdx of gpiIndices) {
                                const columnKey = 'SO' + so + '_GPI' + gpiIdx;
                                const value = parseFloat(course[columnKey]);
                                if (!isNaN(value) && value > 0) {
                                    courseSum += value;
                                    courseCount++;
                                }
                            }

                            if (courseCount > 0) {
                                totalSum += (courseSum / courseCount);
                                totalCount++;
                            }
                        }

                        const avg = totalCount > 0 ? (totalSum / totalCount).toFixed(2) : '';
                        html += `<td style="font-weight:bold;" data-value="${avg}">${avg}</td>`;
                    }
                }
                html += '</tr>';
                return html;
            }

            function buildAttainmentRow2(courses, studentOutcomes, uniquePIs, levelLabel) {
                let html = '<tr style="background-color:#e8f4f8;border-bottom:1px solid #999;">';
                html += '<td colspan="2" style="font-weight:bold;padding:10px;">Attainment (% of students scoring ≥ 2.0)</td>';

                for (let so in uniquePIs) {
                    for (let piCode of uniquePIs[so]) {
                        const gpiIndices = getGPIIndicesForPI(studentOutcomes, so, piCode);
                        let totalStudents = 0;
                        let studentsAbove2 = 0;

                        for (let course of courses) {
                            for (let gpiIdx of gpiIndices) {
                                const countKey = 'SO' + so + '_GPI' + gpiIdx + '_count';
                                const above2Key = 'SO' + so + '_GPI' + gpiIdx + '_above2';
                                const count = parseInt(course[countKey]) || 0;
                                const above2 = parseInt(course[above2Key]) || 0;
                                totalStudents += count;
                                studentsAbove2 += above2;
                            }
                        }

                        const attainmentPercent = totalStudents > 0 ? ((studentsAbove2 / totalStudents) * 100).toFixed(2) : '';
                        const displayValue = attainmentPercent !== '' ? `${attainmentPercent}% (${studentsAbove2}/${totalStudents})` : '';
                        html += `<td style="font-weight:bold;text-align:center;padding:10px;font-size:10px;" data-attainment="${attainmentPercent}" data-threshold="2.0">${displayValue}</td>`;
                    }
                }
                html += '</tr>';
                return html;
            }

            function buildAttainmentRow3(courses, studentOutcomes, uniquePIs, levelLabel) {
                let html = '<tr style="background-color:#e8f4f8;border-bottom:2px solid #333;">';
                html += '<td colspan="2" style="font-weight:bold;padding:10px;">Attainment (% of students scoring ≥ 3.0)</td>';

                for (let so in uniquePIs) {
                    for (let piCode of uniquePIs[so]) {
                        const gpiIndices = getGPIIndicesForPI(studentOutcomes, so, piCode);
                        let totalStudents = 0;
                        let studentsAbove3 = 0;

                        for (let course of courses) {
                            for (let gpiIdx of gpiIndices) {
                                const countKey = 'SO' + so + '_GPI' + gpiIdx + '_count';
                                const above3Key = 'SO' + so + '_GPI' + gpiIdx + '_above3';
                                const count = parseInt(course[countKey]) || 0;
                                const above3 = parseInt(course[above3Key]) || 0;
                                totalStudents += count;
                                studentsAbove3 += above3;
                            }
                        }

                        const attainmentPercent = totalStudents > 0 ? ((studentsAbove3 / totalStudents) * 100).toFixed(2) : '';
                        const displayValue = attainmentPercent !== '' ? `${attainmentPercent}% (${studentsAbove3}/${totalStudents})` : '';
                        html += `<td style="font-weight:bold;text-align:center;padding:10px;font-size:10px;" data-attainment="${attainmentPercent}" data-threshold="3.0">${displayValue}</td>`;
                    }
                }
                html += '</tr>';
                return html;
            }
        });
    </script>

    <style>
        #courseAssessmentTable {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        #courseAssessmentTable th,
        #courseAssessmentTable td {
            border: 1px solid #ddd;
            padding: 10px;
        }
        #courseAssessmentTable th {
            font-weight: bold;
        }
        #courseAssessmentTable tbody tr:hover {
            background-color: #f5f5f5;
        }
        #exportToExcel {
            background-color: #217346;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            font-size: 12px;
            display: none; /* Initially hidden */
        }
        #exportToExcel:hover {
            background-color: #1a5c37;
        }
    </style>

    <div style="padding: 20px;">
        <!-- Flex container for button and legend in same row -->
        <div id="buttonLegendContainer" style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; gap: 20px;">
            <!-- Export button on the left -->
            <div>
                <button id="exportToExcel">
                    <i class="glyphicon glyphicon-download-alt"></i> Export to Excel
                </button>
            </div>

            <!-- Legend container on the right -->
            <div id="legendContainer"></div>
        </div>

        <!-- Table below -->
        <div class="CSSTable_SSPSLIST" style="overflow-x: auto;">
            <table id="courseAssessmentTable" class="display" style="width:100%;"></table>
        </div>
    </div>
    <?php
}
?>