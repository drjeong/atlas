<?php
include_once '../session_handler.php';

// Check if user is system admin
if (!isset($_SESSION['ATLAS_LOGIN_SYSADMIN']) || $_SESSION['ATLAS_LOGIN_SYSADMIN'] !== true) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

require_once(__DIR__ . '/../php_include/dbconnection_class.php');
$db = new Dbconnection();

// Get main menus
$mainMenuQuery = "
    SELECT MenuCode, MenuName, DisplayOrder
    FROM MainMenuGroups
    ORDER BY DisplayOrder
";
$mainMenuResult = $db->sendquery($mainMenuQuery);
$mainMenus = array();

if ($mainMenuResult) {
    while ($row = $mainMenuResult->fetch_assoc()) {
        $mainMenus[] = array(
            'MenuCode' => $row['MenuCode'],
            'MenuName' => $row['MenuName'],
            'DisplayOrder' => $row['DisplayOrder']
        );
    }
}

// Get submenu groups ordered by parent menu display order
$groupQuery = "
    SELECT 
        SMG.GroupCode,
        SMG.GroupName,
        SMG.ParentMenuCode,
        SMG.DisplayOrder,
        MMG.DisplayOrder as ParentDisplayOrder
    FROM SubMenuGroups SMG
    INNER JOIN MainMenuGroups MMG ON SMG.ParentMenuCode = MMG.MenuCode
    ORDER BY MMG.DisplayOrder, SMG.DisplayOrder
";
$groupResult = $db->sendquery($groupQuery);
$subMenuGroups = array();
$groupsByParent = array();

if ($groupResult) {
    while ($row = $groupResult->fetch_assoc()) {
        $groupData = array(
            'GroupCode' => $row['GroupCode'],
            'GroupName' => $row['GroupName'],
            'ParentMenuCode' => $row['ParentMenuCode']
        );

        $subMenuGroups[] = $groupData;

        if (!isset($groupsByParent[$row['ParentMenuCode']])) {
            $groupsByParent[$row['ParentMenuCode']] = array();
        }
        $groupsByParent[$row['ParentMenuCode']][] = $groupData;
    }
}

// Get all users with their permissions
$userQuery = "
    SELECT 
        UA.Idx,
        UA.Name,
        UA.Email,
        PSTN.Name as PositionName,
        AFFILATN.Name as AffiliationName,
        UA.SystemAdmin
    FROM UserAccounts UA
    LEFT JOIN Positions PSTN ON UA.Position = PSTN.Idx
    LEFT JOIN Affiliations AFFILATN ON UA.Affiliation = AFFILATN.Idx
    WHERE UA.Disabled = 0
    ORDER BY UA.Name
";

$userResult = $db->sendquery($userQuery);
$users = array();

if ($userResult) {
    while ($row = $userResult->fetch_assoc()) {
        $userIdx = $row['Idx'];

        // Get submenu group permissions
        $groupPermQuery = "
            SELECT DISTINCT MenuGroupCode 
            FROM UserMenuPermissions 
            WHERE UserIdx = ?
        ";
        $groupPermResult = $db->prepare_execute($groupPermQuery, [$userIdx]);
        $groupPerms = array();
        if ($groupPermResult) {
            while ($permRow = $groupPermResult->fetch_assoc()) {
                $groupPerms[$permRow['MenuGroupCode']] = true;
            }
        }

        // Build permission data object (only for submenu groups)
        $permissionData = array();
        foreach ($subMenuGroups as $group) {
            $permissionData[$group['GroupCode']] = isset($groupPerms[$group['GroupCode']]) ? '1' : '0';
        }

        $users[] = array(
            'DT_RowId' => 'row_' . $row['Idx'],
            'Idx' => $row['Idx'],
            'Name' => $row['Name'],
            'Email' => $row['Email'],
            'PositionName' => $row['PositionName'] ? $row['PositionName'] : '',
            'AffiliationName' => $row['AffiliationName'] ? $row['AffiliationName'] : '',
            'SystemAdmin' => $row['SystemAdmin'],
            'Permissions' => $permissionData
        );
    }
}

// Return data in DataTables format
$response = array(
    'draw' => isset($_GET['draw']) ? intval($_GET['draw']) : 0,
    'recordsTotal' => count($users),
    'recordsFiltered' => count($users),
    'data' => $users,
    'menuItems' => $subMenuGroups,
    'mainMenus' => $mainMenus,
    'menuGroups' => $groupsByParent
);

header('Content-Type: application/json');
echo json_encode($response);
?>