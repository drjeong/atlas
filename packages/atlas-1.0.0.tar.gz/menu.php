<?php
/**
 * menu.php
 * Description: Listing all menus.
 * Author: Dong Hyun Jeong
 *
 * 05/11/2021 - Add if statement for checking $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] is defined or not.
 * 03/01/2024 - Add a new menu (Abet course evaluators)
 * 03/28/2024 - Add a new menu (Evaluation Cycle)
 * 09/22/2024 - Add access control of menus
 * 07/24/2026 - Add User preview
 */

require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/php_include/listfunc.php');
require_once(__DIR__ . '/menu_permission_functions.php');
?>

<?php if (isset($_SESSION['ATLAS_PREVIEW_MODE']) && $_SESSION['ATLAS_PREVIEW_MODE'] === true) { ?>
    <div style="background-color: #ff9800; color: white; padding: 10px; text-align: center; position: sticky; top: 0; z-index: 9999;">
        <strong>⚠️ PREVIEW MODE</strong> - Viewing as: <?php echo htmlspecialchars($_SESSION['ATLAS_LOGIN_USERNAME']); ?>
        <button onclick="exitPreviewMode()" style="margin-left: 20px; padding: 5px 15px; background: white; color: #ff9800; border: none; border-radius: 3px; cursor: pointer;">
            Exit Preview Mode
        </button>
    </div>

    <script>
        function exitPreviewMode() {
            Swal.fire({
                title: 'Exit Preview Mode?',
                text: 'You will return to your admin session.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, exit preview',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show loading
                    Swal.fire({
                        title: 'Restoring Admin Session',
                        html: 'Please wait...',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    fetch('preview_user_view.php?restore=true')
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Admin Session Restored',
                                    text: 'Returning to admin view...',
                                    timer: 1500,
                                    showConfirmButton: false
                                }).then(() => {
                                    window.location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: 'Unable to restore admin session. Please try again.',
                                    confirmButtonColor: '#d33'
                                });
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Connection Error',
                                text: 'An error occurred while restoring admin session.',
                                confirmButtonColor: '#d33'
                            });
                        });
                }
            });
        }
    </script>
<?php } ?>


<?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
    <!-- Preview User Selection Modal -->
    <div id="previewUserModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title">
                        <i class="glyphicon glyphicon-user"></i> Select User to Preview
                    </h4>
                </div>
                <div class="modal-body">
                    <!-- Search Box -->
                    <div class="form-group">
                        <div class="input-group">
                        <span class="input-group-addon">
                            <i class="glyphicon glyphicon-search"></i>
                        </span>
                            <input type="text"
                                   id="previewUserSearch"
                                   class="form-control"
                                   placeholder="Search by name or email..."
                                   autocomplete="off">
                        </div>
                    </div>

                    <!-- Loading Indicator -->
                    <div id="previewUserLoading" style="text-align: center; display: none; padding: 20px;">
                        <i class="glyphicon glyphicon-refresh glyphicon-spin"></i> Loading users...
                    </div>

                    <!-- Users List -->
                    <div id="previewUsersList" style="max-height: 400px; overflow-y: auto;">
                        <!-- Users will be populated here -->
                    </div>

                    <!-- No Results Message -->
                    <div id="previewUsersNoResults" style="display: none; text-align: center; padding: 20px; color: #999;">
                        <i class="glyphicon glyphicon-info-sign"></i> No users found
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <style>
        .preview-user-item {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .preview-user-item:hover {
            background-color: #f5f5f5;
        }

        .preview-user-item:last-child {
            border-bottom: none;
        }

        .preview-user-name {
            font-weight: bold;
            color: #333;
            margin-bottom: 4px;
        }

        .preview-user-email {
            color: #666;
            font-size: 0.9em;
        }

        .preview-user-details {
            color: #999;
            font-size: 0.85em;
            margin-top: 4px;
        }

        .preview-user-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 0.8em;
            margin-left: 8px;
        }

        .badge-observer {
            background-color: #5bc0de;
            color: white;
        }

        .badge-user {
            background-color: #5cb85c;
            color: white;
        }
    </style>

    <script>
        let previewUserSearchTimeout;

        // Open the preview user dialog
        function openPreviewUserDialog(event) {
            event.preventDefault();
            $('#previewUserModal').modal('show');
            loadPreviewUsers('');
        }

        // Load users list with optional search term
        function loadPreviewUsers(searchTerm) {
            const loadingEl = document.getElementById('previewUserLoading');
            const listEl = document.getElementById('previewUsersList');
            const noResultsEl = document.getElementById('previewUsersNoResults');

            loadingEl.style.display = 'block';
            listEl.style.display = 'none';
            noResultsEl.style.display = 'none';

            const url = searchTerm
                ? `get_users_list.php?search=${encodeURIComponent(searchTerm)}`
                : 'get_users_list.php';

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    loadingEl.style.display = 'none';

                    if (data.success && data.users.length > 0) {
                        listEl.style.display = 'block';
                        renderUsersList(data.users);
                    } else {
                        noResultsEl.style.display = 'block';
                    }
                })
                .catch(error => {
                    console.error('Error loading users:', error);
                    loadingEl.style.display = 'none';
                    noResultsEl.style.display = 'block';
                    noResultsEl.innerHTML = '<i class="glyphicon glyphicon-exclamation-sign"></i> Error loading users';

                    Swal.fire({
                        icon: 'error',
                        title: 'Error Loading Users',
                        text: 'Unable to load users list. Please try again.',
                        confirmButtonColor: '#d33'
                    });
                });
        }

        // Render users list
        function renderUsersList(users) {
            const listEl = document.getElementById('previewUsersList');
            listEl.innerHTML = '';

            users.forEach(user => {
                const userItem = document.createElement('div');
                userItem.className = 'preview-user-item';
                userItem.onclick = () => selectUserToPreview(user.Idx, user.Name);

                const badgeClass = user.UserType === 'Observer' ? 'badge-observer' : 'badge-user';

                userItem.innerHTML = `
            <div class="preview-user-name">
                ${escapeHtml(user.Name)}
                <span class="preview-user-badge ${badgeClass}">${escapeHtml(user.UserType)}</span>
            </div>
            <div class="preview-user-email">${escapeHtml(user.Email)}</div>
        `;

                listEl.appendChild(userItem);
            });
        }

        // Select a user to preview
        function selectUserToPreview(userIdx, userName) {
            Swal.fire({
                title: 'Preview User View?',
                html: `You are about to preview the view for:<br><strong>${escapeHtml(userName)}</strong><br><br>You can return to admin view anytime.`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, preview this user',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Close the modal
                    $('#previewUserModal').modal('hide');

                    // Show loading with SweetAlert
                    Swal.fire({
                        title: 'Switching to User View',
                        html: 'Please wait while we load the user\'s view...',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    fetch('preview_user_view.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'userIdx=' + userIdx
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Preview Mode Activated',
                                    text: `Now viewing as: ${data.userName}`,
                                    timer: 1500,
                                    showConfirmButton: false
                                }).then(() => {
                                    window.location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error',
                                    text: data.error || 'Unable to switch to user view',
                                    confirmButtonColor: '#d33'
                                });
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Connection Error',
                                text: 'An error occurred while switching to preview mode. Please try again.',
                                confirmButtonColor: '#d33'
                            });
                        });
                }
            });
        }

        // Search handler with debounce
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('previewUserSearch');
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    clearTimeout(previewUserSearchTimeout);
                    previewUserSearchTimeout = setTimeout(() => {
                        loadPreviewUsers(this.value);
                    }, 300);
                });
            }
        });

        // Helper function to escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>
<?php } ?>

    <table class="pagebacklayout_top" style="border-spacing:0; padding:0; height: 60px;">
        <tr style="background-image: url('./images/banner_bg_repeat.jpg'); background-repeat: repeat;"><td height="5" colspan="3"></td></tr>
        <tr style="background-image: url('./images/banner_bg_repeat.jpg'); background-repeat: repeat;">
            <td style="width:5px;"><img src="./images/universitylogo.svg" class="svgshadow" alt="University Logo" style="height:20px; text-align: left""></td>
            <td style="width:100%;text-align: center;"><span style="color:white; font-size: 20px;text-shadow: 2px 2px #000000;">ATLAS: Academic Tracking & Learning Assessment System</span></td>
            <td style="width:10%;min-width:300px; color:white;font-size: 12pt;">
                <div class="topmenu_nav" style="position:relative;left:0;min-width:110px;">
                    <table style="border-spacing:0; padding:0; width:100%;">
                        <tr>
                            <td>
                                <div class="content">
                                    <ul class="topmenu_item" style="background:none;">
                                        <li style="width:100%;"><a href="javascript:mopen('t1')" onmouseover="mopen('t1')"  onmouseout="mclosetime()"><i class="glyphicon glyphicon-home"></i> <?php echo($_SESSION['ATLAS_LOGIN_USERNAME']);?></a>
                                            <div style="z-index: 1001;" id="t1"  onmouseover="mcancelclosetime()"  onmouseout="mclosetime()">
                                                <table>
                                                    <tr>
                                                        <td style="vertical-align: top">
                                                            <a href="#" onclick="passwordchange();" style="width:100%;"><i class="glyphicon glyphicon-lock"></i> Change Password</a>
                                                            <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
                                                                <a href="#" onclick="openPreviewUserDialog(event)" style="width:100%;">
                                                                    <i class="glyphicon glyphicon-user"></i> Preview User View
                                                                </a>
                                                            <?php } ?>
                                                            <a href="logout.php" style="width:100%;"><i class="glyphicon glyphicon-log-out"></i> Logout</a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
            </td>
        </tr>
    </table>


    <!-- Bootstrap Navbar with hover activation -->
    <nav class="navbar navbar-default" style="background-color: #efbd47; margin-bottom: 0; border-radius: 0; border: none;">
        <div class="container-fluid">
            <!-- Brand and toggle -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <!-- Custom CSS for styling -->
            <style>
                .navbar-default {
                    background-color: #efbd47;
                    border-color: #efbd47;
                }
                .navbar-default .navbar-nav > li > a {
                    color: #000000;
                    font-weight: bold;
                    font-size: 12px; /* Smaller text for menu items */
                }
                .navbar-default .navbar-nav > li > a:hover,
                .navbar-default .navbar-nav > li > a:focus {
                    background-color: #b7312c; /* Red hover color */
                    color: #ffffff; /* White text on hover for better contrast */
                }
                .dropdown-menu {
                    background-color: #f8f8f8;
                    z-index: 100;
                    display: none;
                }
                .dropdown:hover .dropdown-menu {
                    display: block; /* Show dropdown on hover */
                }
                .dropdown-menu > li > a {
                    padding: 6px 20px;
                    font-size: 11px; /* Smaller text for dropdown items */
                }
                /* Hover effect for dropdown items */
                .dropdown-menu > li > a:hover,
                .dropdown-menu > li > a:focus {
                    background-color: #b7312c;
                    color: #ffffff;
                }
                /* For links that had the blue color in original menu */
                .dropdown-menu > li > a.blue-link {
                    color: #0000CC;
                }
                /* Hover effect for blue links */
                .dropdown-menu > li > a.blue-link:hover,
                .dropdown-menu > li > a.blue-link:focus {
                    color: #ffffff;
                    background-color: #b7312c;
                }
                /* For links that had the red color in original menu */
                .dropdown-menu > li > a.red-link {
                    color: #CC0000;
                }
                /* Hover effect for red links */
                .dropdown-menu > li > a.red-link:hover,
                .dropdown-menu > li > a.red-link:focus {
                    color: #ffffff;
                    background-color: #b7312c;
                }
                .dropdown-menu .dropdown-header {
                    background-color: #dcdcdc; /* Light gray */
                    font-size: 11px;
                    font-weight: 600;
                    color: #6c757d;
                    text-transform: uppercase;
                    letter-spacing: 0.5px;
                    padding: 8px 20px;
                    margin: 0;
                    display: block;
                    cursor: default; /* Show default cursor since headers are not clickable */
                }

                /* Hover effect for headers */
                .dropdown-menu .dropdown-header:hover {
                    background-color: #c0c0c0; /* Darker gray on hover */
                    color: #495057; /* Slightly darker text */
                }
                /* Remove top margin from first header */
                .dropdown-menu > li.dropdown-header:first-child {
                    margin-top: 0;
                }

                /* Fix for mobile devices */
                @media (max-width: 767px) {
                    .dropdown:hover .dropdown-menu {
                        display: none;
                    }
                    .dropdown.open .dropdown-menu {
                        display: block;
                    }
                }
            </style>

            <!-- JavaScript to handle dropdown behavior -->
            <script>
                $(document).ready(function() {
                    // For mobile devices, restore click behavior
                    if ($(window).width() < 768) {
                        $('.dropdown-toggle').attr('data-toggle', 'dropdown');
                    } else {
                        // For desktop, remove click event to prevent conflicts with hover
                        $('.dropdown-toggle').attr('data-toggle', '');
                    }

                    // Handle window resize
                    $(window).resize(function() {
                        if ($(window).width() < 768) {
                            $('.dropdown-toggle').attr('data-toggle', 'dropdown');
                        } else {
                            $('.dropdown-toggle').attr('data-toggle', '');
                        }
                    });
                });
            </script>



            <!-- Collect the nav links and forms -->
            <div class="collapse navbar-collapse" id="main-navbar">
                <ul class="nav navbar-nav">
                    <!-- Home - Always visible -->
                    <li><a href="main.php">HOME</a></li>

                    <?php
                    // Course Assessments variables
                    $showMyCourseAssessmentMenus = hasAccessToSubmenuGroup('MY_COURSE_ASSESSMENTS');
                    $showAssistantMenus = hasAccessToSubmenuGroup('ASSISTANT_MENUS');
                    $showReferenceMaterials = hasAccessToSubmenuGroup('REFERENCE_MATERIALS');
                    $showDirectorAssessments = hasAccessToSubmenuGroup('ASSESSMENTS_FOR_DIRECTORS');

                    if ($showMyCourseAssessmentMenus || $showAssistantMenus || $showReferenceMaterials || $showDirectorAssessments) {
                        ?>
                        <!-- Course Assessments Dropdown -->
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">
                                COURSE ASSESSMENTS <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <?php if ($showMyCourseAssessmentMenus) { ?>
                                    <li class="dropdown-header">MY COURSE ASSESSMENTS</li>
                                    <li><a href="u_courses.php" class="blue-link">COURSE ASSESSMENTS</a></li>
                                    <li><a href="u_crsmaterials.php" class="blue-link">COURSE MATERIALS</a></li>
                                    <li><a href="u_cevaluations.php" class="blue-link">COURSE ASSESSMENTS EVALUATION</a></li>
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showAssistantMenus) { ?>
                                    <li class="dropdown-header">ASSISTANT'S MENUS</li>
                                    <li><a href="asst_courses.php">ASSISTANT'S COURSE ASSESSMENTS</a></li>
                                    <li><a href="asst_crsmaterials.php">ASSISTANT'S COURSE MATERIALS COLLECTION</a></li>
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showReferenceMaterials) { ?>
                                    <li class="dropdown-header">REFERENCE MATERIALS</li>
                                    <li><a href="u_allcourses.php">VIEW COURSE ASSESSMENTS</a></li>
                                    <li><a href="u_allcrsmaterials.php">VIEW COURSE MATERIALS</a></li>
                                    <!--                                <li><a href="u_allcevaluations.php">VIEW COURSE ASSESSMENTS EVALUATION</a></li>-->
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showDirectorAssessments) { ?>
                                    <li class="dropdown-header">ASSESSMENTS FOR PROGRAM DIRECTORS</li>
                                    <li><a href="ua_courses.php">ALL COURSE ASSESSMENTS</a></li>
                                    <li><a href="ua_crsmaterials.php">ALL COURSE MATERIALS</a></li>
                                    <li><a href="ua_cevaluations.php">ALL COURSE ASSESSMENTS EVALUATION</a></li>
                                <?php } ?>
                            </ul>
                        </li>
                    <?php } ?>

                    <!-- Assessments Summary Dropdown -->
                    <?php
                    $showAssignments = hasAccessToSubmenuGroup('ASSESSMENT_ASSIGNMENTS');
                    $showEvaluation = hasAccessToSubmenuGroup('EVALUATION_SO_PI');
                    $showCourseLevel = hasAccessToSubmenuGroup('COURSE_LEVEL_EVALUATION');

                    if ($showAssignments || $showEvaluation || $showCourseLevel) {  // FIXED: Use correct variables
                        ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">
                                SUMMARY & REPORT <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <?php if ($showAssignments) { ?>
                                    <li class="dropdown-header">ASSESSMENT ASSIGNMENTS</li>
                                    <li><a href="p_aabycrs.php">ASSESSMENT ASSIGNMENTS BY COURSE</a></li>
                                    <li><a href="p_aabyoutcms.php">ASSESSMENT ASSIGNMENTS BY STUDENT OUTCOME</a></li>
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showEvaluation) { ?>
                                    <li class="dropdown-header">EVALUATION OF SO and PI (BY # OF STUDENT SCORES) </li>
                                    <li><a href="p_evluationsos.php">EVALUATION OF STUDENT OUTCOMES (OVERALL)</a></li>
                                    <li><a href="p_evluationpis.php">EVALUATION OF PERFORMANCE INDICATORS (OVERALL)</a></li>
                                    <li><a href="p_evluationpisdetail.php">EVALUATION OF PERFORMANCE INDICATORS (DETAIL)</a></li>
                                    <li><a href="p_evluationpireq.php">EVALUATION OF PERFORMANCE INDICATORS (BY REQUIREMENT)</a></li>
                                    <li><a href="p_evluationpilvl.php">EVALUATION OF PERFORMANCE INDICATORS (BY LEVEL)</a></li>
                                    <li><a href="p_clevluationsos.php">COURSE-LEVEL EVALUATION OF STUDENT OUTCOMES</a></li>
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showEvaluation) { ?>
                                    <li class="dropdown-header">EVALUATION OF SO and PI (BY # OF STUDENTS) </li>
                                    <li><a href="p_evluationsos_bysts.php">EVALUATION OF STUDENT OUTCOMES (OVERALL)</a></li>
                                    <li><a href="p_evluationpis_bysts.php">EVALUATION OF PERFORMANCE INDICATORS (OVERALL)</a></li>
                                    <li><a href="p_evluationpisdetail_bysts.php">EVALUATION OF PERFORMANCE INDICATORS (DETAIL)</a></li>
                                    <li><a href="p_evluationpireq_bysts.php">EVALUATION OF PERFORMANCE INDICATORS (BY REQUIREMENT)</a></li>
                                    <li><a href="p_evluationpilvl_bysts.php">EVALUATION OF PERFORMANCE INDICATORS (BY LEVEL)</a></li>
                                    <li><a href="p_clevluationsos_bysts.php">COURSE-LEVEL EVALUATION OF STUDENT OUTCOMES</a></li>
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showCourseLevel) { ?>
                                    <li class="dropdown-header">EVALUATION OF CONTINUOUS IMPROVEMENT </li>
                                    <li><a href="p_clcimprvmnt.php">COURSE-LEVEL CONTINUOUS IMPROVEMENT (BY YEAR)</a></li>
                                    <li><a href="p_clcimprvmntbycourse.php">COURSE-LEVEL CONTINUOUS IMPROVEMENT (BY COURSE)</a></li>
                                <?php } ?>
                            </ul>
                        </li>
                    <?php } ?>

                    <!-- ABET Assessment Management Dropdown -->
                    <?php
                    $showMappings = hasAccessToSubmenuGroup('SO_PI_MAPPINGS');
                    $showAbetAssessments = hasAccessToSubmenuGroup('ABET_ASSESSMENTS_GROUP');
                    $showSyllabus = hasAccessToSubmenuGroup('SYLLABUS');

                    if ($showMappings || $showAbetAssessments || $showSyllabus) {
                        ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">
                                ASSESSMENT MANAGEMENT<span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <?php if ($showMappings) { ?>
                                    <li class="dropdown-header">SO & PI MAPPINGS</li>
                                    <li><a href="dept_so.php">STUDENT OUTCOMES</a></li>
                                    <li><a href="dept_pi.php">PERFORMANCE INDICATORS</a></li>
                                    <li><a href="dept_assmntrubrics.php">ASSESSMENT MASTER RUBRICS</a></li>
                                    <li><a href="dept_coursemapping.php">OVERALL SO/PI COURSE MAPPING</a></li>
                                    <li><a href="dept_coursemapping_diff.php">EVALUATION OF SO/PI MAPPING DISCREPANCIES</a></li>
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showAbetAssessments) { ?>
                                    <!--                            <li><a href="dept_cassmnt_cycle.php">COURSE ASSESSMENT CYCLE</a></li>-->
                                    <li class="dropdown-header">ASSESSMENTS</li>
                                    <li><a href="dept_abetcourses.php" class="red-link">COURSES TO BE ASSESSED</a></li>
                                    <li><a href="dept_collectcrsmaterials.php" class="red-link">COURSE MATERIALS TO BE COLLECTED</a></li>
                                    <li><a href="dept_abcevaluators.php" class="red-link">COURSES TO BE EVALUATED</a></li>
                                    <li><a href="dept_abcassistants.php">ASSIGN ASSISTANTS</a></li>
                                    <li><a href="dept_abetcourses_sopidiff.php">EVALUATION OF SO/PI ASSIGNMENT DISCREPANCIES</a></li>
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showAbetAssessments) { ?>
                                    <li class="dropdown-header">LINK COURSES</li>
                                    <li><a href="dept_abetcourses_linkabtcrses.php">LINK SERVICE COURSE TO DIFFERENT PROGRAMS (ONE TO MANY)</a></li>
                                    <li><a href="dept_abetcourses_linkabtcrses_diffnums.php">LINK CO-TAUGHT COURSES (MANY TO ONE)</a></li>
                                    <!--                                <li><a href="dept_abetcourses_linkavlcrses.php">LINK AVAILABLE COURSES (FOR MATERIAL COLLECTION)</a></li>-->
                                <?php } ?>
                            </ul>
                        </li>
                    <?php } ?>


                    <!-- Syllabus Management Dropdown -->
                    <?php
                    $showMappings = hasAccessToSubmenuGroup('SO_PI_MAPPINGS');
                    $showAbetAssessments = hasAccessToSubmenuGroup('ABET_ASSESSMENTS_GROUP');
                    $showSyllabus = hasAccessToSubmenuGroup('SYLLABUS');

                    if ($showMappings || $showAbetAssessments || $showSyllabus) {
                        ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">
                                SYLLABUS MANAGEMENT<span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">

                                <?php if ($showSyllabus) { ?>
                                    <li class="dropdown-header">MASTER COURSE SYLLABUS</li>
                                    <li><a href="dept_abetsyllabus_list.php">SYLLABUS SUMMARY LIST</a></li>
                                    <li><a href="dept_abetsyllabus.php">SYLLABUS INVENTORY</a></li>
                                    <li><a href="dept_abetsyllabus_desc_changes.php">COURSE DESCRIPTION CHANGES</a></li>
                                <?php } ?>
                            </ul>
                        </li>
                    <?php } ?>


                    <!-- Info Management Dropdown -->
                    <?php
                    $showInfoList = hasAccessToSubmenuGroup('INFO_LIST');
                    $showFacultyWorkloads = hasAccessToSubmenuGroup('FACULTY_WORKLOADS');
                    $showAVCourses = hasAccessToSubmenuGroup('AV_COURSES');

                    if ($showInfoList || $showFacultyWorkloads || $showAVCourses) {
                        ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">
                                INFO MANAGEMENT <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <?php if ($showInfoList) { ?>
                                    <li class="dropdown-header">INFO LIST</li>
                                    <li><a href="m_semesterinfo.php">SEMESTER LIST</a></li>
                                    <li><a href="m_academicyearinfo.php">ACADEMICYEAR LIST</a></li>
                                    <li><a href="m_programinfo.php">PROGRAM LIST</a></li>
                                    <li><a href="m_subjects.php">COURSE SUBJECT LIST</a></li>
                                    <li><a href="m_courses.php">ALL COURSE LIST</a></li>
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showFacultyWorkloads) { ?>
                                    <li class="dropdown-header">FACULTY WORKLOADS</li>
                                    <li><a href="m_fworkloads_byprms.php">FACULTY WORKLOADS BY PROGRAMS</a></li>
                                    <li><a href="m_fworkloads_bydepts.php">FACULTY WORKLOADS BY DEPARTMENTS</a></li>
                                    <li class="divider"></li>
                                <?php } ?>

                                <?php if ($showAVCourses) { ?>
                                    <li class="dropdown-header">AVAILABLE COURSES</li>
                                    <li><a href="m_avcourses.php">ALL AVAILABLE COURSES</a></li>
                                <?php } ?>
                            </ul>
                        </li>
                    <?php } ?>

                    <!-- System Management Dropdown -->
                    <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" aria-haspopup="true" aria-expanded="false">
                                SYSTEM MANAGEMENT <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="m_positioninfo.php">POSITION LIST</a></li>
                                <li><a href="m_affiliation.php">AFFILIATION LIST</a></li>
                                <li><a href="m_useraccount.php">USER ACCOUNT LIST</a></li>
                                <li><a href="m_menu_permissions.php">USER ACCESS PERMISSIONS</a></li>
                            </ul>
                        </li>
                    <?php } ?>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.navbar-collapse -->



        </div><!-- /.container-fluid -->
    </nav>



<?php
if (isset($_SESSION['RESET_PWD']) && $_SESSION['RESET_PWD'] === true) {
    echo "<script type='text/javascript'>
        document.addEventListener('DOMContentLoaded', function() {
            passwordreset();
        });
    </script>";
}

?>