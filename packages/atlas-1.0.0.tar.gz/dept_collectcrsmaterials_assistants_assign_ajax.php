<?php
/**
 * Assign Assistant to Abet Courses
 * Description: Assigning assistant to the selected abet courses
 * Author: Dong Hyun Jeong
 *
 * 09/21/2025 - initial version created
 *
 */

include_once 'session_handler.php';

$CourseIdx='';
$AssistantIdxes='';
$newlyChecked='';
$newlyUnchecked='';
if (array_key_exists('astntsidxes', $_POST)
    && array_key_exists('crsidx', $_POST)
    && array_key_exists('newlyChecked', $_POST)
    && array_key_exists('newlyUnchecked', $_POST))
{
    $AssistantIdxes = trim($_POST['astntsidxes']);
    $CourseIdx = trim($_POST['crsidx']);
    $newlyChecked = trim($_POST['newlyChecked']);
    $newlyUnchecked = trim($_POST['newlyUnchecked']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

if ($CourseIdx==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Process and format the newly checked and unchecked arrays
    $newlyCheckedArray = json_decode($newlyChecked, true);
    $newlyUncheckedArray = json_decode($newlyUnchecked, true);

    // Convert arrays to comma-separated lists
    $newlyCheckedList = !empty($newlyCheckedArray) ?
        implode(',', array_map('intval', $newlyCheckedArray)) : '';

    $newlyUncheckedList = !empty($newlyUncheckedArray) ?
        implode(',', array_map('intval', $newlyUncheckedArray)) : '';

    // Call the stored procedure
    $query = "CALL SP_Assign_Assistant_CollectCrsMaterials(?, ?, ?)";
    $params = [
        intval($CourseIdx),
        $newlyCheckedList,
        $newlyUncheckedList
    ];

    // Prepare and execute the procedure call
    $stmt = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    echo "0x11111111";
} catch (mysqli_sql_exception $e) {
    error_log($e->getMessage());   // Log DB error
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'ERROR',
        'message' => 'Database error occurred',
        'query' => $DBCONNECTION->FormatQuery($query, $params)
    ]);
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000x";
}
