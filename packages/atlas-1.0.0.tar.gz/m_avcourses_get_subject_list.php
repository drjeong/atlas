<?php
/**
 * Get Subject List API Endpoint
 *
 * Returns a JSON response containing the comma-separated list of subject names
 * from the database. This is used by the JavaScript to display which subjects
 * will be included when fetching available courses.
 *
 * Response Format:
 * {
 *     "success": true,
 *     "subjectList": "Biology, Chemistry, Mathematics, Physics"
 * }
 */

// Include required files
require_once('m_avcourses_fetch_parsecourses.php');

// Set JSON header
header('Content-Type: application/json');

try {
    // Get the subject list using the existing function
    $subjectList = GetSubjectInfoList();

    // Return success response
    echo json_encode([
        'success' => true,
        'subjectList' => $subjectList ? $subjectList : ''
    ]);

} catch (Exception $e) {
    // Return error response
    echo json_encode([
        'success' => false,
        'error' => 'Failed to retrieve subject list'
    ]);
}