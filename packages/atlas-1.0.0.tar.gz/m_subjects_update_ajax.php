<?php
/**
 * Management of Academic Degree Programs
 * Description: revising the selected course subject
 * Author: Dong Hyun Jeong
 *
 * 10/27/2024 - initial version created
 *
 */

include('checker_systemadmin.php');

$IDX = (isset($_POST['id'])) ? trim($_POST['id']) : '';
$Subject = (isset($_POST['sbjt'])) ? trim($_POST['sbjt']) : '';
$DepartmentNameCode = (isset($_POST['dept'])) ? trim($_POST['dept']) : '';

if ($IDX=="" || $Subject=="" || $DepartmentNameCode==""){
	echo "0x00000011";
	exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $IDX = filter_var($IDX, FILTER_VALIDATE_INT);
    if ($IDX === false) {
        throw new Exception('Invalid Index format');
    }
    $DepartmentNameCode = filter_var($DepartmentNameCode, FILTER_VALIDATE_INT);
    if ($DepartmentNameCode === false) {
        throw new Exception('Invalid Index format');
    }

    // convert unwanted escape strings
    $Subject = $DBCONNECTION->real_escape_string($Subject);

    /////////////////////////////////////////////////////////////////////////////////
    // insert PI
    $query = "CALL SP_UpdateSubject(?, ?, ?);";
    $params = [$IDX, $Subject, $DepartmentNameCode];
    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00200011') !== false) {
        echo '0x00200011';  // same item exists already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500',
            'query' => $DBCONNECTION->FormatQuery($query, $params)
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
