<?php
/**
 * Management of User Accounts
 * Description: adding an user
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 */

include('checker_systemadmin.php');


$_Name = (isset($_POST['name'])) ? trim($_POST['name']) : '';
$_Email = (isset($_POST['email'])) ? trim($_POST['email']) : '';
$_Position = (isset($_POST['pos'])) ? trim($_POST['pos']) : '';
$_Affiliation = (isset($_POST['aff'])) ? trim($_POST['aff']) : '';
$_AccessControl = (isset($_POST['acc'])) ? trim($_POST['acc']) : '';

if ($_Email==""|| $_Position=='' || $_Affiliation==''){
	echo "0x00000011"; 
	exit;
}


//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    $PWD=crypt(gettimeofday(true),'st'); // randomly generate temporary passowrd
    $PWD_Encrypted = hash('sha256', $PWD);

    $_Position = filter_var($_Position, FILTER_VALIDATE_INT);
    if ($_Position === false) {
        throw new Exception('Invalid Index format');
    }
    $_Affiliation = filter_var($_Affiliation, FILTER_VALIDATE_INT);
    if ($_Affiliation === false) {
        throw new Exception('Invalid Index format');
    }

    // convert unwanted escape strings
    $_Name = $DBCONNECTION->real_escape_string($_Name);
    $_Email = $DBCONNECTION->real_escape_string($_Email);

    /////////////////////////////////////////////////////////////////////////////////
    // insert item
    $query = "CALL SP_AddUserAccount(?, ?, ?, ?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query,
        [$_Name, $PWD_Encrypted, $_Email, $_Position, $_Affiliation, $_AccessControl]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00200011') !== false) {
        echo '0x00200011';  // same item exists already
    }
    else if (strpos($errorMessage, '0x00200012') !== false) {
        echo '0x00200012';  // same item exists already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
