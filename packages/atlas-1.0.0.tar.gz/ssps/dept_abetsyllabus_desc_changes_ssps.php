<?php
/**
 * Listing Course Description Changes
 * Description: listing all courses if they have changes in the course descriptions
 *
 *
 *
 */
include_once 'session_handler.php';

require_once(__DIR__ . '/../../config.php');

// DB table to use
$table = 'AbetSyllabus';

// Base join query without WHERE clause - now includes previous version
$joinQuery = "FROM `{$table}` AS `ABS` 
LEFT JOIN `Courses` AS `CS` ON (`CS`.`Idx`=`ABS`.`CourseIndex`)
LEFT JOIN (
    SELECT 
        `CourseIndex`,
        `AcademicProgram`,
        `Description` AS `PrevDescription`,
        `major_version` AS `PrevMajorVersion`,
        `minor_version` AS `PrevMinorVersion`,
        `Pre_requisites` AS `PrevPreRequisites`,
        `Co_requisites` AS `PrevCoRequisites`,
        `Required_Texts` AS `PrevRequiredTexts`,
        `Coordinator` AS `PrevCoordinator`,
        `Requirement` AS `PrevRequirement`
    FROM `{$table}`
) AS `PREV` ON (
    `PREV`.`CourseIndex` = `ABS`.`CourseIndex`
    AND `PREV`.`AcademicProgram` = `ABS`.`AcademicProgram`
    AND (
        (`PREV`.`PrevMajorVersion` = `ABS`.`major_version` - 1 
         AND NOT EXISTS (
            SELECT 1 FROM `{$table}` AS `mid`
            WHERE `mid`.`CourseIndex` = `ABS`.`CourseIndex`
            AND `mid`.`AcademicProgram` = `ABS`.`AcademicProgram`
            AND `mid`.`major_version` = `ABS`.`major_version` - 1
            AND `mid`.`minor_version` > `PREV`.`PrevMinorVersion`
         )
         AND NOT EXISTS (
            SELECT 1 FROM `{$table}` AS `mid`
            WHERE `mid`.`CourseIndex` = `ABS`.`CourseIndex`
            AND `mid`.`AcademicProgram` = `ABS`.`AcademicProgram`
            AND `mid`.`major_version` > `PREV`.`PrevMajorVersion`
            AND `mid`.`major_version` < `ABS`.`major_version`
         ))
        OR 
        (`PREV`.`PrevMajorVersion` = `ABS`.`major_version`
         AND `PREV`.`PrevMinorVersion` < `ABS`.`minor_version`
         AND NOT EXISTS (
            SELECT 1 FROM `{$table}` AS `mid`
            WHERE `mid`.`CourseIndex` = `ABS`.`CourseIndex`
            AND `mid`.`AcademicProgram` = `ABS`.`AcademicProgram`
            AND `mid`.`major_version` = `ABS`.`major_version`
            AND `mid`.`minor_version` > `PREV`.`PrevMinorVersion`
            AND `mid`.`minor_version` < `ABS`.`minor_version`
         ))
    )
)";

// Table's primary key
$primaryKey = '`CS`.`Idx`';

// Array of database columns
$columns = array(
    array('db' => '`CS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId',
        'formatter' => function( $d, $row ) {
            return 'row_'.$d;
        }
    ),
    array( 'db' => '`CS`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => 'CONCAT(`ABS`.`major_version`, \'.\', `ABS`.`minor_version`)',
        'dt' => 'Version', 'field' => 'Version', 'as' => 'Version'),
    array( 'db' => 'CONCAT(`PREV`.`PrevMajorVersion`, \'.\', `PREV`.`PrevMinorVersion`)',
        'dt' => 'PrevVersion', 'field' => 'PrevVersion', 'as' => 'PrevVersion'),
    array( 'db' => '`CS`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`CS`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`CS`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`CS`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`ABS`.`Description`', 'dt' => 'Description', 'field' => 'Description', 'as' => 'Description'),
    array( 'db' => '`PREV`.`PrevDescription`', 'dt' => 'PrevDescription', 'field' => 'PrevDescription', 'as' => 'PrevDescription'),
    array( 'db' => 'CASE WHEN `PREV`.`PrevDescription` IS NULL THEN NULL
                        WHEN `ABS`.`Description` != `PREV`.`PrevDescription` THEN 1
                        ELSE 0 END',
        'dt' => 'DescriptionChanged', 'field' => 'DescriptionChanged', 'as' => 'DescriptionChanged'),
    array( 'db' => '`ABS`.`Pre_requisites`', 'dt' => 'Pre_requisites', 'field' => 'Pre_requisites', 'as' => 'Pre_requisites'),
    array( 'db' => '`PREV`.`PrevPreRequisites`', 'dt' => 'PrevPreRequisites', 'field' => 'PrevPreRequisites', 'as' => 'PrevPreRequisites'),
    array( 'db' => 'CASE WHEN `PREV`.`PrevPreRequisites` IS NULL THEN NULL
                        WHEN COALESCE(`ABS`.`Pre_requisites`, \'\') != COALESCE(`PREV`.`PrevPreRequisites`, \'\') THEN 1
                        ELSE 0 END',
        'dt' => 'PreRequisitesChanged', 'field' => 'PreRequisitesChanged', 'as' => 'PreRequisitesChanged'),
    array( 'db' => '`ABS`.`Co_requisites`', 'dt' => 'Co_requisites', 'field' => 'Co_requisites', 'as' => 'Co_requisites'),
    array( 'db' => '`PREV`.`PrevCoRequisites`', 'dt' => 'PrevCoRequisites', 'field' => 'PrevCoRequisites', 'as' => 'PrevCoRequisites'),
    array( 'db' => 'CASE WHEN `PREV`.`PrevCoRequisites` IS NULL THEN NULL
                        WHEN COALESCE(`ABS`.`Co_requisites`, \'\') != COALESCE(`PREV`.`PrevCoRequisites`, \'\') THEN 1
                        ELSE 0 END',
        'dt' => 'CoRequisitesChanged', 'field' => 'CoRequisitesChanged', 'as' => 'CoRequisitesChanged'),
    array( 'db' => '`ABS`.`Required_Texts`', 'dt' => 'Required_Texts', 'field' => 'Required_Texts', 'as' => 'Required_Texts'),
    array( 'db' => '`PREV`.`PrevRequiredTexts`', 'dt' => 'PrevRequiredTexts', 'field' => 'PrevRequiredTexts', 'as' => 'PrevRequiredTexts'),
    array( 'db' => 'CASE WHEN `PREV`.`PrevRequiredTexts` IS NULL THEN NULL
                        WHEN COALESCE(`ABS`.`Required_Texts`, \'\') != COALESCE(`PREV`.`PrevRequiredTexts`, \'\') THEN 1
                        ELSE 0 END',
        'dt' => 'RequiredTextsChanged', 'field' => 'RequiredTextsChanged', 'as' => 'RequiredTextsChanged'),
    array( 'db' => '`ABS`.`Idx`', 'dt' => 'ABSIdx', 'field' => 'ABSIdx', 'as' => 'ABSIdx'),
    array( 'db' => '`ABS`.`Coordinator`', 'dt' => 'Coordinator', 'field' => 'Coordinator', 'as' => 'Coordinator'),
    array( 'db' => '`PREV`.`PrevCoordinator`', 'dt' => 'PrevCoordinator', 'field' => 'PrevCoordinator', 'as' => 'PrevCoordinator'),
    array( 'db' => 'CASE WHEN `PREV`.`PrevCoordinator` IS NULL THEN NULL
                        WHEN COALESCE(`ABS`.`Coordinator`, \'\') != COALESCE(`PREV`.`PrevCoordinator`, \'\') THEN 1
                        ELSE 0 END',
        'dt' => 'CoordinatorChanged', 'field' => 'CoordinatorChanged', 'as' => 'CoordinatorChanged'),
    array( 'db' => 'CASE WHEN (`ABS`.`Description` IS NOT NULL AND `ABS`.`ApprovalDate` IS NULL) THEN \'Need Approval\' ELSE \'\' END',
        'dt' => 'NeedApproval', 'field' => 'NeedApproval', 'as' => 'NeedApproval'),
    array( 'db' => '`ABS`.`Requirement`', 'dt' => 'Requirement', 'field' => 'Requirement', 'as' => 'Requirement'),
    array( 'db' => '`PREV`.`PrevRequirement`', 'dt' => 'PrevRequirement', 'field' => 'PrevRequirement', 'as' => 'PrevRequirement'),
    array( 'db' => 'CASE WHEN `PREV`.`PrevRequirement` IS NULL THEN NULL
                        WHEN COALESCE(`ABS`.`Requirement`, \'\') != COALESCE(`PREV`.`PrevRequirement`, \'\') THEN 1
                        ELSE 0 END',
        'dt' => 'RequirementChanged', 'field' => 'RequirementChanged', 'as' => 'RequirementChanged'),
    array( 'db' => '`ABS`.`RevisionDate`', 'dt' => 'RevisionDate', 'field' => 'RevisionDate', 'as' => 'RevisionDate'),
    array( 'db' => '`ABS`.`RevisionDesc`', 'dt' => 'RevisionDesc', 'field' => 'RevisionDesc', 'as' => 'RevisionDesc'),
    array( 'db' => '`ABS`.`ApprovalDate`', 'dt' => 'ApprovalDate', 'field' => 'ApprovalDate', 'as' => 'ApprovalDate'),
    array( 'db' => 'CASE 
                        WHEN `PREV`.`PrevDescription` IS NULL THEN 0
                        WHEN (
                            `ABS`.`Description` != `PREV`.`PrevDescription`
                            OR COALESCE(`ABS`.`Pre_requisites`, \'\') != COALESCE(`PREV`.`PrevPreRequisites`, \'\')
                            OR COALESCE(`ABS`.`Co_requisites`, \'\') != COALESCE(`PREV`.`PrevCoRequisites`, \'\')
                            OR COALESCE(`ABS`.`Required_Texts`, \'\') != COALESCE(`PREV`.`PrevRequiredTexts`, \'\')
                            OR COALESCE(`ABS`.`Coordinator`, \'\') != COALESCE(`PREV`.`PrevCoordinator`, \'\')
                            OR COALESCE(`ABS`.`Requirement`, \'\') != COALESCE(`PREV`.`PrevRequirement`, \'\')
                        ) THEN 1
                        ELSE 0 
                    END',
        'dt' => 'HasChanges', 'field' => 'HasChanges', 'as' => 'HasChanges')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );

$extraWhere = "`ABS`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";

// Only get the latest version of each course
$extraWhere .= " AND NOT EXISTS (
    SELECT 1
    FROM AbetSyllabus AS sub
    WHERE sub.CourseIndex = ABS.CourseIndex
    AND sub.AcademicProgram = ABS.AcademicProgram
    AND (
        sub.major_version > ABS.major_version
        OR (
            sub.major_version = ABS.major_version
            AND sub.minor_version > ABS.minor_version
        )
    )
)";

// Only show courses that have changes (optional - remove if you want to see all courses)
// Uncomment the line below if you only want to show courses with changes
// $extraWhere .= " AND `PREV`.`PrevDescription` IS NOT NULL";

$groupBy = '';

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);