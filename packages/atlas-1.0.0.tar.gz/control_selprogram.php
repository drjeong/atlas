<!--                    Displaying extra menu-->
<?php
require_once(__DIR__ . '/php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();
$Query = "SELECT `Idx`, `Name` FROM `AcademicPrograms` ORDER BY `Name`;";
$DBCONNECTION->sendquery($Query);

$url =  "//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
$escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

?>
        <form name='changefrm' action='<?php echo($escaped_url);?>' method='post'>
            <div class="container">
                <div class="row">
                    <div class="col-md-12" style="display: flex; justify-content: center;">
                        <div class="input-group label-primary" style="width: 600px;">
                            <label class="label-primary input-group-addon" style="color:white;font-weight: bold;" for="CH_APR">CONTROL GRANTED PROGRAM:</label>
                            <select name="CH_APR" id="CH_APR" class="input-sm form-control" onchange="document.changefrm.submit();" required style="color: gray;">
                                <option value="" disabled selected hidden style="color: gray;">Please select a program</option>
                                <?php
                                while ($row = $DBCONNECTION->fetch_assoc()) {
                                    $AcademicProgramIdx = $row['Idx'];

                                    $Selected = '';
                                    if ($AcademicProgramIdx == $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'])
                                        $Selected = 'selected';

                                    if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$AcademicProgramIdx])) {
                                        echo("<option value='$AcademicProgramIdx' style='font-size:10pt;' $Selected>". $row['Name'] . "</option>");
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </form>

<?php
unset($DBCONNECTION);


