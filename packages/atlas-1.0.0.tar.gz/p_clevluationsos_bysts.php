<?php
/**
 * Evaluation of Student Outcomes
 * File: p_evluationsos.php
 * Description: Listing evaluation of student outcomes.
 */
?>

<?php
include('header.php');

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection(false);

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}
?>

    <script type="text/javascript">
        $(document).ready(function() {
            // Add event listener to the select element
            $("#_AY").on('change', function() {
                document.academicyear.submit();
            });
        });
    </script>

    <div class="pagebacklayout">
        <div class="row">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSE-LEVEL EVALUATION OF STUDENT OUTCOMES</span></p>
            <p style="text-align:center;font-size:13px;color:#0c5460;margin-top:5px;padding:10px;background-color:#d1ecf1;border-left:4px solid #17a2b8;font-style:italic;">
                <strong>Note:</strong> Average score is calculated as the sum of all students' scores divided by the <span style="color:#d9534f;font-weight:bold;">total number of students</span>.
            </p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <?php include('control_allprograms.php'); ?>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:30%;">
                        <?php echo($AcademicYearSelection);?>
                    </td>
                    <td style="width:10%"></td>
                    <td style="width:60%; text-align: right">
                    </td>
                </tr>
            </table>

            <?php
            require_once(__DIR__ . '/php_include/dbconnection_class.php');

            $DBCONNECTION = new Dbconnection();

            $AbetCourseAvailable = false;
            $Query = "CALL SP_ChkAbetCourses( '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."', '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' )";
            if ($DBCONNECTION->gettotalcount($Query) > 0)
                $AbetCourseAvailable = true;

            if ($AbetCourseAvailable === false){
                echo <<<HTML
        <div class='col-md-12'>
            <div class="alert alert-info text-center" role="alert" style="padding: 40px; margin: 20px 0;">
                <h4 class="alert-heading">No ABET Courses Available</h4>
                <p class="mb-0">There are currently no ABET courses available for the selected academic year and program.</p>
                <hr>
                <p class="mb-0">Please select a different academic year or contact your administrator if you believe this is an error.</p>
            </div>
        </div>
HTML;
            } else {
                require_once(__DIR__ . '/ssps/StudentOutcomeAnalyzer.php');

                /////////////////////////////////////////////////////////////////////////////////
                // Fetch all ABET courses for the selected academic year and program
                $academicYearIdx = intval($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);
                $programIdx = intval($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);

                $query = "
                SELECT DISTINCT
                    ABETCRSES.Idx AS AbetCourseIdx,
                    ABETCRSES.AVCourseIdx AS AvailableCourseIdx,
                    AVCRSES.CourseNo,
                    AVCRSES.Title,
                    AVCRSES.Credits,
                    AVCRSES.Instructor,
                    AVCRSES.Semester
                FROM `AbetCourses` AS `ABETCRSES`
                INNER JOIN `AcademicYears` AS `AYS` ON (ABETCRSES.AcademicYear = AYS.Idx)
                INNER JOIN `AVCourses` AS `AVCRSES` ON (
                    AYS.`From` <= AVCRSES.Semester
                    AND AYS.`To` >= AVCRSES.Semester
                    AND ABETCRSES.AVCourseIdx = AVCRSES.Idx
                )
                WHERE ABETCRSES.AcademicProgram = ?
                  AND ABETCRSES.AcademicYear = ?
                ORDER BY AVCRSES.CourseNo, AVCRSES.Semester, AVCRSES.Instructor
            ";
                $result = $DBCONNECTION->prepare_execute_catch_error($query, [$programIdx, $academicYearIdx]);

                $abetCourses = array();
                if ($result && $DBCONNECTION->num_rows() > 0) {
                    while ($row = $DBCONNECTION->fetch_assoc()) {
                        $abetCourses[] = $row;
                    }
                }

                // Initialize the analyzer
                $analyzer = new StudentOutcomeAnalyzer($DBCONNECTION);

                // Process each course and get student-level analysis
                $data_array = array();
                $hasData = false;

                foreach ($abetCourses as $course) {
                    $AVCIdx = $course['AvailableCourseIdx'];
                    $AbetCourseIdx = $course['AbetCourseIdx'];

                    // Get all mapped student outcomes for this ABET course using the specified query
                    $soQuery = "
                    SELECT `STNTOUTCMS`.Idx AS SOIdx,
                        `STNTOUTCMS`.SO AS SO
                    FROM `AbetCourses` AS `ABETCRSES`
                        INNER JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABETCRSES`.`Idx`=`ABETCRSES_SOS`.`AbetCourseIdx`)
                        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`ABETCRSES_SOS`.`SOIdx`=`STNTOUTCMS`.`Idx`)
                    WHERE `STNTOUTCMS`.AcademicProgram = ?
                        AND `STNTOUTCMS`.AcademicYear = ?
                        AND `ABETCRSES_SOS`.AbetCourseIdx = ?
                    ORDER BY `STNTOUTCMS`.SO
                ";
                    $soResult = $DBCONNECTION->prepare_execute_catch_error($soQuery, [$programIdx, $academicYearIdx, $AbetCourseIdx]);

                    $mappedSOs = array();
                    if ($soResult && $DBCONNECTION->num_rows() > 0) {
                        while ($soRow = $DBCONNECTION->fetch_assoc()) {
                            $mappedSOs[$soRow['SOIdx']] = $soRow['SO'];
                        }
                    }

                    // Get analysis data
                    $analysisData = $analyzer->getAnalysis(
                            $AbetCourseIdx,
                            $AVCIdx,
                            $programIdx,
                            true
                    );

                    // Create a lookup for analysis data by SO
                    $analysisLookup = array();
                    if (!empty($analysisData)) {
                        foreach ($analysisData as $soData) {
                            $analysisLookup[$soData['SOIdx']] = $soData;
                        }
                    }

                    // Only process if we have mapped SOs
                    if (!empty($mappedSOs)) {
                        $hasData = true;

                        // Initialize course data if not exists
                        if (!isset($data_array[$AVCIdx])) {
                            $data_array[$AVCIdx] = array(
                                    "ABCIdx" => $AbetCourseIdx,
                                    "CourseNo" => $course['CourseNo'],
                                    "Credits" => $course['Credits'],
                                    "Title" => $course['Title'],
                                    "Instructor" => $course['Instructor'],
                                    "Semester" => $course['Semester'],
                                    "StudentOutcomes" => array()
                            );
                        }

                        // Process each mapped SO
                        foreach ($mappedSOs as $soIdx => $soName) {
                            if (isset($analysisLookup[$soIdx])) {
                                // We have data for this SO
                                $soData = $analysisLookup[$soIdx];
                                $totalStudents = $soData['TOTAL'];

                                $avgScore = ($totalStudents > 0) ? $soData['AVG'] : 0.0;
                                $topFiftyPercent = ($totalStudents > 0) ? ($soData['TOPFIFTY'] / $totalStudents) * 100 : 0.0;
                                $topTwentyFivePercent = ($totalStudents > 0) ? ($soData['TOPTWENTYFIVE'] / $totalStudents) * 100 : 0.0;

                                $data_array[$AVCIdx]["StudentOutcomes"][] = array(
                                        "SO" => $soName,
                                        "AVG" => sprintf('%.2f', $avgScore),
                                        "TOPFIFTY" => sprintf('%.2f', $topFiftyPercent),
                                        "TOPTWENTYFIVE" => sprintf('%.2f', $topTwentyFivePercent),
                                        "TOTAL_STUDENTS" => $totalStudents
                                );
                            } else {
                                // No data for this SO - show zeros
                                $data_array[$AVCIdx]["StudentOutcomes"][] = array(
                                        "SO" => $soName,
                                        "AVG" => '0.00',
                                        "TOPFIFTY" => '0.00',
                                        "TOPTWENTYFIVE" => '0.00',
                                        "TOTAL_STUDENTS" => 0
                                );
                            }
                        }
                    }
                }

                if (!$hasData || empty($data_array)) {
                    echo <<<HTML
        <div class='col-md-12'>
            <div class="alert alert-warning text-center" role="alert" style="padding: 30px; margin: 20px 0;">
                <h4 class="alert-heading">No Course-Level Evaluation Data Available</h4>
                <p class="mb-0">There are currently no course-level evaluation results for the selected academic year and program.</p>
            </div>
        </div>
HTML;
                } else {
                    echo <<<HTML
        <div class='col-md-12'>
            <!-- Page Content -->
            <div id="pagebacklayout_inner_noborder">
                <div class="CSSTable_ROUNDEDCORDER">
                    <table class="display">
                    <thead>
                        <tr>
                            <th style="height:50px;">COURSE INFO</th>
                            <th style="height:50px;">STUDENT OUTCOME</th>
                            <th>AVERAGE SCORE</th>
                            <th>% >= 2 (Developing)</th>
                            <th>% >= 3 (Satisfactory)</th>
                        </tr>                    
                    </thead>
                    <tbody>
HTML;
                    require_once (__DIR__ . '/php_include/semester_helpers.php');

                    $background_color = '#efefef';
                    foreach ($data_array as $AVCIdx => $Data) {
                        $CourseNo = $Data['CourseNo'];
                        $Credits = $Data['Credits'];
                        $Title = $Data['Title'];
                        $Instructor = $Data['Instructor'];
                        $Semester = $Data['Semester'];
                        $semesterDisplay = getBannerSemesterText($Data['Semester']);

                        $StudentOutcomes = $Data['StudentOutcomes'];
                        $SOCnt = count($StudentOutcomes);

                        if ($SOCnt == 0) continue; // no data to show

                        $firstRow = true;
                        foreach ($StudentOutcomes as $outcome) {
                            if ($firstRow) {
                                echo <<<HTML
                        <tr style="border-spacing: 3px; background-color:$background_color">
                            <td rowspan="$SOCnt" style="width:40%;">
                                $CourseNo $Title ($semesterDisplay), Instructor: $Instructor
                            </td>
                            <td style="width:15%; text-align: center">{$outcome['SO']}</td>
                            <td style="width:15%; text-align: center">{$outcome['AVG']}</td>
                            <td style="width:15%; text-align: center">{$outcome['TOPFIFTY']}%</td>
                            <td style="width:15%; text-align: center">{$outcome['TOPTWENTYFIVE']}%</td>
                        </tr>
HTML;
                                $firstRow = false;
                            } else {
                                echo <<<HTML
                        <tr style="background-color:$background_color">
                            <td style="width:15%; text-align: center">{$outcome['SO']}</td>
                            <td style="width:15%; text-align: center">{$outcome['AVG']}</td>
                            <td style="width:15%; text-align: center">{$outcome['TOPFIFTY']}%</td>
                            <td style="width:15%; text-align: center">{$outcome['TOPTWENTYFIVE']}%</td>
                        </tr>
HTML;
                            }
                        }

                        $background_color = ($background_color == '#efefef') ? '#ffffff' : '#efefef';
                    }
                    echo <<<HTML
                    </tbody>
                    </table>
                </div>
                <!-- /#page-content-wrapper -->
            </div>
        </div>
HTML;
                }
            }
            ?>

        </div>
    </div>

<?php include('footer.php');?>