
function showDuplicateDialog(options) {
	const {
		title,
		warningMessage = 'Please use with caution when duplicating. If not sure, please contact the system administrator.',
		yearFrom = '',
		yearTo = '',
		performDuplication
	} = options;

	const formContent = `
        <form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div style="color:blue; font-weight:bold;">${warningMessage}</div>
            <table style="border-spacing:0; padding:0; width:100%;">
                <tr><td colspan="2"><div class="input-group" style="width:100%">
                    <div class="input-group" style="width:100%">
                        <span class="input-group-addon" style="width:250px;">Duplicate From - Academic Year<span style="color:red">*</span></span>
                        <select name="_AYF" id="_AYF" class="input-sm form-control"><option value=""></option></select>
                    </div>
                    <div class="input-group" style="width:100%">
                        <span class="input-group-addon" style="width:250px;">Duplicate To - Academic Year<span style="color:red">*</span></span>
                        <select name="_AYT" id="_AYT" class="input-sm form-control"><option value=""></option></select>
                    </div>
                </div></td></tr>
            </table>
        </form>`;

	createModalDialog({
		title: `<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">${title}</span>`,
		message: formContent,
		buttons: {
			ok: {
				label: "<span class='glyphicon glyphicon-ok'></span> DUPLICATE",
				className: 'btn-success',
				callback: function() {
					const popupForm = document.getElementById('popupfrm');
					if (popupForm._AYF.value.isEmpty()) {
						popupForm._AYF.focus();
						Swal.fire({title:"ERROR", text: "Academic Year From information is not selected!!", icon:"error"});
						return false;
					}
					if (popupForm._AYT.value.isEmpty()) {
						popupForm._AYT.focus();
						Swal.fire({title:"ERROR", text: "Academic Year To information is not selected!!", icon:"error"});
						return false;
					}
					if (popupForm._AYF.value === popupForm._AYT.value) {
						popupForm._AYF.focus();
						Swal.fire({title:"ERROR", text: "Academic Year From & To information cannot be the same!!", icon:"error"});
						return false;
					}

					performDuplication(popupForm._AYF.value, popupForm._AYT.value);
				}
			},
			cancel: {
				label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
				className: 'btn-default'
			}
		}
	}).on('shown.bs.modal', function() {
		AsyncGetOptions(1)
			.then(data => {
				const selectYearFrom = document.getElementById('_AYF');
				const selectYearTo = document.getElementById('_AYT');

				data.inProgram.forEach(option => {
					const optElement = document.createElement('option');
					optElement.value = option.value;
					optElement.textContent = option.text;
					selectYearFrom.appendChild(optElement);
				});

				data.notInProgram.forEach(option => {
					const optElement = document.createElement('option');
					optElement.value = option.value;
					optElement.textContent = option.text;
					selectYearTo.appendChild(optElement);
				});

				if (!yearFrom.isEmpty()) selectYearFrom.value = yearFrom;
				if (!yearTo.isEmpty()) selectYearTo.value = yearTo;
			})
			.catch(error => {
				console.error('Error loading academic years:', error);
				Swal.fire({
					title: "ERROR",
					text: "Failed to load academic year options",
					icon: "error"
				});
			});
	});
}