<?php
/**
 * Listing abet courses
 * File: dept_collectcrsmaterials_ssps.php
 * Description: listing abet courses to collect course materials
 *
 * 04/07/2025 Initial version is created
 * 08/09/2026 Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */


include_once 'session_handler.php';
$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// the following is used for administrator
if (array_key_exists('_DEPT', $_GET)) {
    $_SESSION['ATLAS_SELECTED_DEPARTMENT'] = trim($_GET['_DEPT']);
}

// DB table to use
$table = 'AVCourses';
$joinQuery = " FROM `AVCourses` AS `AVCRSES`
    INNER JOIN `AcademicYears` AS `AYS` ON (`AVCRSES`.`Semester` BETWEEN `AYS`.`From` AND `AYS`.`To`)
    INNER JOIN `Subjects` AS `SBJTS` ON (`SBJTS`.`Name`=`AVCRSES`.`Subject`)
    LEFT JOIN `Semesters` AS `SMSTRS` ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
    LEFT JOIN `AVCourses_Assistants` AS `AVCRSES_ASSNTS` ON (`AVCRSES`.`Idx`=`AVCRSES_ASSNTS`.`AVCourseIdx`)
    LEFT JOIN `UserAccounts` AS `UA` ON (`AVCRSES_ASSNTS`.`Assistant`=`UA`.`Idx`)";

// Table's primary key
$primaryKey = '`AVCRSES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
$columns = array(
    array('db' => '`AVCRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`AVCRSES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => '`SMSTRS`.`Explanation`', 'dt' => 'SemesterTxt', 'field' => 'SemesterTxt', 'as' => 'SemesterTxt'),
    array( 'db' => '`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => '`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`Section`', 'dt' => 'Section', 'field' => 'Section', 'as' => 'Section'),
    array( 'db' => '`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`Days`', 'dt' => 'Days', 'field' => 'Days', 'as' => 'Days'),
    array( 'db' => '`Times`', 'dt' => 'Times', 'field' => 'Times', 'as' => 'Times'),
    array(
        'db' => '`Instructor`',
        'dt' => 'Instructor',
        'field' => 'Instructor',
        'as' => 'Instructor'
    ),
    array(
        'db' => 'IF(COUNT(`UA`.`Idx`) > 0, GROUP_CONCAT(NULLIF(`UA`.`Idx`, \'\') SEPARATOR \', \'), NULL)',
        'dt' => 'Assistants',
        'field' => 'Assistants',
        'as' => 'Assistants',
        'searchable' => false
    ),
    array(
        'db' => 'IF(COUNT(`UA`.`Idx`) > 0, GROUP_CONCAT(NULLIF(`UA`.`Name`, \'\') SEPARATOR \', \'), NULL)',
        'dt' => 'AssistantNames',
        'field' => 'AssistantNames',
        'as' => 'AssistantNames'
    )
);

require('ssp.join.class.php');

$extraWhere = "`AVCRSES`.`CollectMaterials` = 1";

if (isset($_SESSION['ATLAS_SELECTED_DEPARTMENT'])) {
    $extraWhere .= " AND `SBJTS`.`Department` = '".$_SESSION['ATLAS_SELECTED_DEPARTMENT']."'";
}

if ($AcademicYear != "" && $AcademicYear != "all") {
    $extraWhere .= " AND `AYS`.`Idx`='".$AcademicYear."'";
}

// Set the GROUP BY clause
$groupBy = "`AVCRSES`.`Idx`";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery($_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

