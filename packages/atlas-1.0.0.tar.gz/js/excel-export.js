/**
 * Excel Export Library with Styling Support
 * Uses ExcelJS to export HTML tables to Excel with colors, merges, and formatting
 *
 * @requires ExcelJS library
 * @version 1.0
 * @date 06/11/2026
 */

(function(window) {
    'use strict';

    /**
     * Export HTML table to Excel with full styling support
     * @param {string} tableID - The ID of the HTML table to export
     * @param {string} filename - The desired filename (without extension)
     * @param {object} options - Optional configuration
     * @returns {Promise<void>}
     */
    async function exportTableToExcel(tableID, filename = 'export', options = {}) {
        // Default options
        const config = {
            sheetName: 'Sheet1',
            rowHeight: 20,
            maxColWidth: 50,
            minColWidth: 10,
            includeColors: true,
            includeBorders: true,
            ...options
        };

        const table = document.getElementById(tableID);

        if (!table) {
            console.error(`Table with ID "${tableID}" not found`);
            return;
        }

        // Check if ExcelJS is loaded
        if (typeof ExcelJS === 'undefined') {
            console.error('ExcelJS library is not loaded. Please include it before using this function.');
            return;
        }

        // Create a new workbook
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet(config.sheetName);

        // Helper function to convert RGB to hex
        const rgbToHex = (rgb) => {
            if (!rgb || rgb === 'rgba(0, 0, 0, 0)' || rgb === 'transparent') return null;
            const match = rgb.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)/);
            if (!match) return null;
            const hex = (x) => ("0" + parseInt(x).toString(16)).slice(-2);
            return hex(match[1]) + hex(match[2]) + hex(match[3]);
        };

        // Get all rows
        const rows = table.querySelectorAll('tr');

        // Track merged cells to skip them when processing
        const mergedCells = new Set();

        // First pass: collect all data and merge information
        const tableData = [];
        const mergeRanges = [];

        rows.forEach((row, rowIndex) => {
            const cells = row.querySelectorAll('td, th');
            const rowData = [];
            let colOffset = 0;

            cells.forEach((cell) => {
                // Find the actual column index considering merged cells
                while (mergedCells.has(`${rowIndex},${colOffset}`)) {
                    rowData.push(''); // Fill skipped cells with empty string
                    colOffset++;
                }

                const colspan = parseInt(cell.getAttribute('colspan')) || 1;
                const rowspan = parseInt(cell.getAttribute('rowspan')) || 1;

                // Add the cell value
                rowData.push(cell.textContent.trim());

                // If this cell has colspan or rowspan, record the merge
                if (colspan > 1 || rowspan > 1) {
                    const startRow = rowIndex + 1; // ExcelJS uses 1-based indexing
                    const startCol = colOffset + 1;
                    const endRow = rowIndex + rowspan;
                    const endCol = colOffset + colspan;

                    mergeRanges.push({
                        startRow,
                        startCol,
                        endRow,
                        endCol,
                        cell: cell
                    });

                    // Mark all cells in the merge range as occupied
                    for (let r = rowIndex; r < rowIndex + rowspan; r++) {
                        for (let c = colOffset; c < colOffset + colspan; c++) {
                            if (r !== rowIndex || c !== colOffset) {
                                mergedCells.add(`${r},${c}`);
                            }
                        }
                    }
                }

                // Fill empty cells for colspan
                for (let i = 1; i < colspan; i++) {
                    rowData.push('');
                    colOffset++;
                }

                colOffset++;
            });

            tableData.push({
                data: rowData,
                cells: Array.from(cells)
            });
        });

        // Second pass: add data to worksheet
        tableData.forEach((rowInfo, rowIndex) => {
            const excelRow = worksheet.addRow(rowInfo.data);

            // Apply styling to each cell
            let colIndex = 0;
            rowInfo.cells.forEach((cell) => {
                // Skip merged cells
                while (mergedCells.has(`${rowIndex},${colIndex}`) && !cell.hasAttribute('colspan') && !cell.hasAttribute('rowspan')) {
                    colIndex++;
                }

                const excelCell = excelRow.getCell(colIndex + 1);
                applyCellStyle(excelCell, cell, config);

                const colspan = parseInt(cell.getAttribute('colspan')) || 1;
                colIndex += colspan;
            });

            // Set row height
            excelRow.height = config.rowHeight;
        });

        // Apply all merges
        mergeRanges.forEach(range => {
            worksheet.mergeCells(range.startRow, range.startCol, range.endRow, range.endCol);

            // Apply styling to the merged cell
            const mergedCell = worksheet.getCell(range.startRow, range.startCol);
            applyCellStyle(mergedCell, range.cell, config);
        });

        // Auto-fit columns
        worksheet.columns.forEach((column) => {
            let maxLength = config.minColWidth;
            column.eachCell({ includeEmpty: true }, (cell) => {
                const cellLength = cell.value ? cell.value.toString().length : config.minColWidth;
                maxLength = Math.max(maxLength, cellLength);
            });
            column.width = Math.min(maxLength + 2, config.maxColWidth);
        });

        // Generate and download the file
        const buffer = await workbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename + '.xlsx';
        a.click();
        window.URL.revokeObjectURL(url);
    }

    /**
     * Apply styling to an Excel cell based on HTML cell styling
     * @param {ExcelJS.Cell} excelCell - The Excel cell to style
     * @param {HTMLElement} htmlCell - The HTML cell to read styles from
     * @param {object} config - Configuration options
     */
    function applyCellStyle(excelCell, htmlCell, config) {
        const computedStyle = window.getComputedStyle(htmlCell);
        const bgColor = computedStyle.backgroundColor;
        const fontWeight = computedStyle.fontWeight;
        const textAlign = computedStyle.textAlign;
        const fontColor = computedStyle.color;

        // Helper function to convert RGB to hex
        const rgbToHex = (rgb) => {
            if (!rgb || rgb === 'rgba(0, 0, 0, 0)' || rgb === 'transparent') return null;
            const match = rgb.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)/);
            if (!match) return null;
            const hex = (x) => ("0" + parseInt(x).toString(16)).slice(-2);
            return hex(match[1]) + hex(match[2]) + hex(match[3]);
        };

        const bgHex = rgbToHex(bgColor);
        const fontHex = rgbToHex(fontColor) || '000000';

        // Apply background color
        if (config.includeColors && bgHex) {
            excelCell.fill = {
                type: 'pattern',
                pattern: 'solid',
                fgColor: { argb: 'FF' + bgHex }
            };
        }

        // Apply font styling
        excelCell.font = {
            bold: fontWeight === 'bold' || parseInt(fontWeight) >= 700,
            color: { argb: 'FF' + fontHex }
        };

        // Apply alignment
        excelCell.alignment = {
            horizontal: textAlign === 'center' ? 'center' : (textAlign === 'right' ? 'right' : 'left'),
            vertical: 'middle',
            wrapText: true
        };

        // Apply borders
        if (config.includeBorders) {
            excelCell.border = {
                top: { style: 'thin', color: { argb: 'FFCCCCCC' } },
                left: { style: 'thin', color: { argb: 'FFCCCCCC' } },
                bottom: { style: 'thin', color: { argb: 'FFCCCCCC' } },
                right: { style: 'thin', color: { argb: 'FFCCCCCC' } }
            };
        }

        // Format numbers
        const value = htmlCell.textContent.trim();
        if (!isNaN(parseFloat(value)) && value !== '' && !value.includes('%') && !value.includes('/')) {
            excelCell.value = parseFloat(value);
            excelCell.numFmt = '0.00';
        }
    }

    /**
     * Quick export function with default settings
     * @param {string} tableID - The ID of the HTML table to export
     * @param {string} filename - The desired filename (without extension)
     */
    function quickExport(tableID, filename) {
        return exportTableToExcel(tableID, filename);
    }

    // Expose to global scope
    window.ExcelExporter = {
        exportTableToExcel: exportTableToExcel,
        quickExport: quickExport,
        version: '1.0'
    };

})(window);