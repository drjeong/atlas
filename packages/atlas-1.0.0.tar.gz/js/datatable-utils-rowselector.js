class DataTableRowSelector {
  constructor(tableId, options = {}) {
    this.tableId = tableId;
    this.dataTable = null;
    this.showSelectedOnly = false;
    this.selectedRows = 0;
    this.selectedRowIds = new Set(); // Track selected row IDs for server-side
    this.selectedRowsData = new Map(); // Store full row data for server-side
    this.isServerSide = false;
    this.options = {
      counterId: 'selectedCount',
      toggleButtonId: 'toggleSelected',
      itemName: 'course',
      ...options
    };

    // Bind methods to preserve 'this' context
    this.updateSelectedCount = this.updateSelectedCount.bind(this);
    this.handleToggleSelected = this.handleToggleSelected.bind(this);
    this.handleSelectDeselect = this.handleSelectDeselect.bind(this);
    this.handleSelectAll = this.handleSelectAll.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.filterSelectedRows = this.filterSelectedRows.bind(this);
  }

  init(dataTableInstance) {
    this.dataTable = dataTableInstance;
    this.isServerSide = this.dataTable.settings()[0].oInit.serverSide || false;
    this.initializeControls();
    this.attachEventHandlers();
    if (!this.isServerSide) {
      this.initCustomFilter();
    }
    this.applyStyles();
  }

  initializeControls() {
    $('.filterControls').html(`
            <button type="button" id="${this.options.toggleButtonId}" class="btn btn-primary btn-sm">
                <i class="glyphicon glyphicon-filter"></i> Show Selected Only
            </button>
            <span id="${this.options.counterId}" style="margin-left: 10px;"></span>
        `);
  }

  applyStyles() {
    $('.filterControls').css({
      'padding': '5px',
      'display': 'flex',
      'align-items': 'center'
    });
  }

  updateSelectedCount() {
    try {
      if (this.dataTable) {
        if (this.isServerSide) {
          // For server-side, use tracked count
          this.selectedRows = this.selectedRowIds.size;
        } else {
          // For client-side, count selected rows
          this.selectedRows = this.dataTable.rows('.selected').count();
        }

        $(`#${this.options.counterId}`).html(
            `Selected: ${this.selectedRows} ${this.options.itemName}${this.selectedRows !== 1 ? 's' : ''}`
        );

        if (this.showSelectedOnly) {
          $(`#${this.options.toggleButtonId}`).html(
              `<i class="glyphicon glyphicon-list"></i> Show All (${this.selectedRows})`
          );
        }
      }
    } catch (e) {
      console.error('Error updating selected count:', e);
    }
  }

  handleToggleSelected() {
    this.showSelectedOnly = !this.showSelectedOnly;
    this.updateSelectedCount();

    $(`#${this.options.toggleButtonId}`).html(
        this.showSelectedOnly ?
            `<i class="glyphicon glyphicon-list"></i> Show All (${this.selectedRows})` :
            '<i class="glyphicon glyphicon-filter"></i> Show Selected Only'
    );

    if (this.isServerSide) {
      this.applyServerSideFilter();
    } else {
      this.dataTable.draw();
    }
  }

  applyServerSideFilter() {
    const self = this;

    if (this.showSelectedOnly) {
      // Hide non-selected rows
      this.dataTable.rows().every(function() {
        const rowData = this.data();
        const rowId = rowData ? (rowData.DT_RowId || rowData.Idx) : null;
        const rowNode = $(this.node());

        if (rowId && self.selectedRowIds.has(rowId)) {
          rowNode.show();
        } else {
          rowNode.hide();
        }
      });

      // Update info to show only selected count
      $(`#${this.tableId}_info`).html(
          `Showing ${this.selectedRows} selected ${this.options.itemName}${this.selectedRows !== 1 ? 's' : ''}`
      );
    } else {
      // Show all rows
      this.dataTable.rows().every(function() {
        $(this.node()).show();
      });

      // Restore normal info display
      this.dataTable.draw(false); // false = stay on current page
    }
  }

  handleSelectDeselect(e, dt, type, indexes) {
    if (!this.dataTable) return;

    // Track selections for server-side processing only
    if (this.isServerSide) {
      if (e.type === 'select') {
        indexes.forEach(idx => {
          const rowData = this.dataTable.row(idx).data();
          if (rowData) {
            const rowId = rowData.DT_RowId || rowData.Idx;
            if (rowId) {
              this.selectedRowIds.add(rowId);
              this.selectedRowsData.set(rowId, rowData);
            }
          }
        });
      } else if (e.type === 'deselect') {
        indexes.forEach(idx => {
          const rowData = this.dataTable.row(idx).data();
          if (rowData) {
            const rowId = rowData.DT_RowId || rowData.Idx;
            if (rowId) {
              this.selectedRowIds.delete(rowId);
              this.selectedRowsData.delete(rowId);
            }
          }
        });
      }
    }

    this.updateSelectedCount();

    // If showing selected only, update the view
    if (this.showSelectedOnly) {
      if (this.isServerSide) {
        this.applyServerSideFilter();
      } else {
        this.dataTable.draw();
      }
    }
  }

  handleSelectAll(e) {
    if (!this.dataTable) return;

    const tr = $(e.target).closest("tr");
    tr.toggleClass("selected");

    if (tr.hasClass("selected")) {
      this.dataTable.rows({ page: 'current' }).select();
    } else {
      this.dataTable.rows({ page: 'current' }).deselect();
    }

    this.updateSelectedCount();

    if (this.showSelectedOnly) {
      if (this.isServerSide) {
        this.applyServerSideFilter();
      } else {
        this.dataTable.draw();
      }
    }
  }

  handlePageChange() {
    $('.toggle-all').closest("tr").removeClass("selected");
    this.updateSelectedCount();
  }

  filterSelectedRows(settings, data, dataIndex) {
    if (!this.showSelectedOnly) return true;

    const row = this.dataTable.row(dataIndex).node();
    return $(row).hasClass('selected');
  }

  attachEventHandlers() {
    const self = this;

    // Toggle button handler
    $(`#${this.options.toggleButtonId}`).on('click', this.handleToggleSelected);

    // Selection change handlers
    this.dataTable.on('select.dt', function(e, dt, type, indexes) {
      self.handleSelectDeselect(e, dt, type, indexes);
    });

    this.dataTable.on('deselect.dt', function(e, dt, type, indexes) {
      self.handleSelectDeselect(e, dt, type, indexes);
    });

    // Select all handler
    $(`#${this.tableId}`).on('click', '.toggle-all', this.handleSelectAll);

    // Page change handler
    this.dataTable.on('page.dt', this.handlePageChange);

    // Draw complete handler for server-side
    if (this.isServerSide) {
      this.dataTable.on('draw.dt', function() {
        // Re-apply selections after draw
        if (self.selectedRowIds.size > 0) {
          self.dataTable.rows().every(function() {
            const rowData = this.data();
            const rowId = rowData ? (rowData.DT_RowId || rowData.Idx) : null;
            if (rowId && self.selectedRowIds.has(rowId)) {
              // Re-select the row
              this.select();
            }
          });
        }

        // Re-apply filter if active
        if (self.showSelectedOnly) {
          self.applyServerSideFilter();
        }
      });
    }
  }

  initCustomFilter() {
    // Push the filter function directly
    $.fn.dataTable.ext.search.push(this.filterSelectedRows);
  }

  getSelectedData() {
    if (this.isServerSide) {
      // For server-side, return stored data
      return Array.from(this.selectedRowsData.values());
    } else {
      // For client-side, return current selected rows
      return this.dataTable.rows({ selected: true }).data().toArray();
    }
  }

  /**
   * Clears all selections and resets the filter
   */
  clearAllSelections() {
    if (!this.dataTable) return;

    // Deselect all rows
    this.dataTable.rows().deselect();

    // Clear server-side tracking
    if (this.isServerSide) {
      this.selectedRowIds.clear();
      this.selectedRowsData.clear();
    }

    // Clear the toggle-all checkbox
    $('.toggle-all').closest("tr").removeClass("selected");

    // Reset show selected only filter if active
    if (this.showSelectedOnly) {
      this.showSelectedOnly = false;
      $(`#${this.options.toggleButtonId}`).html(
          '<i class="glyphicon glyphicon-filter"></i> Show Selected Only'
      );

      if (this.isServerSide) {
        this.dataTable.rows().every(function() {
          $(this.node()).show();
        });
      } else {
        this.dataTable.draw();
      }
    }

    // Update the count
    this.updateSelectedCount();
  }

  /**
   * Cleanup method to remove event handlers and filters
   */
  destroy() {
    // Remove event handlers
    $(`#${this.options.toggleButtonId}`).off('click');
    $(`#${this.tableId}`).off('click', '.toggle-all');

    if (this.dataTable) {
      this.dataTable.off('select.dt deselect.dt page.dt draw.dt');
    }

    // Remove custom filter (client-side only)
    if (!this.isServerSide) {
      const index = $.fn.dataTable.ext.search.indexOf(this.filterSelectedRows);
      if (index > -1) {
        $.fn.dataTable.ext.search.splice(index, 1);
      }
    }

    // Clear data
    this.selectedRowIds.clear();
    this.selectedRowsData.clear();
  }
}