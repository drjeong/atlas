<?php
/**
 * Evaluation of Performance Indicators by Requirement
 *
 * 12/14/2025 - initial version created
 * 06/07/2026 - refactored to use performance_indicator_helpers
 * 06/11/2026 - added dual attainment thresholds (>=2.0 and >=3.0)
 *
 */
include_once 'session_handler.php';
?>

<?php
require_once('../php_include/dbconnection_class.php');
require_once('performance_indicator_helpers.php');

// Get parameters from session
$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// Handle academic years - convert from array to string if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
    if (!is_array($academicYears)) {
        $academicYears = array(intval($academicYears));
    }
} else {
    $academicYears = array(intval($IN_AcademicYear));
}

if (empty($academicYears)) {
    $academicYears = array(intval($IN_AcademicYear));
}

// Convert to comma-separated string for SQL queries
$IN_AcademicYears = implode(',', array_map('intval', $academicYears));

// Get requirement filter from GET parameter (optional)
$requirementFilter = isset($_GET['requirement']) ? $_GET['requirement'] : 'All';

// Initialize database connection
$DBCONNECTION = new Dbconnection();
$Data = array();

// Initialize variables
$studentOutcomes = array();
$courses = array();
$requirements = array();

// Query to get all Student Outcomes and their GPIs for the program
$soQuery = "
    SELECT DISTINCT
        STNTOUTCMS.SO,
        STNTOUTCMS.Description AS SODescription,
        GPIS.Idx AS GPIIdx,
        GPIS.GPI AS GPICode
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    ORDER BY STNTOUTCMS.SO, GPIS.GPI
";

$soResults = $DBCONNECTION->sendquery($soQuery);

if ($soResults) {
    while ($row = $soResults->fetch_assoc()) {
        $soKey = $row['SO'];
        if (!isset($studentOutcomes[$soKey])) {
            $studentOutcomes[$soKey] = array(
                'description' => $row['SODescription'],
                'gpis' => array()
            );
        }
        $studentOutcomes[$soKey]['gpis'][] = array(
            'gpiIdx' => $row['GPIIdx'],
            'code' => $row['GPICode']
        );
    }
}

// Query to get distinct requirements first
$requirementQuery = "
    SELECT DISTINCT ABETCRSES.Requirement
    FROM AbetCourses AS ABETCRSES
    WHERE ABETCRSES.AcademicProgram = {$IN_AcademicProgram}
    AND ABETCRSES.AcademicYear IN ({$IN_AcademicYears})
    AND ABETCRSES.Requirement IS NOT NULL
    AND ABETCRSES.Requirement != ''
    ORDER BY ABETCRSES.Requirement
";

$requirementResults = $DBCONNECTION->sendquery($requirementQuery);
if ($requirementResults) {
    while ($row = $requirementResults->fetch_assoc()) {
        if (!empty($row['Requirement'])) {
            $requirements[] = $row['Requirement'];
        }
    }
}

// Ensure all courses have been analyzed and saved
$saveResults = analyzeAndSavePerformanceIndicators(
    $DBCONNECTION,
    $IN_AcademicProgram,
    $academicYears,
    true,  // Don't force recalculate - skip if already exists
    $requirementFilter !== 'All' ? $requirementFilter : null
);

// Get the saved data from database
$savedCourses = getSavedPerformanceIndicators(
    $DBCONNECTION,
    $IN_AcademicProgram,
    $academicYears,
    $requirementFilter !== 'All' ? $requirementFilter : null
);

// Process saved courses and aggregate by CourseNo (consolidate multiple offerings)
$aggregatedCourses = array();

foreach ($savedCourses as $courseKey => $courseData) {
    $courseNo = $courseData['courseNo'];

    // Initialize if first time seeing this course number
    if (!isset($aggregatedCourses[$courseNo])) {
        $aggregatedCourses[$courseNo] = array(
            'courseNo' => $courseData['courseNo'],
            'title' => $courseData['title'],
            'requirement' => $courseData['requirement'],
            'rawScores' => array() // Will store all individual scores to calculate averages
        );
    }

    // Aggregate scores from all course offerings with same course number
    foreach ($courseData['indicators'] as $indicator) {
        $gpiIdx = $indicator['gpiIdx'];

        // Find which SO and GPI code this belongs to
        foreach ($studentOutcomes as $soKey => $soData) {
            foreach ($soData['gpis'] as $gpiInfo) {
                if ($gpiInfo['gpiIdx'] == $gpiIdx) {
                    $gpiCode = $gpiInfo['code'];

                    if (!isset($aggregatedCourses[$courseNo]['rawScores'][$soKey])) {
                        $aggregatedCourses[$courseNo]['rawScores'][$soKey] = array();
                    }
                    if (!isset($aggregatedCourses[$courseNo]['rawScores'][$soKey][$gpiCode])) {
                        $aggregatedCourses[$courseNo]['rawScores'][$soKey][$gpiCode] = array();
                    }

                    // Store the aggregate data for this offering
                    $aggregatedCourses[$courseNo]['rawScores'][$soKey][$gpiCode][] = array(
                        'avg' => $indicator['avg'],
                        'total' => $indicator['total'],
                        'topFifty' => $indicator['topFifty'],        // Students >= 2.0
                        'topTwentyFive' => $indicator['topTwentyFive']  // Students >= 3.0
                    );

                    break 2; // Exit both loops
                }
            }
        }
    }
}

// Calculate final averages and counts across all offerings
foreach ($aggregatedCourses as $courseNo => $courseData) {
    $courses[$courseNo] = array(
        'courseNo' => $courseData['courseNo'],
        'title' => $courseData['title'],
        'requirement' => $courseData['requirement'],
        'scores' => array(),
        'studentCounts' => array(),
        'studentsAbove2' => array(),  // NEW: Students >= 2.0
        'studentsAbove3' => array()   // Students >= 3.0
    );

    foreach ($courseData['rawScores'] as $soKey => $gpiData) {
        $courses[$courseNo]['scores'][$soKey] = array();
        $courses[$courseNo]['studentCounts'][$soKey] = array();
        $courses[$courseNo]['studentsAbove2'][$soKey] = array();  // NEW
        $courses[$courseNo]['studentsAbove3'][$soKey] = array();

        foreach ($gpiData as $gpiCode => $offeringsData) {
            // Aggregate across multiple offerings
            $totalWeightedSum = 0;
            $totalStudents = 0;
            $totalAbove2 = 0;  // NEW: Students >= 2.0
            $totalAbove3 = 0;  // Students >= 3.0

            foreach ($offeringsData as $offering) {
                $totalWeightedSum += $offering['avg'] * $offering['total'];
                $totalStudents += $offering['total'];

                // topFifty = students >= 2.0
                $totalAbove2 += $offering['topFifty'];

                // topTwentyFive = students >= 3.0
                $totalAbove3 += $offering['topTwentyFive'];
            }

            // Calculate overall average
            $overallAvg = $totalStudents > 0 ? $totalWeightedSum / $totalStudents : 0;

            $courses[$courseNo]['scores'][$soKey][$gpiCode] = round($overallAvg, 2);
            $courses[$courseNo]['studentCounts'][$soKey][$gpiCode] = $totalStudents;
            $courses[$courseNo]['studentsAbove2'][$soKey][$gpiCode] = $totalAbove2;  // NEW
            $courses[$courseNo]['studentsAbove3'][$soKey][$gpiCode] = $totalAbove3;
        }
    }
}

// Build the response data
$data = array();
foreach ($courses as $course) {
    $row = array(
        'requirement' => $course['requirement'],
        'courseNo' => $course['courseNo'],
        'title' => $course['title']
    );

    foreach ($studentOutcomes as $soKey => $soData) {
        foreach ($soData['gpis'] as $gpiInfo) {
            $gpiCode = $gpiInfo['code'];
            $columnKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'];
            $countKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_count';
            $above2Key = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_above2';  // NEW
            $above3Key = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_above3';

            // Use the consolidated data by GPI code
            $row[$columnKey] = isset($course['scores'][$soKey][$gpiCode]) ? $course['scores'][$soKey][$gpiCode] : '';
            $row[$countKey] = isset($course['studentCounts'][$soKey][$gpiCode]) ? $course['studentCounts'][$soKey][$gpiCode] : 0;
            $row[$above2Key] = isset($course['studentsAbove2'][$soKey][$gpiCode]) ? $course['studentsAbove2'][$soKey][$gpiCode] : 0;  // NEW
            $row[$above3Key] = isset($course['studentsAbove3'][$soKey][$gpiCode]) ? $course['studentsAbove3'][$soKey][$gpiCode] : 0;
        }
    }

    $data[] = $row;
}

// Prepare final response
$Data['data'] = $data;
$Data['studentOutcomes'] = $studentOutcomes;
$Data['requirements'] = $requirements;

header('Content-Type: application/json');
echo json_encode($Data);