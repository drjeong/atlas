<?php
/**
 * Sending Email
 * Description: Sending email with abet syllabus to instructors
 *
 * Author: Dong Hyun Jeong
 *
 * 11/20/2025 - initial version created
 */

include_once 'session_handler.php';
require_once(__DIR__ . '/../config.php');

header('Content-Type: application/json');

try {
    $instructorDataJson = $_POST['instructorData'] ?? '';
    $customSubject = $_POST['emailSubject'] ?? 'ABET Syllabus for Your Courses';
    $ccEmails = $_POST['ccEmails'] ?? '';
    $customMessage = $_POST['emailMessage'] ?? '';

    $instructorData = json_decode($instructorDataJson, true);

    if (empty($instructorData)) {
        echo json_encode(['success' => false, 'message' => 'No instructor data provided']);
        exit;
    }

    $successCount = 0;
    $failedInstructors = [];

    // Parse CC emails
    $ccEmailList = '';
    if (!empty($ccEmails)) {
        // Clean up CC emails - split by comma, trim whitespace, and rejoin
        $ccArray = array_map('trim', explode(',', $ccEmails));
        $ccArray = array_filter($ccArray); // Remove empty entries
        $ccEmailList = implode(', ', $ccArray);
    }

    // Add session email to CC if not already included
    $sessionEmail = $_SESSION['ATLAS_LOGIN_USEREMAIL'] ?? '';
    if (!empty($sessionEmail)) {
        if (empty($ccEmailList)) {
            $ccEmailList = $sessionEmail;
        } else {
            // Check if session email is already in CC list
            $ccArray = array_map('trim', explode(',', $ccEmailList));
            if (!in_array($sessionEmail, $ccArray)) {
                $ccEmailList .= ', ' . $sessionEmail;
            }
        }
    }

    // Loop through each instructor
    foreach ($instructorData as $email => $data) {
        try {
            $ToEmailAddress = $email; // Send to actual instructor (removed test email)
            $CCEmailAddress = $ccEmailList;
            $instructorName = $data['instructor'];

            // Build course list for email body and collect PDF attachments
            $courseList = '<ul>';
            $pdfAttachments = [];

            foreach ($data['courses'] as $course) {
                $courseList .= '<li><strong>' . htmlspecialchars($course['subject']) .
                    htmlspecialchars($course['num']) . '</strong> - ' .
                    htmlspecialchars($course['title']) .
                    ' (' . htmlspecialchars($course['semester']) . ')' .
                    ' [' . htmlspecialchars($course['academicYearInfo']) . ']</li>';

                // Construct the PDF file path for ABET Syllabus
                $AcademicYear = $course['academicYearInfo'];
                // Fixed the directory constant name (verify this matches your config)
                $ABETSYLLABUS_PDF_PATH = __DIRECTORY_ABETSYLLABI__ . $AcademicYear . DIRECTORY_SEPARATOR;

                // Extract filename from pdfLink
                $pdfFileName = basename($course['AbetSyllabus']);
                $pdfFilePath = $ABETSYLLABUS_PDF_PATH . $pdfFileName;

                // Check if PDF file exists before adding to attachments
                if (file_exists($pdfFilePath)) {
                    $pdfAttachments[] = $pdfFilePath;
                } else {
                    error_log("ABET Syllabus PDF file not found: " . $pdfFilePath);
                }
            }
            $courseList .= '</ul>';

            // Use custom subject
            $Subject = $customSubject;

            // Use custom message and replace placeholders
            $MessageContent = $customMessage;
            $MessageContent = str_replace('[INSTRUCTOR_NAME]', htmlspecialchars($instructorName), $MessageContent);
            $MessageContent = str_replace('[COURSE_LIST]', $courseList, $MessageContent);

            // Since we're using CKEditor, content is already HTML formatted
            // No need for nl2br conversion

            // Send email using your existing function
            require_once 'php_include/mail_attachment.php';
            $ReplyToEmailAddress = $_SESSION['ATLAS_LOGIN_USEREMAIL'] ?? __ADMIN_EMAILADDRESS;
            $bcc_email = __ADMIN_EMAILADDRESS;

            // Prepare attachments - if multiple PDFs, pass as array; if single, pass as string
            $attachmentPath = '';
            if (count($pdfAttachments) > 1) {
                $attachmentPath = $pdfAttachments;
            } elseif (count($pdfAttachments) == 1) {
                $attachmentPath = $pdfAttachments[0];
            }

            // Send email with PDF attachments
            $emailSent = SendGMailMessage(
                $ToEmailAddress,
                $CCEmailAddress,
                $bcc_email,
                $Subject,
                $MessageContent,
                $attachmentPath,
                $ReplyToEmailAddress
            );

            if ($emailSent) {
                $successCount++;
            } else {
                $failedInstructors[] = $instructorName . ' (' . $email . ')';
            }

        } catch (Exception $e) {
            error_log('Email error for ' . $email . ': ' . $e->getMessage());
            $failedInstructors[] = $data['instructor'] . ' (' . $email . ')';
        }
    }

    // Return results
    if ($successCount > 0 && empty($failedInstructors)) {
        echo json_encode([
            'success' => true,
            'message' => "Successfully sent emails to $successCount instructor(s)"
        ]);
    } elseif ($successCount > 0 && !empty($failedInstructors)) {
        echo json_encode([
            'success' => true,
            'message' => "Sent to $successCount instructor(s). Failed: " . implode(', ', $failedInstructors)
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => "Failed to send emails. Failed instructors: " . implode(', ', $failedInstructors)
        ]);
    }

} catch (Exception $e) {
    error_log('Server error in ABET syllabus email: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}

