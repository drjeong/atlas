<?php
/**
 * Academic Year information selection
 * Description: Listing the academic year information.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 05/05/2023 - Default academic year is changed to the latest available academic year
 * 10/05/2023 - Automatically select current academic year evaluating current year information
 *
 */

if (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']) || $_SESSION['ATLAS_SELECTED_ACADEMICYEAR']=='') {
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = 'all'; // default

    // Fetch Current Academic Year
    require_once(__DIR__ . '/php_include/semester_helpers.php');
    $CurrentAcademicYear = getCurrentAcademicYear();

//    Finding current (or latest) academic year if exists in DB
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();
    $Query = "SELECT `Idx` FROM `AcademicYears` WHERE `AcademicYear`=?";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$CurrentAcademicYear]);
    if ($row = $DBCONNECTION->fetch_assoc()) {
        $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $row["Idx"];  // default
    }
}

if (isset($_GET['_AY']) || isset($_POST['_AY'])) {
//    If academic year is selected by the user, it needs to be updated.
    if (isset($_GET['_AY'])) $AcademicYear = trim($_GET['_AY']);
    if (isset($_POST['_AY'])) $AcademicYear = trim($_POST['_AY']);

    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] = $AcademicYear;
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] = $AcademicYear;
}


if (isset($_POST['_AY_FROM']) && isset($_POST['_AY_TO'])) {
    // If academic year is selected by the user, update session variables.

    // Get values from GET or POST
    $AcademicYearFrom = trim($_POST['_AY_FROM']);
    $AcademicYearTo = trim($_POST['_AY_TO']);

    // Validate to ensure "From" is not greater than "To"
    if (isset($AcademicYearFrom, $AcademicYearTo) && $AcademicYearFrom > $AcademicYearTo) {
        // Swap values if they are in the wrong order
        list($AcademicYearFrom, $AcademicYearTo) = [$AcademicYearTo, $AcademicYearFrom];
    }

    // Save valid values in session
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] = $AcademicYearFrom;
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] = $AcademicYearTo;
}


function ListOfAcademicYears()
{
    $academic_years = [];
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();
    $Query = "CALL SP_FetchAcademicYears();";
    $DBCONNECTION->sendquery($Query);
    while ($row = $DBCONNECTION->fetch_assoc()) {
        if (is_array($row)) {
            $academic_years[] = $row;
        }
    }
    unset($DBCONNECTION);
    return $academic_years;
}

function AcademicYearSelection($all = true)
{
    $content = "";
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();
    $Query = "CALL SP_FetchAcademicYears();";
    //echo $Query;
    $DBCONNECTION->sendquery($Query);

    // fetch current url
    $escaped_url = htmlspecialchars(basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']), ENT_QUOTES, 'UTF-8');

    $content .='<form action="'.$escaped_url.'" name="academicyear" method="post" style="font-size:9pt;">';
    $content .='<div class="input-group" style="width:100%">';
    $content .='<span class="input-group-addon" style="width:230px;">BY ACADEMIC YEAR: </span>';
    $content .='<select name="_AY" id="_AY" class="input-sm form-control" style="width:200px;">';
    if ($all === true)
        $content .='<option value="all">ALL</option>';
    while ($row = $DBCONNECTION->fetch_assoc())
    {
        $content .= '<option value="' . $row["Idx"] . '"';
        if ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] == $row["Idx"]){
            $content .= ' selected';
        }
        else if ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] == 'all' && $all === false) {
            // set the default value with other than "all"
            $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $row["Idx"];
            $content .= ' selected';
        }
        $content .= '>' . $row["AcademicYear"] . '</option>';
    }
    $content .='</select>';
    $content .='</div>';
    $content .='</form>';

    unset($DBCONNECTION);

    return $content;
}

function AcademicMultiYearsSelection()
{
    // Initialize content and fetch data
    $content = "";
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();
    $Query = "CALL SP_FetchAcademicYears();";
    $DBCONNECTION->sendquery($Query);

    // Store all academic years in an array
    $academicYears = [];
    while ($row = $DBCONNECTION->fetch_assoc()) {
        $academicYears[] = $row;
        if (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'])) {
            $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $row["Idx"];
        }
    }

    // Get the current URL for form action
    $escaped_url = htmlspecialchars(basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']), ENT_QUOTES, 'UTF-8');

    // Initialize year range if not set
    $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'] = array(); // Reset the session array

    if ((!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM']) || !isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'])) &&
        isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'])) {
        $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
        $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
    }

    $AcademicYearFrom = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'];
    $AcademicYearTo = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'];

    // Store all academic years in the selected range
    foreach ($academicYears as $row) {
        if ($row["Idx"] >= $AcademicYearFrom && $row["Idx"] <= $AcademicYearTo) {
            $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'][] = $row["Idx"];
        }
    }

    // Start building the form
    $content .= '<div style="display:flex; align-items:center; width:100%;">';
    $content .= '<form action="' . $escaped_url . '" name="academicyear" method="post" style="font-size:9pt;">';

    // Create a container div for the entire control
    $content .= '<div style="flex:1; max-width:650px;">';

    // Start the input group - this forces elements to connect properly
    $content .= '<div class="input-group">';

    // Label
    $content .= '<span class="input-group-addon">ACADEMIC YEARS RANGE:</span>';

    // From label
    $content .= '<span class="input-group-addon" style="border-left:0;">From:</span>';

    // From dropdown
    $content .= '<select name="_AY_FROM" id="_AY_FROM" class="form-control input-sm">';
    foreach ($academicYears as $row) {
        $selected = ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] == $row["Idx"]) ? ' selected' : '';
        $content .= '<option value="' . $row["Idx"] . '"' . $selected . '>' . $row["AcademicYear"] . '</option>';
    }
    $content .= '</select>';

    // To label
    $content .= '<span class="input-group-addon" style="border-left:0;">To:</span>';

    // To dropdown
    $content .= '<select name="_AY_TO" id="_AY_TO" class="form-control input-sm">';
    foreach ($academicYears as $row) {
        $selected = ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] == $row["Idx"]) ? ' selected' : '';
        $content .= '<option value="' . $row["Idx"] . '"' . $selected . '>' . $row["AcademicYear"] . '</option>';
    }
    $content .= '</select>';

    // End the input group
    $content .= '</div>'; // End of input-group
    $content .= '</div>'; // End of container

    // Close the main container
    $content .= '</div>'; // End of flex container
    $content .= '</form>';

    // Add custom CSS to fix any remaining spacing issues
    $content .= '<style>
        form[name="academicyear"] .input-group-addon:nth-child(3) {
            border-left: 0 !important;
            padding-left: 0 !important;
            margin-left: 0 !important;
        }
    </style>';

    // Clean up and return
    unset($DBCONNECTION);
    return $content;
}

function AcademicYearsSelection($multipleSelection = false, $visibleTogglebutton = true)
{

    // Initialize content and fetch data
    $content = "";
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();
    $Query = "CALL SP_FetchAcademicYears();";
    $DBCONNECTION->sendquery($Query);

    // Store all academic years in an array
    $academicYears = [];
    while ($row = $DBCONNECTION->fetch_assoc()) {
        $academicYears[] = $row;
        if (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'])) {
            $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $row["Idx"];
        }
    }

    // Get the current URL for form action
    $escaped_url = htmlspecialchars(basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']), ENT_QUOTES, 'UTF-8');

    // Start building the form
    $content .= '<div style="display:flex; align-items:center; width:100%;">';

    if ($visibleTogglebutton) {
        // Toggle Button (same for both modes)
        $content .= '<div style="margin-right:10px;">';
        $content .= '<form id="toggleSelectionForm" action="' . $escaped_url . '" method="post">
            <input type="hidden" name="multipleSelection" id="multipleSelection" value="' . ($multipleSelection ? 'false' : 'true') . '">
            <a href="#" id="toggleSelectionMode" class="btn btn-sm btn-default">Switch to ' . ($multipleSelection ? 'Single Year' : 'Year Range') . '</a>
        </form>';
        $content .= '</div>';
    }

    $content .= '<form action="'.$escaped_url.'" name="academicyear" method="post" style="font-size:9pt;">';

    if ($multipleSelection) {
        $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'] = array(); // Reset the session array

        if ( (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM']) || !isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'])) &&
            isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']) ) {
            $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
            $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
        }

//        // Ensure From and To values are set
//        if (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'])) {
//            $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] = $academicYears[0]["Idx"];
//        }
//        if (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'])) {
//            $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] = end($academicYears)["Idx"];
//        }

        $AcademicYearFrom = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'];
        $AcademicYearTo = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'];

//        echo '$AcademicYearFrom:' . $AcademicYearFrom . '<br>';
//        echo '$AcademicYearTo:' . $AcademicYearTo. '<br>';
        // Store all academic years in the selected range
        foreach ($academicYears as $row) {
            if ($row["Idx"] >= $AcademicYearFrom && $row["Idx"] <= $AcademicYearTo) {
                $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'][] = $row["Idx"];
            }
        }

        // Create a container div for the entire control
        $content .= '<div style="flex:1; max-width:650px;">';

        // Start the input group - this forces elements to connect properly
        $content .= '<div class="input-group">';

        // Label
        $content .= '<span class="input-group-addon">ACADEMIC YEARS RANGE:</span>';

        // From label
        $content .= '<span class="input-group-addon" style="border-left:0;">From:</span>';

        // From dropdown
        $content .= '<select name="_AY_FROM" id="_AY_FROM" class="form-control input-sm">';
        foreach ($academicYears as $row) {
            $selected = ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] == $row["Idx"]) ? ' selected' : '';
            $content .= '<option value="' . $row["Idx"] . '"' . $selected . '>' . $row["AcademicYear"] . '</option>';
        }
        $content .= '</select>';

        // To label
        $content .= '<span class="input-group-addon" style="border-left:0;">To:</span>';

        // To dropdown
        $content .= '<select name="_AY_TO" id="_AY_TO" class="form-control input-sm">';
        foreach ($academicYears as $row) {
            $selected = ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] == $row["Idx"]) ? ' selected' : '';
            $content .= '<option value="' . $row["Idx"] . '"' . $selected . '>' . $row["AcademicYear"] . '</option>';
        }
        $content .= '</select>';

        // End the input group
        $content .= '</div>'; // End of input-group
        $content .= '</div>'; // End of container
    } else {
        // Single Selection Mode UI
        // Create a container div for the entire control
        $content .= '<div style="flex:1; max-width:450px;">';

        // Start the input group
        $content .= '<div class="input-group">';

        // Label
        $content .= '<span class="input-group-addon">BY ACADEMIC YEAR:</span>';

        // Single Year Dropdown
        $content .= '<select name="_AY" id="_AY" class="form-control input-sm">';
        foreach ($academicYears as $row) {
            $content .= '<option value="' . $row["Idx"] . '"';
            if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']) &&
                $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] == $row["Idx"]) {
                $content .= ' selected';
            } else if ((!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']) ||
                $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] == 'all')) {
                $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $row["Idx"];
                $content .= ' selected';
            }
            $content .= '>' . $row["AcademicYear"] . '</option>';
        }
        $content .= '</select>';

        // End the input group
        $content .= '</div>'; // End of input-group
        $content .= '</div>'; // End of container
    }

    // Close the main container
    $content .= '</div>'; // End of flex container
    $content .= '</form>';

    // Add custom CSS to fix any remaining spacing issues
    $content .= '<style>
        form[name="academicyear"] .input-group-addon:nth-child(3) { /* Targets the "To" label */
        border-left: 0 !important;
        padding-left: 0 !important;
        margin-left: 0 !important;
    }
    </style>';

    if ($visibleTogglebutton) {
        // JavaScript for toggle functionality
        $content .= '<script>
            document.getElementById("toggleSelectionMode").addEventListener("click", function(e) {
                e.preventDefault();
                document.getElementById("toggleSelectionForm").submit();
            });
        </script>';
    };

    // Clean up and return
    unset($DBCONNECTION);
    return $content;
}

/**
 * Generates an HTML dropdown form for filtering data by instructor.
 *
 * Queries the database for all active instructors (excluding assistants and disabled accounts)
 * and builds a select dropdown. When a user selects an instructor, the onchange event triggers
 * UpdateDataTablebyInstructor() to dynamically filter/update the displayed data without page reload.
 *
 * Security: Uses prepared statements to prevent SQL injection and htmlspecialchars() to prevent XSS.
 *
 * @return string Complete HTML form string containing the instructor dropdown
 * @throws Exception If database connection or query execution fails
 */
function InstructorList()
{
    $content = "";
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();
    $query = "SELECT `Name`, `Email` FROM `UserAccounts` WHERE `Position`<>? and `Disabled`!=1 ORDER BY `Name` ASC";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [__ASSISTANT_USERCODE]);

    $escaped_url = htmlspecialchars(basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']), ENT_QUOTES, 'UTF-8');

    // Get the selected instructor email from session
    $selectedInstructor = isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDINSTRUCTOR']) ? $_SESSION['ATLAS_ACCESSCNTL_SELECTEDINSTRUCTOR'] : '';

    $content .='<form action="'.$escaped_url.'" name="instructors" method="post" style="font-size:9pt;">';
    $content .='<div class="input-group" style="width:100%">';
    $content .='<span class="input-group-addon" style="width:230px;">BY INSTRUCTOR: </span>';
    $content .='<select name="_USER" id="_USER" class="input-sm form-control" onchange="UpdateDataTablebyInstructor(this);">';

    while ($row = $result->fetch_assoc()) {
        $email = htmlspecialchars($row["Email"], ENT_QUOTES, 'UTF-8');
        $name = htmlspecialchars($row["Name"], ENT_QUOTES, 'UTF-8');

        // Check if this option should be selected
        $selected = ($email === $selectedInstructor) ? ' selected' : '';

        $content .= '<option value="' . $email . '"' . $selected . '>';
        $content .= $name . '</option>';
    }

    $content .='</select>';
    $content .='</div>';
    $content .='</form>';

    unset($DBCONNECTION);

    return $content;
}



