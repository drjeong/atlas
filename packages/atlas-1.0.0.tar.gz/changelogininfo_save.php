<?php
/**
 *
 * Change Login Information
 * Description: save changed login information
 * Author: Dong Hyun Jeong
 *
 * 06/30/2021 - initial version created
 *
*/

include_once 'session_handler.php';

if (!isset($_POST['_OPWD']) || !isset($_POST['_NPWD'])) {
    echo ("0x00000001"); // error
    exit;
}

// processing changed password
$idx=$_SESSION['ATLAS_LOGIN_USERIDX'];
$OldPWD=$_POST['_OPWD'];
$NewPWD=$_POST['_NPWD'];

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    $OldPWD_Encrypted = hash('sha256', $OldPWD);
    $NewPWD_Encrypted = hash('sha256', $NewPWD);

    $query = "CALL SP_ChangeUserPassword(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$idx, $OldPWD_Encrypted, $NewPWD_Encrypted]);

    // destroy all sessions
    session_unset();
    session_destroy();
    session_write_close();
    //session_regenerate_id(true);

    echo("0x11111111"); // Password has been updated successfully!!
} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00201000') !== false) {
        echo '0x00201000';  // Current Password is not matched to the stored password!
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
