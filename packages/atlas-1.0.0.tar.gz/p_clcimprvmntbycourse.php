<?php
/**
 * Course-level Continuous Improvements by course
 * File: p_clcimprvmntbycourse.php
 * Description: Listing courses' continuous improvements by course.
 *
*/

include('header.php');

$AbetCourseSubject=null;
$AbetCourseNum=null;
if (isset($_POST['_ABTCSUB']) && isset($_POST['_ABTCNUM'])) { // user changed
    $AbetCourseSubject = trim($_POST['_ABTCSUB']);
    $AbetCourseNum = trim($_POST['_ABTCNUM']);
}

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

?>

<script type="text/javascript">

    function fetchassessmentassignments(abetcsub, abetcnum)
    {
        let form = document.createElement("form");
        form.method = "POST";
        form.action = "p_clcimprvmntbycourse.php";

        let element;
        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=abetcsub;
        element.name="_ABTCSUB";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=abetcnum;
        element.name="_ABTCNUM";
        form.appendChild(element);

        document.body.appendChild(form);
        form.submit();
    }

    $(document).ready(function() {

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            document.academicyear.submit();
        });
    });
</script>

<div class="pagebacklayout">
    <div class="row">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">ASSESSMENT OF COURSE-LEVEL CONTINUOUS IMPROVEMENT (BY COURSE)</p>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <?php include('control_allprograms.php'); ?>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:30%;">
                </td>
                <td style="width:10%"></td>
                <td style="width:60%; text-align: right">
                </td>
            </tr>
        </table>

        <div class='col-md-2'>
            <!-- Sidebar -->
            <div class="list-group list-group-flush">
                <?php
                require_once(__DIR__ . '/php_include/dbconnection_class.php');
                $DBCONNECTION = new Dbconnection();

                $AbetCourseAvailable = false;

                $Query = "CALL SP_FetchAllAbetCourses('".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."');";
//                echo ($Query);
                $DBCONNECTION->sendquery($Query);

                while ($row = $DBCONNECTION->fetch_assoc())
                {
                    $AbetCourseAvailable = true;
                    if ($AbetCourseSubject == null){
                        $AbetCourseSubject = $row['Subject'];
                        $AbetCourseNum = $row['Num'];
                    }

                    $course = $row['Subject'] . ' ' . $row['Num'] . ' ' . $row['Title'];
                    echo ('<a href="#" class="list-group-item list-group-item-action bg-light');
                    if ($AbetCourseSubject == $row['Subject'] && $AbetCourseNum == $row['Num']) echo (' active ');
                    echo ('" onclick="fetchassessmentassignments(\''.$row['Subject'].'\', \''.$row['Num'].'\');">'.$course.'</a>');
                }

                if ($AbetCourseAvailable == false){
                    echo <<<HTML
                    <div class="boxcontainer" style="width:100%;">
                        <p>
                        <h4>No Abet Courses Available</h4>
                        </p>
HTML;
                }
                ?>
            </div>
            <!-- /#sidebar-wrapper -->
        </div>

        <div class='col-md-10'>
            <!-- Page Content -->
            <div id="pagebacklayout_inner_noborder">

                <div id="assessment_content">
                    <?php

                    if ($AbetCourseAvailable) {
                        /////////////////////////////////////////////////////////////////////////////////
                        // fetch course assessment information
                        $Query = "CALL SP_FetchSelectedAbetCourseCntinusImprvmnts('$AbetCourseSubject', '$AbetCourseNum', '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."');";
//        echo ($Query);
                        $DBCONNECTION->sendquery($Query);
                        while ($row = $DBCONNECTION->fetch_assoc()) {
                            $ABCIdx = $row['ABCIdx'];
                            $AVCIdx = $row['AVCIdx'];
                            $Instructor = $row['Instructor'];
                            $CourseNo = $row['CourseNo'];
                            $Title = $row['Title'];
                            $Credits = $row['Credits'];
                            $Semester = $row['Semester'];
                            $FacultyReflection = convert_encoded_html_to_display($row['FacultyReflection']);

echo <<<HTML
                    <div class="boxcontainer">
                        <p>
                        <h4>$CourseNo $Title</h4>
                        <h5>
                            Semester: $Semester<br/>
                            Credit Hours: $Credits<br/>
                            Professor: $Instructor
                        </h5>
                        </p>
HTML;
echo <<<HTML
                        <div class="box-row">
                            <div class="box-cell box1">
                                <b> $FacultyReflection </b> 
                            </div>
                        </div>
                    </div>
HTML;

                        }
                        unset($DBCONNECTION);
                    }
                    ?>

                </div>
                <!-- /#page-content-wrapper -->
            </div>


        </div>
    </div>

    <?php include('footer.php');?>

