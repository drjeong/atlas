<?php
/**
 * Listing Performance Indicators
 * File: u_course_results_GPI_ssp.php
 * Description: listing performance indicators of the selected course
 * Updated: ABET-compliant per-student calculation with detail view
 */

include_once 'session_handler.php';

// Get parameters
$abetCourseIdx = '';
$availableCourseIdx = '';
$academicProgramIdx = '';

if (array_key_exists('_ABTC', $_GET) && array_key_exists('_AVC', $_GET) && array_key_exists('_AP', $_GET)) {
    $abetCourseIdx = trim($_GET['_ABTC']);
    $availableCourseIdx = trim($_GET['_AVC']);
    $academicProgramIdx = trim($_GET['_AP']);
} else {
    // illegal entry
    exit;
}

require_once('../php_include/dbconnection_class.php');
require_once('PerformanceIndicatorAnalyzer.php');

try {
    $db = new Dbconnection();
    $analyzer = new PerformanceIndicatorAnalyzer($db);

    $output = $analyzer->getDataTablesResponse(
        $abetCourseIdx,
        $availableCourseIdx,
        $academicProgramIdx,
        $_GET['draw'] ?? 0
    );

    header('Content-Type: application/json');
    echo json_encode($output);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

//
//// Initialize database connection
//$DBCONNECTION = new Dbconnection();
//$data = array();
//
//// Escape inputs for security
//$abetCourseIdx = $DBCONNECTION->real_escape_string($abetCourseIdx);
//$availableCourseIdx = $DBCONNECTION->real_escape_string($availableCourseIdx);
//$academicProgramIdx = $DBCONNECTION->real_escape_string($academicProgramIdx);
//
//// Step 1: Get all GPIs and their measures
//$gpiMeasuresQuery = "
//    SELECT
//        GPIS.Idx AS GPIIdx,
//        STNTOUTCMS.SO AS SO,
//        GPIS.GPI AS GPI,
//        GPIS.Description AS Description,
//        AM.Idx AS MeasureIdx,
//        AM.Measure AS MeasureNumber
//    FROM GeneralPerformanceIndicators AS GPIS
//    INNER JOIN StudentOutcomes AS STNTOUTCMS
//        ON (GPIS.SOIdx = STNTOUTCMS.Idx AND STNTOUTCMS.AcademicProgram = {$academicProgramIdx})
//    INNER JOIN AssessmentMeasures AS AM
//        ON (AM.GPI = GPIS.Idx AND AM.AvailableCourseIdx = {$availableCourseIdx} AND AM.AbetCourseIdx = {$abetCourseIdx})
//    WHERE GPIS.AcademicProgram = {$academicProgramIdx}
//    ORDER BY GPIS.Idx, AM.Measure
//";
//
//$gpiMeasuresResults = $DBCONNECTION->sendquery($gpiMeasuresQuery);
//$gpiInfo = array();
//
//if ($gpiMeasuresResults) {
//    while ($row = $gpiMeasuresResults->fetch_assoc()) {
//        $gpiIdx = $row['GPIIdx'];
//
//        if (!isset($gpiInfo[$gpiIdx])) {
//            $gpiInfo[$gpiIdx] = array(
//                'SO' => $row['SO'],
//                'GPI' => $row['GPI'],
//                'Description' => $row['Description'],
//                'RequiredMeasures' => array()
//            );
//        }
//
//        // Store the required measure indices for this GPI
//        $gpiInfo[$gpiIdx]['RequiredMeasures'][] = $row['MeasureIdx'];
//    }
//}
//
//// Step 2: Get raw student scores
//$scoresQuery = "
//    SELECT
//        GPIS.Idx AS GPIIdx,
//        SCSHEET.StudentNo,
//        SCSHEET.AssessmentMeasureIdx,
//        SCSHEET.LevelOfAttainment,
//        AM.Measure
//    FROM AssessmentMeasures AS ASSMNTMEASURES
//    INNER JOIN GeneralPerformanceIndicators AS GPIS
//        ON (GPIS.Idx = ASSMNTMEASURES.GPI AND GPIS.AcademicProgram = {$academicProgramIdx})
//    INNER JOIN Scoresheet AS SCSHEET
//        ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
//    INNER JOIN AssessmentMeasures AS AM
//        ON (SCSHEET.AssessmentMeasureIdx = AM.Idx)
//    WHERE ASSMNTMEASURES.AvailableCourseIdx = {$availableCourseIdx}
//      AND ASSMNTMEASURES.AbetCourseIdx = {$abetCourseIdx}
//    ORDER BY GPIS.Idx, SCSHEET.StudentNo, SCSHEET.AssessmentMeasureIdx
//";
//
//$scoresResults = $DBCONNECTION->sendquery($scoresQuery);
//
//// Organize scores by GPI and Student
//$studentScores = array();
//
//if ($scoresResults) {
//    while ($row = $scoresResults->fetch_assoc()) {
//        $gpiIdx = $row['GPIIdx'];
//        $studentNo = $row['StudentNo'];
//        $measureIdx = $row['AssessmentMeasureIdx'];
//
//        if (!isset($studentScores[$gpiIdx])) {
//            $studentScores[$gpiIdx] = array();
//        }
//
//        if (!isset($studentScores[$gpiIdx][$studentNo])) {
//            $studentScores[$gpiIdx][$studentNo] = array(
//                'measureData' => array(), // Changed to store measure index => score mapping
//                'measureDetails' => array()
//            );
//        }
//
//        // Track unique measures with their scores
//        if (!isset($studentScores[$gpiIdx][$studentNo]['measureData'][$measureIdx])) {
//            $studentScores[$gpiIdx][$studentNo]['measureData'][$measureIdx] = floatval($row['LevelOfAttainment']);
//            $studentScores[$gpiIdx][$studentNo]['measureDetails'][] = array(
//                'measureIdx' => $measureIdx,
//                'measure' => $row['Measure'],
//                'score' => floatval($row['LevelOfAttainment'])
//            );
//        }
//    }
//}
//
//// Step 3: Calculate per-student averages and aggregate results
//foreach ($gpiInfo as $gpiIdx => $gpiData) {
//    $requiredMeasures = $gpiData['RequiredMeasures'];
//    $totalMeasures = count($requiredMeasures);
//
//    if ($totalMeasures == 0) {
//        continue; // Skip GPIs with no measures
//    }
//
//    $validStudentAverages = array();
//    $studentsAbove2 = 0;
//    $studentsAbove3 = 0;
//    $studentDetails = array(); // For detail view
//
//    if (isset($studentScores[$gpiIdx])) {
//        foreach ($studentScores[$gpiIdx] as $studentNo => $studentData) {
//            $studentMeasureData = $studentData['measureData'];
//            $studentMeasureIndices = array_keys($studentMeasureData);
//
//            // Check if student has ALL required measures for THIS specific GPI
//            $missingMeasures = array_diff($requiredMeasures, $studentMeasureIndices);
//
//            if (count($missingMeasures) > 0) {
//                // Student is missing some required measures for this GPI
//                $studentDetails[] = array(
//                    'studentNo' => $studentNo,
//                    'measures' => $studentData['measureDetails'],
//                    'average' => 0,
//                    'included' => false,
//                    'reason' => "Missing " . count($missingMeasures) . " required measure(s) for this PI"
//                );
//                continue;
//            }
//
//            // NEW: Check if ANY of the required measures have a score of 0
//            $hasZeroScore = false;
//            $zeroMeasures = array();
//            foreach ($requiredMeasures as $requiredMeasureIdx) {
//                if (isset($studentMeasureData[$requiredMeasureIdx]) && $studentMeasureData[$requiredMeasureIdx] == 0) {
//                    $hasZeroScore = true;
//                    // Find the measure number for display
//                    foreach ($studentData['measureDetails'] as $detail) {
//                        if ($detail['measureIdx'] == $requiredMeasureIdx) {
//                            $zeroMeasures[] = 'M' . $detail['measure'];
//                            break;
//                        }
//                    }
//                }
//            }
//
//            if ($hasZeroScore) {
//                // Student has zero score on at least one required measure - exclude
//                $studentDetails[] = array(
//                    'studentNo' => $studentNo,
//                    'measures' => $studentData['measureDetails'],
//                    'average' => 0,
//                    'included' => false,
//                    'reason' => "No submission for: " . implode(', ', $zeroMeasures)
//                );
//                continue;
//            }
//
//            // Student has all required measures with non-zero scores - calculate average
//            $scoresForAvg = array();
//            foreach ($requiredMeasures as $requiredMeasureIdx) {
//                $scoresForAvg[] = $studentMeasureData[$requiredMeasureIdx];
//            }
//
//            $studentAvg = array_sum($scoresForAvg) / count($scoresForAvg);
//
//            // Valid student - include in calculation
//            $validStudentAverages[] = $studentAvg;
//
//            if ($studentAvg >= 2.0) {
//                $studentsAbove2++;
//            }
//            if ($studentAvg >= 3.0) {
//                $studentsAbove3++;
//            }
//
//            // Store detail for this student
//            $studentDetails[] = array(
//                'studentNo' => $studentNo,
//                'measures' => $studentData['measureDetails'],
//                'average' => round($studentAvg, 2),
//                'included' => true
//            );
//        }
//    }
//
//    // Calculate overall average
//    $overallAvg = 0;
//    $totalStudents = count($validStudentAverages);
//
//    if ($totalStudents > 0) {
//        $overallAvg = array_sum($validStudentAverages) / $totalStudents;
//    }
//
//    // Build row
//    $row = array(
//        'DT_RowId' => 'row_' . $gpiIdx,
//        'GPIIdx' => $gpiIdx,
//        'GPI' => $gpiData['SO'] . '-' . $gpiData['GPI'],
//        'GPIDescription' => $gpiData['Description'],
//        'AVG' => round($overallAvg, 2),
//        'TOTAL' => $totalStudents,
//        'TOPFIFTY' => $studentsAbove2,
//        'TOPTWENTYFIVE' => $studentsAbove3,
//        'TotalMeasures' => $totalMeasures,
//        'StudentDetails' => $studentDetails
//    );
//
//    $data[] = $row;
//}
//
//// Format response for DataTables
//$output = array(
//    "draw" => isset($_GET['draw']) ? intval($_GET['draw']) : 0,
//    "recordsTotal" => count($data),
//    "recordsFiltered" => count($data),
//    "data" => $data
//);
//
//header('Content-Type: application/json');
//echo json_encode($output);


///**
// * Listing Performance Indicators
// * File: u_course_results_GPI_ssp.php
// * Description: listing performance indicators of the selected course
// */
//
//include_once 'session_handler.php';
//
//$abetCourseIdx='';
//$availableCourseIdx='';
//$academicProgramIdx='';
//if (array_key_exists('_ABTC', $_GET) && array_key_exists('_AVC', $_GET) && array_key_exists('_AP', $_GET)) {
//    $abetCourseIdx = trim($_GET['_ABTC']);
//    $availableCourseIdx = trim($_GET['_AVC']);
//    $academicProgramIdx = trim($_GET['_AP']);
//}
//else {
//    // illegal entry
//    exit;
//}
//
//// DB table to use
//$table = 'AssessmentMeasures';
//$joinQuery = "FROM `$table` AS `ASSMNTMEASURES` INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram`='$academicProgramIdx') INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`='$academicProgramIdx') INNER JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`) ";
//
//// Table's primary key
//$primaryKey = '`GPIS`.`Idx`';
//
//// Array of database columns
//$columns = array(
//    array('db' => '`GPIS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
//        return 'row_'.$row[0];
//    }),
//    array( 'db' => 'CONCAT(`STNTOUTCMS`.`SO`, \'-\', `GPIS`.`GPI`)', 'dt' => 'GPI', 'field' => 'GPI', 'as' => 'GPI'),
//    array( 'db' => '`GPIS`.`Idx`', 'dt' => 'GPIIdx', 'field' => 'GPIIdx', 'as' => 'GPIIdx'),
//    array( 'db' => '`GPIS`.`Description`', 'dt' => 'GPIDescription', 'field' => 'GPIDescription', 'as' => 'GPIDescription'),
//    array( 'db' => 'AVG(`SCSHEET`.`LevelOfAttainment`)', 'dt' => 'AVG', 'field' => 'AVG', 'as' => 'AVG'),
//    array( 'db' => 'COUNT(`SCSHEET`.`LevelOfAttainment`)', 'dt' => 'TOTAL', 'field' => 'TOTAL', 'as' => 'TOTAL'),
//    array( 'db' => 'SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE NULL END)', 'dt' => 'TOPFIFTY', 'field' => 'TOPFIFTY', 'as' => 'TOPFIFTY'),
//    array( 'db' => 'SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE NULL END)', 'dt' => 'TOPTWENTYFIVE', 'field' => 'TOPTWENTYFIVE', 'as' => 'TOPTWENTYFIVE'),
//);
//
//require( 'ssp.join.class.php' );
//$extraWhere = "`ASSMNTMEASURES`.`AvailableCourseIdx` = '$availableCourseIdx'";
//$extraWhere .= " AND `ASSMNTMEASURES`.`AbetCourseIdx`= '$abetCourseIdx'";
//
//// Include all non-aggregated columns in GROUP BY
//$groupBy = "`GPIS`.`Idx`, `STNTOUTCMS`.`SO`, `GPIS`.`GPI`, `GPIS`.`Description`";
//
//require_once(__DIR__ . '/../php_include/dbconnection.php');
//echo json_encode(
//    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
//);