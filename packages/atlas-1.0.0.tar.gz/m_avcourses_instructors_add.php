<?php
include_once 'session_handler.php';

$avcIdx = isset($_POST['avcIdx']) ? intval($_POST['avcIdx']) : 0;
$userIdx = isset($_POST['userIdx']) ? intval($_POST['userIdx']) : 0;
$isPrimary = isset($_POST['isPrimary']) ? intval($_POST['isPrimary']) : 0;

if ($avcIdx <= 0 || $userIdx <= 0) {
    echo "0x00000001"; // Invalid parameters
    exit;
}

try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Call the stored procedure
    $query = "CALL SP_AddCourseInstructor(?, ?, ?)";
    $DBCONNECTION->prepare_execute_catch_error($query, [$avcIdx, $userIdx, $isPrimary]);

    echo "0x11111111"; // Success

} catch (mysqli_sql_exception $e) {
    $errorMessage = $e->getMessage();

    // Check if it's our custom error code
    if (strpos($errorMessage, '0x00000002') !== false) {
        echo "0x00000002"; // Instructor already assigned
    } else {
        error_log("Error adding instructor: " . $errorMessage);
        echo "0x00000500"; // Database error
    }
} catch (Exception $e) {
    error_log("Error adding instructor: " . $e->getMessage());
    echo "0x00000000"; // General error
}

//
//include_once 'session_handler.php';
//
//$avcIdx = isset($_POST['avcIdx']) ? intval($_POST['avcIdx']) : 0;
//$userIdx = isset($_POST['userIdx']) ? intval($_POST['userIdx']) : 0;
//$isPrimary = isset($_POST['isPrimary']) ? intval($_POST['isPrimary']) : 0;
//
//if ($avcIdx <= 0 || $userIdx <= 0) {
//    echo "0x00000001"; // Invalid parameters
//    exit;
//}
//
//try {
//    require_once(__DIR__ . '/php_include/dbconnection_class.php');
//    $DBCONNECTION = new Dbconnection();
//
//    // Check if this instructor is already assigned to this course
//    $checkQuery = "SELECT COUNT(*) as count FROM `AVCoursesInstructors`
//                   WHERE `AVCourseIdx` = ? AND `Instructor` = ?";
//    $checkResult = $DBCONNECTION->prepare_execute_catch_error($checkQuery, [$avcIdx, $userIdx]);
//    $checkRow = $checkResult->fetch_assoc();
//
//    if ($checkRow['count'] > 0) {
//        echo "0x00000002"; // Instructor already assigned
//        exit;
//    }
//
//    // Insert new instructor
//    $insertQuery = "INSERT INTO `AVCoursesInstructors`
//                   (`AVCourseIdx`, `Instructor`)
//                   VALUES (?, ?)";
//    $DBCONNECTION->prepare_execute_catch_error($insertQuery, [$avcIdx, $userIdx]);
//
//    // Update the Instructor field in AVCourses table
//    updateCourseInstructorField($DBCONNECTION, $avcIdx, $userIdx, $isPrimary);
//
//    echo "0x11111111"; // Success
//
//} catch (mysqli_sql_exception $e) {
//    error_log("Error adding instructor: " . $e->getMessage());
//    echo "0x00000500"; // Database error
//} catch (Exception $e) {
//    error_log("Error adding instructor: " . $e->getMessage());
//    echo "0x00000000"; // General error
//}
//
//function updateCourseInstructorField($DBCONNECTION, $avcIdx, $primaryUserIdx = 0, $setPrimary = 0) {
//    // Get all instructors for this course with their names
//    $query = "SELECT ua.`Name`, ua.`Email`
//              FROM `AVCoursesInstructors` aci
//              LEFT JOIN `UserAccounts` ua ON aci.`Instructor` = ua.`Idx`
//              WHERE aci.`AVCourseIdx` = ?
//              ORDER BY ua.`Name` ASC";
//    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$avcIdx]);
//
//    $instructorNames = [];
//    $primaryEmail = '';
//
//    while ($row = $result->fetch_assoc()) {
//        if ($row['Name']) {
//            $instructorNames[] = $row['Name'];
//        }
//    }
//
//    // Determine primary instructor email
//    if ($setPrimary == 1 && $primaryUserIdx > 0) {
//        // Get email of the new primary instructor
//        $emailQuery = "SELECT `Email` FROM `UserAccounts` WHERE `Idx` = ?";
//        $emailResult = $DBCONNECTION->prepare_execute_catch_error($emailQuery, [$primaryUserIdx]);
//        $emailRow = $emailResult->fetch_assoc();
//        if ($emailRow) {
//            $primaryEmail = $emailRow['Email'];
//        }
//    } else {
//        // Keep existing primary email
//        $currentEmailQuery = "SELECT `InstructorEmail` FROM `AVCourses` WHERE `Idx` = ?";
//        $currentEmailResult = $DBCONNECTION->prepare_execute_catch_error($currentEmailQuery, [$avcIdx]);
//        $currentEmailRow = $currentEmailResult->fetch_assoc();
//        if ($currentEmailRow) {
//            $primaryEmail = $currentEmailRow['InstructorEmail'];
//        }
//    }
//
//    $instructorString = implode(', ', $instructorNames);
//
//    // Update AVCourses table
//    $updateQuery = "UPDATE `AVCourses`
//                   SET `Instructor` = ?, `InstructorEmail` = ?
//                   WHERE `Idx` = ?";
//    $DBCONNECTION->prepare_execute_catch_error($updateQuery, [$instructorString, $primaryEmail, $avcIdx]);
//}
