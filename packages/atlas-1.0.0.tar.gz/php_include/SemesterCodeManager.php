<?php

class SemesterCodeManager
{
    private $config;

    public function __construct(SemesterCodeConfig $config)
    {
        $this->config = $config;
    }

    /**
     * Get current semester code
     */
    public function getCurrentSemesterCode()
    {
        $year = (int)date('Y');
        $month = (int)date('m');

        $semester = $this->determineSemester($month);
        return $this->buildSemesterCode($year, $semester);
    }

    /**
     * Get semester code from X years ago
     */
    public function getSemesterCode($yearsOffset = 0)
    {
        $year = (int)date('Y') - $yearsOffset;
        $month = (int)date('m');

        $semester = $this->determineSemester($month);
        return $this->buildSemesterCode($year, $semester);
    }

    /**
     * Determine which semester based on current month
     * Uses the configured pattern's month ranges
     */
    private function determineSemester($month)
    {
        $ranges = $this->config->getMonthRanges();

        foreach ($ranges as $range) {
            if ($month >= $range['start'] && $month <= $range['end']) {
                return $range['semester'];
            }
        }

        // Fallback - should not happen with proper configuration
        throw new RuntimeException("Could not determine semester for month: $month");
    }

    /**
     * Build semester code from year and semester name
     */
    private function buildSemesterCode($year, $semester)
    {
        $pattern = $this->config->getPattern();

        if (!isset($pattern[$semester])) {
            throw new RuntimeException("Unknown semester: $semester");
        }

        $semesterCode = $pattern[$semester];
        $yearOffset = $pattern['year_offset'][$semester];

        return ($year + $yearOffset) . $semesterCode;
    }

    /**
     * Parse semester code into readable format
     * Uses the configured pattern to decode
     */
    public function parseSemesterCode($code)
    {
        if (strlen($code) < 6) {
            throw new InvalidArgumentException("Invalid semester code: $code");
        }

        $year = (int)substr($code, 0, 4);
        $semesterCode = substr($code, 4, 2);

        $pattern = $this->config->getPattern();

        // Find semester name by code
        $semesterName = null;
        foreach ($pattern as $name => $code_value) {
            if ($name === 'year_offset') continue;
            if ($code_value === $semesterCode) {
                $semesterName = $name;

                // Adjust year based on offset
                $year -= $pattern['year_offset'][$name];
                break;
            }
        }

        if ($semesterName === null) {
            throw new RuntimeException("Could not parse semester code: $code");
        }

        return [
            'year' => $year,
            'semester' => ucfirst($semesterName),
            'display' => ucfirst($semesterName) . ' ' . $year,
            'code' => $code,
        ];
    }

    /**
     * Get academic year string
     * Academic year typically runs Fall -> Summer
     */
    public function getAcademicYear()
    {
        $year = (int)date('Y');
        $month = (int)date('m');

        $semester = $this->determineSemester($month);

        // Fall semester starts the new academic year
        if ($semester === 'fall') {
            return $year . '-' . ($year + 1);
        } else {
            // All other semesters are in academic year that started in previous fall
            return ($year - 1) . '-' . $year;
        }
    }
}