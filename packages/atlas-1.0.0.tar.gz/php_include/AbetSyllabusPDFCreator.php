<?php

class AbetSyllabusPDFCreator {
    private const BASE_PATH = __DIR__;

    private $dbConnection;
    private $abetSyllabusIdx;
    private $abetSyllabusFile;
    private $academicYearIdx;
    private $academicProgramIdx;
    private $data;
    private $display; // 0 or 1 : display || 2 : saving to a local folder

    public function __construct($abetSyllabusIdx, $abetSyllabusFile, $academicYearIdx, $academicProgramIdx, $display = 0) {
        require_once self::BASE_PATH .'/dbconnection_class.php';
        require_once self::BASE_PATH .'/listfunc.php';
        require_once self::BASE_PATH .'/mail_attachment.php';
        require_once self::BASE_PATH . '/LatexTemplate.php';

        $this->dbConnection = new Dbconnection();
        $this->abetSyllabusIdx = $abetSyllabusIdx;
        $this->abetSyllabusFile = $abetSyllabusFile;
        $this->academicYearIdx = $academicYearIdx;
        $this->academicProgramIdx = $academicProgramIdx;
        $this->display = $display;
        $this->data = [];
    }

    public function createPDF() {
        try {
            $this->fetchBasicInfo();
            $this->fetchStudentOutcomes();
            $this->fetchPerformanceIndicators();
            $this->fetchRevisionHistory();
            $this->processData();

            LatexTemplate::createPDF($this->data, 'create_abetsyllabus_pdf.tex', $this->abetSyllabusFile, $this->display);
        } catch (mysqli_sql_exception $e) {
            error_log(json_encode([
                'success' => false,
                'error' => $e->getMessage(),
                'errorCode' => '0x00000500'
            ]));
        } catch (Exception $e) {
            error_log($e->getMessage());
            exit;
        }
    }

    public function createLatex() {
        try {
            $this->fetchBasicInfo();
            $this->fetchStudentOutcomes();
            $this->fetchPerformanceIndicators();
            $this->fetchRevisionHistory();
            $this->processData();

            $this->data['logo'] = __UNIV_COLLEGE_LOGO;

            LatexTemplate::createLatex($this->data, 'create_abetsyllabus_pdf.tex', $this->abetSyllabusFile, $this->display);

        } catch (mysqli_sql_exception $e) {
            error_log(json_encode([
                'success' => false,
                'error' => $e->getMessage(),
                'errorCode' => '0x00000500'
            ]));
        } catch (Exception $e) {
            error_log($e->getMessage());
            exit;
        }
    }

    private function fetchBasicInfo() {
        $results = $this->dbConnection->callStoredProcedure('SP_AbetSyllabus_FetchInfo', [$this->abetSyllabusIdx]);
        if ($results) {
            $this->data = $results->fetch_assoc();

            if ($this->abetSyllabusFile == null)
                $this->abetSyllabusFile = getAbetSyllabusFileName($this->data['Subject'], $this->data['Num']);
        }
    }

    private function fetchStudentOutcomes() {
        $results = $this->dbConnection->callStoredProcedure('SP_AbetSyllabus_FetchSOs', [
            $this->data['CourseIndex'],
            $this->abetSyllabusIdx,
            $this->academicYearIdx,
            $this->academicYearIdx,
            $this->academicProgramIdx
        ]);

        if ($results) {
            $SOs = '';
            while ($row = $results->fetch_assoc()) {
                if ($SOs != '') $SOs .= "||";
                $SOs .= "- " . $row['SO'] . " " . $row['Description'];
                if ($row['Comments'] != '') {
                    $this->data['SOsRevision'][] = [
                        'SO' => $row['SO'],
                        'Comments' => $row['Comments'],
                        'Approval' => $row['Approval']
                    ];
                }
            }
            $this->data['SOs'] = $SOs;
        }
    }

    private function fetchPerformanceIndicators() {
        $results = $this->dbConnection->callStoredProcedure('SP_AbetSyllabus_FetchPIs', [
            $this->data['CourseIndex'],
            $this->abetSyllabusIdx,
            $this->academicYearIdx,
            $this->academicYearIdx,
            $this->academicProgramIdx
        ]);

        if ($results) {
            $PIs = '';
            while ($row = $results->fetch_assoc()) {
                if ($PIs != '') $PIs .= "||";
                $PIs .= "- " . $row['SO'] . "-" . $row['GPI'] . " ". $row['Description'];
                if ($row['Comments'] != '') {
                    $this->data['PIsRevision'][] = [
                        'PI' => $row['SO']."-".$row['GPI'],
                        'Comments' => $row['Comments'],
                        'Approval' => $row['Approval']
                    ];
                }
            }
            $this->data['PIs'] = $PIs;
        }
    }

    private function fetchRevisionHistory() {
        $results = $this->dbConnection->callStoredProcedure('SP_AbetSyllabus_FetchRevisionHistory', [
            $this->data['CourseIndex'],
            $this->academicProgramIdx
        ]);

        if ($results) {
//            while ($row = $results->fetch_assoc()) {
//                $this->data['history_data'][] = $row;
//            }
            while ($row = $results->fetch_assoc()) {
                // Decode HTML entities in each field
                foreach ($row as $key => $value) {
                    if (is_string($value)) {
                        $row[$key] = LatexTemplate::plainTextToLatex(html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
                    }
                }
                $this->data['history_data'][] = $row;

            }
        }
    }

    private function processData() {
        $this->data['logo'] = __UNIV_COLLEGE_LOGO_PATH__;

        $fields = [
            'Title', 'Description', 'Pre_requisites', 'Co_requisites',
            'ObjectivesHeadline', 'Objectives', 'TopicsCoveredHeadline', 'TopicsCovered'
        ];

        foreach ($fields as $field) {
            $this->data[$field] = html_entity_decode($this->data[$field], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $this->data[$field] = LatexTemplate::replaceSpecialCharacters($this->data[$field]);
            $this->data[$field] = LatexTemplate::plainTextToLatex($this->data[$field]);
        }

        $this->data['Required_Texts'] = LatexTemplate::processTextWithUrls($this->data['Required_Texts']);
        $this->data['Reference_Texts'] = LatexTemplate::processTextWithUrls($this->data['Reference_Texts']);
        $this->data['Objectives'] = LatexTemplate::processTextWithUrls($this->data['Objectives']);
        $this->data['TopicsCovered'] = LatexTemplate::processTextWithUrls($this->data['TopicsCovered']);

        $this->data['Pre_requisites'] = convertTextLatexList($this->data['Pre_requisites'], 'itemize');
        $this->data['Co_requisites'] = convertTextLatexList($this->data['Co_requisites'], 'itemize');
        $this->data['Objectives'] = convertToLatexNestedList($this->data['Objectives']);
        $this->data['TopicsCovered'] = convertToLatexNestedList($this->data['TopicsCovered']);
        $this->data['SOs'] = convertTextLatexList($this->data['SOs'], 'itemize');
        $this->data['PIs'] = convertTextLatexList($this->data['PIs'], 'itemize');
        $this->data['Required_Texts'] = convertTextLatexList($this->data['Required_Texts'], 'itemize');
        $this->data['Reference_Texts'] = convertTextLatexList($this->data['Reference_Texts'], 'itemize');
    }

    private function generatePDF() {
        LatexTemplate::createPDF($this->data, 'create_abetsyllabus_pdf.tex', $this->abetSyllabusFile, $this->display);
    }
}