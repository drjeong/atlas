<?php
/**
 * Assign PI
 * Description: assign PI to the selected ABET course
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$AbetCourseIdxes='';
$AcademicYear='';
$GeneralPerformanceIndicators='';

if (array_key_exists('ay', $_POST) && array_key_exists('gpi', $_POST) && array_key_exists('abetcrs', $_POST))
{
    $AcademicYear = trim($_POST['ay']);
    $GeneralPerformanceIndicators = trim($_POST['gpi']);
    $AbetCourseIdxes = trim($_POST['abetcrs']);
} else {
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYear=="" || $AcademicProgram=="" || $GeneralPerformanceIndicators=="" || $AbetCourseIdxes==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYear = filter_var($AcademicYear, FILTER_VALIDATE_INT);
    if ($AcademicYear === false) {
        throw new Exception('Invalid Academic Year format');
    }

    $AbetCourseIdxes_Array = explode( '|', $AbetCourseIdxes );
    $PIs_Array = explode( '|', $GeneralPerformanceIndicators );

    // Single query with parameters
    $query = "CALL SP_AddAbetCoursePI(?, ?, ?, ?, ?, ?);";

    // Execute each combination separately
    foreach ($AbetCourseIdxes_Array as $AbetCourseIdx) {
        foreach ($PIs_Array as $PIs) {
            $res = explode('_', $PIs); // $PI[0] -  AbetCourses_SOs index, $PI[1] -  GPI index, $PI[2] - true / false indicator
            $SOIdx = $res[0]; // Idx in AbetCourses_SOs
            $PIIdx = $res[1];
            $PIChecked = $res[2];

            $params = [
                $PIIdx,
                $AbetCourseIdx,
                $SOIdx,
                $AcademicYear,
                $AcademicProgram,
                $PIChecked
            ];

            $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);
            if ($result === null) {
                throw new Exception('Query execution failed');
            }
        }
    }

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    error_log($DBCONNECTION->FormatQuery($query, $params));

    echo "0x00000000";
}
