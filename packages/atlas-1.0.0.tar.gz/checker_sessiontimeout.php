<?php
/**
 * Session Time Out
 * Description: checking session time out
 *
 * 01/28/2025 - update on session checking
 *
 */

// Define timeout duration (in seconds)
define('SESSION_TIMEOUT', 3600); // 60 minutes

function SessionTimeOut()
{
    if (!isset($_SESSION['ATLAS_LASTCONNECTEDTIME'])) {
        // First visit - initialize the timestamp
        $_SESSION['ATLAS_LASTCONNECTEDTIME'] = time();
        return false;
    }

    $timeout = isset($_SESSION['ATLAS_TIMEOUT']) ? $_SESSION['ATLAS_TIMEOUT'] : SESSION_TIMEOUT;

    $current = time();
    $diff = $current - $_SESSION['ATLAS_LASTCONNECTEDTIME'];

    if ($diff > $timeout) {
        return true;
    }

    return false;
}

// Check if this is an AJAX request
$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
    strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

if (!isset($_SESSION['ATLAS_LOGIN_USERIDX']) || SessionTimeOut()) {
    session_unset();
    session_destroy();

    // If AJAX request, return JSON response
    if ($isAjax) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Session expired', 'redirect' => 'index.php']);
        exit;
    }

    // Otherwise, show the HTML page
    echo <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="refresh" content="5; URL=index.php">
    <style>
        .alert {
            background-color: white;
            font-family: 'Open Sans', sans-serif;
            width: 90%;
            max-width: 478px;
            padding: 17px;
            border-radius: 5px;
            text-align: center;
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #575757;
            font-size: 30px;
            text-align: center;
            font-weight: 600;
            margin: 25px 0;
            padding: 0;
            line-height: 25px;
        }
        p {
            color: #797979;
            font-size: 16px;
            text-align: center;
            font-weight: 300;
            margin: 0;
            padding: 0;
            line-height: normal;
        }
        #countdown {
            color: #575757;
            font-size: 20px;
            margin: 15px 0;
        }
        button {
            background-color: #AEDEF4;
            color: white;
            border: none;
            box-shadow: none;
            font-size: 17px;
            font-weight: 500;
            border-radius: 5px;
            padding: 10px 32px;
            margin: 26px 5px 0 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:focus {
            outline: none;
            box-shadow: 0 0 2px rgba(128, 179, 235, 0.5), inset 0 0 0 1px rgba(0, 0, 0, 0.05);
        }
        button:hover {
            background-color: #a1d9f2;
        }
        button:active {
            background-color: #81ccee;
        }
    </style>
</head>
<body style='background-color:gray'>
    <div class='alert'>
        <br/><br/>
        <img src='./images/msg_error.jpg' width='100' alt='Error'><br/>
        <h2>Warning!</h2>
        <p>Session finished, please log in again</p>
        <div id='countdown'>Redirecting in 5 seconds...</div>
        <button class='cancel' onclick='window.location.assign("./index.php"); return false;'>OK</button>
    </div>

    <script>
        let timeLeft = 5;
        const countdownElement = document.getElementById('countdown');
        
        const countdown = setInterval(() => {
            timeLeft--;
            countdownElement.textContent = `Redirecting in \${timeLeft} seconds...`;
            if (timeLeft <= 0) {
                clearInterval(countdown);
            }
        }, 1000);
    </script>
</body>
</html>
HTML;

    exit;
}

// Update session time IMMEDIATELY after successful check
$_SESSION['ATLAS_LASTCONNECTEDTIME'] = time();
