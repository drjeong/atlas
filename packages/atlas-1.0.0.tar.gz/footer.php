<?php
/**
 * Footer
 * Description: displaying information about the system on the footer.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2021 - initial version created
 */

?>

<table style="vertical-align: top; border-spacing:0; padding:0; width:100%;">
    <tr>
        <td width="100%" align="center" valign="bottom">
            <div class=footer>
            <span lang=EN-US style='font-size:8.0pt;font-family:Arial;color:#ffffff; text-shadow: 2px 2px 4px #000000;'>
                ATLAS: Academic Tracking & Learning Assessment System Ver. 1.5.1 <br/>
                <?php
                    require_once(__DIR__ . '/../config.php');
                    echo (__UNIV_NAME__ . '<br/>');
                    echo (__UNIV_ADDRESS__ . '<br/>');
                ?>
                Copyright &copy; 2020~<?php echo(date("Y",time()));?> All Rights Reserved</span>
            </div>
        </td>
    </tr>
</table>


<script>
    // Global AJAX error handler for session timeout
    $(document).ajaxError(function(event, jqxhr, settings, thrownError) {
        if (jqxhr.status === 401) {
            let timerInterval;
            Swal.fire({
                title: 'Session Expired',
                html: 'Your session has expired. Redirecting to login in <b></b> seconds.',
                icon: 'warning',
                timer: 5000,
                timerProgressBar: true,
                allowOutsideClick: false,
                allowEscapeKey: false,
                confirmButtonText: 'Login Now',
                didOpen: () => {
                    const b = Swal.getHtmlContainer().querySelector('b');
                    timerInterval = setInterval(() => {
                        b.textContent = Math.ceil(Swal.getTimerLeft() / 1000);
                    }, 100);
                },
                willClose: () => {
                    clearInterval(timerInterval);
                }
            }).then((result) => {
                window.location.href = 'index.php';
            });
        }
    });
</script>

</body>
</html>


<?php
//echo('session time updated: '. $_SESSION['ATLAS_LASTCONNECTEDTIME']);

/**
 * ABET Course Assessment - Version history
 * 1.0.000 -- initial release (02/28/2021)
 * 1.0.001 -- bug fix in selecting options in User account management page (03/01/2021)
 * 1.0.002 -- bug fix in modifying PI in PI page (03/02/2021)
 * 1.0.003 -- change GPI to PI (04/11/2021)
 * 1.0.004 -- PDF creation, entering evaluator's reflections (03/24/2024)
 * 1.0.005 -- Supporting assistants to enter course assessments materials (09/23/2024)
 * 1.5.001 -- Adding syllabus creation (10/02/2024)
 * 1.5.002 -- Adding all ABET courses SO/PI mapping (01/02/2025)
 * 1.5.101 -- Change Menu layout, Add cross-program course evaluation with uploading student roster (01/02/2026)
 */