<?php
/**
 * Add Performance Indicator
 * Description: adding GPI to DB
 * Author: Dong Hyun Jeong
 *
 * 02/21/2021 - initial version created
 * 03/02/2021 - GPI saving routine is changed to use a MySQL stored procedure
 *
 */

include_once 'session_handler.php';

$AcademicYearIdx='';
$SOIdx='';
$PI='';
$Description='';

if (array_key_exists('ay', $_POST) && array_key_exists('so', $_POST)
    && array_key_exists('pi', $_POST) && array_key_exists('desc', $_POST))
{
    $AcademicYearIdx = trim($_POST['ay']);
    $SOIdx = trim($_POST['so']);
    $PI = trim($_POST['pi']);
    $Description = trim($_POST['desc']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYearIdx=="" || $SOIdx=="" || $PI=="" || $Description=="" || $AcademicProgram==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    //  Convert character encodings
    require_once(__DIR__ . '/php_include/listfunc.php');
    $Description = convertSpecialCharacters($Description);

    // convert unwanted escape strings
    $SOIdx = $DBCONNECTION->real_escape_string($SOIdx);
    $PI = $DBCONNECTION->real_escape_string($PI);
    $Description = $DBCONNECTION->real_escape_string($Description);

    /////////////////////////////////////////////////////////////////////////////////
    // insert PI
    $query = "CALL SP_AddPI(?, ?, ?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$AcademicYearIdx, $SOIdx, $PI, $Description, $AcademicProgram]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00200011') !== false) {
        echo '0x00200011';  // PI exists already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

