<?php
/**
 * Listing Rubrics
 * File: u_course_rubrics_ssps.php
 * Description: listing rubrics of the selected course
 *
 *
 *
 */

include_once 'session_handler.php';

$AbetCourseIdx='';
$AvailableCourseIdx='';
$AcademicProgramIdx='';
if (array_key_exists('_ABTC', $_GET) && array_key_exists('_AVC', $_GET) && array_key_exists('_AP', $_GET)) {
    $AbetCourseIdx = trim($_GET['_ABTC']);
    $AvailableCourseIdx = trim($_GET['_AVC']);
    $AcademicProgramIdx = trim($_GET['_AP']);
}
else {
    // illegal entry
    exit;
}

// DB table to use
$table = 'AssessmentMeasures';
$joinQuery = "FROM `$table` AS `ASSMNTEXMPLES` 
    INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ASSMNTEXMPLES`.`GPI` AND `GPIS`.`AcademicProgram`='$AcademicProgramIdx') 
    INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`='$AcademicProgramIdx') 
    INNER JOIN `AssessmentMasterRubrics` AS `ASSMNTMSTRRBRICS` ON (`GPIS`.`Idx`=`ASSMNTMSTRRBRICS`.`GPIIdx`)";

// Table's primary key
$primaryKey = '`ASSMNTEXMPLES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`ASSMNTEXMPLES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`ASSMNTEXMPLES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`ASSMNTEXMPLES`.`Measure`', 'dt' => 'Measure', 'field' => 'Measure', 'as' => 'Measure'),
    array( 'db' => '`ASSMNTEXMPLES`.`GPI`', 'dt' => 'GPIIdx', 'field' => 'GPIIdx', 'as' => 'GPIIdx'),
    array( 'db' => '`GPIS`.`Description`', 'dt' => 'GPIDescription', 'field' => 'GPIDescription', 'as' => 'GPIDescription'),
    array( 'db' => '`ASSMNTEXMPLES`.`AssignmentType`', 'dt' => 'AssignmentType', 'field' => 'AssignmentType', 'as' => 'AssignmentType'),
    array( 'db' => '`ASSMNTEXMPLES`.`AssignmentNum`', 'dt' => 'AssignmentNum', 'field' => 'AssignmentNum', 'as' => 'AssignmentNum'),
    array( 'db' => '`ASSMNTEXMPLES`.`AssignmentProblem`', 'dt' => 'AssignmentProb', 'field' => 'AssignmentProb', 'as' => 'AssignmentProb'),
    array( 'db' => 'CONCAT_WS(\'-\',`STNTOUTCMS`.`SO`, `GPIS`.`GPI`)', 'dt' => 'GPI', 'field' => 'GPI', 'as' => 'GPI'),
    array( 'db' => '`ASSMNTEXMPLES`.`AssignmentDescription`', 'dt' => 'AssignmentDesc', 'field' => 'AssignmentDesc', 'as' => 'AssignmentDesc'),
    array( 'db' => 'GROUP_CONCAT(`ASSMNTMSTRRBRICS`.`Description` ORDER BY `ASSMNTMSTRRBRICS`.`LevelofAttainment` SEPARATOR \'|\')', 'dt' => 'LOA', 'field' => 'LOA', 'as' => 'LOA'),
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "`ASSMNTEXMPLES`.`AvailableCourseIdx` = '$AvailableCourseIdx'";
$extraWhere .= " AND `ASSMNTEXMPLES`.`AbetCourseIdx`= '$AbetCourseIdx'";
$groupBy = " `ASSMNTEXMPLES`.`Idx` ";


require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
