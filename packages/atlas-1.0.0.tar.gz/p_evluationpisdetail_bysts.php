<?php
/**
 * Evaluation of Performance Indicators
 * Description: Listing the summary of performance indicators evaluation
 *
 *
 */
?>


<?php
include('header.php');

if ( (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM']) || !isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'])) &&
    isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']) ) {
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearsSelection = AcademicYearsSelection($multipleSelection = true, $visibleTogglebutton = false);

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

?>

    <script type="text/javascript">

        $(document).ready(function() {

            // Add event listener to the select element
            $("#_AY").on('change', function() {
                document.academicyear.submit();
            });

            // Add event listeners for changes in both selects
            $("#_AY_FROM").on("change", function () {
                let fromYear = parseInt($("#_AY_FROM").val());
                let toYear = parseInt($("#_AY_TO").val());

                if (fromYear > toYear) {
                    Swal.fire({
                        title: "Warning",
                        text: "The 'From' year cannot be greater than the 'To' year. Setting 'To' year to match 'From' year.",
                        icon: "warning",
                        timer: 2000
                    }).then(() => {
                        $("#_AY_TO").val(fromYear); // Set "To" to match "From"
                        document.academicyear.submit();
                    });
                } else {
                    document.academicyear.submit();
                }
            });

            $("#_AY_TO").on("change", function () {
                let fromYear = parseInt($("#_AY_FROM").val());
                let toYear = parseInt($("#_AY_TO").val());

                if (toYear < fromYear) {
                    Swal.fire({
                        title: "Warning",
                        text: "The 'To' year cannot be less than the 'From' year. Setting 'From' year to match 'To' year.",
                        icon: "warning",
                        timer: 2000
                    }).then(() => {
                        $("#_AY_FROM").val(toYear); // Set "From" to match "To"
                        document.academicyear.submit();
                    });
                } else {
                    document.academicyear.submit();
                }
            });

        });
    </script>

    <div class="pagebacklayout">
        <div class="row">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">EVALUATION OF PERFORMANCE INDICATORS (DETAIL)</span></p>
            <p style="text-align:center;font-size:13px;color:#0c5460;margin-top:5px;padding:10px;background-color:#d1ecf1;border-left:4px solid #17a2b8;font-style:italic;">
                <strong>Note:</strong> Average score is calculated as the sum of all students' scores divided by the <span style="color:#d9534f;font-weight:bold;">total number of students</span>.
            </p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <?php include('control_allprograms.php'); ?>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:100%;">
                        <?php echo($AcademicYearsSelection);?>
                    </td>
                </tr>
            </table>


            <div class='col-md-12'>
                <!-- Page Content -->
                <div id="pagebacklayout_inner_noborder">

                    <div class="CSSTable_SSPSLIST">
                        <?php
                        displayCoreElectiveData();
                        ?>
                    </div>
                    <!-- /#page-content-wrapper -->
                </div>


            </div>
        </div>

    </div>


<?php include('footer.php');?>


<?php
function displayCoreElectiveData() {
    ?>
    <script>
        $(document).ready(function() {
            const varSelectedAcademicYear_From = $("#_AY_FROM option:selected").text();
            const varSelectedAcademicYear_To = $("#_AY_TO option:selected").text();
            const szURL = 'ssps/p_evluationdetail_bysts_ssps.php';
            $.ajax({
                url: szURL,
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (!response.data || response.data.length === 0) {
                        $('#soTablesContainer').html('<div style="text-align:center;padding:20px;">No data available</div>');
                        return;
                    }
                    generateSOTables(response, varSelectedAcademicYear_From, varSelectedAcademicYear_To);
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    console.error('Response:', xhr.responseText);
                }
            });

            // Toggle calculation details
            $(document).on('click', '.toggle-calc-btn', function() {
                const soNumber = $(this).data('so');
                const detailsRow = $('#calc-details-' + soNumber);
                const isVisible = detailsRow.is(':visible');

                if (isVisible) {
                    detailsRow.hide();
                    $(this).html('&#9658; Show Calculation Details');
                    $(this).removeClass('btn-active');
                } else {
                    detailsRow.show();
                    $(this).html('&#9660; Hide Calculation Details');
                    $(this).addClass('btn-active');
                }
            });

            function generateSOTables(response, yearFrom, yearTo) {
                const studentOutcomes = response.studentOutcomes;
                const data = response.data;
                const requirements = response.requirements || [];

                // Identify Core and non-Core requirements
                const coreRequirement = requirements.find(req => req === 'Core') || null;
                const electiveRequirements = requirements.filter(req => req !== 'Core');

                let tablesHTML = '';
                // Process each Student Outcome
                for (let so in studentOutcomes) {
                    const soData = studentOutcomes[so];
                    const soNumber = so.replace('SO ', '');
                    tablesHTML += `<div class="so-table-container">`;
                    tablesHTML += `<h4 style="text-align:center; font-weight: bold; margin-bottom:20px;">Student Outcome ${soNumber} Assessment Results</h4>`;
                    tablesHTML += `<table class="so-assessment-table">`;
                    // SO Description Header
                    tablesHTML += `<tr class="header-row">`;
                    tablesHTML += `<td colspan="2"><strong>Student Outcome ${soNumber}:</strong> ${soData.description}</td>`;
                    tablesHTML += `</tr>`;
                    tablesHTML += `<tr class="separator-row"><td colspan="2"></td></tr>`;
                    // Performance Indicators Section
                    tablesHTML += `<tr class="section-header"><td colspan="2"><strong>Performance Indicators:</strong></td></tr>`;
                    const pis = [...new Set(soData.gpis.map(gpi => gpi.code))];
                    pis.forEach(piCode => {
                        const piData = soData.gpis.find(g => g.code === piCode);
                        const piDesc = piData ? piData.description : `Performance Indicator ${piCode}`;
                        tablesHTML += `<tr>`;
                        tablesHTML += `<td class="pi-code"><strong>SO${soNumber}-${piCode}</strong></td>`;
                        tablesHTML += `<td class="pi-description">${piDesc}</td>`;
                        tablesHTML += `</tr>`;
                    });
                    tablesHTML += `<tr class="separator-row"><td colspan="2"></td></tr>`;

                    // Courses Involved Section - REVISED to show unique course numbers
                    tablesHTML += `<tr class="section-header"><td colspan="2"><strong>Courses Involved:</strong></td></tr>`;
                    const coursesByPI = {};
                    pis.forEach(piCode => {
                        const gpiIndices = getGPIIndicesForPI(studentOutcomes, so, piCode);
                        const coursesForPI = new Set();
                        data.forEach(course => {
                            gpiIndices.forEach(gpiIdx => {
                                const columnKey = 'SOSO ' + soNumber + '_GPI' + gpiIdx;
                                if (course[columnKey] && parseFloat(course[columnKey]) > 0) {
                                    // Only add course number (not the full key with AbetCourseIdx)
                                    coursesForPI.add(course.courseNo);
                                }
                            });
                        });
                        coursesByPI[piCode] = Array.from(coursesForPI).sort();
                    });
                    pis.forEach(piCode => {
                        const courses = coursesByPI[piCode] || [];
                        tablesHTML += `<tr>`;
                        tablesHTML += `<td class="pi-code"><strong>SO${soNumber}-${piCode}</strong></td>`;
                        tablesHTML += `<td class="course-list">${courses.join(', ')}</td>`;
                        tablesHTML += `</tr>`;
                    });
                    tablesHTML += `<tr class="separator-row"><td colspan="2"></td></tr>`;

                    // Average Scores Section
                    tablesHTML += `<tr class="section-header"><td colspan="2"><strong>Average Scores for Performance Indicators</strong></td></tr>`;
                    const avgScoresByPI = {};
                    const calculationDetails = {}; // Store calculation details
                    let totalSOScore = 0;
                    let totalPICount = 0;
                    pis.forEach(piCode => {
                        const gpiIndices = getGPIIndicesForPI(studentOutcomes, so, piCode);

                        // Calculate averages for each requirement type
                        const avgsByRequirement = {};
                        const detailsByRequirement = {};

                        requirements.forEach(req => {
                            const result = calculatePIAverageWithDetails(data.filter(c => c.requirement === req), so, gpiIndices, soNumber);
                            if (result.average !== '') {
                                avgsByRequirement[req] = result.average;
                                detailsByRequirement[req] = result.details;
                            }
                        });

                        avgScoresByPI[piCode] = avgsByRequirement;
                        calculationDetails[piCode] = detailsByRequirement;

                        // Build display string
                        let avgParts = [];
                        let hasAddedToTotal = false;

                        // Add Core first if it exists
                        if (coreRequirement && avgsByRequirement[coreRequirement]) {
                            avgParts.push(`${avgsByRequirement[coreRequirement]} (${coreRequirement})`);
                            totalSOScore += parseFloat(avgsByRequirement[coreRequirement]);
                            totalPICount++;
                            hasAddedToTotal = true;
                        }

                        // Add elective requirements
                        electiveRequirements.forEach(req => {
                            if (avgsByRequirement[req]) {
                                avgParts.push(`${avgsByRequirement[req]} (${req})`);
                                // Only add to total if Core wasn't already added
                                if (!hasAddedToTotal) {
                                    totalSOScore += parseFloat(avgsByRequirement[req]);
                                    totalPICount++;
                                    hasAddedToTotal = true;
                                }
                            }
                        });

                        if (avgParts.length > 0) {
                            tablesHTML += `<tr>`;
                            tablesHTML += `<td class="pi-code"><strong>SO${soNumber}-${piCode}</strong></td>`;
                            tablesHTML += `<td class="score-cell">${avgParts.join(', ')}</td>`;
                            tablesHTML += `</tr>`;
                        }
                    });
                    tablesHTML += `<tr class="separator-row"><td colspan="2"></td></tr>`;

                    // Overall SO Average
                    const overallAvg = totalPICount > 0 ? (totalSOScore / totalPICount).toFixed(2) : 'N/A';
                    tablesHTML += `<tr class="overall-average">`;
                    tablesHTML += `<td colspan="2">`;
                    tablesHTML += `<strong>Average Score (Core) for Student Outcome ${soNumber}:</strong> <span class="overall-score">${overallAvg}</span>`;
                    tablesHTML += `<button class="toggle-calc-btn" data-so="${soNumber}">&#9658; Show Calculation Details</button>`;
                    tablesHTML += `</td>`;
                    tablesHTML += `</tr>`;
                    tablesHTML += `<tr class="separator-row"><td colspan="2"></td></tr>`;

                    // ===== Calculation Details Section (Hidden by default) =====
                    tablesHTML += `<tr id="calc-details-${soNumber}" class="calculation-details-row" style="display: none;">`;
                    tablesHTML += `<td colspan="2" class="calculation-explanation">`;

                    let calcHTML = `<div class="calc-container">`;
                    calcHTML += `<h5 class="calc-header">How the Average is Computed:</h5>`;
                    calcHTML += `<div class="calc-steps">`;
                    calcHTML += `<p><strong>Step 1: Calculate Average for Each Performance Indicator</strong></p>`;

                    let piCalculations = [];
                    pis.forEach(piCode => {
                        const avgsByReq = avgScoresByPI[piCode];
                        const detailsByReq = calculationDetails[piCode];

                        if (Object.keys(avgsByReq).length === 0) return;

                        calcHTML += `<div class="pi-calc-block">`;
                        calcHTML += `<p class="pi-calc-title"><strong>SO${soNumber}-${piCode}:</strong></p>`;

                        // Show calculation for each requirement type
                        Object.keys(avgsByReq).forEach(req => {
                            const details = detailsByReq[req];
                            calcHTML += `<div class="req-calc">`;
                            calcHTML += `<p><em>${req} courses:</em></p>`;
                            calcHTML += `<p class="calc-formula">${details.courseScoresWithNames.join(' + ')} = ${details.sum}</p>`;
                            calcHTML += `<p class="calc-formula">Average = ${details.sum} ÷ ${details.count} = <strong>${avgsByReq[req]}</strong></p>`;
                            calcHTML += `</div>`;
                        });

                        // Determine which value is used
                        let usedValue = '';
                        let usedReq = '';
                        if (coreRequirement && avgsByReq[coreRequirement]) {
                            usedValue = avgsByReq[coreRequirement];
                            usedReq = coreRequirement;
                            calcHTML += `<p class="used-value">✓ <strong>${usedValue}</strong> from ${usedReq} is used (Core takes priority)</p>`;
                        } else {
                            usedReq = Object.keys(avgsByReq)[0];
                            usedValue = avgsByReq[usedReq];
                            calcHTML += `<p class="used-value">✓ <strong>${usedValue}</strong> from ${usedReq} is used</p>`;
                        }

                        piCalculations.push({code: piCode, value: usedValue});
                        calcHTML += `</div>`;
                    });

                    calcHTML += `</div>`; // Close calc-steps

                    // Step 2: Calculate Overall Average
                    if (piCalculations.length > 0) {
                        calcHTML += `<div class="calc-steps" style="margin-top: 20px;">`;
                        calcHTML += `<p><strong>Step 2: Calculate Overall Student Outcome ${soNumber} Average (Core)</strong></p>`;
                        calcHTML += `<p class="calc-formula">`;
                        const piValues = piCalculations.map(p => p.value).join(' + ');
                        const piSum = piCalculations.reduce((sum, p) => sum + parseFloat(p.value), 0).toFixed(2);
                        calcHTML += `${piValues} = ${piSum}`;
                        calcHTML += `</p>`;
                        calcHTML += `<p class="calc-formula">`;
                        calcHTML += `Average = ${piSum} ÷ ${piCalculations.length} = <strong class="final-result">${overallAvg}</strong>`;
                        calcHTML += `</p>`;
                        calcHTML += `<p class="calc-note"><em>Note: When the same course number appears multiple times (e.g., different sections or terms), each offering is treated as a separate course in the calculation. Each Performance Indicator contributes exactly once to the overall average. When both Core and Elective data exist for a PI, only Core is used to avoid double-counting.</em></p>`;
                        calcHTML += `</div>`;
                    }

                    calcHTML += `</div>`; // Close calc-container
                    tablesHTML += calcHTML;
                    tablesHTML += `</td></tr>`;
                    tablesHTML += `<tr class="separator-row"><td colspan="2"></td></tr>`;
                    // ===== END: Calculation Details Section =====

                    // Actions To Be Taken Section
                    tablesHTML += `<tr class="section-header"><td colspan="2"><strong>Actions To Be Taken:</strong></td></tr>`;
                    pis.forEach(piCode => {
                        const gpiIndices = getGPIIndicesForPI(studentOutcomes, so, piCode);
                        const avgsByRequirement = avgScoresByPI[piCode];

                        // Skip if no data for this PI
                        if (Object.keys(avgsByRequirement).length === 0) {
                            return;
                        }

                        let actionText = `<strong>SO${soNumber}-${piCode} [Score `;
                        let scoreParts = [];

                        // Add Core first if it exists
                        if (coreRequirement && avgsByRequirement[coreRequirement]) {
                            scoreParts.push(`${avgsByRequirement[coreRequirement]} ${coreRequirement}`);
                        }

                        // Add elective requirements
                        electiveRequirements.forEach(req => {
                            if (avgsByRequirement[req]) {
                                scoreParts.push(`${avgsByRequirement[req]} ${req}`);
                            }
                        });

                        actionText += scoreParts.join(', ') + ']:</strong> ';

                        // Determine performance level (use Core if available, otherwise use first available)
                        let avgScore;
                        if (coreRequirement && avgsByRequirement[coreRequirement]) {
                            avgScore = parseFloat(avgsByRequirement[coreRequirement]);
                        } else {
                            avgScore = parseFloat(Object.values(avgsByRequirement)[0]);
                        }

                        if (avgScore >= 3.5) {
                            actionText += `The attainment of SO${soNumber} through this performance indicator exceeds the general expectation. `;
                        } else if (avgScore >= 3.0) {
                            actionText += `The attainment of SO${soNumber} through this performance indicator meets the general expectation. `;
                        } else {
                            actionText += `The attainment of SO${soNumber} through this performance indicator is below the general expectation. `;
                        }

                        // Add attainment data for each requirement type
                        requirements.forEach(req => {
                            const attainment = calculateAttainment(data.filter(c => c.requirement === req), so, gpiIndices, soNumber);
                            if (attainment.percent !== '') {
                                actionText += `${req} courses: ${attainment.percent}% (${attainment.above3}/${attainment.total}) of students have attained a score of 3.0 or more. `;
                            }
                        });

                        tablesHTML += `<tr class="action-row">`;
                        tablesHTML += `<td colspan="2" class="action-text">${actionText}</td>`;
                        tablesHTML += `</tr>`;
                    });
                    tablesHTML += `</table>`;
                    tablesHTML += `</div>`;
                }
                $('#soTablesContainer').html(tablesHTML);
            }

            // Modified function to return details with course names (handles multiple offerings)
            // Modified function to return details with course names and semester info
            function calculatePIAverageWithDetails(courses, so, gpiIndices, soNumber) {
                let totalSum = 0;
                let totalCount = 0;
                let courseScoresWithNames = [];

                for (let course of courses) {
                    let courseSum = 0;
                    let courseCount = 0;
                    for (let gpiIdx of gpiIndices) {
                        const columnKey = 'SOSO ' + soNumber + '_GPI' + gpiIdx;
                        const value = parseFloat(course[columnKey]);
                        if (!isNaN(value) && value > 0) {
                            courseSum += value;
                            courseCount++;
                        }
                    }
                    if (courseCount > 0) {
                        const courseAvg = (courseSum / courseCount);
                        totalSum += courseAvg;
                        totalCount++;

                        // Build course display with semester info AND CRN
                        let courseDisplay = course.courseNo;
                        if (course.crn) {
                            courseDisplay += ' (CRN: ' + course.crn + ')';
                        }
                        if (course.semesterDisplay && course.semesterDisplay.trim() !== '') {
                            courseDisplay += ' ' + course.semesterDisplay;
                        }

                        courseScoresWithNames.push(`${courseAvg.toFixed(2)} (${courseDisplay})`);
                    }
                }

                return {
                    average: totalCount > 0 ? (totalSum / totalCount).toFixed(2) : '',
                    details: {
                        courseScoresWithNames: courseScoresWithNames,
                        sum: totalSum.toFixed(2),
                        count: totalCount
                    }
                };
            }

            function calculatePIAverage(courses, so, gpiIndices, soNumber) {
                let totalSum = 0;
                let totalCount = 0;
                for (let course of courses) {
                    let courseSum = 0;
                    let courseCount = 0;
                    for (let gpiIdx of gpiIndices) {
                        const columnKey = 'SOSO ' + soNumber + '_GPI' + gpiIdx;
                        const value = parseFloat(course[columnKey]);
                        if (!isNaN(value) && value > 0) {
                            courseSum += value;
                            courseCount++;
                        }
                    }
                    if (courseCount > 0) {
                        totalSum += (courseSum / courseCount);
                        totalCount++;
                    }
                }
                return totalCount > 0 ? (totalSum / totalCount).toFixed(2) : '';
            }

            function calculateAttainment(courses, so, gpiIndices, soNumber) {
                let totalStudents = 0;
                let studentsAbove3 = 0;
                for (let course of courses) {
                    for (let gpiIdx of gpiIndices) {
                        const countKey = 'SOSO ' + soNumber + '_GPI' + gpiIdx + '_count';
                        const above3Key = 'SOSO ' + soNumber + '_GPI' + gpiIdx + '_above3';
                        const count = parseInt(course[countKey]) || 0;
                        const above3 = parseInt(course[above3Key]) || 0;
                        totalStudents += count;
                        studentsAbove3 += above3;
                    }
                }
                const percent = totalStudents > 0 ? ((studentsAbove3 / totalStudents) * 100).toFixed(2) : '';
                return {
                    percent: percent,
                    above3: studentsAbove3,
                    total: totalStudents
                };
            }

            function getGPIIndicesForPI(studentOutcomes, so, piCode) {
                return studentOutcomes[so].gpis
                    .filter(gpi => gpi.code === piCode)
                    .map(gpi => gpi.gpiIdx);
            }
        });
    </script>

    <!-- CSS remains the same -->
    <style>
        .so-table-container {
            margin-bottom: 40px;
            page-break-after: always;
        }
        .so-assessment-table {
            width: 100%;
            border-collapse: collapse;
            border: 2px solid #333;
            margin-bottom: 30px;
            background-color: white;
        }
        .so-assessment-table td {
            border: 1px solid #333;
            padding: 12px;
            vertical-align: top;
        }
        .so-assessment-table .header-row td {
            background-color: #f0f0f0;
            font-size: 14px;
            line-height: 1.6;
        }
        .so-assessment-table .section-header td {
            background-color: #e8e8e8;
            font-weight: bold;
            padding: 10px 12px;
        }
        .so-assessment-table .separator-row {
            background-color: #333;
            height: 2px;
        }
        .so-assessment-table .separator-row td {
            padding: 0;
            border: none;
            background-color: #333;
        }
        .so-assessment-table .pi-code {
            width: 2cm;
            font-weight: bold;
            white-space: nowrap;
        }
        .so-assessment-table .pi-description,
        .so-assessment-table .course-list,
        .so-assessment-table .score-cell {
            width: 13cm;
        }
        .so-assessment-table .overall-average td {
            background-color: #e3f2fd;
            font-weight: bold;
            font-size: 14px;
            position: relative;
        }
        .so-assessment-table .overall-score {
            background-color: #bbdefb;
            padding: 4px 12px;
            border-radius: 4px;
            margin-left: 10px;
            font-size: 16px;
        }
        .so-assessment-table .action-row td {
            padding: 15px;
        }
        .so-assessment-table .action-text {
            text-align: justify;
            line-height: 1.6;
        }

        /* Toggle button styles */
        .toggle-calc-btn {
            float: right;
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 8px 16px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 13px;
            font-weight: normal;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .toggle-calc-btn:hover {
            background-color: #1976D2;
            box-shadow: 0 3px 6px rgba(0,0,0,0.3);
        }
        .toggle-calc-btn.btn-active {
            background-color: #FF5722;
        }
        .toggle-calc-btn.btn-active:hover {
            background-color: #E64A19;
        }

        /* Calculation details styles */
        .calculation-details-row {
            display: none;
        }
        .calculation-explanation {
            background-color: #f9f9f9;
            padding: 20px;
            line-height: 1.8;
        }
        .calc-container {
            animation: slideDown 0.3s ease-out;
        }
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .calc-header {
            color: #1976D2;
            margin-top: 0;
            margin-bottom: 15px;
            font-size: 16px;
            border-bottom: 2px solid #2196F3;
            padding-bottom: 8px;
        }
        .calc-steps {
            margin-bottom: 15px;
        }
        .pi-calc-block {
            margin-left: 20px;
            margin-bottom: 15px;
            padding: 10px;
            background-color: #fff;
            border-left: 3px solid #2196F3;
        }
        .pi-calc-title {
            font-weight: bold;
            margin-bottom: 8px;
            color: #1976D2;
        }
        .req-calc {
            margin-left: 15px;
            margin-bottom: 10px;
        }
        .calc-formula {
            margin: 5px 0;
            font-family: 'Courier New', monospace;
            background-color: #f5f5f5;
            padding: 5px 10px;
            border-radius: 3px;
        }
        .used-value {
            margin-top: 10px;
            padding: 8px;
            background-color: #e8f5e9;
            border-radius: 4px;
            color: #2e7d32;
        }
        .final-result {
            color: #1976D2;
            font-size: 18px;
            background-color: #e3f2fd;
            padding: 4px 10px;
            border-radius: 4px;
        }
        .calc-note {
            margin-top: 15px;
            padding: 10px;
            background-color: #fff3cd;
            border-left: 4px solid #ffc107;
            font-style: italic;
            color: #856404;
        }

        #exportToExcel {
            background-color: #217346;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            font-weight: bold;
            font-size: 12px;
            margin-bottom: 20px;
            display: none;
        }
        #exportToExcel:hover {
            background-color: #1a5c37;
        }
        @media print {
            .so-table-container {
                page-break-after: always;
            }
            .toggle-calc-btn {
                display: none;
            }
        }
    </style>
    <div style="padding: 20px;">
        <div id="soTablesContainer"></div>
    </div>
    <?php
}
?>