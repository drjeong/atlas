<?php
/**
 * Listing College Information
 * File: m_collegeinfo_ssps.php
 * Description: listing college information
 *
 *
 *
 */
include_once 'session_handler.php';

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */

// DB table to use
$table = 'Colleges'; 

// Table's primary key
$primaryKey = 'Idx';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => 'Idx', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
            // Technically a DOM id cannot start with an integer, so we prefix
            // a string. This can also be useful if you have multiple tables
            // to ensure that the id is unique with a different prefix
            return 'row_'.$d;
		}
    ),
    array( 'db' => 'Idx', 'dt' => 0, 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => 'Name', 'dt' => 1, 'field' => 'Name', 'as' => 'Name'),
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );

require_once(__DIR__ . '/../php_include/dbconnection.php');

echo json_encode(
	SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, null, '', "Name" )
);
