<?php
/**
 * Evaluation of Student Outcomes
 * File: p_evluationsos_bysts.php
 * Description: Listing evaluation of student outcomes.
 */

include('header.php');

// Initialize year range if not set
if (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'])) {
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
}
if (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'])) {
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearsSelection = AcademicMultiYearsSelection(); // multi-year

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']);
}
?>
    <script type="text/javascript">
        $(document).ready(function() {
            // Add event listeners for changes in both selects
            $("#_AY_FROM").on("change", function () {
                let fromYear = parseInt($("#_AY_FROM").val());
                let toYear = parseInt($("#_AY_TO").val());

                if (fromYear > toYear) {
                    Swal.fire({
                        title: "Warning",
                        text: "The 'From' year cannot be greater than the 'To' year. Setting 'To' year to match 'From' year.",
                        icon: "warning",
                        timer: 2000
                    }).then(() => {
                        $("#_AY_TO").val(fromYear);
                        document.academicyear.submit();
                    });
                } else {
                    document.academicyear.submit();
                }
            });

            $("#_AY_TO").on("change", function () {
                let fromYear = parseInt($("#_AY_FROM").val());
                let toYear = parseInt($("#_AY_TO").val());

                if (toYear < fromYear) {
                    Swal.fire({
                        title: "Warning",
                        text: "The 'To' year cannot be less than the 'From' year. Setting 'From' year to match 'To' year.",
                        icon: "warning",
                        timer: 2000
                    }).then(() => {
                        $("#_AY_FROM").val(toYear);
                        document.academicyear.submit();
                    });
                } else {
                    document.academicyear.submit();
                }
            });
        });
    </script>

    <div class="pagebacklayout">
        <div class="row">
            <p style="margin-top:0.2in;text-align:center;">
                <span class="largeheadline">EVALUATION OF STUDENT OUTCOMES (OVERALL)</span>
            </p>
            <p style="text-align:center;font-size:13px;color:#0c5460;margin-top:5px;padding:10px;background-color:#d1ecf1;border-left:4px solid #17a2b8;font-style:italic;">
                <strong>Note:</strong> Average score is calculated as the sum of all students' scores divided by the <span style="color:#d9534f;font-weight:bold;">total number of students</span>.
            </p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <?php include('control_allprograms.php'); ?>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:100%;">
                        <?php echo($AcademicYearsSelection);?>
                    </td>
                </tr>
            </table>

            <?php
            require_once(__DIR__ . '/php_include/dbconnection_class.php');
            $DBCONNECTION = new Dbconnection();

            $AbetCourseAvailable = false;

            // Always use multi-year query
            $Query = "CALL SP_ChkAbetCourses_MultiYears(?, ?);";
            $academicYears = implode(",", $_SESSION['ATLAS_SELECTED_ACADEMICYEARS']);
            $params = [$academicYears, $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']];

            $result = $DBCONNECTION->prepare_execute_catch_error($Query, $params);

            $AbetCourseAvailable = 0;
            if ($result && $DBCONNECTION->num_rows() > 0) {
                $row = $DBCONNECTION->fetch_assoc();
                $AbetCourseAvailable = $row["COUNT"];
            }

            if ($AbetCourseAvailable == 0){
                echo <<<HTML
        <div class='col-md-12'>
            <div class="alert alert-info text-center" role="alert" style="padding: 40px; margin: 20px 0;">
                <h4 class="alert-heading">No Courses Available</h4>
                <p class="mb-0">There are currently no ABET courses available for the selected academic year(s) and program.</p>
                <hr>
                <p class="mb-0">Please select different academic year(s) or contact your administrator if you believe this is an error.</p>
            </div>
        </div>
HTML;
            } else {
                echo <<<HTML
        <div class='col-md-12'>
            <!-- Page Content -->
            <div id="pagebacklayout_inner_noborder">
                <div class="CSSTable_ROUNDEDCORDER">
HTML;

                // Always display multi-year view
                displayMultiYearsData();
                displayCharts_MultiYearsData();

                echo <<<HTML
                </div>
            </div>
            <!-- /#page-content-wrapper -->
        </div>
HTML;
            }
            ?>

        </div>
    </div>

<?php include('footer.php');?>

<?php
function displayMultiYearsData() {
    ?>
    <style>
        .calculation-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .calculation-modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            border-radius: 8px;
            width: 85%;
            max-width: 900px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .close-modal {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close-modal:hover,
        .close-modal:focus {
            color: #000;
        }
        .calc-section {
            margin: 15px 0;
            padding: 10px;
            background-color: #f9f9f9;
            border-left: 4px solid #007bff;
        }
        .calc-formula {
            font-family: 'Courier New', monospace;
            background-color: #e9ecef;
            padding: 10px;
            border-radius: 4px;
            margin: 10px 0;
        }
        .course-details-table {
            width: 100%;
            margin-top: 10px;
            border-collapse: collapse;
            font-size: 12px;
        }
        .course-details-table th {
            background-color: #f0f0f0;
            padding: 8px;
            text-align: left;
            border: 1px solid #ddd;
            font-weight: bold;
        }
        .course-details-table td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .course-details-table td.center {
            text-align: center;
        }
        .details-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            white-space: nowrap;
        }
        .details-btn:hover {
            background-color: #0056b3;
        }
        .loading-spinner {
            text-align: center;
            padding: 20px;
            color: #007bff;
        }
    </style>

    <script src="js/datatable-utils-search.min.js"></script>
    <script>
        function closeCalculationModal(rowId) {
            document.getElementById('modal-' + rowId).style.display = 'none';
        }

        // Close modal when clicking outside of it
        window.onclick = function(event) {
            if (event.target.classList.contains('calculation-modal')) {
                event.target.style.display = 'none';
            }
        }

        // Close modal on ESC key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                var modals = document.querySelectorAll('.calculation-modal');
                modals.forEach(function(modal) {
                    modal.style.display = 'none';
                });
            }
        });

        function showDetailsModal(btn) {
            const table = $('#studentoutcomes').DataTable();
            const row = table.row($(btn).parents('tr'));
            const data = row.data();

            // Create unique ID for this modal
            const rowId = "multi-so-" + data.SO.replace(/[^a-zA-Z0-9]/g, '-') + "-" + data.ay.replace(/[^a-zA-Z0-9]/g, '-');

            // Check if modal already exists, if not create it
            if ($('#modal-' + rowId).length === 0) {
                const modalHTML = `
            <div id="modal-${rowId}" class="calculation-modal">
                <div class="calculation-modal-content">
                    <span class="close-modal" onclick="closeCalculationModal('${rowId}')">&times;</span>
                    <h3>Calculation Details: ${data.SO}</h3>
                    <p><strong>${data.ay === 'Overall' ? 'All Selected Years' : 'Academic Year: ' + data.ay}</strong></p>
                    <hr>

                    <div id="modal-content-${rowId}">
                        <div class="loading-spinner">
                            <span class="glyphicon glyphicon-refresh glyphicon-spin"></span> Loading course details...
                        </div>
                    </div>
                </div>
            </div>
        `;
                $('body').append(modalHTML);
            }

            // Show modal
            document.getElementById('modal-' + rowId).style.display = 'block';

            // Fetch course details via AJAX
            $.ajax({
                url: 'p_evluationsos_bysts_details.php',
                type: 'POST',
                data: {
                    academicYear: data.ay,
                    so: data.SO,
                    program: '<?php echo $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']; ?>'
                },
                dataType: 'json',
                success: function(response) {
                    if (response.error || !response.success) {
                        $('#modal-content-' + rowId).html(
                            '<div class="alert alert-danger">' + (response.error || 'Unknown error occurred') + '</div>'
                        );
                        return;
                    }

                    // Build course breakdown HTML
                    let coursesHTML = '';
                    if (response.courses && response.courses.length > 0) {
                        coursesHTML = '<table class="course-details-table">';
                        coursesHTML += '<thead><tr>';
                        coursesHTML += '<th>Course Num</th>';
                        coursesHTML += '<th>CRN</th>';
                        coursesHTML += '<th>Course Name</th>';
                        coursesHTML += '<th>Academic Year</th>';
                        coursesHTML += '<th class="center">Students</th>';
                        coursesHTML += '<th class="center">Avg Score</th>';
                        coursesHTML += '<th class="center">Total Score</th>';
                        coursesHTML += '</tr></thead><tbody>';

                        response.courses.forEach(function(course) {
                            coursesHTML += '<tr>';
                            coursesHTML += '<td>' + course.courseNo + '</td>';
                            coursesHTML += '<td>' + course.crn + '</td>';
                            coursesHTML += '<td>' + course.courseName + '</td>';
                            coursesHTML += '<td>' + course.academicYear + '</td>';
                            coursesHTML += '<td class="center">' + course.students + '</td>';
                            coursesHTML += '<td class="center">' + course.avgScore + '</td>';
                            coursesHTML += '<td class="center">' + course.totalScore + '</td>';
                            coursesHTML += '</tr>';
                        });

                        coursesHTML += '</tbody></table>';
                    } else {
                        coursesHTML = '<p style="color: #999; font-style: italic;">No course data available.</p>';
                    }

                    // Calculate counts for percentages
                    const countTopFifty = data.tot > 0 ? Math.round((parseFloat(data.top50) / 100) * data.tot) : 0;
                    const countTopTwentyFive = data.tot > 0 ? Math.round((parseFloat(data.top25) / 100) * data.tot) : 0;

                    // Build complete modal content
                    const modalContent =
                        '<div class="calc-section">' +
                        '<h4>1. Number of Students</h4>' +
                        '<p>Total students assessed for this outcome: <strong>' + data.tot + '</strong></p>' +
                        '<p class="calc-formula">Total Students = ' + data.tot + '</p>' +
                        '</div>' +

                        '<div class="calc-section">' +
                        '<h4>2. Average Score</h4>' +
                        '<p>The average score is calculated by summing all individual student scores and dividing by the total number of students.</p>' +
                        '<p><strong>Courses used in this calculation:</strong></p>' +
                        coursesHTML +
                        '<p class="calc-formula" style="margin-top:15px;">' +
                        'Average Score = (Sum of All Student Scores) / (Total Students)<br>' +
                        'Average Score = ' + response.totalScore + ' / ' + response.totalStudents + '<br>' +
                        'Average Score = ' + data.avg +
                        '</p>' +
                        '<p><em>Note: Scores are typically on a scale (e.g., 0-4), where higher values indicate better performance.</em></p>' +
                        '</div>' +

                        '<div class="calc-section">' +
                        '<h4>3. % >= 2 (Developing)</h4>' +
                        '<p>Percentage of students who scored 2 or higher (meeting the "Developing" threshold).</p>' +
                        '<p class="calc-formula">' +
                        'Students with Score >= 2 = ' + countTopFifty + '<br>' +
                        'Percentage = (' + countTopFifty + ' / ' + data.tot + ') × 100<br>' +
                        'Percentage = ' + data.top50 +
                        '</p>' +
                        '</div>' +

                        '<div class="calc-section">' +
                        '<h4>4. % >= 3 (Satisfactory)</h4>' +
                        '<p>Percentage of students who scored 3 or higher (meeting the "Satisfactory" threshold).</p>' +
                        '<p class="calc-formula">' +
                        'Students with Score >= 3 = ' + countTopTwentyFive + '<br>' +
                        'Percentage = (' + countTopTwentyFive + ' / ' + data.tot + ') × 100<br>' +
                        'Percentage = ' + data.top25 +
                        '</p>' +
                        '</div>' +

                        '<div class="calc-section">' +
                        '<h4>Performance Summary</h4>' +
                        '<ul>' +
                        '<li><strong>' + data.top50 + '</strong> of students are developing or better (score >= 2)</li>' +
                        '<li><strong>' + data.top25 + '</strong> of students are satisfactory or better (score >= 3)</li>' +
                        '<li><strong>' + data.avg + '</strong> average score across all ' + data.tot + ' students</li>' +
                        '</ul>' +
                        '</div>';

                    $('#modal-content-' + rowId).html(modalContent);
                },
                error: function(xhr, status, error) {
                    $('#modal-content-' + rowId).html(
                        '<div class="alert alert-danger">Failed to fetch course details: ' + error + '</div>'
                    );
                }
            });
        }

        $(document).ready(function() {
            const varSelectedAcademicYear_From = $("#_AY_FROM option:selected").text();
            const varSelectedAcademicYear_To = $("#_AY_TO option:selected").text();

            const szURL = 'ssps/p_evluationsos_bysts_ssps.php';
            const DataTable = $("#studentoutcomes").DataTable({
                dom: 'lBfrtip',
                "processing": true,
                "serverSide": false,
                "lengthMenu": [ 30, 50, 100, 150, 200, 500, 1000 ],
                "ajax": {
                    "url": szURL,
                    "dataSrc": function(json) {
                        // Store the data globally for chart use
                        tableData = json.data;

                        // Draw charts after data is loaded
                        setTimeout(function() {
                            drawCharts();
                        }, 100);

                        return json.data;
                    }
                },
                "fnInitComplete": function(oSettings, json) {
                    let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                    btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                    $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                        $('#' + oSettings.sTableId).dataTable().fnFilter('');
                    });
                },
                "oLanguage": {"sInfoFiltered": ""},
                "order": [[ 0, "dsc" ], [ 1, "asc" ]],
                "columns": [
                    { "data": 'ay' },
                    { "data": 'SO' },
                    { "data": 'tot' },
                    { "data": 'avg' },
                    { "data": 'top50' },
                    { "data": 'top25' },
                    {
                        "data": null,
                        "defaultContent": '<button class="details-btn" onclick="showDetailsModal(this)"><span class="glyphicon glyphicon-info-sign"></span> Details</button>',
                        "orderable": false
                    }
                ],
                "columnDefs": [
                    {
                        "targets": '_all',
                        "className": 'dt-center'
                    },
                    {
                        "targets"  : 'no-sort',
                        "orderable": false,
                    }
                ],
                "buttons": [
                    {
                        "extend": 'excelHtml5',
                        "title": `Evaluation of Student Outcomes (Academic Years: ${varSelectedAcademicYear_From} ~ ${varSelectedAcademicYear_To})`,
                        "text": '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                        "className": 'btn btn-xs',
                        "attr": {
                            "style": 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                        },
                    }
                ]
            });

            // Initialize the column search functionality
            new DataTableSearch('#studentoutcomes', DataTable, ShowResetBtn=false);
        });
    </script>

    <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
        <table id="studentoutcomes" class="display break-word" style="border-spacing:5px; padding:5px;width:100%;">
            <thead>
            <tr>
                <th>ACADEMIC YEAR</th>
                <th>STUDENT OUTCOME</th>
                <th># OF STUDENTS</th>
                <th>AVERAGE SCORE</th>
                <th>% >= 2 (Developing)</th>
                <th>% >= 3 (Satisfactory)</th>
                <th>DETAILS</th>
            </tr>
            </thead>
            <tfoot>
            <tr>
                <th>ACADEMIC YEAR</th>
                <th>STUDENT OUTCOME</th>
                <th># OF STUDENTS</th>
                <th>AVERAGE SCORE</th>
                <th>% >= 2 (Developing)</th>
                <th>% >= 3 (Satisfactory)</th>
                <th></th>
            </tr>
            </tfoot>
        </table>
    </div>
    <?php
}

function displayCharts_MultiYearsData() {
    ?>
    <!-- Chart container -->
    <div class="container-fluid mt-4">
        <div id="charts" class="row"></div>
    </div>

    <!-- Include D3 and ABET Chart Library -->
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <link rel="stylesheet" href="css/d3-abetchart-library.css">
    <script src="js/d3-abetchart-library.min.js?v=0.0.001"></script>

    <script>
        // Store the DataTable data globally for chart use
        let tableData = [];

        async function drawCharts() {
            // Transform DataTable data into chart format
            const chartData = transformTableDataToChartData(tableData);

            // Initialize charts using the library
            // We'll pass the data directly instead of fetching from URL
            initChartsFromData(chartData, '#charts');
        }

        // Transform table data to chart data format
        function transformTableDataToChartData(data) {
            const chartData = {};

            data.forEach(row => {
                const so = row.SO;
                const ay = row.ay;

                // Initialize SO if not exists
                if (!chartData[so]) {
                    chartData[so] = {
                        description: "", // Leave empty since we'll use SO code only
                        data: {}
                    };
                }

                // Add year data
                chartData[so].data[ay] = {
                    AVG: parseFloat(row.avg),
                    TOPFIFTY: parseFloat(row.top50),
                    TOPTWENTYFIVE: parseFloat(row.top25),
                    TOTAL: parseInt(row.tot)
                };
            });

            return chartData;
        }

        // Initialize charts from data object (instead of URL)
        function initChartsFromData(chartData, containerSelector, options = {}) {
            const config = { ...AbetChartLibrary.defaultConfig, ...options };

            try {
                // Create tooltip div
                const tooltip = d3.select("body").append("div")
                    .attr("class", "abet-chart-tooltip")
                    .style("opacity", 0);

                // Container for chart references
                const chartContainers = [];

                // Get container
                const chartsDiv = d3.select(containerSelector);

                // Create charts
                Object.entries(chartData).forEach(([SO, details]) => {
                    const column = chartsDiv.append("div")
                        .attr("class", "col-md-6 col-lg-4 mb-4");

                    const container = column.append("div")
                        .attr("class", "abet-chart-container");

                    container.append("div")
                        .attr("class", "abet-chart-title")
                        .attr("title", `${SO}: ${details.description}`)
                        .text(`${SO}: ${details.description}`);

                    const overallTotal = details.data.Overall?.TOTAL || 0;
                    container.append("div")
                        .attr("class", "abet-total-label")
                        .text(`Sample Size: ${overallTotal}`);

                    const chartDiv = container.append("div")
                        .attr("class", "abet-chart");

                    const chartId = `abet-chart-${SO.replace(/\s+/g, '-')}`;

                    chartContainers.push({
                        container: chartDiv.node(),
                        data: details,
                        chartId: chartId
                    });

                    AbetChartLibrary.drawGroupedBarChart(details, chartDiv.node(), chartId, config, tooltip);
                    AbetChartLibrary.addPrintButton(container.node(), chartId, `${SO}: ${details.description}`);
                    AbetChartLibrary.addDownloadButton(container.node(), chartId, `${SO}: ${details.description}`, config);
                });

                // Handle window resize
                AbetChartLibrary.setupResizeHandler(chartContainers, config, tooltip);

            } catch (error) {
                console.error("Error initializing ABET charts:", error);
            }
        }
    </script>
    <?php
}
