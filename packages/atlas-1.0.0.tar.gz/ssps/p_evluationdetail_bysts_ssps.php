<?php
/**
 * Evaluation of Performance Indicators by Requirement
 *
 * 12/14/2025 - initial version created
 * 06/02/2026 - revised to handle multiple course offerings with same course number
 * 06/06/2026 - revised to use PerformanceIndicatorAnalyzer with getSavedAnalysis
 * 06/07/2026 - refactored to use performance_indicator_helpers
 *
 */
include_once 'session_handler.php';
?>

<?php
require_once('../php_include/dbconnection_class.php');
require_once('performance_indicator_helpers.php');

// Get parameters from session
$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// Handle academic years - convert from array to string if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
    if (!is_array($academicYears)) {
        $academicYears = array(intval($academicYears));
    }
} else {
    $academicYears = array(intval($IN_AcademicYear));
}

if (empty($academicYears)) {
    $academicYears = array(intval($IN_AcademicYear));
}

// Convert to comma-separated string for SQL queries
$IN_AcademicYears = implode(',', array_map('intval', $academicYears));

// Get requirement filter from GET parameter (optional)
$requirementFilter = isset($_GET['requirement']) ? $_GET['requirement'] : 'All';

// Initialize database connection
$DBCONNECTION = new Dbconnection();
$Data = array();

// Initialize variables
$studentOutcomes = array();
$courses = array();
$requirements = array();

// Query to get all Student Outcomes and their GPIs for the program
$soQuery = "
    SELECT DISTINCT
        AY.AcademicYear,
        STNTOUTCMS.SO,
        STNTOUTCMS.Description AS SODescription,
        GPIS.Description AS PIDescription,
        GPIS.Idx AS GPIIdx,
        GPIS.GPI AS GPICode
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    LEFT JOIN AcademicYears AS AY ON (STNTOUTCMS.AcademicYear = AY.Idx) 
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    ORDER BY STNTOUTCMS.SO, GPIS.GPI
";
$soResults = $DBCONNECTION->sendquery($soQuery);

// Temporary array to track SO descriptions by academic year
$soDescriptions = array();

if ($soResults) {
    while ($row = $soResults->fetch_assoc()) {
        $soKey = $row['SO'];
        $academicYear = $row['AcademicYear'];
        $soDescription = $row['SODescription'];

        // Track unique SO descriptions with their academic years
        if (!isset($soDescriptions[$soKey][$soDescription])) {
            $soDescriptions[$soKey][$soDescription] = array();
        }
        if (!in_array($academicYear, $soDescriptions[$soKey][$soDescription])) {
            $soDescriptions[$soKey][$soDescription][] = $academicYear;
        }

        // Initialize student outcome if not exists
        if (!isset($studentOutcomes[$soKey])) {
            $studentOutcomes[$soKey] = array(
                'description' => '',
                'gpis' => array()
            );
        }

        // Add GPI (avoid duplicates)
        $gpiExists = false;
        foreach ($studentOutcomes[$soKey]['gpis'] as $existingGpi) {
            if ($existingGpi['gpiIdx'] == $row['GPIIdx']) {
                $gpiExists = true;
                break;
            }
        }

        if (!$gpiExists) {
            $studentOutcomes[$soKey]['gpis'][] = array(
                'gpiIdx' => $row['GPIIdx'],
                'code' => $row['GPICode'],
                'description' => $row['PIDescription'],
            );
        }
    }

    // Build combined descriptions with version history
    foreach ($soDescriptions as $soKey => $descriptions) {
        if (count($descriptions) == 1) {
            $studentOutcomes[$soKey]['description'] = array_keys($descriptions)[0];
        } else {
            // Show latest description with expandable history
            $sortedDescriptions = array();
            foreach ($descriptions as $description => $years) {
                rsort($years);
                $sortedDescriptions[$years[0]] = array(
                    'description' => $description,
                    'years' => $years
                );
            }
            krsort($sortedDescriptions);

            $latest = reset($sortedDescriptions);
            $latestYears = implode(', ', $latest['years']);

            $historyHtml = '<div style="margin-top: 8px; padding: 8px; background: #f5f5f5; border-left: 3px solid #ccc; font-size: 0.9em;">';
            $historyHtml .= '<strong>Previous versions:</strong><br>';
            $isFirst = true;
            foreach ($sortedDescriptions as $item) {
                if ($isFirst) {
                    $isFirst = false;
                    continue; // Skip latest
                }
                $years = implode(', ', $item['years']);
                $historyHtml .= '<br><em>' . $years . ':</em> ' . $item['description'];
            }
            $historyHtml .= '</div>';

            $studentOutcomes[$soKey]['description'] =
                '<span style="color: #0066cc;">' . $latestYears . ':</span> ' .
                $latest['description'] .
                (count($sortedDescriptions) > 1 ? $historyHtml : '');
        }
    }
}

// Query to get distinct requirements first
$requirementQuery = "
    SELECT DISTINCT ABETCRSES.Requirement
    FROM AbetCourses AS ABETCRSES
    WHERE ABETCRSES.AcademicProgram = {$IN_AcademicProgram}
    AND ABETCRSES.AcademicYear IN ({$IN_AcademicYears})
    AND ABETCRSES.Requirement IS NOT NULL
    AND ABETCRSES.Requirement != ''
    ORDER BY ABETCRSES.Requirement
";

$requirementResults = $DBCONNECTION->sendquery($requirementQuery);
if ($requirementResults) {
    while ($row = $requirementResults->fetch_assoc()) {
        if (!empty($row['Requirement'])) {
            $requirements[] = $row['Requirement'];
        }
    }
}

require_once(__DIR__ . '/../php_include/semester_helpers.php');

// Ensure all courses have been analyzed and saved
$saveResults = analyzeAndSavePerformanceIndicators(
    $DBCONNECTION,
    $IN_AcademicProgram,
    $academicYears,
    false,  // Don't force recalculate - skip if already exists
    $requirementFilter !== 'All' ? $requirementFilter : null
);

// Get the saved data from database
$savedCourses = getSavedPerformanceIndicators(
    $DBCONNECTION,
    $IN_AcademicProgram,
    $academicYears,
    $requirementFilter !== 'All' ? $requirementFilter : null
);

// Process saved courses into the structure needed for the response
foreach ($savedCourses as $courseKey => $courseData) {
    $semesterDisplay = !empty($courseData['semester']) ? getBannerSemesterText($courseData['semester']) : '';

    $courses[$courseKey] = array(
        'courseNo' => $courseData['courseNo'],
        'crn' => $courseData['crn'],
        'title' => $courseData['title'],
        'requirement' => $courseData['requirement'],
        'abetCourseIdx' => $courseData['abetCourseIdx'],
        'semesterCode' => $courseData['semester'],
        'semesterDisplay' => $semesterDisplay,
        'scores' => array(),
        'studentCounts' => array(),
        'studentsAbove3' => array()
    );

    // Process each GPI in the analysis data
    foreach ($courseData['indicators'] as $indicator) {
        $gpiIdx = $indicator['gpiIdx'];
        $avg = $indicator['avg'];
        $total = $indicator['total'];
        $topFifty = $indicator['topFifty'];
        $topTwentyFive = $indicator['topTwentyFive'];

        // Find which SO and GPI code this belongs to
        foreach ($studentOutcomes as $soKey => $soData) {
            foreach ($soData['gpis'] as $gpiInfo) {
                if ($gpiInfo['gpiIdx'] == $gpiIdx) {
                    $gpiCode = $gpiInfo['code'];

                    if (!isset($courses[$courseKey]['scores'][$soKey])) {
                        $courses[$courseKey]['scores'][$soKey] = array();
                        $courses[$courseKey]['studentCounts'][$soKey] = array();
                        $courses[$courseKey]['studentsAbove3'][$soKey] = array();
                    }

                    $courses[$courseKey]['scores'][$soKey][$gpiCode] = round($avg, 2);
                    $courses[$courseKey]['studentCounts'][$soKey][$gpiCode] = $total;
                    // Use topFifty as a proxy for above 3 (or you can calculate differently)
                    $courses[$courseKey]['studentsAbove3'][$soKey][$gpiCode] = $topTwentyFive;

                    break 2; // Exit both loops
                }
            }
        }
    }
}

// Build the response data
$data = array();
foreach ($courses as $course) {
    $row = array(
        'requirement' => $course['requirement'],
        'courseNo' => $course['courseNo'],
        'crn' => $course['crn'],
        'title' => $course['title'],
        'abetCourseIdx' => $course['abetCourseIdx'],
        'semesterCode' => $course['semesterCode'],
        'semesterDisplay' => $course['semesterDisplay']
    );

    foreach ($studentOutcomes as $soKey => $soData) {
        foreach ($soData['gpis'] as $gpiInfo) {
            $gpiCode = $gpiInfo['code'];
            $columnKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'];
            $countKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_count';
            $above3Key = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_above3';

            // Check if data exists for this SO/GPI combination
            if (isset($course['scores'][$soKey]) && isset($course['scores'][$soKey][$gpiCode])) {
                $row[$columnKey] = $course['scores'][$soKey][$gpiCode];
                $row[$countKey] = $course['studentCounts'][$soKey][$gpiCode];
                $row[$above3Key] = $course['studentsAbove3'][$soKey][$gpiCode];
            } else {
                $row[$columnKey] = null;
                $row[$countKey] = 0;
                $row[$above3Key] = 0;
            }
        }
    }

    $data[] = $row;
}

// Prepare final response
$Data['data'] = $data;
$Data['studentOutcomes'] = $studentOutcomes;
$Data['requirements'] = $requirements;

header('Content-Type: application/json');
echo json_encode($Data);