<?php
/**
 * Evaluation of Performance Indicators
 * Description: Creating JSON chart data
 *
 *
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }

function fetchMultiYearsChartData() {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Prepare and execute stored procedure
    $Query = "CALL SP_FetchOverallAbetCourseAssessmentsByGPI_MultiYears(?, ?);";
    $academicYears = implode(",", $_SESSION['ATLAS_SELECTED_ACADEMICYEARS']);
    $params = [$academicYears, $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']];
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, $params);

    // Group data by Performance Indicator (GPI)
    $chartData = [];
    while ($row = $DBCONNECTION->fetch_assoc($result)) {
        $GPI = $row['GPI'];
        if (!isset($chartData[$GPI])) {
            $chartData[$GPI] = [
                'GPIDescription' => html_entity_decode($row['GPIDescription']),
                'data' => []
            ];
        }
        $chartData[$GPI]['data'][] = [
            'AcademicYear' => $row['AcademicYear'],
            'AverageScore' => round($row['AVG'], 2),
            'TopFifty' => round(($row['TOPFIFTY'] / max($row['TOTAL'], 1)) * 100, 2),
            'TopTwentyFive' => round(($row['TOPTWENTYFIVE'] / max($row['TOTAL'], 1)) * 100, 2),
        ];
    }

    // Output JSON
    header('Content-Type: application/json');
    echo json_encode($chartData);
}

fetchMultiYearsChartData();