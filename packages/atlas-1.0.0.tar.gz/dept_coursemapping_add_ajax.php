<?php
/**
 * Add Abet Course
 * Description: Adding abet course
 * Author: Dong Hyun Jeong
 *
 * 11/19/2024 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$AcademicYearIdx = (isset($_POST['ay'])) ? trim($_POST['ay']) : '';
$Courses = (isset($_POST['crses'])) ? trim($_POST['crses']) : '';
$ABETSyllabi = (isset($_POST['abetbi'])) ? trim($_POST['abetbi']) : '';

$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYearIdx=="" || $AcademicProgramIdx=="" || $Courses==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    $AcademicProgramIdx = filter_var($AcademicProgramIdx, FILTER_VALIDATE_INT);
    if ($AcademicProgramIdx === false) {
        throw new Exception('Invalid Academic Progrogram format');
    }

    // convert courses
    $Course_Array = explode( '|', $Courses );
    $ABETSyllabus_Array = explode( '|', $ABETSyllabi );

    $MultiQuery = "";
    for ($i=0; $i<count($Course_Array); $i++)
    {
        $CourseIdx = $Course_Array[$i];
        $ABETSyllabusIdx = $ABETSyllabus_Array[$i];
        if ($ABETSyllabusIdx === '') $ABETSyllabusIdx = 'NULL';

        $MultiQuery .= "CALL SP_AddCourseMapping_Courses($AcademicYearIdx, $CourseIdx, $ABETSyllabusIdx, $AcademicProgramIdx);";
    }
    $DBCONNECTION->sendmultiquery($MultiQuery);
//    error_log($MultiQuery);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

