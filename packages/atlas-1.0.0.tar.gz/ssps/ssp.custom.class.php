<?php
/**
 * Custom SSP class for handling custom SQL queries with DataTables
 * Based on the original SSP class by DataTables
 */
class SSP {
    /**
     * Create the data output array for the DataTables rows
     *
     * @param  array $columns Column information array
     * @param  array $data    Data from the SQL get
     * @return array          Formatted data in a row based format
     */
    static function data_output($columns, $data)
    {
        $out = array();

        for ($i=0, $ien=count($data); $i<$ien; $i++) {
            $row = array();

            for ($j=0, $jen=count($columns); $j<$jen; $j++) {
                $column = $columns[$j];

                // Is there a formatter?
                if (isset($column['formatter'])) {
                    if (empty($column['db'])) {
                        $row[$column['dt']] = $column['formatter']($data[$i]);
                    } else {
                        $row[$column['dt']] = $column['formatter']($data[$i][$column['db']], $data[$i]);
                    }
                } else {
                    if (!empty($column['db'])) {
                        $row[$column['dt']] = $data[$i][$column['db']];
                    } else {
                        $row[$column['dt']] = "";
                    }
                }
            }

            $out[] = $row;
        }

        return $out;
    }

    /**
     * Database connection
     *
     * Obtain an PHP PDO connection from a connection details array
     *
     * @param  array $conn SQL connection details.
     * @return resource    PDO connection
     */
    static function db($conn)
    {
        if (is_array($conn)) {
            return self::sql_connect($conn);
        }

        return $conn;
    }

    /**
     * Paging
     *
     * Construct the LIMIT clause for server-side processing SQL query
     *
     * @param  array $request Data sent to server by DataTables
     * @param  array $columns Column information array
     * @return string SQL limit clause
     */
    static function limit($request, $columns)
    {
        $limit = '';

        if (isset($request['start']) && $request['length'] != -1) {
            $limit = "LIMIT " . intval($request['start']) . ", " . intval($request['length']);
        }

        return $limit;
    }

    /**
     * Ordering
     *
     * Construct the ORDER BY clause for server-side processing SQL query
     *
     * @param  array $request Data sent to server by DataTables
     * @param  array $columns Column information array
     * @return string SQL order by clause
     */
    static function order($request, $columns)
    {
        $order = '';

        if (isset($request['order']) && count($request['order'])) {
            $orderBy = array();
            $dtColumns = self::pluck($columns, 'dt');

            for ($i=0, $ien=count($request['order']); $i<$ien; $i++) {
                // Convert the column index into the column data property
                $columnIdx = intval($request['order'][$i]['column']);
                $requestColumn = $request['columns'][$columnIdx];

                $columnIdx = array_search($requestColumn['data'], $dtColumns);
                $column = $columns[$columnIdx];

                if ($requestColumn['orderable'] == 'true') {
                    $dir = $request['order'][$i]['dir'] === 'asc' ?
                        'ASC' :
                        'DESC';

                    // Use column name without backticks for ordering
                    $orderBy[] = $column['db'] . ' ' . $dir;
                }
            }

            if (count($orderBy)) {
                $order = 'ORDER BY ' . implode(', ', $orderBy);
            }
        }

        return $order;
    }

    /**
     * Searching / Filtering
     *
     * Construct the WHERE clause for server-side processing SQL query.
     *
     * NOTE this does not match the built-in DataTables filtering which does it
     * word by word on any field. It's possible to do here performance on large
     * databases would be very poor
     *
     * @param  array $request Data sent to server by DataTables
     * @param  array $columns Column information array
     * @param  array $bindings Array of values for PDO bindings, used in the sql_exec() function
     * @return string SQL where clause
     */
    static function filter($request, $columns, &$bindings)
    {
        $globalSearch = array();
        $columnSearch = array();
        $dtColumns = self::pluck($columns, 'dt');

        if (isset($request['search']) && $request['search']['value'] != '') {
            $str = $request['search']['value'];

            for ($i=0, $ien=count($request['columns']); $i<$ien; $i++) {
                $requestColumn = $request['columns'][$i];
                $columnIdx = array_search($requestColumn['data'], $dtColumns);

                if ($columnIdx !== false) {
                    $column = $columns[$columnIdx];

                    if ($requestColumn['searchable'] == 'true' && !empty($column['db'])) {
                        $binding = self::bind($bindings, '%' . $str . '%', PDO::PARAM_STR);
                        // Don't use backticks for column names in derived table
                        $globalSearch[] = $column['db'] . " LIKE " . $binding;
                    }
                }
            }
        }

        // Individual column filtering
        if (isset($request['columns'])) {
            for ($i=0, $ien=count($request['columns']); $i<$ien; $i++) {
                $requestColumn = $request['columns'][$i];
                $columnIdx = array_search($requestColumn['data'], $dtColumns);

                if ($columnIdx !== false) {
                    $column = $columns[$columnIdx];
                    $str = $requestColumn['search']['value'];

                    if ($requestColumn['searchable'] == 'true' && $str != '' && !empty($column['db'])) {
                        $binding = self::bind($bindings, '%' . $str . '%', PDO::PARAM_STR);
                        // Don't use backticks for column names in derived table
                        $columnSearch[] = $column['db'] . " LIKE " . $binding;
                    }
                }
            }
        }

        // Combine the filters into a single string
        $where = '';

        if (count($globalSearch)) {
            $where = '(' . implode(' OR ', $globalSearch) . ')';
        }

        if (count($columnSearch)) {
            $where = $where === '' ?
                implode(' AND ', $columnSearch) :
                $where . ' AND ' . implode(' AND ', $columnSearch);
        }

        if ($where !== '') {
            $where = 'WHERE ' . $where;
        }

        return $where;
    }

    /**
     * Perform the SQL queries needed for an server-side processing requested,
     * utilizing the helper functions of this class, limit(), order() and
     * filter() among others. The returned array is ready to be encoded as JSON
     * in response to an SSP request, or can be modified if needed before
     * sending back to the client.
     *
     * @param  array $request Data sent to server by DataTables
     * @param  array $conn PDO connection details returned by getSqlConnAttributes()
     * @param  string $customQuery Custom SQL query
     * @param  string $primaryKey Primary key of the table
     * @param  array $columns Column information array
     * @return array          Server-side processing response array
     */
    static function complex_custom($request, $conn, $customQuery, $primaryKey, $columns)
    {
        $bindings = array();
        $db = self::db($conn);

        // Custom filtering
        $where = self::filter($request, $columns, $bindings);
        $order = self::order($request, $columns);
        $limit = self::limit($request, $columns);

        // Main query to get the data
        $data = self::sql_exec(
            $db,
            "SELECT * 
         FROM ($customQuery) as custom_derived_table 
         $where 
         $order 
         $limit",
            $bindings
        );

        // Data set length after filtering
        $resFilterLength = self::sql_exec(
            $db,
            "SELECT COUNT(*) as total
         FROM ($customQuery) as custom_derived_table 
         $where",
            $bindings
        );
        $recordsFiltered = $resFilterLength[0]['total'] ?? count($data);

        // Total data set length
        $resTotalLength = self::sql_exec(
            $db,
            "SELECT COUNT(*) as total
         FROM ($customQuery) as custom_derived_table",
            array()
        );
        $recordsTotal = $resTotalLength[0]['total'] ?? count($data);

        // If counts are still 0 but we have data, use the data length
        if ($recordsTotal == 0 && count($data) > 0) {
            $recordsTotal = count($data);
        }

        if ($recordsFiltered == 0 && count($data) > 0) {
            $recordsFiltered = count($data);
        }

        // Output
        return array(
            "draw"            => isset($request['draw']) ?
                intval($request['draw']) :
                1, // Use 1 instead of 0 for initial draw
            "recordsTotal"    => intval($recordsTotal),
            "recordsFiltered" => intval($recordsFiltered),
            "data"            => self::data_output($columns, $data)
        );
    }

    /**
     * Connect to the database
     *
     * @param  array $sql_details SQL server connection details array, with the
     *   properties:
     *     * host - host name
     *     * db   - database name
     *     * user - user name
     *     * pass - user password
     * @return resource Database connection handle
     */
    static function sql_connect($sql_details)
    {
        try {
            $db = @new PDO(
                "mysql:host={$sql_details['host']};dbname={$sql_details['db']}",
                $sql_details['user'],
                $sql_details['pass'],
                array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
            );
            $db->query("SET NAMES 'utf8'");
        } catch (PDOException $e) {
            self::fatal(
                "An error occurred while connecting to the database. ".
                "The error reported by the server was: ".$e->getMessage()
            );
        }

        return $db;
    }

    /**
     * Execute an SQL query on the database
     *
     * @param  resource $db  Database handler
     * @param  string   $sql SQL query to execute
     * @param  array    $bindings Array of PDO binding values from bind() to be
     *   used for safely escaping strings. Note that this can be given as the
     *   SQL query string if no bindings are required.
     * @return array         Result from the query (all rows)
     */
    static function sql_exec($db, $sql, $bindings=array())
    {
        // Argument shifting
        if (is_string($db)) {
            $bindings = $sql;
            $sql = $db;
            $db = self::$db;
        }

        $stmt = $db->prepare($sql);

        // Bind parameters
        if (is_array($bindings)) {
            for ($i=0, $ien=count($bindings); $i<$ien; $i++) {
                $binding = $bindings[$i];
                $stmt->bindValue($binding['key'], $binding['val'], $binding['type']);
            }
        }

        // Execute
        try {
            $stmt->execute();
        } catch (PDOException $e) {
            self::fatal("An SQL error occurred: ".$e->getMessage() . " - Query: " . $sql);
        }

        // Return all
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Throw a fatal error.
     *
     * This writes out an error message in a JSON string which DataTables will
     * see and show to the user in the browser.
     *
     * @param  string $msg Message to send to the client
     */
    static function fatal($msg)
    {
        echo json_encode(array(
            "error" => $msg
        ));

        exit(0);
    }

    /**
     * Create a PDO binding key which can be used for escaping variables safely
     * when executing a query with sql_exec()
     *
     * @param  array &$a    Array of bindings
     * @param  mixed $val   Value to bind
     * @param  int   $type  PDO field type
     * @return string       Bound key to be used in the SQL where this parameter
     *   would be used.
     */
    static function bind(&$a, $val, $type)
    {
        $key = ':binding_' . count($a);

        $a[] = array(
            'key' => $key,
            'val' => $val,
            'type' => $type
        );

        return $key;
    }

    /**
     * Pull a particular property from each assoc. array in a numeric array,
     * returning and array of the property values from each item.
     *
     *  @param  array  $a    Array to get data from
     *  @param  string $prop Property to read
     *  @return array        Array of property values
     */
    static function pluck($a, $prop)
    {
        $out = array();

        for ($i=0, $len=count($a); $i<$len; $i++) {
            if (isset($a[$i][$prop])) {
                $out[] = $a[$i][$prop];
            }
        }

        return $out;
    }
}