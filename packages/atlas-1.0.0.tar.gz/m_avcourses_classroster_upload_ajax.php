<?php
/**
 * Upload Class Roster
 * Description: uploading class roster
 * Author: Dong Hyun Jeong
 *
 * 12/18/2025 - initial version created
 *
 */

include_once 'session_handler.php';
?>

<?php
$AvailableCourseIdx='';
$Enrollment='';
$StudentData = '';

if (array_key_exists('_AVCIDX', $_POST) && array_key_exists('_ENROLLMENT', $_POST) && array_key_exists('studentData', $_POST))
{
    $AvailableCourseIdx = trim($_POST['_AVCIDX']);
    $Enrollment = trim($_POST['_ENROLLMENT']);

    // Validate JSON format
    $StudentData = $_POST['studentData'];
    $testDecode = json_decode($StudentData, true);
    if ($testDecode === null || !is_array($testDecode) || empty($testDecode)) {
        echo "0x00020102";  // Invalid student data format
        exit;
    }
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicProgram=="" || $AvailableCourseIdx=="" || $Enrollment==""){
    // no required information
    echo "0x00000101";
    exit;
}

try {
    require_once(__DIR__ . '/../config.php');
    require_once(__DIR__ . '/php_include/dbconnection_class.php');

    $DBCONNECTION = new Dbconnection();

    // Validate academic program
    $AcademicProgram = filter_var($AcademicProgram, FILTER_VALIDATE_INT);
    if ($AcademicProgram === false) {
        throw new Exception('Invalid Academic Program format: '. $AcademicProgram);
    }

    // Validate enrollment
    $Enrollment = filter_var($Enrollment, FILTER_VALIDATE_INT);
    if ($Enrollment === false) {
        throw new Exception('Invalid enrollment format: '. $Enrollment);
    }

    // Single stored procedure call with JSON data
    $query = "CALL SP_AddStudentToClassRoster(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [
        $AvailableCourseIdx,
        __DB_ENCRYPTION_KEY,
        $StudentData  // Pass JSON string directly
    ]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    error_log("Database error: " . $e->getMessage());
    echo "0x00000500";

} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    echo "0x00000000";
}
?>