<?php
/**
 * Faculty Information
 * Description: Listing faculty position information
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 *
 */



include_once 'session_handler.php';

//--------------------------------- DB PROCESS ------------------------------------------------------

require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

$Query = "SELECT * FROM `Positions` ORDER BY `Name`";
$result = $DBCONNECTION->sendquery($Query);
//echo $Query;

//echo ("<option value=\"\"></option>");

if($DBCONNECTION->num_rows() > 0)//if it finds any row
{
    $idx=1;
    while($row  = $DBCONNECTION->fetch_assoc())
    {
        echo ("<option value=\"".$row["Idx"]."\" style=\"font-size:10pt;\">".$row["Name"]."</option>");
        $idx++;
    }
}
