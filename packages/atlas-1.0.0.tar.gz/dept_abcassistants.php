<?php
/**
 * Abet courses
 * Description: Assign assistant to the abet courses
 * Author: Dong Hyun Jeong
 *
 * 09/21/2025 - initial version created
 * 03/29/2026 - fix highlight assistants in a popped dialog based on the selected row data.
 */

include('checker_programdirector.php');
include('header.php');
?>

<?php

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}
// determine if the user has access control privilege to the selected program.
$AccessControl = false;
if ($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']])
    $AccessControl = true;
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true)
    $AccessControl = true;


// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection();

include('./php_include/dbfunctions.php');
$AcademicYearOptions = GetAcademicYearOption_in_StudentOutcomes();

$Duplicate_AbetCourses_AcademicYearOptions_From = GetAcademicYearOption_in_AbetCourses_Exists($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);
$Duplicate_AbetCourses_AcademicYearOptions_To = GetAcademicYearOption_in_AbetCourses_NotExists($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);

?>

<script src="js/datatable-utils-search.min.js"></script>


<script type="text/javascript">

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
    };

    var DataTable_AbetCourseAssistantsList = null;

    //---------------------------------------------------------------------------------------
    function AssignAssistants()
    {
        let selected = DataTable_AbetCourseAssistantsList.rows({ selected: true }).data();
        if (selected.length === 0) {
            Swal.fire({title:"ERROR", text: "Please select abet courses first!", icon:"error"});
            return;
        }

        // Create an array for the selected abet courses
        let AbetCourseIdx = '';
        let allAssistantIdxes = new Set(); // Use Set to avoid duplicates

        for(let i = 0; i < selected.length; ++i) {
            if (AbetCourseIdx !== '') AbetCourseIdx += "|";
            AbetCourseIdx += encodeURIComponent(selected[i].Idx);

            // Collect assistant IDs from each selected course
            if (selected[i].Assistants && selected[i].Assistants.trim() !== '') {
                const assistantIds = selected[i].Assistants.split(',');
                assistantIds.forEach(id => {
                    const trimmedId = id.trim();
                    if (trimmedId !== '') {
                        allAssistantIdxes.add(trimmedId);
                    }
                });
            }
        }

        // Convert Set to comma-separated string
        const assistantsString = allAssistantIdxes.size > 0
            ? Array.from(allAssistantIdxes).join(',')
            : null;

        AssignAssistantsDlg(AbetCourseIdx, assistantsString);
    }

    function AssignAssistantsDlg(CourseIdx, Assistants=null) {
        let DataTable_Assistants_List = null;
        let initiallySelectedRows = []; // Store initially selected assistants
        let currentlySelectedRows = []; // Store currently selected assistants

        const content = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<div class="CSSTable_SSPSLIST" style="min-height:370px;">'
            + '<table id="assistants_list" class="display" style="border-spacing:0; padding:0; width:100%;">'
            + '<thead>'
            + '<tr>'
            + ' <th class="no-sort" style="width:3px"></th>'
            + ' <th>NAME</th>'
            + ' <th>POSITION</th>'
            + ' <th>AFFILIATION</th>'
            + '</tr>'
            + '</thead>'
            + '<thead id="serachbox" class="filters">'
            + '<tr>'
            + ' <th></th>'
            + ' <th>NAME</th>'
            + ' <th>POSITION</th>'
            + ' <th>AFFILIATION</th>'
            + '</tr>'
            + '</thead>'
            + '<tfoot>'
            + '<tr>'
            + ' <th></th>'
            + ' <th>NAME</th>'
            + ' <th>POSITION</th>'
            + ' <th>AFFILIATION</th>'
            + '</tr>'
            + '</tfoot>'
            + '</table>'
            + '</div></form>';

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN / UNASSIGN ASSISTANTS</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){
                        const selected_assistants = DataTable_Assistants_List.rows({ selected: true }).data();
                        let selected_assistants_list = '';
                        for(let i = 0; i < selected_assistants.length; ++i) {
                            if (selected_assistants_list !== '') selected_assistants_list += "|";
                            selected_assistants_list += encodeURIComponent(selected_assistants[i].Idx);
                        }

                        // Get newly checked and unchecked items
                        const newlyChecked = currentlySelectedRows.filter(id => !initiallySelectedRows.includes(id));
                        const newlyUnchecked = initiallySelectedRows.filter(id => !currentlySelectedRows.includes(id));

                        // console.log("Newly checked assistants:", newlyChecked);
                        // console.log("Newly unchecked assistants:", newlyUnchecked);

                        // You can pass this information to your server if needed
                        AssignAssistants_Perform(CourseIdx, selected_assistants_list, newlyChecked, newlyUnchecked);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        });

        // Define a custom sorting function to the selected rows
        $.fn.dataTable.ext.order['dom-checkbox'] = function  ( settings, col ) {
            return this.api().column( col, {order:'index'} ).nodes().map( function ( td, i ) {
                return $(td).closest('tr').hasClass('selected') ? '1' : '0';
            } );
        }

        DataTable_Assistants_List = $("#assistants_list").DataTable({
            processing: true,
            serverSide: false,
            pageLength: 7,
            lengthChange: false,
            dom: 'tip', // Show table, info, and pagination only
            ajax: {
                url: "ssps/dept_abcassistants_list_ssps.php",
                dataSrc: function(json) {
                    // Store initial and current selections from Assistants data
                    if (Assistants !== null && Assistants.trim() !== '') {
                        const assistantIdxes = Assistants.split(",").map(str => parseInt(str.trim(), 10));
                        initiallySelectedRows = [...assistantIdxes];
                        currentlySelectedRows = [...assistantIdxes];
                    }
                    return json.data;
                }
            },
            order: [[1, 'asc']],
            columns: [
                {
                    data: null,
                    orderable: false,
                    className: 'select-checkbox',
                    defaultContent: ''
                },
                { data: 'Name' },
                { data: 'Position' },
                { data: 'Affiliation' }
            ],
            columnDefs: [
                {
                    targets: '_all',
                    className: 'dt-center'
                },
                {
                    targets: 'no-sort',
                    orderable: false
                }
            ],
            select: {
                style: 'multi',
                selector: 'td:not(:first-child)' // Allow clicking anywhere except the checkbox column
            },
            initComplete: function() {
                // Pre-select rows after DataTable is fully initialized
                if (Assistants !== null && Assistants.trim() !== '') {
                    const assistantIdxes = Assistants.split(",").map(str => parseInt(str.trim(), 10));

                    DataTable_Assistants_List.rows().every(function() {
                        const rowData = this.data();
                        if (assistantIdxes.includes(parseInt(rowData.Idx, 10))) {
                            this.select();
                        }
                    });
                }
            }
        });

        // Listen for select/deselect events
        DataTable_Assistants_List.on('select', function(e, dt, type, indexes) {
            if (type === 'row') {
                indexes.forEach(index => {
                    const rowData = DataTable_Assistants_List.row(index).data();
                    const rowId = parseInt(rowData.Idx, 10);
                    if (!currentlySelectedRows.includes(rowId)) {
                        currentlySelectedRows.push(rowId);
                    }
                });
            }
        });

        DataTable_Assistants_List.on('deselect', function(e, dt, type, indexes) {
            if (type === 'row') {
                indexes.forEach(index => {
                    const rowData = DataTable_Assistants_List.row(index).data();
                    const rowId = parseInt(rowData.Idx, 10);
                    const idx = currentlySelectedRows.indexOf(rowId);
                    if (idx !== -1) {
                        currentlySelectedRows.splice(idx, 1);
                    }
                });
            }
        });

        // Listen for select/deselect events
        DataTable_Assistants_List.on('select', function(e, dt, type, indexes) {
            if (type === 'row') {
                indexes.forEach(index => {
                    const rowData = DataTable_Assistants_List.row(index).data();
                    const rowId = parseInt(rowData.Idx, 10);
                    if (!currentlySelectedRows.includes(rowId)) {
                        currentlySelectedRows.push(rowId);
                    }
                });
            }
        });

        DataTable_Assistants_List.on('deselect', function(e, dt, type, indexes) {
            if (type === 'row') {
                indexes.forEach(index => {
                    const rowData = DataTable_Assistants_List.row(index).data();
                    const rowId = parseInt(rowData.Idx, 10);
                    const idx = currentlySelectedRows.indexOf(rowId);
                    if (idx !== -1) {
                        currentlySelectedRows.splice(idx, 1);
                    }
                });
            }
        });

        // Apply custom sorting to the selected rows
        DataTable_Assistants_List.order([0,'desc']).draw();

        // Setup - add a text input to each footer cell
        $('#assistants_list #serachbox th').each( function () {
            const title = $(this).text();
            if (title !== "") $(this).html( '<input type="text" name="searchbox" placeholder="Search '+title+'" style="color:black; width: 100%;padding:1px;box-sizing: border-box;"/>' );
        } );

        $('#assistants_list tfoot th').each( function () {
            const title = $(this).text();
            if (title !== "") $(this).html( '<input type="text" placeholder="Search '+title+'" style="color:black; width: 100%;padding:1px;box-sizing: border-box;"/>' );
        } );

        // Apply the search
        DataTable_Assistants_List.columns().every( function (colIdx) {
            const that = this;
            $(
                'input',
                $('.filters th').eq($(DataTable_Assistants_List.column(colIdx).header()).index())
            ).on( 'keyup change', function () {
                if ( that.search() !== this.value ) {
                    that.search( this.value )
                        .draw();
                }
            });

            $( 'input', this.footer() ).on( 'keyup change', function () {
                if ( that.search() !== this.value ) {
                    that.search( this.value )
                        .draw();
                }
            });
        } );
    }


    async function AssignAssistants_Perform(CourseIdx, selectedAssistants, newlyChecked = [], newlyUnchecked = []) {
        try {
            const result = await async_commons.makeApiCall('dept_abcassistants_assign_ajax.php', {
                crsidx: CourseIdx,
                astntsidxes: selectedAssistants,
                newlyChecked: JSON.stringify(newlyChecked),
                newlyUnchecked: JSON.stringify(newlyUnchecked)
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Assistant information has been updated');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
            // Hide spinner and show notification
            hideFullPageSpinner();
        }
    }

</script>

<script class="init">
    $(document).ready(function() {
        var SelectedAcademicYear = '<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>';
        const szURL = 'ssps/dept_abctas_ssps.php?_AY=';

        DataTable_AbetCourseAssistantsList = $("#AbetCourseAssistants").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            stateSave: true,
            processing: true,
            serverSide: true,
            lengthMenu: [30, 50, 100, 150, 200, 300, 400],
            ajax: `${szURL}${SelectedAcademicYear}`,
            language: {
                infoFiltered: ''
            },
            order: [[3, 'asc'], [4, 'asc'], [5, 'asc']],
            columns: [
                {
                    data: null,
                    className: 'select-checkbox',
                    defaultContent: '',
                    orderable: false
                },
                { data: 'Semester' },
                { data: 'CRN' },
                { data: 'Subject' },
                { data: 'Num' },
                { data: 'Title' },
                { data: 'Credits' },
                { data: 'Level' },
                { data: 'Instructor' },
                { data: 'AssistantNames' },
                {
                    data: null,
                    orderable: false,
                    className: 'text-center',
                    render: function(data, type, row) {
                        return `<button class="assign-unassign-assistants btn btn-danger btn-xs glyphicon glyphicon-user"
                                id="assign_unassign_assistants"
                               alt="Assign/Unassign Assistants"
                               title="Assign/Unassign Assistants"
                               style="min-height: 20px;"></button>`;
                    }
                }
            ],
            columnDefs: [
                {
                    targets: 'no-sort',
                    orderable: false
                }
            ],
            select: {
                style: 'multi',
                selector: 'td:not(:last-child)' // Allow clicking anywhere except action column
            },
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'landscape',
                    pageSize: 'LETTER',
                    title: function() {
                        const selectedText = document.forms["changefrm"]["CH_APR"].options[document.forms["changefrm"]["CH_APR"].selectedIndex].text;
                        return `ASSISTANTS TO ASSESSING THE COURSES (${selectedText})`;
                    },
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> PDF',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff; margin-left:8px;'
                    },
                    exportOptions: {
                        columns: [1, 2, 3, 4, 5, 6, 7, 8, 9]
                    },
                    customize: function(doc) {
                        // Set font sizes
                        doc.styles.tableHeader.fontSize = 10;
                        doc.defaultStyle.fontSize = 9;

                        // Make table fit to page width
                        doc.content[1].table.widths = Array(doc.content[1].table.body[0].length).fill('auto');

                        // Alternatively, set specific column widths (percentages that total 100%)
                        // doc.content[1].table.widths = ['5%', '8%', '7%', '8%', '6%', '20%', '7%', '8%', '18%', '13%'];

                        // Set table layout to fit page
                        doc.content[1].layout = {
                            hLineWidth: function(i, node) { return 0.5; },
                            vLineWidth: function(i, node) { return 0.5; },
                            hLineColor: function(i, node) { return '#aaa'; },
                            vLineColor: function(i, node) { return '#aaa'; },
                            paddingLeft: function(i, node) { return 4; },
                            paddingRight: function(i, node) { return 4; },
                            paddingTop: function(i, node) { return 2; },
                            paddingBottom: function(i, node) { return 2; }
                        };

                        // Adjust page margins
                        doc.pageMargins = [20, 40, 20, 40]; // [left, top, right, bottom]

                        // Make sure content doesn't overflow
                        doc.styles.tableBodyOdd = { fillColor: '#f3f3f3' };
                        doc.styles.tableBodyEven = { fillColor: '#ffffff' };
                    }
                },
                {
                    extend: 'excelHtml5',
                    title: function() {
                        const selectedText = document.forms["changefrm"]["CH_APR"].options[document.forms["changefrm"]["CH_APR"].selectedIndex].text;
                        return `ASSISTANTS TO THE ABET COURSES (${selectedText})`;
                    },
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff;'
                    },
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
                    }
                }
            ],
            initComplete: function(settings, json) {
                // Add "Clear Filter" button
                const btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + settings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));

                $('#' + settings.sTableId + '_wrapper .btnClearDataTableFilter').click(function() {
                    DataTable_AbetCourseAssistantsList.search('').draw();
                });
            },
            drawCallback: function() {
                this.api().state.clear(); // Clear state after reload

                const table = $('#AbetCourseAssistants');

                // Center align specific columns
                const centerColumns = [1, 2, 3, 4, 5, 7, 8, 9, 10, 11];
                centerColumns.forEach(col => {
                    table.find(`tr td:nth-child(${col})`).css('text-align', 'center');
                });

                // Set vertical align for checkbox column
                table.find('tr td:nth-child(1)').css('vertical-align', 'bottom');

                // Set min-width for data columns
                const minWidthColumns = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
                minWidthColumns.forEach(col => {
                    table.find(`tr td:nth-child(${col})`).css('min-width', '80px');
                });

                // Set width for action column
                table.find('tr td:nth-child(11)').css('width', '110px');
            }
        });

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_AbetCourseAssistantsList.ajax.url(tmpURL).load();
        });

        // Initialize the column search functionality
        new DataTableSearch('#AbetCourseAssistants', DataTable_AbetCourseAssistantsList);

        // Set the DataTable in AsyncCommons
        async_commons.setDataTable(DataTable_AbetCourseAssistantsList);

        // Enable toggle-all button
        $('#AbetCourseAssistants').on('click', '.toggle-all', function() {
            $(this).closest("tr").toggleClass("selected");
            if ($(this).closest("tr").hasClass("selected")) {
                DataTable_AbetCourseAssistantsList.rows({ page: 'current' }).select();
            }
            else {
                DataTable_AbetCourseAssistantsList.rows({ page: 'current' }).deselect();
            }
        });

        $('#AbetCourseAssistants tbody').on( 'click', '#assign_unassign_assistants', function () {
            const data = DataTable_AbetCourseAssistantsList.row( $(this).parents('tr') ).data();
            AssignAssistantsDlg(data.Idx, data.Assistants);
            return false; // disable row selection action
        } );

    } );

</script>

<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">ASSISTANTS TO THE ABET COURSES</p>
        <?php include('control_selprogram.php'); ?>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:20%; min-width:350px;">
                    <?php echo($AcademicYearSelection);?>
                </td>
                <td style="width:5%"></td>
                <td style="width:75%; text-align: right">
              <?php
if ($AccessControl) { // available only to the people who have access controls to programs
?>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-user" onclick="AssignAssistants();return false;">&nbsp;ASSIGN ASSISTANTS</button>
<?php
}
?>
                </td>
            </tr>
        </table>


        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="AbetCourseAssistants" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th class="toggle-all" style="width:3px; "></th>
                    <th style="width:50px">SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>LEVEL</th>
                    <th>INSTRUCTOR</th>
                    <th>ASSISTANT</th>
                    <th class="no-sort">OPERATION</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th></th>
                    <th>SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>LEVEL</th>
                    <th>INSTRUCTOR</th>
                    <th>ASSISTANT</th>
                    <th></th>
                </tr>
                </tfoot>
            </table>
        </div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-user" style="pointer-events: none;"></span>: Assign / Unassign Assistants
                </td>
            </tr>
        </table>
    </div>
</div>


<?php include('footer.php');?>



