<?php
/**
 * Listing Courses
 * Description: listing courses for collecting course materials
 * Author: Dong Hyun Jeong
 *
 * 02/04/2025 - initial version created
 * 08/09/2026 - Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */

include_once 'session_handler.php';

if (array_key_exists('_AY', $_GET)) {
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = trim($_GET['_AY']);
}

// the following is used for administrator
if (array_key_exists('_DEPT', $_GET)) {
    $_SESSION['ATLAS_SELECTED_DEPARTMENT'] = trim($_GET['_DEPT']);
}

// the following is used for administrator
if (array_key_exists('_INSTR', $_GET)) {
    $InstructorEmail = trim($_GET['_INSTR']);
}

// DB table to use
$table = 'AVCourses';
$joinQuery = " FROM `AVCourses` AS `AVCRSES`
    INNER JOIN `AcademicYears` AS `AYS` ON (`AVCRSES`.`Semester` BETWEEN `AYS`.`From` AND `AYS`.`To`)
    INNER JOIN `Subjects` AS `SBJTS` ON (`SBJTS`.`Name`=`AVCRSES`.`Subject`)
    LEFT JOIN `Semesters` AS `SMSTRS` ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
    LEFT JOIN `AVCourses_Assistants` AS `AVCRSES_ASSNTS` ON (`AVCRSES`.`Idx`=`AVCRSES_ASSNTS`.`AVCourseIdx`)
    LEFT JOIN `UserAccounts` AS `UA` ON (`AVCRSES_ASSNTS`.`Assistant`=`UA`.`Idx`)
    LEFT JOIN `AVCourses_CrsMaterials` AS `CRSMAT` ON (`AVCRSES`.`Idx`=`CRSMAT`.`AvailableCourseIdx`)
    LEFT JOIN `AVCourses_InstMaterials` AS `INSTMAT` ON (`AVCRSES`.`Idx`=`INSTMAT`.`AvailableCourseIdx`)";

// Table's primary key
$primaryKey = '`AVCRSES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`AVCRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_'.$row[0];
    }),
    array( 'db' => '`AVCRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),

    // Use MIN() or MAX() to aggregate AcademicYear
    array( 'db' => 'MIN(`AYS`.`AcademicYear`)', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),

    array( 'db' => '`AVCRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`AVCRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`AVCRSES`.`Instructor`', 'dt' => 'Instructor', 'field' => 'Instructor', 'as' => 'Instructor'),
    array( 'db' => '`AVCRSES`.`InstructorEmail`', 'dt' => 'InstructorEmail', 'field' => 'InstructorEmail', 'as' => 'InstructorEmail'),
    array( 'db' => '`AVCRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`AVCRSES`.`Idx`', 'dt' => 'AVCourseIdx', 'field' => 'AVCourseIdx', 'as' => 'AVCourseIdx'),
    array( 'db' => '`AVCRSES`.`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => '`AVCRSES`.`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => '`AVCRSES`.`Actual`', 'dt' => 'Enrollment', 'field' => 'Enrollment', 'as' => 'Enrollment'),
    array( 'db' => '`AVCRSES`.`Syllabus`', 'dt' => 'CourseSyllabus', 'field' => 'CourseSyllabus', 'as' => 'CourseSyllabus'),

    // Use MIN() to aggregate AcademicYear in CONCAT
    array(
        'db' => "CONCAT(MIN(`AYS`.`AcademicYear`), ' (', `SMSTRS`.`Explanation`, ')')",
        'dt' => 'AcademicYearCustomInfo',
        'field' => 'AcademicYearCustomInfo',
        'as' => 'AcademicYearCustomInfo'
    ),
    array(
        'db' => "CONCAT(`AVCRSES`.`Subject`, ' ', `AVCRSES`.`Num`, ' ', `AVCRSES`.`Title`, ' (CRN: ', `AVCRSES`.`CRN`, ')')",
        'dt' => 'CourseCustomInfo',
        'field' => 'CourseCustomInfo',
        'as' => 'CourseCustomInfo'
    ),
    array( 'db' => '`SMSTRS`.`Explanation`', 'dt' => 'SemesterTxt', 'field' => 'SemesterTxt', 'as' => 'SemesterTxt'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT `UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR \', \')', 'dt' => 'Assistant', 'field' => 'Assistant', 'as' => 'Assistant'),
    array( 'db' => 'COUNT(DISTINCT `CRSMAT`.`Idx`)', 'dt' => 'CrsMaterialsCount', 'field' => 'CrsMaterialsCount', 'as' => 'CrsMaterialsCount'),
    array( 'db' => 'COUNT(DISTINCT `INSTMAT`.`Idx`)', 'dt' => 'InstMaterialsCount', 'field' => 'InstMaterialsCount', 'as' => 'InstMaterialsCount'),
    array(
        'db' => "COALESCE((
        SELECT SUM(
            (CASE WHEN StudentSample1 IS NOT NULL AND StudentSample1 != '' THEN 1 ELSE 0 END) +
            (CASE WHEN StudentSample2 IS NOT NULL AND StudentSample2 != '' THEN 1 ELSE 0 END) +
            (CASE WHEN StudentSample3 IS NOT NULL AND StudentSample3 != '' THEN 1 ELSE 0 END)
        )
        FROM AVCourses_CrsMaterials
        WHERE AvailableCourseIdx = `AVCRSES`.`Idx`
    ), 0)",
        'dt' => 'TotalStudentSamples',
        'field' => 'TotalStudentSamples',
        'as' => 'TotalStudentSamples'
    ),
    array(
        'db' => "(
        SELECT COUNT(*)
        FROM AVCourses_CrsMaterials
        WHERE AvailableCourseIdx = `AVCRSES`.`Idx`
    ) * 3",
        'dt' => 'ExpectedStudentSamples',
        'field' => 'ExpectedStudentSamples',
        'as' => 'ExpectedStudentSamples'
    )
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "`AVCRSES`.`CollectMaterials` = 1";

if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'])) {
    if ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] != 'all') {
        $extraWhere .= " AND `AYS`.`Idx` = ". $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
    }
}

//if ( $_SESSION['ATLAS_LOGIN_SYSADMIN'] )
//    // For admin is logged in, it needs to show list of users (for evaluation purpose).
//    $extraWhere .= " AND `AVCRSES`.`InstructorEmail` <> ''";    // showing all courses
//else
//    // Showing only the instructor's courses
//    $extraWhere .= " AND `AVCRSES`.`InstructorEmail` LIKE '%" . $_SESSION['ATLAS_LOGIN_USEREMAIL'] . "%'";


require_once(__DIR__ . '/../../config.php');
if ($_SESSION['ATLAS_LOGIN_USEREMAIL'] == __ADMIN_ACCOUNT_EMAILADDRESS) {
    if (!isset($InstructorEmail) && isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDINSTRUCTOR']))
        $InstructorEmail = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDINSTRUCTOR'];
}

// Determine the target email to filter by
if (isset($InstructorEmail)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDINSTRUCTOR'] = $InstructorEmail;
    $targetEmail = $InstructorEmail;
}
else {
    $targetEmail = $_SESSION['ATLAS_LOGIN_USEREMAIL'];
}

// Use a subquery to filter courses that have the target instructor
if ($extraWhere !="") $extraWhere .= " AND ";
$extraWhere .= "`AVCRSES`.`Idx` IN (
    SELECT `AVINSTR_SUB`.`AVCourseIdx` 
    FROM `AVCoursesInstructors` AS `AVINSTR_SUB` 
    INNER JOIN `UserAccounts` AS `UA_SUB` ON (`AVINSTR_SUB`.`Instructor`=`UA_SUB`.`Idx`) 
    WHERE `UA_SUB`.`Email` = '" . $targetEmail . "'
)";

$groupBy = " `AVCRSES`.`Idx` ";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
