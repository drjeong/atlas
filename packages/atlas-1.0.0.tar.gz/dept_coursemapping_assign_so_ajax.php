<?php
/**
 * Assign SOs to Abet Courses
 * Description: Assigning SOs to the selected abet courses
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 * 04/12/2021 - Change the title "GPI" to "PI"
 *
 */

include_once 'session_handler.php';

$AbetCourseIdxes='';
$AcademicYearIdx='';
$StudentOutcomes='';

if (array_key_exists('ay', $_POST) && array_key_exists('sos', $_POST) && array_key_exists('abetcrs', $_POST))
{
    $AcademicYearIdx = trim($_POST['ay']);
    $StudentOutcomes = trim($_POST['sos']);
    $AbetCourseIdxes = trim($_POST['abetcrs']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYearIdx=="" || $AcademicProgram=="" || $StudentOutcomes=="" || $AbetCourseIdxes==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    $AbetCourseIdxes_Array = explode( '|', $AbetCourseIdxes );
    $SOs_Array = explode( '|', $StudentOutcomes );

    $MultiQuery = "";
    foreach ($AbetCourseIdxes_Array AS $AbetCourseIdx) {
        foreach ($SOs_Array AS $StudentOutcome) {
            $SO = explode( '_', $StudentOutcome ); // $SO[0] -  SO index, $SO[1] - true / false indicator
            $MultiQuery .= "CALL SP_AddCourseMapping_SOs('$AbetCourseIdx', '$SO[0]', '$AcademicYearIdx', '$AcademicProgram', '$SO[1]');";
        }
    }

//    error_log($MultiQuery);
//	echo ($MultiQuery); exit;
    $DBCONNECTION->sendmultiquery($MultiQuery);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
