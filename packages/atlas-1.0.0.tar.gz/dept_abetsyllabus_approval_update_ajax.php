<?php
/**
 * Add Abet Course
 * Description: Adding abet course
 * Author: Dong Hyun Jeong
 *
 * 11/19/2024 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$Courses='';
if (array_key_exists('crses', $_POST) && array_key_exists('approvalinfo', $_POST) && array_key_exists('approvaldate', $_POST))
{
    $Courses = trim($_POST['crses']);
    $ApprovalInfo = trim($_POST['approvalinfo']);
    $ApprovalDate = trim($_POST['approvaldate']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}


$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicProgramIdx=="" || $Courses==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Escape the inputs
    $Courses = $DBCONNECTION->real_escape_string($Courses);
    $ApprovalInfo = $DBCONNECTION->real_escape_string($ApprovalInfo);
    $ApprovalDate = $DBCONNECTION->real_escape_string($ApprovalDate);

    // Single stored procedure call that handles the pipe-delimited list
    $query = "CALL SP_UpdateAbetSyllabus_ApprovalInfo(?, ?, ?);";
//    echo("Query: $query, Courses: $Courses, ApprovalInfo: $ApprovalInfo, ApprovalDate: $ApprovalDate");
//    exit;
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$Courses, $ApprovalInfo, $ApprovalDate]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    echo "0x00000500";  // DB error
    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500'
    ]));

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}