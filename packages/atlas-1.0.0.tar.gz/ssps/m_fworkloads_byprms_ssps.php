<?php
/**
 * Listing Faculty Workloads by Programs
 * File: m_fworkloads_byprms_ssps.php
 * Description: listing faculty workloads with grouped courses filtered by academic program
 *
 * 08/09/2026 Modified to use Semesters table join instead of FUNC_GetYearSem
 */
include_once 'session_handler.php';

// If either session variable is not set or empty, return empty data
if (empty($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM']) || empty($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO'])) {
    echo json_encode(array(
        "draw" => isset($_GET['draw']) ? intval($_GET['draw']) : 0,
        "recordsTotal" => 0,
        "recordsFiltered" => 0,
        "data" => array()
    ));
    exit;
}

require_once(__DIR__ . '/../../config.php');

// DB table to use
$table = 'AVCourses';

// Updated JOIN query to include AbetSyllabus and Courses tables
$joinQuery = "FROM `{$table}` AS `AVCRSES` 
    LEFT JOIN `Semesters` AS `SMSTRS` ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
    LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` ON (`AVCRSES`.`Idx`=`AVINSTRUCTORS`.`AVCourseIdx`) 
    INNER JOIN `UserAccounts` AS `UA` ON (`AVINSTRUCTORS`.`Instructor`=`UA`.`Idx`)
    INNER JOIN `Courses` AS `CRSES` ON (`AVCRSES`.`Subject`=`CRSES`.`Subject` AND `AVCRSES`.`Num`=`CRSES`.`Num`)
    INNER JOIN `AbetSyllabus` AS `SYLLABUS` ON (`CRSES`.`Idx`=`SYLLABUS`.`CourseIndex`)";

// Table's primary key
$primaryKey = 'CRN';

// Array of database columns - simplified for workloads
$columns = array(
    array('db' => '`AVCRSES`.`Semester`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function ($d, $row) {
        return $d; // Return semester code for sorting
    }),
    array('db' => '`AVCRSES`.`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array(
        'db' => '`SMSTRS`.`Explanation`',
        'dt' => 'SemesterTxt',
        'field' => 'SemesterTxt',
        'as' => 'SemesterTxt'
    ),
    array('db' => '`AVCRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array('db' => '`AVCRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array('db' => '`AVCRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array('db' => '`AVCRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array('db' => '(SELECT GROUP_CONCAT(`UA2`.`Name` ORDER BY `UA2`.`Name` SEPARATOR \', \') 
                    FROM `AVCoursesInstructors` AS `AVINST2` 
                    LEFT JOIN `UserAccounts` AS `UA2` ON `AVINST2`.`Instructor`=`UA2`.`Idx` 
                    WHERE `AVINST2`.`AVCourseIdx`=`AVCRSES`.`Idx`)',
        'dt' => 'Instructor',
        'field' => 'Instructor',
        'as' => 'Instructor')
);

require('ssp.join.class.php');

// Build WHERE clause for semester range and academic program
$extraWhere = "";

// Semester range filter using session variables
$SemesterFrom = $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM'];
$SemesterTo = $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO'];

// Create semester range filter
if ($SemesterFrom <= $SemesterTo) {
    $extraWhere = "`AVCRSES`.`Semester` BETWEEN '" . $SemesterFrom . "' AND '" . $SemesterTo . "'";
} else {
    // If FROM is greater than TO, swap them
    $extraWhere = "`AVCRSES`.`Semester` BETWEEN '" . $SemesterTo . "' AND '" . $SemesterFrom . "'";
}

// Add AND for next filter
$extraWhere .= " AND ";

// Academic Program filter
if (!empty($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'])) {
    $extraWhere .= "`SYLLABUS`.`AcademicProgram`='" . $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] . "'";
} else {
    // If no program selected, return no data
    echo json_encode(array(
        "draw" => isset($_GET['draw']) ? intval($_GET['draw']) : 0,
        "recordsTotal" => 0,
        "recordsFiltered" => 0,
        "data" => array()
    ));
    exit;
}

$groupBy = " `AVCRSES`.`Idx` ";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery($_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

