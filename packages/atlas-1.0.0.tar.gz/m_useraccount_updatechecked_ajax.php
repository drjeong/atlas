<?php
/**
 * Management of User Accounts
 * Description: changing the selected user's access privileges
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 */

include('checker_systemadmin.php');


$UserIdx=$_GET['id'];
$Option = trim($_GET['option']);
$Checked = trim($_GET['checked']);
if ($UserIdx=='' || $Option=='' || $Checked==''){
    echo "0x00000011";
    exit;
}
$Checked = ($Checked=='true')?1:0;


//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    $SetField = '';
    switch ($Option)
    {
        case 'SysAdmin':
            $SetField = "`SystemAdmin`=$Checked";
            break;
        case 'AccessDisabled':
            $SetField = "`Disabled`=$Checked";
            break;
        case 'Observer':
            $SetField = "`Observer`=$Checked";
            break;
    }

    if ($SetField != '')
    {
        $Query = "UPDATE `UserAccounts` SET $SetField WHERE `Idx`='$UserIdx'";
        //echo $Query;
        $result = $DBCONNECTION->sendquery($Query);
    }

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}