<?php
include_once 'session_handler.php';

$instructorIdx = isset($_POST['instructorIdx']) ? intval($_POST['instructorIdx']) : 0;

if ($instructorIdx <= 0) {
    echo "0x00000001"; // Invalid parameters
    exit;
}

try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Call the stored procedure
    $query = "CALL SP_RemoveCourseInstructor(?)";
    $DBCONNECTION->prepare_execute_catch_error($query, [$instructorIdx]);

    echo "0x11111111"; // Success

} catch (mysqli_sql_exception $e) {
    $errorMessage = $e->getMessage();

    // Check if it's our custom error code
    if (strpos($errorMessage, '0x00000001') !== false) {
        echo "0x00000001"; // Invalid instructor assignment
    } else {
        error_log("Error removing instructor: " . $errorMessage);
        echo "0x00000500"; // Database error
    }
} catch (Exception $e) {
    error_log("Error removing instructor: " . $e->getMessage());
    echo "0x00000000"; // General error
}

//
//include_once 'session_handler.php';
//
//$instructorIdx = isset($_POST['instructorIdx']) ? intval($_POST['instructorIdx']) : 0;
//
//if ($instructorIdx <= 0) {
//    echo "0x00000001"; // Invalid parameters
//    exit;
//}
//
//try {
//    require_once(__DIR__ . '/php_include/dbconnection_class.php');
//    $DBCONNECTION = new Dbconnection();
//
//    // Get the AVCourseIdx and UserIdx before deleting
//    $query = "SELECT `AVCourseIdx`, `Instructor` FROM `AVCoursesInstructors` WHERE `Idx` = ?";
//    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$instructorIdx]);
//    $row = $result->fetch_assoc();
//
//    if (!$row) {
//        echo "0x00000001"; // Invalid parameters
//        exit;
//    }
//
//    $avcIdx = $row['AVCourseIdx'];
//    $removedUserIdx = $row['Instructor'];
//
//    // Get the primary instructor email before deletion
//    $emailQuery = "SELECT `InstructorEmail` FROM `AVCourses` WHERE `Idx` = ?";
//    $emailResult = $DBCONNECTION->prepare_execute_catch_error($emailQuery, [$avcIdx]);
//    $emailRow = $emailResult->fetch_assoc();
//    $currentPrimaryEmail = $emailRow ? $emailRow['InstructorEmail'] : '';
//
//    // Get the email of the instructor being removed
//    $removedEmailQuery = "SELECT `Email` FROM `UserAccounts` WHERE `Idx` = ?";
//    $removedEmailResult = $DBCONNECTION->prepare_execute_catch_error($removedEmailQuery, [$removedUserIdx]);
//    $removedEmailRow = $removedEmailResult->fetch_assoc();
//    $removedEmail = $removedEmailRow ? $removedEmailRow['Email'] : '';
//
//    // Delete instructor
//    $deleteQuery = "DELETE FROM `AVCoursesInstructors` WHERE `Idx` = ?";
//    $DBCONNECTION->prepare_execute_catch_error($deleteQuery, [$instructorIdx]);
//
//    // Update the Instructor field in AVCourses table
//    updateCourseInstructorField($DBCONNECTION, $avcIdx, $currentPrimaryEmail, $removedEmail);
//
//    echo "0x11111111"; // Success
//
//} catch (mysqli_sql_exception $e) {
//    error_log("Error removing instructor: " . $e->getMessage());
//    echo "0x00000500"; // Database error
//} catch (Exception $e) {
//    error_log("Error removing instructor: " . $e->getMessage());
//    echo "0x00000000"; // General error
//}
//
//function updateCourseInstructorField($DBCONNECTION, $avcIdx, $currentPrimaryEmail, $removedEmail) {
//    // Get all remaining instructors for this course
//    $query = "SELECT ua.`Name`, ua.`Email`
//              FROM `AVCoursesInstructors` aci
//              LEFT JOIN `UserAccounts` ua ON aci.`Instructor` = ua.`Idx`
//              WHERE aci.`AVCourseIdx` = ?
//              ORDER BY ua.`Name` ASC";
//    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$avcIdx]);
//
//    $instructorNames = [];
//    $newPrimaryEmail = '';
//    $firstEmail = '';
//
//    while ($row = $result->fetch_assoc()) {
//        if ($row['Name']) {
//            $instructorNames[] = $row['Name'];
//        }
//        if (empty($firstEmail) && $row['Email']) {
//            $firstEmail = $row['Email'];
//        }
//        // If current primary email matches this instructor, keep it
//        if ($row['Email'] == $currentPrimaryEmail) {
//            $newPrimaryEmail = $currentPrimaryEmail;
//        }
//    }
//
//    // If we removed the primary instructor, assign the first remaining instructor as primary
//    if ($removedEmail == $currentPrimaryEmail && !empty($firstEmail)) {
//        $newPrimaryEmail = $firstEmail;
//    } else if (empty($newPrimaryEmail)) {
//        $newPrimaryEmail = $currentPrimaryEmail;
//    }
//
//    $instructorString = count($instructorNames) > 0 ? implode(', ', $instructorNames) : '';
//
//    // Update AVCourses table
//    $updateQuery = "UPDATE `AVCourses`
//                   SET `Instructor` = ?, `InstructorEmail` = ?
//                   WHERE `Idx` = ?";
//    $DBCONNECTION->prepare_execute_catch_error($updateQuery, [$instructorString, $newPrimaryEmail, $avcIdx]);
//}
