<?php
/**
 * Listing All Courses
 * File: ua_courses_ssps.php
 * Description: listing all courses assigned with instructor information
 *
 * 08/09/2026 Modified to use Semesters table join instead of FUNC_GetYearSem
 */

include_once 'session_handler.php';

$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = 'AbetCourses';
$joinQuery = " FROM `AbetCourses` AS `ABETCRSES` 
    INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`) 
    INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (`ABETCRSES`.`AcademicProgram`=`ACDEMICPRMS`.`Idx`) 
    INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx`= `AVCRSES`.`Idx`)
    LEFT JOIN `Semesters` AS `SMSTRS` ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
    LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` ON (`AVCRSES`.`Idx`=`AVINSTRUCTORS`.`AVCourseIdx`) 
    INNER JOIN `UserAccounts` AS `UA` ON (`AVINSTRUCTORS`.`Instructor`=`UA`.`Idx`) 
    LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABETCRSES`.`Idx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
    LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` ON (`ABETCRSES_GPIS`.`SOIdx`=`ABETCRSES_SOS`.`SOIdx` AND `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
    LEFT JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`ABETCRSES_SOS`.`SOIdx`=`STNTOUTCMS`.`Idx`) 
    LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ABETCRSES_GPIS`.`GPIIdx`) 
    LEFT JOIN `ContinuousImprovement` AS `CNTNUSIMPRVMNT` ON (`CNTNUSIMPRVMNT`.`AvailableCourseIdx`=`AVCRSES`.`Idx` AND `CNTNUSIMPRVMNT`.`AbetCourseIdx`=`ABETCRSES`.`Idx`)
    LEFT JOIN `AbetCourses_Assistants` AS `ASSNTS` ON (`ABETCRSES`.`Idx`=`ASSNTS`.`AbetCourseIdx`)
    LEFT JOIN `UserAccounts` AS `UA2` ON (`ASSNTS`.`Assistant`=`UA2`.`Idx`)
    LEFT JOIN `AssessmentMeasures` AS `ASSSMNT` ON (`ASSSMNT`.`AbetCourseIdx`=`ABETCRSES`.`Idx` AND `ASSSMNT`.`GPI`=`ABETCRSES_GPIS`.`GPIIdx`)
    ";

// Table's primary key
$primaryKey = '`ABETCRSES`.`Idx`';

// Array of database columns
$columns = array(
    array('db' => '`ABETCRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_'.$row[0];
    }),
    array( 'db' => '`ABETCRSES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`ABETCRSES`.`Reference`', 'dt' => 'ReferenceCrsAssessment', 'field' => 'ReferenceCrsAssessment', 'as' => 'ReferenceCrsAssessment'),
    array( 'db' => '`ABETCRSES`.`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => '`ABETCRSES`.`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram'),
    array( 'db' => '`ACDEMICPRMS`.`Name`', 'dt' => 'AcademicProgramName', 'field' => 'AcademicProgramName', 'as' => 'AcademicProgramName'),
    array( 'db' => '`AYS`.`AcademicYear`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => 'CONCAT(`AVCRSES`.`Subject`, \' \', `AVCRSES`.`Num`, \' \', `AVCRSES`.`Title`, \' (CRN: \', `AVCRSES`.`CRN`, \')\')', 'dt' => 'CourseInfo', 'field' => 'CourseInfo', 'as' => 'CourseInfo'),
    array( 'db' => '`AVCRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`AVCRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`AVCRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`AVCRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`AVCRSES`.`Idx`', 'dt' => 'AVCourseIdx', 'field' => 'AVCourseIdx', 'as' => 'AVCourseIdx'),
    array( 'db' => '`AVCRSES`.`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => '`AVCRSES`.`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => '`AVCRSES`.`SurveyReport`', 'dt' => 'SurveyReport', 'field' => 'SurveyReport', 'as' => 'SurveyReport'),
    array( 'db' => '`AVCRSES`.`Actual`', 'dt' => 'Enrollment', 'field' => 'Enrollment', 'as' => 'Enrollment'),
    array( 'db' => '`AVCRSES`.`Syllabus`', 'dt' => 'CourseSyllabus', 'field' => 'CourseSyllabus', 'as' => 'CourseSyllabus', 'formatter' => function( $d, $row ) {
        $return_string = $d;
        if ($return_string == null) $return_string = '';
        return $return_string;
    }),
    array( 'db' => '`SMSTRS`.`Explanation`', 'dt' => 'SemesterTxt', 'field' => 'SemesterTxt', 'as' => 'SemesterTxt'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`UA`.`Name`) ORDER BY `UA`.`Name` SEPARATOR \', \')', 'dt' => 'Instructor', 'field' => 'Instructor', 'as' => 'Instructor'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`UA`.`Email`) ORDER BY `UA`.`Email` SEPARATOR \'; \')', 'dt' => 'InstructorEmail', 'field' => 'InstructorEmail', 'as' => 'InstructorEmail'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`UA2`.`Name`) ORDER BY `UA2`.`Name` SEPARATOR \', \')', 'dt' => 'Assistant', 'field' => 'Assistant', 'as' => 'Assistant'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`UA2`.`Email`) ORDER BY `UA2`.`Email` SEPARATOR \'; \')', 'dt' => 'AssistantEmail', 'field' => 'AssistantEmail', 'as' => 'AssistantEmail'),
    array( 'db' => '`ABETCRSES`.`Syllabus`', 'dt' => 'AbetSyllabus', 'field' => 'AbetSyllabus', 'as' => 'AbetSyllabus', 'formatter' => function( $d, $row ) {
        $return_string = $d;
        if ($return_string == null) $return_string = '';
        return $return_string;
    }),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`ABETCRSES_SOS`.`SOIdx`) ORDER BY `STNTOUTCMS`.`SO` SEPARATOR \', \')', 'dt' => 'SOIdxes', 'field' => 'SOIdxes', 'as' => 'SOIdxes'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`STNTOUTCMS`.`SO`) ORDER BY `STNTOUTCMS`.`SO` SEPARATOR \', \')', 'dt' => 'StudentOutcomes', 'field' => 'StudentOutcomes', 'as' => 'StudentOutcomes'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`ABETCRSES_GPIS`.`GPIIdx`) ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI` SEPARATOR \', \')', 'dt' => 'GPIIdxes', 'field' => 'GPIIdxes', 'as' => 'GPIIdxes'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(CONCAT_WS(\'-\',`STNTOUTCMS`.`SO`, `GPIS`.`GPI`)) ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI` SEPARATOR \', \')', 'dt' => 'GPIs', 'field' => 'GPIs', 'as' => 'GPIs'),
    array( 'db' => '(SELECT GROUP_CONCAT(CONCAT(gpi_idx, \':\', measure_count) ORDER BY gpi_idx SEPARATOR \', \') FROM (SELECT `ABETCRSES_GPIS`.`GPIIdx` as gpi_idx, COUNT(DISTINCT `ASSSMNT`.`Idx`) as measure_count FROM `AbetCourses_GPIs` AS `ABETCRSES_GPIS` LEFT JOIN `AssessmentMeasures` AS `ASSSMNT` ON (`ASSSMNT`.`AbetCourseIdx`=`ABETCRSES`.`Idx` AND `ASSSMNT`.`GPI`=`ABETCRSES_GPIS`.`GPIIdx`) WHERE `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES`.`Idx` GROUP BY `ABETCRSES_GPIS`.`GPIIdx`) as gpi_counts)', 'dt' => 'AssessmentMeasuresCount', 'field' => 'AssessmentMeasuresCount', 'as' => 'AssessmentMeasuresCount'),
    array(
        'db' => '(SELECT COUNT(DISTINCT `SAMPLES`.`Idx`) 
              FROM `AssessmentMeasures` AS `MEASURES` 
              LEFT JOIN `AssessmentMeasureSamples` AS `SAMPLES` 
                ON (`SAMPLES`.`AssessmentMeasureIdx` = `MEASURES`.`Idx`) 
              WHERE `MEASURES`.`AbetCourseIdx` = `ABETCRSES`.`Idx`)',
        'dt' => 'StudentSamplesCount',
        'field' => 'StudentSamplesCount',
        'as' => 'StudentSamplesCount'
    ),
    array( 'db' => 'MAX(SUBSTRING(`CNTNUSIMPRVMNT`.`FacultyReflection`, 1, 2))', 'dt' => 'FacultyReflection', 'field' => 'FacultyReflection', 'as' => 'FacultyReflection')
);

require( 'ssp.join.class.php' );
$extraWhere = '';
if ($AcademicYear != "" && $AcademicYear != "all") {
    $extraWhere .= "`ABETCRSES`.`AcademicYear`='".$AcademicYear."'";
}

if ($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] != '')
{
    if ($extraWhere !="") $extraWhere .= " AND ";
    $extraWhere .= "`ACDEMICPRMS`.`Idx`='".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";
}

// Include all non-aggregated columns in GROUP BY
$groupBy = "`ABETCRSES`.`Idx`, `ABETCRSES`.`Reference`, `ABETCRSES`.`AcademicYear`, `ABETCRSES`.`AcademicProgram`, `ABETCRSES`.`Syllabus`, `ACDEMICPRMS`.`Name`, `AYS`.`AcademicYear`, `AVCRSES`.`Idx`, `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Title`, `AVCRSES`.`Credits`, `AVCRSES`.`Semester`, `AVCRSES`.`CRN`, `AVCRSES`.`SurveyReport`, `AVCRSES`.`Actual`, `AVCRSES`.`Syllabus`";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
