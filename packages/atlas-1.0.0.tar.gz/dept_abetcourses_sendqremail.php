<?php
/**
 * Sending Email
 * Description: Sending email with QR codes to instructors
 *
 * Author: Dong Hyun Jeong
 *
 * 11/20/2025 - initial version created
 */


include_once 'session_handler.php';

header('Content-Type: application/json');

try {
    $instructorDataJson = $_POST['instructorData'] ?? '';
    $instructorData = json_decode($instructorDataJson, true);

    if (empty($instructorData)) {
        echo json_encode(['success' => false, 'message' => 'No instructor data provided']);
        exit;
    }

    $successCount = 0;
    $failedInstructors = [];
    $tempFiles = []; // Track temporary files for cleanup

    // Loop through each instructor
    foreach ($instructorData as $email => $data) {
        try {
            $ToEmailAddress = $email; // Send to actual instructor
            $CCEmailAddress = $_SESSION['ATLAS_LOGIN_USEREMAIL']; // CC if needed
            $instructorName = $data['instructor'];

            // Build course list for email body
            $courseList = '<ul>';
            foreach ($data['courses'] as $course) {
                $courseList .= '<li><strong>' . htmlspecialchars($course['subject']) .
                    htmlspecialchars($course['num']) . '</strong> - ' .
                    htmlspecialchars($course['title']) . '</li>';
            }
            $courseList .= '</ul>';

            // Create email subject
            $Subject = 'Survey QR Codes for Your Courses';

            // Create email message
            $MessageContent = '
                <p>Dear Prof. ' . htmlspecialchars($instructorName) . ',</p>
                <p>Please find attached the QR codes for your course surveys for the following courses:</p>
                ' . $courseList . '
                <p>These QR codes can be displayed in class or shared with students to access the course survey.</p>
                <p>Thank you for your participation in our assessment process.</p>
                <p>Best regards,<br/>Assessment Survey Team</p>
            ';

            // Save QR code images as temporary files
            $qrCodeFiles = [];
            foreach ($data['courses'] as $course) {
                // Decode base64 image
                $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $course['base64']));

                // Create temporary file
                $tempFileName = sys_get_temp_dir() . '/' . $course['filename'] . '.png';
                file_put_contents($tempFileName, $imageData);
                $qrCodeFiles[] = $tempFileName;
                $tempFiles[] = $tempFileName; // Track for cleanup
            }

            // Pass all QR code files as array for multiple attachments
            $attachmentPath = count($qrCodeFiles) > 1 ? $qrCodeFiles : $qrCodeFiles[0];

            // Send email using your existing function
            require_once 'php_include/mail_attachment.php';
            $ReplyToEmailAddress = $_SESSION['ATLAS_LOGIN_USEREMAIL'] ?? __ADMIN_EMAILADDRESS;
            $bcc_email = __ADMIN_EMAILADDRESS;

            $emailSent = SendGMailMessage(
                $ToEmailAddress,
                $CCEmailAddress,
                $bcc_email,
                $Subject,
                $MessageContent,
                $attachmentPath,
                $ReplyToEmailAddress
            );

            if ($emailSent) {
                $successCount++;
            } else {
                $failedInstructors[] = $instructorName . ' (' . $email . ')';
            }

        } catch (Exception $e) {
            error_log('Email error for ' . $email . ': ' . $e->getMessage());
            $failedInstructors[] = $data['instructor'] . ' (' . $email . ')';
        }
    }

    // Cleanup temporary files
    foreach ($tempFiles as $tempFile) {
        if (file_exists($tempFile)) {
            @unlink($tempFile);
        }
    }

    // Return results
    if ($successCount > 0 && empty($failedInstructors)) {
        echo json_encode([
            'success' => true,
            'message' => "Successfully sent emails to $successCount instructor(s)"
        ]);
    } elseif ($successCount > 0 && !empty($failedInstructors)) {
        echo json_encode([
            'success' => true,
            'message' => "Sent to $successCount instructor(s). Failed: " . implode(', ', $failedInstructors)
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => "Failed to send emails. Failed instructors: " . implode(', ', $failedInstructors)
        ]);
    }

} catch (Exception $e) {
    error_log('Server error in QR email: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
