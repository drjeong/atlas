<?php
/**
 * Listing Courses
 * File: u_courses_ssps.php
 * Description: listing courses assigned to each instructor
 *
 * 09/22/2022 - initial version created
 * 03/29/2026 - add to return LinkedGroupId, IsReference, CourseSection
 * 08/09/2026 - Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */

include_once 'session_handler.php';

$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// the following is used for administrator
if (array_key_exists('_INSTR', $_GET)) {
    $InstructorEmail = trim($_GET['_INSTR']);
}

// DB table to use
$table = 'AbetCourses';
$joinQuery = " FROM `AbetCourses` AS `ABETCRSES` 
    INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`) 
    INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (`ABETCRSES`.`AcademicProgram`=`ACDEMICPRMS`.`Idx`) 
    INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx`= `AVCRSES`.`Idx`) 
    LEFT JOIN `Semesters` AS `SMSTRS` ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
    LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABETCRSES`.`Idx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
    LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` ON (`ABETCRSES_GPIS`.`SOIdx`=`ABETCRSES_SOS`.`SOIdx` AND `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
    LEFT JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`ABETCRSES_SOS`.`SOIdx`=`STNTOUTCMS`.`Idx`) 
    LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ABETCRSES_GPIS`.`GPIIdx`)
    LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` ON (`AVCRSES`.`Idx`=`AVINSTRUCTORS`.`AVCourseIdx`) 
    LEFT JOIN `UserAccounts` AS `UA` ON (`AVINSTRUCTORS`.`Instructor`=`UA`.`Idx`)";

// Table's primary key
$primaryKey = '`ABETCRSES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`ABETCRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`ABETCRSES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`ABETCRSES`.`Reference`', 'dt' => 'ReferenceCrsAssessment', 'field' => 'ReferenceCrsAssessment', 'as' => 'ReferenceCrsAssessment'),
    array( 'db' => '`ABETCRSES`.`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => '`ABETCRSES`.`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram'),
    array( 'db' => '`ACDEMICPRMS`.`Name`', 'dt' => 'AcademicProgramName', 'field' => 'AcademicProgramName', 'as' => 'AcademicProgramName'),
    array( 'db' => '`AYS`.`AcademicYear`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => '`AVCRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`AVCRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`AVCRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`AVCRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`AVCRSES`.`Idx`', 'dt' => 'AVCourseIdx', 'field' => 'AVCourseIdx', 'as' => 'AVCourseIdx'),
    array( 'db' => '`AVCRSES`.`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => '`AVCRSES`.`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => '`AVCRSES`.`Actual`', 'dt' => 'Enrollment', 'field' => 'Enrollment', 'as' => 'Enrollment'),
    array( 'db' => '`AVCRSES`.`Syllabus`', 'dt' => 'CourseSyllabus', 'field' => 'CourseSyllabus', 'as' => 'CourseSyllabus'),
    array( 'db' => '`SMSTRS`.`Explanation`', 'dt' => 'SemesterTxt', 'field' => 'SemesterTxt', 'as' => 'SemesterTxt'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT `UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR \', \')', 'dt' => 'Instructor', 'field' => 'Instructor', 'as' => 'Instructor'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT `UA`.`Email` ORDER BY `UA`.`Name` SEPARATOR \', \')', 'dt' => 'InstructorEmail', 'field' => 'InstructorEmail', 'as' => 'InstructorEmail'),
    array( 'db' => '`ABETCRSES`.`Syllabus`', 'dt' => 'AbetSyllabus', 'field' => 'AbetSyllabus', 'as' => 'AbetSyllabus'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`ABETCRSES_SOS`.`SOIdx`) ORDER BY `STNTOUTCMS`.`SO` SEPARATOR \', \')', 'dt' => 'SOIdxes', 'field' => 'SOIdxes', 'as' => 'SOIdxes'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`STNTOUTCMS`.`SO`) ORDER BY `STNTOUTCMS`.`SO` SEPARATOR \', \')', 'dt' => 'StudentOutcomes', 'field' => 'StudentOutcomes', 'as' => 'StudentOutcomes'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT `ABETCRSES_GPIS`.`GPIIdx` ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI` SEPARATOR \', \')', 'dt' => 'GPIIdxes', 'field' => 'GPIIdxes', 'as' => 'GPIIdxes'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT CONCAT_WS(\'-\',`STNTOUTCMS`.`SO`, `GPIS`.`GPI`) ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI` SEPARATOR \', \')', 'dt' => 'GPIs', 'field' => 'GPIs', 'as' => 'GPIs'),
    array( 'db' => '(SELECT GROUP_CONCAT(CONCAT(gpi_idx, \':\', measure_count) ORDER BY gpi_idx SEPARATOR \', \') FROM (SELECT `ABETCRSES_GPIS`.`GPIIdx` as gpi_idx, COUNT(DISTINCT `ASSSMNT`.`Idx`) as measure_count FROM `AbetCourses_GPIs` AS `ABETCRSES_GPIS` LEFT JOIN `AssessmentMeasures` AS `ASSSMNT` ON (`ASSSMNT`.`AbetCourseIdx`=`ABETCRSES`.`Idx` AND `ASSSMNT`.`GPI`=`ABETCRSES_GPIS`.`GPIIdx`) WHERE `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES`.`Idx` GROUP BY `ABETCRSES_GPIS`.`GPIIdx`) as gpi_counts)', 'dt' => 'AssessmentMeasuresCount', 'field' => 'AssessmentMeasuresCount', 'as' => 'AssessmentMeasuresCount'),
    array(
        'db' => '(SELECT COUNT(DISTINCT `SAMPLES`.`Idx`) 
              FROM `AssessmentMeasures` AS `MEASURES` 
              LEFT JOIN `AssessmentMeasureSamples` AS `SAMPLES` 
                ON (`SAMPLES`.`AssessmentMeasureIdx` = `MEASURES`.`Idx`) 
              WHERE `MEASURES`.`AbetCourseIdx` = `ABETCRSES`.`Idx`)',
        'dt' => 'StudentSamplesCount',
        'field' => 'StudentSamplesCount',
        'as' => 'StudentSamplesCount'
    ),
    array(
        'db' => 'COALESCE(`ABETCRSES`.`Reference`, `ABETCRSES`.`Idx`)',
        'dt' => 'LinkedGroupId',
        'field' => 'LinkedGroupId',
        'as' => 'LinkedGroupId'
    ),
    array(
        'db' => 'CONCAT(`AVCRSES`.`Semester`, \'_\', `AVCRSES`.`CRN`)',
        'dt' => 'CourseSection',
        'field' => 'CourseSection',
        'as' => 'CourseSection'
    ),
    array( 'db' => 'IF(`ABETCRSES`.`Reference` IS NULL OR `ABETCRSES`.`Reference` = 0, 0, 1)', 'dt' => 'IsReference', 'field' => 'IsReference', 'as' => 'IsReference'),
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "";
if ($AcademicYear != "" && $AcademicYear != "all") {
    // Data restriction is applied to currently selected academic year
    if ($extraWhere !="") $extraWhere .= " AND ";
    $extraWhere .= "`ABETCRSES`.`AcademicYear`='".$AcademicYear."'";
}

require_once(__DIR__ . '/../../config.php');
if ($_SESSION['ATLAS_LOGIN_USEREMAIL'] == __ADMIN_ACCOUNT_EMAILADDRESS) {
    if (!isset($InstructorEmail) && isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDINSTRUCTOR']))
        $InstructorEmail = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDINSTRUCTOR'];
}

// Determine the target email to filter by
if (isset($InstructorEmail)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDINSTRUCTOR'] = $InstructorEmail;
    $targetEmail = $InstructorEmail;
}
else {
    $targetEmail = $_SESSION['ATLAS_LOGIN_USEREMAIL'];
}

// Use a subquery to filter courses that have the target instructor
if ($extraWhere !="") $extraWhere .= " AND ";
$extraWhere .= "`AVCRSES`.`Idx` IN (
    SELECT `AVINSTR_SUB`.`AVCourseIdx` 
    FROM `AVCoursesInstructors` AS `AVINSTR_SUB` 
    INNER JOIN `UserAccounts` AS `UA_SUB` ON (`AVINSTR_SUB`.`Instructor`=`UA_SUB`.`Idx`) 
    WHERE `UA_SUB`.`Email` = '" . $targetEmail . "'
)";

$groupBy = " `ABETCRSES`.`Idx`, `AVCRSES`.`Idx`, `ABETCRSES`.`AcademicProgram` ";

// Define custom ORDER BY for proper linked course grouping
$customOrderBy = "`AYS`.`AcademicYear` DESC, 
                  `AVCRSES`.`Semester` DESC,
                  COALESCE(`ABETCRSES`.`Reference`, `ABETCRSES`.`Idx`) ASC,
                  IF(`ABETCRSES`.`Reference` IS NULL, 0, 1) ASC,
                  `AVCRSES`.`CRN` ASC,
                  `ABETCRSES`.`Idx` ASC";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery_ordered( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, $customOrderBy, false)
);
