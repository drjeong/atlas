<?php
/**
 * SemesterCodeConfig.php
 *
 * Configuration class for Banner 9 semester code management.
 *
 * Banner 9 uses 6-digit semester codes (YYYYSS format) where:
 * - YYYY = Academic year (4 digits)
 * - SS = Semester suffix (2 digits)
 *
 * Example semester codes:
 * - 202520 = Spring 2025
 * - 202530 = Summer 2025
 * - 202610 = Fall 2025 (note the year increment)
 *
 * Different institutions may use different semester code patterns.
 * This class provides flexible configuration to support various patterns.
 *
 * Banner 9 API Reference:
 * To retrieve all semester terms from Banner 9 Self-Service:
 * GET https://banner.myuniv.edu/StudentRegistrationSsb/ssb/classSearch/getTerms?searchTerm=&offset=1&max=50
 *
 * @see https://banner.myuniv.edu/StudentRegistrationSsb/ssb/classSearch/getTerms?searchTerm=&offset=1&max=50
 */

class SemesterCodeConfig
{
    /**
     * Define semester code patterns for different institutions
     *
     * Each pattern specifies:
     * 1. Semester suffix codes (2-digit codes appended to year)
     * 2. Year offset rules (how the year component relates to calendar year)
     *
     * ========================================================================
     * PATTERN: 'standard' (Traditional Banner 3-semester system)
     * ========================================================================
     * Most common Banner 9 pattern used by many universities
     * - Spring: Suffix '20', Year offset 0 (e.g., Spring 2025 = 202520)
     * - Summer: Suffix '30', Year offset 0 (e.g., Summer 2025 = 202530)
     * - Fall: Suffix '10', Year offset +1 (e.g., Fall 2025 = 202610)
     *
     * Why Fall has +1 offset: Academic years typically start in Fall, so
     * Fall 2025 belongs to the 2025-2026 academic year (thus 202610).
     *
     * ========================================================================
     * PATTERN: 'alternative' (Extended semester system with special sessions)
     * ========================================================================
     * Used by institutions with more granular term definitions
     * - Winter: Suffix '05', Year offset 0 (e.g., Winter 2025 = 202505)
     * - Spring: Suffix '10', Year offset 0 (e.g., Spring 2025 = 202510)
     * - Summer: Suffix '20', Year offset 0 (e.g., Summer 2025 = 202520)
     * - Fall: Suffix '40', Year offset 0 (e.g., Fall 2025 = 202540)
     * - Community: Suffix '45', Year offset 0 (e.g., Community 2025 = 202545)
     * - Saturday: Suffix '07', Year offset 0 (e.g., Saturday 2025 = 202507)
     *
     * ========================================================================
     * PATTERN: 'sequential' (Sequential numbering system)
     * ========================================================================
     * Simple sequential pattern where semesters increment by 1
     * - Fall: Suffix '01', Year offset 0 (e.g., Fall 2025 = 202501)
     * - Spring: Suffix '02', Year offset 1 (e.g., Spring 2026 = 202602)
     * - Summer: Suffix '03', Year offset 1 (e.g., Summer 2026 = 202603)
     *
     * Used by some institutions for simplicity. Spring/Summer belong to the
     * same academic year as the preceding Fall, hence the +1 offset.
     *
     * ========================================================================
     * PATTERN: 'quarters' (Quarter system - 4 terms per year)
     * ========================================================================
     * Common in West Coast universities (e.g., UC system, Stanford)
     * - Fall: Suffix '10', Year offset 0 (e.g., Fall 2025 = 202510)
     * - Winter: Suffix '20', Year offset 1 (e.g., Winter 2026 = 202620)
     * - Spring: Suffix '30', Year offset 1 (e.g., Spring 2026 = 202630)
     * - Summer: Suffix '40', Year offset 1 (e.g., Summer 2026 = 202640)
     *
     * Academic year runs Fall-Summer, so Winter/Spring/Summer increment year.
     *
     * ========================================================================
     * PATTERN: 'trimester' (Three equal terms per year)
     * ========================================================================
     * Less common, but used by some institutions
     * - Fall: Suffix '10', Year offset 0 (e.g., Fall 2025 = 202510)
     * - Winter: Suffix '20', Year offset 1 (e.g., Winter 2026 = 202620)
     * - Spring: Suffix '30', Year offset 1 (e.g., Spring 2026 = 202630)
     *
     * ========================================================================
     * PATTERN: 'mini_terms' (Extended system with multiple sub-sessions)
     * ========================================================================
     * Used by institutions offering many mini-sessions throughout the year
     * Includes full semesters plus A/B/C sub-sessions
     * - Spring Full: '20'
     * - Spring A: '21'
     * - Spring B: '22'
     * - Spring C: '23'
     * - Summer Full: '30'
     * - Summer A: '31'
     * - Summer B: '32'
     * - Summer C: '33'
     * - Fall Full: '10' (offset +1)
     * - Fall A: '11' (offset +1)
     * - Fall B: '12' (offset +1)
     * - Fall C: '13' (offset +1)
     *
     * ========================================================================
     * PATTERN: 'international' (Calendar year based system)
     * ========================================================================
     * Common in international universities where academic year follows
     * calendar year (January-December)
     * - Winter: Suffix '10', Year offset 0
     * - Spring: Suffix '20', Year offset 0
     * - Summer: Suffix '30', Year offset 0
     * - Fall: Suffix '40', Year offset 0
     *
     * All semesters in the same calendar year share the same year code.
     */
    const PATTERNS = [
        // ====================================================================
        // STANDARD PATTERN (Most Common Banner 9)
        // ====================================================================
        'standard' => [
            'spring' => '20',
            'summer' => '30',
            'fall' => '10',
            'year_offset' => [
                'spring' => 0,    // Spring 2025 = 202520
                'summer' => 0,    // Summer 2025 = 202530
                'fall' => 1,      // Fall 2025 = 202610 (next calendar year)
            ],
        ],

        // ====================================================================
        // ALTERNATIVE PATTERN (Extended Sessions)
        // ====================================================================
        'alternative' => [
            'winter' => '05',
            'spring' => '10',
            'summer' => '20',
            'fall' => '40',
            'community' => '45',
            'saturday' => '07',
            'year_offset' => [
                'winter' => 0,    // Winter 2025 = 202505
                'spring' => 0,    // Spring 2025 = 202510
                'summer' => 0,    // Summer 2025 = 202520
                'fall' => 0,      // Fall 2025 = 202540
                'community' => 0, // Community 2025 = 202545
                'saturday' => 0,  // Saturday 2025 = 202507
            ],
        ],

        // ====================================================================
        // SEQUENTIAL PATTERN (Simple Numbering)
        // ====================================================================
        'sequential' => [
            'fall' => '01',
            'spring' => '02',
            'summer' => '03',
            'year_offset' => [
                'fall' => 0,      // Fall 2025 = 202501
                'spring' => 1,    // Spring 2026 = 202602
                'summer' => 1,    // Summer 2026 = 202603
            ],
        ],

        // ====================================================================
        // QUARTERS PATTERN (4 Terms Per Year)
        // ====================================================================
        'quarters' => [
            'fall' => '10',
            'winter' => '20',
            'spring' => '30',
            'summer' => '40',
            'year_offset' => [
                'fall' => 0,      // Fall 2025 = 202510
                'winter' => 1,    // Winter 2026 = 202620
                'spring' => 1,    // Spring 2026 = 202630
                'summer' => 1,    // Summer 2026 = 202640
            ],
        ],

        // ====================================================================
        // TRIMESTER PATTERN (3 Equal Terms)
        // ====================================================================
        'trimester' => [
            'fall' => '10',
            'winter' => '20',
            'spring' => '30',
            'year_offset' => [
                'fall' => 0,      // Fall 2025 = 202510
                'winter' => 1,    // Winter 2026 = 202620
                'spring' => 1,    // Spring 2026 = 202630
            ],
        ],

        // ====================================================================
        // MINI TERMS PATTERN (Multiple Sub-Sessions)
        // ====================================================================
        'mini_terms' => [
            'spring_full' => '20',
            'spring_a' => '21',
            'spring_b' => '22',
            'spring_c' => '23',
            'summer_full' => '30',
            'summer_a' => '31',
            'summer_b' => '32',
            'summer_c' => '33',
            'fall_full' => '10',
            'fall_a' => '11',
            'fall_b' => '12',
            'fall_c' => '13',
            'year_offset' => [
                'spring_full' => 0,
                'spring_a' => 0,
                'spring_b' => 0,
                'spring_c' => 0,
                'summer_full' => 0,
                'summer_a' => 0,
                'summer_b' => 0,
                'summer_c' => 0,
                'fall_full' => 1,    // Fall shifts to next year
                'fall_a' => 1,
                'fall_b' => 1,
                'fall_c' => 1,
            ],
        ],

        // ====================================================================
        // INTERNATIONAL PATTERN (Calendar Year Based)
        // ====================================================================
        'international' => [
            'winter' => '10',
            'spring' => '20',
            'summer' => '30',
            'fall' => '40',
            'year_offset' => [
                'winter' => 0,    // Winter 2025 = 202510
                'spring' => 0,    // Spring 2025 = 202520
                'summer' => 0,    // Summer 2025 = 202530
                'fall' => 0,      // Fall 2025 = 202540
            ],
        ],
    ];

    /**
     * Define month ranges for determining current semester
     *
     * Maps calendar months to semesters for each pattern.
     * Used to automatically determine which semester code to use based on current date.
     *
     * Important notes:
     * - Ranges are evaluated in the order listed (first match wins)
     * - Ranges should not overlap
     * - All 12 months must be covered
     * - Month numbers: 1=January, 12=December
     *
     * ========================================================================
     * STANDARD PATTERN: Traditional Semester Calendar
     * ========================================================================
     * - Fall semester: August-December (months 8-12)
     * - Spring semester: January-April (months 1-4)
     * - Summer semester: May-July (months 5-7)
     *
     * ========================================================================
     * ALTERNATIVE PATTERN: Extended Session Calendar
     * ========================================================================
     * - Fall semester: August-December (months 8-12)
     * - Winter semester: January only (month 1)
     * - Spring semester: February-April (months 2-4)
     * - Summer semester: May-July (months 5-7)
     *
     * ========================================================================
     * SEQUENTIAL PATTERN: Simple Academic Year
     * ========================================================================
     * - Fall semester: August-December (months 8-12)
     * - Spring semester: January-April (months 1-4)
     * - Summer semester: May-July (months 5-7)
     *
     * ========================================================================
     * QUARTERS PATTERN: 4-Quarter System
     * ========================================================================
     * Each quarter is approximately 10-11 weeks
     * - Fall quarter: September-December (months 9-12)
     * - Winter quarter: January-March (months 1-3)
     * - Spring quarter: April-June (months 4-6)
     * - Summer quarter: July-August (months 7-8)
     *
     * ========================================================================
     * TRIMESTER PATTERN: 3-Term System
     * ========================================================================
     * Each term is approximately 14-15 weeks
     * - Fall trimester: August-December (months 8-12)
     * - Winter trimester: January-April (months 1-4)
     * - Spring trimester: May-July (months 5-7)
     *
     * ========================================================================
     * MINI TERMS PATTERN: Full Terms by Default
     * ========================================================================
     * Defaults to full-length terms; sub-sessions handled separately
     * - Fall: August-December (months 8-12)
     * - Spring: January-April (months 1-4)
     * - Summer: May-July (months 5-7)
     *
     * ========================================================================
     * INTERNATIONAL PATTERN: Calendar Year Alignment
     * ========================================================================
     * Aligned with calendar year, starting in January
     * - Winter: January-March (months 1-3)
     * - Spring: April-June (months 4-6)
     * - Summer: July-August (months 7-8)
     * - Fall: September-December (months 9-12)
     */
    const SEMESTER_MONTHS = [
        'standard' => [
            ['semester' => 'fall', 'start' => 8, 'end' => 12],    // Aug-Dec
            ['semester' => 'spring', 'start' => 1, 'end' => 4],   // Jan-Apr
            ['semester' => 'summer', 'start' => 5, 'end' => 7],   // May-Jul
        ],
        'alternative' => [
            ['semester' => 'fall', 'start' => 8, 'end' => 12],    // Aug-Dec
            ['semester' => 'winter', 'start' => 1, 'end' => 1],   // Jan only
            ['semester' => 'spring', 'start' => 2, 'end' => 4],   // Feb-Apr
            ['semester' => 'summer', 'start' => 5, 'end' => 7],   // May-Jul
        ],
        'sequential' => [
            ['semester' => 'fall', 'start' => 8, 'end' => 12],    // Aug-Dec
            ['semester' => 'spring', 'start' => 1, 'end' => 4],   // Jan-Apr
            ['semester' => 'summer', 'start' => 5, 'end' => 7],   // May-Jul
        ],
        'quarters' => [
            ['semester' => 'fall', 'start' => 9, 'end' => 12],    // Sep-Dec
            ['semester' => 'winter', 'start' => 1, 'end' => 3],   // Jan-Mar
            ['semester' => 'spring', 'start' => 4, 'end' => 6],   // Apr-Jun
            ['semester' => 'summer', 'start' => 7, 'end' => 8],   // Jul-Aug
        ],
        'trimester' => [
            ['semester' => 'fall', 'start' => 8, 'end' => 12],    // Aug-Dec
            ['semester' => 'winter', 'start' => 1, 'end' => 4],   // Jan-Apr
            ['semester' => 'spring', 'start' => 5, 'end' => 7],   // May-Jul
        ],
        'mini_terms' => [
            // Default to full terms; sub-sessions handled separately
            ['semester' => 'fall_full', 'start' => 8, 'end' => 12],
            ['semester' => 'spring_full', 'start' => 1, 'end' => 4],
            ['semester' => 'summer_full', 'start' => 5, 'end' => 7],
        ],
        'international' => [
            ['semester' => 'winter', 'start' => 1, 'end' => 3],   // Jan-Mar
            ['semester' => 'spring', 'start' => 4, 'end' => 6],   // Apr-Jun
            ['semester' => 'summer', 'start' => 7, 'end' => 8],   // Jul-Aug
            ['semester' => 'fall', 'start' => 9, 'end' => 12],    // Sep-Dec
        ],
    ];

    /**
     * Real-world institution examples using each pattern
     *
     * This reference helps identify which pattern your institution likely uses.
     */
    const INSTITUTION_EXAMPLES = [
        'standard' => [
            'description' => 'Traditional Banner 9 semester system (most common)',
            'examples' => [
                'Many state universities',
                'Community colleges using Banner',
                'Traditional semester-based institutions',
            ],
            'characteristics' => [
                'Fall term code ends in 10 but belongs to next calendar year',
                'Spring ends in 20, Summer ends in 30',
                'Three main terms per academic year',
            ],
        ],
        'quarters' => [
            'description' => 'Quarter system with 4 terms per year',
            'examples' => [
                'University of California system',
                'Stanford University',
                'Dartmouth College',
                'Northwestern University',
            ],
            'characteristics' => [
                'Four 10-11 week terms',
                'More compressed course schedule',
                'Students typically take 3 terms per year',
            ],
        ],
        'sequential' => [
            'description' => 'Simple sequential numbering',
            'examples' => [
                'Some smaller colleges',
                'Custom implementations',
            ],
            'characteristics' => [
                'Easy to understand: 01, 02, 03',
                'Less common in Banner implementations',
            ],
        ],
        'international' => [
            'description' => 'Calendar year alignment',
            'examples' => [
                'European universities',
                'Asian universities',
                'Institutions with January start dates',
            ],
            'characteristics' => [
                'Academic year follows calendar year',
                'No year offset complications',
            ],
        ],
    ];

    private $pattern;
    private $monthRanges;
    private $patternName;

    /**
     * Constructor
     *
     * @param string $patternName Pattern identifier (default: 'standard')
     * @throws InvalidArgumentException If pattern name is not recognized
     *
     * Usage examples:
     *     $config = new SemesterCodeConfig();                    // Uses 'standard'
     *     $config = new SemesterCodeConfig('quarters');          // For quarter system
     *     $config = new SemesterCodeConfig('international');     // For calendar-year based
     */
    public function __construct($patternName = 'standard')
    {
        if (!isset(self::PATTERNS[$patternName])) {
            $available = implode(', ', array_keys(self::PATTERNS));
            throw new InvalidArgumentException(
                "Unknown pattern: '$patternName'. Available patterns: $available"
            );
        }

        $this->patternName = $patternName;
        $this->pattern = self::PATTERNS[$patternName];
        $this->monthRanges = self::SEMESTER_MONTHS[$patternName];
    }

    /**
     * Get the semester code pattern configuration
     *
     * @return array Pattern configuration including suffixes and year offsets
     */
    public function getPattern()
    {
        return $this->pattern;
    }

    /**
     * Get the month-to-semester mapping ranges
     *
     * @return array Array of semester ranges with start/end months
     */
    public function getMonthRanges()
    {
        return $this->monthRanges;
    }

    /**
     * Get the name of the current pattern
     *
     * @return string Pattern name (e.g., 'standard', 'quarters', 'international')
     */
    public function getPatternName()
    {
        return $this->patternName;
    }

    /**
     * Get all available pattern names
     *
     * @return array List of all supported pattern identifiers
     */
    public static function getAvailablePatterns()
    {
        return array_keys(self::PATTERNS);
    }

    /**
     * Get institution examples for a specific pattern
     *
     * @param string $patternName Pattern identifier
     * @return array|null Examples and characteristics, or null if pattern not found
     */
    public static function getPatternExamples($patternName)
    {
        return self::INSTITUTION_EXAMPLES[$patternName] ?? null;
    }

    /**
     * Get all institution examples
     *
     * @return array Complete mapping of patterns to real-world examples
     */
    public static function getAllExamples()
    {
        return self::INSTITUTION_EXAMPLES;
    }

    /**
     * Detect pattern from sample semester codes
     *
     * Analyzes a set of semester codes to guess which pattern is being used.
     * Useful for automatic configuration.
     *
     * @param array $semesterCodes Array of semester codes (e.g., ['202520', '202530', '202610'])
     * @return string|null Detected pattern name, or null if unable to determine
     *
     * Example:
     *     $detected = SemesterCodeConfig::detectPattern(['202520', '202530', '202610']);
     *     // Returns: 'standard'
     */
    public static function detectPattern(array $semesterCodes)
    {
        if (empty($semesterCodes)) {
            return null;
        }

        // Extract suffixes from semester codes
        $suffixes = array_map(function($code) {
            return substr($code, -2);
        }, $semesterCodes);

        $suffixes = array_unique($suffixes);
        sort($suffixes);

        // Check each pattern
        foreach (self::PATTERNS as $patternName => $pattern) {
            $patternSuffixes = array_values(array_filter($pattern, function($key) {
                return $key !== 'year_offset';
            }, ARRAY_FILTER_USE_KEY));

            sort($patternSuffixes);

            // If suffixes match pattern suffixes (or are a subset)
            if (empty(array_diff($suffixes, $patternSuffixes))) {
                return $patternName;
            }
        }

        return null;
    }
}