<?php
/**
 * Listing courses
 * File: dept_abetcourses_courselist_ssps.php
 * Description: listing courses in a dialog window - shows courses NOT in AbetCourses
 *
 * 12/22/2025 - revised to exclude courses already in AbetCourses for the selected program
 *            - revised to exclude courses without instructor information
 * 08/09/2026 - Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */

include_once 'session_handler.php';

$AcademicYear = '';
$AcademicYear_From = '';
$AcademicYear_To = '';
if (array_key_exists('_AY', $_GET))
{
    $AcademicYear = trim($_GET['_AY']);
}

if ($AcademicYear == "" || $AcademicYear == "all")
{ // error
    exit;
}

// fetching academic year range
require_once(__DIR__ . '/../php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();
$Query = "SELECT `From`, `To` FROM `AcademicYears` WHERE `Idx`=?;";
$result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AcademicYear]);
if ($result && $DBCONNECTION->num_rows() > 0) {
    $row = $DBCONNECTION->fetch_assoc();
    $AcademicYear_From = $row['From'];
    $AcademicYear_To = $row['To'];
}
unset($DBCONNECTION);

$AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

if (!isset($AcademicYear) || !isset($AcademicProgram) ||
    !isset($AcademicYear_From) || !isset($AcademicYear_To)) {
    die(json_encode(['error' => 'Missing required parameters']));
}

$AcademicYear = intval($AcademicYear);
$AcademicProgram = intval($AcademicProgram);
$AcademicYear_From = intval($AcademicYear_From);
$AcademicYear_To = intval($AcademicYear_To);

// DB table to use
$table = 'AVCourses';
$joinQuery = "FROM `{$table}` AS `AVCRSES` 
    INNER JOIN `CourseMapping_Courses` AS `CMCRSES`
        ON `CMCRSES`.`AcademicYear` = {$AcademicYear}
        AND `CMCRSES`.`AcademicProgram` = {$AcademicProgram}
    INNER JOIN `Courses` AS `CRSES` 
        ON `CMCRSES`.`CourseIdx` = `CRSES`.`Idx`
        AND `CRSES`.`Subject` = `AVCRSES`.`Subject` 
        AND `CRSES`.`Num` = `AVCRSES`.`Num`
    LEFT JOIN `Semesters` AS `SMSTRS` 
        ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
    INNER JOIN `AcademicYears` AS `AYS` 
        ON `CMCRSES`.`AcademicYear` = `AYS`.`Idx`
    INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` 
        ON `CMCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`
    INNER JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` 
        ON `AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`
    INNER JOIN `UserAccounts` AS `UA` 
        ON `AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`
    LEFT JOIN `AbetCourses` AS `ABTCRSES` 
        ON `AVCRSES`.`Idx` = `ABTCRSES`.`AVCourseIdx` 
        AND `ABTCRSES`.`AcademicProgram` = {$AcademicProgram}";

// Table's primary key
$primaryKey = '`AVCRSES`.`Idx`';

// Array of database columns
$columns = array(
    array('db' => '`AVCRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId',
        'formatter' => function( $d, $row ) {
            return 'row_'.$row[0];
        }
    ),
    array( 'db' => '`AVCRSES`.`Idx`', 'dt' => 'AVCIdx', 'field' => 'AVCIdx', 'as' => 'AVCIdx'),
    array( 'db' => '`CMCRSES`.`Idx`', 'dt' => 'CMCIdx', 'field' => 'CMCIdx', 'as' => 'CMCIdx'),
    array( 'db' => '`CMCRSES`.`AbetSyllabus`', 'dt' => 'AbetSyllabusIdx', 'field' => 'AbetSyllabusIdx', 'as' => 'AbetSyllabusIdx'),
    array( 'db' => '`CMCRSES`.`Level`', 'dt' => 'Level', 'field' => 'Level', 'as' => 'Level'),
    array( 'db' => '`CMCRSES`.`Requirement`', 'dt' => 'Requirement', 'field' => 'Requirement', 'as' => 'Requirement'),
    array( 'db' => '`AYS`.`AcademicYear`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => '`ACDEMICPRMS`.`Degree`', 'dt' => 'Degree', 'field' => 'Degree', 'as' => 'Degree'),
    array( 'db' => '`SMSTRS`.`Explanation`',
        'dt' => 'SemesterTxt', 'field' => 'SemesterTxt', 'as' => 'SemesterTxt'),
    array( 'db' => '`AVCRSES`.`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => '`AVCRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`AVCRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`AVCRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`AVCRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array(
        'db' => 'GROUP_CONCAT(DISTINCT `UA`.`Name` SEPARATOR \', \')',
        'dt' => 'Instructor',
        'field' => 'Instructor',
        'as' => 'Instructor'
    )
);

require( 'ssp.join.class.php' );

// Filter out courses that already exist in AbetCourses for this AcademicProgram
$extraWhere = "`AVCRSES`.`Semester` BETWEEN $AcademicYear_From AND $AcademicYear_To 
    AND `ABTCRSES`.`Idx` IS NULL";

// Include all non-aggregated columns in GROUP BY
$groupBy = "`AVCRSES`.`Idx`, `CMCRSES`.`Idx`, `CMCRSES`.`AbetSyllabus`, `CMCRSES`.`Level`, `CMCRSES`.`Requirement`, `AYS`.`AcademicYear`, `ACDEMICPRMS`.`Degree`, `SMSTRS`.`Explanation`, `AVCRSES`.`CRN`, `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Title`, `AVCRSES`.`Credits`";

require_once(__DIR__ . '/../php_include/dbconnection.php');
try {
    $result = SSP::joinquery(
        $_GET,
        getSqlConnAttributes(),
        $table,
        $primaryKey,
        $columns,
        $joinQuery,
        $extraWhere,
        $groupBy,
        false
    );
    echo json_encode($result);
} catch (Exception $e) {
    echo json_encode(['error' => 'Database error occurred']);
}

