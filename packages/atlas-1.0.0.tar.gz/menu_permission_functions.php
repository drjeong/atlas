<?php
// Helper functions for menu access checking

function hasAccessToSubmenuGroup($groupCode) {
    // System admins have all access
    if (isset($_SESSION['ATLAS_LOGIN_SYSADMIN']) && $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
        return true;
    }

    // Check if accessible menus are set
    if (!isset($_SESSION['ATLAS_ACCESSIBLE_MENUS'])) {
        return false;
    }

    $menus = $_SESSION['ATLAS_ACCESSIBLE_MENUS'];

    // Check for wildcard (system admin)
    if (is_array($menus) && in_array('*', $menus)) {
        return true;
    }

    // Check if group is in accessible list
    return is_array($menus) && in_array($groupCode, $menus);
}
