<?php
/**
 * Sending Email
 * Description: Sending email with abet syllabus to instructors
 *
 * Author: Dong Hyun Jeong
 *
 * 11/20/2025 - initial version created
 */

include_once 'session_handler.php';
require_once(__DIR__ . '/../config.php');

header('Content-Type: application/json');

try {
    $instructorDataJson = $_POST['instructorData'] ?? '';
    $customSubject = $_POST['emailSubject'] ?? 'ABET Syllabus for Your Courses';
    $ccEmails = $_POST['ccEmails'] ?? '';
    $customMessage = $_POST['emailMessage'] ?? '';

    $instructorData = json_decode($instructorDataJson, true);

    if (empty($instructorData)) {
        echo json_encode(['success' => false, 'message' => 'No instructor data provided']);
        exit;
    }

    $successCount = 0;
    $failedInstructors = [];

    // Parse CC emails
    $ccEmailList = '';
    if (!empty($ccEmails)) {
        // Clean up CC emails - split by comma, trim whitespace, and rejoin
        $ccArray = array_map('trim', explode(',', $ccEmails));
        $ccArray = array_filter($ccArray); // Remove empty entries
        $ccEmailList = implode(', ', $ccArray);
    }

    // Add session email to CC if not already included
    $sessionEmail = $_SESSION['ATLAS_LOGIN_USEREMAIL'] ?? '';
    if (!empty($sessionEmail)) {
        if (empty($ccEmailList)) {
            $ccEmailList = $sessionEmail;
        } else {
            // Check if session email is already in CC list
            $ccArray = array_map('trim', explode(',', $ccEmailList));
            if (!in_array($sessionEmail, $ccArray)) {
                $ccEmailList .= ', ' . $sessionEmail;
            }
        }
    }

    // Loop through each instructor
    foreach ($instructorData as $email => $data) {
        try {
            $ToEmailAddress = $email; // Send to actual instructor
            $CCEmailAddress = $ccEmailList;
            $instructorName = $data['instructor'];

            // Build course list for email body and collect PDF attachments
            $courseList = '<ul>';
            $pdfAttachments = [];
            $uniqueCourses = []; // Initialize here

            foreach ($data['courses'] as $course) {
                // Create a unique key for each course based on critical fields
                $courseKey = $course['subject'] . $course['num'] . $course['semester'] . $course['academicYearInfo'];

                // Check if we've already seen this specific course
                if (!isset($uniqueCourses[$courseKey])) {
                    // If not, add it to our unique list
                    $uniqueCourses[$courseKey] = $course;
                }
            }

            // Now, loop through the unique courses to generate the HTML output
            foreach ($uniqueCourses as $uniqueCourse) {
                $courseList .= '<li><strong>' . htmlspecialchars($uniqueCourse['subject']) .
                    htmlspecialchars($uniqueCourse['num']) . '</strong> - ' .
                    htmlspecialchars($uniqueCourse['title']) .
                    ' (' . htmlspecialchars($uniqueCourse['semester']) . ')';

                // Add academic year info if available
                if (!empty($uniqueCourse['academicYearInfo'])) {
                    $courseList .= ' [' . htmlspecialchars($uniqueCourse['academicYearInfo']) . ']';
                }

                $courseList .= '</li>';
            }
            $courseList .= '</ul>';

            // Generate PDF attachments
            foreach ($data['courses'] as $course) {
                // ABET Syllabus filename (ex, abet_syllabus_2025-2026_bscs_apct_232.pdf)
                $AbetSyllabusFileName = 'abet_syllabus';
                $AbetSyllabusFileName .= '_' . strtolower($course['academicYearInfo']);
                $AbetSyllabusFileName .= '_' . strtolower($course['academicDegreeInfo']);
                $AbetSyllabusFileName .= '_' . strtolower(str_replace(' ', '_', $course['subject']));
                $AbetSyllabusFileName .= '_' . strtolower(str_replace(' ', '_', $course['num']));
                $AbetSyllabusFileName .= '.pdf';

                // Construct the PDF file path for ABET Syllabus
                $AbetSyllabusFile = __DIRECTORY_ABETSYLLABI__ . $course['academicYearInfo'] . DIRECTORY_SEPARATOR . $AbetSyllabusFileName;

                // Create if the syllabus not exists
                if (!file_exists($AbetSyllabusFile)) {
                    // Ensure the directory exists before attempting file operations
                    $targetDir = dirname($AbetSyllabusFile);
                    if (!is_dir($targetDir)) {
                        error_log("Target directory not found: " . $targetDir);
                    }

                    require_once __DIR__ . "/php_include/AbetSyllabusPDFCreator.php";
                    $creator = new AbetSyllabusPDFCreator($course['abetSyllabusIdx'], $AbetSyllabusFile, $course['academicYearIdx'], $course['academicProgramIdx'], 2);
                    $creator->createPDF();
                }

                // Check if PDF file exists before adding to attachments
                if (file_exists($AbetSyllabusFile)) {
                    $pdfAttachments[] = $AbetSyllabusFile;
                } else {
                    error_log("ABET Syllabus PDF file not found: " . $AbetSyllabusFile);
                }
            }

            // Use custom subject
            $Subject = $customSubject;

            // Use custom message and replace placeholders
            $MessageContent = $customMessage;
            $MessageContent = str_replace('[INSTRUCTOR_NAME]', htmlspecialchars($instructorName), $MessageContent);
            $MessageContent = str_replace('[COURSE_LIST]', $courseList, $MessageContent);

            // Since we're using CKEditor, content is already HTML formatted
            // No need for nl2br conversion

            // Send email using your existing function
            require_once 'php_include/mail_attachment.php';
            $ReplyToEmailAddress = $_SESSION['ATLAS_LOGIN_USEREMAIL'] ?? __ADMIN_EMAILADDRESS;
            $bcc_email = __ADMIN_EMAILADDRESS;

            // Prepare attachments - if multiple PDFs, pass as array; if single, pass as string
            $attachmentPath = '';
            if (count($pdfAttachments) > 1) {
                $attachmentPath = $pdfAttachments;
            } elseif (count($pdfAttachments) == 1) {
                $attachmentPath = $pdfAttachments[0];
            }

            // Send email with PDF attachments
            $emailSent = SendGMailMessage(
                $ToEmailAddress,
                $CCEmailAddress,
                $bcc_email,
                $Subject,
                $MessageContent,
                $attachmentPath,
                $ReplyToEmailAddress
            );

            if ($emailSent) {
                $successCount++;
            } else {
                $failedInstructors[] = $instructorName . ' (' . $email . ')';
            }

        } catch (Exception $e) {
            error_log('Email error for ' . $email . ': ' . $e->getMessage());
            $failedInstructors[] = $data['instructor'] . ' (' . $email . ')';
        }
    }

    // Return results
    if ($successCount > 0 && empty($failedInstructors)) {
        echo json_encode([
            'success' => true,
            'message' => "Successfully sent emails to $successCount instructor(s)"
        ]);
    } elseif ($successCount > 0 && !empty($failedInstructors)) {
        echo json_encode([
            'success' => true,
            'message' => "Sent to $successCount instructor(s). Failed: " . implode(', ', $failedInstructors)
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => "Failed to send emails. Failed instructors: " . implode(', ', $failedInstructors)
        ]);
    }

} catch (Exception $e) {
    error_log('Server error in ABET syllabus email: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
