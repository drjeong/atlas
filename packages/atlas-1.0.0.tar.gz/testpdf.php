<?php
//163, null, , 657151400


/**
 * Test PDF Creation with Ghostscript Post-processing
 * This tests the AbetSyllabusPDFCreator to verify the save prompt issue is resolved
 */

// You'll need to provide actual values from your database
// Replace these with valid IDs from your system
$AbetSyllabusIdx = 163;        // Replace with a valid AbetSyllabus ID
$AcademicYearIdx = null;         // Replace with a valid AcademicYear ID
$AcademicProgramIdx = 657151400;      // Replace with a valid AcademicProgram ID

try {
    require_once __DIR__ . "/php_include/AbetSyllabusPDFCreator.php";

    echo "Creating PDF with Ghostscript post-processing...<br>";
    echo "AbetSyllabusIdx: $AbetSyllabusIdx<br>";
    echo "AcademicYearIdx: $AcademicYearIdx<br>";
    echo "AcademicProgramIdx: $AcademicProgramIdx<br><br>";
    $abetSyllabusFile = 'tmp.pdf';

    $creator = new AbetSyllabusPDFCreator($AbetSyllabusIdx, $abetSyllabusFile, $AcademicYearIdx, $AcademicProgramIdx, 1);
    $creator->createPDF();

    echo "PDF created successfully!<br>";

} catch (Exception $e) {
    echo "Error creating PDF: " . $e->getMessage() . "<br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}
