<?php
/**
 * Management of semester info
 * Description: manage semesters
 * Author: Dong Hyun Jeong
 *
 * 08/04/2026 - initial version created
 * 08/05/2026 - revised to handle semester information
 * 08/09/2026 - added Add Selected Semesters feature
 *
 */

include('checker_programdirector.php');
include('header.php');

require_once(__DIR__ . '/../config.php');
?>

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
    ?>

    <script type="text/javascript">
        // Constants
        const ErrorCodes = {
            SUCCESS: '0x11111111',
            SAME_ITEM_EXIST: '0x00200011',
            ITEM_NOT_EXIST: '0x00200012',
            CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
        };

        // Global variable to track selected semesters
        let selectedSemesters = new Set();

        <?php
        if (__COURSE_LISTING_METHOD__ === 'BANNER9') {
        ?>
        async function FetchSemesterInfo()
        {
            try {
                // Reset selected semesters
                selectedSemesters.clear();

                // Show loading message
                Swal.fire({
                    title: 'Fetching Semester Information',
                    text: 'Please wait while we retrieve semester data from the university server...',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                // Fetch semester data from server
                const response = await fetch('m_semesterinfo_fetch_ajax.php', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const result = await response.json();

                // Close loading dialog
                Swal.close();

                if (!result.success) {
                    await Swal.fire({
                        title: 'ERROR',
                        text: result.message || 'Failed to fetch semester information from the university server.',
                        icon: 'error'
                    });
                    return;
                }

                if (!result.semesters || result.semesters.length === 0) {
                    await Swal.fire({
                        title: 'No Data',
                        text: 'No semester data found on the university server.',
                        icon: 'info'
                    });
                    return;
                }

                // Get existing semester codes from the DataTable
                const existingSemesterCodes = new Set();

                // Make sure we get all data, not just the current page
                const allTableData = DataTable_Semesters.rows({search: 'applied'}).data().toArray();

                allTableData.forEach(row => {
                    // Convert to string to ensure proper comparison
                    const code = String(row.SemesterCode).trim();
                    existingSemesterCodes.add(code);
                });

                // Filter: keep all semesters that don't exist yet, remove "(View Only)" text if present
                const filteredSemesters = result.semesters
                    .map(semester => {
                        // Remove "(View Only)" text from description if present
                        return {
                            code: String(semester.code).trim(),
                            description: semester.description
                                ? semester.description.replace(/\s*\(View Only\)\s*/g, '').trim()
                                : ''
                        };
                    })
                    .filter(semester => {
                        // Remove semesters that already exist in the DataTable
                        const exists = existingSemesterCodes.has(semester.code);
                        return !exists;
                    });

                // Check if there are any semesters left after filtering
                if (filteredSemesters.length === 0) {
                    await Swal.fire({
                        title: 'No New Semesters',
                        text: 'All available semesters from the server are already in your system.',
                        icon: 'info'
                    });
                    return;
                }

                // Build table HTML with filtered semester data
                let tableHtml = `
    <div style="max-height: 500px; overflow-y: auto;">
        <table class="table table-striped table-bordered" id="semesterFetchTable" style="width: 100%; margin: 0;">
            <thead style="position: sticky; top: 0; background: white; z-index: 10;">
                <tr>
                    <th style="text-align: center; width: 10%;">
                        <input type="checkbox" id="selectAllSemesters" onchange="toggleSelectAllSemesters(this);" style="cursor: pointer;">
                    </th>
                    <th style="text-align: center; width: 25%;">Semester Code</th>
                    <th style="text-align: left; width: 45%;">Description</th>
                    <th style="text-align: center; width: 20%;">Action</th>
                </tr>
            </thead>
            <tbody>
`;

                filteredSemesters.forEach(semester => {
                    tableHtml += `
        <tr>
            <td style="text-align: center;">
                <input type="checkbox" class="semester-checkbox" data-code="${semester.code}" data-description="${semester.description.replace(/"/g, '&quot;')}" onchange="updateSelectedSemesters();" style="cursor: pointer;">
            </td>
            <td style="text-align: center;">${semester.code}</td>
            <td style="text-align: left;">${semester.description}</td>
            <td style="text-align: center;">
                <button class="btn btn-success btn-xs" onclick="AddSemester('${semester.code}', '${semester.description.replace(/'/g, "\\'")}'); return false;">
                    <span class="glyphicon glyphicon-import"></span> Add
                </button>
            </td>
        </tr>
    `;
                });

                tableHtml += `
            </tbody>
        </table>
    </div>
    <div style="margin-top: 10px; padding: 10px; background-color: #f0f0f0; border-radius: 4px;">
        <strong>Selected:</strong> <span id="selectedCount">0</span> semester(s)
    </div>
`;

                // Show modal with semester data
                createModalDialog({
                    title: '<span class="glyphicon glyphicon-cloud-download" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">FETCH SEMESTER INFORMATION FROM SERVER</span>',
                    message: tableHtml,
                    buttons: {
                        addSelected: {
                            label: "<span class='glyphicon glyphicon-download-alt'></span>&nbsp;ADD SELECTED",
                            className: 'btn-primary',
                            callback: function(){
                                AddSelectedSemesters();
                            }
                        },
                        addAll: {
                            label: "<span class='glyphicon glyphicon-download-alt'></span>&nbsp;ADD ALL",
                            className: 'btn-success',
                            callback: function(){
                                AddAllSemesters(filteredSemesters);
                            }
                        },
                        close: {
                            label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CLOSE",
                            className: 'btn-default',
                            callback: function(){}
                        }
                    }
                });

            } catch (error) {
                Swal.close();
                await Swal.fire({
                    title: 'ERROR',
                    text: 'An error occurred while fetching semester information: ' + error.message,
                    icon: 'error'
                });
                console.error('Error in FetchSemesterInfo:', error);
            }
        }

        function toggleSelectAllSemesters(checkbox) {
            const checkboxes = document.querySelectorAll('.semester-checkbox');
            checkboxes.forEach(cb => {
                cb.checked = checkbox.checked;
            });
            updateSelectedSemesters();
        }

        function updateSelectedSemesters() {
            selectedSemesters.clear();
            const checkboxes = document.querySelectorAll('.semester-checkbox:checked');

            checkboxes.forEach(cb => {
                selectedSemesters.add({
                    code: cb.getAttribute('data-code'),
                    description: cb.getAttribute('data-description')
                });
            });

            // Update count display
            const countElement = document.getElementById('selectedCount');
            if (countElement) {
                countElement.textContent = selectedSemesters.size;
            }

            // Update "Select All" checkbox state
            const selectAllCheckbox = document.getElementById('selectAllSemesters');
            const allCheckboxes = document.querySelectorAll('.semester-checkbox');
            if (selectAllCheckbox && allCheckboxes.length > 0) {
                selectAllCheckbox.checked = allCheckboxes.length === checkboxes.length;
                selectAllCheckbox.indeterminate = checkboxes.length > 0 && checkboxes.length < allCheckboxes.length;
            }
        }

        async function AddSelectedSemesters() {
            if (selectedSemesters.size === 0) {
                await Swal.fire({
                    title: 'No Selection',
                    text: 'Please select at least one semester to add.',
                    icon: 'warning'
                });
                return;
            }

            try {
                const willAddSelected = await Swal.fire({
                    title: 'Confirm Add Selected',
                    html: `Do you want to add <strong>${selectedSemesters.size}</strong> selected semester(s)?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, Add Selected',
                    cancelButtonText: 'Cancel',
                    confirmButtonColor: '#337ab7',
                    cancelButtonColor: '#d33'
                });

                if (!willAddSelected.isConfirmed) return;

                // Show progress
                Swal.fire({
                    title: 'Adding Selected Semesters',
                    html: `Adding semester <span id="current-semester">1</span> of ${selectedSemesters.size}...`,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                let successCount = 0;
                let errorCount = 0;
                let errors = [];
                const semestersArray = Array.from(selectedSemesters);

                for (let i = 0; i < semestersArray.length; i++) {
                    const semester = semestersArray[i];

                    // Update progress
                    const currentSemesterEl = document.getElementById('current-semester');
                    if (currentSemesterEl) {
                        currentSemesterEl.textContent = i + 1;
                    }

                    try {
                        const result = await async_commons.makeApiCall('m_semesterinfo_add_ajax.php', {
                            semesterCode: semester.code,
                            explanation: semester.description
                        });

                        const responseCode = result.trim();
                        if (responseCode === ErrorCodes.SUCCESS) {
                            successCount++;
                        } else if (responseCode === ErrorCodes.SAME_ITEM_EXIST) {
                            errorCount++;
                            errors.push(`${semester.code} - Already exists`);
                        } else {
                            errorCount++;
                            errors.push(`${semester.code} - Unexpected error`);
                        }
                    } catch (error) {
                        errorCount++;
                        errors.push(`${semester.code} - ${error.message}`);
                    }
                }

                // Close progress dialog
                Swal.close();

                // Reload DataTable
                await async_commons.reloadDataTable();

                // Show results
                let resultMessage = `<strong>Successfully added:</strong> ${successCount} semester(s)`;
                if (errorCount > 0) {
                    resultMessage += `<br><strong>Failed:</strong> ${errorCount} semester(s)`;
                    if (errors.length > 0) {
                        resultMessage += `<br><br><div style="text-align: left; max-height: 200px; overflow-y: auto;">`;
                        errors.forEach(error => {
                            resultMessage += `<small>• ${error}</small><br>`;
                        });
                        resultMessage += `</div>`;
                    }
                }

                await Swal.fire({
                    title: 'Add Complete',
                    html: resultMessage,
                    icon: successCount > 0 ? 'success' : 'warning'
                });

            } catch (error) {
                Swal.close();
                await Swal.fire({
                    title: 'ERROR',
                    text: 'An error occurred while adding selected semesters: ' + error.message,
                    icon: 'error'
                });
            }
        }

        async function AddAllSemesters(semesters) {
            try {
                const willAddAll = await Swal.fire({
                    title: 'Confirm Add All',
                    html: `Do you want to add all <strong>${semesters.length}</strong> semesters?`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, Add All',
                    cancelButtonText: 'Cancel',
                    confirmButtonColor: '#5cb85c',
                    cancelButtonColor: '#d33'
                });

                if (!willAddAll.isConfirmed) return;

                // Show progress
                Swal.fire({
                    title: 'Adding Semesters',
                    html: `Adding semester <span id="current-semester">1</span> of ${semesters.length}...`,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                let successCount = 0;
                let errorCount = 0;
                let errors = [];

                for (let i = 0; i < semesters.length; i++) {
                    const semester = semesters[i];

                    // Update progress
                    const currentSemesterEl = document.getElementById('current-semester');
                    if (currentSemesterEl) {
                        currentSemesterEl.textContent = i + 1;
                    }

                    try {
                        const result = await async_commons.makeApiCall('m_semesterinfo_add_ajax.php', {
                            semesterCode: semester.code,
                            explanation: semester.description
                        });

                        const responseCode = result.trim();
                        if (responseCode === ErrorCodes.SUCCESS) {
                            successCount++;
                        } else if (responseCode === ErrorCodes.SAME_ITEM_EXIST) {
                            errorCount++;
                            errors.push(`${semester.code} - Already exists`);
                        } else {
                            errorCount++;
                            errors.push(`${semester.code} - Unexpected error`);
                        }
                    } catch (error) {
                        errorCount++;
                        errors.push(`${semester.code} - ${error.message}`);
                    }
                }

                // Close progress dialog
                Swal.close();

                // Reload DataTable
                await async_commons.reloadDataTable();

                // Show results
                let resultMessage = `<strong>Successfully added:</strong> ${successCount} semester(s)`;
                if (errorCount > 0) {
                    resultMessage += `<br><strong>Failed:</strong> ${errorCount} semester(s)`;
                    if (errors.length > 0) {
                        resultMessage += `<br><br><div style="text-align: left; max-height: 200px; overflow-y: auto;">`;
                        errors.forEach(error => {
                            resultMessage += `<small>• ${error}</small><br>`;
                        });
                        resultMessage += `</div>`;
                    }
                }

                await Swal.fire({
                    title: 'Add Complete',
                    html: resultMessage,
                    icon: successCount > 0 ? 'success' : 'warning'
                });

            } catch (error) {
                Swal.close();
                await Swal.fire({
                    title: 'ERROR',
                    text: 'An error occurred while adding semesters: ' + error.message,
                    icon: 'error'
                });
            }
        }

        async function AddSemester(code, description) {
            try {
                const willAdd = await Swal.fire({
                    title: 'Confirm Add',
                    html: `Do you want to add this semester?<br><br><strong>${code} - ${description}</strong>`,
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, Add',
                    cancelButtonText: 'Cancel',
                    confirmButtonColor: '#5cb85c',
                    cancelButtonColor: '#d33'
                });

                if (!willAdd.isConfirmed) return;

                await AddSemester_Perform(code, description);

            } catch (error) {
                await Swal.fire({
                    title: 'ERROR',
                    text: 'An error occurred while adding semester: ' + error.message,
                    icon: 'error'
                });
            }
        }
        <?php
        }
        ?>

        async function AddSemester_Perform(_SemesterCode, _Explanation) {
            try {
                const result = await async_commons.makeApiCall('m_semesterinfo_add_ajax.php', {
                    semesterCode: _SemesterCode,
                    explanation: _Explanation
                });

                const code = result.trim();
                switch (code) {
                    case ErrorCodes.SUCCESS: {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('ADDED', 'Semester is added successfully!');
                        break;
                    }
                    case ErrorCodes.SAME_ITEM_EXIST: {
                        await async_commons.showErrorMessage(
                            'ERROR',
                            `The entered semester code exists already!`
                        );
                        AddSemesterInfo(_SemesterCode, _Explanation);
                        break;
                    }
                    default: {
                        throw new Error('Unexpected server response');
                    }
                }
            } catch (error) {
                await async_commons.handleError(error);
            }
        }

        function AddSemesterInfo(_SemesterCode='', _Explanation='') {
            const formContent =
                `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
         <table style="border-spacing:0; padding:0; width:100%;">
         <tr><td colspan="2">
         <div class="input-group" style="width:100%; margin-bottom:10px;">
            <span class="input-group-addon" style="width:200px;">Semester Code<span style="color:red">*</span></span>
            <input type="text" placeholder="e.g., 202510, 202501, 202599" class="input-sm form-control" id="_SEMESTERCODE" name="_SEMESTERCODE" value="${_SemesterCode}"/>
         </div>
         <div class="input-group" style="width:100%;">
            <span class="input-group-addon" style="width:200px;">Explanation<span style="color:red">*</span></span>
            <input type="text" placeholder="e.g., Fall 2025, Spring 2025" class="input-sm form-control" id="_EXPLANATION" name="_EXPLANATION" value="${_Explanation}" />
         </div>
         </td></tr>
         </table></form>`;

            createModalDialog({
                title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD SEMESTER INFORMATION</span>',
                message: formContent,
                buttons: {
                    ok: {
                        label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;ADD",
                        className: 'btn-success',
                        callback: function(){
                            const popupForm = document.getElementById('popupfrm');
                            if (!ValidateItems(popupForm)) return false;
                            AddSemester_Perform(popupForm._SEMESTERCODE.value, popupForm._EXPLANATION.value);
                        }
                    },
                    cancel: {
                        label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                        className: 'btn-default',
                        callback: function(){
                        }
                    }
                }
            }).on('shown.bs.modal', function(){
                $("#_SEMESTERCODE").focus();
            });
        }

        function ValidateItems(popupForm) {
            const semesterCodeRegex = /^[0-9]{6}$/;
            const semesterCode = popupForm._SEMESTERCODE.value.trim();
            const explanation = popupForm._EXPLANATION.value.trim();

            if (!semesterCode) {
                popupForm._SEMESTERCODE.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Semester code is not entered!",
                    icon: "error"
                });
                return false;
            }

            if (!semesterCodeRegex.test(semesterCode)) {
                popupForm._SEMESTERCODE.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Please enter a valid 6-digit semester code (e.g., 202510, 202501, 202599)!",
                    icon: "error"
                });
                return false;
            }

            const year = parseInt(semesterCode.substring(0, 4));
            const suffix = semesterCode.substring(4, 6);
            const currentYear = new Date().getFullYear();

            if (year < currentYear - 30 || year > currentYear + 30) {
                popupForm._SEMESTERCODE.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Year in semester code must be within reasonable range (current year ± 30 years)!",
                    icon: "error"
                });
                return false;
            }

            if (!explanation) {
                popupForm._EXPLANATION.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Explanation is not entered!",
                    icon: "error"
                });
                return false;
            }

            if (explanation.length < 3) {
                popupForm._EXPLANATION.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Explanation must be at least 3 characters long!",
                    icon: "error"
                });
                return false;
            }

            return true;
        }

        async function RemoveSemesterInfo(id, code, explanation){
            try {
                const willDelete = await async_commons.showConfirmDialog(
                    `Deleted content (<span style="color:red">${code} - ${explanation}</span>) cannot be restored!`
                );

                if (!willDelete.value) return;
                const result = await async_commons.makeApiCall('m_semesterinfo_remove_ajax.php', {
                    id: id
                });

                const responseCode = result.trim();
                switch (responseCode) {
                    case ErrorCodes.SUCCESS: {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('DELETED', 'The selected semester has been deleted!');
                        break;
                    }
                    case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                        await async_commons.showErrorMessage('ERROR', 'The selected semester cannot be removed!! It has been used already!!');
                        break;
                    }
                    default: {
                        throw new Error('Unexpected server response');
                    }
                }
            } catch (error) {
                await async_commons.handleError(error);
            }
        }

    </script>
    <?php
}
?>

    <script class="init">
        $(document).ready(function() {
            DataTable_Semesters = $("#semesterinfo").DataTable({
                "processing": true,
                "serverSide": false,
                "lengthMenu": [ 30, 50, 75, 100, 150, 300, 500 ],
                "ajax": "ssps/m_semesterinfo_ssps.php",
                "order": [[ 0, "desc" ]],
                "fnInitComplete": function(oSettings, json) {
                    let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                    btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                    $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                        $('#' + oSettings.sTableId).dataTable().fnFilter('');
                    });
                },
                "fnDrawCallback": function() {
                    $('#semesterinfo tr td:nth-child(1)').css('text-align', 'center');
                    $('#semesterinfo tr td:nth-child(2)').css('text-align', 'left');
                    <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
                    $('#semesterinfo tr td:nth-child(3)').css('text-align', 'center');
                    <?php } ?>
                },
                "columns": [
                    { "data": 'SemesterCode' },
                    { "data": 'Explanation' },
                    <?php
                    if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                    ?>
                    { "data": "" }
                    <?php
                    }
                    ?>
                ],
                "columnDefs": [
                    {
                        "targets": 'no-sort',
                        "orderable": false,
                    }
                    <?php
                    if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                    ?>
                    ,{
                        "targets": -1,
                        "data": null,
                        "orderable": false,
                        "defaultContent": "<div style=\"width:100%;text-align:center;\"><button id=\"remove\" class=\"btn btn-danger btn-xs glyphicon glyphicon-remove\" style=\"min-height: 20px;\"></button></div>"
                    }
                    <?php
                    }
                    ?>
                ]
            });

            <?php
            if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
            ?>
            async_commons.setDataTable(DataTable_Semesters);

            $('#semesterinfo tbody').on( 'click', '#remove', function () {
                const data = DataTable_Semesters.row( $(this).parents('tr') ).data();
                RemoveSemesterInfo(data.Idx, data.SemesterCode, data.Explanation);
            } );

            <?php
            }
            ?>
        });

    </script>

    <div class="pagebacklayout">
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">SEMESTER INFORMATION</span>&nbsp;</p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td width="50%"></td>
                    <td width="50%" align="right">
                        <?php
                        if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                            if (__COURSE_LISTING_METHOD__ === 'BANNER9') {
                                ?>
                                <button class="btn btn-primary btn-sm" onclick="FetchSemesterInfo();return false;" style="margin-right: 5px;">
                                    <span class="glyphicon glyphicon-cloud-download"></span> AUTO FETCH FROM SERVER
                                </button>
                                <?php
                            }
                            ?>
                            <button class="btn btn-danger btn-sm" onclick="AddSemesterInfo();return false;">ADD MANUALLY</button>
                            <?php
                        }
                        ?>
                    </td>
                </tr>
            </table>

            <div class="CSSTable_SSPSLIST">
                <table id="semesterinfo" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th>SEMESTER CODE</th>
                        <th>EXPLANATION</th>
                        <?php
                        if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                            ?>
                            <th class="no-sort">OPERATION</th>
                            <?php
                        }
                        ?>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>


<?php include('footer.php');?>