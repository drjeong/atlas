/**
 * D3 ABET Chart Library
 * Reusable charting functions for ABET assessment visualization
 * Creates grouped bar charts with dual axes for student outcome evaluation
 */

(function(window) {
    'use strict';

    // Main AbetChartLibrary object
    const AbetChartLibrary = {
        // Default configuration
        defaultConfig: {
            margin: {
                top: 50,
                right: 60,
                bottom: 60,
                left: 55
            },
            height: 300,
            scaleFactor: 2.5,
            extraBottomSpace: 40,
            categories: [
                { key: "AVG", label: "Avg", color: "steelblue", axis: "primary" },
                { key: "TOPFIFTY", label: "% >= 2", color: "#82c91e", axis: "secondary" },
                { key: "TOPTWENTYFIVE", label: "% >= 3", color: "#f03e3e", axis: "secondary" }
            ]
        },

        /**
         * Initialize and draw charts from data URL
         * @param {string} dataUrl - URL to fetch chart data
         * @param {string} containerSelector - CSS selector for chart container
         * @param {object} options - Optional configuration overrides
         */
        async initCharts(dataUrl, containerSelector, options = {}) {
            const config = { ...this.defaultConfig, ...options };

            try {
                // Fetch Data
                const response = await fetch(dataUrl);
                const chartData = await response.json();

                // Create tooltip div
                const tooltip = d3.select("body").append("div")
                    .attr("class", "abet-chart-tooltip")
                    .style("opacity", 0);

                // Container for chart references
                const chartContainers = [];

                // Get container
                const chartsDiv = d3.select(containerSelector);

                // Create charts
                Object.entries(chartData).forEach(([SO, details]) => {
                    const column = chartsDiv.append("div")
                        .attr("class", "col-md-6 col-lg-4 mb-4");

                    const container = column.append("div")
                        .attr("class", "abet-chart-container");

                    container.append("div")
                        .attr("class", "abet-chart-title")
                        .attr("title", `${SO}: ${details.description}`)
                        .text(`${SO}: ${details.description}`);

                    const overallTotal = details.data.Overall?.TOTAL || 0;
                    container.append("div")
                        .attr("class", "abet-total-label")
                        .text(`Sample Size: ${overallTotal}`);

                    const chartDiv = container.append("div")
                        .attr("class", "abet-chart");

                    const chartId = `abet-chart-${SO.replace(/\s+/g, '-')}`;

                    chartContainers.push({
                        container: chartDiv.node(),
                        data: details,
                        chartId: chartId
                    });

                    this.drawGroupedBarChart(details, chartDiv.node(), chartId, config, tooltip);
                    this.addPrintButton(container.node(), chartId, `${SO}: ${details.description}`);
                    this.addDownloadButton(container.node(), chartId, `${SO}: ${details.description}`, config);
                });

                // Handle window resize
                this.setupResizeHandler(chartContainers, config, tooltip);

            } catch (error) {
                console.error("Error initializing ABET charts:", error);
            }
        },

        /**
         * Transform nested data into array format for D3
         */
        transformData(soData) {
            return Object.entries(soData.data).map(([year, values]) => ({
                AcademicYear: year,
                AVG: parseFloat(values.AVG),
                TOPFIFTY: parseFloat(values.TOPFIFTY),
                TOPTWENTYFIVE: parseFloat(values.TOPTWENTYFIVE),
                TOTAL: parseInt(values.TOTAL)
            }));
        },

        /**
         * Draw a grouped bar chart with dual axes
         */
        drawGroupedBarChart(soData, container, chartId, config, tooltip) {
            const data = this.transformData(soData);
            const containerWidth = container.clientWidth;
            const { margin, height, categories } = config;
            const width = containerWidth;

            // Clear existing content
            d3.select(container).selectAll("*").remove();

            // Create scales
            const x0Scale = d3.scaleBand()
                .domain(data.map(d => d.AcademicYear))
                .range([margin.left, width - margin.right])
                .padding(0.2);

            const x1Scale = d3.scaleBand()
                .domain(categories.map(c => c.key))
                .range([0, x0Scale.bandwidth()])
                .padding(0.05);

            const yScalePrimary = d3.scaleLinear()
                .domain([0, Math.max(4, d3.max(data, d => d.AVG) * 1.1)])
                .nice()
                .range([height - margin.bottom, margin.top]);

            const yScaleSecondary = d3.scaleLinear()
                .domain([0, 100])
                .nice()
                .range([height - margin.bottom, margin.top]);

            // Create SVG
            const svg = d3.select(container)
                .append("svg")
                .attr("width", width)
                .attr("height", height)
                .attr("id", chartId);

            // X Axis
            svg.append("g")
                .attr("class", "axis")
                .attr("transform", `translate(0,${height - margin.bottom})`)
                .call(d3.axisBottom(x0Scale))
                .selectAll("text")
                .attr("transform", "rotate(-45)")
                .style("text-anchor", "end")
                .attr("dx", "-.8em")
                .attr("dy", ".15em");

            // Primary Y Axis
            svg.append("g")
                .attr("class", "axis")
                .attr("transform", `translate(${margin.left},0)`)
                .call(d3.axisLeft(yScalePrimary))
                .append("text")
                .attr("class", "axis-label")
                .attr("transform", "rotate(-90)")
                .attr("y", -40)
                .attr("x", -height / 2)
                .attr("text-anchor", "middle")
                .text("Average Score");

            // Secondary Y Axis
            svg.append("g")
                .attr("class", "axis")
                .attr("transform", `translate(${width - margin.right},0)`)
                .call(d3.axisRight(yScaleSecondary).tickFormat(d => d + "%"))
                .append("text")
                .attr("class", "axis-label")
                .attr("transform", "rotate(-90)")
                .attr("y", 40)
                .attr("x", -height / 2)
                .attr("text-anchor", "middle")
                .text("Percentage");

            // Draw bars
            const barGroups = svg.selectAll(".bar-group")
                .data(data)
                .enter()
                .append("g")
                .attr("class", "bar-group")
                .attr("transform", d => `translate(${x0Scale(d.AcademicYear)},0)`);

            barGroups.selectAll("rect")
                .data(d => categories.map(c => ({
                    key: c.key,
                    value: d[c.key],
                    color: c.color,
                    axis: c.axis,
                    year: d.AcademicYear,
                    total: d.TOTAL
                })))
                .enter()
                .append("rect")
                .attr("class", d => `bar-${d.key.toLowerCase()}`)
                .attr("x", d => x1Scale(d.key))
                .attr("y", d => d.axis === "primary" ? yScalePrimary(d.value) : yScaleSecondary(d.value))
                .attr("width", x1Scale.bandwidth())
                .attr("height", d => {
                    if (d.axis === "primary") {
                        return height - margin.bottom - yScalePrimary(d.value);
                    } else {
                        return height - margin.bottom - yScaleSecondary(d.value);
                    }
                })
                .attr("fill", d => d.color)
                .on("mouseover", function(event, d) {
                    d3.select(this).attr("opacity", 0.8);
                    tooltip.transition().duration(200).style("opacity", .9);

                    let tooltipText = `${d.year}<br>
                        ${d.key === "AVG"
                        ? `Average Score: ${d.value.toFixed(2)}`
                        : `${d.key === "TOPFIFTY" ? "% >= 2" : "% >= 3"}: ${d.value.toFixed(1)}%`}<br>
                        Sample Size: ${d.total}`;

                    tooltip.html(tooltipText)
                        .style("left", (event.pageX + 10) + "px")
                        .style("top", (event.pageY - 28) + "px");
                })
                .on("mouseout", function() {
                    d3.select(this).attr("opacity", 1);
                    tooltip.transition().duration(500).style("opacity", 0);
                });

            // Legend
            const legend = svg.append("g")
                .attr("transform", `translate(${width/2 - 140},${margin.top - 35})`);

            const legendItems = legend.selectAll(".legend-item")
                .data(categories)
                .enter()
                .append("g")
                .attr("class", "legend-item")
                .attr("transform", (d, i) => `translate(${i * 60}, 0)`);

            legendItems.append("rect")
                .attr("width", 12)
                .attr("height", 12)
                .attr("fill", d => d.color);

            legendItems.append("text")
                .attr("x", 16)
                .attr("y", 10)
                .attr("class", "legend")
                .text(d => d.label);
        },

        /**
         * Add print button to chart container
         */
        addPrintButton(container, chartId, title) {
            const printButton = document.createElement("button");
            printButton.className = "abet-chart-print-btn";
            printButton.onclick = () => this.printChart(chartId, title);

            const icon = document.createElement("span");
            icon.className = "glyphicon glyphicon-print";
            icon.style.fontSize = "8px";
            printButton.appendChild(icon);

            Object.assign(printButton.style, {
                position: "absolute",
                background: "#007bff",
                color: "white",
                border: "none",
                borderRadius: "50%",
                width: "16px",
                height: "16px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                zIndex: "10",
                padding: "0",
                lineHeight: "16px",
                bottom: "10px",
                right: "10px"
            });

            container.style.position = "relative";
            container.appendChild(printButton);
        },

        /**
         * Add download button to chart container
         */
        addDownloadButton(container, chartId, title, config) {
            const downloadButton = document.createElement("button");
            downloadButton.className = "abet-chart-download-btn";
            downloadButton.onclick = () => this.downloadChartAsImage(chartId, title, config);

            const icon = document.createElement("span");
            icon.className = "glyphicon glyphicon-download-alt";
            icon.style.fontSize = "8px";
            downloadButton.appendChild(icon);

            Object.assign(downloadButton.style, {
                position: "absolute",
                background: "#28a745",
                color: "white",
                border: "none",
                borderRadius: "50%",
                width: "16px",
                height: "16px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
                zIndex: "10",
                padding: "0",
                lineHeight: "16px",
                bottom: "10px",
                right: "30px"
            });

            container.style.position = "relative";
            container.appendChild(downloadButton);
        },

        /**
         * Print chart in new window
         */
        printChart(chartId, title) {
            const chartElement = document.getElementById(chartId);
            if (!chartElement) {
                console.error("Chart not found:", chartId);
                return;
            }

            const clonedChart = chartElement.cloneNode(true);
            const bbox = chartElement.getBBox();
            const originalWidth = bbox.width || 800;
            const originalHeight = bbox.height || 600;

            const maxWidth = 600;
            const aspectRatio = originalWidth / originalHeight;
            let scaledHeight = maxWidth / aspectRatio;
            const extraPadding = 50;
            scaledHeight += extraPadding;

            clonedChart.setAttribute("viewBox", `0 0 ${originalWidth} ${originalHeight + extraPadding}`);
            clonedChart.setAttribute("width", maxWidth);
            clonedChart.setAttribute("height", scaledHeight);

            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                <head>
                    <title>Print Chart</title>
                    <style>
                        body { text-align: center; font-family: Arial, sans-serif; margin: 0; padding: 0; }
                        svg { max-width: 90vw; height: auto; margin: auto; display: block; }
                        text { font-size: 10px !important; }
                        .legend text { font-size: 8px !important; }
                        .axis text { font-size: 9px !important; }
                        .axis-label { font-size: 8px !important; }
                    </style>
                </head>
                <body>
                    <h2 style="font-size: 14px;">${title}</h2>
                    ${clonedChart.outerHTML}
                    <script>
                        window.onload = function() {
                            setTimeout(() => {
                                window.print();
                                window.onafterprint = () => window.close();
                            }, 500);
                        };
                    <\/script>
                </body>
                </html>
            `);
            printWindow.document.close();
        },

        /**
         * Download chart as PNG image
         */
        downloadChartAsImage(chartId, title, config) {
            const chartElement = document.getElementById(chartId);
            if (!chartElement) {
                console.error("Chart not found:", chartId);
                return;
            }

            const svgElement = chartElement.cloneNode(true);
            const bbox = chartElement.getBBox();
            const originalWidth = bbox.width || 800;
            const originalHeight = bbox.height || 600;

            const { scaleFactor, extraBottomSpace } = config;
            const adjustedHeight = originalHeight + extraBottomSpace;
            const width = originalWidth * scaleFactor;
            const height = adjustedHeight * scaleFactor;

            svgElement.setAttribute('width', width);
            svgElement.setAttribute('height', height);
            svgElement.removeAttribute('viewBox');

            const g = document.createElementNS("http://www.w3.org/2000/svg", "g");
            g.setAttribute('transform', `scale(${scaleFactor})`);

            while (svgElement.firstChild) {
                g.appendChild(svgElement.firstChild);
            }

            const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
            rect.setAttribute("width", width);
            rect.setAttribute("height", height);
            rect.setAttribute("fill", "white");
            svgElement.appendChild(rect);
            svgElement.appendChild(g);

            const allText = svgElement.querySelectorAll('text');
            allText.forEach(text => {
                let fontSize = window.getComputedStyle(text).fontSize || '10px';
                let fontSizeNum = parseFloat(fontSize);
                text.style.fontSize = fontSizeNum + 'px';
            });

            const svgString = new XMLSerializer().serializeToString(svgElement);
            const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
            const url = URL.createObjectURL(svgBlob);

            const img = new Image();
            img.onload = function() {
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');

                ctx.fillStyle = 'white';
                ctx.fillRect(0, 0, width, height);
                ctx.drawImage(img, 0, 0, width, height);

                canvas.toBlob(function(blob) {
                    const link = document.createElement('a');
                    const filename = `${title.replace(/[^a-z0-9]/gi, '_')}.png`;
                    link.download = filename;
                    link.href = URL.createObjectURL(blob);
                    link.click();

                    URL.revokeObjectURL(url);
                    URL.revokeObjectURL(link.href);
                }, 'image/png');
            };

            img.src = url;
        },

        /**
         * Setup resize handler with debounce
         */
        setupResizeHandler(chartContainers, config, tooltip) {
            let resizeTimeout;
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimeout);
                resizeTimeout = setTimeout(() => {
                    chartContainers.forEach(chart => {
                        this.drawGroupedBarChart(chart.data, chart.container, chart.chartId, config, tooltip);
                    });
                }, 250);
            });
        }
    };

    // Expose to window
    window.AbetChartLibrary = AbetChartLibrary;

})(window);