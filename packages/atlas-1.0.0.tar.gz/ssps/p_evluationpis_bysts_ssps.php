<?php
/**
 * Listing Performance Indicators
 * Description: listing performance indicators (per-student averages)
 *
 * 06/07/2026 - initial version created
 * 06/07/2026 - refactored to use PerformanceIndicatorAnalyzer
 *
 */

include_once 'session_handler.php';
require_once('../ssps/PerformanceIndicatorAnalyzer.php');
require_once('../php_include/dbconnection_class.php');

// Get parameters from session
$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// Handle academic years - convert from array to string if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
    // If it's an array, use it directly
    if (!is_array($academicYears)) {
        $academicYears = array(intval($academicYears));
    }
} else {
    // Fallback to single academic year
    $academicYears = array(intval($IN_AcademicYear));
}

// If empty, use the current academic year
if (empty($academicYears)) {
    $academicYears = array(intval($IN_AcademicYear));
}

// Sanitize academic program
$IN_AcademicProgram = intval($IN_AcademicProgram);

// Initialize database connection
$DBCONNECTION = new Dbconnection();

$academicYearsStr = implode(',', array_map('intval', $academicYears));

//
//
//// Step 1: Get all ABET courses for selected academic program and years
//
//$query = "
//    SELECT DISTINCT
//        ABETCRSES.Idx AS AbetCourseIdx,
//        ABETCRSES.AcademicYear AS AcademicYearIdx,
//        AYS.AcademicYear,
//        ABETCRSES.AVCourseIdx AS AvailableCourseIdx,
//        AVCRSES.CourseNo,
//        AVCRSES.Crn
//    FROM `AbetCourses` AS `ABETCRSES`
//    INNER JOIN `AcademicYears` AS `AYS` ON (ABETCRSES.AcademicYear = AYS.Idx)
//    INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (ABETCRSES.AcademicProgram = ACDEMICPRMS.Idx)
//    INNER JOIN `AVCourses` AS `AVCRSES` ON (
//        AYS.`From` <= AVCRSES.Semester
//        AND AYS.`To` >= AVCRSES.Semester
//        AND ABETCRSES.AVCourseIdx = AVCRSES.Idx
//    )
//    WHERE ABETCRSES.AcademicProgram = ?
//      AND ABETCRSES.AcademicYear IN ($academicYearsStr)
//    ORDER BY ABETCRSES.AcademicYear, AVCRSES.CourseNo
//";
//
//$result = $DBCONNECTION->prepare_execute_catch_error($query, [$IN_AcademicProgram]);
//
//$abetCourses = array();
//if ($result && $DBCONNECTION->num_rows() > 0) {
//    while ($row = $DBCONNECTION->fetch_assoc()) {
//        $abetCourses[] = array(
//            'AbetCourseIdx' => $row['AbetCourseIdx'],
//            'AcademicYearIdx' => $row['AcademicYearIdx'],
//            'AcademicYear' => $row['AcademicYear'],
//            'AvailableCourseIdx' => $row['AvailableCourseIdx'],
//            'CourseNo' => $row['CourseNo'],
//            'Crn' => $row['Crn']
//        );
//    }
//}
//
//// Step 2: Collect all individual performance indicator records using PerformanceIndicatorAnalyzer
//$analyzer = new PerformanceIndicatorAnalyzer($DBCONNECTION);
//$piRecords = array(); // Store individual PI scores
//$processedCourses = array();
//
//foreach ($abetCourses as $course) {
//    // Create unique key to avoid processing same course multiple times
//    $courseKey = $course['AbetCourseIdx'] . '_' . $course['AvailableCourseIdx'];
//
//    if (isset($processedCourses[$courseKey])) {
//        continue;
//    }
//    $processedCourses[$courseKey] = true;
//
//    // Use getAnalysis with autoSave=false to get fresh calculated data (not from DB)
//    $analysisData = $analyzer->getAnalysis(
//        $course['AbetCourseIdx'],
//        $course['AvailableCourseIdx'],
//        $IN_AcademicProgram,
//        false  // Don't auto-save, we're just reading
//    );
//
//    if (!empty($analysisData)) {
//        foreach ($analysisData as $piData) {
//            // getAnalysis returns GPI and GPIIdx
//            $gpiCode = isset($piData['GPI']) ? $piData['GPI'] : null;
//            $gpiIdx = isset($piData['GPIIdx']) ? $piData['GPIIdx'] : null;
//
//            // Skip if GPI data is missing
//            if (empty($gpiCode)) {
//                continue;
//            }
//
//            $academicYear = $course['AcademicYear'];
//
//            // Store individual records grouped by Year and GPI code
//            $key = $academicYear . '|' . $gpiCode;
//
//            if (!isset($piRecords[$key])) {
//                $piRecords[$key] = array(
//                    'AcademicYear' => $academicYear,
//                    'GPI' => $gpiCode,
//                    'GPIIdx' => $gpiIdx,
//                    'GPIDescription' => isset($piData['GPIDescription']) ? $piData['GPIDescription'] : '',
//                    'scores' => array()
//                );
//            }
//
//            // Store aggregated course data
//            $piRecords[$key]['scores'][] = array(
//                'avg' => floatval($piData['AVG']),
//                'total' => intval($piData['TOTAL']),
//                'topFifty' => intval($piData['TOPFIFTY']),
//                'topTwentyFive' => intval($piData['TOPTWENTYFIVE'])
//            );
//        }
//    }
//}

// Include the helper functions
require_once('performance_indicator_helpers.php');

// Step 1 & 2 Combined: Ensure analysis is saved and retrieve it
// First, make sure all courses have been analyzed and saved
$saveResults = analyzeAndSavePerformanceIndicators(
    $DBCONNECTION,
    $IN_AcademicProgram,
    $academicYears,
    true  // Force recalculate
);

// Get the saved data from database
$savedCourses = getSavedPerformanceIndicators(
    $DBCONNECTION,
    $IN_AcademicProgram,
    $academicYears
);

// Transform into your existing $piRecords structure
$piRecords = array();

foreach ($savedCourses as $course) {
    $academicYear = $course['academicYear'];

    foreach ($course['indicators'] as $indicator) {
        $gpiCode = $indicator['gpi'];
        $gpiIdx = $indicator['gpiIdx'];

        // Store individual records grouped by Year and GPI code
        $key = $academicYear . '|' . $gpiCode;

        if (!isset($piRecords[$key])) {
            $piRecords[$key] = array(
                'AcademicYear' => $academicYear,
                'GPI' => $gpiCode,
                'GPIIdx' => $gpiIdx,
                'GPIDescription' => $indicator['gpiDescription'],
                'scores' => array()
            );
        }

        // Store aggregated course data
        $piRecords[$key]['scores'][] = array(
            'avg' => $indicator['avg'],
            'total' => $indicator['total'],
            'topFifty' => $indicator['topFifty'],
            'topTwentyFive' => $indicator['topTwentyFive']
        );
    }
}

// Step 3: Aggregate by Academic Year and GPI code
$allGPIData = array();
foreach ($piRecords as $key => $record) {
    $totalStudents = 0;
    $totalScoreSum = 0;
    $topFiftyCount = 0;
    $topTwentyFiveCount = 0;

    foreach ($record['scores'] as $score) {
        $totalStudents += $score['total'];
        $totalScoreSum += ($score['avg'] * $score['total']);
        $topFiftyCount += $score['topFifty'];
        $topTwentyFiveCount += $score['topTwentyFive'];
    }

    $allGPIData[$key] = array(
        'AcademicYear' => $record['AcademicYear'],
        'GPI' => $record['GPI'],
        'GPIIdx' => $record['GPIIdx'],
        'GPIDescription' => $record['GPIDescription'],
        'TotalStudents' => $totalStudents,
        'TotalScoreSum' => $totalScoreSum,
        'TopFiftyCount' => $topFiftyCount,
        'TopTwentyFiveCount' => $topTwentyFiveCount
    );
}

// Step 4: Calculate Overall data by GPI code (combining all years)
$overallGPIData = array();
foreach ($allGPIData as $data) {
    $gpiCode = $data['GPI'];

    if (!isset($overallGPIData[$gpiCode])) {
        $overallGPIData[$gpiCode] = array(
            'GPI' => $gpiCode,
            'GPIIdx' => $data['GPIIdx'],
            'GPIDescription' => $data['GPIDescription'],
            'TotalStudents' => 0,
            'TotalScoreSum' => 0,
            'TopFiftyCount' => 0,
            'TopTwentyFiveCount' => 0
        );
    }

    $overallGPIData[$gpiCode]['TotalStudents'] += $data['TotalStudents'];
    $overallGPIData[$gpiCode]['TotalScoreSum'] += $data['TotalScoreSum'];
    $overallGPIData[$gpiCode]['TopFiftyCount'] += $data['TopFiftyCount'];
    $overallGPIData[$gpiCode]['TopTwentyFiveCount'] += $data['TopTwentyFiveCount'];
}

// Step 5: Format results for DataTables
$finalResults = array();

// Add yearly data
foreach ($allGPIData as $data) {
    $avg = $data['TotalStudents'] > 0
        ? $data['TotalScoreSum'] / $data['TotalStudents']
        : 0;
    $topFiftyPercent = $data['TotalStudents'] > 0
        ? ($data['TopFiftyCount'] / $data['TotalStudents']) * 100
        : 0;
    $topTwentyFivePercent = $data['TotalStudents'] > 0
        ? ($data['TopTwentyFiveCount'] / $data['TotalStudents']) * 100
        : 0;

    $finalResults[] = array(
        'DT_RowId' => 'row_' . $data['AcademicYear'] . '_' . str_replace(' ', '_', $data['GPI']),
        'GPIIdx' => $data['GPIIdx'],
        'GPI' => $data['GPI'],
        'desc' => $data['GPIDescription'],
        'ay' => $data['AcademicYear'],
        'avg' => number_format($avg, 2),
        'tot' => $data['TotalStudents'],
        'top50' => number_format($topFiftyPercent, 1). '%',
        'top25' => number_format($topTwentyFivePercent, 1). '%'
    );
}

// Add overall data (ONE row per GPI code)
foreach ($overallGPIData as $gpiCode => $data) {
    $avg = $data['TotalStudents'] > 0
        ? $data['TotalScoreSum'] / $data['TotalStudents']
        : 0;
    $topFiftyPercent = $data['TotalStudents'] > 0
        ? ($data['TopFiftyCount'] / $data['TotalStudents']) * 100
        : 0;
    $topTwentyFivePercent = $data['TotalStudents'] > 0
        ? ($data['TopTwentyFiveCount'] / $data['TotalStudents']) * 100
        : 0;

    $finalResults[] = array(
        'DT_RowId' => 'row_overall_' . str_replace(' ', '_', $gpiCode),
        'GPIIdx' => $data['GPIIdx'],
        'GPI' => $gpiCode,
        'desc' => $data['GPIDescription'],
        'ay' => 'Overall',
        'avg' => number_format($avg, 2),
        'tot' => $data['TotalStudents'],
        'top50' => number_format($topFiftyPercent, 1). '%',
        'top25' => number_format($topTwentyFivePercent, 1). '%'
    );
}

// Sort: First by GPI, then by year (with Overall last for each GPI)
usort($finalResults, function($a, $b) {
    $gpiCompare = strcmp($a['GPI'], $b['GPI']);
    if ($gpiCompare != 0) return $gpiCompare;

    if ($a['ay'] == 'Overall' && $b['ay'] != 'Overall') return 1;
    if ($a['ay'] != 'Overall' && $b['ay'] == 'Overall') return -1;

    return strcmp($b['ay'], $a['ay']); // Descending year order
});

// Close database connection
unset($DBCONNECTION);

// Output JSON for DataTables
echo json_encode(array(
    'draw' => isset($_GET['draw']) ? intval($_GET['draw']) : 0,
    'recordsTotal' => count($finalResults),
    'recordsFiltered' => count($finalResults),
    'data' => $finalResults
));