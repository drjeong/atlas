<?php
/**
 * Removing Selected Abet course
 * Description: removing the selected course from DB.
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$IDX='';
$AbetSyllabus='';
$AcademicYearInfo='';
if (array_key_exists('id', $_POST) && array_key_exists('syllabus', $_POST) && array_key_exists('ayinfo', $_POST))
{
    $IDX = trim($_POST['id']);
    $AbetSyllabus = trim($_POST['syllabus']);
    $AcademicYearInfo = trim($_POST['ayinfo']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

if ($IDX=="" ){
    // no IDX information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $IDX = filter_var($IDX, FILTER_VALIDATE_INT);
    if ($IDX === false) {
        throw new Exception('Invalid Index format');
    }

    $query = "CALL SP_RemoveAbetCourse(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$IDX]);

    // remove syllabus PDF
    // NOTICE: Currently removing syllabus PDF is not allowed.
//    if (!empty($AbetSyllabus)) {
//        require_once(__DIR__ . '/../config.php');
//        $target_dir = __DIRECTORY_ABETSYLLABI__ . $AcademicYearInfo . '/';
//        $AbetSyllabusFile = $target_dir . basename($AbetSyllabus);
//
//        if (file_exists($AbetSyllabusFile)) {
//            if (!unlink($AbetSyllabusFile)) {
//                error_log("Failed to delete file: " . $AbetSyllabusFile);
//            }
//        }
//    }

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    // Case-insensitive search for the error code
    if (stripos($errorMessage, '0x09000010') !== false) {
        echo '0x09000010';  // Cannot delete: abet course is referenced already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500',
            'sqlState' => $e->getSqlState(),  // Added for debugging
            'errorNo' => $e->getCode()        // Added for debugging
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
