<?php
/**
 * Listing Assistants
 * Description: listing assistants to be assigned to the selected abet courses
 * Author: Dong Hyun Jeong
 *
 * 09/21/2024 - initial version created
 */

include_once 'session_handler.php';

// DB table to use
$table = 'UserAccounts';
$joinQuery = " FROM `{$table}` AS `USRACCNTS` 
    LEFT JOIN `Positions` AS `POSITIONS` ON (`POSITIONS`.`Idx` = `USRACCNTS`.`Position`)
    LEFT JOIN `Affiliations` AS `AFFILIATIONS` ON (`AFFILIATIONS`.`Idx` = `USRACCNTS`.`Affiliation`)
";

// Table's primary key
$primaryKey = '`USRACCNTS`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`USRACCNTS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`USRACCNTS`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`USRACCNTS`.`Name`', 'dt' => 'Name', 'field' => 'Name', 'as' => 'Name'),
    array( 'db' => '`POSITIONS`.`Name`', 'dt' => 'Position', 'field' => 'Position', 'as' => 'Position'),
    array( 'db' => '`AFFILIATIONS`.`Name`', 'dt' => 'Affiliation', 'field' => 'Affiliation', 'as' => 'Affiliation')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require_once( 'ssp.join.class.php' );
require_once(__DIR__ . '/../php_include/dbconnection.php');

$extraWhere = "`USRACCNTS`.`Position`=".__ASSISTANT_USERCODE." AND `USRACCNTS`.`Disabled`=0";
// Listing only assistants

echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere)
);

