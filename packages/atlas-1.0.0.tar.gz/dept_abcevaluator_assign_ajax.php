<?php
/**
 * Assign Evaluator to Abet Courses
 * Description: Assigning evaluator to the selected abet courses
 * Author: Dong Hyun Jeong
 *
 * 03/04/2024 - initial version created
 *
 */

include_once 'session_handler.php';

$AbetCourseIdxes='';
$EvaluatorIdxes='';

if (array_key_exists('evidx', $_POST) && array_key_exists('abetcrs', $_POST))
{
    $EvaluatorIdxes = trim($_POST['evidx']);
    $AbetCourseIdxes = trim($_POST['abetcrs']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

if ($EvaluatorIdxes=="" || $AbetCourseIdxes==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    $EvaluatorIdxes_Array = explode( '|', $EvaluatorIdxes );
    $AbetCourseIdxes_Array = explode( '|', $AbetCourseIdxes );

    $MultiQuery = "";
    foreach ($AbetCourseIdxes_Array AS $AbetCourseIdx) {
        // remove previously assigned evaluators
        $MultiQuery .= "CALL SP_Evaluator_Unassign($AbetCourseIdx);";
        foreach ($EvaluatorIdxes_Array AS $EvaluatorIdx) {
            // assign evaluator
            $MultiQuery .= "CALL SP_Evaluator_Assign($AbetCourseIdx, $EvaluatorIdx);";
        }
    }

//    error_log($MultiQuery);
//	echo ($MultiQuery); exit;
    $DBCONNECTION->sendmultiquery($MultiQuery);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
