<?php
/**
 * Course-level Continuous Improvements
 * File: p_clcimprvmnt.php
 * Description: Listing courses' continuous improvements.
 *
 */

include('header.php');

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection(false);

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

?>

    <script type="text/javascript">

        $(document).ready(function() {

            // Add event listener to the select element
            $("#_AY").on('change', function() {
                document.academicyear.submit();
            });
        });

    </script>

    <div class="pagebacklayout">
        <div class="row">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">ASSESSMENT OF COURSE-LEVEL CONTINUOUS IMPROVEMENT (BY ACADEMIC YEAR)</p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <?php include('control_allprograms.php'); ?>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:30%;">
                        <?php echo($AcademicYearSelection);?>
                    </td>
                    <td style="width:10%"></td>
                    <td style="width:60%; text-align: right">
                    </td>
                </tr>
            </table>

            <?php
            require_once(__DIR__ . '/php_include/dbconnection_class.php');
            $DBCONNECTION = new Dbconnection();

            $AbetCourseAvailable = false;
            $Query = "CALL SP_ChkAbetCourses( '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."', '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' )";
            if ($DBCONNECTION->gettotalcount($Query) > 0)
                $AbetCourseAvailable = true;

            if ($AbetCourseAvailable == false){
                echo <<<HTML
            <div class='col-md-12'>
                <div class="alert alert-info text-center" role="alert" style="padding: 40px; margin: 20px 0;">
                    <h4 class="alert-heading">No ABET Courses Available</h4>
                    <p class="mb-0">There are currently no ABET courses available for the selected academic year and program.</p>
                    <hr>
                    <p class="mb-0">Please select a different academic year or contact your administrator if you believe this is an error.</p>
                </div>
            </div>
HTML;
            } else {
                /////////////////////////////////////////////////////////////////////////////////
                // fetch continuous improvement information
                $Query = "CALL SP_FetchAbetCourseCntinusImprvmnt('".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."', '" . $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] . "');";
                $DBCONNECTION->sendquery($Query);

                $hasData = false;
                $tableContent = '';

                while ($row = $DBCONNECTION->fetch_assoc()) {
                    $hasData = true;

                    $ABCIdx = isset($row['ABCIdx']) ? $row['ABCIdx'] : '';
                    $AVCIdx = isset($row['AVCIdx']) ? $row['AVCIdx'] : '';
                    $CourseNo = isset($row['CourseNo']) ? $row['CourseNo'] : 'N/A';
                    $Instructor = isset($row['Instructor']) ? $row['Instructor'] : 'N/A';
                    $Title = isset($row['Title']) ? $row['Title'] : 'N/A';
                    $Credits = isset($row['Credits']) ? $row['Credits'] : 'N/A';
                    $Semester = isset($row['Semester']) ? $row['Semester'] : 'N/A';
                    $FacultyReflection = isset($row['FacultyReflection']) ? convert_encoded_html_to_display($row['FacultyReflection']) : '';

                    $tableContent .= <<<HTML
                <tr style="border-spacing: 3px;">
                    <td style="width:30%;">
                         <p>
                            $CourseNo $Title<br/>
                            Semester: $Semester<br/>
                            Credit Hours: $Credits<br/>
                            Professor: $Instructor
                        </p>
                    </td>
                    <td style="width:70%;">
HTML;
                    if ($FacultyReflection != '') {
                        $tableContent .= '<p>' . $FacultyReflection . '</p>';
                    } else {
                        $tableContent .= '<p><em>No faculty reflection provided</em></p>';
                    }

                    $tableContent .= <<<HTML
                    </td>
                </tr>
HTML;
                }

                if (!$hasData) {
                    echo <<<HTML
            <div class='col-md-12'>
                <div class="alert alert-warning text-center" role="alert" style="padding: 30px; margin: 20px 0;">
                    <h4 class="alert-heading">No Continuous Improvement Data Available</h4>
                    <p class="mb-0">There are currently no continuous improvement reflections for the selected academic year and program.</p>
                </div>
            </div>
HTML;
                } else {
                    echo <<<HTML
            <div class='col-md-12'>
                <!-- Page Content -->
                <div id="pagebacklayout_inner_noborder">
                    <div class="CSSTable_ROUNDEDCORDER">
                        <table class="display">
HTML;
                    echo $tableContent;
                    echo <<<HTML
                        </table>
                    </div>
                    <!-- /#page-content-wrapper -->
                </div>
            </div>
HTML;
                }

                unset($DBCONNECTION);
            }
            ?>

        </div>
    </div>

<?php include('footer.php');?>