<?php
/**
 * Evaluation of Performance Indicators by Level
 *
 * 12/14/2025 - initial version created
 * 02/03/2026 - added student count and attainment metrics
 *
 */
include_once 'session_handler.php';
?>

<?php
require_once ('../php_include/dbconnection_class.php');

// Get parameters from session
$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// Handle academic years - convert from array to string if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
    if (is_array($academicYears)) {
        $IN_AcademicYears = implode(',', $academicYears);
    } else {
        $IN_AcademicYears = $academicYears;
    }
} else {
    $IN_AcademicYears = $IN_AcademicYear;
}

if (empty($IN_AcademicYears)) {
    $IN_AcademicYears = $IN_AcademicYear;
}

// Level mapping function
function getLevelName($levelNumber) {
    $levelMap = array(
        '1' => 'Introductory',
        '2' => 'Practice',
        '3' => 'Mastery'
    );
    return isset($levelMap[$levelNumber]) ? $levelMap[$levelNumber] : $levelNumber;
}

// Get level filter from GET parameter (optional)
$levelFilter = isset($_GET['level']) ? $_GET['level'] : 'All';

// Initialize database connection
$DBCONNECTION = new Dbconnection();
$Data = array();

// Initialize variables
$studentOutcomes = array();
$courses = array();
$levels = array();

// Query to get all Student Outcomes and their GPIs for the program
$soQuery = "
    SELECT DISTINCT
        STNTOUTCMS.SO,
        STNTOUTCMS.Description AS SODescription,
        GPIS.Idx AS GPIIdx,
        GPIS.GPI AS GPICode
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    ORDER BY STNTOUTCMS.SO, GPIS.GPI
";

$soResults = $DBCONNECTION->sendquery($soQuery);

if ($soResults) {
    while ($row = $soResults->fetch_assoc()) {
        $soKey = $row['SO'];
        if (!isset($studentOutcomes[$soKey])) {
            $studentOutcomes[$soKey] = array(
                'description' => $row['SODescription'],
                'gpis' => array()
            );
        }
        $studentOutcomes[$soKey]['gpis'][] = array(
            'gpiIdx' => $row['GPIIdx'],
            'code' => $row['GPICode']
        );
    }
}

// Query to get distinct levels first
$levelQuery = "
    SELECT DISTINCT ABETCRSES.Level
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    LEFT JOIN AssessmentMeasures AS ASSMNTMEASURES ON (ASSMNTMEASURES.GPI = GPIS.Idx)
    LEFT JOIN Scoresheet AS SCSHEET ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
    LEFT JOIN AbetCourses AS ABETCRSES ON (SCSHEET.AbetCourseIdx = ABETCRSES.Idx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    AND ABETCRSES.Level IS NOT NULL
    AND ABETCRSES.Level != ''
    ORDER BY ABETCRSES.Level
";

$levelResults = $DBCONNECTION->sendquery($levelQuery);
if ($levelResults) {
    while ($row = $levelResults->fetch_assoc()) {
        if (!empty($row['Level'])) {
            $levelNumber = $row['Level'];
            $levelName = getLevelName($levelNumber);
            // Store both the number (for filtering) and name (for display)
            $levels[] = array(
                'value' => $levelNumber,
                'label' => $levelName
            );
        }
    }
}

// Build the WHERE clause for level filter
$levelWhereClause = "";
if ($levelFilter !== 'All') {
    // The filter will come as the level name, so we need to convert it back to number
    $levelFilterNumber = '';
    if ($levelFilter === 'Introductory') {
        $levelFilterNumber = '1';
    } elseif ($levelFilter === 'Practice') {
        $levelFilterNumber = '2';
    } elseif ($levelFilter === 'Mastery') {
        $levelFilterNumber = '3';
    }

    if (!empty($levelFilterNumber)) {
        $levelFilterNumber = $DBCONNECTION->real_escape_string($levelFilterNumber);
        $levelWhereClause = "AND ABETCRSES.Level = '{$levelFilterNumber}'";
    }
}

// Query to get course data with scores AND student counts
$dataQuery = "
    SELECT
        AVCRSES.CourseNo,
        AVCRSES.Title,
        ABETCRSES.Level,
        STNTOUTCMS.SO,
        GPIS.Idx AS GPIIdx,
        GPIS.GPI AS GPICode,
        AVG(SCSHEET.LevelOfAttainment) AS AVG_SCORE,
        COUNT(SCSHEET.LevelOfAttainment) AS TOTAL_ASSESSMENTS,
        SUM(CASE WHEN SCSHEET.LevelOfAttainment >= 2.0 THEN 1 ELSE 0 END) AS COUNT_ABOVE_2,
        SUM(CASE WHEN SCSHEET.LevelOfAttainment >= 3.0 THEN 1 ELSE 0 END) AS COUNT_ABOVE_3
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    LEFT JOIN AssessmentMeasures AS ASSMNTMEASURES ON (ASSMNTMEASURES.GPI = GPIS.Idx)
    LEFT JOIN Scoresheet AS SCSHEET ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
    LEFT JOIN AVCourses AS AVCRSES ON (SCSHEET.AvailableCourseIdx = AVCRSES.Idx)
    LEFT JOIN AbetCourses AS ABETCRSES ON (SCSHEET.AbetCourseIdx = ABETCRSES.Idx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    AND AVCRSES.CourseNo IS NOT NULL
    AND SCSHEET.LevelOfAttainment IS NOT NULL
    {$levelWhereClause}
    GROUP BY AVCRSES.CourseNo, AVCRSES.Title, ABETCRSES.Level, STNTOUTCMS.SO, GPIS.Idx, GPIS.GPI
    HAVING COUNT(SCSHEET.LevelOfAttainment) > 0
    ORDER BY ABETCRSES.Level, AVCRSES.CourseNo, STNTOUTCMS.SO, GPIS.GPI
";

$dataResults = $DBCONNECTION->sendquery($dataQuery);

if ($dataResults) {
    while ($row = $dataResults->fetch_assoc()) {
        $courseKey = $row['CourseNo'];

        if (!isset($courses[$courseKey])) {
            $courses[$courseKey] = array(
                'courseNo' => $row['CourseNo'],
                'title' => $row['Title'],
                'level' => getLevelName($row['Level']), // Convert to display name
                'levelNumber' => $row['Level'], // Keep original number for sorting
                'scores' => array(),
                'counts' => array(),
                'above2' => array(),
                'above3' => array()
            );
        }

        if (!isset($courses[$courseKey]['scores'][$row['SO']])) {
            $courses[$courseKey]['scores'][$row['SO']] = array();
            $courses[$courseKey]['counts'][$row['SO']] = array();
            $courses[$courseKey]['above2'][$row['SO']] = array();
            $courses[$courseKey]['above3'][$row['SO']] = array();
        }

        $courses[$courseKey]['scores'][$row['SO']][$row['GPIIdx']] = round($row['AVG_SCORE'], 2);
        $courses[$courseKey]['counts'][$row['SO']][$row['GPIIdx']] = intval($row['TOTAL_ASSESSMENTS']);
        $courses[$courseKey]['above2'][$row['SO']][$row['GPIIdx']] = intval($row['COUNT_ABOVE_2']);
        $courses[$courseKey]['above3'][$row['SO']][$row['GPIIdx']] = intval($row['COUNT_ABOVE_3']);
    }
}

// Build the response data
$data = array();
foreach ($courses as $course) {
    $row = array(
        'level' => $course['level'], // Display name (Introductory, Practice, Mastery)
        'levelNumber' => $course['levelNumber'], // Original number for sorting
        'courseNo' => $course['courseNo'],
        'title' => $course['title']
    );

    foreach ($studentOutcomes as $soKey => $soData) {
        foreach ($soData['gpis'] as $gpiInfo) {
            $gpiIdx = $gpiInfo['gpiIdx'];
            $columnKey = 'SO' . $soKey . '_GPI' . $gpiIdx;
            $countKey = $columnKey . '_count';
            $above2Key = $columnKey . '_above2';
            $above3Key = $columnKey . '_above3';

            // Add average score
            $row[$columnKey] = isset($course['scores'][$soKey][$gpiIdx])
                ? $course['scores'][$soKey][$gpiIdx]
                : '';

            // Add student count
            $row[$countKey] = isset($course['counts'][$soKey][$gpiIdx])
                ? $course['counts'][$soKey][$gpiIdx]
                : 0;

            // Add count of students scoring >= 2.0
            $row[$above2Key] = isset($course['above2'][$soKey][$gpiIdx])
                ? $course['above2'][$soKey][$gpiIdx]
                : 0;

            // Add count of students scoring >= 3.0
            $row[$above3Key] = isset($course['above3'][$soKey][$gpiIdx])
                ? $course['above3'][$soKey][$gpiIdx]
                : 0;
        }
    }

    $data[] = $row;
}

// Prepare final response
$Data['data'] = $data;
$Data['studentOutcomes'] = $studentOutcomes;
$Data['levels'] = $levels;

header('Content-Type: application/json');
echo json_encode($Data);
?>