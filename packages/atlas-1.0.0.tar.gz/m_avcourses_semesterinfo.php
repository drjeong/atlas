<?php
/**
 * Management of Available Courses
 * Description: fetching available semester information from the university website.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 01/14/2026 - Banner9 is supported
 */

include('checker_systemadmin.php');

function GetSemesterInfo($CURL)
{
    require_once(__DIR__ . '/../config.php');

    $url = __BANNER_TERMS_API_URL__;

    // Create temporary cookie file
    $cookie = tempnam(sys_get_temp_dir(), 'cookie_');

    // Clear any previous options
    curl_reset($CURL);

    // Basic options
    curl_setopt($CURL, CURLOPT_URL, $url);
    curl_setopt($CURL, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($CURL, CURLOPT_TIMEOUT, 60);
    curl_setopt($CURL, CURLOPT_FOLLOWLOCATION, true);

    // SSL options - let cURL use default certificate bundle
    curl_setopt($CURL, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($CURL, CURLOPT_SSL_VERIFYHOST, 2);

    // Updated User Agent
    curl_setopt($CURL, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");

    // Cookie handling with temp file
    curl_setopt($CURL, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($CURL, CURLOPT_COOKIESESSION, true);
    curl_setopt($CURL, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($CURL, CURLOPT_REFERER, $url);

    // Accept JSON
    curl_setopt($CURL, CURLOPT_HTTPHEADER, array(
        'Accept: application/json',
        'Content-Type: application/json'
    ));

    // Enable verbose output for debugging
    curl_setopt($CURL, CURLOPT_VERBOSE, true);
    $verbose = fopen('php://temp', 'w+');
    curl_setopt($CURL, CURLOPT_STDERR, $verbose);

    // Execute request
    $data = curl_exec($CURL);

    // Check for cURL errors
    if ($data === false) {
        $error = curl_error($CURL);
        $errno = curl_errno($CURL);
        echo "<option value='0x00000000'>cURL Error ($errno): $error</option>";

        // Show verbose output for debugging
        rewind($verbose);
        $verboseLog = stream_get_contents($verbose);
        error_log("cURL Verbose Log: " . $verboseLog);

        fclose($verbose);

        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return false;
    }

    // Check HTTP status
    $httpCode = curl_getinfo($CURL, CURLINFO_HTTP_CODE);
    if ($httpCode >= 400) {
        echo "<option value='0x00000000'>HTTP Error $httpCode. Server returned error.</option>";
        fclose($verbose);

        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return false;
    }

    fclose($verbose);

    // Check if data is empty
    if (empty($data)) {
        echo '<option value="0x00000000">No connection to the university server. Please try again later!!</option>';

        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return false;
    }

    // Parse JSON response
    $semesters = json_decode($data, true);

    // Check if JSON parsing was successful
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo '<option value="0x00000000">Invalid JSON response: ' . json_last_error_msg() . '</option>';

        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return false;
    }

    // Check if we got an array
    if (!is_array($semesters) || empty($semesters)) {
        echo '<option value="0x00000000">No semester data found.</option>';

        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return false;
    }

    // Generate option elements from JSON data
    foreach ($semesters as $semester) {
        if (isset($semester['code']) && isset($semester['description'])) {
            echo '<option value="' . htmlspecialchars($semester['code']) . '">'
                . htmlspecialchars($semester['description']) . '</option>';
        }
    }

    // Clean up temp cookie file
    if (file_exists($cookie)) {
        unlink($cookie);
    }

    return true;
}

// Create curl resource
$CURL = curl_init();
if (!$CURL) {
    die("Failed to initialize cURL");
}

GetSemesterInfo($CURL);
curl_close($CURL);
