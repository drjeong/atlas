<?php
/**
 * Listing abet courses and their assigned assistants
 * Description: listing abet courses and their assigned assistants
 * Author: Dong Hyun Jeong
 *
 * 09/21/2025 - initial version created
 * 08/09/2026 - Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */
include_once 'session_handler.php';


$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = '';
$joinQuery = " FROM
(
    SELECT `ABETCRSES`.`Idx`, `ABETCRSES`.`AcademicYear`, `ABETCRSES`.`Level`, `AYS`.`AcademicYear` AS `AcademicYearInfo`, 
        `ABETCRSES`.`AcademicProgram`, 
        FUNC_GetCourseLevel(`ABETCRSES`.`Level`) AS `CourseLevel`,
        `SMSTRS`.`Explanation` AS `Semester`, 
        `AVCRSES`.`CRN`, `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Title`, `AVCRSES`.`Credits`, 
        `ABETCRSES`.`Syllabus`, `ACDEMICPRMS`.`Degree`,
        GROUP_CONCAT(`UA`.`Name`) AS `Instructor`
    FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx` 
            AND `ABETCRSES`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."')
        LEFT JOIN `Semesters` AS `SMSTRS` ON (`AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`)
        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` ON (`AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`) 
        INNER JOIN `UserAccounts` AS `UA` ON (`AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`)
        INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear` = `AYS`.`Idx`) 
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        GROUP BY `ABETCRSES`.`Idx`
) AS A
LEFT JOIN
(
    SELECT `ABETCRSES`.`Idx` AS `AbetCourseIdx`, `ABETCRSES`.`AcademicYear`, 
        `ABETCRSES`.`AcademicProgram`,  
        GROUP_CONCAT(`ASSNTS`.`Assistant`) AS `Assistants`,
        GROUP_CONCAT(`UA`.`Name`) AS `AssistantsNames`
    FROM `AbetCourses` AS `ABETCRSES` 
    	INNER JOIN `AbetCourses_Assistants` AS `ASSNTS` ON (`ABETCRSES`.`Idx` = `ASSNTS`.`AbetCourseIdx`
    	    AND `ABETCRSES`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."')
        INNER JOIN `UserAccounts` AS `UA` ON (`ASSNTS`.`Assistant` = `UA`.`Idx`) 
        GROUP BY `ABETCRSES`.`Idx`
) AS B
ON (A.`Idx` = B.`AbetCourseIdx` AND A.`AcademicYear` = B.`AcademicYear` AND A.`AcademicProgram` = B.`AcademicProgram` )";

// Table's primary key
$primaryKey = 'A.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => 'A.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => 'A.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => 'A.`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => 'A.`AcademicYearInfo`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => 'A.`CourseLevel`', 'dt' => 'Level', 'field' => 'Level', 'as' => 'Level'),
    array( 'db' => 'A.`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => 'A.`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => 'A.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => 'A.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => 'A.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => 'A.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => 'A.`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram'),
    array( 'db' => 'A.`Degree`', 'dt' => 'Degree', 'field' => 'Degree', 'as' => 'Degree'),
    array( 'db' => 'B.`Assistants`', 'dt' => 'Assistants', 'field' => 'Assistants', 'as' => 'Assistants'),
    array( 'db' => 'B.`AssistantsNames`', 'dt' => 'AssistantNames', 'field' => 'AssistantNames', 'as' => 'AssistantNames'),
    array( 'db' => 'A.`Instructor`', 'dt' => 'Instructor', 'field' => 'Instructor', 'as' => 'Instructor')
);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "A.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";
if ($AcademicYear != "" && $AcademicYear != "all")
    $extraWhere .= " AND A.`AcademicYear`='".$AcademicYear."'";
$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

