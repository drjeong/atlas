<?php
/**
 * Listing Course Materials
 * Description: listing course materials
 *
 */

include_once 'session_handler.php';


$AvailableCourseIdx='';
if (array_key_exists('_AVC', $_GET))  {
    $AvailableCourseIdx = trim($_GET['_AVC']);
}
else {
    // illegal entry
    exit;
}

// DB table to use
$table = 'AVCourses_CrsMaterials';
$joinQuery = "FROM `$table` AS `CRSMATERIALS` ";

// Table's primary key
$primaryKey = '`CRSMATERIALS`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`CRSMATERIALS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`CRSMATERIALS`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`CRSMATERIALS`.`AssmntType`', 'dt' => 'AssmntType', 'field' => 'AssmntType', 'as' => 'AssmntType'),
    array( 'db' => '`CRSMATERIALS`.`AssmntNum`', 'dt' => 'AssmntNum', 'field' => 'AssmntNum', 'as' => 'AssmntNum'),
    array( 'db' => '`CRSMATERIALS`.`AssmntSample`', 'dt' => 'AssmntSample', 'field' => 'AssmntSample', 'as' => 'AssmntSample'),
    array( 'db' => '`CRSMATERIALS`.`StudentSample1`', 'dt' => 'StudentSample1', 'field' => 'StudentSample1', 'as' => 'StudentSample1'),
    array( 'db' => '`CRSMATERIALS`.`StudentSample2`', 'dt' => 'StudentSample2', 'field' => 'StudentSample2', 'as' => 'StudentSample2'),
    array( 'db' => '`CRSMATERIALS`.`StudentSample3`', 'dt' => 'StudentSample3', 'field' => 'StudentSample3', 'as' => 'StudentSample3')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "`CRSMATERIALS`.`AvailableCourseIdx` = '$AvailableCourseIdx'";

$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
