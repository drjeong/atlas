<?php
/**
 * Listing Courses
 * Description: listing courses for student outcomes (per-student averages)
 *
 * 06/07/2026 - initial version created
 *
 */

include_once 'session_handler.php';
require_once('../ssps/StudentOutcomeAnalyzer.php');
require_once('../php_include/dbconnection_class.php');

// Get parameters from session
$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// Handle academic years - convert from array to string if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
    // If it's an array, use it directly
    if (!is_array($academicYears)) {
        $academicYears = array(intval($academicYears));
    }
} else {
    // Fallback to single academic year
    $academicYears = array(intval($IN_AcademicYear));
}

// If empty, use the current academic year
if (empty($academicYears)) {
    $academicYears = array(intval($IN_AcademicYear));
}

// Sanitize academic program
$IN_AcademicProgram = intval($IN_AcademicProgram);

// Initialize database connection
$DBCONNECTION = new Dbconnection();

// Step 1: Get all ABET courses for selected academic program and years
$academicYearsStr = implode(',', array_map('intval', $academicYears));

$query = "
    SELECT DISTINCT
        ABETCRSES.Idx AS AbetCourseIdx,
        ABETCRSES.AcademicYear AS AcademicYearIdx,
        AYS.AcademicYear,
        ABETCRSES.AVCourseIdx AS AvailableCourseIdx,
        AVCRSES.CourseNo,
        AVCRSES.Crn
    FROM `AbetCourses` AS `ABETCRSES`
    INNER JOIN `AcademicYears` AS `AYS` ON (ABETCRSES.AcademicYear = AYS.Idx)
    INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (ABETCRSES.AcademicProgram = ACDEMICPRMS.Idx)
    INNER JOIN `AVCourses` AS `AVCRSES` ON (
        AYS.`From` <= AVCRSES.Semester 
        AND AYS.`To` >= AVCRSES.Semester 
        AND ABETCRSES.AVCourseIdx = AVCRSES.Idx
    )
    WHERE ABETCRSES.AcademicProgram = ?
      AND ABETCRSES.AcademicYear IN ($academicYearsStr)
    ORDER BY ABETCRSES.AcademicYear, AVCRSES.CourseNo
";

$result = $DBCONNECTION->prepare_execute_catch_error($query, [$IN_AcademicProgram]);

$abetCourses = array();
if ($result && $DBCONNECTION->num_rows() > 0) {
    while ($row = $DBCONNECTION->fetch_assoc()) {
        $abetCourses[] = array(
            'AbetCourseIdx' => $row['AbetCourseIdx'],
            'AcademicYearIdx' => $row['AcademicYearIdx'],
            'AcademicYear' => $row['AcademicYear'],
            'AvailableCourseIdx' => $row['AvailableCourseIdx'],
            'CourseNo' => $row['CourseNo'],
            'Crn' => $row['Crn']
        );
    }
}

// Step 2: Collect all individual student records
$analyzer = new StudentOutcomeAnalyzer($DBCONNECTION);
$studentRecords = array(); // Store individual student scores
$processedCourses = array();

foreach ($abetCourses as $course) {
    // Create unique key to avoid processing same course multiple times
    $courseKey = $course['AbetCourseIdx'] . '_' . $course['AvailableCourseIdx'];

    if (isset($processedCourses[$courseKey])) {
        continue;
    }
    $processedCourses[$courseKey] = true;

    $analysisData = $analyzer->getSavedAnalysis(
        $course['AbetCourseIdx'],
        $course['AvailableCourseIdx'],
        $IN_AcademicProgram,
        true
    );

    foreach ($analysisData as $soData) {
        $soCode = $soData['SO'];
        $academicYear = $course['AcademicYear'];

        // Store individual records grouped by Year and SO code
        $key = $academicYear . '|' . $soCode;

        if (!isset($studentRecords[$key])) {
            $studentRecords[$key] = array(
                'AcademicYear' => $academicYear,
                'SO' => $soCode,
                'SOIdx' => $soData['SOIdx'],
                'scores' => array()
            );
        }

        // Add individual student scores
        // Assuming TOTAL represents number of students and we need to extract individual scores
        // If AVG and TOTAL are provided, we can infer the distribution
        $total = $soData['TOTAL'];
        $avg = $soData['AVG'];
        $topFifty = $soData['TOPFIFTY'];
        $topTwentyFive = $soData['TOPTWENTYFIVE'];

        // Store aggregated course data
        $studentRecords[$key]['scores'][] = array(
            'avg' => $avg,
            'total' => $total,
            'topFifty' => $topFifty,
            'topTwentyFive' => $topTwentyFive
        );
    }
}

// Step 3: Aggregate by Academic Year and SO code
$allSOData = array();
foreach ($studentRecords as $key => $record) {
    $totalStudents = 0;
    $totalScoreSum = 0;
    $topFiftyCount = 0;
    $topTwentyFiveCount = 0;

    foreach ($record['scores'] as $score) {
        $totalStudents += $score['total'];
        $totalScoreSum += ($score['avg'] * $score['total']);
        $topFiftyCount += $score['topFifty'];
        $topTwentyFiveCount += $score['topTwentyFive'];
    }

    $allSOData[$key] = array(
        'AcademicYear' => $record['AcademicYear'],
        'SO' => $record['SO'],
        'SOIdx' => $record['SOIdx'],
        'TotalStudents' => $totalStudents,
        'TotalScoreSum' => $totalScoreSum,
        'TopFiftyCount' => $topFiftyCount,
        'TopTwentyFiveCount' => $topTwentyFiveCount
    );
}

// Step 4: Calculate Overall data by SO code (combining all years)
$overallSOData = array();
foreach ($allSOData as $data) {
    $soCode = $data['SO'];

    if (!isset($overallSOData[$soCode])) {
        $overallSOData[$soCode] = array(
            'SO' => $soCode,
            'SOIdx' => $data['SOIdx'],
            'TotalStudents' => 0,
            'TotalScoreSum' => 0,
            'TopFiftyCount' => 0,
            'TopTwentyFiveCount' => 0
        );
    }

    $overallSOData[$soCode]['TotalStudents'] += $data['TotalStudents'];
    $overallSOData[$soCode]['TotalScoreSum'] += $data['TotalScoreSum'];
    $overallSOData[$soCode]['TopFiftyCount'] += $data['TopFiftyCount'];
    $overallSOData[$soCode]['TopTwentyFiveCount'] += $data['TopTwentyFiveCount'];
}

// Step 5: Get SO descriptions
$query = "
    SELECT SO.Idx, SO.SO, SO.Description
    FROM StudentOutcomes SO
    INNER JOIN AcademicYears AY ON SO.AcademicYear = AY.Idx
    WHERE SO.AcademicProgram = ?
      AND SO.TobeRemoved = 0
      AND SO.AcademicYear IN ($academicYearsStr)
    ORDER BY SO.SO, AY.`From` DESC
";

$result = $DBCONNECTION->prepare_execute_catch_error($query, [$IN_AcademicProgram]);

$soDescriptions = array();
if ($result && $DBCONNECTION->num_rows() > 0) {
    while ($row = $DBCONNECTION->fetch_assoc()) {
        if (!isset($soDescriptions[$row['SO']])) {
            $soDescriptions[$row['SO']] = array(
                'Idx' => $row['Idx'],
                'SO' => $row['SO'],
                'Description' => $row['Description']
            );
        }
    }
}

// Step 6: Format results for DataTables
$finalResults = array();

// Add yearly data
foreach ($allSOData as $data) {
    $avg = $data['TotalStudents'] > 0
        ? $data['TotalScoreSum'] / $data['TotalStudents']
        : 0;
    $topFiftyPercent = $data['TotalStudents'] > 0
        ? ($data['TopFiftyCount'] / $data['TotalStudents']) * 100
        : 0;
    $topTwentyFivePercent = $data['TotalStudents'] > 0
        ? ($data['TopTwentyFiveCount'] / $data['TotalStudents']) * 100
        : 0;

    $soInfo = isset($soDescriptions[$data['SO']])
        ? $soDescriptions[$data['SO']]
        : array('SO' => $data['SO'], 'Description' => '');

    $finalResults[] = array(
        'DT_RowId' => 'row_' . $data['AcademicYear'] . '_' . str_replace(' ', '_', $data['SO']),
        'SOIdx' => $data['SOIdx'],
        'SO' => $data['SO'],
        'desc' => $soInfo['Description'],
        'ay' => $data['AcademicYear'],
        'avg' => number_format($avg, 2),
        'tot' => $data['TotalStudents'],
        'top50' => number_format($topFiftyPercent, 1). '%',
        'top25' => number_format($topTwentyFivePercent, 1). '%'
    );
}

// Add overall data (ONE row per SO code)
foreach ($overallSOData as $soCode => $data) {
    $avg = $data['TotalStudents'] > 0
        ? $data['TotalScoreSum'] / $data['TotalStudents']
        : 0;
    $topFiftyPercent = $data['TotalStudents'] > 0
        ? ($data['TopFiftyCount'] / $data['TotalStudents']) * 100
        : 0;
    $topTwentyFivePercent = $data['TotalStudents'] > 0
        ? ($data['TopTwentyFiveCount'] / $data['TotalStudents']) * 100
        : 0;

    $soInfo = isset($soDescriptions[$soCode])
        ? $soDescriptions[$soCode]
        : array('SO' => $soCode, 'Description' => '');

    $finalResults[] = array(
        'DT_RowId' => 'row_overall_' . str_replace(' ', '_', $soCode),
        'SOIdx' => $data['SOIdx'],
        'SO' => $soCode,
        'desc' => $soInfo['Description'],
        'ay' => 'Overall',
        'avg' => number_format($avg, 2),
        'tot' => $data['TotalStudents'],
        'top50' => number_format($topFiftyPercent, 1). '%',
        'top25' => number_format($topTwentyFivePercent, 1). '%'
    );
}

// Sort: First by SO, then by year (with Overall last for each SO)
usort($finalResults, function($a, $b) {
    $soCompare = strcmp($a['SO'], $b['SO']);
    if ($soCompare != 0) return $soCompare;

    if ($a['ay'] == 'Overall' && $b['ay'] != 'Overall') return 1;
    if ($a['ay'] != 'Overall' && $b['ay'] == 'Overall') return -1;

    return strcmp($a['ay'], $b['ay']);
});

// Close database connection
unset($DBCONNECTION);

// Output JSON for DataTables
echo json_encode(array(
    'draw' => isset($_GET['draw']) ? intval($_GET['draw']) : 0,
    'recordsTotal' => count($finalResults),
    'recordsFiltered' => count($finalResults),
    'data' => $finalResults
));