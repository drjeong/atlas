/**
 * API PDF Download
 * Version 1.0
 * api_pdfviewer.js
 *
 */

function downloadPDF(filename, code, academicyearinfo) {
	// Show the full page spinner before starting the fetch
	showFullPageSpinner();

	const url = `pdf_viewer.php`;

	// Prepare the POST request
	fetch(url, {
		method: "POST", // Use POST method
		headers: {
			"Content-Type": "application/json" // Set content type for JSON
		},
		body: JSON.stringify({
			pdf: filename,
			cn: code,
			ayinfo: academicyearinfo
		}) // Send data in the body of the request
	})
		.then(response => {
			if (!response.ok) {
				// Hide spinner if there's an error with the response
				hideFullPageSpinner();
				throw new Error(`HTTP error! status: ${response.status}`);
			}
			return response.blob(); // Fetch the file as a binary object
		})
		.then(blob => {
			// Create a downloadable link
			const fileURL = URL.createObjectURL(blob);
			const link = document.createElement('a');
			link.href = fileURL;
			link.download = `${filename || 'downloaded_file.pdf'}`; // Suggested filename
			document.body.appendChild(link);

			// Hide spinner right before clicking the download link
			hideFullPageSpinner();

			link.click();

			// Clean up
			setTimeout(() => {
				window.URL.revokeObjectURL(link.href);
			}, 100);

			document.body.removeChild(link); // Clean up the link element
		})
		.catch(error => {
			// Make sure spinner is hidden if there's an error
			hideFullPageSpinner();
			console.error('Error downloading the file:', error);
		});
}

