<?php
/**
 * Abet courses
 * Description: Listing abet course assessment cycle
 * Author: Dong Hyun Jeong
 *
 * 11/24/2024 - initial version created
 * 
 */

include('checker_programdirector.php');
include('header.php');
?>

<?php

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection();

include('./php_include/dbfunctions.php');
$AcademicYearOptions = GetAcademicYearOption_in_StudentOutcomes();

$Duplicate_AbetCourses_AcademicYearOptions_From = GetAcademicYearOption_in_AbetCourses_Exists($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);
$Duplicate_AbetCourses_AcademicYearOptions_To = GetAcademicYearOption_in_AbetCourses_NotExists($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);

?>

<script type="text/javascript">

    var DataTable_AbetCourseList = null;
    var SelectedAcademicYear = '<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>';
    var DataTable_CoursesList = null;

    function AssignPIs(AbetCourseIdx, AcademicYear, AcademicYearInfo, SOIdxes, GPIIdxes)
    {
        let DataTable_GPIList = null;
        const content = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<div class="CSSTable_SSPSLIST" style="min-height:370px;">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>'
            + '     <input type="text" name="_AY" id="_AY" class="input-sm form-control" value="'+AcademicYearInfo+'" disabled>'
            + ' </div>'
            + '<table id="gpilist" class="display" style="border-spacing:0; padding:0; width:100%;">'
            + '<thead>'
            + ' <tr>'
            + ' <th class="no-sort" style="width:3px"></th>'
            + ' <th>SO</th>'
            + ' <th>PI</th>'
            + ' <th>DESC</th>'
            + '</tr>'
            + '</thead>'
            + '</table>'
            + '</div></form>';

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN PERFORMANCE INDICATORS</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){

                        let selected = DataTable_GPIList.rows({ selected: true }).data();
                        let unselected  = DataTable_GPIList.rows({ selected: false }).data();

                        let checked_unchecked_list = '';
                        for(let i = 0; i < selected.length; ++i) {
                            if (checked_unchecked_list !='') checked_unchecked_list += "|";
                            checked_unchecked_list += encodeURIComponent(selected[i].SOIdx + "_" + selected[i].GPIIdx+"_true");
                        }
                        for(let i = 0; i < unselected.length; ++i) {
                            if (checked_unchecked_list !='') checked_unchecked_list += "|";
                            checked_unchecked_list += encodeURIComponent(unselected[i].SOIdx + "_" + unselected[i].GPIIdx+"_false");
                        }
                        AssignPIs_Perform(AbetCourseIdx, AcademicYear, '<?php echo($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);?>', checked_unchecked_list);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        });

        DataTable_GPIList = $("#gpilist").DataTable({
            "processing": true,
            "serverSide": false,
            "iDisplayLength": 8,
            "lengthChange": false,
            "sDom": 'tp', // invisible search box & show pagination tabs
            "ajax": "ssps/dept_abetcourses_gpilist_ssps.php?_IDX="+encodeURIComponent(AbetCourseIdx)+"&_AY="+AcademicYear+"&_SO="+encodeURIComponent(SOIdxes),
            "order": [[ 1, 'asc' ]],
            "fnDrawCallback": function() {
                $('#gpilist tr td:nth-child(1)').css('text-align', 'center');
                $('#gpilist tr td:nth-child(2)').css('text-align', 'center');
                $('#gpilist tr td:nth-child(3)').css('text-align', 'center');

                $('#gpilist tr td:nth-child(4)').css('width', '80%');
            },
            "columns": [
                {
                    "data": 'DT_RowId',
                    "render": function ( data, type, full, meta ) {
                            if (GPIIdxes != "" & GPIIdxes != null){
                                let res = GPIIdxes.split(",");
                                for(let i = 0; i < res.length; i++) {
                                    if (res[i].trim() == full.GPIIdx) {
                                        DataTable_GPIList.row('#'+data).select();
                                    }
                                }
                            }
                        return '';
                    }
                },
                { "data": 'SO' },
                { "data": 'GPI' },
                { "data": 'Desc' },
            ],
            "columnDefs": [
                {
                    'orderable': false,
                    'className': 'select-checkbox',
                    'targets': 0
                },
                {
                "targets"  : 'no-sort',
                "orderable": false,
                }
            ],
            "select": {
                'style': 'multi'
            }
        });
    }

    function AssignPIs_Perform(AbetCourseIdx, _AY, _APROGRAM, CheckedUncheckedGPIs)
    {
        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case"0x11111111": {
                        DataTable_AbetCourseList.rows({selected: true }).deselect();
                        DataTable_AbetCourseList.ajax.reload(null, false);
                        Swal.fire({
                            title: "ADDED",
                            text: "GPIS are assigned!",
                            icon: "success",
                            timer: 2000
                        });
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }
        const param = "ap="+encodeURIComponent(_APROGRAM)+"&ay="+encodeURIComponent(_AY)+"&gpi="+encodeURIComponent(CheckedUncheckedGPIs)+"&abetcrs="+encodeURIComponent(AbetCourseIdx);
        xmlhttp.open("POST", "dept_abetcourses_pi_assign_ajax.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send(param);
    }

    function isSameAcademicYear(el, index, arr)
    {
        if (index === 0){
            return true;
        } else {
            return (el.AcademicYear === arr[index - 1].AcademicYear);
        }
    }

    function isSameStudentOutcomes(el, index, arr)
    {
        if (index === 0){
            return true;
        } else {
            return (el.SOIdxes === arr[index - 1].SOIdxes);
        }
    }

    function EmptyStudentOutcomes(arr)
    {
        return (arr.SOIdxes === null);
    }

    function AssignPIsToSelectedCourses()
    {
        let selected = DataTable_AbetCourseList.rows({ selected: true }).data();
        if (selected.length == 0) {
            Swal.fire({title:"ERROR", text: "Please select abet courses first!", icon:"error"});
            return;
        }

        // check if the selected abet courses have the same academic year information.
        if (selected.toArray().every(isSameAcademicYear) == false) {
            Swal.fire({title:"ERROR", text: "Selected abet courses must be in the same academic year!", icon:"error"});
            return;
        }

        // check if the selected abet courses have student outcomes assigned.
        if (selected.toArray().find(EmptyStudentOutcomes) != null) {
            Swal.fire({title:"ERROR", text: "Selected abet courses must have student outcomes assigned!", icon:"error"});
            return;
        }

        // check if the selected abet courses have the same student outcomes.
        if (selected.toArray().every(isSameStudentOutcomes) == false) {
            Swal.fire({title:"ERROR", text: "Selected abet courses must have the same student outcomes!", icon:"error"});
            return;
        }

        // create an array for the selected abet courses
        let AbetCourseIdxs = '';
        for(let i = 0; i < selected.length; ++i) {
            if (AbetCourseIdxs != '') AbetCourseIdxs += "|";
            AbetCourseIdxs += encodeURIComponent(selected[i].Idx);
        }
        AssignPIs(AbetCourseIdxs, selected[0].AcademicYear, selected[0].AcademicYearInfo, selected[0].SOIdxes, null)
    }

    // ----------------------------------------------------------------------------------------------
    function AssignLevelToSelectedCourses()
    {
        let selected = DataTable_AbetCourseList.rows({ selected: true }).data();
        if (selected.length == 0) {
            Swal.fire({title:"ERROR", text: "Please select abet courses first!", icon:"error"});
            return;
        }

        // create an array for the selected abet courses
        let AbetCourseIdxs = '';
        for(let i = 0; i < selected.length; ++i) {
            if (AbetCourseIdxs != '') AbetCourseIdxs += "|";
            AbetCourseIdxs += encodeURIComponent(selected[i].Idx);
        }
        AssignLevel(AbetCourseIdxs, selected[0].AcademicYear, selected[0].AcademicYearInfo, null)
    }

    function AssignLevel(AbetCourseIdxs, AcademicYear, AcademicYearInfo, SOIdxes)
    {
        let DataTable_SOList = null;
        const content = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<div class="CSSTable_SSPSLIST">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Course Level<span style="color:red">*</span></span>'
            + '     <select name="_Level" id="_Level" class="input-sm form-control">'
            + '     <option value=""></option>'
            + '     <option value="1">Introductory</option>'
            + '     <option value="2">Practice</option>'
            + '     <option value="3">Mastery</option>'
            + '     </select>'
            + ' </div>'
            + '</div></form>';

        createModalDialog({
            // className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN COURSE LEVEL</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){

                        AssignLevel_Perform(AbetCourseIdxs, AcademicYear, '<?php echo($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);?>', popupfrm._Level.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        });
    }

    function AssignLevel_Perform(AbetCourseIdxs, _AY, _APROGRAM, _Level)
    {
        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case"0x11111111": {
                        DataTable_AbetCourseList.rows({selected: true }).deselect();
                        DataTable_AbetCourseList.ajax.reload();
                        Swal.fire({
                            title: "ADDED",
                            text: "Student outcomes are assigned!",
                            icon: "success",
                            timer: 2000
                        });
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }

        const param = "ap="+encodeURIComponent(_APROGRAM)+"&ay="+encodeURIComponent(_AY)+"&level="+encodeURIComponent(_Level)+"&abetcrs="+encodeURIComponent(AbetCourseIdxs);
        xmlhttp.open("POST", "dept_abetcourses_level_assign_ajax.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send(param);
    }



    //---------------------------------------------------------------------------------------
    function AssignSOsToSelectedCourses()
    {
        let selected = DataTable_AbetCourseList.rows({ selected: true }).data();
        if (selected.length == 0) {
            Swal.fire({title:"ERROR", text: "Please select abet courses first!", icon:"error"});
            return;
        }

        // check if the selected abet courses have the same academic year information.
        if (selected.toArray().every(isSameAcademicYear) == false) {
            Swal.fire({title:"ERROR", text: "Selected abet courses must be in the same academic year!", icon:"error"});
            return;
        }

        // create an array for the selected abet courses
        let AbetCourseIdx = '';
        for(let i = 0; i < selected.length; ++i) {
            if (AbetCourseIdx != '') AbetCourseIdx += "|";
            AbetCourseIdx += encodeURIComponent(selected[i].Idx);
        }
        AssignSOs(AbetCourseIdx, selected[0].AcademicYear, selected[0].AcademicYearInfo, null)
    }

    function AssignSOs(AbetCourseIdx, AcademicYear, AcademicYearInfo, SOIdxes)
    {
        let DataTable_SOList = null;
        const content = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<div class="CSSTable_SSPSLIST" style="min-height:370px;">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>'
            + '     <input type="text" name="_AY" id="_AY" class="input-sm form-control" value="'+AcademicYearInfo+'" disabled>'
            + ' </div>'
            + '<table id="solist" class="display" style="border-spacing:0; padding:0; width:100%;">'
            + '<thead>'
            + '<tr>'
            + ' <th class="no-sort" style="width:3px"></th>'
            + ' <th>SO</th>'
            + ' <th>DESC</th>'
            + '</tr>'
            + '</thead>'
            + '</table>'
            + '</div></form>';

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN STUDENT OUTCOMES</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){

                        let selected = DataTable_SOList.rows({ selected: true }).data();
                        let unselected  = DataTable_SOList.rows({ selected: false }).data();

                        let checked_unchecked_list = '';
                        for(let i = 0; i < selected.length; ++i) {
                            if (checked_unchecked_list != '') checked_unchecked_list += "|";
                            checked_unchecked_list += encodeURIComponent(selected[i].Idx + "_true");
                        }
                        for(let i = 0; i < unselected.length; ++i) {
                            if (checked_unchecked_list != '') checked_unchecked_list += "|";
                            checked_unchecked_list += encodeURIComponent(unselected[i].Idx + "_false");
                        }
                        AssignSOs_Perform(AbetCourseIdx, AcademicYear, '<?php echo($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);?>', checked_unchecked_list);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        });

        DataTable_SOList = $("#solist").DataTable({
            "processing": true,
            "serverSide": false,
            "iDisplayLength": 8,
            "lengthChange": false,
            "sDom": 'tp', // invisible search box & show pagination tabs
            "ajax": "ssps/dept_abetcourses_solist_ssps.php?_AY="+AcademicYear,
            "order": [[ 1, 'asc' ]],
            "fnDrawCallback": function() {
                $('#solist tr td:nth-child(1)').css('text-align', 'center');
                $('#solist tr td:nth-child(2)').css('text-align', 'center');
                $('#solist tr td:nth-child(3)').css('width', '80%');
            },
            "columns": [
                {
                    "data": 'DT_RowId',
                    "render": function ( data, type, full, meta ) {
                        let rowId = full.Idx; // // Get Idx
                        if (SOIdxes!=null)
                        {
                            if (SOIdxes.search(rowId) >=0)
                                DataTable_SOList.row('#'+data).select();
                        }
                        return '';
                    }
                },
                { "data": 'SO' },
                { "data": 'Desc' },
            ],
            "columnDefs": [
                {
                    'orderable': false,
                    'className': 'select-checkbox',
                    'targets': 0
                },
                {
                    "targets"  : 'no-sort',
                    "orderable": false,
                }
            ],
            'select': {
                'style': 'multi'
            }
        });
    }

    function AssignSOs_Perform(AbetCourseIdx, _AY, _APROGRAM, CheckedUncheckedSOs)
    {
        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case"0x11111111": {
                        // DataTable_AbetCourseList.rows({selected: true }).deselect();
                        DataTable_AbetCourseList.ajax.reload(null, false);
                        Swal.fire({
                            title: "ADDED",
                            text: "Student outcomes are assigned!",
                            icon: "success",
                            timer: 2000
                        });
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }

        const param = "ap="+encodeURIComponent(_APROGRAM)+"&ay="+encodeURIComponent(_AY)+"&sos="+encodeURIComponent(CheckedUncheckedSOs)+"&abetcrs="+encodeURIComponent(AbetCourseIdx);
        xmlhttp.open("POST", "dept_abetcourses_so_assign_ajax.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send(param);
    }


    function RemoveAbetCourse(Idx, AcademicYearInfo, Subject, Num, Title, Syllabus)
    {
        Swal.fire({
            title: "DELETE?",
            html: "Deleted content (<span style=\"color:red\">"+AcademicYearInfo+" "+Subject+" "+Num+" "+Title+" </span>) cannot be restored!",
            icon: "question",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!"
        }).then(function(result){
            if (result.value)
            {
                let xmlhttp;
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp=new XMLHttpRequest();
                } else { // code for IE6, IE5
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function() {
                    if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                        switch(xmlhttp.responseText.trim())
                        {
                            case"0x11111111": {
                                DataTable_AbetCourseList.ajax.reload(null, false);

                                Swal.fire({
                                    title: "DELETED!",
                                    text: "The selected course has been deleted!",
                                    icon: "success",
                                    timer: 2000
                                }).then(function(){
                                    //location.reload();
                                });

                                break;
                            }
                            case"0x09000011": {
                                Swal.fire({
                                    title: "ERROR",
                                    text: "The selected abet course cannot be deleted because it has been used already.",
                                    icon: "error",
                                    timer: 5000
                                });
                                break;
                            }
                            default:{
                                Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                                break;
                            }
                        }
                    }
                }
                xmlhttp.open("POST", "dept_abetcourses_remove_ajax.php", true);
                xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlhttp.send("id="+Idx+"&syllabus="+Syllabus+"&ayinfo="+AcademicYearInfo);
            }

        });
    }

    function AddAbetCourses_Perform(_AY, _SELECTEDCOURSES)
    {
        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case"0x11111111": {
                        DataTable_AbetCourseList.ajax.reload(null, false);

                        Swal.fire({
                            title: "ADDED",
                            text: "Abet courses are added!",
                            icon: "success",
                            timer: 2000
                        }).then(function(){
                            location.reload();
                        });
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }
        const param = "ap="+encodeURIComponent(<?php echo($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);?>)+"&ay="+encodeURIComponent(_AY)+"&crses="+encodeURIComponent(_SELECTEDCOURSES);
        xmlhttp.open("POST", "dept_abetcourses_add_ajax.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send(param);
    }

    function UpdateCourses(option){
        let url = "ssps/dept_abetcourses_courselist_ssps.php?_AY="+option.value;
        DataTable_CoursesList.ajax.url( url ).load();
    }

    function AddAbetCourses()
    {
        SelectedAcademicYear = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].value;

        const content = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<div class="CSSTable_SSPSLIST" style="min-height:370px;">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>'
            + '     <select name="_AY" id="_AY" class="input-sm form-control" onchange="UpdateCourses(this)"><option value=""></option><?php echo($AcademicYearOptions);?></select>'
            + ' </div>'
            + '<table id="selectedcouselist" class="display" style="border-spacing:0; padding:0; width:100%;">'
            + '<thead>'
            + ' <tr>'
            + ' <th class="no-sort" style="width:3px"></th>'
            + ' <th>SEMESTER</th>'
            + ' <th>CRN</th>'
            + ' <th>SUBJECT</th>'
            + ' <th>NUM</th>'
            + ' <th>TITLE</th>'
            + ' <th>CREDITS</th>'
            + ' <th>INSTRUCTOR(S)</th>'
            + '</tr>'
            + '</thead>'
            + '<tfoot>'
            + ' <tr>'
            + ' <th></th>'
            + ' <th>SEMESTER</th>'
            + ' <th>CRN</th>'
            + ' <th>SUBJECT</th>'
            + ' <th>NUM</th>'
            + ' <th>TITLE</th>'
            + ' <th>CREDITS</th>'
            + ' <th>INSTRUCTOR(S)</th>'
            + '</tr>'
            + '</tfoot>'
            + '</table>'
            + '</div></form>';

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD COURSES</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ADD",
                    className: 'btn-success',
                    callback: function(){
                        if (popupfrm._AY.value.isEmpty())
                        {
                            popupfrm._AY.focus();
                            Swal.fire({title:"ERROR", text: "Academic Year information is not selected!!", icon:"error"});

                            return false;
                        }
                        let selected = DataTable_CoursesList.rows({ selected: true }).data();
                        if (selected.length == 0) {
                            Swal.fire({title: "ERROR", text: "You need to check at least one course!!", icon: "error"});
                            return false;
                        }
                        let selectedcoures = '';
                        for(let i = 0; i < selected.length; ++i) {
                            if (selectedcoures !='') selectedcoures += "|";
                            selectedcoures += selected[i].Idx;
                        }

                        AddAbetCourses_Perform(popupfrm._AY.value, selectedcoures);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        });

        DataTable_CoursesList = $("#selectedcouselist").DataTable({
            "processing": true,
            "serverSide": false,
            "iDisplayLength": 8,
            "lengthChange": false,
            "sDom": 'tp', // invisible search box & show pagination tabs
            "ajax": "ssps/dept_abetcourses_courselist_ssps.php?_AY="+SelectedAcademicYear,
            "order": [[ 1, 'asc' ], [ 2, 'asc' ]],
            "fnDrawCallback": function() {
                $('#selectedcouselist tr td:nth-child(1)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(2)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(3)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(4)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(5)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(7)').css('text-align', 'center');

                $('#selectedcouselist tr td:nth-child(6)').css('width', '200px');
                $('#selectedcouselist tr td:nth-child(8)').css('width', '200px');
            },
            "columns": [
                {
                    "data": 'DT_RowId',
                    "render": function ( data, type, full, meta ) {
                        return '';
                    }
                },
                { "data": 'SemesterTxt' },
                { "data": 'CRN' },
                { "data": 'Subject' },
                { "data": 'Num' },
                { "data": 'Title' },
                { "data": 'Credits' },
                { "data": 'Instructor' }
            ],
            "columnDefs": [
                {
                    'orderable': false,
                    'className': 'select-checkbox',
                    'targets': 0
                },
                {
                "targets"  : 'no-sort',
                "orderable": false,
                }
            ],
            'select': {
                'style': 'multi'
            }
        });


        // Setup - add a text input to each footer cell
        $('#selectedcouselist tfoot th').each( function (index, value) {
            if (index == 0) return; // skip for checkbox column
            let title = $(this).text();
            $(this).html( '<input type="text" placeholder="Search '+title+'" value="'+DataTable_CoursesList.column(index).search()+'" style="color:black; width: 100%;padding:1px;box-sizing: border-box;"/>' );
        } );

        // Apply the search
        DataTable_CoursesList.columns().every( function () {
            let that = this;
            $( 'input', this.footer() ).on( 'keyup change', function () {
                if (popupfrm._AY.value.isEmpty())
                {
                    popupfrm._AY.focus();
                    Swal.fire({title:"ERROR", text: "Please select Target Academic Year information first!!", icon:"error"});
                    this.value = '';
                    return false;
                }

                if ( that.search() !== this.value ) {
                    that
                        .search( this.value )
                        .draw();
                }
            });
        } );


        $('#selectedcouselist tbody').on( 'click', 'tr', function () {
            if (popupfrm._AY.value.isEmpty())
            {
                popupfrm._AY.focus();
                Swal.fire({title:"ERROR", text: "Please select Target Academic Year information first!!", icon:"error"});
                return false;
            }
        } );


        // let e = document.academicyear._AY;
        // let selectedAcademicYear = e.options[e.selectedIndex].value;
        if (SelectedAcademicYear != '') {
            popupfrm._AY.value = SelectedAcademicYear;
            UpdateCourses(popupfrm._AY);
        }
    }

    function UploadAbetSyllabus(_IDX="", _AYINFO="", _AY="", _SUBJECT="", _NUM="", _TITLE="", _DEGREE="", _AP="")
    {
        const content = `
                <form enctype="multipart/form-data" name="popupfrm" id="popupfrm">
                <input type="hidden" name="_IDX" size="30" value="${_IDX}">
                <input type="hidden" name="_AYINFO" size="30" value="${_AYINFO}">
                <input type="hidden" name="_AY" size="30" value="${_AY}">
                <input type="hidden" name="_AP" size="30" value="${_AP}">
                <input type="hidden" name="_DEGREE" size="30" value="${_DEGREE}">
                <input type="hidden" name="_SUBJECT" size="30" value="${_SUBJECT}">
                <input type="hidden" name="_NUM" size="30" value="${_NUM}">
                <table style="border-spacing:0; padding:0; width:100%;">
                <tr><td colspan="2"><div class="input-group" style="width:100%">
                 <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">COURSE INFO: ${_AYINFO} ${_SUBJECT} ${_NUM} </span>
                 </div>
                 <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Syllabus<span style="color:red">* (PDF only, MAX: 2MB)</span></span>
                 <input type="file" name="_FILE" id="_FILE" class="input-sm form-control" value="" placeholder="Select Syllabus File" accept=".pdf" onchange="FileSizeValidation('_FILE')" required>
                 </div>
                </div></td></tr>
                </table></form>
                `;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">UPLOAD MASTER SYLLABUS</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> UPLOAD",
                    className: 'btn-success',
                    callback: function(){
                        if (popupfrm._FILE.files.length == 0)
                        {
                            popupfrm._FILE.focus();
                            Swal.fire({title:"ERROR", text: "File is not selected!!", icon:"error"});
                            return false;
                        }
                        if (FileSizeValidation('_FILE') == false)
                            return false;
                        UploadAbetSyllabus_Perform();
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_FILE").focus();
        });
    }

    function UploadAbetSyllabus_Perform()
    {
        // Show the full page spinner
        showFullPageSpinner();

        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                // Hide spinner and show notification
                hideFullPageSpinner();

                switch(xmlhttp.responseText.trim())
                {
                    case"0x11111111": {
                        DataTable_AbetCourseList.ajax.reload(null, false);
                        Swal.fire({
                            icon: 'success',
                            title: "UPLOADED",
                            text: "Abet syllabus has been uploaded!",
                            timer: 2000
                        });
                        break;
                    }
                    case "0x00251400": {
                        Swal.fire({title:"ERROR", text: "The file uploaded exceeds the limits (2MB)!", icon:"error"});
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }

        const formData = new FormData(document.forms.namedItem("popupfrm"));
        xmlhttp.open("POST", "dept_abetcourses_uploadsyllabus_ajax.php", true);
        xmlhttp.send(formData);
        // reference site: https://developer.mozilla.org/en-US/docs/Web/API/FormData/Using_FormData_Objects
    }

    function removesyllabus(Idx, AcademicYearInfo, AbetSyllabus)
    {
        Swal.fire({
            title: "DELETE?",
            html: "Deleted master syllabus cannot be restored!",
            icon: "question",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, delete it!"
        }).then(function(result){
            if (result.value)
            {
                let xmlhttp;
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp=new XMLHttpRequest();
                } else { // code for IE6, IE5
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function() {
                    if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                        switch(xmlhttp.responseText.trim()) {
                            case "0x11111111":
                                DataTable_AbetCourseList.ajax.reload(null, false);

                                Swal.fire({
                                    title: "DELETED!",
                                    text: "The selected abet syllabus has been deleted!",
                                    icon: "success",
                                    timer: 2000
                                });
                                break;
                            default:
                                Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                            // unexpected error
                        }
                    }
                }
                const param = "idx="+Idx+"&ayinfo="+encodeURIComponent(AcademicYearInfo)+"&abetsyllabus="+encodeURIComponent(AbetSyllabus);
                xmlhttp.open("POST", "dept_abetcourses_removeabetsyllabus_ajax.php", true);
                xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlhttp.send(param);
            }

        });
    }

</script>

<script class="init">
    $(document).ready(function() {
        const szURL = 'ssps/dept_abetcourses_ssps.php?_AY=';

        DataTable_AbetCourseList = $("#AbetCourses").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            "stateSave": true,
            "processing": true,
            "serverSide": false,
            "select": true,
            "lengthMenu": [ 15, 30, 50, 100, 150, 200, 300, 400 ],
            "ajax": `${szURL}${SelectedAcademicYear}`,
            "oLanguage": {"sInfoFiltered": ""},
            "order": [[ 2, "asc" ], [ 3, "asc" ], [ 4, "asc" ]], // default sorting
            "columns": [
                {
                    "data": null,
                    "className": "select-checkbox",
                    "defaultContent": "",
                    "orderable": false
                },
                { "data": 'Semester' },
                { "data": 'CRN' },
                { "data": 'Subject' },
                { "data": 'Num' },
                { "data": 'Title' },
                { "data": 'Credits' },
                { "data": 'Level' },
                { "data": 'Instructor' },
                { "data": 'StudentOutcomes' },
                {
                    "data": 'GPIs',
                    "render": function ( data, type, full, meta ) {
                        let tmp = full.GPIs;
                        let res = tmp.split(",");
                        tmp = "";
                        for(let i = 0; i < res.length; i++) {
                            // find only PI assigned items
                            if (res[i].search("-") >= 0) {
                                if (tmp != "") tmp += ", ";
                                tmp += res[i].trim();
                            }
                        }
                        return tmp;
                    }
                },
                {
                    "data": 'AbetSyllabus',
                    "render": function ( data, type, full, meta ) {
                        let tmp = '<a id="abetsyllabus" href="" target="_blank" style="color:blue;">'+data+'</a>';
                        if (full.AbetSyllabus != '')
                            tmp += '&nbsp;<span id=\"removesyllabus\" class=\"btn btn-xs glyphicon glyphicon-remove-circle\" style=\"color: red; min-height: 20px;\"></span>';
                        return tmp;
                    }
                },
                { "data": "" } // used for representing menu options
            ],
            "fnInitComplete": function(oSettings, json) {
                // Add "Clear Filter" button to Filter
                let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                    $('#' + oSettings.sTableId).dataTable().fnFilter('');
                });
            },
            "fnDrawCallback": function() {
                this.api().state.clear(); // cancel "stateSave" after reload the page
                $('#AbetCourses tr td:nth-child(1)').css('text-align', 'center');
                $('#AbetCourses tr td:nth-child(2)').css('text-align', 'center');
                $('#AbetCourses tr td:nth-child(3)').css('text-align', 'center');
                $('#AbetCourses tr td:nth-child(4)').css('text-align', 'center');
                $('#AbetCourses tr td:nth-child(5)').css('text-align', 'center');
                $('#AbetCourses tr td:nth-child(7)').css('text-align', 'center');
                $('#AbetCourses tr td:nth-child(8)').css('text-align', 'center');

                $('#AbetCourses tr td:nth-child(1)').css('vertical-align', 'bottom');
                $('#AbetCourses tr td:nth-child(2)').css('width', '40px');
                $('#AbetCourses tr td:nth-child(3)').css('width', '20px');
                $('#AbetCourses tr td:nth-child(4)').css('width', '25px');
                $('#AbetCourses tr td:nth-child(5)').css('width', '25px');
                $('#AbetCourses tr td:nth-child(9)').css('width', '25px');
                $('#AbetCourses tr td:nth-child(13)').css('width', '110px');
            },
            "columnDefs": [
                {
                    "targets"  : 'no-sort',
                    "orderable": false,
                }
                ,{
                    "targets": -1,
                    "data": null,
                    "orderable": false,
                    "defaultContent": "<button id=\"assignso\" alt=\"Assign Student Outcomes\" title=\"Assign Student Outcome\" class=\"btn btn-danger btn-xs glyphicon glyphicon-th-list\" style=\"min-height: 20px;\"></button></div>&nbsp;<button id=\"assigngpi\" alt=\"Assign Performance Indicators\" title=\"Assign Performance Indicators\" class=\"btn btn-danger btn-xs glyphicon glyphicon-list\" style=\"min-height: 20px;\"></button></div>&nbsp;<button id=\"upload\" alt=\"Upload Master course syllabus\" title=\"Upload Master course syllabus\" class=\"btn btn-danger btn-xs glyphicon glyphicon-upload\" style=\"min-height: 20px;\"></button></div>&nbsp;<button id=\"remove\" alt=\"Remove ABET course\" title=\"Remove ABET course\" class=\"btn btn-danger btn-xs glyphicon glyphicon-remove\" style=\"min-height: 20px;\"></button></div>"
                }
            ],
            "buttons": [
                {
                    "extend": 'pdfHtml5',
                    "orientation": 'landscape',
                    "title": 'ABET Courses ('+document.forms["changefrm"]["CH_APR"].options[document.forms["changefrm"]["CH_APR"].selectedIndex].text+')',
                    "exportOptions": {
                        columns: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
                    },
                    "customize": function(doc) {
                        doc.styles.tableHeader.fontSize = 9;
                        doc.defaultStyle.fontSize = 8; // change default fontsize
                    }
                },
                {
                    "extend": 'excelHtml5',
                    "title": 'ABET Courses ('+document.forms["changefrm"]["CH_APR"].options[document.forms["changefrm"]["CH_APR"].selectedIndex].text+')',
                    "exportOptions": {
                        columns: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
                    }
                }
            ],'select': {
                'style': 'multi'
            }
        });


        // Add event listener to the select element
        $("#_AY").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_AbetCourseList.ajax.url(tmpURL).load();
        });

        // Setup - add a text input to each footer cell
        $('#AbetCourses tfoot th').each( function (index, value) {
            let title = $(this).text();
            if (title != '')
                $(this).html( '<input type="text" placeholder="Search '+title+'" value="'+DataTable_AbetCourseList.column(index).search()+'" style="color:black; width: 100%;padding:1px;box-sizing: border-box;"/>' );
        } );

        $('#AbetCourses').on('click', '.toggle-all', function() {
            $(this).closest("tr").toggleClass("selected");
            if ($(this).closest("tr").hasClass("selected")) {
                DataTable_AbetCourseList.rows({ page: 'current' }).select();
            }
            else {
                DataTable_AbetCourseList.rows({ page: 'current' }).deselect();
            }
        });

        // Apply the search
        DataTable_AbetCourseList.columns().every( function () {
            let that = this;
            $( 'input', this.footer() ).on( 'keyup change', function () {
                if ( that.search() !== this.value ) {
                    that
                        .search( this.value )
                        .draw();
                }
            });
        } );

        $('#AbetCourses tbody').on( 'click', '#removesyllabus', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            removesyllabus(data.Idx, data.AcademicYearInfo, data.AbetSyllabus);
            return false; // disable row selection action
        } );

        $('#AbetCourses tbody').on( 'click', '#abetsyllabus', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            location.href = "pdf_viewer.php?pdf="+data.AbetSyllabus+"&cn=293428384&ayinfo="+data.AcademicYearInfo;
            // let win = window.open();
            // win.location = "pdf_viewer.php?pdf="+data.AbetSyllabus+"&cn=293428384";
            // win.opener = null;
            // win.blur();
            // window.focus();
            return false; // disable row selection action
        } );

        $('#AbetCourses tbody').on( 'click', '#assignso', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            AssignSOs(data.Idx, data.AcademicYear, data.AcademicYearInfo, data.SOIdxes);
            return false; // disable row selection action
        } );
        $('#AbetCourses tbody').on( 'click', '#assigngpi', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            if (data.SOIdxes == null)
            {
                Swal.fire({
                    title: "ERROR",
                    text: "Please add Student Outcomes first.",
                    icon: "error",
                    timer: 5000
                }).then(function(result){
                });
                return false;
            }
            AssignPIs(data.Idx, data.AcademicYear, data.AcademicYearInfo, data.SOIdxes, data.GPIIdxes);
            return false;  // disable row selection action
        } );
        $('#AbetCourses tbody').on( 'click', '#remove', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            RemoveAbetCourse(data.Idx, data.AcademicYearInfo, data.Subject, data.Num, data.Title, data.Syllabus);
            return false;  // disable row selection action
        } );
        $('#AbetCourses tbody').on( 'click', '#upload', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            UploadAbetSyllabus(data.Idx, data.AcademicYearInfo, data.AcademicYear, data.Subject, data.Num, data.Title, data.Degree, data.AcademicProgram);
            return false;  // disable row selection action
        } );
    } );

</script>

<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">ABET COURSE EVALUATION CYCLE</p>
        <?php include('control_selprogram.php'); ?>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:20%; min-width:350px;">
                    <?php echo($AcademicYearSelection);?>
                </td>
                <td style="width:5%"></td>
                <td style="width:75%; text-align: right">
                    <?php
                    if ($AcademicYearOptions != "") // Academic Year Information exists
                    {    ?>
                        <button class="btn btn-danger btn-sm glyphicon glyphicon-th-large" onclick="AssignLevelToSelectedCourses();return false;">&nbsp;ASSIGN LEVEL</button>
                        <button class="btn btn-danger btn-sm glyphicon glyphicon-th-list" onclick="AssignSOsToSelectedCourses();return false;">&nbsp;ASSIGN SOs</button>
                        <button class="btn btn-danger btn-sm glyphicon glyphicon-list" onclick="AssignPIsToSelectedCourses();return false;">&nbsp;ASSIGN PIs</button>
                        <button class="btn btn-danger btn-sm glyphicon glyphicon-list-alt" onclick="AddAbetCourses();return false;">&nbsp;ADD ABET COURSES</button>
                        <?php
                    }
                    ?>
                </td>
            </tr>
        </table>


        <div class="CSSTable_SSPSLIST">
            <table id="AbetCourses" class="display" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th class="toggle-all" style="width:3px; "></th>
                    <th style="width:50px">SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>LEVEL</th>
                    <th>INSTRUCTOR</th>
                    <th style="width:150px">STUDENT OUTCOMES</th>
                    <th style="width:180px">PERFORMANCE INDICATORS</th>
                    <th>MASTER SYLLABUS</th>
                    <th class="no-sort">OPERATION</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th></th>
                    <th>SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>LEVEL</th>
                    <th>INSTRUCTOR</th>
                    <th>STUDENT OUTCOMES</th>
                    <th>PERFORMANCE INDICATORS</th>
                    <th></th>
                    <th></th>
                </tr>
                </tfoot>
            </table>
        </div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-th-large" style="pointer-events: none;"></span>: Assign Course Level
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-th-list" style="pointer-events: none;"></span>: Assign Student Outcome
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-list" style="pointer-events: none;"></span>: Assign Performance Indicator
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-upload" style="pointer-events: none;"></span>: Upload ABET Syllabus
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Remove ABET Course
                </td>
            </tr>
        </table>
    </div>
</div>


<?php include('footer.php');?>



