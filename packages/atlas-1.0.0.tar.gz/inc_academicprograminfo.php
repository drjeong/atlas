<?php
/**
 * Academic Program Info
 * Description: displaying academic program information
 * Author: Dong Hyun Jeong
 *
 * 02/21/2021 - initial version created
 */


include_once 'session_handler.php';


//--------------------------------- DB PROCESS ------------------------------------------------------
require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

$Query ="SELECT `APRGMS`.`Idx` AS `Idx`, `APRGMS`.`Name` AS `AcademicProgram` FROM `AcademicPrograms` AS `APRGMS` ORDER BY `APRGMS`.`Idx`";
//echo $Query;
$result = $DBCONNECTION->sendquery($Query);
//echo ("<option value=\"\"></option>");

$idx=1;
while($row  = $DBCONNECTION->fetch_assoc())
{
    echo ('<div class="checkbox"><label><input type="checkbox" name="_AccessControl" value="'.$row["Idx"].'"> '.$row["AcademicProgram"].'</label></div>');
//    echo ("<option value=\"".$row["Idx"]."\">".$row["AcademicProgram"]."</option>");
    $idx++;
}

