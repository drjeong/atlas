<?php
/**
 * Management of User Accounts
 * Description: update the selected user's password with randomly generated password.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 */

include('checker_systemadmin.php');


$advisorid=$_POST['id'];
$PWD=$_POST['pass'];

$PWD_Encrypted = hash('sha256', $PWD);


//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

	$Query = "UPDATE `UserAccounts` SET `PWD`='$PWD_Encrypted', `ResetPWD` = 1, `LoginFails` = 0 WHERE `Idx`='$advisorid';";
	//echo $Query;

	$result = $DBCONNECTION->sendquery($Query);


    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}