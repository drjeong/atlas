<?php

class PDFLayoutConverter
{
    private string $pdfjam_path;
    private ?string $tempFile = null;
    private ?string $backupFile = null;
    private ?string $intermediateFile = null;

    public function __construct(string $pdfjam_path = '/usr/bin/pdfjam')
    {
        $this->pdfjam_path = $pdfjam_path;
    }

    public function convert(string $filePath): bool
    {
        try {
            $this->validateInput($filePath);
            $this->createTempFiles($filePath);

            $layout = $this->detectLayout($filePath);
            $this->createBackup($filePath);

            if ($layout === 'landscape') {
                $this->processLandscapeFormat($filePath);
            } else {
                $this->processPortraitFormat($filePath);
            }

            $this->replaceOriginalFile($filePath);
            return true;

        } catch (Exception $e) {
            $this->handleError($e, $filePath);
            return false;
        } finally {
            $this->cleanup();
        }
    }

    private function validateInput(string $filePath): void
    {
        if (!file_exists($filePath) || !is_readable($filePath)) {
            throw new Exception("Input file does not exist or is not readable: {$filePath}");
        }
    }

    private function createTempFiles(string $filePath): void
    {
        $tempDir = sys_get_temp_dir();
        $timestamp = time();
        $randomStr = bin2hex(random_bytes(8));

        $this->tempFile = "{$tempDir}/temp_{$timestamp}_{$randomStr}.pdf";
        $this->backupFile = $filePath . '.backup';
        $this->intermediateFile = $this->tempFile . '_intermediate.pdf';
    }

    private function detectLayout(string $filePath): string
    {
        $pdfinfo = shell_exec("pdfinfo " . escapeshellarg($filePath));
        if ($pdfinfo === null) {
            throw new Exception("Failed to execute pdfinfo command");
        }

        if (!preg_match('/Page size:\s+(\d+\.?\d*)\s*x\s*(\d+\.?\d*)/', $pdfinfo, $matches)) {
            throw new Exception("Failed to detect PDF dimensions");
        }

        $width = floatval($matches[1]);
        $height = floatval($matches[2]);

        return ($width > $height) ? 'landscape' : 'portrait';
    }

    private function createBackup(string $filePath): void
    {
        if (!copy($filePath, $this->backupFile)) {
            throw new Exception("Failed to create backup file");
        }
    }

    private function processLandscapeFormat(string $filePath): void
    {

        // First create 2x4 layout in landscape
        $cmd1 = sprintf(
            '%s --no-landscape --nup 2x4 --paper letterpaper --frame true ' .
            '--scale 1.0 --outfile %s %s',
            $this->pdfjam_path,
            escapeshellarg($this->tempFile),
            escapeshellarg($filePath)
        );

        exec($cmd1, $output1, $returnVar1);
        if ($returnVar1 !== 0) {
            throw new Exception('Failed to create 2x4 layout: ' . implode("\n", $output1));
        }

//
//        // First create 2x3 layout in landscape
//        $cmd1 = sprintf(
//            '%s --landscape --nup 2x3 --paper letterpaper --frame true ' .
//            '--scale 1.0 --outfile %s %s',
//            $this->pdfjam_path,
//            escapeshellarg($this->intermediateFile),
//            escapeshellarg($filePath)
//        );
//
//        // Then rotate to portrait
//        $cmd2 = sprintf(
//            '%s --angle 90 --no-landscape --paper letterpaper ' .
//            '--outfile %s %s',
//            $this->pdfjam_path,
//            escapeshellarg($this->tempFile),
//            escapeshellarg($this->intermediateFile)
//        );
//
//        exec($cmd1, $output1, $returnVar1);
//        if ($returnVar1 !== 0) {
//            throw new Exception('Failed to create 2x3 layout: ' . implode("\n", $output1));
//        }
//
//        exec($cmd2, $output2, $returnVar2);
//        if ($returnVar2 !== 0) {
//            throw new Exception('Failed to rotate to portrait: ' . implode("\n", $output2));
//        }
    }

    private function processPortraitFormat(string $filePath): void
    {
        $cmd = sprintf(
            '%s --no-landscape --nup 2x2 --suffix 4up --letterpaper --frame true --trim "0mm 0mm 0mm 0mm" --outfile %s %s',
            $this->pdfjam_path,
            escapeshellarg($this->tempFile),
            escapeshellarg($filePath)
        );

        exec($cmd, $output, $returnVar);
        if ($returnVar !== 0) {
            throw new Exception('Failed to process portrait format: ' . implode("\n", $output));
        }
    }

    private function replaceOriginalFile(string $filePath): void
    {
        if (!file_exists($this->tempFile)) {
            throw new Exception("Conversion failed - temporary file not created");
        }

        if (!rename($this->tempFile, $filePath)) {
            if (!copy($this->tempFile, $filePath)) {
                throw new Exception("Failed to replace original file");
            }
            unlink($this->tempFile);
        }

        // Remove backup file after successful replacement
        if (file_exists($this->backupFile)) {
            unlink($this->backupFile);
        }
    }

    private function handleError(Exception $e, string $filePath): void
    {
        // Restore from backup if it exists
        if ($this->backupFile && file_exists($this->backupFile)) {
            copy($this->backupFile, $filePath);
        }

        error_log("PDF conversion error: " . $e->getMessage());
    }

    private function cleanup(): void
    {
        // Clean up temporary files
        if ($this->tempFile && file_exists($this->tempFile)) {
            @unlink($this->tempFile);
        }

        if ($this->intermediateFile && file_exists($this->intermediateFile)) {
            @unlink($this->intermediateFile);
        }

        if ($this->backupFile && file_exists($this->backupFile)) {
            @unlink($this->backupFile);
        }
    }
}