<?php
/**
 * Attainment Thresholds API
 * Handles CRUD operations for attainment thresholds by program
 *
 * Date: 2026-07-17
 */

// Make sure session is started BEFORE checking session variables
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once(__DIR__ . '/../php_include/dbconnection_class.php');

header('Content-Type: application/json');

// Enable error logging for debugging
//error_log('=== Attainment Thresholds API Called ===');
//error_log('Action: ' . ($_GET['action'] ?? $_POST['action'] ?? 'none'));
//error_log('Session Program: ' . ($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] ?? 'not set'));

$DBCONNECTION = new Dbconnection();

$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : '');
$programIdx = isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']) ? intval($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']) : 0;

if ($programIdx === 0) {
    error_log('ERROR: No program selected');
    echo json_encode([
        'success' => false,
        'message' => 'No program selected. Please select a program from the dropdown.',
        'debug' => [
            'session_id' => session_id(),
            'session_keys' => array_keys($_SESSION ?? [])
        ]
    ]);
    exit;
}

//error_log('Processing action: ' . $action . ' for program: ' . $programIdx);

switch ($action) {
    case 'get':
        getThresholds($DBCONNECTION, $programIdx);
        break;
    case 'update':
        updateThresholds($DBCONNECTION, $programIdx);
        break;
    case 'reset':
        resetThresholds($DBCONNECTION, $programIdx);
        break;
    default:
        error_log('ERROR: Invalid action: ' . $action);
        echo json_encode(['success' => false, 'message' => 'Invalid action: ' . $action]);
        break;
}

/**
 * Get thresholds for a specific program
 */
function getThresholds($DBCONNECTION, $programIdx) {
    //error_log('Getting thresholds for program: ' . $programIdx);

    $query = "
        SELECT 
            ThresholdType,
            ScoreThreshold,
            GreenThreshold,
            YellowThreshold,
            Label
        FROM AttainmentThresholds
        WHERE ProgramIdx = ?
        ORDER BY ThresholdType
    ";

    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$programIdx]);

    if ($result === false) {
        error_log('ERROR: Database query failed');
        echo json_encode(['success' => false, 'message' => 'Database query error']);
        return;
    }

    $thresholds = [];

    // Check if result is a mysqli_result object and fetch all rows
    if ($result instanceof mysqli_result) {
        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $result->free();

        //error_log('Found ' . count($rows) . ' threshold records');

        foreach ($rows as $row) {
            $thresholds[$row['ThresholdType']] = [
                'score' => floatval($row['ScoreThreshold']),
                'green' => floatval($row['GreenThreshold']),
                'yellow' => floatval($row['YellowThreshold']),
                'label' => $row['Label']
            ];
        }
    } elseif (is_array($result)) {
        // If it returns an array directly
        //error_log('Found ' . count($result) . ' threshold records');

        foreach ($result as $row) {
            $thresholds[$row['ThresholdType']] = [
                'score' => floatval($row['ScoreThreshold']),
                'green' => floatval($row['GreenThreshold']),
                'yellow' => floatval($row['YellowThreshold']),
                'label' => $row['Label']
            ];
        }
    } else {
        error_log('No thresholds found - inserting defaults');
    }

    // If no thresholds exist, insert defaults
    if (empty($thresholds)) {
        $inserted = insertDefaultThresholds($DBCONNECTION, $programIdx);
        if ($inserted) {
            error_log('Default thresholds inserted - retrying query');
            // Recursively call to get the newly inserted values
            getThresholds($DBCONNECTION, $programIdx);
            return;
        } else {
            error_log('ERROR: Failed to insert default thresholds');
            echo json_encode(['success' => false, 'message' => 'Failed to create default thresholds']);
            return;
        }
    }

//    error_log('SUCCESS: Returning thresholds');
    echo json_encode([
        'success' => true,
        'thresholds' => $thresholds,
        'program_idx' => $programIdx
    ]);
}

/**
 * Update thresholds for a specific program
 */
function updateThresholds($DBCONNECTION, $programIdx) {
    //error_log('Updating thresholds for program: ' . $programIdx);

    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['thresholds'])) {
        error_log('ERROR: Missing thresholds data in request');
        echo json_encode(['success' => false, 'message' => 'Missing thresholds data']);
        return;
    }

    $thresholds = $input['thresholds'];
    $userIdx = isset($_SESSION['ATLAS_ACCESSCNTL_IDX']) ? intval($_SESSION['ATLAS_ACCESSCNTL_IDX']) : null;

    //error_log('Updating thresholds - User: ' . ($userIdx ?? 'none'));
    //error_log('Input thresholds: ' . json_encode($thresholds));

    $success = true;
    $errorMessage = '';
    $updatedCount = 0;

    foreach (['basic', 'proficiency'] as $type) {
        if (!isset($thresholds[$type])) {
            error_log('Skipping ' . $type . ' - not in request');
            continue;
        }

        $data = $thresholds[$type];

        //error_log('Updating ' . $type . ': green=' . $data['green'] . ', yellow=' . $data['yellow']);

        $query = "
            UPDATE AttainmentThresholds
            SET 
                GreenThreshold = ?,
                YellowThreshold = ?,
                ModifiedBy = ?,
                ModifiedDate = CURRENT_TIMESTAMP
            WHERE ProgramIdx = ? AND ThresholdType = ?
        ";

        $params = [
            floatval($data['green']),
            floatval($data['yellow']),
            $userIdx,
            $programIdx,
            $type
        ];

        //error_log('Executing UPDATE with params: ' . json_encode($params));
        //error_log($DBCONNECTION->formatQuery($query, $params));

        $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

        //error_log('Update result - Type: ' . gettype($result) . ', Value: ' . var_export($result, true));

        if ($result !== false) {
            //error_log('SUCCESS: Updated ' . $type . ' threshold');
            $updatedCount++;
        } else {
            $success = false;
            // Get the actual database error
            $dbError = $DBCONNECTION->get_last_error();
            $errorMessage = "Failed to update {$type} threshold: " . $dbError;
            error_log('ERROR: ' . $errorMessage);
            break;
        }
    }

    if ($success && $updatedCount > 0) {
        //error_log('SUCCESS: All thresholds updated (' . $updatedCount . ' records)');
        echo json_encode([
            'success' => true,
            'message' => 'Thresholds updated successfully',
            'updated_count' => $updatedCount
        ]);
    } else if ($updatedCount == 0) {
        error_log('WARNING: No thresholds were updated');
        echo json_encode([
            'success' => false,
            'message' => 'No thresholds were updated'
        ]);
    } else {
        error_log('ERROR: Update failed - ' . $errorMessage);
        echo json_encode([
            'success' => false,
            'message' => $errorMessage
        ]);
    }
}

/**
 * Reset thresholds to default values
 */
function resetThresholds($DBCONNECTION, $programIdx) {
    //error_log('Resetting thresholds for program: ' . $programIdx);

    $userIdx = isset($_SESSION['ATLAS_ACCESSCNTL_IDX']) ? intval($_SESSION['ATLAS_ACCESSCNTL_IDX']) : null;

    $query = "
        UPDATE AttainmentThresholds
        SET 
            GreenThreshold = CASE 
                WHEN ThresholdType = 'basic' THEN 90.00
                WHEN ThresholdType = 'proficiency' THEN 80.00
            END,
            YellowThreshold = CASE 
                WHEN ThresholdType = 'basic' THEN 80.00
                WHEN ThresholdType = 'proficiency' THEN 70.00
            END,
            ModifiedBy = ?,
            ModifiedDate = CURRENT_TIMESTAMP
        WHERE ProgramIdx = ?
    ";

    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$userIdx, $programIdx]);

    if ($result !== false) {
        //error_log('SUCCESS: Thresholds reset to defaults');
        echo json_encode([
            'success' => true,
            'message' => 'Thresholds reset to default values'
        ]);
    } else {
        error_log('ERROR: Failed to reset thresholds');
        echo json_encode([
            'success' => false,
            'message' => 'Failed to reset thresholds'
        ]);
    }
}

/**
 * Insert default thresholds for a program
 */
function insertDefaultThresholds($DBCONNECTION, $programIdx) {
    //error_log('Inserting default thresholds for program: ' . $programIdx);

    $userIdx = isset($_SESSION['ATLAS_ACCESSCNTL_IDX']) ? intval($_SESSION['ATLAS_ACCESSCNTL_IDX']) : null;

    // Check if thresholds already exist (to avoid duplicate key errors)
    $checkQuery = "SELECT COUNT(*) as cnt FROM AttainmentThresholds WHERE ProgramIdx = ?";
    $checkResult = $DBCONNECTION->prepare_execute_catch_error($checkQuery, [$programIdx]);

    if ($checkResult instanceof mysqli_result) {
        $row = $checkResult->fetch_assoc();
        $checkResult->free();
        if ($row['cnt'] > 0) {
            error_log('Thresholds already exist for this program');
            return true;
        }
    }

    // Insert basic threshold
    $query1 = "
        INSERT INTO AttainmentThresholds 
        (ProgramIdx, ThresholdType, ScoreThreshold, GreenThreshold, YellowThreshold, Label, CreatedBy)
        VALUES (?, 'basic', 2.0, 90.00, 80.00, 'Basic Competency (≥2.0)', ?)
    ";

    $result1 = $DBCONNECTION->prepare_execute_catch_error($query1, [$programIdx, $userIdx]);

    // Insert proficiency threshold
    $query2 = "
        INSERT INTO AttainmentThresholds 
        (ProgramIdx, ThresholdType, ScoreThreshold, GreenThreshold, YellowThreshold, Label, CreatedBy)
        VALUES (?, 'proficiency', 3.0, 80.00, 70.00, 'Proficiency (≥3.0)', ?)
    ";

    $result2 = $DBCONNECTION->prepare_execute_catch_error($query2, [$programIdx, $userIdx]);

    $success = ($result1 !== false && $result2 !== false);

    if ($success) {
        error_log('SUCCESS: Default thresholds inserted');
    } else {
        error_log('ERROR: Failed to insert default thresholds');
    }

    return $success;
}
?>