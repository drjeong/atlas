class DataTableSearch {
  constructor(tableId, dataTable, showResetBtn = true) {
    this.tableId = tableId;
    this.dataTable = dataTable;
    this.showResetBtn = showResetBtn;
    this.initialize();
  }

  initialize() {
    if (this.showResetBtn) this.addResetButton();
    this.setupHeaderSearch();
    this.setupFooterSearch();
    this.initializeSearchHandlers();
  }

  // addResetButton() {
  //   $(this.tableId).before('&nbsp;<button id="resetSearch" class="btn btn-danger btn-xs" style="height:25px; margin-bottom:10px;">CLEAR ALL FILTERS</button>&nbsp;');
  //
  //   $('#resetSearch').on('click', () => {
  //     // Clear all input fields
  //     $(`${this.tableId} #serachbox input, ${this.tableId} tfoot input`).each(function() {
  //       $(this).val('');
  //       $(this).siblings('.clearColumn').hide(); // Hide all clear buttons
  //     });
  //
  //     // Clear all searches
  //     this.dataTable.columns().every(function() {
  //       this.search('');
  //     });
  //     this.dataTable.search('');
  //     this.dataTable.draw();
  //   });
  // }


  addResetButton() {
    this.dataTable.on('init.dt', () => {
      const tableId = this.tableId.replace('#', '');
      const btnResetAll = $('<button id="resetSearch" class="btn btn-danger btn-xs" style="height:25px; margin-right:8px;">CLEAR ALL FILTERS</button>');
      $(`#${tableId}_wrapper .dataTables_length`).prepend(btnResetAll);

      $('#resetSearch').on('click', () => {
        $(`${this.tableId} #serachbox input, ${this.tableId} tfoot input`).each(function() {
          $(this).val('');
          $(this).siblings('.clearColumn').hide();
        });
        this.dataTable.columns().every(function() {
          this.search('');
        });
        this.dataTable.search('');
        this.dataTable.draw();
        if (this.enableHoldSearch) {
          localStorage.removeItem(this.storageKey);
        }
      });
    });
  }

  setupHeaderSearch() {
    $(`${this.tableId} #serachbox th`).each((index, element) => {
      const title = $(element).text().trim();
      if (title !== '' && title !== null) {
        $(element).html(`
                    <div style="display: flex; gap: 2px;">
                        <input type="text" placeholder="Search ${title}" 
                               value="${this.dataTable.column(index).search()}"
                               style="color:black; width: 100%; padding:1px; box-sizing: border-box;"/>
                        <button class="clearColumn" data-column="${index}" 
                                style="padding: 0 4px; display: none;">×</button>
                    </div>
                `);
      }
    });
  }

  setupFooterSearch() {
    $(`${this.tableId} tfoot th`).each((index, element) => {
      const title = $(element).text().trim();
      if (title !== '' && title !== null) {
        $(element).html(`
                    <div style="display: flex; gap: 2px;">
                        <input type="text" placeholder="Search ${title}" 
                               value="${this.dataTable.column(index).search()}"
                               style="color:black; width: 100%; padding:1px; box-sizing: border-box;"/>
                        <button class="clearColumn" data-column="${index}" 
                                style="padding: 0 4px; display: none;">×</button>
                    </div>
                `);
      }
    });
  }

  initializeSearchHandlers() {
    // Individual column clear button handler
    $(this.tableId).on('click', '.clearColumn', (event) => {
      const columnIndex = $(event.currentTarget).data('column');
      $(event.currentTarget).siblings('input').val('');
      $(event.currentTarget).hide();
      this.dataTable.column(columnIndex).search('').draw();
    });

    // Input handlers for both header and footer
    const handleInput = (input, clearButton) => {
      if (input.value.length > 0) {
        clearButton.style.display = 'block';
      } else {
        clearButton.style.display = 'none';
      }
    };

    // Header search handler
    this.dataTable.columns().every((colIdx) => {
      const that = this.dataTable.column(colIdx);
      $('input', $('.filters th').eq($(this.dataTable.column(colIdx).header()).index()))
          .on('keyup change', function() {
            const clearButton = $(this).siblings('.clearColumn')[0];
            handleInput(this, clearButton);
            if (that.search() !== this.value) {
              that.search(this.value).draw();
            }
          });
    });

    // Footer search handler
    this.dataTable.columns().every(function() {
      const that = this;
      $('input', this.footer()).on('keyup change', function() {
        const clearButton = $(this).siblings('.clearColumn')[0];
        handleInput(this, clearButton);
        if (that.search() !== this.value) {
          that.search(this.value).draw();
        }
      });
    });
  }
}