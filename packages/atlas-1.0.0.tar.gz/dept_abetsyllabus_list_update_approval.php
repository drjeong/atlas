<?php
/**
 * Abet Syllabus
 * Description: Update the approval information (ApprovalDesc / ApprovalDate)
 *
 * 03/21/2026 - initial version created
 */
include_once 'session_handler.php';

$ABSIdx = '';
$Field  = '';
$Value  = '';

// Whitelist allowed fields to prevent SQL injection
$allowedFields = ['ApprovalDesc', 'ApprovalDate', 'Coordinator'];

if (array_key_exists('ABSIdx', $_POST)
    && array_key_exists('Field', $_POST)
    && array_key_exists('Value', $_POST))
{
    $ABSIdx = trim($_POST['ABSIdx']);
    $Field  = trim($_POST['Field']);
    $Value  = trim($_POST['Value']);
}
else
{
    // unwanted illegal entry
    echo json_encode(['success' => false, 'error' => 'Missing required fields', 'code' => '0x00000000']);
    exit;
}

if ($ABSIdx === '' || $Field === '') {
    // no required information
    echo json_encode(['success' => false, 'error' => 'Missing required information', 'code' => '0x00000101']);
    exit;
}

if (!in_array($Field, $allowedFields)) {
    // field not allowed
    echo json_encode(['success' => false, 'error' => 'Invalid field specified', 'code' => '0x00000102']);
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/../config.php');
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate ABSIdx must be integer
    $ABSIdx = filter_var($ABSIdx, FILTER_VALIDATE_INT);
    if ($ABSIdx === false) {
        throw new Exception('Invalid input format');
    }

    // Sanitize the value
    $Value = htmlspecialchars(strip_tags($Value), ENT_QUOTES, 'UTF-8');

    // Call stored procedure — pass Field name so SP knows which column to update
    $query  = "CALL SP_UpdateAbetSyllabusApproval(?, ?, ?);";
    $params = [$ABSIdx, $Field, $Value];
    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    if ($result) {
        echo json_encode(['success' => true, 'code' => '0x11111111']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Update failed', 'code' => '0x00000103']);
    }

} catch (mysqli_sql_exception $e) {
    echo json_encode(['success' => false, 'error' => 'Database error', 'code' => '0x00000500']);
    error_log(json_encode([
        'success' => false,
        'error'   => $e->getMessage(),
        'query'   => '0x00000500'
    ]));
    error_log($DBCONNECTION->FormatQuery($query, $params));
} catch (Exception $e) {
    error_log($e->getMessage());
    echo json_encode(['success' => false, 'error' => $e->getMessage(), 'code' => '0x00000000']);
}