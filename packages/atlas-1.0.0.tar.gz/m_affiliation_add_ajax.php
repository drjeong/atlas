<?php
/**
 * Management of Department (Affiliation) Information
 * Description: add department information
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 *
 */

include('checker_systemadmin.php');

$AffiliationName = (isset($_POST['_AFNAME'])) ? trim($_POST['_AFNAME']) : '';

if ($AffiliationName==""){
	echo "0x00000011";  // error
	exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // convert unwanted escape strings
    $AffiliationName = $DBCONNECTION->real_escape_string($AffiliationName);

    /////////////////////////////////////////////////////////////////////////////////
    // insert PI
    $query = "CALL SP_AddAffiliation(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$AffiliationName]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00200011') !== false) {
        echo '0x00200011';  // same item exists already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
