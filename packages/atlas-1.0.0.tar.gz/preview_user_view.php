<?php
session_start();

// Check if we're restoring admin session
if (isset($_GET['restore']) && $_GET['restore'] === 'true') {
    restoreAdminSession();
    echo json_encode(['success' => true, 'message' => 'Admin session restored']);
    exit;
}

// Security check - only system admins can preview
if (!isset($_SESSION['ATLAS_LOGIN_SYSADMIN']) || $_SESSION['ATLAS_LOGIN_SYSADMIN'] !== true) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit;
}

// Get target user ID
$targetUserIdx = isset($_POST['userIdx']) ? intval($_POST['userIdx']) : 0;

if ($targetUserIdx <= 0) {
    echo json_encode(['success' => false, 'error' => 'Invalid user ID']);
    exit;
}

try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Backup current admin session before switching
    backupAdminSession();

    // Fetch target user's session data
    $query = "CALL SP_GetUserSessionData(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$targetUserIdx]);

    if ($result && $DBCONNECTION->num_rows() > 0) {
        $row = $DBCONNECTION->fetch_assoc();

        // Mark this as a preview session
        $_SESSION['ATLAS_PREVIEW_MODE'] = true;
        $_SESSION['ATLAS_PREVIEW_ORIGINAL_ADMIN_IDX'] = $_SESSION['ATLAS_ADMIN_BACKUP']['ATLAS_LOGIN_USERIDX'];

        // Load target user's session data
        $_SESSION['ATLAS_LOGIN_USERIDX'] = $row["Idx"];
        $_SESSION['ATLAS_LOGIN_USERNAME'] = $row["Name"];
        $_SESSION['ATLAS_LOGIN_AFFILATION'] = $row["Affiliation"];
        $_SESSION['ATLAS_LOGIN_USEREMAIL'] = $row["Email"];
        $_SESSION['ATLAS_LOGIN_SYSADMIN'] = false; // Never give preview session admin rights
        $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = null;

        // Get access control information
        $_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'] = array();

        $AccessGranted = explode(",", $row["AccessGranted"]);
        $AccessNotGranted = explode(",", $row["AccessNotGranted"]);

        foreach($AccessGranted as $value) {
            if ($value != '') {
                $_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$value] = true;

                if ($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] == null) {
                    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = $value;
                }
            }
        }

        foreach($AccessNotGranted as $value) {
            if ($value != '') {
                $_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$value] = false;

                if ($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] == null) {
                    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = $value;
                }
            }
        }

        $_SESSION['ATLAS_LOGIN_OBSERVER'] = ($row["Observer"] == "1");
        $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] = false;

        // Program director check
        if (count(array_filter($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'])) > 0) {
            $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] = true;
        }

        // Add menu access control
        require_once(__DIR__ . '/php_include/menu_access_control.php');

        if (isset($_SESSION['ATLAS_LOGIN_USERIDX'])) {
            $menuAccess = new MenuAccessControl(
                $DBCONNECTION,
                $_SESSION['ATLAS_LOGIN_USERIDX']
            );

            $_SESSION['ATLAS_ACCESSIBLE_MENUS'] = $menuAccess->getAccessibleMenus();
        }

        // Update session time
        $_SESSION['ATLAS_LASTCONNECTEDTIME'] = time();
        $_SESSION['ATLAS_TIMEOUT'] = 3600;

        echo json_encode([
            'success' => true,
            'message' => 'Preview mode activated',
            'userName' => $row["Name"]
        ]);
        exit;
    }

    echo json_encode(['success' => false, 'error' => 'User not found']);
    exit;

} catch (Exception $e) {
    error_log('Preview User View Error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error']);
    exit;
}

/**
 * Backup current admin session
 */
function backupAdminSession() {
    $backupKeys = [
        'ATLAS_LOGIN_USERIDX',
        'ATLAS_LOGIN_USERNAME',
        'ATLAS_LOGIN_AFFILATION',
        'ATLAS_LOGIN_USEREMAIL',
        'ATLAS_LOGIN_SYSADMIN',
        'ATLAS_LOGIN_OBSERVER',
        'ATLAS_ACCESSCNTL_GRANTEDPROGRAMS',
        'ATLAS_ACCESSCNTL_SELECTEDPROGRAM',
        'ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS',
        'ATLAS_ACCESSIBLE_MENUS',
        'ATLAS_LASTCONNECTEDTIME',
        'ATLAS_TIMEOUT'
    ];

    $_SESSION['ATLAS_ADMIN_BACKUP'] = [];

    foreach ($backupKeys as $key) {
        if (isset($_SESSION[$key])) {
            $_SESSION['ATLAS_ADMIN_BACKUP'][$key] = $_SESSION[$key];
        }
    }
}

/**
 * Restore admin session from backup
 */
function restoreAdminSession() {
    if (isset($_SESSION['ATLAS_ADMIN_BACKUP']) && is_array($_SESSION['ATLAS_ADMIN_BACKUP'])) {
        foreach ($_SESSION['ATLAS_ADMIN_BACKUP'] as $key => $value) {
            $_SESSION[$key] = $value;
        }

        // Clear backup and preview mode flags
        unset($_SESSION['ATLAS_ADMIN_BACKUP']);
        unset($_SESSION['ATLAS_PREVIEW_MODE']);
        unset($_SESSION['ATLAS_PREVIEW_ORIGINAL_ADMIN_IDX']);
    }
}
