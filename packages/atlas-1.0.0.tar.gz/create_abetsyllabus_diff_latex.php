<?php
/**
 * Create ABET Syllabus Latex file
 * Description: It requires latex to be installed on the server.
 *      Check necessary components in LatexTemplate.php under php_include
 * Author: Dong Hyun Jeong
 *
 * 02/11/2025 - initial version created
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';


// for debugging
// create_abetsyllabus_diff_pdf.php?_idx=

$CourseIndex = '';
$CurrentSyllabusIndex = '';
$TargetSyllabusIndex = '';
$Subject = '';
$Title = '';
$Num = '';

if (array_key_exists('cidx', $_GET)
    && array_key_exists('tidx', $_GET)
    && array_key_exists('sub', $_GET)
    && array_key_exists('title', $_GET)
    && array_key_exists('num', $_GET) )
{
    $CurrentSyllabusIndex = trim($_GET['cidx']);
    $TargetSyllabusIndex = trim($_GET['tidx']);
    $Subject = trim($_GET['sub']);
    $Num = trim($_GET['num']);
    $Title = trim($_GET['title']);
}
else {
    // illegal entry
    exit;
}


require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();
$Data= array();

//----------------------------------------------------------------------------------------
// Initialize variables with default empty string
$data = null;

// Fetching abet syllabus information for different versions
$results = $DBCONNECTION->callStoredProcedure('SP_AbetSyllabus_FetchDiffInfo', [$CurrentSyllabusIndex, $TargetSyllabusIndex]);

// Check if results are returned
$data = null;
if ($results) {
    // Fetch and display the results
    while ($row = $results->fetch_assoc()) {
        $data = $row;
    }
}
$data['Subject'] = $Subject;
$data['Num'] = $Num;
$data['Title'] = $Title;

//print_r($data);
//exit;

$AbetSyllabusPDF_FileName = 'abet_syllabus';
$AbetSyllabusPDF_FileName .= '_'. str_replace(" ","_",strtolower($data['Subject']));
$AbetSyllabusPDF_FileName .= '_'. str_replace(" ","_",strtolower($data['Num']));
$AbetSyllabusPDF_FileName .= '_diff.pdf';

$data['logo'] = __UNIV_COLLEGE_LOGO_PATH__;

require_once(__DIR__ . '/php_include/listfunc.php');


try {
    require_once 'php_include/mail_attachment.php';
    require_once(__DIR__ . '/php_include/LatexTemplate.php');

    $data['Title'] = html_entity_decode($data['Title'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['Description_1'] = html_entity_decode($data['Description_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['Description_2'] = html_entity_decode($data['Description_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['Required_Texts_1'] = html_entity_decode($data['Required_Texts_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['Required_Texts_2'] = html_entity_decode($data['Required_Texts_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['Reference_Texts_1'] = html_entity_decode($data['Reference_Texts_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['Reference_Texts_2'] = html_entity_decode($data['Reference_Texts_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['Pre_requisites_1'] = html_entity_decode($data['Pre_requisites_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['Pre_requisites_2'] = html_entity_decode($data['Pre_requisites_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');

//    $data['Reference_Texts_1'] = convertTextToLatexUrl($data['Reference_Texts_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
//    $data['Reference_Texts_2'] = convertTextToLatexUrl($data['Reference_Texts_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
//    $data['Reference_Texts_1'] = html_entity_decode($data['Reference_Texts_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
//    $data['Reference_Texts_2'] = html_entity_decode($data['Reference_Texts_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');

    $data['Objectives_1'] = html_entity_decode($data['Objectives_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['Objectives_2'] = html_entity_decode($data['Objectives_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['ObjectivesHeadline_1'] = html_entity_decode($data['ObjectivesHeadline_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['ObjectivesHeadline_2'] = html_entity_decode($data['ObjectivesHeadline_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['TopicsCoveredHeadline_1'] = html_entity_decode($data['TopicsCoveredHeadline_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['TopicsCoveredHeadline_2'] = html_entity_decode($data['TopicsCoveredHeadline_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['TopicsCovered_1'] = html_entity_decode($data['TopicsCovered_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['TopicsCovered_2'] = html_entity_decode($data['TopicsCovered_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['RevisionDesc_1'] = html_entity_decode($data['RevisionDesc_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['RevisionDesc_2'] = html_entity_decode($data['RevisionDesc_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['ApprovalDesc_1'] = html_entity_decode($data['ApprovalDesc_1'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $data['ApprovalDesc_2'] = html_entity_decode($data['ApprovalDesc_2'], ENT_QUOTES | ENT_HTML5, 'UTF-8');

    $data['Title'] = LatexTemplate::replaceSpecialCharacters($data['Title']);
    $data['Description_1'] = LatexTemplate::replaceSpecialCharacters($data['Description_1']);
    $data['Description_2'] = LatexTemplate::replaceSpecialCharacters($data['Description_2']);
    $data['Pre_requisites_1'] = LatexTemplate::replaceSpecialCharacters($data['Pre_requisites_1']);
    $data['Pre_requisites_2'] = LatexTemplate::replaceSpecialCharacters($data['Pre_requisites_2']);
    $data['Required_Texts_1'] = LatexTemplate::replaceSpecialCharacters($data['Required_Texts_1']);
    $data['Required_Texts_2'] = LatexTemplate::replaceSpecialCharacters($data['Required_Texts_2']);
    $data['Reference_Texts_1'] = LatexTemplate::replaceSpecialCharacters($data['Reference_Texts_1']);
    $data['Reference_Texts_2'] = LatexTemplate::replaceSpecialCharacters($data['Reference_Texts_2']);
    $data['ObjectivesHeadline_1'] = LatexTemplate::replaceSpecialCharacters($data['ObjectivesHeadline_1']);
    $data['Objectives_1'] = LatexTemplate::replaceSpecialCharacters($data['Objectives_1']);
    $data['ObjectivesHeadline_2'] = LatexTemplate::replaceSpecialCharacters($data['ObjectivesHeadline_2']);
    $data['Objectives_2'] = LatexTemplate::replaceSpecialCharacters($data['Objectives_2']);
    $data['TopicsCoveredHeadline_1'] = LatexTemplate::replaceSpecialCharacters($data['TopicsCoveredHeadline_1']);
    $data['TopicsCovered_1'] = LatexTemplate::replaceSpecialCharacters($data['TopicsCovered_1']);
    $data['TopicsCoveredHeadline_2'] = LatexTemplate::replaceSpecialCharacters($data['TopicsCoveredHeadline_2']);
    $data['TopicsCovered_2'] = LatexTemplate::replaceSpecialCharacters($data['TopicsCovered_2']);
    $data['RevisionDesc_1'] = LatexTemplate::replaceSpecialCharacters($data['RevisionDesc_1']);
    $data['RevisionDesc_2'] = LatexTemplate::replaceSpecialCharacters($data['RevisionDesc_2']);
    $data['ApprovalDesc_1'] = LatexTemplate::replaceSpecialCharacters($data['ApprovalDesc_1']);
    $data['ApprovalDesc_2'] = LatexTemplate::replaceSpecialCharacters($data['ApprovalDesc_2']);

    $data['Title'] = LatexTemplate::plainTextToLatex($data['Title']);
    $data['Description_1'] = LatexTemplate::plainTextToLatex($data['Description_1']);
    $data['Description_2'] = LatexTemplate::plainTextToLatex($data['Description_2']);
    $data['Required_Texts_1']= LatexTemplate::plainTextToLatex($data['Required_Texts_1']);
    $data['Required_Texts_2']= LatexTemplate::plainTextToLatex($data['Required_Texts_2']);
    $data['Reference_Texts_1']= LatexTemplate::plainTextToLatex($data['Reference_Texts_1']);
    $data['Reference_Texts_2']= LatexTemplate::plainTextToLatex($data['Reference_Texts_2']);
    $data['RevisionDesc_1']= LatexTemplate::plainTextToLatex($data['RevisionDesc_1']);
    $data['RevisionDesc_2']= LatexTemplate::plainTextToLatex($data['RevisionDesc_2']);
    $data['ApprovalDesc_1']= LatexTemplate::plainTextToLatex($data['ApprovalDesc_1']);
    $data['ApprovalDesc_2']= LatexTemplate::plainTextToLatex($data['ApprovalDesc_2']);

//    error_log($data['RevisionDesc_1']);
//    error_log($data['RevisionDesc_2']);
//    exit;

    list($data['Description_1'], $data['Description_2']) = highlightDifferencesLatex($data['Description_1'], $data['Description_2']);
    list($data['Credits_1'], $data['Credits_2']) = highlightDifferencesLatex($data['Credits_1'], $data['Credits_2']);
    list($data['Requirement_1'], $data['Requirement_2']) = highlightDifferencesLatex($data['Requirement_1'], $data['Requirement_2']);
    list($data['Pre_requisites_1'], $data['Pre_requisites_2']) = highlightDifferencesLatex($data['Pre_requisites_1'], $data['Pre_requisites_2']);
    list($data['Co_requisites_1'], $data['Co_requisites_2']) = highlightDifferencesLatex($data['Co_requisites_1'], $data['Co_requisites_2']);
    list($data['Required_Texts_1'], $data['Required_Texts_2']) = highlightDifferencesLatex($data['Required_Texts_1'], $data['Required_Texts_2']);
    list($data['Reference_Texts_1'], $data['Reference_Texts_2']) = highlightDifferencesLatex($data['Reference_Texts_1'], $data['Reference_Texts_2']);
    list($data['Coordinator_1'], $data['Coordinator_2']) = highlightDifferencesLatex($data['Coordinator_1'], $data['Coordinator_2']);
    list($data['ObjectivesHeadline_1'], $data['ObjectivesHeadline_2']) = highlightDifferencesLatex($data['ObjectivesHeadline_1'], $data['ObjectivesHeadline_2']);
    list($data['Objectives_1'], $data['Objectives_2']) = highlightDifferencesLatex($data['Objectives_1'], $data['Objectives_2']);
    list($data['TopicsCoveredHeadline_1'], $data['TopicsCoveredHeadline_2']) = highlightDifferencesLatex($data['TopicsCoveredHeadline_1'], $data['TopicsCoveredHeadline_2']);
    list($data['TopicsCovered_1'], $data['TopicsCovered_2']) = highlightDifferencesLatex($data['TopicsCovered_1'], $data['TopicsCovered_2']);


    $data['Pre_requisites_1'] = convertTextLatexList($data['Pre_requisites_1'], 'itemize');
    $data['Pre_requisites_2'] = convertTextLatexList($data['Pre_requisites_2'], 'itemize');
    $data['Required_Texts_1'] = convertTextLatexList($data['Required_Texts_1'], 'itemize');
    $data['Required_Texts_2'] = convertTextLatexList($data['Required_Texts_2'], 'itemize');
    $data['Reference_Texts_1'] = convertTextLatexList($data['Reference_Texts_1'], 'itemize');
    $data['Reference_Texts_2'] = convertTextLatexList($data['Reference_Texts_2'], 'itemize');
    $data['Objectives_1'] = convertTextLatexList($data['Objectives_1'], 'itemize');
    $data['Objectives_2'] = convertTextLatexList($data['Objectives_2'], 'itemize');
    $data['TopicsCovered_1'] = convertToLatexNestedList($data['TopicsCovered_1']);
    $data['TopicsCovered_2'] = convertToLatexNestedList($data['TopicsCovered_2']);

//    $data['Required_Texts_1'] = convertTextToLatexUrl($data['Required_Texts_1']);
//    $data['Required_Texts_1'] = convertTextToLatexUrl($data['Required_Texts_1']);
//    $data['Reference_Texts_1'] = convertTextToLatexUrl($data['Reference_Texts_1']);
//    $data['Reference_Texts_2'] = convertTextToLatexUrl($data['Reference_Texts_2']);

//    print_r($data);exit;

    LatexTemplate::createLatex($data, 'create_abetsyllabus_diff_pdf.tex', $AbetSyllabusPDF_FileName, 0/*0:screen / 1:download*/);

} catch(Exception $e) {
//    require_once 'php_include/mail_attachment.php';
//    NotifyAdminByEmail('Error: Create ABET Syllabus PDF', $e -> getMessage());
//
//    error_log($e -> getMessage());
    echo $e -> getMessage();
    echo ('0x23894723');    // Error
    exit;
}


