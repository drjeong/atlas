<?php
/**
 * Create Multiple Course Binder PDFs and ZIP them
 * Description: Creates binder PDFs for multiple courses and returns them as a ZIP file
 *
 * Requires: create_coursebinder_pdf.php logic
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';
require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/php_include/listfunc.php');
require_once(__DIR__ . '/php_include/LatexTemplate.php');
require_once(__DIR__ . '/php_include/dbconnection_class.php');

// Get courses data from POST
$coursesJson = $_POST['courses'] ?? '';

if (empty($coursesJson)) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No courses provided']);
    exit;
}

$courses = json_decode($coursesJson, true);

if (!is_array($courses) || count($courses) === 0) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid courses data']);
    exit;
}

$DBCONNECTION = new Dbconnection();

// Create temporary directory for PDFs
$tempDir = sys_get_temp_dir() . '/course_binders_' . uniqid();
if (!mkdir($tempDir, 0777, true)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Failed to create temporary directory']);
    exit;
}

$successCount = 0;
$errorCount = 0;
$errorDetails = [];

// Generate each PDF
foreach ($courses as $course) {
    try {
        $AvailableCourseIdx = $course['AVCourseIdx'] ?? '';
        $AcademicYear = $course['AcademicYearInfo'] ?? '';

        if (!$AvailableCourseIdx || !$AcademicYear) {
            throw new Exception('Missing required course parameters');
        }

        // Set up paths
        $ASSESSMENT_PDF_PATH = __DIRECTORY_ABETASSESSMENTS__ . "$AcademicYear" . DIRECTORY_SEPARATOR;
        $ABETSYLLABUS_PDF_PATH = __DIRECTORY_ABETSYLLABI__ . "$AcademicYear" . DIRECTORY_SEPARATOR;
        $COURSESYLLABUS_PDF_PATH = __DIRECTORY_COURSEBI__ . "$AcademicYear" . DIRECTORY_SEPARATOR;
        $INSTRUCTIONAL_MATERIALS_PDF_PATH = __DIRECTORY_INSTRUCTIONAL_MATERIALS__ . "$AcademicYear" . DIRECTORY_SEPARATOR;
        $COURSEASSESSMENT_SAMPLES_PDF_PATH = __DIRECTORY_COURSEASSIGNMENT_SAMPLES__ . "$AcademicYear" . DIRECTORY_SEPARATOR;
        $COURSEBINDER_PDF_PATH = __DIRECTORY_COURSEBINDERS__ . "$AcademicYear" . DIRECTORY_SEPARATOR;
        $UNIV_LOGO_PATH = __UNIV_LOGO_PATH__;

        // Fetch Course Info
        $Query = "CALL SP_CreatePDF_FetchAvailableCourseInfo(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx]);

        if (!$result || $DBCONNECTION->num_rows() === 0) {
            throw new Exception('No course data found');
        }

        $row = $DBCONNECTION->fetch_assoc();

        $Semester = $row['Semester'] ?? '';
        $CourseCRN = $row['CRN'] ?? '';
        $CourseSubject = $row['Subject'] ?? '';
        $CourseNum = $row['Num'] ?? '';
        $CourseTitle = $row['Title'] ?? '';
        $CourseCredits = $row['Credits'] ?? '';
        $InstructorName = $row['Instructor'] ?? '';
        $Degree = $row['Degree'] ?? '';
        $BinderUpdated = ($row['BinderUpdated'] == '1') ? true : false;

        // Build filenames
        $lowercase_values = [
            'degree' => strtolower($Degree),
            'subject' => strtolower($CourseSubject),
            'num' => strtolower($CourseNum),
            'semester' => strtolower($Semester)
        ];

        $filename_parts = [
            'semester' => str_replace(' ', '_', $lowercase_values['semester']),
            'subject' => str_replace(' ', '_', $lowercase_values['subject']),
            'num' => str_replace(' ', '_', $lowercase_values['num']),
            'crn' => 'crn' . str_replace(' ', '_', $CourseCRN)
        ];

        $base_filename = implode('_', $filename_parts);
        $CourseBinderPDF_FileName = "coursebinder_{$base_filename}.pdf";
        $CourseSyllabusPDF_FileName = "syllabus_{$base_filename}.pdf";

        $abet_filename_parts = [
            str_replace(' ', '-', $AcademicYear),
            str_replace(' ', '_', $lowercase_values['degree']),
            str_replace(' ', '_', $lowercase_values['subject']),
            str_replace(' ', '_', $lowercase_values['num'])
        ];
        $AbetSyllabusPDF_FileName = 'abet_syllabus_' . implode('_', $abet_filename_parts) . '.pdf';

        $course_title = trim(sprintf('%s %s %s', $CourseSubject, $CourseNum, $CourseTitle));

        // Check if already exists and not updated
        $existingPDF = $COURSEBINDER_PDF_PATH . $CourseBinderPDF_FileName;
        if (!$BinderUpdated && file_exists($existingPDF)) {
            // Copy existing PDF to temp directory
            if (copy($existingPDF, $tempDir . '/' . $CourseBinderPDF_FileName)) {
                $successCount++;
                continue;
            }
        }

        // Prepare data for PDF generation
        $data = [
            'logo' => $UNIV_LOGO_PATH,
            'assessmentpath' => $ASSESSMENT_PDF_PATH,
            'courseinfo' => $CourseCRN,
            'coursetitle' => LatexTemplate::plainTextToLatex($course_title),
            'coursesemester' => LatexTemplate::replaceSpecialCharacters($Semester),
            'courseCRN' => LatexTemplate::replaceSpecialCharacters($CourseCRN),
            'courseinstructor' => LatexTemplate::plainTextToLatex($InstructorName),
            'coursesyllabus' => $COURSESYLLABUS_PDF_PATH . $CourseSyllabusPDF_FileName,
            'abetcoursesyllabus' => $ABETSYLLABUS_PDF_PATH . $AbetSyllabusPDF_FileName
        ];

        // Fetch Instructional Materials
        $Query = "CALL SP_CreatePDF_FetchAvailableCourseIMs(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx]);

        $InstructionalMaterials = [];
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $materialType = $row['MaterialType'] ?? '';
                if (!isset($InstructionalMaterials[$materialType])) {
                    $InstructionalMaterials[$materialType] = [];
                }
                $materialType = LatexTemplate::replaceSpecialCharacters($materialType);
                $InstructionalMaterials[$materialType][] = [
                    'MaterialType' => $materialType,
                    'MaterialSample' => $INSTRUCTIONAL_MATERIALS_PDF_PATH . $row['MaterialSample']
                ];
            }
            $data['InstructionalMaterials'] = $InstructionalMaterials;
        }

        // Fetch Assessment Materials
        $Query = "CALL SP_CreatePDF_FetchAvailableCourseAMs(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx]);

        $CourseAssessmentMaterials = [];
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $assessmentType = $row['AssmntType'] ?? '';
                if (!isset($CourseAssessmentMaterials[$assessmentType])) {
                    $CourseAssessmentMaterials[$assessmentType] = [];
                }
                $CourseAssessmentMaterials[$assessmentType][] = [
                    'AssmntType' => LatexTemplate::replaceSpecialCharacters($assessmentType),
                    'AssmntNum' => LatexTemplate::replaceSpecialCharacters($row['AssmntNum'] ?? ''),
                    'AssmntSample' => $COURSEASSESSMENT_SAMPLES_PDF_PATH . $row['AssmntSample'],
                    'StudentSample1' => ($row['StudentSample1'] === null) ? '' : ($COURSEASSESSMENT_SAMPLES_PDF_PATH . $row['StudentSample1']),
                    'StudentSample2' => ($row['StudentSample2'] === null) ? '' : ($COURSEASSESSMENT_SAMPLES_PDF_PATH . $row['StudentSample2']),
                    'StudentSample3' => ($row['StudentSample3'] === null) ? '' : ($COURSEASSESSMENT_SAMPLES_PDF_PATH . $row['StudentSample3'])
                ];
            }
            $data['CourseAssessmentMaterials'] = $CourseAssessmentMaterials;
        }

        if (!isset($data['InstructionalMaterials']) || !isset($data['CourseAssessmentMaterials'])) {
            throw new Exception('Missing required materials data');
        }

        // Generate PDF to temp directory
        LatexTemplate::createToCPDF(
            $data,
            'create_coursebinder_pdf.tex',
            $CourseBinderPDF_FileName,
            3, // Mode 3: Save to file without sending output (for batch processing)
            $tempDir . DIRECTORY_SEPARATOR
        );

        // Update database
        $Query = "CALL SP_UpdateCourseBinderCreation(?);";
        $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx]);

        // Also save to permanent location
        if (file_exists($tempDir . DIRECTORY_SEPARATOR . $CourseBinderPDF_FileName)) {
            copy(
                $tempDir . DIRECTORY_SEPARATOR . $CourseBinderPDF_FileName,
                $COURSEBINDER_PDF_PATH . $CourseBinderPDF_FileName
            );
        }

        $successCount++;

    } catch (Exception $e) {
        $errorCount++;
        $courseIdentifier = ($course['Subject'] ?? '') . ' ' . ($course['Num'] ?? '');
        $errorDetails[] = trim($courseIdentifier) . ': ' . $e->getMessage();
        error_log("Error creating binder for course {$courseIdentifier}: " . $e->getMessage());
    }
}

// If no PDFs were created successfully, return error
if ($successCount === 0) {
    // Clean up temp directory
    array_map('unlink', glob("$tempDir/*.*"));
    rmdir($tempDir);

    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'error' => 'Failed to generate any course binders',
        'details' => $errorDetails
    ]);
    exit;
}

// Create ZIP file
$zipFilename = $tempDir . '.zip';
$zip = new ZipArchive();

if ($zip->open($zipFilename, ZipArchive::CREATE) !== TRUE) {
    // Clean up temp directory
    array_map('unlink', glob("$tempDir/*.*"));
    rmdir($tempDir);

    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Failed to create ZIP file']);
    exit;
}

// Add all PDF files to ZIP
$files = glob($tempDir . '/*.pdf');
foreach ($files as $file) {
    $zip->addFile($file, basename($file));
}

$zip->close();

// Send ZIP file to browser
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="course_binders_' . date('Ymd') . '.zip"');
header('Content-Length: ' . filesize($zipFilename));
header('Pragma: no-cache');
header('Expires: 0');

readfile($zipFilename);

// Clean up temporary files
unlink($zipFilename);
array_map('unlink', glob("$tempDir/*.*"));
rmdir($tempDir);

exit;
?>