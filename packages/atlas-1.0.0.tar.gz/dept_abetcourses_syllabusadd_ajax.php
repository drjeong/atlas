<?php
/**
 * Add Abet Course
 * Description: Adding abet course
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$AbetCourseIdx='';
$ABETSyllabusIdx='';
$AcademicYearIdx='';       // index
$AcademicProgramIdx='';
$Subject='';
$Num='';

if (array_key_exists('ay', $_POST) && array_key_exists('sub', $_POST)
    && array_key_exists('num', $_POST) && array_key_exists('ap', $_POST)  && array_key_exists('syllabus', $_POST) )
{
    $AbetCourseIdx = trim($_POST['idx']);
    $AcademicYearIdx = trim($_POST['ay']);
    $AcademicProgramIdx = trim($_POST['ap']);
    $Subject = trim($_POST['sub']);
    $Num = trim($_POST['num']);
    $ABETSyllabusIdx = trim($_POST['syllabus']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

//$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AbetCourseIdx==='' || $AcademicYearIdx==='' || $AcademicProgramIdx==='' || $Subject==='' || $Num==='' || $ABETSyllabusIdx===''){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    $query = "CALL SP_UpdateAbetCourse_Syllabus(?, ?, ?, ?);";
    $params = [$AcademicYearIdx, $AbetCourseIdx, $AcademicProgramIdx, strtolower($Subject.'_'.$Num)];
    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    if ($result && $DBCONNECTION->num_rows() > 0) {
        $row = $DBCONNECTION->fetch_assoc();
        $AbetSyllabusFileName = $row["AbetSyllabus"];   // Master syllabus filename
        $AcademicYearInfo = $row["AcademicYear"]; // 2024-2025

        if ($AbetSyllabusFileName !== null) {
            // ABET Syllabus Creation using Latex
            require_once(__DIR__ . '/../config.php');
            $target_dir = __DIRECTORY_ABETSYLLABI__ . $AcademicYearInfo . DIRECTORY_SEPARATOR;
            $AbetSyllabusFile = $target_dir . basename($AbetSyllabusFileName);

//            error_log($AbetSyllabusFile);
//            if (!file_exists($AbetSyllabusFile))
//            createAbetSyllabusPDF($ABETSyllabusIdx, $AbetSyllabusFile, $AcademicYearIdx, $AcademicProgramIdx);

            require_once __DIR__ . "/php_include/AbetSyllabusPDFCreator.php";
            $creator = new AbetSyllabusPDFCreator($ABETSyllabusIdx, $AbetSyllabusFile, $AcademicYearIdx, $AcademicProgramIdx, 2);
            $creator->createPDF();
        }
    }
    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    error_log($DBCONNECTION->FormatQuery($query, $params));

    echo "0x00000000";
}
