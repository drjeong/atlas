<?php
/**
 * Abet courses
 * Description: Listing abet courses (differnt course numbers) to be shared for multiple degree programs
 * Author: Dong Hyun Jeong
 *
 * 03/12/2026 - initial version created
 */

include('checker_programdirector.php');
include('header.php');
?>

<?php

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection();

?>

    <script src="js/datatable-utils-search.min.js"></script>
    <script src="js/datatable-utils-rowselector.min.js"></script>
    <script src="js/datatable-utils-rowselector-validate-linkedcourses.min.js"></script>


    <script type="text/javascript">
        // Constants
        const ErrorCodes = {
            SUCCESS: '0x11111111',
            REFERENCED1: '0x50004007',   // Primary course already has a Reference value
            REFERENCED2: '0x50004008',   // Primary course is already referenced by other courses
            NO_SO_DATA: '0x00000100',
            NO_PI_DATA: '0x00000200',
            CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010'
        };

        var DataTable_AbetCourseList = null;
        var DataTable_CoursesList = null;
        function LinkAbetCourses()
        {
            const [selectedAcademicYearValue, selectedAcademicYearText] = async_commons.getSelectedAcademicYear();
            if (selectedAcademicYearValue === '') {
                return;
            }
            const formContent =
                `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
                <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                    <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>
                        <input type="hidden" name="_AY" id="_AY" class="input-sm form-control" value="${selectedAcademicYearValue}" readonly>
                        <input type="text" name="_AYTXT" id="_AYTXT" class="input-sm form-control" value="${selectedAcademicYearText}" readonly>
                    </div>
                    <div class="alert alert-info" style="margin: 10px 0; padding: 8px 12px; font-size: 13px;">
                        <i class="glyphicon glyphicon-info-sign"></i>
                        <strong>Note:</strong> When selecting multiple courses, you can designate one as Primary (contains assessments) and others as References.
                    </div>
                    <table id="selectedcouselist" class="display" style="border-spacing:0; padding:0; width:100%;">
                        <thead>
                        <tr>
                            <th class="no-sort" style="width:3px"></th>
                            <th>SEMESTER</th>
                            <th>CRN</th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>PROGRAM NAME</th>
                            <th>INSTRUCTOR(S)</th>
                            <th>STUDENT OUTCOMES</th>
                            <th>PERFORMANCE INDICATORS</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th></th>
                            <th>SEMESTER</th>
                            <th>CRN</th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>PROGRAM NAME</th>
                            <th>INSTRUCTOR(S)</th>
                            <th>STUDENT OUTCOMES</th>
                            <th>PERFORMANCE INDICATORS</th>
                        </tr>
                        </tfoot>
                    </table>
                </div></form>`;

            createModalDialog({
                className: "dialogWidth80p",
                title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">LINK ABET COURSES</span>',
                message: formContent,
                buttons: {
                    ok: {
                        label: "<span class='glyphicon glyphicon-ok'></span> LINK",
                        className: 'btn-success',
                        callback: function(){
                            const popupForm = document.getElementById('popupfrm');

                            let selected = rowSelector.getSelectedData();
                            if (selected.length <= 1) {
                                Swal.fire({title: "ERROR", text: "You need to check more than one course!!", icon: "error"});
                                return false;
                            }

                            // All validations are already done by the row selector
                            showPrimaryReferenceSelection(selected, popupForm._AY.value);
                            return false;
                        }
                    },
                    cancel: {
                        label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                        className: 'btn-default',
                        callback: function(){
                        }
                    }
                }
            }).on('shown.bs.modal',function(){
            });

            // Destroy existing DataTable if it exists
            if ($.fn.DataTable.isDataTable('#selectedcouselist')) {
                $('#selectedcouselist').DataTable().clear().destroy();
            }

            // Generate unique cache buster
            const cacheBuster = new Date().getTime() + '_' + Math.random().toString(36).substring(7);

            let rowSelector; // Declare here to be accessible throughout

            DataTable_CoursesList = $("#selectedcouselist").DataTable({
                processing: true,
                serverSide: true,
                iDisplayLength: 8,
                lengthChange: false,
                select: {
                    style: 'multi',
                    selector: 'td'
                },
                initComplete: function() {
                    // Create row selector after DataTable is initialized
                    rowSelector = new DatatableUtilsRowselectorValidateLinkedCourses('selectedcouselist', {
                        counterId: 'selectedCount',
                        toggleButtonId: 'toggleSelected',
                        itemName: 'course',
                        validationFields: {
                            semester: 'SemesterTxt',
                            studentOutcomes: 'StudentOutcomes',
                            performanceIndicators: 'PerformanceIndicators'
                        }
                    });
                    rowSelector.init(DataTable_CoursesList);
                },
                ajax: {
                    url: `ssps/dept_abetcourses_linkabtcrses_diffnums_list_ssps.php`,
                    type: 'POST',
                    cache: false,
                    data: function(d) {
                        d._AY = selectedAcademicYearValue;
                        d._cacheBuster = cacheBuster;
                        d._timestamp = new Date().getTime();
                        return d;
                    },
                    error: function(xhr, error, thrown) {
                        console.log('Ajax error:', error);
                        console.log('Response:', xhr.responseText);
                        Swal.fire({
                            title: "Error",
                            text: "Failed to load course data. Please check the console for details.",
                            icon: "error"
                        });
                    },
                    dataSrc: function(json) {
                        if (json.error) {
                            Swal.fire({
                                title: "Error",
                                text: json.error,
                                icon: "error"
                            });
                            return [];
                        }
                        return json.data;
                    },
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
                        xhr.setRequestHeader('Pragma', 'no-cache');
                        xhr.setRequestHeader('Expires', '0');
                    }
                },
                order: [[ 1, 'asc' ], [ 2, 'asc' ]],
                fnDrawCallback: function() {
                    $('#selectedcouselist tr td:nth-child(1)').css('text-align', 'center');
                    $('#selectedcouselist tr td:nth-child(2)').css('text-align', 'center');
                    $('#selectedcouselist tr td:nth-child(3)').css('text-align', 'center');
                    $('#selectedcouselist tr td:nth-child(4)').css('text-align', 'center');
                    $('#selectedcouselist tr td:nth-child(5)').css('text-align', 'center');
                    $('#selectedcouselist tr td:nth-child(7)').css('text-align', 'center');

                    $('#selectedcouselist tr td:nth-child(6)').css('width', '120px');
                    $('#selectedcouselist tr td:nth-child(7)').css('width', '20px');
                    $('#selectedcouselist tr td:nth-child(8)').css('width', '90px');
                    $('#selectedcouselist tr td:nth-child(9)').css({'width': '150px', 'font-size': '11px'});
                    $('#selectedcouselist tr td:nth-child(10)').css({'width': '200px', 'font-size': '11px'});

                    if (rowSelector) {
                        rowSelector.updateSelectedCount();
                    }
                },
                columns: [
                    {
                        data: 'DT_RowId',
                        render: function ( data, type, full, meta ) {
                            return '';
                        }
                    },
                    { data: 'SemesterTxt' },
                    { data: 'CRN' },
                    { data: 'Subject' },
                    { data: 'Num' },
                    { data: 'Title' },
                    { data: 'AcademicProgramName' },
                    { data: 'Instructor' },
                    {
                        data: 'StudentOutcomes',
                        render: function(data, type, row) {
                            if (!data || data === '') {
                                return '<span style="color: #999;">N/A</span>';
                            }
                            const outcomes = data.split(',').map(so => so.trim());
                            return outcomes.map(so => `${so}`).join(', ');
                        }
                    },
                    {
                        data: 'PerformanceIndicators',
                        render: function(data, type, row) {
                            if (!data || data === '') {
                                return '<span style="color: #999;">N/A</span>';
                            }
                            const indicators = data.split(',').map(pi => pi.trim());
                            return indicators.map(pi => `${pi}`).join(', ');
                        }
                    }
                ],
                columnDefs: [
                    {
                        orderable: false,
                        className: 'select-checkbox',
                        targets: 0
                    },
                    {
                        targets  : 'no-sort',
                        orderable: false,
                    }
                ]
            });

            new DataTableSearch('#selectedcouselist', DataTable_CoursesList, ShowResetBtn=false);
        }

        function showPrimaryReferenceSelection(selectedCourses, academicYear) {
            // Convert to array - the data has numeric keys (0, 1, 2, etc.)
            let coursesArray = [];

            if (Array.isArray(selectedCourses)) {
                coursesArray = selectedCourses;
            } else if (selectedCourses && typeof selectedCourses === 'object') {
                // Extract numeric keys and build array
                const keys = Object.keys(selectedCourses).filter(key => !isNaN(key));
                coursesArray = keys.map(key => selectedCourses[key]);
            } else {
                console.error('Invalid selectedCourses format:', selectedCourses);
                Swal.fire({
                    title: "ERROR",
                    text: "Invalid course data format",
                    icon: "error"
                });
                return;
            }

            // Validate we have courses
            if (!coursesArray || coursesArray.length === 0) {
                Swal.fire({
                    title: "ERROR",
                    text: "No courses selected",
                    icon: "error"
                });
                return;
            }

            // console.log('Courses array:', coursesArray); // Debug

            // Build the course selection interface
            let courseListHtml = '';

            coursesArray.forEach((course, idx) => {
                const courseKey = `${course.Subject} ${course.Num}`;

                courseListHtml += `
                    <div class="course-option" style="padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; background-color: white;">
                        <div style="display: flex; align-items: center; justify-content: space-between; gap: 15px;">
                            <div style="flex: 1;">
                                <div style="font-weight: bold; font-size: 15px; margin-bottom: 5px;">
                                    ${courseKey} - ${course.Title}
                                </div>
                                <div style="font-size: 13px; color: #666; margin-bottom: 3px;">
                                    <strong>CRN: ${course.CRN}</strong> | ${course.SemesterTxt}
                                </div>
                                <div style="font-size: 12px; color: #888;">
                                    Instructor: ${course.Instructor || 'N/A'}
                                </div>
                            </div>
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <label style="margin: 0; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                                    <input type="radio"
                                           name="course_${idx}_type"
                                           value="primary"
                                           data-course-index="${course.AVCIdx}_${course.ABTIdx}"
                                           data-course-idx="${idx}"
                                           ${idx === 0 ? 'checked' : ''}
                                           style="width: 18px; height: 18px; cursor: pointer;"
                                           class="course-type-radio primary-radio">
                                    <span class="label label-warning" style="font-size: 13px; padding: 6px 12px;">Primary</span>
                                </label>
                                <label style="margin: 0; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                                    <input type="radio"
                                           name="course_${idx}_type"
                                           value="reference"
                                           data-course-index="${course.AVCIdx}_${course.ABTIdx}"
                                           data-course-idx="${idx}"
                                           ${idx !== 0 ? 'checked' : ''}
                                           style="width: 18px; height: 18px; cursor: pointer;"
                                           class="course-type-radio reference-radio">
                                    <span class="label label-info" style="font-size: 13px; padding: 6px 12px;">Reference</span>
                                </label>
                            </div>
                        </div>
                    </div>
                `;
            });

            const content = `
                <form name="primaryReferenceForm" id="primaryReferenceForm">
                    <div style="text-align: left; font-size: 14px;">
                        <p style="margin-bottom: 12px; font-size: 13px;">
                            <i class="glyphicon glyphicon-info-sign text-info"></i>
                            Configure how the selected courses should be added:
                        </p>
                        <p class="text-warning" style="margin-bottom: 15px; font-size: 13px; padding: 10px; background-color: #fcf8e3; border-left: 4px solid #f0ad4e; border-radius: 4px;">
                            <i class="glyphicon glyphicon-exclamation-sign"></i>
                            <strong>Note:</strong> Select <strong>Primary</strong> for the course that will contain assessments (only ONE allowed). Select <strong>Reference</strong> for courses that will reference the primary course.
                        </p>
                        <div id="course-list">
                            ${courseListHtml}
                        </div>
                    </div>
                </form>
            `;

            // Close the first modal
            $('.modal').modal('hide');

            // Small delay to ensure first modal is closed
            setTimeout(function() {
                const modal = createModalDialog({
                    className: "dialogWidth60p",
                    title: '<span class="glyphicon glyphicon-link" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">CONFIGURE PRIMARY & REFERENCE COURSES</span>',
                    message: content,
                    buttons: {
                        ok: {
                            label: "<span class='glyphicon glyphicon-ok'></span> LINK COURSES",
                            className: 'btn-success',
                            callback: function() {
                                // Collect primary courses
                                const primaryCourses = [];
                                document.querySelectorAll('.primary-radio:checked').forEach(radio => {
                                    primaryCourses.push(radio.dataset.courseIndex);
                                });

                                // Collect reference courses
                                const referenceCourses = [];
                                document.querySelectorAll('.reference-radio:checked').forEach(radio => {
                                    referenceCourses.push(radio.dataset.courseIndex);
                                });

                                // Validate that EXACTLY ONE primary is selected
                                if (primaryCourses.length === 0) {
                                    Swal.fire({
                                        title: 'Validation Error',
                                        text: 'You must select exactly one course as Primary.',
                                        icon: 'error',
                                        confirmButtonText: 'OK'
                                    });
                                    return false;
                                }

                                if (primaryCourses.length > 1) {
                                    Swal.fire({
                                        title: 'Validation Error',
                                        text: 'You can only select ONE course as Primary. All other courses must be Reference.',
                                        icon: 'error',
                                        confirmButtonText: 'OK'
                                    });
                                    return false;
                                }

                                // All courses (primary + reference)
                                const allCourses = [...primaryCourses, ...referenceCourses].join('|');
                                const primaryCourse = primaryCourses[0]; // Single primary course
                                const referenceCoursesList = referenceCourses.join('|');

                                // console.log('Primary course:', primaryCourse);
                                // console.log('All courses:', allCourses);
                                // console.log('Reference courses:', referenceCoursesList);

                                // Call the function with primary and reference courses to link them
                                LinkAbetCourses_Perform(academicYear, allCourses, primaryCourse, referenceCoursesList);
                                return true;
                            }
                        },
                        cancel: {
                            label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                            className: 'btn-default',
                            callback: function() {
                                // Re-open the original modal
                                LinkAbetCourses();
                            }
                        }
                    }
                });

                modal.on('shown.bs.modal', function() {
                    // Add event listener to enforce only one primary selection
                    document.querySelectorAll('.primary-radio').forEach(radio => {
                        radio.addEventListener('change', function() {
                            if (this.checked) {
                                // Uncheck all other primary radios
                                document.querySelectorAll('.primary-radio').forEach(otherRadio => {
                                    if (otherRadio !== this && otherRadio.checked) {
                                        // Get the corresponding reference radio
                                        const courseIdx = otherRadio.dataset.courseIdx;
                                        const referenceRadio = document.querySelector(`.reference-radio[data-course-idx="${courseIdx}"]`);
                                        if (referenceRadio) {
                                            referenceRadio.checked = true;
                                        }
                                    }
                                });
                            }
                        });
                    });

                    // Focus on the first radio button
                    $('.course-type-radio:first').focus();
                });
            }, 300);
        }

        async function LinkAbetCourses_Perform(_AY, _ALLCOURSES, _PRIMARYCOURSE, _REFERENCECOURSES) {
            try {
                // Show spinner at the start
                showFullPageSpinner();

                // Validate inputs
                if (!_AY || !_ALLCOURSES || !_PRIMARYCOURSE) {
                    throw new Error('Invalid parameters: Academic Year, Courses, and Primary Course are required');
                }

                // Make API call with all parameters
                const result = await async_commons.makeApiCall('dept_abetcourses_linkabtcrses_diffnums_link_ajax.php', {
                    ay: _AY,
                    crses: _ALLCOURSES,
                    primarycrse: _PRIMARYCOURSE,
                    refcrses: _REFERENCECOURSES || ''  // Empty string if no reference courses
                });

                const code = result.trim();

                // Handle response based on error code
                hideFullPageSpinner();
                switch (code) {
                    case ErrorCodes.SUCCESS: {
                        // Reload data first
                        await async_commons.reloadDataTable();
                        // Then show success message
                        await async_commons.showSuccessMessage('LINKED', 'ABET courses are linked successfully');
                        break;
                    }
                    case ErrorCodes.REFERENCED1: {
                        await async_commons.showErrorMessage('ERROR', 'The Primary course is used as a reference course to others.');
                        LinkAbetCourses(); // Re-open the original modal
                        break;
                    }
                    case ErrorCodes.REFERENCED2: {
                        await async_commons.showErrorMessage('ERROR', 'The Primary course has been referenced by other courses.');
                        LinkAbetCourses(); // Re-open the original modal
                        break;
                    }
                    default: {
                        throw new Error(`Unexpected server response: ${code}`);
                    }
                }

                return true;

            } catch (error) {
                console.error('Error adding ABET courses:', error);
                await async_commons.handleError(error);
                return false;
            } finally {
                // Always hide spinner
                hideFullPageSpinner();
            }
        }

        async function RemoveLinkedCourses(abtidx, avcidx, ay){
            try {
                const willDelete = await async_commons.showConfirmDialog(
                    `Unliked content cannot be restored!`
                );

                if (!willDelete.value) return;
                const result = await async_commons.makeApiCall('dept_abetcourses_linkabtcrses_diffnums_unlink_ajax.php', {
                    abtidx: abtidx,
                    avcidx: avcidx,
                    ay: ay
                });

                hideFullPageSpinner();
                const code = result.trim();
                switch (code) {
                    case ErrorCodes.SUCCESS: {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('UNLINKED', 'The selected linked courses are unlinked!');
                        break;
                    }
                    default: {
                        throw new Error('Unexpected server response');
                    }
                }
            } catch (error) {
                await async_commons.handleError(error);
            } finally {
                // Always hide spinner
                hideFullPageSpinner();
            }
        }

    </script>

    <script class="init">

        $(document).ready(function() {
            const SelectedAcademicYear = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].value;
            const szURL = 'ssps/dept_abetcourses_linkabtcrses_diffnums_ssps.php?_AY=';

            // Helper function to safely get the academic year text
            function getAcademicYearText() {
                try {
                    if (document.forms["academicyear"]) {
                        return document.forms["academicyear"]["_AY"].options[document.forms["academicyear"]["_AY"].selectedIndex].text;
                    }
                    return '';
                } catch(e) {
                    return '';
                }
            }

            DataTable_AbetCourseList = $("#AbetCourses").DataTable({
                dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
                stateSave: true,
                processing: true,
                serverSide: true,
                lengthMenu: [30, 50, 100, 150, 200, 300, 400],
                ajax: `${szURL}<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>`,
                oLanguage: {
                    sInfoFiltered: ""
                },
                // Default ordering by Semester, CRN, Subject, Number
                order: [[0, "asc"], [1, "asc"], [2, "asc"], [3, "asc"]],
                ordering: false,  // Disable all sorting

                // Column definitions
                columns: [
                    { data: 'Semester', className: 'text-center' },
                    { data: 'CRN', className: 'text-center' },
                    { data: 'Subject', className: 'text-center' },
                    { data: 'Num', className: 'text-center' },
                    { data: 'Title', className: 'text-center' },
                    { data: 'Credits', className: 'text-center' },
                    { data: 'Instructor', className: 'text-center' },
                    { data: 'Requirement', className: 'text-center' },
                    { data: 'Level', className: 'text-center' },
                    { data: 'StudentOutcomes' },
                    {
                        data: 'PIs',
                        render: (data, type, row) => {
                            return row.PIs.split(",")
                                .filter(item => item.includes("-"))
                                .map(item => item.trim())
                                .join(", ");
                        }
                    },
                    { data: 'AcademicProgramName' },
                    {
                        data: 'LinkedCrsAssessment',
                        render: (data, type, row) => {
                            const isPrimary = (data === null || data === 0 || data === '0');
                            let btnClass = isPrimary ? 'btn-warning' : 'btn-info';
                            let icon = isPrimary ? 'glyphicon-star' : 'glyphicon-link';
                            let text = isPrimary ? 'Primary' : 'Reference';
                            let title = isPrimary ? 'This is a Primary course' : `References Primary course ${data}`;

                            return `<span class="btn ${btnClass} btn-xs"
                                title="${title}"
                                style="width: 95px; text-align: center; cursor: default; pointer-events: none;">
                                <span class="glyphicon ${icon}"></span> ${text}
                            </span>`;
                        }
                    },
                    { data: "", className: 'text-center' }
                ],

                // Styling callbacks
                fnInitComplete: function(settings) {
                    const btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                    btnClear.appendTo($('#' + settings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                    btnClear.click(() => $('#' + settings.sTableId).dataTable().fnFilter(''));
                },

                rowCallback: function(row, data, index) {
                    // Create a unique key for grouping based on SEMESTER, CRN, SUBJECT, NUMBER, TITLE
                    const groupKey = `${data.Semester}-${data.CRN}-${data.Subject}-${data.Num}-${data.Title}`;

                    // Store the key as a data attribute on the row
                    $(row).attr('data-group-key', groupKey);
                },

                fnDrawCallback: function() {
                    this.api().state.clear(); // cancel "stateSave" after reload the page

                    // Cell widths (existing code)
                    const cellWidths = {
                        1: '80px',
                        2: '80px',
                        3: '80px'
                    };
                    const minWidths = {
                        4: '150px',
                        5: '80px',
                        6: '80px',
                        7: '80px',
                        8: '80px',
                        9: '80px',
                        10: '80px',
                        11: '150px'
                    };

                    Object.entries(cellWidths).forEach(([col, width]) => {
                        $(`#AbetCourses tr td:nth-child(${col})`).css('width', width);
                    });
                    Object.entries(minWidths).forEach(([col, width]) => {
                        $(`#AbetCourses tr td:nth-child(${col})`).css('min-width', width);
                    });

                    // Apply alternating background colors to groups
                    const groupedRows = {};
                    $('#AbetCourses tbody tr').each(function() {
                        const groupKey = $(this).attr('data-group-key');
                        if (!groupedRows[groupKey]) {
                            groupedRows[groupKey] = [];
                        }
                        groupedRows[groupKey].push(this);
                    });

                    // Define color palette for groups
                    const colors = [
                        '#f0f8ff', // Alice blue
                        '#fff5ee', // Seashell
                        '#f0fff0', // Honeydew
                        '#fffacd', // Lemon chiffon
                        '#ffe4e1', // Misty rose
                        '#f0ffff', // Azure
                        '#fff0f5', // Lavender blush
                        '#f5f5dc'  // Beige
                    ];

                    let colorIndex = 0;
                    Object.keys(groupedRows).forEach(groupKey => {
                        const rows = groupedRows[groupKey];
                        if (rows.length > 1) {
                            // Only highlight if there are multiple rows in the group
                            const color = colors[colorIndex % colors.length];
                            rows.forEach(row => {
                                $(row).css('background-color', color);
                            });
                            colorIndex++;
                        }
                    });
                },

                columnDefs: [
                    {
                        targets: '_all',  // Apply to all columns
                        orderable: false
                    },
                    {
                        targets: -1,
                        data: null,
                        orderable: false,
                        defaultContent:`<div style="width:100%;text-align:center;"><button id="remove" class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="min-height: 20px;"></button></div>`
                    }
                ],

                buttons: [
                    {
                        extend: 'pdfHtml5',
                        orientation: 'landscape',
                        title: function() {
                            return `COURSES TO BE SHARED ACROSS PROGRAMS (${getAcademicYearText()})`;
                        },
                        text: '<span class="glyphicon glyphicon-floppy-save"></span> PDF',
                        className: 'btn btn-xs',
                        attr: {
                            style: 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff; margin-left:8px;'
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                        },
                        customize: doc => {
                            // Font size adjustments
                            doc.styles.tableHeader.fontSize = 9;
                            doc.defaultStyle.fontSize = 8;

                            // Set page size to US Letter
                            doc.pageSize = 'LETTER';

                            // Reduce margins to maximize space (in points, 72 points = 1 inch)
                            doc.pageMargins = [20, 20, 20, 20]; // [left, top, right, bottom]

                            // Set column widths
                            doc.content[1].table.widths = ['7%', '5%', '6%', '6%', '11%', '6%', '10%', '10%', '10%', '10%', '10%', '10%'];

                            // Enhanced styling
                            doc.styles.tableHeader.alignment = 'left';
                            doc.styles.tableBodyEven = doc.styles.tableBodyOdd;
                            doc.styles.tableHeader.bold = true;
                        },
                        pageSize: 'LETTER'
                    },
                    {
                        extend: 'excelHtml5',
                        title: function() {
                            return `COURSES TO BE SHARED ACROSS PROGRAMS (${getAcademicYearText()})`;
                        },
                        text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                        className: 'btn btn-xs',
                        attr: {
                            style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff;'
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                        }
                    }
                ]
            });

            // Add event listener to the select element
            $("#_AY").on('change', function() {
                const tmpURL = szURL + this.value;
                DataTable_AbetCourseList.ajax.url(tmpURL).load();
            });

            $('#AbetCourses tbody').on( 'click', '#remove', function () {
                const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
                RemoveLinkedCourses(data.Idx, data.AVCIdx, data.AcademicYear);
            } );

            // Initialize the column search functionality
            if (typeof DataTableSearch !== 'undefined') {
                new DataTableSearch('#AbetCourses', DataTable_AbetCourseList);
            }

            // Set the DataTable in AsyncCommons
            if (typeof async_commons !== 'undefined') {
                async_commons.setDataTable(DataTable_AbetCourseList);
            }

        });

    </script>

    <div class="pagebacklayout">
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">LINK CO-TAUGHT COURSES (MANY TO ONE)</p>

            <p style="margin:0.2in auto 0;text-align:center;max-width:1000px;">
                Only the courses that are marked for assessment and manually linked will be displayed.
                Please use the button "LINK CO-TAUGHT COURSES" to link courses as "Primary" or "Reference". This allows instructors to add assessment measures only to the primary course and automatically copied to the reference course(s).
            </p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:20%; min-width:350px;">
                        <?php echo($AcademicYearSelection);?>
                    </td>
                    <td style="width:5%"></td>
                    <td style="width:75%; text-align: right">
                        <button class="btn btn-danger btn-sm glyphicon glyphicon-list-alt" onclick="LinkAbetCourses();return false;">&nbsp;LINK CO-TAUGHT COURSES</button>
                    </td>
                </tr>
            </table>


            <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
                <table id="AbetCourses" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th style="width:50px">SEMESTER</th>
                        <th>CRN</th>
                        <th>SUBJECT</th>
                        <th>NUMBER</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>INSTRUCTOR</th>
                        <th>REQUIREMENT</th>
                        <th>LEVEL</th>
                        <th>STUDENT OUTCOMES</th>
                        <th>PERFORMANCE INDICATORS</th>
                        <th>PROGRAM NAME</th>
                        <th>PRIMARY / REFERENCE</th>
                        <th class="no-sort">OPERATION</th>
                    </tr>
                    </thead>
                    <thead id="serachbox" class="filters">
                    <tr>
                        <th>SEMESTER</th>
                        <th>CRN</th>
                        <th>SUBJECT</th>
                        <th>NUMBER</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>INSTRUCTOR</th>
                        <th>REQUIREMENT</th>
                        <th>LEVEL</th>
                        <th>STUDENT OUTCOMES</th>
                        <th>PERFORMANCE INDICATORS</th>
                        <th>PROGRAM NAME</th>
                        <th>PRIMARY / REFERENCE</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>SEMESTER</th>
                        <th>CRN</th>
                        <th>SUBJECT</th>
                        <th>NUMBER</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>INSTRUCTOR</th>
                        <th>REQUIREMENT</th>
                        <th>LEVEL</th>
                        <th>STUDENT OUTCOMES</th>
                        <th>PERFORMANCE INDICATORS</th>
                        <th>PROGRAM NAME</th>
                        <th>PRIMARY / REFERENCE</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>
            </div>

            <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
                <tr>
                    <td>
                        <span style="color:red;font-weight:bold;"></span></td>
                    <td style="text-align:right;">
                        <span class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Unlink Courses
                    </td>
                </tr>
            </table>
        </div>
    </div>


<?php include('footer.php');?>