<?php
/**
 * Unlink All Abet Courses
 * Description: Remove primary/reference connections for all courses in a group
 * Author: Dong Hyun Jeong
 *
 * 05/19/2026 - initial version created
 *
 */

include_once 'session_handler.php';

$action = '';
$avcIdx = null;
$abcIdxList = '';

if (array_key_exists('action', $_POST) &&
    array_key_exists('avcIdx', $_POST) &&
    array_key_exists('abcIdxList', $_POST))
{
    $action = trim($_POST['action']);
    $avcIdx = $_POST['avcIdx'];
    $abcIdxList = $_POST['abcIdxList'];
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

// abcIdxList should be a comma-separated string, not an array
if ($action !== 'unlink_all_courses' || $avcIdx === null || empty($abcIdxList)) {
    // no required information or invalid action
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/../config.php');
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate avcIdx
    $avcIdx = filter_var($avcIdx, FILTER_VALIDATE_INT);
    if ($avcIdx === false) {
        throw new Exception('Invalid avcIdx format');
    }

    // abcIdxList is already a comma-separated string from JavaScript
    // Split it and validate each value
    $abcIdxArray = explode(',', $abcIdxList);
    $validatedAbcIdxList = [];

    foreach ($abcIdxArray as $abcIdx) {
        $abcIdx = trim($abcIdx);
        $validated = filter_var($abcIdx, FILTER_VALIDATE_INT);
        if ($validated === false) {
            throw new Exception('Invalid abcIdx format');
        }
        $validatedAbcIdxList[] = $validated;
    }

    // Convert back to comma-separated string for the stored procedure
    $abcIdxString = implode(',', $validatedAbcIdxList);

    // Call stored procedure once with avcIdx and all abcIdx values
    $query = "CALL SP_RemoveLinksInAllAbetCourses(?, ?);";
    $params = [$avcIdx, $abcIdxString];
//     error_log($DBCONNECTION->formatQuery($query, $params));
    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();

    // Check if it's a SIGNAL error with our custom error code
    if (strpos($errorMessage, '0x5000') !== false) {
        // Extract error code from message
        preg_match('/0x[0-9A-Fa-f]+/', $errorMessage, $matches);
        if (!empty($matches)) {
            echo $matches[0];
        } else {
            echo "0x00000500";
        }
    } else {
        echo "0x00000500";  // other DB error
    }

    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'avcIdx' => $avcIdx ?? 'N/A',
        'abcIdxString' => $abcIdxString ?? 'N/A',
        'query' => isset($query) ? $query : 'N/A'
    ]));

    if (isset($query) && isset($params)) {
        error_log($DBCONNECTION->FormatQuery($query, $params));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}