<?php
/**
 * COURSE ASSIGNMENTS
 * Description:Listing course materials for the selected course
 *
 * 09/22/2024 - initial version created
 */

$_ABTCIDX = (isset($_POST['_abtcidx']))?$_POST['_abtcidx']:''; // Abet Course Index
$_AY = (isset($_POST['_ay']))?$_POST['_ay']:'';           // Academic Year Information
$_AP = (isset($_POST['_ap']))?$_POST['_ap']:'';           // Academic Program Idx
$_SEMTXT = (isset($_POST['_semtxt']))?$_POST['_semtxt']:'';   // Semester Information (ex, 2020 Fall)
$_AVCIDX = (isset($_POST['_avcidx']))?$_POST['_avcidx']:'';   // Available Course Index
$_SUB = (isset($_POST['_sub']))?$_POST['_sub']:'';         // Course Subject
$_NUM = (isset($_POST['_num']))?$_POST['_num']:'';         // Course Num
$_TITLE = (isset($_POST['_title']))?$_POST['_title']:'';     // Course Title
$_CREDITS = (isset($_POST['_credits']))?$_POST['_credits']:''; // Course Credits
$_INSTRUCTOR = (isset($_POST['_instructor']))?$_POST['_instructor']:'';         // Course Instructor
$_INSTRUCTOREMAIL = (isset($_POST['_instructoremail']))?$_POST['_instructoremail']:'';         // Course Instructor Email
$_ASST = (isset($_POST['_asst']))?$_POST['_asst']:'';         // Teaching Assistant
$_ENROLLMENT = (isset($_POST['_enrollment']))?$_POST['_enrollment']:''; // # of students in the course
$_SEM = (isset($_POST['_sem']))?$_POST['_sem']:'';         // Available Course Semester Information
$_CRN = (isset($_POST['_crn']))?$_POST['_crn']:'';         // Available Course CRN Information
$_CTROL = (isset($_POST['_ctrol']))?$_POST['_ctrol']:'';         // Control Course Assignments

$instructorEmailNames  = '';

if ($_ABTCIDX === '' && $_AVCIDX === ''){
    // illegal entry
    header('Location: main.php');
    exit;
}

include('header.php');
?>
<script src="js/api_pdfviewer.min.js?v=0.0.1"></script>


<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSE MATERIALS FOR THE FOLLOWING COURSE</span><br/>
                <span class="smallheadline">ACADEMIC YEAR: <?php echo($_AY); ?> (<?php echo($_SEMTXT);?>)<br/>
                <?php echo("$_SUB $_NUM (CRN:$_CRN) $_TITLE"); ?> <br/>
                INSTRUCTOR: <?php echo($_INSTRUCTOR);?>
                <?php if ($_ASST != '') { ?>
                <br>ASSISTANT: <?php echo($_ASST);?>
                <?php } ?>
                </span></p>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a href="asst_crsmaterials.php">BACK TO THE LIST</a>
            </li>
            <li class="nav-item active">
                <a href="#menu2" class="nav-link" data-toggle="tab">Instructional Materials</a>
            </li>
            <li class="nav-item">
                <a href="#menu3" class="nav-link" data-toggle="tab">Course Assignment Materials</a>
            </li>
            <li class="nav-item">
                <a href="#menu7"
                   class="nav-link"
                   id="downloadBtn"
                   onclick="<?php echo "downloadCourseBinderPDF('$_AVCIDX', '$_ABTCIDX', '$_AP', '$_AY', '$_SEMTXT', '$_SUB', '$_NUM', '$_CRN');" ?>return false;">Download Course Binder (PDF)</a>
            </li>
        </ul>

        <div class="tab-content">
            <div id="menu2" class="tab-pane fade in active">
                <h3>Instructional Materials</h3>
                <p><?php include('u_crsmaterials_instmaterials.php');?></p>
            </div>
            <div id="menu3" class="tab-pane fade">
                <h3>Course Assignment Materials</h3>
                <p><?php include('u_crsmaterials_assmnts.php');?></p>
            </div>
        </div>

    </div>
</div>



<?php include('footer.php');?>

