<?php
/**
 * Management of Syllabus of Master Courses
 * Description: managing syllabus information
 * Author: Dong Hyun Jeong
 *
 * 10/07/2024 - initial version created
 *
 */

$TargetSyllabusIndex = null;
$CourseIndex = '';
$Subject = '';
$Title = '';
$Num = '';

if (array_key_exists('cindex', $_POST)
    && array_key_exists('Subject', $_POST)
    && array_key_exists('Title', $_POST)
    && array_key_exists('Num', $_POST) )
{
    $CourseIndex = trim($_POST['cindex']);
    $Subject = trim($_POST['Subject']);
    $Num = trim($_POST['Num']);
    $Title = trim($_POST['Title']);

    if (isset($_POST['targetindex'])) $TargetSyllabusIndex = trim($_POST['targetindex']);

} else {

    // unwanted illegal entry
    header('Location: dept_abetsyllabus.php');
    exit;
}

if ($CourseIndex==""){
    header('Location: dept_abetsyllabus.php');
    exit;
}
include('header.php');

// using convertTextList function
require_once(__DIR__ . '/php_include/listfunc.php');

// fetch academic years
require_once('inc_academicyear_selection.php');
$ListAcademicYears = ListOfAcademicYears();

//--------------------------------- DB PROCESS ------------------------------------------------------
require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

$AllowEditingSyllabus = false;

$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$AcademicProgramIdx]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) {
    $AllowEditingSyllabus = true;
}

if ($_SESSION['ATLAS_LOGIN_SYSADMIN']) {
    $AllowEditingSyllabus = true;
}

//-------------------------------------------------------------------------------------------
// Fetching revision history information
$results = $DBCONNECTION->callStoredProcedure('SP_AbetSyllabus_Edit_FetchInfo',
    [$CourseIndex, $TargetSyllabusIndex, $AcademicProgramIdx]);
//echo ($DBCONNECTION->formatQuery('CALL SP_AbetSyllabus_Edit_FetchInfo(?, ?, ?);', [$CourseIndex, $TargetSyllabusIndex, $AcademicProgramIdx]));

// Check if results are returned
$data = null;
if ($results) {
    // Fetch and display the results
    while ($row = $results->fetch_assoc()) {
        $data = $row;
    }
}

// Syllabus Index
$SyllabusIndex = $data['Idx'];

// Academic Year Period
$AcademicYearFromIdx = $data['AcademicYearFrom'] ?? null;
$AcademicYearToIdx = $data['AcademicYearTo'] ?? null;

$ABET_StudentOutcomeRevisionExist = false;
//-------------------------------------------------------------------------------------------
// Fetching student outcomes information
$results = $DBCONNECTION->callStoredProcedure('SP_AbetSyllabus_FetchSOs',
    [$CourseIndex, $SyllabusIndex, $AcademicYearFromIdx, $AcademicYearToIdx, $AcademicProgramIdx]);
//echo "CALL SP_AbetSyllabus_FetchSOs('$Subject', $Num, $SyllabusIndex, $AcademicYearFromIdx, $AcademicYearToIdx);";

// Check if results are returned
if ($results) {
    // Fetch and display the results
    while ($row = $results->fetch_assoc()) {
        $data['SOs'][] = $row;
        if ($row['Comments'] != '') $ABET_StudentOutcomeRevisionExist = true;
    }
}

if (empty($data['ObjectivesHeadline'])) {
    $data['ObjectivesHeadline'] = 'Students who complete this course should be able to perform the following tasks:';
}

if (empty($data['TopicsCoveredHeadline'])) {
    $data['TopicsCoveredHeadline'] = 'The following topics will be covered:';
}


//-------------------------------------------------------------------------------------------
// Fetching student performance indicators' information
$params = [$CourseIndex, $SyllabusIndex, $AcademicYearFromIdx, $AcademicYearToIdx, $AcademicProgramIdx];
$results = $DBCONNECTION->callStoredProcedure('SP_AbetSyllabus_FetchPIs', $params);
//echo ($DBCONNECTION->formatQuery('CALL SP_AbetSyllabus_FetchPIs(?, ?, ?, ?, ?);', $params));

// Check if results are returned
if ($results) {
    // Fetch and display the results
    while ($row = $results->fetch_assoc()) {
        $data['PIs'][] = $row;
        if ($row['Comments'] != '') $ABET_StudentOutcomeRevisionExist = true;
    }
}

//-------------------------------------------------------------------------------------------
if ($data['major_version']=='') {
    // if revision information does not exist, create the version 1.0 as a new version
    $data['major_version'] = '1';
    $data['minor_version'] = '0';
}
$data['version'] = $data['major_version'] . '.' . $data['minor_version'];

$formatingguidelines = <<<HTML
<p class='text-left'>Four possible options to list items. 
<table width='100%' border='0' cellspacing='20'>
  <tr>
    <td width='25%' valign='top'>
      <h5>Option 1</h5>
      <ul style='list-style-type: none; padding-left: 0;'>
        <li>item 1</li>
        <li>item 2</li>
        <li>item 3</li>
      </ul>
    </td>
    <td width='25%' valign='top'>
      <h5>Option 2</h5>
      <ul style='list-style-type: none; padding-left: 0;'>
        <li>- item 1</li>
        <li>- item 2</li>
        <li>- item 3</li>
      </ul>
    </td>
    <td width='25%' valign='top'>
      <h5>Option 3</h5>
      <ul style='list-style-type: none; padding-left: 0;'>
        <li>a. item 1</li>
        <li>b. item 2</li>
        <li>c. item 3</li>
      </ul>
    </td>
    <td width='25%' valign='top'>
      <h5>Option 4 (nested)</h5>
      <ul style='list-style-type: none; padding-left: 0;'>
        <li>1. item 1
          <ul style='list-style-type: none; padding-left: 0;'>
            <li style='margin-left: 30px;'>a. sub-item1</li>
            <li style='margin-left: 30px;'>b. sub-item2</li>
            <li style='margin-left: 30px;'>c. sub-item3</li>
          </ul>
        </li>
        <li>2. item 2</li>
        <li>3. item 3
          <ul style='list-style-type: none; padding-left: 0;'>
            <li style='margin-left: 30px;'>a. sub-item1</li>
            <li style='margin-left: 30px;'>b. sub-item2</li>
          </ul>
        </li>
      </ul>
    </td>
  </tr>
</table></p>
HTML;

//print_r($data);
?>


<script src="js/datatable-utils-search.min.js"></script>

<script type="text/javascript">

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010'
    };

    function ShowDetail(target)
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_abetsyllabus_edit.php");
        $form.append($(document.createElement('input')).attr('name','targetindex').val(target));
        $form.append($(document.createElement('input')).attr('name','cindex').val("<?php echo ($CourseIndex); ?>"));
        $form.append($(document.createElement('input')).attr('name','Subject').val("<?php echo ($Subject); ?>"));
        $form.append($(document.createElement('input')).attr('name','Title').val("<?php echo ($Title); ?>"));
        $form.append($(document.createElement('input')).attr('name','Num').val("<?php echo ($Num); ?>"));
        $("body").append($form);
        $form.submit();
    }

    function ShowDifference(current, target)
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_abetsyllabus_diff.php");
        $form.append($(document.createElement('input')).attr('name','cindex').val("<?php echo ($CourseIndex); ?>"));
        $form.append($(document.createElement('input')).attr('name','currentindex').val(current));
        $form.append($(document.createElement('input')).attr('name','targetindex').val(target));
        $form.append($(document.createElement('input')).attr('name','Subject').val("<?php echo ($Subject); ?>"));
        $form.append($(document.createElement('input')).attr('name','Title').val("<?php echo ($Title); ?>"));
        $form.append($(document.createElement('input')).attr('name','Num').val("<?php echo ($Num); ?>"));
        $("body").append($form);
        $form.submit();
    }

    async function downloadSyllabus(SyllabusIndex, AcademicProgram='') {
        try {
            const blob = await async_commons.makeApiCall('create_abetsyllabus_pdf.php', {
                _idx: SyllabusIndex,
                _ap: AcademicProgram
            }, true, 'blob');

            if (blob.type === "application/pdf") {
                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);

                let AssessmentPDF_FileName = 'abet_syllabus';
                AssessmentPDF_FileName += '_' + String('<?php echo ($Subject); ?>').toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '_' + String('<?php echo ($Num); ?>').toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '.pdf';

                link.download = AssessmentPDF_FileName;
                link.click();

                // Clean up
                setTimeout(() => {
                    window.URL.revokeObjectURL(link.href);
                }, 100);

                await async_commons.showSuccessMessage('SUCCESS', 'PDF downloaded successfully!');
            } else {
                throw new Error('Invalid file type received');
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
        }
    }

<?php if ($AllowEditingSyllabus===true) { ?>
    function AddRevisionSyllabusInfo(NewMajorVersion, NewMinorVersion)
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_abetsyllabus_revision.php");
        $form.append($(document.createElement('input')).attr('name','cindex').val("<?php echo ($CourseIndex); ?>"));
        $form.append($(document.createElement('input')).attr('name','si').val("<?php echo ($data['Idx']); ?>"));
        $form.append($(document.createElement('input')).attr('name','Subject').val("<?php echo ($Subject); ?>"));
        $form.append($(document.createElement('input')).attr('name','Title').val("<?php echo ($Title); ?>"));
        $form.append($(document.createElement('input')).attr('name','Num').val("<?php echo ($Num); ?>"));
        $form.append($(document.createElement('input')).attr('name','Credits').val("<?php echo ($data['Credits']); ?>"));
        $form.append($(document.createElement('input')).attr('name','OldMajorVersion').val("<?php echo ($data['major_version']); ?>"));
        $form.append($(document.createElement('input')).attr('name','OldMinorVersion').val("<?php echo ($data['minor_version']); ?>"));
        $form.append($(document.createElement('input')).attr('name','NewMajorVersion').val(NewMajorVersion));
        $form.append($(document.createElement('input')).attr('name','NewMinorVersion').val(NewMinorVersion));
        $("body").append($form);
        $form.submit();
    }

    // Function to validate the date format YYYY-MM-DD
    function isValidDate(dateString) {
        // Check if the input matches the format YYYY-MM-DD using a regular expression
        const regex = /^\d{4}-\d{2}-\d{2}$/;
        if (!dateString.match(regex)) return false;

        // Parse the date parts
        const parts = dateString.split("-");
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10);
        const day = parseInt(parts[2], 10);

        // Check the ranges of month and day
        if (month < 1 || month > 12) return false;
        if (day < 1 || day > 31) return false;

        // Handle month-specific day limits (accounting for leap years)
        const monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

        // Adjust for leap years
        if (month === 2) {
            const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
            if (isLeapYear) {
                monthLength[1] = 29;
            }
        }

        return day <= monthLength[month - 1];
    }

    function ValidateItems()
    {
        if (sylalbusfrm.Subject.value.isEmpty() || sylalbusfrm.Num.value.isEmpty())
        { // error
            return false;
        }
        const fields = [
            { element: sylalbusfrm.FromAcademicYears, message: "From Academic Years is not selected!!" },
            { element: sylalbusfrm.Description, message: "Description is not entered!!" },
            { element: sylalbusfrm.Credits, message: "Credits is not entered!!" },
            { element: sylalbusfrm.Requirement, message: "Requirement is not entered!!" },
            { element: sylalbusfrm.Pre_requisites, message: "Pre_requisites is not entered!!" },
            { element: sylalbusfrm.Required_Texts, message: "Required_Texts is not entered!!" },
            { element: sylalbusfrm.Coordinator, message: "Coordinator is not entered!!" },
            { element: sylalbusfrm.Objectives, message: "Objectives is not entered!!" },
            { element: sylalbusfrm.TopicsCovered, message: "TopicsCovered is not entered!!" },
            { element: sylalbusfrm.RevisionDesc, message: "Revision Description is not entered!!" },
            { element: sylalbusfrm.RevisionDate, message: "Revision date is not entered!!" }
        ];

        for (const field of fields) {
            if (field.element.value.trim() === '') {
                field.element.focus();
                Swal.fire({ title: "ERROR", text: field.message, icon: "error" });
                return false;
            }
        }

        // THIS VALIDATION FOR ACADEMIC YEAR RANGE
        const fromYear = sylalbusfrm.FromAcademicYears.value;
        const toYear = sylalbusfrm.ToAcademicYears.value;

        // If both years are selected and TO year is not empty (not "Current")
        if (fromYear && toYear) {
            // Get the text of the selected options to compare the actual years
            const fromYearText = sylalbusfrm.FromAcademicYears.options[sylalbusfrm.FromAcademicYears.selectedIndex].text;
            const toYearText = sylalbusfrm.ToAcademicYears.options[sylalbusfrm.ToAcademicYears.selectedIndex].text;

            // Extract the start year from formats like "2019-2020" or "2026-2027"
            const fromYearNum = parseInt(fromYearText.split('-')[0]);
            const toYearNum = parseInt(toYearText.split('-')[0]);

            if (fromYearNum > toYearNum) {
                sylalbusfrm.ToAcademicYears.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "The 'TO' academic year cannot be earlier than the 'FROM' academic year! Please correct the date range.",
                    icon: "error"
                });
                return false;
            }
        }

        if (!sylalbusfrm.RevisionDate.value.isEmpty()) {
            if (!isValidDate(sylalbusfrm.RevisionDate.value)) {
                sylalbusfrm.RevisionDate.focus();
                Swal.fire({title:"ERROR", text: "Revision date is not valid!!", icon:"error"});
                return false;
            }
        }
        if (!sylalbusfrm.ApprovalDate.value.isEmpty()) {
            if (!isValidDate(sylalbusfrm.ApprovalDate.value)) {
                sylalbusfrm.ApprovalDate.focus();
                Swal.fire({title:"ERROR", text: "Approval date is not valid!!", icon:"error"});
                return false;
            }
        }
        return true;
    }

    async function LinkSyllabus_Perform(selectedAbetSyllabus) {
        try {
            const result = await async_commons.makeApiCall('dept_abetsyllabus_edit_link2another_ajax.php', {
                id: <?php echo($SyllabusIndex);?>,
                as: selectedAbetSyllabus
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.showSuccessMessage_reloadPage('ADDED', 'Syllabus info is linked!', 2000, true);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function UnLinkSyllabus(_SyllabusIdx) {
        try {
            const willUnlink = await async_commons.showConfirmDialog(
                `Do you want to unlink the syllabus?`,
                {
                    title: 'UNLINK?',
                    confirmButtonText: 'Yes, unlink it?'
                }
            );

            if (!willUnlink.value) return;

            const result = await async_commons.makeApiCall('dept_abetsyllabus_unlink_ajax.php', {
                sid: _SyllabusIdx
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.showSuccessMessage_reloadPage('UNLINKED', 'The syllabus has been unlinked!', 2000, true);
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected syllabus cannot be unlinked because it is used already.');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function LinkSyllabus(_Subject, _Num, _Title) {
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                <div class="input-group" style="width:100%">
                    <span class="input-group-addon" style="width:230px;">Target Course: ${_Subject} ${_Num} ${_Title}</span>
                </div>
                <table id="selectedcouselist" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                        <tr>
                            <th style="width:3px"></th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                            <th>PROGRAM</th>
                            <th>SYLLABUS</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                            <th>PROGRAM</th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </form>`;

        let DataTable_CoursesList = null;

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">LINK THIS SYLLABUS TO THE ONE IN OTHER PROGRAM</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> COPY NOW",
                    className: 'btn-success',
                    callback: function() {
                        const popupForm = document.getElementById('popupfrm');
                        let selected = DataTable_CoursesList.rows({ selected: true }).data();

                        if (!selected.length || selected.length>1) {
                            Swal.fire({
                                title: "ERROR",
                                text: "You need to select a course!!",
                                icon: "error"
                            });
                            return false;
                        }

                        const selectedAbetSyllabus = selected.map(course => course.Idx).join('|');
                        LinkSyllabus_Perform(selectedAbetSyllabus);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function() {}
                }
            }
        }).on('shown.bs.modal', function() {
        }).find('.modal-dialog').css({
            'margin-top': function() {
                let w = $(window).height();
                let b = $(this).height();
                let h = (w - b) * 0.1;
                return h + "px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"
        }).find('.modal-header').css({
            'cursor': 'move'
        });

        DataTable_CoursesList = $("#selectedcouselist").DataTable({
            processing: true,
            serverSide: false,
            iDisplayLength: 8,
            lengthChange: false,
            select: true,
            "sDom": 'tip', // invisible search box & show pagination tabs & show selected entries
            ajax: `ssps/dept_abetsyllabus_edit_courselist_ssps.php?sub=${_Subject}&num=${_Num}`,
            order: [[1, 'asc'], [2, 'asc']],
            fnDrawCallback: function() {
                $('#selectedcouselist tr td:nth-child(1)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(2)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(3)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(4)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(5)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(6)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(7)').css('text-align', 'center');

                $('#selectedcouselist tr td:nth-child(2)').css('width', '40px');
                $('#selectedcouselist tr td:nth-child(3)').css('width', '30px');
                $('#selectedcouselist tr td:nth-child(4)').css('min-width', '150px');
                $('#selectedcouselist tr td:nth-child(5)').css('width', '30px');
                $('#selectedcouselist tr td:nth-child(6)').css('width', '30px');
                $('#selectedcouselist tr td:nth-child(7)').css('width', '30px');
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function(data, type, full, meta) {
                        return '';
                    }
                },
                { data: 'Subject' },
                { data: 'Num' },
                { data: 'Title' },
                { data: 'Credits' },
                { data: 'APName' },
                { data: 'ABSIdx',
                    render: function ( data, type, full, meta ) {
                        let content = '';
                        if (full.ABSIdx !== null && full.RevisionDate !== null) {
                            content += '<button id="downloadpdf" alt="Download Syllabus" title="Download Syllabus" class="btn btn-success btn-xs glyphicon glyphicon-floppy-save" style="min-height: 20px;"></button>';
                        }
                        return content;
                    }
                }
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets: 'no-sort',
                    orderable: false,
                },
                {
                    // prevent selection when clicking PDF button
                    targets: 6,
                    className: 'no-select'
                }
            ]
        });


        $('#selectedcouselist tbody').on( 'click', '#downloadpdf', function () {
            const data = DataTable_CoursesList.row( $(this).parents('tr') ).data();
            downloadSyllabus(data.ABSIdx, data.APIdx);
            return false; // disable row selection action
        } );


        // Initialize the column search functionality
        new DataTableSearch('#selectedcouselist', DataTable_CoursesList, false);
    }

    function RevisePreviousVersion()
    {
        Swal.fire({
            title: 'Updating Old Version?',
            text: "You are about to change the old version. Do you want to proceed?.",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, update it!'
        }).then((result) => {
            if (result.isConfirmed) {
                SaveChanges();
            }
        })
    }

    async function SaveChanges()
    {
        if (ValidateItems()===false) return;

        // Show the full page spinner
        showFullPageSpinner();

        const form = document.getElementById('sylalbusfrm');
        const formData = new FormData(form);

        try {
            const response = await fetch('dept_abetsyllabus_edit_update_ajax.php', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.text();
            const trimmedData = data.trim();
            const [error_code, message] = trimmedData.split(':').map(item => item.trim());

            // Hide spinner
            hideFullPageSpinner();

            switch(error_code)
            {
                case "0x11111111": {
                    await Swal.fire({
                        title: "UPDATED",
                        text: "The Syllabus Info has been updated!",
                        icon: "success",
                        timer: 2000
                    });

                    // Reload the current page content without redirecting
                    await reloadCurrentPage();
                    break;
                }
                case "0x11111110":
                    await Swal.fire({
                        title: "UPDATED, BUT...",
                        text: "The Syllabus Info has been updated! But, the content ("+message+") has unwanted characters. Please change it!!",
                        icon: "error"
                    });
                    break;
                default:{
                    await Swal.fire({
                        title:"ERROR",
                        text: "Unexpected error found. Please contact the system administrator!",
                        icon:"error"
                    });
                    break;
                }
            }
        } catch (error) {
            hideFullPageSpinner();
            await Swal.fire({
                title: "ERROR",
                text: "Failed to save changes: " + error.message,
                icon: "error"
            });
        }
    }

    async function reloadCurrentPage() {
        try {
            // Create form data to reload the current page
            const formData = new FormData();
            formData.append('cindex', '<?php echo($CourseIndex); ?>');
            formData.append('Subject', '<?php echo($Subject); ?>');
            formData.append('Title', '<?php echo($Title); ?>');
            formData.append('Num', '<?php echo($Num); ?>');
            formData.append('targetindex', '<?php echo($TargetSyllabusIndex); ?>');

            const response = await fetch(window.location.href, {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error('Failed to reload content');
            }

            const html = await response.text();

            // Parse the HTML and extract the main content
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');

            // Replace the main content area
            const newContent = doc.querySelector('.pagebacklayout');
            const currentContent = document.querySelector('.pagebacklayout');

            if (newContent && currentContent) {
                currentContent.innerHTML = newContent.innerHTML;

                // Re-initialize tooltips
                $('[data-toggle="tooltip-help"]').tooltip({
                    template: '<div class="tooltip" style="background-color: darkslategray !important; min-width: 500px; z-index: 99 !important; margin-left: 200px;">' +
                        '<div class="tooltip-arrow"></div>' +
                        '<div class="tooltip-head" style="color: white !important; display: flex; justify-content: space-between; padding: 5px;">' +
                        '<h5>&nbsp;<span class="glyphicon glyphicon-info-sign"></span> Formatting Guideline</h5>' +
                        '<button type="button" class="close" style="color: white !important; opacity: 1; padding: 0 10px; font-size: 20px; font-weight: bold; border: none; background: none; cursor: pointer;">&times;</button>' +
                        '</div>' +
                        '<div class="tooltip-inner" style="margin: 5px; min-width: 500px; background-color: white !important; color: black !important;"></div>' +
                        '</div>',
                    html: true
                });

                // Re-attach tooltip close handler
                $(document).on('click', '.tooltip .close', function(e) {
                    $('[data-toggle="tooltip-help"]').tooltip('hide');
                });

                <?php if ($AllowEditingSyllabus===false) { ?>
                preventEditing('input, textarea, select');
                <?php } ?>
            }
        } catch (error) {
            console.error('Error reloading content:', error);
            // Show error message
            await Swal.fire({
                title: "WARNING",
                text: "Content may not have refreshed properly. Please refresh the page manually if needed.",
                icon: "warning"
            });
        }
    }
    <?php } ?>

    <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
    async function UpdateVersion() {
        const majorVersion = document.getElementById('major_version').value.trim();
        const minorVersion = document.getElementById('minor_version').value.trim();

        // Validation
        if (majorVersion === '' || minorVersion === '') {
            Swal.fire({
                title: "ERROR",
                text: "Both major and minor version numbers are required!",
                icon: "error"
            });
            return false;
        }

        // Check if they are valid numbers
        if (isNaN(majorVersion) || isNaN(minorVersion)) {
            Swal.fire({
                title: "ERROR",
                text: "Version numbers must be valid integers!",
                icon: "error"
            });
            return false;
        }

        // Check if they are non-negative
        if (parseInt(majorVersion) < 0 || parseInt(minorVersion) < 0) {
            Swal.fire({
                title: "ERROR",
                text: "Version numbers must be non-negative!",
                icon: "error"
            });
            return false;
        }

        // Confirm the change
        const willUpdate = await Swal.fire({
            title: 'Update Version?',
            text: `Change version to ${majorVersion}.${minorVersion}?`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, update it!'
        });

        if (!willUpdate.isConfirmed) return;

        try {
            const result = await async_commons.makeApiCall('dept_abetsyllabus_update_version_ajax.php', {
                syllabus_index: <?php echo($SyllabusIndex); ?>,
                major_version: majorVersion,
                minor_version: minorVersion
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.showSuccessMessage('UPDATED', 'Version has been updated successfully!');
                    // Reload page content without full page reload
                    await reloadPageContent();
                    break;
                }
                default: {
                    throw new Error('Unexpected server response: ' + code);
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function reloadPageContent() {
        // Create form data to reload the current page
        const formData = new FormData();
        formData.append('cindex', '<?php echo($CourseIndex); ?>');
        formData.append('Subject', '<?php echo($Subject); ?>');
        formData.append('Title', '<?php echo($Title); ?>');
        formData.append('Num', '<?php echo($Num); ?>');
        formData.append('targetindex', '<?php echo($TargetSyllabusIndex); ?>');

        try {
            const response = await fetch(window.location.href, {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error('Failed to reload content');
            }

            const html = await response.text();

            // Parse the HTML and extract the main content
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');

            // Replace the main content area (you may need to adjust the selector)
            const newContent = doc.querySelector('.pagebacklayout');
            const currentContent = document.querySelector('.pagebacklayout');

            if (newContent && currentContent) {
                currentContent.innerHTML = newContent.innerHTML;

                // Re-initialize tooltips and other plugins if needed
                $('[data-toggle="tooltip-help"]').tooltip({
                    template: '<div class="tooltip" style="background-color: darkslategray !important; min-width: 500px; z-index: 99 !important; margin-left: 200px;">' +
                        '<div class="tooltip-arrow"></div>' +
                        '<div class="tooltip-head" style="color: white !important; display: flex; justify-content: space-between; padding: 5px;">' +
                        '<h5>&nbsp;<span class="glyphicon glyphicon-info-sign"></span> Formatting Guideline</h5>' +
                        '<button type="button" class="close" style="color: white !important; opacity: 1; padding: 0 10px; font-size: 20px; font-weight: bold; border: none; background: none; cursor: pointer;">&times;</button>' +
                        '</div>' +
                        '<div class="tooltip-inner" style="margin: 5px; min-width: 500px; background-color: white !important; color: black !important;"></div>' +
                        '</div>',
                    html: true
                });
            }
        } catch (error) {
            console.error('Error reloading content:', error);
            // Fallback to full page reload
            location.reload();
        }
    }

    <?php } ?>

</script>
<script class="init">

    $(document).ready(function() {
        $('[data-toggle="tooltip-help"]').tooltip({
            template: '<div class="tooltip" style="background-color: darkslategray !important; min-width: 500px; z-index: 99 !important; margin-left: 200px;">' +
                '<div class="tooltip-arrow"></div>' +
                '<div class="tooltip-head" style="color: white !important; display: flex; justify-content: space-between; padding: 5px;">' +
                '<h5>&nbsp;<span class="glyphicon glyphicon-info-sign"></span> Formatting Guideline</h5>' +
                '<button type="button" class="close" style="color: white !important; opacity: 1; padding: 0 10px; font-size: 20px; font-weight: bold; border: none; background: none; cursor: pointer;">&times;</button>' +
                '</div>' +
                '<div class="tooltip-inner" style="margin: 5px; min-width: 500px; background-color: white !important; color: black !important;"></div>' +
                '</div>',
            html: true
        });

        $(document).on('click', '.tooltip .close', function(e) {
            $('[data-toggle="tooltip-help"]').tooltip('hide');
        });

        <?php if ($AllowEditingSyllabus===false) { ?>
        preventEditing('input, textarea, select');
        <?php } ?>

    });
</script>

<?php
$ReadOnlyIndicatorHTML = ($data['LinkedTo']!==null)?'readonly':null;
$ReadOnlyIndicatorText = ($data['LinkedTo']!==null)?' <span style="color:red;">(readonly)</span>':'*';
?>

<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;">
            <span class="largeheadline">SYLLABUS - <?php echo(strtoupper("$Subject $Num $Title"));?></span>
            <?php if ($data['LinkedTo']!==null) {
                echo <<< HTML
                    <div style="color: red; text-align:center;">LINKED TO: {$data['linked_course_Course']} - {$data['linked_course_AcademicProgramName']}({$data['linked_course_AcademicProgramDegree']}) - Version {$data['linked_course_major_version']}.{$data['linked_course_minor_version']} </div>
HTML;
            }
            ?>

            <?php // DEBUG: echo("CourseIndex: $CourseIndex"); echo ("SyllabusIndex: $SyllabusIndex");?>
        </p>
	</div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
			<td style="width:20%">
                <ul class="nav nav-tabs" style="width:fit-content;">
                    <li class="nav-item">
                        <?php
                        $backUrl = isset($_SESSION['last_list_page']) ? $_SESSION['last_list_page'] : 'dept_abetsyllabus.php';
                        ?>
                        <a href="<?php echo $backUrl; ?>" style="color: white; background-color: #007bff; padding: 8px 15px;">BACK TO THE LIST</a>
                    </li>
                    <li class="nav-item">
                    </li>
                </ul>
            </td>
			<td style="width:80%; text-align:right">

                <?php if ($AllowEditingSyllabus===true) { ?>
                    <?php if ($data['is_latest_version']=='1' || $data['is_latest_version']=='') { ?>
                        <button class="btn btn-danger btn-sm glyphicon glyphicon-floppy-save" onclick="SaveChanges();">&nbsp;SAVE CHANGES</button>
                    <?php } else { ?>
                        <button class="btn btn-danger btn-sm glyphicon glyphicon-floppy-save" onclick="RevisePreviousVersion();">&nbsp;SAVE CHANGES</button>
                    <?php } ?>
                <?php } ?>

                <?php
                if ($AllowEditingSyllabus===true) {
                    if ($data['LinkedTo']!==null) { ?>
                        <button class="btn btn-warning btn-sm glyphicon glyphicon-link" onclick="UnLinkSyllabus('<?php echo($SyllabusIndex);?>')">&nbsp;UNLINK</button>
                        <?php } elseif ($data['LinkedByCount']>0) { ?>
                        <button class="btn btn-warning btn-sm" onclick="" disabled><i class="glyphicon glyphicon-link"></i>&nbsp;LINKED</button>
                        <?php } else { ?>
                        <button class="btn btn-warning btn-sm" onclick="LinkSyllabus('<?php echo($Subject);?>', '<?php echo($Num);?>', '<?php echo($Title);?>')" <?php echo($data['version'] != '1.0' || $data['ApprovalDate']!=null?'disabled':'');?>><i class="glyphicon glyphicon-link"></i>&nbsp;LINK</button>
                <?php }
                } ?>

                <?php if (($AllowEditingSyllabus===true) && ($data['is_latest_version']=='1' || $data['is_latest_version']=='') && ($data['LinkedTo']===null)) { ?>
                <button class="btn btn-danger btn-sm" onclick="AddRevisionSyllabusInfo('<?php echo ((int)$data['major_version'] + 1)?>', '0')" <?php echo($data['ApprovalDate']==null?'disabled':'');?>><i class="glyphicon glyphicon-edit"></i> &nbsp;Create Major Revision</button>&nbsp;
                <button class="btn btn-danger btn-sm" onclick="AddRevisionSyllabusInfo('<?php echo ((int)$data['major_version'])?>', '<?php echo( (int)$data['minor_version'] + 1);?>');" <?php echo($data['ApprovalDate']==null?'disabled':'');?>><i class="glyphicon glyphicon-edit"></i> &nbsp;Create Minor Revision</button>&nbsp;
                <?php } ?>

                <?php if (!empty($data['TopicsCovered'])) { ?>
                <button class="btn btn-success btn-sm" onclick="downloadSyllabus('<?php echo($SyllabusIndex);?>')"><i class="glyphicon glyphicon-floppy-save"></i> &nbsp;Download Syllabus</button>
                <?php } ?>
            </td>
		</tr>
		</table>

		<div class="CSSTable_SSPSLIST">
            <form name="sylalbusfrm" id="sylalbusfrm" method="" onsubmit="return false;" enctype="multipart/form-data">
                <input type="hidden" name="CourseIndex" value="<?php echo($CourseIndex); ?>">
                <input type="hidden" name="CourseTitle" value="<?php echo($Title); ?>">
                <input type="hidden" name="SyllabusIndex" value="<?php echo($SyllabusIndex); ?>">
                <input type="hidden" name="Subject" value="<?php echo($Subject); ?>">
                <input type="hidden" name="Num" value="<?php echo($Num); ?>">
                <input type="hidden" name="MajorVersion" value="<?php echo($data['major_version']); ?>">
                <input type="hidden" name="MinorVersion" value="<?php echo($data['minor_version']); ?>">
                <table style="border-spacing: 0; padding: 0; width: 100%;">
                    <tr>
                        <td>
                            <div class="input-group" style="width:100%;">
                                <span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Current Version<span style="color:red">*</span></span>
                                <?php if (($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) && ($data['LinkedTo'] === null)) { ?>
                                    <input type="text" name="major_version" id="major_version" class="input-sm form-control" value="<?php echo($data['major_version']); ?>" style="width:80px;" placeholder="Major">
                                    <span class="input-group-addon">.</span>
                                    <input type="text" name="minor_version" id="minor_version" class="input-sm form-control" value="<?php echo($data['minor_version']); ?>" style="width:80px;" placeholder="Minor">
                                    <span class="input-group-btn">
                    <button type="button" class="btn btn-primary btn-sm" onclick="UpdateVersion();">
                        <span class="glyphicon glyphicon-refresh"></span> Update Version
                    </button>
                </span>
                                <?php } else { ?>
                                    <input type="text" name="version" id="version" class="input-sm form-control" value="<?php echo($data['version']); ?>" readonly>
                                <?php } ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%;">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Applied Academic Years<span style="color:red">*</span></span>
                                    <div class="input-group" style="width:100%">
                                        <span class="input-group-addon" style="width:230px;">FROM: </span>
                                        <select name="FromAcademicYears" id="FromAcademicYears" class="input-sm form-control">
                                            <?php if ($data['AcademicYearFrom']=='') echo ('<option value="" selected></option>');?>
                                            <?php foreach ($ListAcademicYears as $ayears): ?>
                                            <option value="<?php echo($ayears['Idx']);?>" <?php echo($ayears['Idx']==$data['AcademicYearFrom']?'selected':'');?>><?php echo($ayears['AcademicYear']);?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="input-group" style="width:100%">
                                        <span class="input-group-addon" style="width:230px;">To: </span>
                                        <select name="ToAcademicYears" id="ToAcademicYears" class="input-sm form-control">
                                            <?php if ($data['AcademicYearTo']==null || $data['AcademicYearTo']=='') echo ('<option value="" selected>Current</option>');
                                            else echo ('<option value="">Current</option>');
                                            ?>
                                            <?php foreach ($ListAcademicYears as $ayears): ?>
                                                <option value="<?php echo($ayears['Idx']);?>" <?php echo($ayears['Idx']==$data['AcademicYearTo']?'selected':'');?>><?php echo($ayears['AcademicYear']);?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;"><span class="input-group-addon" style="color: black; background-color:#efbd47;">Catalog Description<span style="color:red"><?php echo($ReadOnlyIndicatorText); ?></span></span></div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <textarea id="Description" name="Description" class="input-sm form-control" style="min-height: 100px;" <?php echo($ReadOnlyIndicatorHTML); ?>><?php echo($data['Description']); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;"><span class="input-group-addon" style="color: black; background-color:#efbd47;">Credits<span style="color:red"><?php echo($ReadOnlyIndicatorText); ?></span></span></div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <input type="text" name="Credits" id="Credits" class="input-sm form-control" value="<?php echo($data['Credits']); ?>" <?php echo($ReadOnlyIndicatorHTML); ?>>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;">
                                    <span class="input-group-addon" style="color: black; background-color:#efbd47;">Requirement<span style="color:red">*</span>
                                    <span class="glyphicon glyphicon-question-sign"
                                          style="margin-left: 5px; cursor: pointer;"
                                          data-toggle="tooltip-help"
                                          data-placement="bottom"
                                          data-width="100%"
                                          data-html="true"
                                          data-container="body"
                                          data-title="<p class='text-left'>Core / Elective / or else</p>"></span></span>
                                </div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <input type="text" name="Requirement" id="Requirement" class="input-sm form-control" value="<?php echo($data['Requirement']); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;"><span class="input-group-addon" style="color: black; background-color:#efbd47;">Pre-requisites<span style="color:red"><?php echo($ReadOnlyIndicatorText); ?></span></span></div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <textarea id="Pre_requisites" name="Pre_requisites" class="input-sm form-control" style="min-height: 60px;" <?php echo($ReadOnlyIndicatorHTML); ?>><?php echo(convertTextList($data['Pre_requisites'])); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;"><span class="input-group-addon" style="color: black; background-color:#efbd47;">Co-requisites<span style="color:red"></span></span></div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <input type="text" name="Co_requisites" id="Co_requisites" class="input-sm form-control" value="<?php echo($data['Co_requisites']); ?>" <?php echo($ReadOnlyIndicatorHTML); ?>>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;"><span class="input-group-addon" style="color: black; background-color:#efbd47;">Required Texts<span style="color:red"><?php echo($ReadOnlyIndicatorText); ?></span></span></div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <textarea id="Required_Texts" name="Required_Texts" class="input-sm form-control" style="min-height: 60px;" <?php echo($ReadOnlyIndicatorHTML); ?>><?php echo(convertTextList($data['Required_Texts'])); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;"><span class="input-group-addon" style="color: black; background-color:#efbd47;">Reference Texts<span style="color:red"></span></span></div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <textarea id="ReferenceTexts" name="ReferenceTexts" class="input-sm form-control" style="min-height: 60px;" <?php echo($ReadOnlyIndicatorHTML); ?>><?php echo(convertTextList($data['Reference_Texts'])); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;"><span class="input-group-addon" style="color: black; background-color:#efbd47;">Coordinator<span style="color:red"><?php echo($ReadOnlyIndicatorText); ?></span></span></div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <input type="text" name="Coordinator" id="Coordinator" class="input-sm form-control" value="<?php echo($data['Coordinator']); ?>" <?php echo($ReadOnlyIndicatorHTML); ?>>
                                </div>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;">
                                <span class="input-group-addon" style="color: black; background-color:#efbd47;">
                                    Objectives<span style="color:red"><?php echo($ReadOnlyIndicatorText); ?></span>
                                    <span class="glyphicon glyphicon-question-sign"
                                          style="margin-left: 5px; cursor: pointer;"
                                          data-toggle="tooltip-help"
                                          data-placement="bottom"
                                          data-width="100%"
                                          data-html="true"
                                          data-container="body"
                                          data-title="<?php echo ($formatingguidelines); ?>"></span>
                                </div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <textarea id="ObjectivesHeadline" name="ObjectivesHeadline" class="input-sm form-control" style="min-height: 50px;" <?php echo($ReadOnlyIndicatorHTML); ?>><?php echo($data['ObjectivesHeadline']); ?></textarea>
                                    <textarea id="Objectives" name="Objectives" class="input-sm form-control" style="min-height: 250px;" <?php echo($ReadOnlyIndicatorHTML); ?>><?php echo(convertTextList($data['Objectives'])); ?></textarea>

                                </div>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%; display: flex;">
                                <div class="input-group" style="width:250px;">
                                <span class="input-group-addon" style="color: black; background-color:#efbd47;">
                                    Topics Covered<span style="color:red"><?php echo($ReadOnlyIndicatorText); ?></span>
                                    <span class="glyphicon glyphicon-question-sign"
                                          style="margin-left: 5px; cursor: pointer;"
                                          data-toggle="tooltip-help"
                                          data-placement="bottom"
                                          data-width="100%"
                                          data-html="true"
                                          data-container="body"
                                          data-title="<?php echo ($formatingguidelines); ?>"></span>
                                </div>
                                <div class="input-group" style="flex: 1; width:100%;">
                                    <input type="text" name="TopicsCoveredHeadline" id="TopicsCoveredHeadline" class="input-sm form-control" value="<?php echo($data['TopicsCoveredHeadline']); ?>" <?php echo($ReadOnlyIndicatorHTML); ?>>
                                    <textarea id="TopicsCovered" name="TopicsCovered" class="input-sm form-control" style="min-height: 320px;" <?php echo($ReadOnlyIndicatorHTML); ?>><?php echo(convertTextList($data['TopicsCovered'])); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width: 100%; display: flex; align-items: stretch;">
                                <div style="width: 250px; background-color: #efbd47; color: black; display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 10px; box-sizing: border-box;">
                                    <span style="text-align: center; overflow-wrap: break-word; white-space: normal; font-size: 11pt;">Relationship to Curriculum:</br><span style="color:red">(read only)</span></span></div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;" class="prevent-edit-field">
                                    Meets Educational Objectives through Student Outcomes:
                                    <div>
                                        <?php
                                        if (isset($data['SOs'])) {
                                            foreach ($data['SOs'] as $record) {
                                                echo("- " . $record['SO'] . " " . $record['Description'] . "</br>");
                                            }
                                        }?>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width: 100%; display: flex; align-items: stretch;">
                                <div style="width: 250px; background-color: #efbd47; color: black; display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 10px; box-sizing: border-box;">
                                    <span style="text-align: center; overflow-wrap: break-word; white-space: normal; font-size: 11pt;">
                                        Course Student Outcomes through Performance Indicators (Assessed for Student Outcomes):
                                        <br>
                                        <span style="color: red;">(read only)</span>
                                    </span>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;" class="prevent-edit-field">
                                    Students will be able to:
                                    <div>
                                        <?php
                                        if (isset($data['PIs'])) {
                                            foreach ($data['PIs'] as $record) {
                                                echo ("- " . $record['SO'] . "-" . $record['GPI'] . " ". $record['Description'] . "</br>");
                                            }
                                        }?>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>


                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Revision Description<span style="color:red">*</span></span>
                                    <input type="text" name="RevisionDesc" id="RevisionDesc" class="input-sm form-control" value="<?php if ($data['RevisionDesc']=='') echo ("An initial version is created by Prof. "); else echo($data['RevisionDesc']); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>

                    <?php
                    if ($data['RevisionDate'] == '') $data['RevisionDate'] = date('Y-m-d');;
                    ?>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Revision Date (YYYY-MM-DD)<span style="color:red">*</span></span>
                                    <input type="text" name="RevisionDate" id="RevisionDate" class="input-sm form-control" value="<?php echo($data['RevisionDate']); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Approval Description<span style="color:red"></span></span>
                                    <input type="text" name="ApprovalDesc" id="ApprovalDesc" class="input-sm form-control" value="<?php echo($data['ApprovalDesc']); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Approval Date (YYYY-MM-DD)<span style="color:red"></span></span>
                                    <input type="text" name="ApprovalDate" id="ApprovalDate" class="input-sm form-control" value="<?php echo($data['ApprovalDate']); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>

                </table>

            </form>

		</div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <?php if ($AllowEditingSyllabus===true) { ?>
                        <?php if ($data['is_latest_version']=='1' || $data['is_latest_version']=='') { ?>
                            <button class="btn btn-danger btn-sm glyphicon glyphicon-floppy-save" onclick="SaveChanges();">&nbsp;SAVE CHANGES</button>
                        <?php } else { ?>
                            <button class="btn btn-danger btn-sm glyphicon glyphicon-floppy-save" onclick="RevisePreviousVersion();">&nbsp;SAVE CHANGES</button>
                        <?php } ?>
                    <?php } ?>
                </td>
            </tr>
        </table>


        <?php if ($ABET_StudentOutcomeRevisionExist == true) { ?>
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;">
                <span class="smallheadline">ABET STUDENT OUTCOME REVISION HISTORY </span>
            </p>
        </div>
        <div class="CSSTable_SSPSLIST">
            <table style="border-spacing:0; padding:0; width:100%; ">
                <?php foreach ($data['SOs'] as $record) :
                    if ($record['Comments'] != '') { ?>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div style="width:100%; background-color: white;">
                                <div class="input-group" style="width:100%;">
                                    <span class="input-group-addon" style="width:100px; color: black; background-color:#efbd47; " >
                                        <?php echo($record['SO']); ?>
                                    </span>
                                    <div style="width:100%; font-size: 9pt; padding: 10px; " class="prevent-edit-field">
                                        &nbsp;- <?php echo($record['Comments']); ?>  | <?php echo($record['Approval']); ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php } endforeach; ?>
            </table>
            <table style="border-spacing:0; padding:0; width:100%; ">
                <?php foreach ($data['PIs'] as $record) :
                    if ($record['Comments'] != '') { ?>
                        <tr>
                            <td style="border: 1px solid darkgray;">
                                <div style="width:100%; background-color: white;">
                                    <div class="input-group" style="width:100%;">
                                        <span class="input-group-addon" style="width:100px; color: black; background-color:#efbd47; " >
                                            <?php echo($record['SO']. "-" . $record['GPI']); ?>
                                        </span>
                                        <div style="width:100%; font-size: 9pt; padding: 10px; " class="prevent-edit-field">
                                            &nbsp;- <?php echo($record['Comments']); ?>  | <?php echo($record['Approval']); ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php } endforeach; ?>
            </table>
        </div>
        <?php } ?>

<?php

// Fetching revision history information
$results = $DBCONNECTION->callStoredProcedure('SP_AbetSyllabus_FetchRevisionHistory',
    [$CourseIndex, $AcademicProgramIdx]);

// Check if results are returned
$history_data = null;
if ($results) {
    // Fetch and display the results
    while ($row = $results->fetch_assoc()) {
        $history_data[] = $row;
    }
}
?>
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;">
                <span class="smallheadline">SYLLABUS REVISION HISTORY </span>
            </p>
        </div>
        <div class="CSSTable_SSPSLIST">
            <table style="border-spacing:0; padding:0; width:100%; ">
            <?php if (!empty($history_data)): ?>
            <?php foreach ($history_data as $history_row): ?>
            <tr>
                <td style="border: 1px solid darkgray;">
                    <div style="width:100%; background-color: white;">
                        <div class="input-group" style="width:100%;">
                            <span class="input-group-addon" style="width:100px; color: black; background-color:#efbd47; " >
                                r<?php echo($history_row['major_version'].".".$history_row['minor_version']); ?>
                                <button type="button" title="Show Differences" class="CustomEnableDisableButton" onclick="ShowDifference('<?php echo $SyllabusIndex; ?>', '<?php echo $history_row['Idx']; ?>');" <?php if ($SyllabusIndex == $history_row['Idx']) echo("disabled");?>><i class="glyphicon glyphicon-th-list"></i></button>&nbsp;
                                <button type="button" title="See detail" class="CustomEnableDisableButton" onclick="ShowDetail('<?php echo $history_row['Idx']; ?>');" <?php if ($SyllabusIndex == $history_row['Idx']) echo("disabled");?>><i class="glyphicon glyphicon-search"></i></button>
                            </span>
                            <div style="width:100%; font-size: 9pt; padding: 10px; " class="prevent-edit-field">
                            &nbsp;- <?php echo($history_row['RevisionDesc']); ?>  ( <?php echo($history_row['RevisionDate']); ?> ) | <?php echo($history_row['ApprovalDesc']); ?> ( <?php echo($history_row['ApprovalDate']); ?> )&nbsp;
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
            </table>
        </div>

    </div>
</div>


<?php include('footer.php');?>
