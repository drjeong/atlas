<?php
/**
 * Login checking
 * Description: login processing
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 06/16/2021 - Set default program to $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']
 *
 */


session_start();

if (!isset($_POST['email']) && !isset($_POST['lname'])) // illegal access
{
    include_once ('./php_include/notify_user.php');
	Notify_User_Then_HistoryBack("Error!", "Illegal entry!!", "index.php");
	exit;
}
// username and password sent from the index page
if (array_key_exists('lname', $_POST) && array_key_exists('lname', $_POST) )
{
    $LNAME = trim($_POST['lname']);
    $EMAIL=trim($_POST['email']);
}
else{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

// converting the entered information
include_once ('./php_include/rsa.php');
$EMAIL = trim(DecryptData($EMAIL)); // decrypting with private key by removing white space
$LNAME = trim(DecryptData($LNAME)); // decrypting with private key by removing white space

$Temp_PWD=crypt(gettimeofday(true).$LNAME,'st'); // randomly generate temporary password
$Temp_PWD_Encrypted = hash('sha256', $Temp_PWD);

// connecting to database and compare the hash key
require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

$query = "CALL SP_LoginReset(?, ?, ?);";
$params = [ $EMAIL, $LNAME, $Temp_PWD_Encrypted];
$result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

//$sql ="CALL SP_LoginReset('$EMAIL', '$LNAME', '$Temp_PWD_Encrypted');";
//$DBCONNECTION->sendquery($sql);

$row  = $DBCONNECTION->fetch_assoc();
if ($row["MESSAGE"] == "0x11111111")
{
    include_once ('./php_include/notify_user.php');

    $message = "Dear $EMAIL, <br/><br/> Here is your account information (password reset) for the system (ATLAS: Academic Tracking & Learning Assessment System).<br/> Your temporarily created password:<br/><br/>Password: $Temp_PWD<br/><br/>Since this email was transmitted without encryption, kindly ask you to change your password ASAP. For changing the password, please log-in to the system. The password change menu is located in the right top corner under your name.<br/><br/>Sincerely yours, <br/><br/> System support team";

    NotifyUserByEmail($EMAIL, "Notification: Temporary created password!!", $message);
//    error_log($EMAIL);
//    error_log($message);
}
else
{
    include_once ('./php_include/notify_user.php');

    $message = "Dear $EMAIL, <br/><br/> We received a password-reset request for the system (ATLAS: Academic Tracking & Learning Assessment System). But, we cannot process it due to the incorrectly entered name. Please contact the system administrator. Also, if you did not make this request, please report to the system administrator. Thank you.<br/><br/>Sincerely yours, <br/><br/> System support team ";

    NotifyUserByEmail($EMAIL, "Notification: Temporary created password!!", $message);
}
echo ("0x11111111");