<?php
/**
 * Abet courses
 * Description: Assign evaluators to the abet courses
 * Author: Dong Hyun Jeong
 *
 * 03/04/2024 - initial version created
 */

include('checker_programdirector.php');
include('header.php');
?>

<?php

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}
// determine if the user has access control privilege to the selected program.
$AccessControl = false;
if ($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']])
    $AccessControl = true;
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true)
    $AccessControl = true;

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection();

//include('./php_include/dbfunctions.php');
//$AcademicYearOptions = GetAcademicYearOption_in_StudentOutcomes();

//$Duplicate_AbetCourses_AcademicYearOptions_From = GetAcademicYearOption_in_AbetCourses_Exists($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);
//$Duplicate_AbetCourses_AcademicYearOptions_To = GetAcademicYearOption_in_AbetCourses_NotExists($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);


?>

<script src="js/datatable-utils-search.min.js"></script>

<script type="text/javascript">

    var DataTable_AbetCourseEvaluatorsList = null;
    var SelectedAcademicYear = '<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>';
    var DataTable_CoursesList = null;

    //---------------------------------------------------------------------------------------
    function AssignEvaluator()
    {
        let selected = DataTable_AbetCourseEvaluatorsList.rows({ selected: true }).data();
        if (selected.length == 0) {
            Swal.fire({title:"ERROR", text: "Please select abet courses first!", icon:"error"});
            return;
        }

        // create an array for the selected abet courses
        let AbetCourseIdx = '';
        for(let i = 0; i < selected.length; ++i) {
            if (AbetCourseIdx != '') AbetCourseIdx += "|";
            AbetCourseIdx += encodeURIComponent(selected[i].Idx);
        }
        AssignEvaluatorDlg(AbetCourseIdx)
    }

    function AssignEvaluatorDlg(AbetCourseIdx, Evaluators=null)
    {
        let DataTable_EvaluatorList = null;
        const content = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<div class="CSSTable_SSPSLIST" style="min-height:370px;">'
            + '<table id="evaluatorlist" class="display" style="border-spacing:0; padding:0; width:100%;">'
            + '<thead>'
            + '<tr>'
            + ' <th class="no-sort" style="width:3px"></th>'
            + ' <th>NAME</th>'
            + ' <th>POSITION</th>'
            + ' <th>AFFILIATION</th>'
            + '</tr>'
            + '</thead>'
            + '<thead id="serachbox" class="filters">'
            + '<tr>'
            + ' <th></th>'
            + ' <th>NAME</th>'
            + ' <th>POSITION</th>'
            + ' <th>AFFILIATION</th>'
            + '</tr>'
            + '</thead>'
            + '<tfoot>'
            + '<tr>'
            + ' <th></th>'
            + ' <th>NAME</th>'
            + ' <th>POSITION</th>'
            + ' <th>AFFILIATION</th>'
            + '</tr>'
            + '</tfoot>'
            + '</table>'
            + '</div></form>';

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN EVALUATORS</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){
                        const selected_evaluators = DataTable_EvaluatorList.rows({ selected: true }).data();
                        if (selected_evaluators.length === 0) {
                            Swal.fire({title:"ERROR", text: "Please select evaluator first!", icon:"error"});
                            return false;
                        }

                        let selected_evaluators_list = '';
                        for(let i = 0; i < selected_evaluators.length; ++i) {
                            if (selected_evaluators_list !== '') selected_evaluators_list += "|";
                            selected_evaluators_list += encodeURIComponent(selected_evaluators[i].Idx);
                        }

                        AssignEvaluator_Perform(AbetCourseIdx, selected_evaluators_list);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        });


        // Define a custom sorting function to the selected rows
        $.fn.dataTable.ext.order['dom-checkbox'] = function  ( settings, col )
        {
            return this.api().column( col, {order:'index'} ).nodes().map( function ( td, i ) {
                return $(td).closest('tr').hasClass('selected') ? '1' : '0';
            } );
        }

        DataTable_EvaluatorList = $("#evaluatorlist").DataTable({
            "processing": true,
            "serverSide": false,
            "iDisplayLength": 7,
            "lengthChange": false,
            "sDom": 'tip', // invisible search box & show pagination tabs & show selected entries
            "ajax": "ssps/dept_abcevaluators_list_ssps.php",
            "order": [[ 1, 'asc' ]],
            "language": {
                "info": "", // Hide default info
                "infoEmpty": "",
                "infoFiltered": "",
                "select": {
                    "rows": {
                        _: "%d rows selected",
                        0: "",
                        1: "1 row selected"
                    }
                }
            },
            "fnDrawCallback": function() {
                $('#evaluatorlist tr td:nth-child(1)').css('text-align', 'center');
                $('#evaluatorlist tr td:nth-child(2)').css('text-align', 'center');
                $('#evaluatorlist tr td:nth-child(3)').css('text-align', 'center');
            },
            "columns": [
                {
                    "data": 'DT_RowId',
                    "render": function ( data, type, full, meta ) {
                        let rowId = full.Idx; // Get Idx
                        let checked = "";
                        if (Evaluators != null)
                        {
                            let EvaluatorsIdxes = Evaluators.split(",").map(str => parseInt(str.trim(), 10));
                            if (EvaluatorsIdxes.includes(rowId))
                                DataTable_EvaluatorList.row('#'+data).select();
                        }
                        return '';
                    }
                },
                { "data": 'Name' },
                { "data": 'Position' },
                { "data": 'Affiliation' }
            ],
            "columnDefs": [
                {
                    'orderable': false,
                    'className': 'select-checkbox',
                    'targets': 0,
                    'orderDataType': 'dom-checkbox'
                },
                {
                    "targets"  : 'no-sort',
                    "orderable": false,
                }
            ],
            'select': {
                'style': 'multi',
                'info': true  // Keep the select info enabled
            }
        });

        // Apply custom sorting to the selected rows
        DataTable_EvaluatorList.order([0,'desc']).draw();

        // Setup - add a text input to each footer cell
        $('#evaluatorlist #serachbox th').each( function () {
            const title = $(this).text();
            if (title != "") $(this).html( '<input type="text" name="searchbox" placeholder="Search '+title+'" style="color:black; width: 100%;padding:1px;box-sizing: border-box;"/>' );
        } );

        $('#evaluatorlist tfoot th').each( function () {
            const title = $(this).text();
            if (title != "") $(this).html( '<input type="text" placeholder="Search '+title+'" style="color:black; width: 100%;padding:1px;box-sizing: border-box;"/>' );
        } );

        // Apply the search
        DataTable_EvaluatorList.columns().every( function (colIdx) {
            const that = this;
            $(
                'input',
                $('.filters th').eq($(DataTable_EvaluatorList.column(colIdx).header()).index())
            ).on( 'keyup change', function () {
                if ( that.search() !== this.value ) {
                    that.search( this.value )
                        .draw();
                }
            });

            $( 'input', this.footer() ).on( 'keyup change', function () {
                if ( that.search() !== this.value ) {
                    that.search( this.value )
                        .draw();
                }
            });
        } );
    }

    function AssignEvaluator_Perform(AbetCourseIdx, EvaluatorIdx)
    {
        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case"0x11111111": {
                        DataTable_AbetCourseEvaluatorsList.rows({selected: true }).deselect();
                        DataTable_AbetCourseEvaluatorsList.ajax.reload(null, false);
                        Swal.fire({
                            title: "ASSIGNED",
                            text: "Evaluators are assigned!",
                            icon: "success",
                            timer: 2000
                        });
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }

        const param = "evidx="+encodeURIComponent(EvaluatorIdx)+"&abetcrs="+encodeURIComponent(AbetCourseIdx);
        xmlhttp.open("POST", "dept_abcevaluator_assign_ajax.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send(param);
    }

    function UnassignEvaluator(Idx, Semester, Subject, Num, Title, Syllabus)
    {
        Swal.fire({
            title: "UNASSIGN?",
            html: "Unassigned evaluators to the (<span style=\"color:red\">"+Semester+" "+Subject+" "+Num+" "+Title+" </span>) cannot be restored!",
            icon: "question",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, unassign it!"
        }).then(function(result){
            if (result.value)
            {
                let xmlhttp;
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp=new XMLHttpRequest();
                } else { // code for IE6, IE5
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function() {
                    if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                        switch(xmlhttp.responseText.trim())
                        {
                            case"0x11111111": {
                                DataTable_AbetCourseEvaluatorsList.ajax.reload(null, false);

                                Swal.fire({
                                    title: "UNASSIGNED",
                                    text: "The evaluators has been unassigned!",
                                    icon: "success",
                                    timer: 2000
                                }).then(function(){
                                    //location.reload();
                                });

                                break;
                            }
                            default:{
                                Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                                break;
                            }
                        }
                    }
                }
                xmlhttp.open("POST", "dept_abcevaluator_unassign_ajax.php", true);
                xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlhttp.send("abetcrs="+Idx);
            }

        });
    }



</script>

<script class="init">
    $(document).ready(function() {

        const szURL = 'ssps/dept_abcevaluators_ssps.php?_AY=';

        DataTable_AbetCourseEvaluatorsList = $("#AbetCourseEvaluators").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            "stateSave": true,
            "processing": true,
            "serverSide": true,
            'select': {
                'style': 'multi'
            },
            "lengthMenu": [ 30, 50, 100, 150, 200, 300, 400 ],
            "ajax": `${szURL}${SelectedAcademicYear}`,
            "oLanguage": {"sInfoFiltered": ""},
            "order": [[ 3, "asc" ], [ 4, "asc" ], [ 5, "asc" ]], // default sorting
            "columns": [
                {
                    "data": null,
                    "className": "select-checkbox",
                    "defaultContent": "",
                    "orderable": false
                },
                { "data": 'Semester' },
                { "data": 'CRN' },
                { "data": 'Subject' },
                { "data": 'Num' },
                { "data": 'Title' },
                { "data": 'Credits' },
                { "data": 'Level' },
                { "data": 'Instructor' },
                {
                    "data": 'Evaluator_Names',
                    "render": function(data, type, row) {
                        if (type === 'display') {
                            if (!data || data.trim() === '') {
                                return '0';
                            }
                            const names = data.split(',').map(n => n.trim()).filter(n => n !== '');
                            const count = names.length;
                            return `<b>${count}</b> - ${names.join(', ')}`;
                        }
                        return data; // raw data for sorting/filtering
                    }
                },
                {
                    "data": null,
                    "render": function(data, type, row)
                    {
                        return '<div><button id="assignevaluator" alt="Assign Evaluators" title="Assign Evaluators" class="btn btn-danger btn-xs glyphicon glyphicon-user" style="min-height: 20px;"></button>' +
                            '&nbsp;<button id="unassignevaluator" alt="Unassign Evaluators" title="Unassign Evaluators" class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="min-height: 20px;"></button></div>';
                    }

                } // used for representing menu options
            ],
            "fnInitComplete": function(oSettings, json) {
                // Add "Clear Filter" button to Filter
                let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                    $('#' + oSettings.sTableId).dataTable().fnFilter('');
                });

            },
            "fnDrawCallback": function() {
                this.api().state.clear(); // cancel "stateSave" after reload the page

                const table = $('#AbetCourseEvaluators');

                // Center align
                [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].forEach(col => {
                    table.find(`tr td:nth-child(${col})`).css('text-align', 'center');
                });

                // Set vertical align for column 1
                table.find('tr td:nth-child(1)').css('vertical-align', 'bottom');

                // Set min-width for specific columns
                [2, 3, 4, 5, 6, 7, 8, 9, 10, 11].forEach(col => {
                    table.find(`tr td:nth-child(${col})`).css('min-width', '80px');
                });

                // Set width for column 12
                table.find('tr td:nth-child(12)').css('width', '110px');
            },
            'rowCallback': function( row, data, index ){
            },
            "columnDefs": [
                {
                    "targets"  : 'no-sort',
                    "orderable": false,
                }, {
                    "targets": -1,
                    "data": null,
                    "orderable": false,
                    "defaultContent": ""
                }
            ],
            "buttons": [
                {
                    "extend": 'pdfHtml5',
                    "orientation": 'landscape',
                    "title": 'Evaluators for the courses ('+document.forms["changefrm"]["CH_APR"].options[document.forms["changefrm"]["CH_APR"].selectedIndex].text+')',
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> PDF',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff; margin-left:8px;'
                    },
                    "exportOptions": {
                        columns: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
                    },
                    "customize": function(doc) {
                        // Font size adjustments
                        doc.styles.tableHeader.fontSize = 9;
                        doc.defaultStyle.fontSize = 8;

                        // Set page size to US Letter
                        doc.pageSize = 'LETTER';

                        // Reduce margins to maximize space (in points, 72 points = 1 inch)
                        doc.pageMargins = [20, 20, 20, 20]; // [left, top, right, bottom]

                        // Ensure table fits page width
                        doc.content[1].table.widths = Array(doc.content[1].table.body[0].length).fill('*');

                        // Optional: Set specific widths if needed for certain columns
                        doc.content[1].table.widths = ['1%', '12%', '10%', '10%', '10%', '17%', '10%', '10%', '10%', '10%'];

                        // Add some styling to make it more readable
                        doc.styles.tableHeader.alignment = 'left';
                        doc.styles.tableBodyEven = doc.styles.tableBodyOdd;
                    },
                    pageSize: 'LETTER'
                },
                {
                    "extend": 'excelHtml5',
                    "title": 'Evaluators for the courses ('+document.forms["changefrm"]["CH_APR"].options[document.forms["changefrm"]["CH_APR"].selectedIndex].text+')',
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff;'
                    },
                    "exportOptions": {
                        columns: [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
                    }
                }
            ]
        });

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_AbetCourseEvaluatorsList.ajax.url(tmpURL).load();
        });

        // Initialize the column search functionality
        new DataTableSearch('#AbetCourseEvaluators', DataTable_AbetCourseEvaluatorsList);

        // Enable toggle-all button
        $('#AbetCourseEvaluators').on('click', '.toggle-all', function() {
            const table = DataTable_AbetCourseEvaluatorsList;
            const isCurrentlySelected = $(this).closest("tr").hasClass("selected");

            if (!isCurrentlySelected) {
                // Select all rows first
                table.rows({ page: 'current' }).select();

                // Then deselect rows with 'not-selectable' class
                table.rows('.not-selectable')
                    .nodes()
                    .each(node => $(node).removeClass('selected'));
            } else {
                // Deselect all rows
                table.rows().deselect();
            }
        });

        $('#AbetCourseEvaluators').on('click', 'tr', function() {

            if ($(this).hasClass('not-selectable')) {
                // $(this).removeClass('selected');

                Swal.fire({
                    title:"ERROR",
                    text: "The assigned evaluator(s) in the selected course has completed course evaluation. You cannot change or unassign evaluator(s)",
                    icon:"error"}).then(function(result){
                        // Get the nodes of all selected rows
                        let selectedRows = DataTable_AbetCourseEvaluatorsList.rows({selected: true}).nodes();

                        // Iterate through each selected row node
                        selectedRows.each(function (rowNode) {
                            if ($(rowNode).hasClass('not-selectable')) {
                                $(rowNode).removeClass('selected');
                            }
                        });
                });

            } else {
                // Toggle row selection
                $(this).toggleClass('selected');
            }

        });

        $('#AbetCourseEvaluators tbody').on( 'click', '#assignevaluator', function () {
            const data = DataTable_AbetCourseEvaluatorsList.row( $(this).parents('tr') ).data();
            AssignEvaluatorDlg(data.Idx, data.Evaluators);
            return false; // disable row selection action
        } );
        $('#AbetCourseEvaluators tbody').on( 'click', '#unassignevaluator', function () {
            const data = DataTable_AbetCourseEvaluatorsList.row( $(this).parents('tr') ).data();
            UnassignEvaluator(data.Idx, data.Semester, data.Subject, data.Num, data.Title, data.Degree, data.AcademicProgram);

            return false;  // disable row selection action
        } );
    } );
</script>

<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSES TO BE EVALUATED</p>
        <?php include('control_selprogram.php'); ?>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:20%; min-width:350px;">
                    <?php echo($AcademicYearSelection);?>
                </td>
                <td style="width:5%"></td>
                <td style="width:75%; text-align: right">
<?php
if ($AccessControl) { // available only to the people who have access controls to programs
?>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-user" onclick="AssignEvaluator();return false;">&nbsp;ASSIGN EVALUATORS</button>
<?php
}
?>
                </td>
            </tr>
        </table>

        <p style="margin-top:0.2in;text-align:center; color:red;">PLEASE ASSIGN EVALUATORS TO THE COURSES IF YOU WANT THEM TO BE EVALUATED. </p>

        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="AbetCourseEvaluators" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th class="toggle-all" style="width:3px; "></th>
                    <th style="width:50px">SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>LEVEL</th>
                    <th>INSTRUCTOR</th>
                    <th>EVALUATOR</th>
                    <th class="no-sort">OPERATION</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th></th>
                    <th>SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>LEVEL</th>
                    <th>INSTRUCTOR</th>
                    <th>EVALUATOR</th>
                    <th></th>
                </tr>
                </tfoot>
            </table>
        </div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-user" style="pointer-events: none;"></span>: Assign Evaluators
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Unassign Evaluators
                </td>
            </tr>
        </table>
    </div>
</div>

<?php include('footer.php');?>



