<?php
/**
 *
 * List Programs
 * Description: Listing all available programs to control
 * Author: Dong Hyun Jeong
 *
 * 06/30/2021 - initial version created
 */


require_once(__DIR__ . '/php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

$url =  "//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
$escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );
?>

<form name='changefrm' action='<?php echo($escaped_url);?>' method='post'>
    <div class="input-group label-primary" style="background-color:white;">
        <span class="label-default input-group-addon" style="color:white; font-weight: bold;">SELECTED PROGRAM:</span>
        <select name="CH_APR" class="input-sm form-control" style="width:250px" onchange="document.changefrm.submit();">
            <?php
            $Query = "SELECT `Idx`, `Name` FROM `AcademicPrograms` ORDER BY `Name`;";
            $DBCONNECTION->sendquery($Query);
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $AcademicProgramIdx = $row['Idx'];
                $AcademicProgramName = $row['Name'];
                if ($_SESSION['ATLAS_LOGIN_OBSERVER']) {
                    $Selected = '';
                    if ($AcademicProgramIdx == $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'])
                        $Selected = 'selected';

                    if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$AcademicProgramIdx])) {
                        echo("<option value='$AcademicProgramIdx' style='font-size:10pt;' $Selected>". $AcademicProgramName . "</option>");
                    }
                } else {
                    echo ('<option value="'.$AcademicProgramIdx.'" style="font-size:10pt;">'.$AcademicProgramName.'</option>');

                }

            }
            ?>
        </select>
    </div><!-- /input-group -->
</form>

<?php
if( isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] ))
{
    if (empty($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))
    {
        // if no program is selected, select any program based on the user's affiliation information.
        if (!empty($_SESSION['ATLAS_LOGIN_AFFILATION']))
        {
            $AcademicProgramIdx = '';
            $Query = "SELECT `ACDEMICPRMS`.`Idx` FROM `Affiliations` AS `AFFILIATIONS` 
                    INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` 
                        ON (`AFFILIATIONS`.`Idx` = `ACDEMICPRMS`.`Department`) 
                       WHERE  `AFFILIATIONS`.`Idx`=".$_SESSION['ATLAS_LOGIN_AFFILATION']." LIMIT 1;";
            $DBCONNECTION->sendquery($Query);
            if ($row = $DBCONNECTION->fetch_assoc()) {
                $AcademicProgramIdx = $row['Idx'];
            }
            if ($AcademicProgramIdx != '' && $AcademicProgramIdx != null)
            {
                $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = $AcademicProgramIdx;
            }
        }
    }

    if (!empty($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))
    {
        echo <<<HTML
<script>document.changefrm.CH_APR.value = "{$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']}";</script>

HTML;
    }
}
unset($DBCONNECTION);
