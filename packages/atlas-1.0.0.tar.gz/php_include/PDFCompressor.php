<?php

class PDFCompressor {
    private $gs_path = '/usr/bin/gs'; // Path to Ghostscript executable

    function __construct() {
//        require_once ('config.php');
//        $this->gs_path = __GS_PATH__;
    }

    /**
     * Compress and replace the source PDF file
     *
     * @param string $source_path Path to source PDF file
     * @param string $quality Quality level (low, medium, high)
     * @return array Result array with status and metadata
     */
    public function compressAndReplace($source_path, $quality = 'medium') {
        try {
            if (!file_exists($source_path)) {
                throw new Exception("Source file not found: $source_path");
            }

            if (strtolower(pathinfo($source_path, PATHINFO_EXTENSION)) !== 'pdf') {
                throw new Exception("File must be a PDF");
            }

            $temp_output = tempnam(sys_get_temp_dir(), 'compressed_') . '.pdf';

            $quality_settings = [
                'low' => [
                    'dpi' => 72,
                    'settings' => '/screen'
                ],
                'medium' => [
                    'dpi' => 150,
                    'settings' => '/ebook'
                ],
                'high' => [
                    'dpi' => 300,
                    'settings' => '/prepress'
                ]
            ];

            $settings = $quality_settings[$quality] ?? $quality_settings['medium'];

            // Ghostscript command for PDF compression
            $command = sprintf(
                '%s -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=%s ' .
                '-dNOPAUSE -dQUIET -dBATCH -dColorImageResolution=%d ' .
                '-sOutputFile="%s" "%s"',
                $this->gs_path,
                $settings['settings'],
                $settings['dpi'],
                $temp_output,
                $source_path
            );

            // Execute command
            exec($command . ' 2>&1', $output, $return_code);

            if ($return_code !== 0) {
                throw new Exception("Compression failed: " . implode("\n", $output));
            }

            if (!file_exists($temp_output)) {
                throw new Exception("Compressed file was not created");
            }

            $original_size = filesize($source_path);
            $compressed_size = filesize($temp_output);

            // Only replace if compression actually reduced file size
            if ($compressed_size >= $original_size) {
                unlink($temp_output);
                return [
                    'success' => true,
                    'message' => 'File already optimized',
                    'original_size' => $original_size,
                    'compressed_size' => $original_size,
                    'reduction_percent' => 0
                ];
            }

            // Create backup and replace original
            $backup_path = $source_path . '.backup';
            if (!copy($source_path, $backup_path)) {
                throw new Exception("Failed to create backup file");
            }

            if (!rename($temp_output, $source_path)) {
                unlink($backup_path);
                throw new Exception("Failed to replace original file");
            }

            unlink($backup_path);

            return [
                'success' => true,
                'message' => 'File successfully compressed and replaced',
                'original_size' => $original_size,
                'compressed_size' => $compressed_size,
                'reduction_percent' => round((($original_size - $compressed_size) / $original_size) * 100, 2),
                'path' => $source_path
            ];

        } catch (Exception $e) {

            error_log($command);

            if (isset($temp_output) && file_exists($temp_output)) {
                unlink($temp_output);
            }

            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    public function formatSize($bytes) {
        $units = ['B', 'KB', 'MB', 'GB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);
        return round($bytes, 2) . ' ' . $units[$pow];
    }

    // Test if gs is working
    public function testGS() {
        try {
            exec($this->gs_path . ' --version 2>&1', $output, $return_code);
            if ($return_code === 0) {
                return [
                    'success' => true,
                    'version' => $output[0],
                    'path' => $this->gs_path
                ];
            } else {
                return [
                    'success' => false,
                    'error' => 'GS not working: ' . implode("\n", $output)
                ];
            }
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}