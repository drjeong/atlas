<?php
/**
 * Syllabus Viewer
 * Description: Create a PDF syllabus and download it automatically.
 *
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';


$PDF = '';
$PDFTYPE = '';
$AcademicYearInfo = '';
if (isset($_GET['pdf'])) {
    $PDF = trim($_GET['pdf']); // user changed
}
if (isset($_GET['cn'])) {
    $PDFTYPE = trim($_GET['cn']); // code number
}
if (isset($_GET['ayinfo'])) {
    $AcademicYearInfo = trim($_GET['ayinfo']); // academic year information
}

$PDFPATH = '';
if ($PDFTYPE == '293428384') {// abet syllabus
    require_once(__DIR__ . '/../config.php');
    $PDFPATH = __DIRECTORY_ABETSYLLABI__;
}
else if ($PDFTYPE == '253438384'){ // course syllabus
    require_once(__DIR__ . '/../config.php');
    $PDFPATH = __DIRECTORY_COURSEBI__;
}
else if ($PDFTYPE == '213432394'){ // actual assessment sample
    require_once(__DIR__ . '/../config.php');
    $PDFPATH = __DIRECTORY_ABETASSESSMENTS__;
}
else { // error - illegal entry
    include_once ('./php_include/notify_user.php');
    Notify_User_Then_HistoryBack("Login Error!", "Illegal entry!!");
    exit;
}

// The location of the PDF file on the server
$FileNamePath = $PDFPATH. '/' . $AcademicYearInfo . '/' . $PDF;

// Header content type
header('Content-Description: File Transfer');
header("Content-type: application/pdf");
header('Content-Disposition: attachment; filename="'.$PDF.'"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header("Content-Length: " . filesize($FileNamePath));

// Send the file to the browser.
readfile($FileNamePath);


