<?php

if( !isset($_SESSION)) { session_start(); }
if( !isset($_SESSION['ATLAS_LOGIN_USERIDX']) ) exit;

/*
 * Retrieving academic years that have student outcomes
 */
function GetAcademicYearOption_in_StudetOutcome_Exists($ProgramIDX)
{
    $content = "";
    try {
        require_once('dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchAcademicYears_SOExistence_InProgram(?);";
//        echo ($query . $ProgramIDX);
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$ProgramIDX]);

        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $content .= '<option value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
            }
        }
    } catch (mysqli_sql_exception $e) {
        error_log( $e->getMessage() );   // DB error messages from anything else
    } catch (Exception $e) {
        error_log($e->getMessage()); // Error messages from anything else
    }
    return $content;
}

/*
 * Retrieving academic years that does not have student outcomes
 */
function GetAcademicYearOption_in_StudetOutcome_NotExists($ProgramIDX)
{
    $content = "";
    try {
        require_once('dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $Query = "SELECT * FROM `AcademicYears` WHERE `Idx` NOT IN (SELECT DISTINCT `AcademicYear` FROM `StudentOutcomes` AS `STNTOUTCMS` WHERE `STNTOUTCMS`.`AcademicProgram`='$ProgramIDX') ORDER BY `AcademicYear` DESC LIMIT 10;";
        //echo $Query;
        $DBCONNECTION->sendquery($Query);
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $content .= '<option value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
        }
        unset($DBCONNECTION);
    } catch (mysqli_sql_exception $e) {
        error_log( $e->getMessage() );   // DB error messages from anything else
    } catch (Exception $e) {
        error_log($e->getMessage()); // Error messages from anything else
    }
    return $content;
}

/*
 * Retrieving academic years that have student outcomes
 */
function GetAcademicYearOption_in_StudentOutcomes()
{
    $content = "";
    try {
        require_once('dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $Query = "SELECT DISTINCT `AYS`.`Idx`, `AYS`.`AcademicYear` FROM `StudentOutcomes` AS `STNTOUTCMS` INNER JOIN `AcademicYears` AS `AYS` ON (`STNTOUTCMS`.`AcademicYear`=`AYS`.`Idx`) WHERE `STNTOUTCMS`.`AcademicProgram`='".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' ORDER BY `AYS`.`AcademicYear` DESC LIMIT 10;";
        //echo $Query;
        $DBCONNECTION->sendquery($Query);
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $content .= '<option value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
        }
        unset($DBCONNECTION);
    } catch (mysqli_sql_exception $e) {
        error_log( $e->getMessage() );   // DB error messages from anything else
    } catch (Exception $e) {
        error_log($e->getMessage()); // Error messages from anything else
    }
    return $content;
}

/*
 * Retrieving academic years that have assessment information in abet courses
 */
function GetAcademicYearOption_in_AbetCourses_Exists($ProgramIDX)
{
    $content = "";
    try {
        require_once('dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $Query = "SELECT DISTINCT `AY`.`Idx`, `AY`.`AcademicYear` FROM `AbetCourses` AS `ABETCRSES` INNER JOIN `AcademicYears` AS `AY` ON (`ABETCRSES`.`AcademicYear`=`AY`.`Idx`) WHERE `AcademicProgram`='$ProgramIDX' ORDER BY `AY`.`AcademicYear` DESC LIMIT 10;";
        $DBCONNECTION->sendquery($Query);
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $content .= '<option value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
        }
        unset($DBCONNECTION);

    } catch (mysqli_sql_exception $e) {
        error_log( $e->getMessage() );   // DB error messages from anything else
    } catch (Exception $e) {
        error_log($e->getMessage()); // Error messages from anything else
    }
    return $content;
}

/*
 * Retrieving academic years that does not have assessment information in abet courses
 */
function GetAcademicYearOption_in_AbetCourses_NotExists($ProgramIDX)
{
    $content = "";
    try {
        require_once('dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $Query = "SELECT DISTINCT `AY`.`Idx`, `AY`.`AcademicYear` FROM `AbetCourses` AS `ABETCRSES` INNER JOIN `AcademicYears` AS `AY` ON (`ABETCRSES`.`AcademicYear`=`AY`.`Idx`) WHERE `AcademicProgram`='$ProgramIDX' ORDER BY `AY`.`AcademicYear` DESC LIMIT 10;";
        $DBCONNECTION->sendquery($Query);
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $content .= '<option value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
        }
        unset($DBCONNECTION);

    } catch (mysqli_sql_exception $e) {
        error_log( $e->getMessage() );   // DB error messages from anything else
    } catch (Exception $e) {
        error_log($e->getMessage()); // Error messages from anything else
    }
    return $content;
}






//function GetAllAcademicYearOption_in_StudentOutcomes(&$AcademicYear = null)
//{
//    $content = "";
//    require_once('dbconnection_class.php');
//    $DBCONNECTION = new Dbconnection();
//    $Query = '';
//    if ($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] == "")
//        $Query .= "SELECT DISTINCT `AYS`.`Idx`, `AYS`.`AcademicYear` FROM `StudentOutcomes` AS `STNTOUTCMS` INNER JOIN `AcademicYears` AS `AYS` ON (`STNTOUTCMS`.`AcademicYear`=`AYS`.`Idx`) ORDER BY `AYS`.`AcademicYear` DESC";
//    else
//        $Query .= "SELECT DISTINCT `AYS`.`Idx`, `AYS`.`AcademicYear` FROM `StudentOutcomes` AS `STNTOUTCMS` INNER JOIN `AcademicYears` AS `AYS` ON (`STNTOUTCMS`.`AcademicYear`=`AYS`.`Idx`) WHERE `STNTOUTCMS`.`AcademicProgram`= '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' ORDER BY `AYS`.`AcademicYear` DESC";
//    //echo $Query;
//    $DBCONNECTION->sendquery($Query);
//
//    $exist = false; // check if the academic year information exists or not
//    while ($row = $DBCONNECTION->fetch_assoc()) {
//        if ($AcademicYear == $row["Idx"])
//            $exist = true;
//        $content .= '<option value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
//    }
//    if ($exist == false) { // Academic year information does not exist, set the default value as "all".
//        $AcademicYear = 'all';
//    }
//    unset($DBCONNECTION);
//
//    return $content;
//}


//function GetAcademicYearOption_in_GPIs(&$AcademicYear = null)
//{
//    $content = "";
//    require_once('dbconnection_class.php');
//    $DBCONNECTION = new Dbconnection();
//    $Query = "SELECT DISTINCT `AYS`.`Idx`, `AYS`.`AcademicYear` FROM `GeneralPerformanceIndicators` AS `GPIS` INNER JOIN `AcademicYears` AS `AYS` ON (`GPIS`.`AcademicYear`=`AYS`.`Idx`)  WHERE `GPIS`.`AcademicProgram`='".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' ORDER BY `AYS`.`AcademicYear` DESC";
//    //echo $Query;
//    $DBCONNECTION->sendquery($Query);
//
//    $exist = false; // check if the academic year information exists or not
//    while ($row = $DBCONNECTION->fetch_assoc()){
//        if ($AcademicYear != null && $AcademicYear=='all' && $AcademicYear!='')
//            $AcademicYear = $row["Idx"];
//        if ($AcademicYear == $row["Idx"])
//            $exist = true;
//
//        $content .= '<option value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
//    }
//    if ($exist == false) { // Academic year information does not exist, set the default value as "all".
//        $AcademicYear = 'all';
//    }
//    unset($DBCONNECTION);
//
//    return $content;
//}


//function GetAcademicYearOption_in_AssessmentRubrics(&$AcademicYear = null)
//{
//    $content = "";
//    require_once('dbconnection_class.php');
//    $DBCONNECTION = new Dbconnection();
//    $Query = "SELECT DISTINCT `AYS`.`Idx`, `AYS`.`AcademicYear` FROM `AssessmentMasterRubrics` AS `AMRS` INNER JOIN `AcademicYears` AS `AYS` ON (`AMRS`.`AcademicYear`=`AYS`.`Idx`) WHERE `AMRS`.`AcademicProgram`='".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' ORDER BY `AYS`.`AcademicYear` DESC";
//    //echo $Query;
//    $DBCONNECTION->sendquery($Query);
//
//    $exist = false; // check if the academic year information exists or not
//    while ($row = $DBCONNECTION->fetch_assoc()) {
//        if ($AcademicYear != null && $AcademicYear=='all' && $AcademicYear!='')
//            $AcademicYear = $row["Idx"];
//        if ($AcademicYear == $row["Idx"])
//            $exist = true;
//        $content .= '<option value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
//    }
//    if ($exist == false) { // Academic year information does not exist, set the default value as "all".
//        $AcademicYear = 'all';
//    }
//    unset($DBCONNECTION);
//
//    return $content;
//}
//
//function GetAcademicYearOption_in_AbetCourses(&$AcademicYear = null)
//{
//    $content = "";
//    require_once('dbconnection_class.php');
//    $DBCONNECTION = new Dbconnection();
//    $Query = "SELECT DISTINCT `AYS`.`Idx`, `AYS`.`AcademicYear` FROM `AbetCourses` AS `ABETCRSES` INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`) WHERE `ABETCRSES`.`AcademicProgram`='".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' ORDER BY `AYS`.`AcademicYear` DESC";
//    //echo $Query;
//    $DBCONNECTION->sendquery($Query);
//
//    $exist = false; // check if the academic year information exists or not
//    while ($row = $DBCONNECTION->fetch_assoc()) {
//        if ($AcademicYear != null && $AcademicYear=='all' && $AcademicYear!='')
//            $AcademicYear = $row["Idx"];
//        if ($AcademicYear == $row["Idx"])
//            $exist = true;
//        $content .= '<option value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
//    }
//    if ($exist == false) { // Academic year information does not exist, set the default value as "all".
//        $AcademicYear = 'all';
//    }
//    unset($DBCONNECTION);
//    return $content;
//}

//function GetAcademicYearOption_in_AbetCourses_w_Default(&$AcademicYear)
//{
//    $content = "";
//    require_once('dbconnection_class.php');
//    $DBCONNECTION = new Dbconnection();
//    $Query = "SELECT DISTINCT `AYS`.`Idx`, `AYS`.`AcademicYear` FROM `AbetCourses` AS `ABETCRSES` INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`) WHERE `ABETCRSES`.`AcademicProgram`='".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' ORDER BY `AYS`.`AcademicYear` DESC";
//    //echo $Query;
//    $DBCONNECTION->sendquery($Query);
//
//    while ($row = $DBCONNECTION->fetch_assoc()){
//        if ($AcademicYear == null || $AcademicYear == 'all')
//            $AcademicYear = $row["Idx"];
//        $content .= '<option';
//        if ($AcademicYear == $row["Idx"]) $content .= ' selected ';
//        $content .= ' value="' . $row["Idx"] . '">' . $row["AcademicYear"] . '</option>';
//    }
//    unset($DBCONNECTION);
//
//    return $content;
//}

