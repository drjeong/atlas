<?php
/**
 * Management of Academic Year
 * Description: add academic year
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 *
 */

include('checker_systemadmin.php');

// Your dataset of academic years
$academicYears = [
    '2019-2020',
    '2020-2021',
    '2021-2022',
    '2022-2023',
    '2023-2024',
    '2024-2025',
    '2025-2026',
    '2026-2027',
    '2027-2028'
];

// Loop through the dataset and call the function for each year range
foreach ($academicYears as $yearRange) {
    // Split the range into "from" and "to"
    [$AcademicYearFrom, $AcademicYearTo] = explode('-', $yearRange);

    // Call the function with the extracted years
    $result = createAcademicYearDirectories($AcademicYearFrom, $AcademicYearTo);

    // Output the result for each range
    echo "Result for {$yearRange}: {$result}\n";
}

function createAcademicYearDirectories($AcademicYearFrom, $AcademicYearTo) {
    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        require_once(__DIR__ . '/../config.php');

        $DBCONNECTION = new Dbconnection();

        // Create semester code matched to the university system
        $AcademicYearInfo = "{$AcademicYearFrom}-{$AcademicYearTo}";

        // Define parent directories that need to exist
        $parentDirectories = [
            __DIRECTORY_ABETASSESSMENTS__,
            __DIRECTORY_ABETSYLLABI__,
            __DIRECTORY_COURSEBI__,
            __DIRECTORY_INSTRUCTIONAL_MATERIALS__,
            __DIRECTORY_COURSEASSIGNMENT_SAMPLES__,
            __DIRECTORY_ABETASSESSMENTSURVEY__,
            __DIRECTORY_COURSEBINDERS__
        ];

        // Track which parent directories failed
        $failedParentDirs = [];

        // Create parent directories first
        $mode = 0755; // Owner: rwx, Group: rx, Others: rx
        foreach ($parentDirectories as $parentDir) {
            if (is_dir($parentDir)) {
                echo "Parent directory already exists: {$parentDir}\n";
            } else {
                if (mkdir($parentDir, $mode, true)) {
                    echo "Parent directory created successfully: {$parentDir}\n";
                } else {
                    $error = error_get_last();
                    echo "WARNING: Failed to create parent directory: {$parentDir}. Error: " . ($error['message'] ?? 'Unknown error') . "\n";
                    $failedParentDirs[] = $parentDir;
                }
            }
        }

        // Define directories to create
        $directories = [
            __DIRECTORY_ABETASSESSMENTS__ . $AcademicYearInfo . DIRECTORY_SEPARATOR,
            __DIRECTORY_ABETSYLLABI__ . $AcademicYearInfo . DIRECTORY_SEPARATOR,
            __DIRECTORY_COURSEBI__ . $AcademicYearInfo . DIRECTORY_SEPARATOR,
            __DIRECTORY_INSTRUCTIONAL_MATERIALS__ . $AcademicYearInfo . DIRECTORY_SEPARATOR,
            __DIRECTORY_COURSEASSIGNMENT_SAMPLES__ . $AcademicYearInfo . DIRECTORY_SEPARATOR,
            __DIRECTORY_ABETASSESSMENTSURVEY__ . $AcademicYearInfo . DIRECTORY_SEPARATOR,
            __DIRECTORY_COURSEBINDERS__ . $AcademicYearInfo . DIRECTORY_SEPARATOR
        ];

        // Track success and failures
        $successCount = 0;
        $failureCount = 0;

        // Create academic year subdirectories
        foreach ($directories as $directory) {
            // Check if parent directory failed
            $parentFailed = false;
            foreach ($failedParentDirs as $failedParent) {
                if (strpos($directory, $failedParent) === 0) {
                    echo "Skipping directory (parent failed): {$directory}\n";
                    $failureCount++;
                    $parentFailed = true;
                    break;
                }
            }

            if ($parentFailed) {
                continue;
            }

            if (is_dir($directory)) {
                echo "Directory already exists: {$directory}\n";
                $successCount++;
            } else {
                if (mkdir($directory, $mode, true)) {
                    echo "Directory created successfully: {$directory}\n";
                    $successCount++;
                } else {
                    $error = error_get_last();
                    echo "WARNING: Failed to create directory: {$directory}. Error: " . ($error['message'] ?? 'Unknown error') . "\n";
                    $failureCount++;
                }
            }
        }

        // Return success if at least some directories were created/exist
        if ($successCount > 0) {
            echo "Summary: {$successCount} successful, {$failureCount} failed\n";
            return "0x11111111";
        } else {
            echo "Summary: All directories failed\n";
            return "0x00000000";
        }

    } catch (Exception $e) {
        // Log the error and return failure code
        echo "ERROR: " . $e->getMessage() . "\n";
        error_log("General Error: " . $e->getMessage() .
            " in " . __FILE__ .
            " on line " . __LINE__);
        return "0x00000000";
    }
}