<?php
/**
 * Updating Student Outcomes
 * Description: updating the stored student outcomes.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2021 - initial version created
 * 03/02/2021 -- changed to support only updating modified SO descriptions
 * 10/08/2024 -- Adding revision comments and approval info
 * 11/10/2024 -- change SQL execution to address SQL injection
 */


include_once 'session_handler.php';


$IDX='';
$Description='';
$Comments='';
$Approval='';
$Removal='';

if (array_key_exists('id', $_POST)
    && array_key_exists('desc', $_POST)
    && array_key_exists('cmnts', $_POST)
    && array_key_exists('aprval', $_POST)
    && array_key_exists('removal', $_POST))
{
    $IDX = trim($_POST['id']);
    $Description = trim($_POST['desc']);
    $Comments = trim($_POST['cmnts']);
    $Approval = trim($_POST['aprval']);
    $Removal = trim($_POST['removal']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}
if ($IDX=="" || $Description=="" ){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    //  Convert character encodings
    require_once(__DIR__ . '/php_include/listfunc.php');
    $Description = convertSpecialCharacters($Description);
    $Comments = convertSpecialCharacters($Comments);
    $Approval = convertSpecialCharacters($Approval);

    // convert unwanted escape strings
    $Description = $DBCONNECTION->real_escape_string($Description);
    $Comments = $DBCONNECTION->real_escape_string($Comments);
    $Approval = $DBCONNECTION->real_escape_string($Approval);
    $Removal = ($Removal=='true')?'1':'0';

    # update the student outcome information
    $query = "CALL SP_UpdateSO(?, ?, ?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$IDX, $Description, $Comments, $Approval, $Removal]);

    echo "0x11111111";
} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x09000012') !== false) {
        echo '0x09000012';  // Cannot update: Student Outcome is not found
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}