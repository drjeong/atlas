<?php
/**
 * Add Abet Course
 * Description: Adding abet course
 * Author: Dong Hyun Jeong
 *
 * 11/19/2024 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$Courses='';
if (array_key_exists('crses', $_POST))
{
    $Courses = trim($_POST['crses']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicProgramIdx=="" || $Courses==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // convert courses
    $Course_Array = explode( '|', $Courses );

    // Validate inputs
    $AcademicProgramIdx = filter_var($AcademicProgramIdx, FILTER_VALIDATE_INT);
    if ($AcademicProgramIdx === false) {
        throw new Exception('Invalid Academic Program format');
    }
    
    $MultiQuery = "";
    for ($i=0; $i<count($Course_Array); $i++)
    {
        $CourseIdx = $Course_Array[$i];

        // Validate course index
        $CourseIdx = filter_var($CourseIdx, FILTER_VALIDATE_INT);
        if ($CourseIdx === false) {
            throw new Exception('Invalid Course Information format');
        }

        $MultiQuery .= "CALL SP_AddAbetSyllabus_Courses('$CourseIdx', '$AcademicProgramIdx');";
    }
    $DBCONNECTION->sendmultiquery($MultiQuery);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

