<?php
// test_semester_codes.php

// Mock config.php for testing
if (!defined('__SCHOOL_SEMESTER_PATTERN')) {
    define('__SCHOOL_SEMESTER_PATTERN', 'standard');
}

require_once 'semester_helpers.php';

class SemesterCodeTester
{
    private $pattern;

    public function __construct($pattern)
    {
        $this->pattern = $pattern;
    }

    /**
     * Create a test manager with specific pattern
     */
    private function getTestManager()
    {
        $config = new SemesterCodeConfig($this->pattern);
        return new SemesterCodeManager($config);
    }

    public function runAllTests()
    {
        echo "\n" . str_repeat("=", 70) . "\n";
        echo "Testing: " . strtoupper($this->pattern) . " PATTERN\n";
        echo str_repeat("=", 70) . "\n\n";

        $this->testHelperFunctions();
        $this->testBannerSemesterText();
        $this->testMonthMapping();
        $this->testCodeParsing();
        $this->testYearOffsets();
        $this->testEdgeCases();
    }

    private function testHelperFunctions()
    {
        echo "--- Helper Functions Test ---\n";

        // Note: These use the global singleton, so they use __SCHOOL_SEMESTER_PATTERN
        // We'll create direct instances for pattern-specific testing
        $manager = $this->getTestManager();

        echo "Academic Year: " . $manager->getAcademicYear() . "\n";
        echo "Current Semester Code: " . $manager->getCurrentSemesterCode() . "\n";
        echo "3 Years Ago Code: " . $manager->getSemesterCode(3) . "\n";
        echo "\n";
    }

    private function testBannerSemesterText()
    {
        echo "--- getBannerSemesterText() Test ---\n";

        $manager = $this->getTestManager();
        $config = new SemesterCodeConfig($this->pattern);
        $pattern = $config->getPattern();

        // Test regular semester codes
        $testYear = 2026;
        echo "Regular semester codes:\n";

        foreach ($pattern as $semesterName => $code) {
            if ($semesterName === 'year_offset') continue;

            $offset = $pattern['year_offset'][$semesterName];
            $semesterCode = ($testYear + $offset) . $code;

            try {
                $parsed = $manager->parseSemesterCode($semesterCode);
                $bannerText = $parsed['year'] . ucfirst($parsed['semester']);

                printf("  Code: %s -> Banner: %s (Expected: %d%s)\n",
                    $semesterCode,
                    $bannerText,
                    $parsed['year'],
                    ucfirst($semesterName)
                );
            } catch (Exception $e) {
                echo "  ERROR: Code $semesterCode - {$e->getMessage()}\n";
            }
        }

        // Test "Current" codes
        echo "\nSpecial 'Current' codes:\n";
        foreach ($pattern as $semesterName => $code) {
            if ($semesterName === 'year_offset') continue;

            $currentCode = '9999' . $code;
            $config = new SemesterCodeConfig($this->pattern);
            $testPattern = $config->getPattern();

            $currentCodes = [];
            foreach ($testPattern as $sem => $semCode) {
                if ($sem !== 'year_offset') {
                    $currentCodes[] = '9999' . $semCode;
                }
            }

            $result = in_array($currentCode, $currentCodes) ? "Current" : "Not recognized";
            printf("  Code: %s -> %s ✓\n", $currentCode, $result);
        }

        echo "\n";
    }

    private function testMonthMapping()
    {
        echo "--- Month-to-Semester Mapping ---\n";

        $config = new SemesterCodeConfig($this->pattern);
        $ranges = $config->getMonthRanges();

        for ($m = 1; $m <= 12; $m++) {
            $semester = 'unknown';
            foreach ($ranges as $range) {
                if ($m >= $range['start'] && $m <= $range['end']) {
                    $semester = $range['semester'];
                    break;
                }
            }

            $monthName = date('F', mktime(0, 0, 0, $m, 1));
            printf("  %-10s (M%02d) -> %-10s\n", $monthName, $m, ucfirst($semester));
        }
        echo "\n";
    }

    private function testCodeParsing()
    {
        echo "--- Semester Code Parsing ---\n";

        $manager = $this->getTestManager();
        $config = new SemesterCodeConfig($this->pattern);
        $pattern = $config->getPattern();

        $testYear = 2027;

        foreach ($pattern as $semesterName => $code) {
            if ($semesterName === 'year_offset') continue;

            $offset = $pattern['year_offset'][$semesterName];
            $semesterCode = ($testYear + $offset) . $code;

            try {
                $parsed = $manager->parseSemesterCode($semesterCode);
                printf("  %-12s -> Code: %s -> Display: %s\n",
                    ucfirst($semesterName),
                    $semesterCode,
                    $parsed['display']
                );
            } catch (Exception $e) {
                echo "  ERROR parsing $semesterCode: {$e->getMessage()}\n";
            }
        }
        echo "\n";
    }

    private function testYearOffsets()
    {
        echo "--- Year Offset Verification ---\n";

        $config = new SemesterCodeConfig($this->pattern);
        $pattern = $config->getPattern();

        $baseYear = 2025;
        echo "  Base Year: $baseYear\n\n";

        foreach ($pattern['year_offset'] as $semester => $offset) {
            $code = ($baseYear + $offset) . $pattern[$semester];

            printf("  %-12s: Offset=%+d, Year=%d, Code=%s\n",
                ucfirst($semester),
                $offset,
                $baseYear + $offset,
                $code
            );
        }
        echo "\n";
    }

    private function testEdgeCases()
    {
        echo "--- Edge Cases Test ---\n";

        $manager = $this->getTestManager();

        // Test invalid codes
        $invalidCodes = [
            '202799',  // Invalid semester suffix
            '20271',   // Too short
            '2027100', // Too long
            'abcd10',  // Non-numeric year
            '202700',  // Zero suffix
        ];

        echo "Testing invalid codes (should throw exceptions):\n";
        foreach ($invalidCodes as $code) {
            try {
                $parsed = $manager->parseSemesterCode($code);
                echo "  Code: $code -> UNEXPECTED SUCCESS: {$parsed['display']}\n";
            } catch (Exception $e) {
                echo "  Code: $code -> Exception caught ✓ ({$e->getMessage()})\n";
            }
        }

        echo "\n";
    }
}

// Run tests for both patterns
echo "\n";
echo "████████████████████████████████████████████████████████████████████████\n";
echo "█                     SEMESTER CODE SYSTEM TEST                        █\n";
echo "████████████████████████████████████████████████████████████████████████\n";

$tester1 = new SemesterCodeTester('standard');
$tester1->runAllTests();

$tester2 = new SemesterCodeTester('alternative');
$tester2->runAllTests();

// Comparison test
echo str_repeat("=", 70) . "\n";
echo "PATTERN COMPARISON (Current Date: " . date('Y-m-d') . ")\n";
echo str_repeat("=", 70) . "\n\n";

$standardManager = new SemesterCodeManager(new SemesterCodeConfig('standard'));
$altManager = new SemesterCodeManager(new SemesterCodeConfig('alternative'));

echo "Current Semester Codes:\n";
echo "  Standard:    " . $standardManager->getCurrentSemesterCode() . "\n";
echo "  Alternative: " . $altManager->getCurrentSemesterCode() . "\n\n";

echo "Academic Years:\n";
echo "  Standard:    " . $standardManager->getAcademicYear() . "\n";
echo "  Alternative: " . $altManager->getAcademicYear() . "\n\n";

// Month mapping comparison for key months
echo "Key Month Comparison:\n";
$keyMonths = [1, 6, 8, 12]; // January, June, August, December

$standardConfig = new SemesterCodeConfig('standard');
$altConfig = new SemesterCodeConfig('alternative');

foreach ($keyMonths as $month) {
    $monthName = date('F', mktime(0, 0, 0, $month, 1));

    $standardRanges = $standardConfig->getMonthRanges();
    $altRanges = $altConfig->getMonthRanges();

    $standardSem = 'unknown';
    foreach ($standardRanges as $range) {
        if ($month >= $range['start'] && $month <= $range['end']) {
            $standardSem = $range['semester'];
            break;
        }
    }

    $altSem = 'unknown';
    foreach ($altRanges as $range) {
        if ($month >= $range['start'] && $month <= $range['end']) {
            $altSem = $range['semester'];
            break;
        }
    }

    printf("  %-10s: Standard=%-10s Alternative=%-10s %s\n",
        $monthName,
        ucfirst($standardSem),
        ucfirst($altSem),
        $standardSem === $altSem ? '✓' : '✗'
    );
}

echo "\n" . str_repeat("=", 70) . "\n";
echo "Test completed!\n";
echo str_repeat("=", 70) . "\n\n";