<?php

if (session_status() === PHP_SESSION_ACTIVE) {
    $_SESSION['ATLAS_LASTCONNECTEDTIME'] = time(); // update last accessed time
//    error_log('session time updated: '. $_SESSION['ATLAS_LASTCONNECTEDTIME']);
}

require_once ('dbconnection_class.php');
function getSqlConnAttributes()
{
    if (!isset($SQL_CONNATTRIBUTES)) {
        // SQL server connection information
        $SQL_CONNATTRIBUTES = array(
            'user' => __DB_USERID,
            'pass' => __DB_USERPWD,
            'db' => __DB_DBNAME,
            'host' => __DB_HOSTNAME
        );
    }
    return $SQL_CONNATTRIBUTES;
}
