<?php
/**
 * updating Master Syllabus
 * Description: updating master syllabus
 * Author: Dong Hyun Jeong
 *
 * 10/08/2024 - initial version created
 */


include_once 'session_handler.php';

// Required fields
$fields = [
    'CourseIndex', 'CourseTitle',
    'FromAcademicYears', 'MajorVersion', 'MinorVersion',
    'Subject', 'Num', 'Description', 'Credits', 'Requirement',
    'Pre_requisites', 'Required_Texts',
    'Coordinator', 'Objectives', 'TopicsCovered',
    'RevisionDesc', 'RevisionDate'
];

$data = [];
foreach ($fields as $field) {
    if (array_key_exists($field, $_POST)) {
        $data[$field] = trim($_POST[$field]);
    } else {
        // Unwanted illegal entry
        echo "0x00000000";
        exit;
    }
}

foreach ($fields as $field) {
    if ($field !== 'ReferenceTexts' && $field !== 'Co_requisites' && $data[$field] === '') {
        // No required information
        echo "0x00000101";
        exit;
    }
}

// Access your variables like this:
$CourseIndex = $data['CourseIndex'];
$CourseTitle = $data['CourseTitle'];
$FromAcademicYears = $data['FromAcademicYears'];
$Subject = $data['Subject'];
$MajorVersion = $data['MajorVersion'];
$MinorVersion = $data['MinorVersion'];
$Num = $data['Num'];
$Description = $data['Description'];
$Credits = $data['Credits'];
$Requirement = $data['Requirement'];
$Pre_requisites = $data['Pre_requisites'];
$Required_Texts = $data['Required_Texts'];
$Coordinator = $data['Coordinator'];
$Objectives = $data['Objectives'];
$TopicsCovered = $data['TopicsCovered'];
$RevisionDesc = $data['RevisionDesc'];
$RevisionDate = $data['RevisionDate'];

// Handle optional fields
$SyllabusIndex = isset($_POST['SyllabusIndex']) ? trim($_POST['SyllabusIndex']) : '';
$Co_requisites = isset($_POST['Co_requisites']) ? trim($_POST['Co_requisites']) : '';
$ReferenceTexts = isset($_POST['ReferenceTexts']) ? trim($_POST['ReferenceTexts']) : '';
$ToAcademicYears = isset($_POST['ToAcademicYears']) ? trim($_POST['ToAcademicYears']) : '';
$ApprovalDesc = isset($_POST['ApprovalDesc']) ? trim($_POST['ApprovalDesc']) : '';
$ApprovalDate = isset($_POST['ApprovalDate']) ? trim($_POST['ApprovalDate']) : '';
$ObjectivesHeadline = isset($_POST['ObjectivesHeadline']) ? trim($_POST['ObjectivesHeadline']) : '';
$TopicsCoveredHeadline = isset($_POST['TopicsCoveredHeadline']) ? trim($_POST['TopicsCoveredHeadline']) : '';

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    //  Convert character encodings
    require_once(__DIR__ . '/php_include/listfunc.php');

    $Pre_requisites = replaceBulletPoints($Pre_requisites);
    $Co_requisites = replaceBulletPoints($Co_requisites);
    $Required_Texts = replaceBulletPoints($Required_Texts);
    $ReferenceTexts = replaceBulletPoints($ReferenceTexts);
    $ObjectivesHeadline = replaceBulletPoints($ObjectivesHeadline);
    $Objectives = replaceBulletPoints($Objectives);
    $TopicsCoveredHeadline = replaceBulletPoints($TopicsCoveredHeadline);
    $TopicsCovered = replaceBulletPoints($TopicsCovered);

    // remove all new lines
    $Description = removeNewline($Description);

    // replace all special characters
    $Description = replaceSpecialCharacters($Description);
    $Required_Texts = replaceSpecialCharacters($Required_Texts);
    $ReferenceTexts = replaceSpecialCharacters($ReferenceTexts);
    $ObjectivesHeadline = replaceSpecialCharacters($ObjectivesHeadline);
    $Objectives = replaceSpecialCharacters($Objectives);
    $TopicsCoveredHeadline = replaceSpecialCharacters($TopicsCoveredHeadline);
    $TopicsCovered = replaceSpecialCharacters($TopicsCovered);

    // replace all new lines to "||"
    $Pre_requisites = replaceNewlines_removeWhiteSpace($Pre_requisites);
    $Required_Texts = replaceNewlines_removeWhiteSpace($Required_Texts);
    $ReferenceTexts = replaceNewlines_removeWhiteSpace($ReferenceTexts);
    $ObjectivesHeadline = replaceNewlines($ObjectivesHeadline);
    $Objectives = replaceNewlines($Objectives);
    $TopicsCoveredHeadline = replaceNewlines($TopicsCoveredHeadline);
    $TopicsCovered = replaceNewlines($TopicsCovered);
    $RevisionDesc = replaceNewlines_removeWhiteSpace($RevisionDesc);
    $ApprovalDesc = replaceNewlines_removeWhiteSpace($ApprovalDesc);

    // remove all unnecessary characters to be used in DB
    $Description = cleanInput($Description, $DBCONNECTION);
    $Requirement = cleanInput($Requirement, $DBCONNECTION);
    $Pre_requisites = cleanInput($Pre_requisites, $DBCONNECTION);
    $Co_requisites = cleanInput($Co_requisites, $DBCONNECTION);
    $Required_Texts = cleanInput($Required_Texts, $DBCONNECTION);
    $ReferenceTexts = cleanInput($ReferenceTexts, $DBCONNECTION);
    $Coordinator = cleanInput($Coordinator, $DBCONNECTION);
    $ObjectivesHeadline = cleanInput($ObjectivesHeadline, $DBCONNECTION);
    $Objectives = cleanInput($Objectives, $DBCONNECTION);
    $TopicsCoveredHeadline = cleanInput($TopicsCoveredHeadline, $DBCONNECTION);
    $TopicsCovered = cleanInput($TopicsCovered, $DBCONNECTION);
    $RevisionDesc = cleanInput($RevisionDesc, $DBCONNECTION);
    $ApprovalDesc = cleanInput($ApprovalDesc, $DBCONNECTION);
    $ApprovalDate = cleanInput($ApprovalDate, $DBCONNECTION);
    $RevisionDate = cleanInput($RevisionDate, $DBCONNECTION);

    $ToAcademicYears = !empty($ToAcademicYears) ? $ToAcademicYears : null;
    $ApprovalDate = !empty($ApprovalDate) ? $ApprovalDate : null;
    $RevisionDate = !empty($RevisionDate) ? $RevisionDate : null;

    // editing the existing syllabus
    $params = [$SyllabusIndex, $MajorVersion, $MinorVersion,
        $FromAcademicYears, $ToAcademicYears,
        $Subject, $Num, $Description, $Credits, $Requirement, $Pre_requisites,
        $Co_requisites, $Required_Texts, $ReferenceTexts, $Coordinator,
        $ObjectivesHeadline, $Objectives,
        $TopicsCoveredHeadline, $TopicsCovered,
        $RevisionDesc, $RevisionDate, $ApprovalDesc, $ApprovalDate];
    $results = $DBCONNECTION->callStoredProcedure('SP_AbetSyllabus_Edit_Save', $params);

//    error_log($DBCONNECTION->formatQueryStoredProcedure('SP_AbetSyllabus_Edit_Update', $params));

    // Validating if contents can be used to generate PDF
    require_once(__DIR__ . '/php_include/LatexTemplate.php');
    $data = [
        'Description' => $Description,
        'Credits' => $Credits,
        'Requirement' => $Requirement,
        'Pre_requisites' => $Pre_requisites,
        'Co_requisites' => $Co_requisites,
        'Required_Texts' => $Required_Texts,
        'Reference_Texts' => $ReferenceTexts,
        'Coordinator' => $Coordinator,
        'ObjectivesHeadline' => $ObjectivesHeadline,
        'Objectives' => $Objectives,
        'TopicsCoveredHeadline' => $TopicsCoveredHeadline,
        'TopicsCovered' => $TopicsCovered,
        'RevisionDesc' => $RevisionDesc,
        'RevisionDate' => $RevisionDate,
        'ApprovalDesc' => $ApprovalDesc,
        'ApprovalDate' => $ApprovalDate
    ];

    $validation = LatexTemplate::validateTreatedLaTeXContent($data);
    if (!$validation['valid']) {
        $errorLabels = [
            'Description' => "Catalog Description",
            'Credits' => "Credits",
            'Requirement' => "Requirement",
            'Pre_requisites' => "Pre-requisites",
            'Co_requisites' => "Co-requisites",
            'Required_Texts' => "Required Texts",
            'Reference_Texts' => "Reference Texts",
            'Coordinator' => "Coordinator",
            'ObjectivesHeadline' => "Objectives Headline",
            'Objectives' => "Objectives",
            'TopicsCoveredHeadline' => "TopicsCovered Headline",
            'TopicsCovered' => "TopicsCovered",
            'RevisionDesc' => "Revision Description",
            'RevisionDate' => "Revision Date",
            'ApprovalDesc' => "Approval Description",
            'ApprovalDate' => "Approval Date"
        ];

        // convert to appropriate error labels
        $error_labels = array_map(function($field) use ($errorLabels) {
            return array_key_exists($field, $errorLabels) ? $errorLabels[$field] : $field;
        }, array_filter($validation['error_fields'], function($field) use ($errorLabels) {
            return array_key_exists($field, $errorLabels);
        }));

        // reporting error message with specific input field to be fixed.
        echo "0x11111110: " . (empty($error_labels) ? "" : implode(", ", $error_labels));

        error_log("LaTeX content validation failed:\n" .
            implode("\n", $validation['errors'])
        );
        return; // PDF creation is not possible due to errors.
    }

    echo "0x11111111";
} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
//    $errorMessage = $e->getMessage();
    echo "0x00000500";  // other DB error
    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500'
    ]));

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}