<?php
/**
 * Management of User Accounts
 * Description: sending an email with the randomly generated password
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 */

include_once ('./php_include/notify_user.php');

if (!isset($_POST['name']) || !isset($_POST['email']) || !isset($_POST['password']))
{
	exit;
}

$name = trim($_POST['name']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);

$message = "Here is your account information (password reset) for the system (ATLAS: Academic Tracking & Learning Assessment System).<br/> Your temporarily created password:<br /><br />Password: $password<br /><br />Since this email was transmitted without encryption, kindly ask you to change your password ASAP. For changing the password, please log-in to the system. The password change menu is located in the right top corner under your name.";

NotifyUserByEmail($email, "Notification: Temporary created password!!", $message);
echo "0x11111111";