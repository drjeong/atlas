<?php
/**
 * Listing Available Courses
 * File: m_avcourses_ssps.php
 * Description: listing all available courses
 *
 * 08/09/2026 Modified to use Semesters table join instead of FUNC_GetYearSem
 * 08/10/2026 Fixed to show courses even when instructor is empty/null
 *
 */
include_once 'session_handler.php';

$Semester = '';
if (array_key_exists('_SM', $_GET)) {
    $Semester = ltrim(rtrim($_GET['_SM']));
}

require_once(__DIR__ . '/../../config.php');

// ============================================================================
// DATABASE CONFIGURATION
// ============================================================================

// Primary table for available courses
$table = 'AVCourses';

/**
 * JOIN Query Structure
 *
 * This query joins multiple tables to gather comprehensive course information:
 *
 * 1. AVCourses (AVCRSES) - Base table with course offerings
 * 2. AVCoursesInstructors (AVINSTRUCTORS) - Links courses to instructors [LEFT JOIN - may be null]
 * 3. UserAccounts (UA) - Instructor details [LEFT JOIN - may be null]
 * 4. Semesters (SMSTRS) - Semester information
 * 5. Courses (CS) - Course catalog information
 * 6. AbetSyllabus (ABS) - Syllabus records
 * 7. AcademicYears (AY) - Academic year mapping
 *
 * NOTE: Using LEFT JOINs for instructor tables ensures courses without
 * instructors are still displayed in the results.
 */
$joinQuery = "FROM `{$table}` AS `AVCRSES` 
    LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` ON (`AVCRSES`.`Idx`=`AVINSTRUCTORS`.`AVCourseIdx`) 
    LEFT JOIN `UserAccounts` AS `UA` ON (`AVINSTRUCTORS`.`Instructor`=`UA`.`Idx`)
    LEFT JOIN `Semesters` AS `SMSTRS` ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
    LEFT JOIN `Courses` AS `CS` ON (`AVCRSES`.`Subject`=`CS`.`Subject` AND `AVCRSES`.`Num`=`CS`.`Num`)
    LEFT JOIN `AbetSyllabus` AS `ABS` ON (`CS`.`Idx`=`ABS`.`CourseIndex`)
    LEFT JOIN `AcademicYears` AS `AY` ON (`AVCRSES`.`Semester` BETWEEN `AY`.`From` AND `AY`.`To`)";

// ============================================================================
// TABLE CONFIGURATION
// ============================================================================

// Table's primary key for row identification
$primaryKey = 'CRN';

// ============================================================================
// COLUMN DEFINITIONS
// ============================================================================

/**
 * Array of database columns to retrieve and display
 *
 * Each column definition includes:
 * - db: SQL expression or column name
 * - dt: DataTables column identifier
 * - field: Field name for processing
 * - as: SQL alias for the column
 * - formatter: (optional) PHP function to format the output
 */
$columns = array(
    // ------------------------------------------------------------------------
    // ROW IDENTIFIER
    // ------------------------------------------------------------------------
    array(
        'db' => '`AVCRSES`.`CRN`',
        'dt' => 'DT_RowId',
        'field' => 'DT_RowId',
        'as' => 'DT_RowId',
        'formatter' => function ($d, $row) {
            return 'row_' . $d; // Format: row_12345
        }
    ),

    // ------------------------------------------------------------------------
    // ACADEMIC YEAR INFORMATION
    // ------------------------------------------------------------------------
    array(
        'db' => 'MAX(`AY`.`Idx`)',
        'dt' => 'AcademicYearIdx',
        'field' => 'AcademicYearIdx',
        'as' => 'AcademicYearIdx'
    ),
    array(
        'db' => 'MAX(`AY`.`AcademicYear`)',
        'dt' => 'AcademicYearInfo',
        'field' => 'AcademicYearInfo',
        'as' => 'AcademicYearInfo'
    ),

    // ------------------------------------------------------------------------
    // SEMESTER INFORMATION
    // ------------------------------------------------------------------------
    array(
        'db' => '`AVCRSES`.`Semester`',
        'dt' => 'Semester',
        'field' => 'Semester',
        'as' => 'Semester'
    ),
    array(
        'db' => '`SMSTRS`.`Explanation`',
        'dt' => 'SemesterTxt',
        'field' => 'SemesterTxt',
        'as' => 'SemesterTxt',
        'formatter' => function ($d, $row) {
            // Format: "Spring 2026 (202620)"
            return $d . ' (' . $row['Semester'] . ')';
        }
    ),

    // ------------------------------------------------------------------------
    // COURSE IDENTIFICATION
    // ------------------------------------------------------------------------
    array(
        'db' => '`AVCRSES`.`Idx`',
        'dt' => 'AVCIdx',
        'field' => 'AVCIdx',
        'as' => 'AVCIdx'
    ),
    array(
        'db' => '`AVCRSES`.`CRN`',
        'dt' => 'CRN',
        'field' => 'CRN',
        'as' => 'CRN'
    ),
    array(
        'db' => '`AVCRSES`.`Subject`',
        'dt' => 'Subject',
        'field' => 'Subject',
        'as' => 'Subject'
    ),
    array(
        'db' => '`AVCRSES`.`Num`',
        'dt' => 'Num',
        'field' => 'Num',
        'as' => 'Num'
    ),

    // ------------------------------------------------------------------------
    // COURSE DETAILS
    // ------------------------------------------------------------------------
    array(
        'db' => '`AVCRSES`.`Title`',
        'dt' => 'Title',
        'field' => 'Title',
        'as' => 'Title'
    ),
    array(
        'db' => '`AVCRSES`.`Credits`',
        'dt' => 'Credits',
        'field' => 'Credits',
        'as' => 'Credits'
    ),

    // ------------------------------------------------------------------------
    // SCHEDULE INFORMATION
    // ------------------------------------------------------------------------
    array(
        'db' => '`AVCRSES`.`Days`',
        'dt' => 'Days',
        'field' => 'Days',
        'as' => 'Days'
    ),
    array(
        'db' => '`AVCRSES`.`Times`',
        'dt' => 'Times',
        'field' => 'Times',
        'as' => 'Times'
    ),
    array(
        'db' => '`AVCRSES`.`Location`',
        'dt' => 'Location',
        'field' => 'Location',
        'as' => 'Location'
    ),

    // ------------------------------------------------------------------------
    // ENROLLMENT INFORMATION
    // ------------------------------------------------------------------------
    array(
        'db' => '`AVCRSES`.`Capacity`',
        'dt' => 'Capacity',
        'field' => 'Capacity',
        'as' => 'Capacity'
    ),
    array(
        'db' => '`AVCRSES`.`Actual`',
        'dt' => 'Actual',
        'field' => 'Actual',
        'as' => 'Actual'
    ),

    // ------------------------------------------------------------------------
    // CLASS ROSTER STATUS
    // ------------------------------------------------------------------------
    array(
        'db' => 'MAX(CASE WHEN EXISTS (
                    SELECT 1 
                    FROM `ClassRoster` AS `CLSROSTER`
                    WHERE `AVCRSES`.`Idx`=`CLSROSTER`.`AvailableCourseIdx`
                ) THEN 1 ELSE 0 END)',
        'dt' => 'ClassRoster',
        'field' => 'ClassRoster',
        'as' => 'ClassRoster'
    ),

    // ------------------------------------------------------------------------
    // INSTRUCTOR INFORMATION
    // ------------------------------------------------------------------------
    /**
     * Instructor Names
     *
     * Uses a subquery to concatenate all instructor names for the course.
     * This approach ensures we get all instructors even when using GROUP BY.
     * Returns comma-separated list of instructor names, or NULL if no instructors.
     */
    array(
        'db' => '(SELECT GROUP_CONCAT(`UA2`.`Name` ORDER BY `UA2`.`Name` SEPARATOR \', \') 
                    FROM `AVCoursesInstructors` AS `AVINST2` 
                    LEFT JOIN `UserAccounts` AS `UA2` ON `AVINST2`.`Instructor`=`UA2`.`Idx` 
                    WHERE `AVINST2`.`AVCourseIdx`=`AVCRSES`.`Idx`)',
        'dt' => 'Instructor',
        'field' => 'Instructor',
        'as' => 'Instructor'
    ),
    array(
        'db' => '`AVCRSES`.`InstructorEmail`',
        'dt' => 'InstructorEmail',
        'field' => 'InstructorEmail',
        'as' => 'InstructorEmail'
    ),

    // ------------------------------------------------------------------------
    // SYLLABUS INFORMATION
    // ------------------------------------------------------------------------
    /**
     * Syllabus Data
     *
     * Complex subquery that retrieves ALL matching syllabi for the course.
     * Returns comma-separated list of: "SyllabusIdx|AcademicProgramIdx|Degree"
     *
     * Matching Criteria:
     * 1. Subject and Number must match
     * 2. Title must match (case-insensitive)
     * 3. Semester must fall within syllabus academic year range
     * 4. Only includes the highest version (major.minor) per academic program
     *
     * Example Output: "123|5|BS, 124|6|MS"
     * - First syllabus: Idx=123, Program=5 (BS degree)
     * - Second syllabus: Idx=124, Program=6 (MS degree)
     */
    array(
        'db' => '(SELECT GROUP_CONCAT(CONCAT(`ABS2`.`Idx`, "|", IFNULL(`ABS2`.`AcademicProgram`, ""), "|", IFNULL(`APS`.`Degree`, "")) 
                               ORDER BY 
                                 `ABS2`.`AcademicProgram` ASC
                               SEPARATOR ", ")
        FROM `AbetSyllabus` AS `ABS2` 
        INNER JOIN `Courses` AS `CS2` ON `ABS2`.`CourseIndex` = `CS2`.`Idx`
        LEFT JOIN `AcademicPrograms` AS `APS` ON `ABS2`.`AcademicProgram` = `APS`.`Idx`
        LEFT JOIN `AcademicYears` AS `AY_FROM` ON `ABS2`.`AcademicYearFrom` = `AY_FROM`.`Idx`
        LEFT JOIN `AcademicYears` AS `AY_TO` ON `ABS2`.`AcademicYearTo` = `AY_TO`.`Idx`
        WHERE `CS2`.`Subject` = `AVCRSES`.`Subject` 
          AND `CS2`.`Num` = `AVCRSES`.`Num`
          AND LOWER(TRIM(`CS2`.`TitleUniv`)) = LOWER(TRIM(`AVCRSES`.`Title`))
          AND (
            (`ABS2`.`AcademicYearFrom` IS NULL OR `AVCRSES`.`Semester` >= `AY_FROM`.`From`)
            AND
            (`ABS2`.`AcademicYearTo` IS NULL OR `AVCRSES`.`Semester` <= `AY_TO`.`To`)
          )
          AND (`ABS2`.`major_version`, `ABS2`.`minor_version`) = (
            SELECT `ABS3`.`major_version`, `ABS3`.`minor_version`
            FROM `AbetSyllabus` AS `ABS3`
            INNER JOIN `Courses` AS `CS3` ON `ABS3`.`CourseIndex` = `CS3`.`Idx`
            LEFT JOIN `AcademicYears` AS `AY_FROM3` ON `ABS3`.`AcademicYearFrom` = `AY_FROM3`.`Idx`
            LEFT JOIN `AcademicYears` AS `AY_TO3` ON `ABS3`.`AcademicYearTo` = `AY_TO3`.`Idx`
            WHERE `CS3`.`Subject` = `CS2`.`Subject`
              AND `CS3`.`Num` = `CS2`.`Num`
              AND (IFNULL(`ABS3`.`AcademicProgram`, 0) = IFNULL(`ABS2`.`AcademicProgram`, 0))
              AND LOWER(TRIM(`CS3`.`TitleUniv`)) = LOWER(TRIM(`AVCRSES`.`Title`))
              AND (
                (`ABS3`.`AcademicYearFrom` IS NULL OR `AVCRSES`.`Semester` >= `AY_FROM3`.`From`)
                AND
                (`ABS3`.`AcademicYearTo` IS NULL OR `AVCRSES`.`Semester` <= `AY_TO3`.`To`)
              )
            ORDER BY `ABS3`.`major_version` DESC, `ABS3`.`minor_version` DESC
            LIMIT 1
          ))',
        'dt' => 'SyllabusData',
        'field' => 'SyllabusData',
        'as' => 'SyllabusData',
        'formatter' => function($d, $row) {
            return $d;
        }
    ),
);

// ============================================================================
// SERVER-SIDE PROCESSING
// ============================================================================

require('ssp.join.class.php');

// Build WHERE clause for semester filtering
$extraWhere = "";
if ($Semester != "" && $Semester != "all") {
    $extraWhere = "`AVCRSES`.`Semester`='" . $Semester . "'";
}

/**
 * GROUP BY clause
 *
 * Groups results by course to aggregate instructor information.
 * This prevents duplicate rows when a course has multiple instructors.
 *
 * Note: We use a subquery for instructor names rather than relying on
 * GROUP_CONCAT in the JOIN to ensure accurate results.
 */
$groupBy = " `AVCRSES`.`Idx`, `AVCRSES`.`Semester`, `AVCRSES`.`CRN`, `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Title`, `AVCRSES`.`Credits`, `AVCRSES`.`Days`, `AVCRSES`.`Times`, `AVCRSES`.`Location`, `AVCRSES`.`Capacity`, `AVCRSES`.`Actual`, `AVCRSES`.`InstructorEmail` ";

// ============================================================================
// EXECUTE QUERY AND RETURN JSON
// ============================================================================

require_once(__DIR__ . '/../php_include/dbconnection.php');

echo json_encode(
    SSP::joinquery(
        $_GET,                      // DataTables request parameters
        getSqlConnAttributes(),     // Database connection attributes
        $table,                     // Primary table name
        $primaryKey,                // Primary key column
        $columns,                   // Column definitions
        $joinQuery,                 // JOIN clause
        $extraWhere,                // WHERE clause (semester filter)
        $groupBy,                   // GROUP BY clause
        false                       // Debug flag
    )
);

