/**
 * Course Syllabus Upload Module
 *
 * Dependencies:
 * - async_commons.js (v0.0.2 or higher)
 *   Include via:
 *
 * - ErrorCodes object must be defined globally before using these functions
 *   Example:
 *   const ErrorCodes = {
 *       SUCCESS: '0x11111111',
 *       CANNOT_CONNECT_SERVER: '0x00041000',
 *       INFORMATION_NOT_FOUND: '0x00061000',
 *       INCORRECT_OPERATION: '0x00000102',
 *       FILE_SIZE_EXCEED: '0x00251400'
 *   };
 *
 * - DataTable_UCourses must be initialized (used for reloading table after operations)
 * - SweetAlert2 (Swal) library for dialogs
 * - Bootstrap modal for the upload dialog
 * - FileSizeValidation() function for file validation
 */

/**
 * Opens a modal dialog to upload a course syllabus
 *
 * @param {string} _DIALOG_TITLE - Title prefix for the dialog
 * @param {string} _AVCIDX - Academic Version Course Index
 * @param {string} _ABTIDX - Academic Book Type Index
 * @param {string} _AYINFO - Academic Year Information
 * @param {string} _SEMESTER - Semester (e.g., "Fall 2024")
 * @param {string} _SUBJECT - Subject code (e.g., "CS")
 * @param {string} _NUM - Course number (e.g., "101")
 * @param {string} _TITLE - Course title
 * @param {string} _CRN - Course Reference Number
 */
function uploadCourseSyllabus(_DIALOG_TITLE, _AVCIDX, _ABTIDX, _AYINFO, _SEMESTER, _SUBJECT, _NUM, _TITLE, _CRN) {
    const content = `
            <form enctype="multipart/form-data" name="popupfrm" id="popupfrm">
                <input type="hidden" name="_AYINFO" size="30" value="${_AYINFO}">
                <input type="hidden" name="_AVCIDX" size="30" value="${_AVCIDX}">
                <input type="hidden" name="_ABTIDX" size="30" value="${_ABTIDX}">
                <input type="hidden" name="_CINFO" size="30" value="${_SEMESTER}_${_SUBJECT}_${_NUM}_crn${_CRN}">
                <table style="border-spacing:0; padding:0; width:100%;">
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%">
                                    <span class="input-group-addon" style="width:230px;">COURSE INFO: ${_SEMESTER} ${_SUBJECT} ${_NUM} ${_TITLE}</span>
                                </div>
                                <div class="input-group" style="width:100%">
                                    <span class="input-group-addon" style="width:230px;">Syllabus<span style="color:red">* (PDF only, MAX: 2MB)</span></span>
                                    <input type="file" name="_FILE" id="_FILE" class="input-sm form-control" value="" placeholder="Select Syllabus File" accept=".pdf" onchange="FileSizeValidation('_FILE')" required>
                                </div>
                            </div>
                        </td>
                    </tr>
                </table>
            </form>
            `;

    createModalDialog({
        title: `<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">${_DIALOG_TITLE} COURSE SYLLABUS</span>`,
        message: content,
        buttons: {
            ok: {
                label: "<span class='glyphicon glyphicon-ok'></span> UPLOAD",
                className: 'btn-success',
                callback: function () {
                    if (popupfrm._FILE.files.length === 0) {
                        popupfrm._FILE.focus();
                        Swal.fire({title: "ERROR", text: "File is not selected!!", icon: "error"});
                        return false;
                    }
                    if (FileSizeValidation('_FILE') === false)
                        return false;

                    uploadCourseSyllabus_perform();
                }
            },
            cancel: {
                label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                className: 'btn-default',
                callback: function () {
                }
            }
        }
    }).on('shown.bs.modal', function () {
        $("#_FILE").focus();
    });
}

/**
 * Performs the actual course syllabus upload to the server
 * Called internally by uploadCourseSyllabus() after validation
 *
 * @async
 * @returns {Promise<void>}
 */
async function uploadCourseSyllabus_perform() {
    try {
        // FormData automatically captures all form fields including hidden inputs
        const formData = new FormData(document.forms.namedItem("popupfrm"));
        const result = await async_commons.makeApiCall('u_courses_uploadsyllabus_ajax.php', formData);

        const code = result.trim();
        switch (code) {
            case ErrorCodes.SUCCESS: {
                await async_commons.reloadDataTable(DataTable_UCourses);
                await async_commons.showSuccessMessage_reloadPage('UPLOADED', 'Course syllabus has been uploaded!', 2000, false);
                break;
            }
            case ErrorCodes.FILE_SIZE_EXCEED: {
                await async_commons.showErrorMessage(
                    'ERROR',
                    `The file uploaded exceeds the limits (2MB)!`
                );
                break;
            }
            case ErrorCodes.CANNOT_CONNECT_SERVER: {
                await async_commons.showErrorMessage(
                    'ERROR',
                    `Cannot connect to the server!`
                );
                break;
            }
            default: {
                throw new Error('Unexpected server response');
            }
        }
    } catch (error) {
        await async_commons.handleError(error);
    }
}

/**
 * Removes a course syllabus after user confirmation
 *
 * @async
 * @param {string} AVCIdx - Academic Version Course Index
 * @param {string} ABTIdx - Academic Book Type Index
 * @param {string} AcademicYearInfo - Academic Year Information
 * @param {string} CourseSyllabus - Syllabus filename or identifier
 * @returns {Promise<void>}
 */
async function removeSyllabus(AVCIdx, ABTIdx, AcademicYearInfo, CourseSyllabus) {
    const result = await Swal.fire({
        title: "DELETE?",
        html: "Deleted course syllabus cannot be restored!",
        icon: "question",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "Cancel"
    });

    if (!result.value) {
        return;
    }

    try {
        // Make API call
        const response = await async_commons.makeApiCall('u_courses_removecrssyllabus_ajax.php', {
            avcidx: AVCIdx,
            abtidx: ABTIdx,
            ayinfo: AcademicYearInfo,
            csyllabus: CourseSyllabus
        });

        // Handle response
        switch (response.trim()) {
            case "0x11111111":
                // Reload DataTable
                DataTable_UCourses.ajax.reload(null, false);

                // Show success message
                Swal.fire({
                    title: "DELETED!",
                    text: "The selected course syllabus has been deleted!",
                    icon: "success",
                    timer: 2000,
                    timerProgressBar: true,
                    showConfirmButton: false
                });
                break;

            default:
                Swal.fire({
                    title: "ERROR",
                    text: "Unexpected error found. Please contact the system administrator!",
                    icon: "error"
                });
        }

    } catch (error) {
        Swal.fire({
            title: "ERROR",
            text: "Failed to delete syllabus. Please try again.",
            icon: "error"
        });
        console.error('Delete syllabus error:', error);
    }
}