<?php
/**
 * Assign PI
 * Description: assign PI to the selected course
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$AbetCourseIdxes='';
$AcademicYearIdx='';
$GeneralPerformanceIndicators='';

if (array_key_exists('ay', $_POST)
    && array_key_exists('gpi', $_POST)
    && array_key_exists('abetcrs', $_POST))
{
    $AcademicYearIdx = trim($_POST['ay']);
    $GeneralPerformanceIndicators = trim($_POST['gpi']);
    $AbetCourseIdxes = trim($_POST['abetcrs']);
} else {
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYearIdx==""
    || $AcademicProgram==""
    || $GeneralPerformanceIndicators==""
    || $AbetCourseIdxes==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    $AbetCourseIdxes_Array = explode( '|', $AbetCourseIdxes );
    $GPIs_Array = explode( '|', $GeneralPerformanceIndicators );

    $MultiQuery = "";
    foreach ($AbetCourseIdxes_Array AS $AbetCourseIdx) {
        foreach ($GPIs_Array as $GPIs) {
            $res = explode('_', $GPIs); // $GPI[0] -  SOs index, $GPI[1] -  GPI index, $GPI[2] - true / false indicator
            $SOIdx = $res[0];
            $GPIIdx = $res[1];
            $GPIChecked = $res[2];

            $MultiQuery .= "CALL SP_AddCourseMapping_GPI('$GPIIdx', '$AbetCourseIdx', '$SOIdx', '$AcademicYearIdx', '$AcademicProgram', '$GPIChecked');";
        }
    }

//    error_log($MultiQuery);
//	echo ($MultiQuery); exit;
    $DBCONNECTION->sendmultiquery($MultiQuery);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
