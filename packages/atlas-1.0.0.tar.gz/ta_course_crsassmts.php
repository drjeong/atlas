<?php
/**
 * COURSE ASSESSMENTS
 * Description:Listing course assements information for the selected course
 *
 * 09/22/2024 - initial version created
 */

$_ABTCIDX = (isset($_POST['_abtcidx']))?$_POST['_abtcidx']:''; // Abet Course Index
$_ABTCIDXREF = (isset($_POST['_abtcidxref']))?$_POST['_abtcidxref']:''; // Abet Course Index Reference
$_AY = (isset($_POST['_ay']))?$_POST['_ay']:'';           // Academic Year Information
$_AP = (isset($_POST['_ap']))?$_POST['_ap']:'';           // Academic Program Idx
$_SEMTXT = (isset($_POST['_semtxt']))?$_POST['_semtxt']:'';   // Semester Information (ex, 2020 Fall)
$_AVCIDX = (isset($_POST['_avcidx']))?$_POST['_avcidx']:'';   // Available Course Index
$_SUB = (isset($_POST['_sub']))?$_POST['_sub']:'';         // Course Subject
$_NUM = (isset($_POST['_num']))?$_POST['_num']:'';         // Course Num
$_TITLE = (isset($_POST['_title']))?$_POST['_title']:'';     // Course Title
$_CREDITS = (isset($_POST['_credits']))?$_POST['_credits']:''; // Course Credits
$_INSTRUCTOR = (isset($_POST['_instructor']))?$_POST['_instructor']:'';         // Course Instructor
$_TA = (isset($_POST['_ta']))?$_POST['_ta']:'';         // Teaching Assistant
$_ENROLLMENT = (isset($_POST['_enrollment']))?$_POST['_enrollment']:''; // # of students in the course
$_SEM = (isset($_POST['_sem']))?$_POST['_sem']:'';         // Available Course Semester Information
$_CRN = (isset($_POST['_crn']))?$_POST['_crn']:'';         // Available Course CRN Information
$_GPIIDXES = (isset($_POST['_gpiidxes']))?$_POST['_gpiidxes']:'';   // PI Indexes
$_GPIS = (isset($_POST['_gpis']))?$_POST['_gpis']:'';           // PI Information
$_CTROL = (isset($_POST['_ctrol']))?$_POST['_ctrol']:'';         // Control Course Assessments
$_APNAME = (isset($_POST['_apname']))?$_POST['_apname']:'';         // Academic Program Name

if ($_ABTCIDX == '' && $_AVCIDX == ''){
    // illegal entry
    header('Location: main.php');
    exit;
}


include('header.php');

$isReferenceAbetCourse = (!empty($_ABTCIDXREF)) ? true :false;

?>
<script src="js/api_pdfviewer.min.js?v=0.0.1"></script>

<script src="js/datatable-utils-columnvisibility.min.js?v=0.0.004"></script>

<script>
    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        CANNOT_CONNECT_SERVER: '0x00041000',
        INFORMATION_NOT_FOUND: '0x00061000',
        INCORRECT_OPERATION: '0x00000102',
        DUPLICATE_ENTRY: '0x00200011',
        ALREADY_EXISTS: '0x80001010',
        FILE_SIZE_EXCEEDED: '0x00251400',
        FILE_CORRUPTED: '0x00251500'
    };

    let DataTable_Rubrics = null;
    let DataTable_AssessmentMeasures = null;
    let DataTable_cntimprvmnt = null;
    let DataTable_Results_SO = null;
    let DataTable_Results_GPI = null;
    let DataTable_Results_AssessmentMeasures = null;
    let DataTable_Scoresheets = null;

    const scoresheetpage = "u_course_scoresheet.php?_ta=1&_abtcidx=<?php echo($_ABTCIDX);?>&_avcidx=<?php echo($_AVCIDX);?>&_ap=<?php echo($_AP);?>&_semtxt="+encodeURIComponent('<?php echo($_SEMTXT);?>')+"&_sub=<?php echo($_SUB);?>&_num=<?php echo($_NUM);?>&_crn=<?php echo($_CRN);?>&_enrollment=<?php echo($_ENROLLMENT);?>&_title="+encodeURIComponent('<?php echo($_TITLE);?>');
    const assessmentmeasurespage = "u_course_assessmentmeasures.php?_abtcidx=<?php echo($_ABTCIDX);?>&_abtcidxref=<?php echo($_ABTCIDXREF);?>&_ay=<?php echo($_AY);?>&_avcidx=<?php echo($_AVCIDX);?>&_ap=<?php echo($_AP);?>&_semtxt="+encodeURIComponent('<?php echo($_SEMTXT);?>')+"&_sub=<?php echo($_SUB);?>&_num=<?php echo($_NUM);?>&_crn=<?php echo($_CRN);?>&_enrollment=<?php echo($_ENROLLMENT);?>";
    const continuousimprovementspage = "u_course_continuousimprovements.php?_abtcidx=<?php echo($_ABTCIDX);?>&_avcidx=<?php echo($_AVCIDX);?>&_instructor="+encodeURIComponent('<?php echo($_INSTRUCTOR);?>');

    function ReloadResults()
    {
        if (DataTable_Results_AssessmentMeasures) DataTable_Results_AssessmentMeasures.ajax.reload(null, false); // user paging is not reset on reload
        if (DataTable_Results_SO) DataTable_Results_SO.ajax.reload(null, false); // user paging is not reset on reload
        if (DataTable_Results_GPI) DataTable_Results_GPI.ajax.reload(null, false); // user paging is not reset on reload
    }

    function ReloadAssessmentMeasures(reset=false)
    {
        if (DataTable_AssessmentMeasures) {
            if (reset) {
                if ($("#assessmentmeasures").length > 0) {
                    // Check if the assessmentmeasures table exists (indicating page is loaded)
                    if ($("#assessmentmeasures_tbl").length > 0) {
                        // Destroy the DataTable first
                        DataTable_AssessmentMeasures.destroy();
                        DataTable_AssessmentMeasures = null;
                    }

                    // Always reload the page content when reset is true
                    $("#assessmentmeasures").html('').load(assessmentmeasurespage);
                }
            }
            else {
                DataTable_AssessmentMeasures.ajax.reload(null, false);
            }
        }
    }

    function ReloadRubrics(reset=false)
    {
        if (DataTable_Rubrics) {
            if (reset) {
                DataTable_Rubrics.ajax.reload(); // user paging is reset on reload
            } else {
                DataTable_Rubrics.ajax.reload(null, false); // user paging is not reset on reload
            }
        }
    }

    function ReloadScoresheet(reset=false)
    {
        if (DataTable_Scoresheets) {
            if (reset) {
                if ($("#scoresheet").length > 0) {
                    // Check if the scoresheets table exists (indicating page is loaded)
                    if ($("#scoresheets_tbl").length > 0) {
                        // Destroy the DataTable first
                        DataTable_Scoresheets.destroy();
                        DataTable_Scoresheets = null;
                    }

                    // Always reload the page content when reset is true
                    $("#scoresheet").html('').load(scoresheetpage);
                }
            }
            else {
                DataTable_Scoresheets.ajax.reload(null, false);
            }
        }
    }

    function ReloadCImprovement()
    {
        $("#continuousimprovements").load(continuousimprovementspage);
    }

</script>


<script class="init">
    $(document).ready(function() {
        if ($("#assessmentmeasures").length > 0) {
            $("#assessmentmeasures").load(assessmentmeasurespage);
        }
        if ($("#scoresheet").length > 0) {
            $("#scoresheet").load(scoresheetpage);
        }
        ReloadCImprovement();

        // Use namespace to avoid removing other click handlers (used in scoresheet page)
        $(document).off('click.closeColumnMenu').on('click.closeColumnMenu', function(event) {
            if (!$(event.target).closest('#columnVisibilityBtn, #columnVisibilityMenu').length) {
                $('#columnVisibilityMenu').hide();
            }
        });
    });
</script>


<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSE ASSESSMENT FOR THE FOLLOWING COURSE</span><br/>
                <span class="smallheadline">ACADEMIC YEAR: <?php echo($_AY); ?> (<?php echo($_SEMTXT);?>)<br/>
                <?php echo("$_SUB $_NUM (CRN:$_CRN) $_TITLE"); ?> <br/>
                INSTRUCTOR: <?php echo($_INSTRUCTOR);?><br/>
                ASSISTANT: <?php echo($_TA);?><br/>
                ACADEMIC PROGRAM NAME: <?php echo($_APNAME); ?></span>
        </p>

        <?php if ($isReferenceAbetCourse) { ?>
            <div class="alert alert-warning" style="width: 80%; margin: 10px auto; text-align: center; padding: 10px;">
                <i class="glyphicon glyphicon-info-sign"></i> <strong>Reference Course:</strong> Only "Scoresheet" and "Continuous Improvement" entries are allowed.
            </div>
        <?php } ?>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <?php
                if ($_CTROL == '1')
                    echo <<<HTML
                    <a href="asst_courses.php">BACK TO THE LIST</a>
HTML;
                else
                    echo <<<HTML
                <a href="asst_courses.php">BACK TO THE LIST</a>
HTML;
                ?>
            </li>
            <li class="nav-item active">
                <a href="#menu2" class="nav-link" onclick="ReloadAssessmentMeasures(true);return false;" data-toggle="tab">Assessment Measures</a>
            </li>
            <li class="nav-item">
                <a href="#menu3" class="nav-link" onclick="ReloadRubrics(true);return false;" data-toggle="tab">Rubrics</a>
            </li>
            <li class="nav-item">
                <a href="#menu4" class="nav-link" onclick="ReloadScoresheet(true);return false;" data-toggle="tab">Scoresheet</a>
            </li>
            <li class="nav-item">
                <a href="#menu5" class="nav-link" onclick="ReloadCImprovement();return false;" data-toggle="tab">Continuous Improvement</a>
            </li>
            <li class="nav-item">
                <a href="#menu6" class="nav-link" onclick="ReloadResults();return false;" data-toggle="tab">Results</a>
            </li>
            <li class="nav-item">
                <a href="#menu7" class="nav-link" onclick="downloadAssessmentReport(<?php echo("'$_AVCIDX', '$_ABTCIDX', '$_AP', '$_AY', '$_SEMTXT', '$_SUB', '$_NUM', '$_CRN'"); ?>);return false;">Download PDF</a>
            </li>
        </ul>

        <?php
        $gpiData = []; // Array to store the database results
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();

        // Fetch GPI information
        $Query2 = "CALL SP_FetchGPIInfo2(?, ?, ?);";
        $results = $DBCONNECTION->prepare_execute_catch_error($Query2, [$_ABTCIDX, $_AY, $_AP]);

        if ($results) {
            while ($row = $results->fetch_assoc()) {
                // Store each row in the array
                $gpiData[] = [
                    'SO' => $row['SO'],
                    'GPI' => $row['GPI'],
                    'GPIIdx' => $row['GPIIdx'],
                    'Description' => $row['Description']
                ];
            }
        }
        unset($DBCONNECTION);
        ?>

        <div class="tab-content">
            <div id="menu2" class="tab-pane fade in active">
                <h3>Assessment Measures</h3>
                <div id="assessmentmeasures"><!-- assessmentmeasures data here --></div>
                <p><?php //include('u_course_assessmentmeasures.php');?></p>
            </div>
            <div id="menu3" class="tab-pane fade">
                <h3>Rubrics</h3>
                <p><?php include('u_course_rubrics.php');?></p>
            </div>
            <div id="menu4" class="tab-pane fade">
                <h3>Scoresheet</h3>
                <div id="scoresheet"><!-- scoresheet data here --></div>
                <p><?php //include('u_course_scoresheet.php');?></p>
            </div>
            <div id="menu5" class="tab-pane fade">
                <h3>Continuous Improvement</h3>
                <div id="continuousimprovements"><!-- continuousimprovements data here --></div>
                <p><?php //include('u_course_continuousimprovements.php');?></p>
            </div>
            <div id="menu6" class="tab-pane fade">
                <h3>Results</h3>
                <p><?php include('u_course_results.php');?></p>
            </div>
        </div>

    </div>
</div>


<?php include('footer.php');?>

