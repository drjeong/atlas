<?php

/**
 * Management of Syllabus of Courses
 * Description: Show differences of student outcomes in two academic years
 * Author: Dong Hyun Jeong
 *
 * 10/17/2024 - initial version created
 *
 */

include('header.php');

$_AY1 = '';
$_AY2 = '';

if (array_key_exists('_AY1', $_POST)
    && array_key_exists('_AY2', $_POST) )
{
    $_AY1 = trim($_POST['_AY1']);
    $_AY2 = trim($_POST['_AY2']);
}

if ($_AY1=="" || $_AY2==""){
    // no required information
    exit;
}

// using convertTextList function
require_once(__DIR__ . '/php_include/listfunc.php');

// fetch academic years
require_once('inc_academicyear_selection.php');
$ListAcademicYears = ListOfAcademicYears();

//--------------------------------- DB PROCESS ------------------------------------------------------
require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

// Fetching abet syllabus information for different versions
$results = $DBCONNECTION->callStoredProcedure('SP_FetchSO_DiffInfo', [$_AY1, $_AY2, $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

// Check if results are returned
$data = null;
$_AY1Text = '';
$_AY2Text = '';
$AcademicProgramText = '';
if ($results) {
    // Fetch and display the results
    while ($row = $results->fetch_assoc()) {
        if ($_AY1Text == ''){
            $_AY1Text = $row['AcademicYear_1'];
            $_AY2Text = $row['AcademicYear_2'];
            $AcademicProgramText = $row['Name'] . " (".$row['Degree'].")";
        }

        if ($row['TobeRemoved_1'] == 1)
            $row['Description_1'] = '<s>' . $row['Description_1'] . '</s>';

        $data[] = $row;
    }
}


?>

<script type="text/javascript">

    function Back2SOList()
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_so.php");
        $("body").append($form);
        $form.submit();
    }

    function DownloadDiff()
    {
        // Show the full page spinner
        showFullPageSpinner();

        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
            xmlhttp.responseType = "blob";
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                // Hide spinner and show notification
                hideFullPageSpinner();

                const blob = xmlhttp.response;
                if (blob.type === "application/pdf") {
                    // let blob=new Blob([data], { type: "application/pdf" });
                    let link=document.createElement('a');
                    link.href=window.URL.createObjectURL(blob);

                    <?php
                    $AcademicProgramText_Tmp = $AcademicProgramText;
                    $AcademicProgramText_Tmp = str_replace(" ","_",strtolower($AcademicProgramText_Tmp));
                    $AcademicProgramText_Tmp = str_replace("(","_",strtolower($AcademicProgramText_Tmp));
                    $AcademicProgramText_Tmp = str_replace(")","_",strtolower($AcademicProgramText_Tmp));

                    $PDF_FileName = 'abet_so';
                    $PDF_FileName .= '_'. $AcademicProgramText_Tmp;
                    $PDF_FileName .= '_'. str_replace(" ","_",strtolower($_AY1Text));
                    $PDF_FileName .= '_'. str_replace(" ","_",strtolower($_AY2Text));
                    $PDF_FileName .= '_diff.pdf';
                    ?>
                    link.download="<?php echo($PDF_FileName); ?>";
                    link.click();

                    // Clean up
                    setTimeout(() => {
                        window.URL.revokeObjectURL(link.href);
                    }, 100);
                }
                else {
                    Swal.fire({title:"ERROR", text: "Unknown error found. Please contact the system administrator!!", icon:"error"});
                }
            }
        }
        const param = "create_so_diff_pdf.php?_AY1=<?php echo($_AY1); ?>&_AY2=<?php echo($_AY2); ?>";
        xmlhttp.open("GET", param, true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send();
    }
</script>

<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;">
            <span class="largeheadline">&nbsp;STUDENT OUTCOMES DIFFERENCES</span><br>
            <span class="largeheadline2">&nbsp;<?php echo($AcademicProgramText);?></span>
        </p>
	</div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
			<td style="width:50%">
                <ul class="nav nav-tabs" style="width:fit-content;">
                    <li class="nav-item"><a href="" onclick="Back2SOList(); return false;" style="color: white; background-color: #007bff; padding: 8px 15px;">BACK TO THE STUDENT OUTCOMES LIST</a></li>
                </ul>
            </td>
			<td style="width:50%; text-align:right">
                <button class="btn btn-success btn-sm glyphicon glyphicon-floppy-save" onclick="DownloadDiff()">&nbsp;Download Difference</button>
            </td>
		</tr>
		</table>

		<div class="CSSTable_SSPSLIST">
                <table style="border-spacing:0; padding:0; width:100%; ">
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:150px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Academic Year</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt; font-weight: bold;">
                                    <?php echo($_AY1Text); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt; font-weight: bold;"><?php echo($_AY2Text); ?>
                                </div>
                            </div>
                        </td>
                    </tr>

                    <?php

                    foreach ($data as $row) {

                        list($row['Description_1'], $row['Description_2']) = highlightDifferences($row['Description_1'], $row['Description_2']);
                    ?>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:150px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;"><?php echo($row['SO']); ?></span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo($row['Description_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;"><?php echo($row['Description_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </table>
		</div>



        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;">
                <span class="smallheadline">STUDENT OUTCOMES REVISION </span>
            </p>
        </div>
        <div class="CSSTable_SSPSLIST">
            <table style="border-spacing:0; padding:0; width:100%; ">
                <tr>
                    <td>
                        <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                            <div style="width:150px; background-color:#efbd47;">
                                <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Academic Year</span>
                            </div>
                            <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                <?php echo($_AY1Text); ?>
                            </div>
                            <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;"><?php echo($_AY2Text); ?>
                            </div>
                        </div>
                    </td>
                </tr>

                <?php

                foreach ($data as $row) {
                    if ($row['Comments_1']=='' && $row['Comments_2']=='') continue;

                    ?>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:150px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;"><?php echo($row['SO']); ?></span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php if ($row['Comments_1']!='') echo("- ".$row['Comments_1'] . " <br> - " . $row['Approval_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;"><?php if ($row['Comments_2']!='') echo("- ".$row['Comments_2'] . " <br> - " . $row['Approval_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </table>
        </div>



        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-edit" onclick="Back2SOList();">&nbsp;BACK TO THE STUDENT OUTCOMES LIST</button>
                </td>
            </tr>
        </table>

    </div>
</div>


<?php include('footer.php');?>
