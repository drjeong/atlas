<?php
/**
 * Removing All Abet courses
 * Description: removing the selected course from DB.
 * Author: Dong Hyun Jeong
 *
 * 03/30/2024 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$AcademicYearIdx='';
if (array_key_exists('ay', $_POST))
{
    $AcademicYearIdx = trim($_POST['ay']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYearIdx=="" || $AcademicProgram==""){
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    $query = "CALL SP_RemoveAllCMs(?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error(
        $query,
        [$AcademicYearIdx, $AcademicProgram]
    );

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x09000010') !== false) {
        echo '0x09000010';  // Cannot delete: Student Outcome is referenced in Courses
    } else if (strpos($errorMessage, '0x09000011') !== false) {
        echo '0x09000011';  // Cannot delete: Student Outcome is referenced in Performance Indicators
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
