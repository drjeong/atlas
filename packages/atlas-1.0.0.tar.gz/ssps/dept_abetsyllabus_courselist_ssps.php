<?php
/**
 * Listing courses
 * Description: listing courses in a dialog window
 *
 * 11/19/2024 - initial version created
 *
 */

include_once 'session_handler.php';


$AcademicYearIdx='';
if (array_key_exists('_AY', $_GET))
{
    $AcademicYearIdx = trim($_GET['_AY']);
}

$AcademicProgramIdx = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];
if (!isset($AcademicYearIdx) || !isset($AcademicProgramIdx)) {
    die(json_encode(['error' => 'Missing required parameters']));
}

// DB table to use
$table = 'Courses';

$joinQuery = "FROM `{$table}` AS `CRSES` 
    LEFT JOIN `AbetSyllabus` AS `ABS`
            ON (`CRSES`.`Idx` = `ABS`.`CourseIndex` AND `AcademicProgram` = {$AcademicProgramIdx})";


// Table's primary key
$primaryKey = '`CRSES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`CRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`CRSES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`CRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`CRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`CRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`CRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits')
);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = " (`ABS`.`AcademicProgram` <> {$AcademicProgramIdx} OR `ABS`.`AcademicProgram` IS NULL) ";

$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

