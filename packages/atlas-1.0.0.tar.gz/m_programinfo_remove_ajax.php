<?php
/**
 * Management of Academic Degree Programs
 * Description: removing the selected academic degree program
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 *
 */

include('checker_systemadmin.php');

$IDX = (isset($_POST['id'])) ? trim($_POST['id']) : '';

if ($IDX==""){
	echo "0x00000011"; 
	exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $IDX = filter_var($IDX, FILTER_VALIDATE_INT);
    if ($IDX === false) {
        throw new Exception('Invalid Index format');
    }

    $query = "CALL SP_RemoveProgram(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$IDX]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x09000010') !== false) {
        echo '0x09000010';  // Cannot delete: the item is already in use.
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
