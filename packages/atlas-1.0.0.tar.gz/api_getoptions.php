<?php
/**
 * Fetch Data
 * Description: Fetching Academic Year Options
 * Author: Dong Hyun Jeong
 *
 * 11/28/2024 - initial version created
 */

if( !isset($_SESSION)) { session_start(); }
if( !isset($_SESSION['ATLAS_LOGIN_USERIDX']) ) exit;

function handleRequest() {
    if (!isset($_GET['sel'], $_GET['op'])) {
        return sendErrorResponse('Missing required parameters');
    }

    $selector = strtolower(trim($_GET['sel']));
    $option = (int)$_GET['op'];

    $handlers = [
        'so' => [ // dept_so.php
            1 => 'getAcademicYears_DuplicateSOs',
            2 => 'getAcademicYears_ShowDifferencesInTwoSOs',
            3 => 'getAcademicYears_DuplicateCrossProgramSOs'
        ],
        'pi' => [ // dept_pi.php
            0 => 'getAvailableStudentOutcomes',
            1 => 'getAcademicYears_DuplicatePIs',
            2 => 'getAcademicYears_ShowDifferencesInTwoPIs',
            3 => 'getAcademicYears_DuplicateCrossProgramPIs'
        ],
        'amr' => [ // dept_assmntrubrics.php
            2 => 'getAcademicYears_ShowDifferencesInTwoAMRs'
        ],
        'cm' => [ // dept_coursemapping.php
            1 => 'getAcademicYears_DuplicateCMs',
            4 => 'isAddCMItemPossible'
        ]

    ];

    if (!array_key_exists($selector, $handlers)) {
        return sendErrorResponse('Invalid selector');
    }

    if (!array_key_exists($option, $handlers[$selector])) {
        return sendErrorResponse('Invalid option');
    }

    try {
        $handlerFunction = $handlers[$selector][$option];
        if (is_callable($handlerFunction)) {
            return $handlerFunction();
        }
        return sendErrorResponse('Handler not implemented');
    } catch (Exception $e) {
        return sendErrorResponse($e->getMessage());
    }
}

function sendErrorResponse($message) {
    header('Content-Type: application/json');
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $message
    ]);
    exit;
}

// Execute the request handler
handleRequest();


function isAddCMItemPossible() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_IsAddCMPossible(?, ?);";
        $params = [$_SESSION['ATLAS_SELECTED_ACADEMICYEAR'], $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']];
        $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

        $data = '';
        if ($result && $DBCONNECTION->num_rows() > 0) {
            $row = $DBCONNECTION->fetch_assoc();
            $data = $row["Possibility"];
        }

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred',
            'query' => $DBCONNECTION->FormatQuery($query, $params)
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}

function getAcademicYears_DuplicateCMs() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchAcademicYears_CMExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);
//        error_log("CALL SP_FetchAcademicYears_CMExistence_InProgram(?);".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);

        $data1 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data1[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        $query = "CALL SP_FetchAcademicYears_CMNonExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error(
            $query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]
        );

        $data2 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data2[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        $data = [
            'inProgram' => $data1,
            'notInProgram' => $data2
        ];

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}

function getAcademicYears_ShowDifferencesInTwoAMRs() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchAcademicYears_AMRExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

        $data = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}


function getAcademicYears_DuplicateCrossProgramPIs() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchAcademicYears_PIExistence_InOtherPrograms(?);";
//        error_log($query. $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']);
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

        $data1 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data1[] = array(
                    'value' => $row["AYIdx"] . '_' . $row["APIdx"],
                    'text' => $row["Name"] . ' ('. $row["AcademicYear"] . ')'
                );
            }
        }

        $query = "CALL SP_FetchAcademicYears_PINonExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);
        $data2 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data2[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        $data = [
            'inProgram' => $data1,
            'notInProgram' => $data2
        ];

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}

function getAcademicYears_ShowDifferencesInTwoPIs() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchAcademicYears_PIExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

        $data = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}


function getAcademicYears_DuplicatePIs() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchAcademicYears_PIExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

        $data1 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data1[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        $query = "CALL SP_FetchAcademicYears_PINonExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error(
            $query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]
        );

        $data2 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data2[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        $data = [
            'inProgram' => $data1,
            'notInProgram' => $data2
        ];

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}


function getAvailableStudentOutcomes() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchSOs(?, ?);";
        $params = [$_SESSION['ATLAS_SELECTED_ACADEMICYEAR'], $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']];
        $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

        $data = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["SO"]
                );
            }
        }

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}

function getAcademicYears_DuplicateCrossProgramSOs() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchAcademicYears_SOExistence_InOtherPrograms(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

        $data1 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data1[] = array(
                    'value' => $row["AYIdx"] . '_' . $row["APIdx"],
                    'text' => $row["Name"] . ' ('. $row["AcademicYear"] . ')'
                );
            }
        }

        $query = "CALL SP_FetchAcademicYears_SONonExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);
        $data2 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data2[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        $data = [
            'inProgram' => $data1,
            'notInProgram' => $data2
        ];

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}

function getAcademicYears_ShowDifferencesInTwoSOs() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchAcademicYears_SOExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

        $data = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}

function getAcademicYears_DuplicateSOs() {

    try {
        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $query = "CALL SP_FetchAcademicYears_SOExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

        $data1 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data1[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }


        $query = "CALL SP_FetchAcademicYears_SONonExistence_InProgram(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

        $data2 = array();
        if ($result && $DBCONNECTION->num_rows() > 0) {
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $data2[] = array(
                    'value' => $row["Idx"],
                    'text' => $row["AcademicYear"]
                );
            }
        }

        $data = [
            'inProgram' => $data1,
            'notInProgram' => $data2
        ];

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;
    } catch (mysqli_sql_exception $e) {
        error_log($e->getMessage());   // Log DB error
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => 'Database error occurred'
        ]);
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ]);
        exit;
    }
}
