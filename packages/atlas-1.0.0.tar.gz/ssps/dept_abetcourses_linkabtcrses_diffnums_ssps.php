<?php
/**
 * Listing abet courses
 * File: dept_abetcourses_shared_diffsubj_ssps.php
 * Description: listing only shared abet courses (having different course numbers) for multiple degree programs
 *
 * 03/12/2026 - initial version created
 * 08/09/2026 - Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */

require_once 'json_response_handler.php';

$AcademicYear = '';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = '';
$joinQuery = " FROM (
    SELECT 
        A.`Idx`, A.`AVCIdx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Requirement`, A.`Semester`, A.`CRN`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`Syllabus`, A.`AcademicProgramName`, 
        A.`Degree`, A.`Survey`, A.`Enrollment`, A.`Linked`, A.`Reference`,        
        GROUP_CONCAT(DISTINCT A.`Instructor` ORDER BY A.`Instructor` SEPARATOR ', ') as `Instructor`,
        GROUP_CONCAT(DISTINCT A.`Email` ORDER BY A.`Email` SEPARATOR ', ') as `Email`,
        GROUP_CONCAT(DISTINCT B.`SO` ORDER BY B.`SO` SEPARATOR ', ') as `StudentOutcomes`,
        GROUP_CONCAT(DISTINCT B.`SOIdx` ORDER BY B.`SO` SEPARATOR ', ') as `SOIdxes`,
        GROUP_CONCAT(DISTINCT B.`PIIdx` ORDER BY B.`SO`, B.`PI` SEPARATOR ', ') as `PIIdxes`,
        GROUP_CONCAT(DISTINCT CONCAT_WS('-', B.`SO`, B.`PI`) ORDER BY B.`SO`, B.`PI` SEPARATOR ', ') as `PIs`,
        MAX(IFNULL(C.`HasClassRoster`, 0)) as `HasClassRoster`,
        MAX(IFNULL(E.`HasAssessment`, 0)) as `ExistCrsAssessment`,
        A.`SharedPrograms`,
        A.`SharedCourseNumbers`,
        A.`ReferenceGroupId`,
        A.`IsReferenceCourse`
    FROM (
        SELECT 
            `ABETCRSES`.`Idx`, 
            `ABETCRSES`.`AcademicYear`, 
            `ABETCRSES`.`Level`, 
            `ABETCRSES`.`AcademicProgram`, 
            `ABETCRSES`.`Requirement`, 
            `ABETCRSES`.`Syllabus`,
            `ABETCRSES`.`Linked`,
            `ABETCRSES`.`Reference`,
            `AYS`.`AcademicYear` AS `AcademicYearInfo`, 
            `SMSTRS`.`Explanation` AS `Semester`,
            `AVCRSES`.`Idx` AS `AVCIdx`,
            `AVCRSES`.`CRN`, 
            `AVCRSES`.`Subject`, 
            `AVCRSES`.`Num`, 
            `AVCRSES`.`Title`, 
            `AVCRSES`.`Survey`, 
            `AVCRSES`.`Credits`, 
            `AVCRSES`.`Actual` AS `Enrollment`,
            `ACDEMICPRMS`.`Name` AS `AcademicProgramName`,
            `ACDEMICPRMS`.`Degree`,
            `UA`.`Name` AS `Instructor`, 
            `UA`.`Email`,
            `SHARED`.`SharedPrograms`,
            `SHARED`.`SharedCourseNumbers`,
            `SHARED`.`ReferenceGroupId`,
            IF(`ABETCRSES`.`Reference` IS NOT NULL, 'Yes', 'No') AS `IsReferenceCourse`
        FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AVCourses` AS `AVCRSES` 
            ON `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`
        LEFT JOIN `Semesters` AS `SMSTRS`
            ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` 
            ON `AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`
        LEFT JOIN `UserAccounts` AS `UA` 
            ON `AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`
        INNER JOIN `AcademicYears` AS `AYS` 
            ON `ABETCRSES`.`AcademicYear` = `AYS`.`Idx`
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` 
            ON `ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`
        INNER JOIN (
            SELECT 
                `AC1`.`Idx` AS `CourseIdx`,
                -- ReferenceGroupId: Use Reference value if it exists (this is a reference course),
                -- otherwise use the course's own Idx (this is a primary course)
                IFNULL(`AC1`.`Reference`, `AC1`.`Idx`) AS `ReferenceGroupId`,
                COUNT(DISTINCT `AC2`.`Idx`) AS `CourseCount`,
                COUNT(DISTINCT `AC2`.`AcademicProgram`) AS `ProgramCount`,
                COUNT(DISTINCT CONCAT(`AVC2`.`Subject`, '-', `AVC2`.`Num`)) AS `CourseNumberCount`,
                GROUP_CONCAT(DISTINCT `AP2`.`Name` ORDER BY `AP2`.`Name` SEPARATOR ', ') AS `SharedPrograms`,
                GROUP_CONCAT(DISTINCT CONCAT(`AVC2`.`Subject`, '-', `AVC2`.`Num`) ORDER BY `AVC2`.`Subject`, `AVC2`.`Num` SEPARATOR ', ') AS `SharedCourseNumbers`
            FROM `AbetCourses` AS `AC1`
            INNER JOIN `AbetCourses` AS `AC2` 
                ON (
                    -- Join courses that belong to the same group
                    -- For AC1: Use Reference if exists (reference course), else use Idx (primary course)
                    -- For AC2: Use Reference if exists (reference course), else use Idx (primary course)
                    IFNULL(`AC1`.`Reference`, `AC1`.`Idx`) = IFNULL(`AC2`.`Reference`, `AC2`.`Idx`)
                )
            INNER JOIN `AVCourses` AS `AVC2` ON `AC2`.`AVCourseIdx` = `AVC2`.`Idx`
            INNER JOIN `AcademicPrograms` AS `AP2` ON `AC2`.`AcademicProgram` = `AP2`.`Idx`
            -- Only include courses where Linked = 1 (part of a linked group)
            WHERE `AC1`.`Linked` = 1 AND `AC2`.`Linked` = 1
            GROUP BY `AC1`.`Idx`, ReferenceGroupId
            -- Only show groups with at least 2 courses
            HAVING COUNT(DISTINCT `AC2`.`Idx`) >= 2
        ) AS `SHARED` ON `ABETCRSES`.`Idx` = `SHARED`.`CourseIdx`
    ) AS A
    LEFT JOIN (
        SELECT 
            `ABETCRSES`.`Idx` AS `AbetCourseIdx`, 
            `ABETCRSES`.`AcademicYear`, 
            `ABETCRSES`.`AcademicProgram`, 
            `STNTOUTCMS`.`Idx` AS `SOIdx`, 
            `STNTOUTCMS`.`SO`, 
            `GPIS`.`Idx` AS `PIIdx`, 
            `GPIS`.`GPI` AS `PI`
        FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` 
            ON `ABETCRSES`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx`
        LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` 
            ON `ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx` 
            AND `ABETCRSES_GPIS`.`AbetCourseIdx` = `ABETCRSES_SOS`.`AbetCourseIdx`
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` 
            ON `ABETCRSES_SOS`.`SOIdx` = `STNTOUTCMS`.`Idx`
        LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON `GPIS`.`Idx` = `ABETCRSES_GPIS`.`GPIIdx`
    ) AS B ON A.`Idx` = B.`AbetCourseIdx` 
        AND A.`AcademicYear` = B.`AcademicYear` 
        AND A.`AcademicProgram` = B.`AcademicProgram`
    LEFT JOIN (
        SELECT 
            `AvailableCourseIdx`, 
            IF(COUNT(*) > 0, 1, 0) AS `HasClassRoster`
        FROM `ClassRoster`
        GROUP BY `AvailableCourseIdx`
    ) AS C ON A.`AVCIdx` = C.`AvailableCourseIdx`
    LEFT JOIN (
        SELECT 
            `AvailableCourseIdx`,
            `AbetCourseIdx`,
            IF(COUNT(*) > 0, 1, 0) AS `HasAssessment`
        FROM `AssessmentMeasures`
        GROUP BY `AvailableCourseIdx`, `AbetCourseIdx`
    ) AS E ON A.`AVCIdx` = E.`AvailableCourseIdx` 
        AND A.`Idx` = E.`AbetCourseIdx`
    GROUP BY 
        A.`Idx`, A.`AVCIdx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Requirement`, A.`Semester`, A.`CRN`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`Syllabus`, A.`AcademicProgramName`, 
        A.`Degree`, A.`Survey`, A.`Enrollment`, A.`Linked`, A.`Reference`,
        A.`SharedPrograms`, A.`SharedCourseNumbers`, A.`ReferenceGroupId`, A.`IsReferenceCourse`
    ORDER BY A.`ReferenceGroupId` ASC, A.`IsReferenceCourse` ASC, A.`Semester` ASC, A.`CRN` ASC, A.`Subject` ASC, A.`Num` ASC, A.`AcademicProgramName` ASC
) AS combined";

// Table's primary key
$primaryKey = '`Idx`';

// Array of database columns which should be read and sent back to DataTables.
$columns = array(
    array(
        'db' => '`Idx`',
        'dt' => 'DT_RowId',
        'field' => 'DT_RowId',
        'as' => 'DT_RowId',
        'formatter' => function($d, $row) {
            return 'row_' . $d;
        }
    ),
    array('db' => '`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array('db' => '`AVCIdx`', 'dt' => 'AVCIdx', 'field' => 'AVCIdx', 'as' => 'AVCIdx'),
    array('db' => '`Enrollment`', 'dt' => 'Enrollment', 'field' => 'Enrollment', 'as' => 'Enrollment'),
    array('db' => '`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array('db' => '`AcademicyearInfo`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array('db' => '`Requirement`', 'dt' => 'Requirement', 'field' => 'Requirement', 'as' => 'Requirement'),
    array('db' => 'FUNC_GetCourseLevel(`Level`)', 'dt' => 'Level', 'field' => 'Level', 'as' => 'Level'),
    array('db' => '`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array('db' => '`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array('db' => '`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array('db' => '`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array('db' => '`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array('db' => '`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array('db' => '`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram'),
    array('db' => '`AcademicProgramName`', 'dt' => 'AcademicProgramName', 'field' => 'AcademicProgramName', 'as' => 'AcademicProgramName'),
    array('db' => '`Degree`', 'dt' => 'Degree', 'field' => 'Degree', 'as' => 'Degree'),
    array('db' => '`Instructor`', 'dt' => 'Instructor', 'field' => 'Instructor', 'as' => 'Instructor'),
    array('db' => '`Email`', 'dt' => 'Email', 'field' => 'Email', 'as' => 'Email'),
    array('db' => '`SOIdxes`', 'dt' => 'SOIdxes', 'field' => 'SOIdxes', 'as' => 'SOIdxes'),
    array('db' => '`StudentOutcomes`', 'dt' => 'StudentOutcomes', 'field' => 'StudentOutcomes', 'as' => 'StudentOutcomes'),
    array('db' => '`PIIdxes`', 'dt' => 'PIIdxes', 'field' => 'PIIdxes', 'as' => 'PIIdxes'),
    array('db' => '`PIs`', 'dt' => 'PIs', 'field' => 'PIs', 'as' => 'PIs'),
    array(
        'db' => '`HasClassRoster`',
        'dt' => 'HasClassRoster',
        'field' => 'HasClassRoster',
        'as' => 'HasClassRoster',
        'formatter' => function($d) {
            return (int)$d;
        }
    ),
    array('db' => '`Reference`', 'dt' => 'LinkedCrsAssessment', 'field' => 'LinkedCrsAssessment', 'as' => 'LinkedCrsAssessment'),
    array(
        'db' => '`ExistCrsAssessment`',
        'dt' => 'ExistCrsAssessment',
        'field' => 'ExistCrsAssessment',
        'as' => 'ExistCrsAssessment',
        'formatter' => function($d) {
            return (int)$d;
        }
    ),
    array('db' => '`SharedPrograms`', 'dt' => 'SharedPrograms', 'field' => 'SharedPrograms', 'as' => 'SharedPrograms'),
    array('db' => '`SharedCourseNumbers`', 'dt' => 'SharedCourseNumbers', 'field' => 'SharedCourseNumbers', 'as' => 'SharedCourseNumbers'),
    array('db' => '`ReferenceGroupId`', 'dt' => 'ReferenceGroupId', 'field' => 'ReferenceGroupId', 'as' => 'ReferenceGroupId'),
    array('db' => '`IsReferenceCourse`', 'dt' => 'IsReferenceCourse', 'field' => 'IsReferenceCourse', 'as' => 'IsReferenceCourse')
);

require('ssp.join.class.php');

$extraWhere = "";

if (!empty($AcademicYear) && $AcademicYear !== "all") {
    $AcademicYear = filter_var($AcademicYear, FILTER_VALIDATE_INT);
    if ($AcademicYear !== false) {
        $extraWhere = "combined.`AcademicYear` = $AcademicYear";
    }
}

$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');

try {
    $result =  SSP::joinquery($_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false);
    sendJsonResponse($result);
} catch (Exception $e) {
    error_log('DataTables Error: ' . $e->getMessage());
    sendJsonError('Database error occurred', 500);
}
