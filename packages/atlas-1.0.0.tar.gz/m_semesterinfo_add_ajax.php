<?php
/**
 * Management of Semester Information
 * Description: add semester information
 * Author: Dong Hyun Jeong
 *
 * 08/04/2026 - initial version created
 * 08/05/2026 - revised to handle semester information
 *
 */


include('checker_systemadmin.php');

$SemesterCode = (isset($_POST['semesterCode'])) ? trim($_POST['semesterCode']) : '';
$Explanation = (isset($_POST['explanation'])) ? trim($_POST['explanation']) : '';

if ($SemesterCode=="" || $Explanation==""){
    echo "0x00000011";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate semester code (6 digits)
    $SemesterCode = filter_var($SemesterCode, FILTER_VALIDATE_INT);
    if ($SemesterCode === false || strlen((string)$SemesterCode) !== 6) {
        throw new Exception('Invalid semester code format');
    }

    // Validate explanation
    $Explanation = filter_var($Explanation, FILTER_SANITIZE_STRING);
    if (strlen($Explanation) < 3) {
        throw new Exception('Explanation too short');
    }

    /////////////////////////////////////////////////////////////////////////////////
    // insert item
    $query = "CALL SP_AddSemesterInfo(?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query,
        [$SemesterCode, $Explanation]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    $errorMessage = $e->getMessage();

    if (strpos($errorMessage, '0x00200011') !== false) {
        echo '0x00200011';  // Duplicate entry
    } else {
        echo "0x00000500";  // General DB error
        error_log(json_encode([
            'success' => false,
            'error' => $errorMessage,
            'errorCode' => '0x00000500',
            'file' => __FILE__,
            'line' => __LINE__
        ]));
    }
} catch (Exception $e) {
    error_log("General Error: " . $e->getMessage() .
        " in " . __FILE__ .
        " on line " . __LINE__);
    echo "0x00000000";
} finally {
}