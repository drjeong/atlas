<?php
include_once 'session_handler.php';

$AssessmentMeasureIdx = '';
if (array_key_exists('_ASSM', $_GET)) {
    $AssessmentMeasureIdx = trim($_GET['_ASSM']);
} else {
    // illegal entry
    exit;
}

// DB table to use
$table = 'AssessmentMeasureSamples';
$joinQuery = "FROM `$table` AS `SAMPLES`";

// Table's primary key
$primaryKey = '`SAMPLES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
$columns = array(
    array('db' => '`SAMPLES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId',
        'formatter' => function($d, $row) {
            return 'row_'.$row[0];
        }
    ),
    array('db' => '`SAMPLES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array('db' => '`SAMPLES`.`SampleFile`', 'dt' => 'SampleFile', 'field' => 'SampleFile', 'as' => 'SampleFile'),
);

require('ssp.join.class.php');
$extraWhere = "`SAMPLES`.`AssessmentMeasureIdx` = '$AssessmentMeasureIdx'";
$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery($_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
