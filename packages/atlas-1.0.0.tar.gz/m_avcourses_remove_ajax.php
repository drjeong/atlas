<?php
/**
 * Management of Available Courses
 * Description: remove available courses
 * Author: Dong Hyun Jeong
 *
 * 08/04/2026 - initial version created
 * 08/05/2026 - revised to handle multiple courses with detailed results
 *
 */

include('checker_systemadmin.php');

// Only sysadmin can remove courses
if (!$_SESSION['ATLAS_LOGIN_SYSADMIN']) {
    echo json_encode([
        'success' => false,
        'error' => '0x00000000',
        'message' => 'Unauthorized'
    ]);
    exit;
}

// Get course indices
$courseIndices = isset($_POST['courseIndices']) ? trim($_POST['courseIndices']) : '';

// Validate input
if (empty($courseIndices)) {
    echo json_encode([
        'success' => false,
        'error' => '0x00000001',
        'message' => 'Invalid parameters'
    ]);
    exit;
}

// Convert comma-separated string to array
$indexArray = explode(',', $courseIndices);
$indexArray = array_filter(array_map('intval', $indexArray));

if (empty($indexArray)) {
    echo json_encode([
        'success' => false,
        'error' => '0x00000001',
        'message' => 'Invalid parameters'
    ]);
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    $successfulDeletions = [];
    $failedDeletions = [];

    // Process each course
    foreach ($indexArray as $idx) {
        try {
            $query = "CALL SP_RemoveAvailableCourse(?);";
            $DBCONNECTION->prepare_execute_catch_error($query, [$idx]);

            $successfulDeletions[] = $idx;

        } catch (mysqli_sql_exception $e) {
            $errorMessage = $e->getMessage();
            $errorCode = $e->getCode();

            $errorType = 'Unknown error';
            $errorCodeStr = '0x00000500';

            // Check for custom error codes from stored procedure
            if ($errorCode == 1644) { // SIGNAL SQLSTATE '45000'
                if (strpos($errorMessage, '0x09000010') !== false) {
                    $errorType = 'Course is in use (has assessments)';
                    $errorCodeStr = '0x09000010';
                } else if (strpos($errorMessage, '0x00200012') !== false) {
                    $errorType = 'Course not found';
                    $errorCodeStr = '0x00200012';
                } else if (strpos($errorMessage, '0x00000001') !== false) {
                    $errorType = 'Invalid course index';
                    $errorCodeStr = '0x00000001';
                } else {
                    $errorType = 'Database error';
                    $errorCodeStr = '0x00000500';
                }
            }

            $failedDeletions[] = [
                'idx' => $idx,
                'error' => $errorType,
                'errorCode' => $errorCodeStr
            ];
        }
    }

    $totalProcessed = count($indexArray);
    $successCount = count($successfulDeletions);
    $failCount = count($failedDeletions);

    // Return detailed results
    $response = [
        'totalProcessed' => $totalProcessed,
        'successCount' => $successCount,
        'failCount' => $failCount,
        'successful' => $successfulDeletions,
        'failed' => $failedDeletions
    ];

    if ($successCount === $totalProcessed) {
        // All courses deleted successfully
        $response['success'] = true;
        $response['status'] = 'all_success';
        $response['code'] = '0x11111111';
    } else if ($successCount === 0) {
        // All courses failed
        $response['success'] = false;
        $response['status'] = 'all_failed';
        $response['code'] = $failedDeletions[0]['errorCode'];
    } else {
        // Partial success
        $response['success'] = true;
        $response['status'] = 'partial_success';
        $response['code'] = '0x09000011';
    }

    echo json_encode($response);

} catch (mysqli_sql_exception $e) {
    error_log("SQLException in m_avcourses_remove_ajax.php: Code=" . $e->getCode() . ", Message=" . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => '0x00000500',
        'message' => 'Database error'
    ]);

} catch (Exception $e) {
    error_log("Exception in m_avcourses_remove_ajax.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => '0x00000000',
        'message' => 'General error'
    ]);
}
