<?php
/**
 * Management of Syllabus of Master Courses
 * Description: managing courses
 * Author: Dong Hyun Jeong
 *
 * 09/29/2024 - initial version created
 *
 */

//include('checker_programdirector.php');
include('header.php');

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

?>

<script src="js/datatable-utils-holdsearch.min.js"></script>
<script src="js/datatable-utils-search.min.js"></script>
<script src="js/datatable-utils-rowselector.min.js?v=0.0.001"></script>
<script src="js/datatable-utils-columnvisibility.min.js?v=0.0.004"></script>

<script>

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        SAME_ITEM_EXIST: '0x00200011',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
    };

    let DataTable_Courses = null;

    async function removeSyllabus(SyllabusIdx, CourseIdx, Subject, Num, Title, Version) {
        // if (Version === '1.0') {
        //     Swal.fire({
        //         title: "ERROR",
        //         text: "You are not allowed to remove syllabus version 1.0!!",
        //         icon: "error"
        //     });
        //     return;
        // }

        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted syllabus (<span style="color:red">${Subject} ${Num} ${Title} Version${Version}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('dept_abetsyllabus_remove_ajax.php', {
                sid: SyllabusIdx,
                cid: CourseIdx
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected course has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected course cannot be deleted because it is used already.');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    <?php if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) { ?>
    async function downloadSyllabusLatex(SyllabusIndex, Subject, Num) {
        try {
            const latexContent = await async_commons.makeApiCall('create_abetsyllabus_latex.php', {
                _idx: SyllabusIndex
            }, true);

            if (latexContent) {
                // Create a proper Blob object from the LaTeX content
                const blob = new Blob([latexContent], { type: 'text/plain' });

                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);

                // Build LaTeX filename
                let LatexFileName = 'abet_syllabus';
                LatexFileName += '_' + String(Subject).toLowerCase().replace(/ /g, '_');
                LatexFileName += '_' + String(Num).toLowerCase().replace(/ /g, '_');
                LatexFileName += '.tex';

                link.download = LatexFileName;
                link.click();

                // Clean up
                setTimeout(() => {
                    window.URL.revokeObjectURL(link.href);
                }, 100);

                await async_commons.showSuccessMessage('SUCCESS', 'LaTeX file downloaded successfully!');
            } else {
                throw new Error('No content received from server');
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
        }
    }
    <?php } ?>

    async function downloadSyllabus(SyllabusIndex, Subject, Num) {
        try {
            const blob = await async_commons.makeApiCall('create_abetsyllabus_pdf.php', {
                _idx: SyllabusIndex
            }, true, 'blob');

            if (blob.type === "application/pdf") {
                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);

                let AssessmentPDF_FileName = 'abet_syllabus';
                AssessmentPDF_FileName += '_' + String(Subject).toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '_' + String(Num).toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '.pdf';

                link.download = AssessmentPDF_FileName;
                link.click();

                // Clean up
                setTimeout(() => {
                    window.URL.revokeObjectURL(link.href);
                }, 100);

                await async_commons.showSuccessMessage('SUCCESS', 'PDF downloaded successfully!');
            } else {
                throw new Error('Invalid file type received');
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
        }
    }

    function editSyllabusInfo(index, Subject, Num, Title, Credits, Syllabus)
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_abetsyllabus_edit.php");
        $form.append($(document.createElement('input')).attr('name','cindex').val(index));
        $form.append($(document.createElement('input')).attr('name','Subject').val(Subject));
        $form.append($(document.createElement('input')).attr('name','Title').val(Title));
        $form.append($(document.createElement('input')).attr('name','Num').val(Num));
        $form.append($(document.createElement('input')).attr('name','Credits').val(Credits));
        $form.append($(document.createElement('input')).attr('name','targetindex').val(Syllabus));
        $("body").append($form);
        $form.submit();
    }

</script>

<?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
<script>
    async function addCourses_perform(_SELECTEDCOURSES) {
        try {
            const result = await async_commons.makeApiCall('dept_abetsyllabus_add_ajax.php', {
                crses: _SELECTEDCOURSES
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'Course is added!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function addCourses() {

        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                <table id="selectedcouselist" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                        <tr>
                            <th class="toggle-all" style="width:3px"></th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </form>`;

        const rowSelector = new DataTableRowSelector('selectedcouselist', {
            counterId: 'selectedCount',
            toggleButtonId: 'toggleSelected',
            itemName: 'course'
        });

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD COURSES</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ADD",
                    className: 'btn-success',
                    callback: function() {
                        const popupForm = document.getElementById('popupfrm');
                        let selected = rowSelector.getSelectedData();

                        if (!selected.length) {
                            Swal.fire({
                                title: "ERROR",
                                text: "You need to select at least one course!!",
                                icon: "error"
                            });
                            return false;
                        }

                        const selectedCourses = selected.map(course => course.Idx).join('|');
                        addCourses_perform(selectedCourses);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function() {}
                }
            }
        }).on('shown.bs.modal', function() {
        }).find('.modal-dialog').css({
            'margin-top': function() {
                let w = $(window).height();
                let b = $(this).height();
                let h = (w - b) * 0.1;
                return h + "px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"
        }).find('.modal-header').css({
            'cursor': 'move'
        });

        DataTable_CoursesList = $("#selectedcouselist").DataTable({
            processing: true,
            serverSide: false,
            iDisplayLength: 8,
            lengthChange: false,
            select: {
                style: 'multi',
                selector: 'td'
            },
            dom: `t<"row"<"col-sm-6"<"filterControls">><"col-sm-6"p>>`, // add filter controls at the bottom
            initComplete: function() {
                // Initialize the row selector
                rowSelector.init(DataTable_CoursesList);
            },
            ajax: `ssps/dept_abetsyllabus_courselist_ssps.php`,
            order: [[1, 'asc'], [2, 'asc']],
            fnDrawCallback: function() {
                $('#selectedcouselist tr td:nth-child(1)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(2)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(3)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(5)').css('text-align', 'center');

                $('#selectedcouselist tr td:nth-child(2)').css('width', '20px');
                $('#selectedcouselist tr td:nth-child(3)').css('width', '20px');
                $('#selectedcouselist tr td:nth-child(4)').css('width', '200px');
                $('#selectedcouselist tr td:nth-child(5)').css('width', '20px');
                // $('#selectedcouselist tr td:nth-child(4)').css('min-width', '150px');

                rowSelector.updateSelectedCount();
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function(data, type, full, meta) {
                        return '';
                    }
                },
                { data: 'Subject' },
                { data: 'Num' },
                { data: 'Title' },
                { data: 'Credits' }
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets: 'no-sort',
                    orderable: false,
                }
            ]
        });

        // Initialize the column search functionality
        new DataTableSearch('#selectedcouselist', DataTable_CoursesList, false);
    }

    async function downloadSyllabusBulk() {

        // Check if DataTable is empty
        if (DataTable_Courses.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No syllabus available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses and convert to array
        const selected = DataTable_Courses.rows({selected: true}).data().toArray();

        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        // // Check if more than 5 courses are selected
        // if (selected.length > 5) {
        //     Swal.fire({
        //         title: "Too Many Courses Selected",
        //         text: "You can only download up to 5 course binders at a time. Please select 5 or fewer courses.",
        //         icon: "warning"
        //     });
        //     return;
        // }

        // Show confirmation dialog
        const confirmation = await Swal.fire({
            title: 'Confirm Download',
            html: `
            <p>You have selected <strong>${selected.length}</strong> course(s).</p>
            <p style="margin-top: 10px;">Do you want to download the syllabus for all selected courses? It may take several minutes.</p>
        `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, Download All',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            reverseButtons: true
        });

        // If user cancels, exit
        if (!confirmation.isConfirmed) {
            return;
        }

        const totalCourses = selected.length;
        let processedCourses = 0;
        let successCount = 0;
        let errorCount = 0;
        const errorDetails = [];

        // Show progress dialog
        Swal.fire({
            title: 'Downloading Syllabus',
            html: `
            <div>
                <p>Processing course <span id="current-course">0</span> of ${totalCourses}</p>
                <div style="width: 100%; background-color: #e0e0e0; border-radius: 10px; margin-top: 10px;">
                    <div id="progress-bar" style="width: 0%; height: 30px; background-color: #4caf50; border-radius: 10px; transition: width 0.3s;"></div>
                </div>
                <p id="progress-percent" style="margin-top: 10px; font-weight: bold;">0%</p>
                <p id="current-status" style="margin-top: 5px; font-size: 0.9em; color: #666;"></p>
            </div>
        `,
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        // Helper function to safely update DOM elements
        function updateProgress(processed, total, status = '') {
            const progressPercent = Math.round((processed / total) * 100);

            const currentCourseEl = document.getElementById('current-course');
            const progressBarEl = document.getElementById('progress-bar');
            const progressPercentEl = document.getElementById('progress-percent');
            const statusEl = document.getElementById('current-status');

            if (currentCourseEl) currentCourseEl.textContent = processed;
            if (progressBarEl) progressBarEl.style.width = progressPercent + '%';
            if (progressPercentEl) progressPercentEl.textContent = progressPercent + '%';
            if (statusEl && status) statusEl.textContent = status;
        }

        // Download assessment report for each selected course sequentially
        for (let i = 0; i < selected.length; i++) {
            const item = selected[i];

            if (item.Idx) {
                const _SUBJECT = item.Subject;
                const _NUM = item.Num;

                // Update status
                updateProgress(processedCourses, totalCourses, `Downloading: ${_SUBJECT} ${_NUM}`);

                try {
                    // Call DownloadPDF with course-specific parameters
                    const downloadResult = await downloadSyllabusPDFForCourse(item);

                    if (downloadResult) {
                        successCount++;
                    } else {
                        errorCount++;
                        errorDetails.push(`${_SUBJECT} ${_NUM}: Download failed`);
                    }
                } catch (error) {
                    console.error(`Error downloading syllabus for ${_SUBJECT} ${_NUM}:`, error);
                    errorCount++;
                    errorDetails.push(`${_SUBJECT} ${_NUM}: ${error.message || 'Unknown error'}`);
                }

                // Update progress
                processedCourses++;
                updateProgress(processedCourses, totalCourses, `Completed: ${_SUBJECT} ${_NUM}`);

                // Small delay between downloads to prevent overwhelming the server
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        }

        // Close progress dialog
        Swal.close();

        // Show summary
        const summaryHtml = `
        <div style="text-align: left;">
            <p><strong>Total Courses:</strong> ${totalCourses}</p>
            <p><strong>Successfully Downloaded:</strong> ${successCount}</p>
            <p><strong>Failed:</strong> ${errorCount}</p>
            ${errorCount > 0 ? `
                <div style="margin-top: 15px;">
                    <strong>Error Details:</strong>
                    <ul style="text-align: left; max-height: 200px; overflow-y: auto;">
                        ${errorDetails.map(err => `<li>${err}</li>`).join('')}
                    </ul>
                </div>
            ` : ''}
        </div>
    `;

        await Swal.fire({
            title: 'Download Complete',
            html: summaryHtml,
            icon: errorCount === 0 ? 'success' : 'warning',
            confirmButtonText: 'OK'
        });
    }


    // Helper function to download Syllabus PDF for a specific course
    async function downloadSyllabusPDFForCourse(courseItem) {
        try {
            const param = {
                _idx: courseItem.ABSIdx
            };

            const blob = await async_commons.makeApiCall(
                'create_abetsyllabus_pdf.php',
                param,
                false,
                'blob'
            );

            if (blob instanceof Blob) {
                if (blob.type === "application/pdf") {
                    // Create download link
                    const link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);

                    // Generate filename
                    const subject = (courseItem.Subject || '').toLowerCase().replace(/\s+/g, '_');
                    const num = (courseItem.Num || '').toLowerCase().replace(/\s+/g, '_');

                    const filename = `abet_syllabus_${subject}_${num}.pdf`;
                    link.download = filename;
                    link.click();

                    // Clean up
                    setTimeout(() => {
                        window.URL.revokeObjectURL(link.href);
                    }, 100);

                    return true;
                } else if (blob.type === "text/html") {
                    const htmlContent = await blob.text();

                    if (htmlContent === "0x3234234") {
                        console.warn(`Syllabus PDF not available for ${courseItem.Subject} ${courseItem.Num}`);
                        return false;
                    } else {
                        console.error(`Unexpected error for ${courseItem.Subject} ${courseItem.Num}`);
                        return false;
                    }
                } else {
                    console.error(`Unknown blob type for ${courseItem.Subject} ${courseItem.Num}`);
                    return false;
                }
            } else {
                console.error(`Unexpected response type for ${courseItem.Subject} ${courseItem.Num}`);
                return false;
            }
        } catch (error) {
            console.error(`Failed to download PDF for ${courseItem.Subject} ${courseItem.Num}:`, error);
            return false;
        }
    }
</script>
<?php } ?>

<script class="init">
$(document).ready(function() {

    DataTable_Courses = $("#coursesyllabusinfo_list").DataTable({
        dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
        processing: true,
        serverSide: true,
        select: {
            'style': 'multi'
        },
        lengthMenu: [ 50, 100, 150, 300, 500 ],
        search: { regex: true },
        fnInitComplete: function(oSettings, json) {
            // Add "Clear" Filter button
            let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
            btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
            $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function() {
                $('#' + oSettings.sTableId).dataTable().fnFilter('');
            });

            // Column visibility
            new DataTableColumnVisibility(DataTable_Courses, oSettings.sTableId, {
                skipColumns: ['operation', '']  // must be lowercase letters
            }).build();
        },
        ajax: 'ssps/dept_abetsyllabus_list_ssps.php',
        oLanguage: { sInfoFiltered: "" },
        columns: [
            {
                data: null,
                className: 'select-checkbox',
                defaultContent: "",
                orderable: false
            },
            { data: 'Subject', className: 'text-center' },
            { data: 'Num', className: 'text-center' },
            { data: 'Title', className: 'text-center' },
            { data: 'Credits', className: 'text-center' },
            {
                data: 'Pre_requisites',
                className: 'text-left',
                render: function(data, type, row) {
                    if (type === 'display' && data) return data.replace(/\|\|/g, '<br>');
                    return data;
                }
            },
            {
                data: 'Co_requisites',
                className: 'text-left',
                render: function(data, type, row) {
                    if (type === 'display' && data) return data.replace(/\|\|/g, '<br>');
                    return data;
                }
            },
            {
                data: 'Required_Texts',
                className: 'text-left',
                render: function(data, type, row) {
                    if (type === 'display' && data) return data.replace(/\|\|/g, '<br>');
                    return data;
                }
            },
            { data: 'Requirement', className: 'text-center' },
            { data: 'Description', className: 'text-left' },
            {
                data: 'Coordinator',
                className: 'text-center',
                render: function(data, type, row) {
                    if (type === 'display') {
                        return '<span class="coordinator-value" ' +
                            'style="cursor:pointer; display:block;" title="Double-click to edit">' +
                            (data || '&nbsp;') + '</span>';
                    }
                    return data;
                }
            },
            { data: 'Version', className: 'text-center' },
            { data: 'RevisionDesc', className: 'text-left' },
            { data: 'RevisionDate', className: 'text-center' },
            {
                data: 'ApprovalDesc',
                className: 'text-left',
                render: function(data, type, row) {
                    if (type === 'display') {
                        return '<span class="approval-desc-value" ' +
                            'style="cursor:pointer; display:block;" title="Double-click to edit">' +
                            (data || '&nbsp;') + '</span>';
                    }
                    return data;
                }
            },
            {
                data: 'ApprovalDate',
                className: 'text-center',
                render: function(data, type, row) {
                    if (type === 'display') {
                        return '<span class="approval-date-value" ' +
                            'style="cursor:pointer; display:block;" title="Click to edit">' +
                            (data || '&nbsp;') + '</span>';
                    }
                    return data;
                }
            },
            {
                data: 'ABSIdx',
                className: 'text-center',
                render: function(data, type, full, meta) {
                    let content = '<button id="addinfo" alt="Edit Syllabus Info" title="Edit Syllabus Info" class="btn btn-danger btn-xs glyphicon glyphicon-edit" style="min-height: 20px;"></button>&nbsp;';
                    <?php if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) { ?>
                    content += '<button id="remove" alt="Remove Syllabus Info" title="Remove Syllabus Info" class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="min-height: 20px;"></button>&nbsp;';
                    <?php } ?>
                    if (full.ABSIdx !== null && full.RevisionDate !== null) {
                        content += `<button class="btn btn-success btn-xs" id="downloadpdf" title="Download Syllabus"><i class="glyphicon glyphicon-floppy-save"></i> PDF</button>`;
                    }
                    <?php if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) { ?>
                    content += `<button class="btn btn-warning btn-xs" id="downloadlatex" title="Download Syllabus"><i class="glyphicon glyphicon-floppy-save"></i> LATEX</button>`;
                    <?php } ?>
                    return content;
                }
            }
        ],
        order: [[ 0, 'asc' ], [ 1, 'asc' ]],
        fnDrawCallback: function() {
        },
        columnDefs: [{
            targets: 'no-sort',
            orderable: false
        }],
        buttons: [
            {
                extend: 'excelHtml5',
                title: 'ALL COURSES\' MASTER SYLLABUS LIST',
                text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                className: 'btn btn-xs',
                attr: {
                    style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                },
                exportOptions: {
                    columns: ':not(:first-child):not(:last-child)'  // exclude first & last column
                }
            }
        ]
    });

    async_commons.setDataTable(DataTable_Courses);

    // Save individual column searches
    DataTable_Courses.columns().every(function(index) {
        $(this.header()).on('keyup change', 'input', function() {
            localStorage.setItem('dtColSearch_' + index, this.value);
        });
    });

    $('#coursesyllabusinfo_list').on('click', '.toggle-all', function() {
        $(this).closest("tr").toggleClass("selected");
        if($(this).closest("tr").hasClass("selected")){
            DataTable_Courses.rows({ page: 'current' }).select();
        }
        else {
            DataTable_Courses.rows({ page: 'current' }).deselect();
        }
    });

    // ── Coordinator inline editing (DOUBLE-CLICK) ────────────────────────────────────────
    $('#coursesyllabusinfo_list tbody').on('dblclick', 'td:has(.coordinator-value)', function() {
        const span = $(this).find('.coordinator-value');
        if (span.attr('contenteditable') === 'true') return; // already editing
        span.attr('contenteditable', 'true').focus();
        // Select all text
        const range = document.createRange();
        range.selectNodeContents(span[0]);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        // Visual indicator
        span.css({ 'background-color': '#ffffcc', 'padding': '2px 5px', 'border': '1px solid #ccc', 'border-radius': '3px', 'outline': 'none', 'display': 'inline-block', 'min-width': '80px' });
        return false;
    });

    $('#coursesyllabusinfo_list tbody').on('blur', '.coordinator-value', function() {
        const span = $(this);
        const newValue = span.text().trim();
        span.css({ 'background-color': '', 'padding': '', 'border': '', 'border-radius': '', 'display': '' });
        span.attr('contenteditable', 'false');

        const row = DataTable_Courses.row(span.closest('tr'));
        const rowData = row.data();
        const oldValue = rowData.Coordinator || '';

        if (newValue === oldValue) return;

        rowData.Coordinator = newValue;

        $.ajax({
            url: 'dept_abetsyllabus_list_update_approval.php',
            method: 'POST',
            data: {
                ABSIdx:      rowData.ABSIdx,
                Field:       'Coordinator',
                Value:       newValue
            },
            success: function(response) {
                try {
                    const data = typeof response === 'string' ? JSON.parse(response) : response;
                    if (data.success || data.code === '0x11111111') {
                        span.css('background-color', '#d4edda');
                        setTimeout(() => span.css('background-color', ''), 1500);
                        Swal.fire({ title: 'Saved!', text: 'Coordinator updated.', icon: 'success', timer: 1500, showConfirmButton: false });
                    } else {
                        span.text(oldValue);
                        Swal.fire({ title: 'ERROR', text: data.error || 'Failed to update.', icon: 'error', timer: 3000 });
                    }
                } catch(e) {
                    span.text(oldValue);
                    Swal.fire({ title: 'ERROR', text: 'Error processing response.', icon: 'error', timer: 3000 });
                }
            },
            error: function() {
                span.text(oldValue);
                Swal.fire({ title: 'ERROR', text: 'Server error. Please try again.', icon: 'error', timer: 3000 });
            }
        });
    });

    $('#coursesyllabusinfo_list tbody').on('keydown', '.coordinator-value', function(e) {
        if (e.keyCode === 13) { e.preventDefault(); $(this).blur(); }           // Enter = save
        if (e.keyCode === 27) {                                                  // Escape = cancel
            e.preventDefault();
            const rowData = DataTable_Courses.row($(this).closest('tr')).data();
            $(this).text(rowData.Coordinator || '').blur();
        }
    });

    // ── ApprovalDesc inline editing (DOUBLE-CLICK) ────────────────────────────────────────
    $('#coursesyllabusinfo_list tbody').on('dblclick', 'td:has(.approval-desc-value)', function() {
        const span = $(this).find('.approval-desc-value');
        if (span.attr('contenteditable') === 'true') return; // already editing
        span.attr('contenteditable', 'true').focus();
        // Select all text
        const range = document.createRange();
        range.selectNodeContents(span[0]);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        // Visual indicator
        span.css({ 'background-color': '#ffffcc', 'padding': '2px 5px', 'border': '1px solid #ccc', 'border-radius': '3px', 'outline': 'none', 'display': 'inline-block', 'min-width': '80px' });
        return false;
    });

    $('#coursesyllabusinfo_list tbody').on('blur', '.approval-desc-value', function() {
        const span = $(this);
        const newValue = span.text().trim();
        span.css({ 'background-color': '', 'padding': '', 'border': '', 'border-radius': '', 'display': '' });
        span.attr('contenteditable', 'false');

        const row = DataTable_Courses.row(span.closest('tr'));
        const rowData = row.data();
        const oldValue = rowData.ApprovalDesc || '';

        if (newValue === oldValue) return;

        rowData.ApprovalDesc = newValue;

        $.ajax({
            url: 'dept_abetsyllabus_list_update_approval.php',
            method: 'POST',
            data: {
                ABSIdx:      rowData.ABSIdx,
                Field:       'ApprovalDesc',
                Value:       newValue
            },
            success: function(response) {
                try {
                    const data = typeof response === 'string' ? JSON.parse(response) : response;
                    if (data.success || data.code === '0x11111111') {
                        span.css('background-color', '#d4edda');
                        setTimeout(() => span.css('background-color', ''), 1500);
                        Swal.fire({ title: 'Saved!', text: 'Approval description updated.', icon: 'success', timer: 1500, showConfirmButton: false });
                    } else {
                        span.text(oldValue);
                        Swal.fire({ title: 'ERROR', text: data.error || 'Failed to update.', icon: 'error', timer: 3000 });
                    }
                } catch(e) {
                    span.text(oldValue);
                    Swal.fire({ title: 'ERROR', text: 'Error processing response.', icon: 'error', timer: 3000 });
                }
            },
            error: function() {
                span.text(oldValue);
                Swal.fire({ title: 'ERROR', text: 'Server error. Please try again.', icon: 'error', timer: 3000 });
            }
        });
    });

    $('#coursesyllabusinfo_list tbody').on('keydown', '.approval-desc-value', function(e) {
        if (e.keyCode === 13) { e.preventDefault(); $(this).blur(); }           // Enter = save
        if (e.keyCode === 27) {                                                  // Escape = cancel
            e.preventDefault();
            const rowData = DataTable_Courses.row($(this).closest('tr')).data();
            $(this).text(rowData.ApprovalDesc || '').blur();
        }
    });

// ── ApprovalDate inline editing (DOUBLE-CLICK) ────────────────────────────────────────
    $('#coursesyllabusinfo_list tbody').on('dblclick', 'td:has(.approval-date-value)', function() {
        const span = $(this).find('.approval-date-value');
        if (span.attr('contenteditable') === 'true') return;

        span.attr('contenteditable', 'true').focus();
        const range = document.createRange();
        range.selectNodeContents(span[0]);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        span.css({ 'background-color': '#ffffcc', 'padding': '2px 5px', 'border': '1px solid #ccc', 'border-radius': '3px', 'outline': 'none', 'display': 'inline-block', 'min-width': '80px' });
        return false;
    });

    $('#coursesyllabusinfo_list tbody').on('blur', '.approval-date-value', function() {
        const span = $(this);
        const newValue = span.text().trim();
        span.css({ 'background-color': '', 'padding': '', 'border': '', 'border-radius': '', 'display': '' });
        span.attr('contenteditable', 'false');

        const row = DataTable_Courses.row(span.closest('tr'));
        const rowData = row.data();
        const oldValue = rowData.ApprovalDate || '';

        if (newValue === oldValue) return;

        // Basic date format validation (YYYY-MM-DD or MM/DD/YYYY)
        const datePattern = /^(\d{4}-\d{2}-\d{2}|\d{2}\/\d{2}\/\d{4})$/;
        if (newValue !== '' && !datePattern.test(newValue)) {
            Swal.fire({ title: 'Invalid Date', text: 'Please use YYYY-MM-DD or MM/DD/YYYY format.', icon: 'warning', timer: 3000 });
            span.text(oldValue);
            return;
        }

        rowData.ApprovalDate = newValue;

        $.ajax({
            url: 'dept_abetsyllabus_list_update_approval.php',
            method: 'POST',
            data: {
                ABSIdx: rowData.ABSIdx,
                Field:  'ApprovalDate',
                Value:  newValue
            },
            success: function(response) {
                try {
                    const data = typeof response === 'string' ? JSON.parse(response) : response;
                    if (data.success || data.code === '0x11111111') {
                        span.css('background-color', '#d4edda');
                        setTimeout(() => span.css('background-color', ''), 1500);
                        Swal.fire({ title: 'Saved!', text: 'Approval date updated.', icon: 'success', timer: 1500, showConfirmButton: false });
                    } else {
                        span.text(oldValue);
                        Swal.fire({ title: 'ERROR', text: data.error || 'Failed to update.', icon: 'error', timer: 3000 });
                    }
                } catch(e) {
                    span.text(oldValue);
                    Swal.fire({ title: 'ERROR', text: 'Error processing response.', icon: 'error', timer: 3000 });
                }
            },
            error: function() {
                span.text(oldValue);
                Swal.fire({ title: 'ERROR', text: 'Server error. Please try again.', icon: 'error', timer: 3000 });
            }
        });
    });

    $('#coursesyllabusinfo_list tbody').on('keydown', '.approval-date-value', function(e) {
        if (e.keyCode === 13) { e.preventDefault(); $(this).blur(); }
        if (e.keyCode === 27) {
            e.preventDefault();
            const rowData = DataTable_Courses.row($(this).closest('tr')).data();
            $(this).text(rowData.ApprovalDate || '').blur();
        }
    });

    $('#coursesyllabusinfo_list tbody').on( 'click', '#addinfo', function () {
        const data = DataTable_Courses.row( $(this).parents('tr') ).data();
        editSyllabusInfo(data.Idx, data.Subject, data.Num, data.Title, data.Credits, data.ABSIdx);
        return false;
    } );

    $('#coursesyllabusinfo_list tbody').on( 'click', '#downloadpdf', function () {
        const data = DataTable_Courses.row( $(this).parents('tr') ).data();
        downloadSyllabus(data.ABSIdx, data.Subject, data.Num);
        return false;
    } );

    <?php if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) { ?>
    $('#coursesyllabusinfo_list tbody').on( 'click', '#downloadlatex', function () {
        const data = DataTable_Courses.row( $(this).parents('tr') ).data();
        downloadSyllabusLatex(data.ABSIdx, data.Subject, data.Num);
        return false;
    } );
    <?php } ?>

<?php if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) { ?>
    $('#coursesyllabusinfo_list tbody').on( 'click', '#remove', function () {
        const data = DataTable_Courses.row( $(this).parents('tr') ).data();
        removeSyllabus(data.ABSIdx, data.Idx, data.Subject, data.Num, data.Title, data.Version);
        return false;
    } );
<?php } ?>

    // Initialize the column search functionality
    new DataTableHoldSearch('#coursesyllabusinfo_list', DataTable_Courses, true, true);
} );
</script>


<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">MASTER COURSE SYLLABUS SUMMARY LIST</span></p>
    </div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
			<td style="width:50%; text-align: left;">
<?php
    include('control_allprograms.php');
?>
            </td>
			<td style="width:50%; text-align:right">
<?php
if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) {
?>
                <button class="btn btn-danger btn-sm glyphicon glyphicon-envelope" onclick="downloadSyllabusBulk();return false;">&nbsp;DOWNLOAD SYLLABUS</button>&nbsp;
                <button class="btn btn-danger btn-sm" onclick="addCourses();return false;">ADD COURSE</button>
<?php } ?>
            </td>
		</tr>
		</table>

        <style>
            .wrap-cell {
                white-space: normal !important;
                word-wrap: break-word;
                max-width: 200px;
                padding: 8px !important;
            }

            /* Ensure consistent row heights even with multi-line content */
            #coursesyllabusinfo_list tbody tr {
                vertical-align: top;
            }

            /* Enhance readability */
            #coursesyllabusinfo_list tbody tr td {
                padding: 8px;
            }
        </style>

        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="coursesyllabusinfo_list" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th class="toggle-all no-sort" style="width:3px; "></th>
                    <th>SUBJ</th>
                    <th>NUM</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>PRE-REQUISITES</th>
                    <th>CO-REQUISITES</th>
                    <th>REQUIRED TEXTS</th>
                    <th>REQUIREMENT</th>
                    <th>DESCRIPTION</th>
                    <th>COORDINATOR</th>
                    <th>VERSION</th>
                    <th>REVISION DESC</th>
                    <th>REVISION</th>
                    <th>APPROVAL DESC</th>
                    <th>APPROVAL</th>
                    <th class="no-sort" style="width:100px;">OPERATION</th>
                </tr>
                </thead>
                <thead id="serachbox" class="filters">
                <tr>
                    <th></th>
                    <th>SUBJ</th>
                    <th>NUM</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>PRE-REQUISITES</th>
                    <th>CO-REQUISITES</th>
                    <th>REQUIRED TEXTS</th>
                    <th>REQUIREMENT</th>
                    <th>DESCRIPTION</th>
                    <th>COORDINATOR</th>
                    <th>VERSION</th>
                    <th>REVISION DESC</th>
                    <th>REVISION</th>
                    <th>APPROVAL DESC</th>
                    <th>APPROVAL</th>
                    <th></th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th></th>
                    <th>SUBJ</th>
                    <th>NUM</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>PRE-REQUISITES</th>
                    <th>CO-REQUISITES</th>
                    <th>REQUIRED TEXTS</th>
                    <th>REQUIREMENT</th>
                    <th>DESCRIPTION</th>
                    <th>COORDINATOR</th>
                    <th>VERSION</th>
                    <th>REVISION</th>
                    <th>REVISION DESC</th>
                    <th>APPROVAL DESC</th>
                    <th>APPROVAL</th>
                    <th></th>
                </tr>
                </tfoot>
            </table>
        </div>


        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-edit" style="pointer-events: none;"></span>: Edit Syllabus
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Remove Syllabus
                    <?php } ?>
                    <span class="btn btn-success btn-xs glyphicon glyphicon-floppy-save" style="pointer-events: none;"></span>: Download Syllabus
                </td>
            </tr>
        </table>
    </div>
</div>

<!-- On dept_abetsyllabus_list.php before redirecting -->
<?php
$_SESSION['last_list_page'] = 'dept_abetsyllabus_list.php';
?>

<?php include('footer.php');?>
