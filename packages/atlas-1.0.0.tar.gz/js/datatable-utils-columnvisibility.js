/**
 * DataTableColumnVisibility
 * Reusable Show/Hide Columns dropdown for any DataTable instance.
 *
 * Usage:
 *   const cv = new DataTableColumnVisibility(DataTable_Courses, 'coursesyllabusinfo_list', {
 *       skipColumns: ['actions', ''],   // header texts to exclude (case-insensitive)
 *       buttonLabel: 'Show/Hide Columns'
 *   });
 *   cv.build();
 */
class DataTableColumnVisibility {

    constructor(dtInstance, tableId, options = {}) {
        this.dt          = dtInstance;
        this.tableId     = tableId;
        this.wrapperId   = '#' + tableId + '_wrapper';
        this.menuId      = tableId + '_colVisMenu';
        this.btnId       = tableId + '_colVisBtn';
        this.masterId    = tableId + '_colVisMaster';

        // Options with defaults
        this.skipColumns = options.skipColumns  || ['actions', ''];
        this.buttonLabel = options.buttonLabel  || 'SHOW/HIDE COLUMNS';
        this.accentColor = options.accentColor  || '#337ab7';
        this.hoverColor  = options.hoverColor   || '#f0f7ff';
        this.menuWidth   = options.menuWidth    || { min: '220px', max: '320px' };
        this.appendTo    = options.appendTo     || '.dataTables_length'; // where to inject

        // Mark all cells with their column index BEFORE DataTables processes them
        this._markCellIndexes();

        // Setup column visibility event listener
        this._setupVisibilitySync();
    }

    // ── Private: mark all thead/tfoot cells with data-col-index ───
    _markCellIndexes() {
        const self = this;
        const table = $('#' + self.tableId);

        // Mark all thead rows
        table.find('thead tr').each(function() {
            $(this).find('th, td').each(function(idx) {
                $(this).attr('data-col-index', idx);
            });
        });

        // Mark all tfoot rows
        table.find('tfoot tr').each(function() {
            $(this).find('th, td').each(function(idx) {
                $(this).attr('data-col-index', idx);
            });
        });
    }

    // ── Private: setup event listener for column visibility changes ───
    _setupVisibilitySync() {
        const self = this;

        // Listen to DataTables column-visibility event
        self.dt.on('column-visibility.dt', function(e, settings, column, state) {
            setTimeout(function() {
                self._syncHeadersAndFooters();
            }, 10);
        });

        // Also sync after any draw
        self.dt.on('draw.dt', function() {
            setTimeout(function() {
                self._syncHeadersAndFooters();
            }, 10);
        });
    }

    // ── Private: sync all thead and tfoot based on column visibility ───
    _syncHeadersAndFooters() {
        const self = this;
        const table = $('#' + self.tableId);

        // Get visibility state for all columns
        const colVisibility = [];
        self.dt.columns().every(function(idx) {
            colVisibility[idx] = this.visible();
        });

        // Sync ALL thead rows using data-col-index
        table.find('thead tr').each(function(rowIdx) {
            $(this).find('th[data-col-index], td[data-col-index]').each(function() {
                const colIdx = parseInt($(this).attr('data-col-index'));
                const shouldShow = colVisibility[colIdx];

                if (shouldShow) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });

        // Sync tfoot rows using data-col-index
        table.find('tfoot tr').each(function(rowIdx) {
            $(this).find('th[data-col-index], td[data-col-index]').each(function() {
                const colIdx = parseInt($(this).attr('data-col-index'));
                const shouldShow = colVisibility[colIdx];

                if (shouldShow) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
    }

    // ── Public: build and inject the button + menu ─────────────────────
    build() {
        const self = this;

        const container = $('<div>').css({
            position: 'relative',
            display: 'inline-block',
            marginLeft: '8px'
        });

        container.append(self._buildButton());
        container.append(self._buildMenu());

        $(self.wrapperId).find(self.appendTo).append(container);

        // Initial sync
        setTimeout(function() {
            self._syncHeadersAndFooters();
        }, 100);

        // Close on outside click (namespaced to avoid duplicate binds)
        $(document).off('click.colvis_' + self.tableId)
            .on ('click.colvis_' + self.tableId, function(e) {
                if (!$(e.target).closest('#' + self.btnId + ', #' + self.menuId).length) {
                    $('#' + self.menuId).hide();
                }
            });
    }

    // ── Private: toggle button ─────────────────────────────────────────
    _buildButton() {
        const self = this;
        return $('<button>')
            .attr('id', self.btnId)
            .addClass('btn btn-primary btn-sm')
            .css({ fontSize: '11px', padding: '3px 8px', height: '25px', lineHeight: '1.5' })
            .html('<span class="glyphicon glyphicon-th-list"></span> ' + self.buttonLabel)
            .on('click', function(e) {
                e.stopPropagation();
                $('#' + self.menuId).toggle();
            });
    }

    // ── Private: dropdown menu ─────────────────────────────────────────
    _buildMenu() {
        const self = this;

        const menu = $('<div>')
            .attr('id', self.menuId)
            .css({
                display:       'none',
                position:      'absolute',
                left:          '0',
                top:           '100%',
                background:    'white',
                border:        '1px solid #ccc',
                padding:       '10px',
                marginTop:     '5px',
                minWidth:      self.menuWidth.min,
                maxWidth:      self.menuWidth.max,
                boxShadow:     '0 2px 5px rgba(0,0,0,0.2)',
                zIndex:        1000,
                maxHeight:     '400px',
                overflowY:     'auto',
                textAlign:     'left'
            });

        menu.append(self._buildMasterCheckbox());

        // One row per column
        self.dt.columns().every(function(index) {
            const headerText = $(this.header()).text().trim();
            if (self.skipColumns.includes(headerText.toLowerCase())) return;

            menu.append(self._buildColumnRow(index, headerText, this.visible()));
        });

        return menu;
    }

    // ── Private: master "Show All / Hide All" row ──────────────────────
    _buildMasterCheckbox() {
        const self = this;

        const masterDiv = $('<div>').css({
            padding:      '5px 5px 8px 5px',
            borderBottom: '2px solid ' + self.accentColor,
            marginBottom: '5px'
        });

        const masterLabel = $('<label>').css({
            fontWeight: 'bold', cursor: 'pointer', margin: 0, display: 'block'
        });

        const masterCheckbox = $('<input type="checkbox">')
            .attr('id', self.masterId)
            .prop('checked', true)
            .css({ marginRight: '8px', verticalAlign: 'middle' })
            .on('change', function() {
                const isChecked = $(this).is(':checked');
                $('#' + self.menuId + ' input[data-col-index]').each(function() {
                    const colIndex = $(this).data('col-index');
                    $(this).prop('checked', isChecked);
                    self.dt.column(colIndex).visible(isChecked);
                });
            });

        masterLabel.append(masterCheckbox).append($('<span>').text('Show All / Hide All'));
        masterDiv.append(masterLabel);
        return masterDiv;
    }

    // ── Private: individual column row ────────────────────────────────
    _buildColumnRow(index, headerText, isVisible) {
        const self = this;

        const itemDiv = $('<div>').css({ padding: '5px', borderBottom: '1px solid #eee' })
            .on('mouseenter', function() { $(this).css('background', self.hoverColor); })
            .on('mouseleave', function() { $(this).css('background', ''); });

        const label = $('<label>').css({
            fontWeight: 'normal', cursor: 'pointer', margin: 0, display: 'block'
        });

        const checkbox = $('<input type="checkbox">')
            .prop('checked', isVisible)
            .attr('data-col-index', index)
            .css({ marginRight: '8px', verticalAlign: 'top', marginTop: '2px', float: 'left' })
            .on('change', function() {
                const isChecked = $(this).is(':checked');
                self.dt.column(index).visible(isChecked);
                self._updateMaster();
            });

        const span = $('<span>').css({ display: 'block', marginLeft: '25px' }).text(headerText);

        label.append(checkbox).append(span);
        itemDiv.append(label);
        return itemDiv;
    }

    // ── Private: sync master checkbox state ───────────────────────────
    _updateMaster() {
        const all     = $('#' + this.menuId + ' input[data-col-index]');
        const checked = $('#' + this.menuId + ' input[data-col-index]:checked');
        const master  = document.getElementById(this.masterId);
        if (!master) return;

        if (checked.length === 0) {
            master.checked = false; master.indeterminate = false;
        } else if (checked.length === all.length) {
            master.checked = true;  master.indeterminate = false;
        } else {
            master.checked = false; master.indeterminate = true;
        }
    }
}