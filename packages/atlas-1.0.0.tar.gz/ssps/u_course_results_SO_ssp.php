<?php
/**
 * Listing Student Outcomes
 * File: u_course_results_SO_ssp.php
 * Description: listing student outcomes of the selected course
 * Updated: ABET-compliant per-student calculation with detail view
 */

include_once '../ssps/session_handler.php';

// Get parameters
$abetCourseIdx = '';
$availableCourseIdx = '';
$academicProgramIdx = '';

if (array_key_exists('_ABTC', $_GET) && array_key_exists('_AVC', $_GET) && array_key_exists('_AP', $_GET)) {
    $abetCourseIdx = trim($_GET['_ABTC']);
    $availableCourseIdx = trim($_GET['_AVC']);
    $academicProgramIdx = trim($_GET['_AP']);
} else {
    // illegal entry
    exit;
}


require_once('../php_include/dbconnection_class.php');
require_once('StudentOutcomeAnalyzer.php');

try {
    $db = new Dbconnection();
    $analyzer = new StudentOutcomeAnalyzer($db);

    $output = $analyzer->getDataTablesResponse(
        $abetCourseIdx,
        $availableCourseIdx,
        $academicProgramIdx,
        $_GET['draw'] ?? 0
    );

    header('Content-Type: application/json');
    echo json_encode($output);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

//
//
//// Initialize database connection
//$DBCONNECTION = new Dbconnection();
//$data = array();
//
//// Escape inputs for security
//$abetCourseIdx = $DBCONNECTION->real_escape_string($abetCourseIdx);
//$availableCourseIdx = $DBCONNECTION->real_escape_string($availableCourseIdx);
//$academicProgramIdx = $DBCONNECTION->real_escape_string($academicProgramIdx);
//
//// Step 1: Get all Student Outcomes and their measures (through GPIs)
//$soMeasuresQuery = "
//    SELECT
//        STNTOUTCMS.Idx AS SOIdx,
//        STNTOUTCMS.SO AS SO,
//        STNTOUTCMS.Description AS Description,
//        AM.Idx AS MeasureIdx,
//        AM.Measure AS MeasureNumber,
//        GPIS.Idx AS GPIIdx
//    FROM StudentOutcomes AS STNTOUTCMS
//    INNER JOIN GeneralPerformanceIndicators AS GPIS
//        ON (GPIS.SOIdx = STNTOUTCMS.Idx AND GPIS.AcademicProgram = {$academicProgramIdx})
//    INNER JOIN AssessmentMeasures AS AM
//        ON (AM.GPI = GPIS.Idx AND AM.AvailableCourseIdx = {$availableCourseIdx} AND AM.AbetCourseIdx = {$abetCourseIdx})
//    WHERE STNTOUTCMS.AcademicProgram = {$academicProgramIdx}
//    ORDER BY STNTOUTCMS.Idx, AM.Measure
//";
//
//$soMeasuresResults = $DBCONNECTION->sendquery($soMeasuresQuery);
//$soInfo = array();
//
//if ($soMeasuresResults) {
//    while ($row = $soMeasuresResults->fetch_assoc()) {
//        $soIdx = $row['SOIdx'];
//
//        if (!isset($soInfo[$soIdx])) {
//            $soInfo[$soIdx] = array(
//                'SO' => $row['SO'],
//                'Description' => $row['Description'],
//                'RequiredMeasures' => array(),
//                'GPIs' => array()
//            );
//        }
//
//        // Store the required measure indices for this SO
//        if (!in_array($row['MeasureIdx'], $soInfo[$soIdx]['RequiredMeasures'])) {
//            $soInfo[$soIdx]['RequiredMeasures'][] = $row['MeasureIdx'];
//        }
//
//        // Track which GPIs are part of this SO
//        if (!in_array($row['GPIIdx'], $soInfo[$soIdx]['GPIs'])) {
//            $soInfo[$soIdx]['GPIs'][] = $row['GPIIdx'];
//        }
//    }
//}
//
//// Step 2: Get raw student scores
//$scoresQuery = "
//    SELECT
//        STNTOUTCMS.Idx AS SOIdx,
//        SCSHEET.StudentNo,
//        SCSHEET.AssessmentMeasureIdx,
//        SCSHEET.LevelOfAttainment,
//        AM.Measure,
//        GPIS.Idx AS GPIIdx
//    FROM AssessmentMeasures AS ASSMNTMEASURES
//    INNER JOIN GeneralPerformanceIndicators AS GPIS
//        ON (GPIS.Idx = ASSMNTMEASURES.GPI AND GPIS.AcademicProgram = {$academicProgramIdx})
//    INNER JOIN StudentOutcomes AS STNTOUTCMS
//        ON (GPIS.SOIdx = STNTOUTCMS.Idx AND STNTOUTCMS.AcademicProgram = {$academicProgramIdx})
//    INNER JOIN Scoresheet AS SCSHEET
//        ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
//    INNER JOIN AssessmentMeasures AS AM
//        ON (SCSHEET.AssessmentMeasureIdx = AM.Idx)
//    WHERE ASSMNTMEASURES.AvailableCourseIdx = {$availableCourseIdx}
//      AND ASSMNTMEASURES.AbetCourseIdx = {$abetCourseIdx}
//    ORDER BY STNTOUTCMS.Idx, SCSHEET.StudentNo, SCSHEET.AssessmentMeasureIdx
//";
//
//$scoresResults = $DBCONNECTION->sendquery($scoresQuery);
//
//// Organize scores by SO and Student
//$studentScores = array();
//
//if ($scoresResults) {
//    while ($row = $scoresResults->fetch_assoc()) {
//        $soIdx = $row['SOIdx'];
//        $studentNo = $row['StudentNo'];
//        $measureIdx = $row['AssessmentMeasureIdx'];
//
//        if (!isset($studentScores[$soIdx])) {
//            $studentScores[$soIdx] = array();
//        }
//
//        if (!isset($studentScores[$soIdx][$studentNo])) {
//            $studentScores[$soIdx][$studentNo] = array(
//                'measureData' => array(),
//                'measureDetails' => array()
//            );
//        }
//
//        // Track unique measures with their scores
//        if (!isset($studentScores[$soIdx][$studentNo]['measureData'][$measureIdx])) {
//            $studentScores[$soIdx][$studentNo]['measureData'][$measureIdx] = floatval($row['LevelOfAttainment']);
//            $studentScores[$soIdx][$studentNo]['measureDetails'][] = array(
//                'measureIdx' => $measureIdx,
//                'measure' => $row['Measure'],
//                'score' => floatval($row['LevelOfAttainment']),
//                'gpiIdx' => $row['GPIIdx']
//            );
//        }
//    }
//}
//
//// Step 3: Calculate per-student averages and aggregate results
//foreach ($soInfo as $soIdx => $soData) {
//    $requiredMeasures = $soData['RequiredMeasures'];
//    $totalMeasures = count($requiredMeasures);
//
//    if ($totalMeasures == 0) {
//        continue; // Skip SOs with no measures
//    }
//
//    $validStudentAverages = array();
//    $studentsAbove2 = 0;
//    $studentsAbove3 = 0;
//    $studentDetails = array(); // For detail view
//
//    if (isset($studentScores[$soIdx])) {
//        foreach ($studentScores[$soIdx] as $studentNo => $studentData) {
//            $studentMeasureData = $studentData['measureData'];
//            $studentMeasureIndices = array_keys($studentMeasureData);
//
//            // Check if student has ALL required measures for THIS specific SO
//            $missingMeasures = array_diff($requiredMeasures, $studentMeasureIndices);
//
//            if (count($missingMeasures) > 0) {
//                // Student is missing some required measures for this SO
//                $studentDetails[] = array(
//                    'studentNo' => $studentNo,
//                    'measures' => $studentData['measureDetails'],
//                    'average' => 0,
//                    'included' => false,
//                    'reason' => "Missing " . count($missingMeasures) . " required measure(s) for this SO"
//                );
//                continue;
//            }
//
//            // Check if ANY of the required measures have a score of 0
//            $hasZeroScore = false;
//            $zeroMeasures = array();
//            foreach ($requiredMeasures as $requiredMeasureIdx) {
//                if (isset($studentMeasureData[$requiredMeasureIdx]) && $studentMeasureData[$requiredMeasureIdx] == 0) {
//                    $hasZeroScore = true;
//                    // Find the measure number for display
//                    foreach ($studentData['measureDetails'] as $detail) {
//                        if ($detail['measureIdx'] == $requiredMeasureIdx) {
//                            $zeroMeasures[] = 'M' . $detail['measure'];
//                            break;
//                        }
//                    }
//                }
//            }
//
//            if ($hasZeroScore) {
//                // Student has zero score on at least one required measure - exclude
//                $studentDetails[] = array(
//                    'studentNo' => $studentNo,
//                    'measures' => $studentData['measureDetails'],
//                    'average' => 0,
//                    'included' => false,
//                    'reason' => "No submission for: " . implode(', ', $zeroMeasures)
//                );
//                continue;
//            }
//
//            // Student has all required measures with non-zero scores - calculate average
//            $scoresForAvg = array();
//            foreach ($requiredMeasures as $requiredMeasureIdx) {
//                $scoresForAvg[] = $studentMeasureData[$requiredMeasureIdx];
//            }
//
//            $studentAvg = array_sum($scoresForAvg) / count($scoresForAvg);
//
//            // Valid student - include in calculation
//            $validStudentAverages[] = $studentAvg;
//
//            if ($studentAvg >= 2.0) {
//                $studentsAbove2++;
//            }
//            if ($studentAvg >= 3.0) {
//                $studentsAbove3++;
//            }
//
//            // Store detail for this student
//            $studentDetails[] = array(
//                'studentNo' => $studentNo,
//                'measures' => $studentData['measureDetails'],
//                'average' => round($studentAvg, 2),
//                'included' => true
//            );
//        }
//    }
//
//    // Calculate overall average
//    $overallAvg = 0;
//    $totalStudents = count($validStudentAverages);
//
//    if ($totalStudents > 0) {
//        $overallAvg = array_sum($validStudentAverages) / $totalStudents;
//    }
//
//    // Build row
//    $row = array(
//        'DT_RowId' => 'row_' . $soIdx,
//        'SOIdx' => $soIdx,
//        'SO' => $soData['SO'],
//        'SODescription' => $soData['Description'],
//        'AVG' => round($overallAvg, 2),
//        'TOTAL' => $totalStudents,
//        'TOPFIFTY' => $studentsAbove2,
//        'TOPTWENTYFIVE' => $studentsAbove3,
//        'TotalMeasures' => $totalMeasures,
//        'StudentDetails' => $studentDetails
//    );
//
//    $data[] = $row;
//}
//
//// Format response for DataTables
//$output = array(
//    "draw" => isset($_GET['draw']) ? intval($_GET['draw']) : 0,
//    "recordsTotal" => count($data),
//    "recordsFiltered" => count($data),
//    "data" => $data
//);
//
//header('Content-Type: application/json');
//echo json_encode($output);




//
///**
// * Listing Student Outcomes
// * File: u_course_results_SO_ssp.php
// * Description: listing student outcomes of the selected course
// */
//
//include_once 'session_handler.php';
//
//$abetCourseIdx='';
//$availableCourseIdx='';
//$academicProgramIdx='';
//if (array_key_exists('_ABTC', $_GET) && array_key_exists('_AVC', $_GET) && array_key_exists('_AP', $_GET)) {
//    $abetCourseIdx = trim($_GET['_ABTC']);
//    $availableCourseIdx = trim($_GET['_AVC']);
//    $academicProgramIdx = trim($_GET['_AP']);
//}
//else {
//    // illegal entry
//    exit;
//}
//
//// DB table to use
//$table = 'AssessmentMeasures';
//$joinQuery = "FROM `$table` AS `ASSMNTMEASURES` INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram`='$academicProgramIdx') INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`='$academicProgramIdx') INNER JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)  ";
//
//// Table's primary key
//$primaryKey = '`STNTOUTCMS`.`Idx`';
//
//// Array of database columns
//$columns = array(
//    array('db' => '`STNTOUTCMS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
//        return 'row_'.$row[0];
//    }),
//    array( 'db' => '`STNTOUTCMS`.`SO`', 'dt' => 'SO', 'field' => 'SO', 'as' => 'SO'),
//    array( 'db' => '`STNTOUTCMS`.`Idx`', 'dt' => 'SOIdx', 'field' => 'SOIdx', 'as' => 'SOIdx'),
//    array( 'db' => '`STNTOUTCMS`.`Description`', 'dt' => 'SODescription', 'field' => 'SODescription', 'as' => 'SODescription'),
//    array( 'db' => 'AVG(`SCSHEET`.`LevelOfAttainment`)', 'dt' => 'AVG', 'field' => 'AVG', 'as' => 'AVG'),
//    array( 'db' => 'COUNT(`SCSHEET`.`LevelOfAttainment`)', 'dt' => 'TOTAL', 'field' => 'TOTAL', 'as' => 'TOTAL'),
//    array( 'db' => 'SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE NULL END)', 'dt' => 'TOPFIFTY', 'field' => 'TOPFIFTY', 'as' => 'TOPFIFTY'),
//    array( 'db' => 'SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE NULL END)', 'dt' => 'TOPTWENTYFIVE', 'field' => 'TOPTWENTYFIVE', 'as' => 'TOPTWENTYFIVE'),
//);
//
//require( 'ssp.join.class.php' );
//$extraWhere = "`ASSMNTMEASURES`.`AvailableCourseIdx` = '$availableCourseIdx'";
//$extraWhere .= " AND `ASSMNTMEASURES`.`AbetCourseIdx`= '$abetCourseIdx'";
//
//// Include all non-aggregated columns in GROUP BY
//$groupBy = "`STNTOUTCMS`.`Idx`, `STNTOUTCMS`.`SO`, `STNTOUTCMS`.`Description`";
//
//require_once(__DIR__ . '/../php_include/dbconnection.php');
//echo json_encode(
//    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
//);