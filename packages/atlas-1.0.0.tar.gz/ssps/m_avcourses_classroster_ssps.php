<?php
/**
 * Class Roster Management
 * File: m_avcourses_classroster_ssps.php
 * Description: Get and manage student roster for ABET courses
 */

include_once 'session_handler.php';

// Handle POST request (Remove students)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!array_key_exists('_ACTION', $_POST) || $_POST['_ACTION'] !== 'REMOVE') {
        echo '0x00000000'; // Invalid action
        exit;
    }

    $AvailableCourseIdx = isset($_POST['_AVCIDX']) ? intval($_POST['_AVCIDX']) : 0;
    $AbetCourseIdx = isset($_POST['_ABETIDX']) ? intval($_POST['_ABETIDX']) : 0;
    $AcademicProgram = isset($_POST['_DEGREE']) ? intval($_POST['_DEGREE']) : 0;
    $StudentNos = isset($_POST['_STUDNOS']) ? trim($_POST['_STUDNOS']) : '';

    if ($AvailableCourseIdx == 0 || $AbetCourseIdx == 0 || $AcademicProgram == 0 || $StudentNos == '') {
        echo '0x00000001'; // Missing parameters
        exit;
    }

    // Parse student numbers
    $studentNoArray = explode('|', $StudentNos);

    require_once(__DIR__ . '/../php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    try {
        $failedStudents = [];
        $successCount = 0;

        // Process each student
        foreach ($studentNoArray as $studentNo) {
            $studentNo = intval(trim($studentNo));
            if ($studentNo <= 0) continue;

            // Call stored procedure
            $Query = "CALL SP_RemoveStudentFromScoresheet(?, ?, ?, @result)";
            $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx, $AbetCourseIdx, $studentNo]);

            // Get result
            $resultQuery = "SELECT @result AS result";
            $result = $DBCONNECTION->prepare_execute_catch_error($resultQuery, []);

            if ($result && $DBCONNECTION->num_rows() > 0) {
                $row = $DBCONNECTION->fetch_assoc();
                $resultCode = $row['result'];

                if ($resultCode === '0x11111111') {
                    $successCount++;
                } elseif ($resultCode === '0x00000003') {
                    // Student has assessment data - cannot delete
                    $failedStudents[] = $studentNo;
                }
            }
        }

        // Return response based on results
        if (count($failedStudents) > 0) {
            // Some students have assessment data
            echo json_encode([
                'status' => 'partial',
                'code' => '0x00000003',
                'message' => 'Some students have assessment data and cannot be removed',
                'failed_students' => $failedStudents,
                'success_count' => $successCount
            ]);
        } elseif ($successCount > 0) {
            echo '0x11111111'; // All successful
        } else {
            echo '0x00000004'; // No records found
        }

    } catch (Exception $e) {
        echo '0x00000002'; // Database error
    }

    unset($DBCONNECTION);
    exit;
}

// Handle GET request (Retrieve student list using SP_FetchClassRoster)
if (!array_key_exists('_AVCIDX', $_GET)) {
    die(json_encode(['error' => 'Missing required parameters']));
}

$AvailableCourseIdx = intval($_GET['_AVCIDX']);

if ($AvailableCourseIdx == 0) {
    die(json_encode(['error' => 'Invalid parameters']));
}

$AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];
if (!isset($AcademicProgram)) {
    die(json_encode(['error' => 'Academic program not selected']));
}

$AcademicProgram = intval($AcademicProgram);

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/../php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

try {
    // Call SP_FetchClassRoster stored procedure
    $Query = "CALL SP_FetchClassRoster(?, ?)";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx, __DB_ENCRYPTION_KEY]);

    if (!$result) {
        throw new Exception('Failed to execute stored procedure');
    }

    $data = [];

    while ($row = $DBCONNECTION->fetch_assoc()) {
        $data[] = [
            'DT_RowId' => 'row_' . $row['StudentNo'],
            'DT_RowClass' => ($row['IsDropped'] == 1) ? 'dropped-student' : '',
            'StudentNo' => $row['StudentNo'],
            'StudentName' => $row['StudentName'],
            'StudentMajor' => $row['StudentMajor'],
            'AcademicProgramName' => $row['AcademicProgramName'],
            'Degree' => $row['Degree'],
            'IsDropped' => $row['IsDropped']
        ];
    }

    // Format response for DataTables
    $response = [
        'draw' => isset($_GET['draw']) ? intval($_GET['draw']) : 1,
        'recordsTotal' => count($data),
        'recordsFiltered' => count($data),
        'data' => $data
    ];

    echo json_encode($response);

} catch (Exception $e) {
    echo json_encode([
        'error' => 'Database error occurred',
        'message' => $e->getMessage()
    ]);
}

unset($DBCONNECTION);