<?php
/**
 * Unlinking Abet Syllabus
 * Description: unlinking the selected abet syllabus link to another one
 * Author: Dong Hyun Jeong
 *
 * 11/10/2024 -- initial version created
 */


include_once 'session_handler.php';

$SyllabusIdx = (isset($_POST['sid'])) ? trim($_POST['sid']) : '';
$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';

if ($SyllabusIdx=="" || $AcademicProgramIdx=="") {
    echo "0x00000011";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $SyllabusIdx = filter_var($SyllabusIdx, FILTER_VALIDATE_INT);
    if ($SyllabusIdx === false) {
        throw new Exception('Invalid Index format');
    }

    $query = "CALL SP_RemoveAbetSyllabusLink(?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$SyllabusIdx, $AcademicProgramIdx]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x09000010') !== false) {
        echo '0x09000010';  // Cannot delete: course is referenced already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}