<?php
/**
 * updating Master Syllabus
 * Description: adding abet syllabus revision
 * Author: Dong Hyun Jeong
 *
 * 10/08/2024 - initial version created
 */


include_once 'session_handler.php';

// Required fields
$fields = [
    'CourseIndex',
    'FromAcademicYears', 'MajorVersion', 'MinorVersion',
    'OldMajorVersion', 'OldMinorVersion',
    'Subject', 'Num', 'Description', 'Credits', 'Requirement',
    'Pre_requisites', 'Required_Texts',
    'Coordinator', 'Objectives', 'TopicsCovered',
    'RevisionDesc', 'RevisionDate', 'AcademicProgram'
];

$data = [];
foreach ($fields as $field) {
    if (array_key_exists($field, $_POST)) {
        $data[$field] = trim($_POST[$field]);
    } else {
        // Unwanted illegal entry
        echo "0x00000000";
        exit;
    }
}

foreach ($fields as $field) {
    if ($field !== 'ReferenceTexts' && $field !== 'Co_requisites' && $data[$field] === '') {
        // No required information
        echo "0x00000101";
        exit;
    }
}

// Access your variables like this:
$CourseIndex = $data['CourseIndex'];
$FromAcademicYears = $data['FromAcademicYears'];
$Subject = $data['Subject'];
$PreviousMajorVersion = $data['OldMajorVersion'];
$PreviousMinorVersion = $data['OldMinorVersion'];
$MajorVersion = $data['MajorVersion'];
$MinorVersion = $data['MinorVersion'];
$Num = $data['Num'];
$Description = $data['Description'];
$Credits = $data['Credits'];
$Requirement = $data['Requirement'];
$Pre_requisites = $data['Pre_requisites'];
$Required_Texts = $data['Required_Texts'];
$Coordinator = $data['Coordinator'];
$Objectives = $data['Objectives'];
$TopicsCovered = $data['TopicsCovered'];
$RevisionDesc = $data['RevisionDesc'];
$RevisionDate = $data['RevisionDate'];
$AcademicProgramIdx = $data['AcademicProgram'];

// Handle optional fields
$PreviousSyllabusIndex = isset($_POST['SyllabusIndex']) ? trim($_POST['SyllabusIndex']) : '';
$Co_requisites = isset($_POST['Co_requisites']) ? trim($_POST['Co_requisites']) : '';
$ReferenceTexts = isset($_POST['ReferenceTexts']) ? trim($_POST['ReferenceTexts']) : '';
$ToAcademicYears = isset($_POST['ToAcademicYears']) ? trim($_POST['ToAcademicYears']) : '';
$ApprovalDesc = isset($_POST['ApprovalDesc']) ? trim($_POST['ApprovalDesc']) : '';
$ApprovalDate = isset($_POST['ApprovalDate']) ? trim($_POST['ApprovalDate']) : '';
$NewMajorVersion = isset($_POST['NewMajorVersion']) ? trim($_POST['NewMajorVersion']) : '';
$NewMinorVersion = isset($_POST['NewMinorVersion']) ? trim($_POST['NewMinorVersion']) : '';
$LinkedSyllabus = isset($_POST['LinkedSyllabus']) ? trim($_POST['LinkedSyllabus']) : '';
$ObjectivesHeadline = isset($_POST['ObjectivesHeadline']) ? trim($_POST['ObjectivesHeadline']) : '';
$TopicsCoveredHeadline = isset($_POST['TopicsCoveredHeadline']) ? trim($_POST['TopicsCoveredHeadline']) : '';

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    //  Convert character encodings
    require_once(__DIR__ . '/php_include/listfunc.php');

    $ToAcademicYears = ($ToAcademicYears=='') ? null:  $ToAcademicYears;
    $Description = cleanInput($Description, $DBCONNECTION);
    $Requirement = cleanInput($Requirement, $DBCONNECTION);
    $Pre_requisites = cleanInput(replaceNewlines_removeWhiteSpace($Pre_requisites), $DBCONNECTION);
    $Co_requisites = cleanInput($Co_requisites, $DBCONNECTION);
    $Required_Texts = cleanInput(replaceNewlines_removeWhiteSpace($Required_Texts), $DBCONNECTION);
    $ReferenceTexts = cleanInput(replaceNewlines_removeWhiteSpace($ReferenceTexts), $DBCONNECTION);
    $Coordinator = cleanInput($Coordinator, $DBCONNECTION);
    $ObjectivesHeadline = cleanInput(replaceNewlines($ObjectivesHeadline), $DBCONNECTION);
    $Objectives = cleanInput(replaceNewlines($Objectives), $DBCONNECTION);
    $TopicsCoveredHeadline = cleanInput(replaceNewlines($TopicsCoveredHeadline), $DBCONNECTION);
    $TopicsCovered = cleanInput(replaceNewlines($TopicsCovered), $DBCONNECTION);
    $RevisionDesc = cleanInput(replaceNewlines_removeWhiteSpace($RevisionDesc), $DBCONNECTION);
    $RevisionDate = cleanInput($RevisionDate, $DBCONNECTION);
    $ApprovalDesc = cleanInput(replaceNewlines_removeWhiteSpace($ApprovalDesc), $DBCONNECTION);
    $ApprovalDate = cleanInput($ApprovalDate, $DBCONNECTION);
    $ApprovalDate = ($ApprovalDate=='')?null:$ApprovalDate;
    $RevisionDate = ($RevisionDate=='')?null:$RevisionDate;
    $AcademicProgramIdx = ($AcademicProgramIdx=='')?null:$AcademicProgramIdx;

    $query = "CALL SP_AbetSyllabus_RevisionAdd(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $params = [$PreviousSyllabusIndex, $CourseIndex,
        $MajorVersion, $MinorVersion,
        $MajorVersion-$PreviousMajorVersion, $MinorVersion-$PreviousMinorVersion,
        $FromAcademicYears, $ToAcademicYears,
        $Subject, $Num, $Description, $Credits, $Requirement, $Pre_requisites,
        $Co_requisites, $Required_Texts, $ReferenceTexts, $Coordinator,
        $ObjectivesHeadline, $Objectives,
        $TopicsCoveredHeadline, $TopicsCovered,
        $RevisionDesc, $RevisionDate, $ApprovalDesc, $ApprovalDate,
        $AcademicProgramIdx];

    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);
    $AddedSyllabusIndex = null;
    if ($result && $DBCONNECTION->num_rows() > 0) {
        $row = $DBCONNECTION->fetch_assoc();
        $AddedSyllabusIndex = $row["AddedSyllabusIndex"];
    }

    // reporting error message with specific input field to be fixed.
    echo "0x11111111: " . $AddedSyllabusIndex;

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    error_log($DBCONNECTION->FormatQuery($query, $params));
    echo "0x00000000";
}