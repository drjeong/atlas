<?php
/**
 * Management of Program Director Session
 * Description: validation of the logged-in user's status.
 *          only the person who has program director privilege can access management pages.
 * Author: Dong Hyun Jeong
 *
 * 11/24/2024 - initial version created
 *
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check for session hijacking
if (isset($_SESSION['LAST_IP']) && $_SESSION['LAST_IP'] !== $_SERVER['REMOTE_ADDR']) {
    session_destroy();
    header('Location: ./');
    exit;
}

// illegal access (session expired or not logged in)
if (!isset($_SESSION['ATLAS_LOGIN_SYSADMIN']) || !isset($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'])) {
    session_destroy();
    header('Location: ./');
    exit;
}

// Only allow access if user is EITHER a system admin OR a program director
if (!$_SESSION['ATLAS_LOGIN_SYSADMIN'] && !$_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS']) {
    header('Location: main.php');
    exit;
}

// Prevent caching of protected pages
//header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
//header('Cache-Control: post-check=0, pre-check=0', false);
//header('Pragma: no-cache');



//if( !isset($_SESSION['ATLAS_LOGIN_SYSADMIN'])  ) {
//    if (!$_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS']) {
//        echo ('<script type="text/javascript">');
//        echo ('document.location.href="main.php";');
//        echo ('</script>');
//        exit;
//    }
//}
//else
//{
//    if (($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === false) AND ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === false)) {
//        echo ('<script type="text/javascript">');
//        echo ('document.location.href="main.php";');
//        echo ('</script>');
//        exit;
//    }
//}
