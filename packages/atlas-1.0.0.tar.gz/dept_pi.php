<?php
/**
 * Department Performance Indicators (PI)
 * Description: Listing performance indicators outcomes for the student outcomes.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2021 - initial version created
 * 03/02/2021 - Modified the PI description in the edit dialog window
 * 04/12/2021 - Changed the title "GPI" to "PI"
 * 12/08/2021 - Updated duplicate performance indicators selection options
 * 03/09/2023 - Added to show course level information.
 * 09/29/2023 - Adding cross program duplication
 * 10/08/2024 -- Adding revision comments and approval info
 * 10/17/2024 -- Adding revision comparison
 *
 */

//include('checker_programdirector.php');
include('header.php');

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelectionOptions = AcademicYearSelection();

// loading list of db functions
include('./php_include/dbfunctions.php');

?>


<script src="js/dlg_commons.js"></script>
<script>
    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        SAME_ITEM_EXIST: '0x00200011',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
        NO_DATA_IN_SOURCE_YEAR: '0x09500011',
        DATA_EXIST_ALREADY_IN_TARGET_YEAR: '0x09500012',
    };

    async function AsyncGetOptions(option = 1) {
        try {
            const rawResult = await async_commons.makeApiCall(`api_getoptions.php?sel=pi&op=${option}`, {});
            const result = JSON.parse(rawResult);

            if (result.status === 'ERROR') {
                throw new Error(result.message);
            }

            return result.data;
        } catch (error) {
            await async_commons.handleError(error);
            throw error;
        }
    }
</script>

<?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true) { ?>
<script>
    async function UpdatePerformanceIndicator(_ID, _DESC, _CMNTS, _APRVAL, _TobeRemoved) {
        try {
            const result = await async_commons.makeApiCall('dept_pi_update_ajax.php', {
                id: _ID,
                desc: _DESC,
                cmnts: _CMNTS,
                aprval: _APRVAL,
                removal: _TobeRemoved
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'The PI information has been updated!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function RemovePerformanceIndicator(id, ay, pi){
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted content (<span style="color:red">${ay} ${pi}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('dept_pi_remove_ajax.php', {
                id: id
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected PI has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected PI cannot be deleted because it is used in course assessment already.');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function AddPerformanceIndicator_Perform(_AY, _SO, _SOINFO, _PI, _DESC) {
        try {
            const result = await async_commons.makeApiCall('dept_pi_add_ajax.php', {
                ay: _AY,
                so: _SO,
                pi: _PI,
                desc: _DESC
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'The entered PI is added successfully!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `The entered PI (${_SOINFO}-${_PI}) exists already!`
                    );
                    // Re-open the add dialog
                    AddPerformanceIndicator(_AY, _SO, _PI, _DESC);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function ModifyPerformanceIndicator(idx, _AY, _PITXT, _DESC, _CMNTS, _APRVAL, _TobeRemoved)
    {
        _CMNTS = (_CMNTS==null)?'':_CMNTS;
        _APRVAL = (_APRVAL==null)?'':_APRVAL;

        const formContent = `
             <form name="popupfrm" id="popupfrm" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2"><div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Academic Year<span style="color:red">*</span></span>
                  <input type="text" class="input-sm form-control" id="_AY" name="_AY" value="${_AY}" disabled/>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Performance Indicator<span style="color:red">*</span></span>
                  <input type="text" name="_SO" id="_SO" class="input-sm form-control" value="${_PITXT}" disabled/>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Description<span style="color:red">*</span></span>
                  <textarea name="_DESC" id="_DESC" row="6" class="input-sm form-control" style="height:90px" required>${_DESC}</textarea>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Revision Comments<span style="color:red"></span></span>
                  <textarea name="_CMNTS" id="_CMNTS" row="6" class="input-sm form-control" style="height:90px" required>${_CMNTS}</textarea>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Revision Approval<span style="color:red"></span></span>
                  <textarea name="_APRVAL" id="_APRVAL" row="6" class="input-sm form-control" style="height:90px" required>${_APRVAL}</textarea>
              </div>
              <div class="input-group" style="width:100%;">
                  <label class="checkbox-container" style="width:100%; font-size:9pt;"><input type="checkbox" id="_TobeRemoved" name="_TobeRemoved" id="_TobeRemoved" value="1">Check if it will be removed.</label>
              </div>
             </div></td></tr>
             </table></form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">EDIT PERFORMANCE INDICATOR</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> UPDATE",
                    className: 'btn-success',
                    callback: function(){

                        const popupForm = document.getElementById('popupfrm');
                        if (popupForm._DESC.value.isEmpty())
                        {
                            popupForm._DESC.focus();
                            Swal.fire({title:"ERROR", text: "Description is not entered!!", icon:"error"});

                            return false;
                        }

                        UpdatePerformanceIndicator(
                            idx,
                            popupForm._DESC.value,
                            popupForm._CMNTS.value,
                            popupForm._APRVAL.value,
                            popupForm._TobeRemoved.checked);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_AYS").focus();
        });

        const popupForm = document.getElementById('popupfrm');
        if (_TobeRemoved) popupForm._TobeRemoved.checked = true;
    }

    function AddPerformanceIndicator(_AY="", _SO="", _PI="", _DESC="") {

        const [selectedAcademicYearValue, selectedAcademicYearText] = async_commons.getSelectedAcademicYear();
        if (selectedAcademicYearValue === '') {
            return;
        }

        const performanceIndicators = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K'];
        const formContent = `
        <form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
            <table style="border-spacing:0; padding:0; width:100%;">
                <tr><td colspan="2"><div class="input-group" style="width:100%">
                    <div class="input-group" style="width:100%">
                        <span class="input-group-addon" style="width:230px;">Academic Year<span style="color:red">*</span></span>
                        <input type="hidden" name="_AY" id="_AY" class="input-sm form-control" value="${selectedAcademicYearValue}" readonly>
                        <input type="text" name="_AYTXT" id="_AYTXT" class="input-sm form-control" value="${selectedAcademicYearText}" readonly>
                    </div>
                    <div class="input-group" style="width:100%">
                        <span class="input-group-addon" style="width:230px;">Student Outcome<span style="color:red">*</span></span>
                        <select name="_SO" id="_SO" class="input-sm form-control"></select>
                    </div>
                    <div class="input-group" style="width:100%">
                        <span class="input-group-addon" style="width:230px;">Performance Indicator<span style="color:red">*</span></span>
                        <select name="_PI" id="_PI" class="input-sm form-control" required>
                            <option value=""></option>
                            ${performanceIndicators.map(pi => `<option value="${pi}">${pi}</option>`).join('')}
                        </select>
                    </div>
                    <div class="input-group" style="width:100%">
                        <span class="input-group-addon" style="width:230px;">Description<span style="color:red">*</span></span>
                        <textarea name="_DESC" row="6" class="input-sm form-control" style="height:90px" required>${_DESC}</textarea>
                    </div>
                </div></td></tr>
            </table>
        </form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD PERFORMANCE INDICATOR</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ADD",
                    className: 'btn-success',
                    callback: function() {

                        const popupForm = document.getElementById('popupfrm');
                        if (ValidateItems(popupForm) === false) return false;

                        const selectedSOText = popupForm._SO.options[popupForm._SO.selectedIndex].text;
                        AddPerformanceIndicator_Perform(
                            popupForm._AY.value,
                            popupForm._SO.value,
                            selectedSOText,
                            popupForm._PI.value,
                            popupForm._DESC.value
                        );
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){}
                }
            }
        }).on('shown.bs.modal', function() {
            AsyncGetOptions(0)
                .then(data => {
                    // Add new options
                    const selectStudentOutcomes = document.getElementById('_SO');
                    data.forEach(option => {
                        const optElement = document.createElement('option');
                        optElement.value = option.value;
                        optElement.textContent = option.text;
                        selectStudentOutcomes.appendChild(optElement);
                    });
                    if (data.length===0) {
                        Swal.fire({
                            title: "ERROR",
                            text: "Please add Student Outcomes first",
                            icon: "error"
                        }).then(() => {
                            bootbox.hideAll();
                        });
                    }
                })
                .catch(error => {
                    console.error('Error loading academic years:', error);
                    Swal.fire({
                        title: "ERROR",
                        text: "Failed to load academic year options",
                        icon: "error"
                    });
                });

            $("#_SO").focus();
        });

        const popupForm = document.getElementById('popupfrm');
        if (_SO) popupForm._SO.value = _SO;
        if (_PI) popupForm._PI.value = _PI;
        if (_AY) popupForm._AY.value = _AY;
    }

    function ValidateItems(popupForm)
    {
        if (popupForm._AY.value.isEmpty())
        {
            popupForm._AY.focus();
            Swal.fire({title:"ERROR", text: "Academic Year information is not selected!!", icon:"error"});

            return false;
        }
        else if (popupForm._SO.value.isEmpty())
        {
            popupForm._SO.focus();
            Swal.fire({title:"ERROR", text: "Student Outcome information is not selected!!", icon:"error"});

            return false;
        }
        else if (popupForm._PI.value.isEmpty())
        {
            popupForm._PI.focus();
            Swal.fire({title:"ERROR", text: "Performance Indicator is not entered!!", icon:"error"});

            return false;
        }
        else if (popupForm._DESC.value.isEmpty())
        {
            popupForm._DESC.focus();
            Swal.fire({title:"ERROR", text: "Description is not entered!!", icon:"error"});

            return false;
        }
        return true;
    }

    function DuplicatePIs(_AYF = '', _AYT = '') {
        showDuplicateDialog({
            title: 'DUPLICATE PERFORMANCE INDICATORS',
            yearFrom: _AYF,
            yearTo: _AYT,
            performDuplication: DuplicatePI_Perform
        });
    }

    async function DuplicatePI_Perform(_AYF, _AYT) {
        try {
            const result = await async_commons.makeApiCall('dept_pi_duplicate_ajax.php', {
                ayf: _AYF,
                ayt: _AYT
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage(
                        'DUPLICATED',
                        'PI are duplicated successfully!'
                    );
                    // location.reload();
                    break;
                }
                case ErrorCodes.NO_DATA_IN_SOURCE_YEAR: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        'The selected "DUPLICATE FROM YEAR" does not have PIs.'
                    );
                    break;
                }
                case ErrorCodes.DATA_EXIST_ALREADY_IN_TARGET_YEAR: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        'The selected "DUPLICATE TO YEAR" has PIs already.'
                    );
                    DuplicatePIs(_AYF, _AYT);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }
</script>
<?php } ?>

<script>

    function ShowDifferences_Perform(_AY1, _AY2)
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_pi_diff.php");
        $form.append($(document.createElement('input')).attr('name','_AY1').val(_AY1));
        $form.append($(document.createElement('input')).attr('name','_AY2').val(_AY2));
        $("body").append($form);
        $form.submit();
    }

    function ShowDifferences()
    {
        const formContent = `
             <form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2"><div class="input-group" style="width:100%">
             			<div class="input-group" style="width:100%"><span class="input-group-addon" style="width:250px;">Academic Year 1<span style="color:red">*</span></span>
                  <select name="_AY1" id="_AY1" class="input-sm form-control"><option value=""></option></select>
                      </div>
             			<div class="input-group" style="width:100%"><span class="input-group-addon" style="width:250px;">Academic Year 2<span style="color:red">*</span></span>
                  <select name="_AY2" id="_AY2" class="input-sm form-control"><option value=""></option></select>
                      </div>
             </div></td></tr>
             </table></form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">SHOW DIFFERENCES IN PIs</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> SHOW",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');
                        if (popupForm._AY1.value.isEmpty())
                        {
                            popupForm._AY1.focus();
                            Swal.fire({title:"ERROR", text: "Academic Year1 information is not selected!!", icon:"error"});
                            return false;
                        }
                        else if (popupForm._AY2.value.isEmpty())
                        {
                            popupForm._AY2.focus();
                            Swal.fire({title:"ERROR", text: "Academic Year2 information is not selected!!", icon:"error"});
                            return false;
                        }
                        else if (popupForm._AY1.value == popupForm._AY2.value)
                        {
                            popupForm._AY1.focus();
                            Swal.fire({title:"ERROR", text: "Academic Year1 & Year2 information cannot be the same!!", icon:"error"});
                            return false;
                        }

                        ShowDifferences_Perform(popupForm._AY1.value, popupForm._AY2.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            // Load the academic year options after the modal is shown
            AsyncGetOptions(2)
                .then(data => {
                    // Function to populate select options
                    const populateSelect = (selectId, options) => {
                        const select = document.getElementById(selectId);
                        options.forEach(({ value, text }) => {
                            const option = document.createElement('option');
                            option.value = value;
                            option.textContent = text;
                            select.appendChild(option);
                        });
                        return select;
                    };

                    // Populate both selects
                    const selectYearFrom = populateSelect('_AY1', data);
                    const selectYearTo = populateSelect('_AY2', data);
                })
                .catch(error => {
                    console.error('Error loading academic years:', error);
                    Swal.fire({
                        title: "ERROR",
                        text: "Failed to load academic year options",
                        icon: "error"
                    });
                });
        });
    }
</script>

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN']) { // available only to the people who have access controls to programs
?>
<script>
    async function RemoveAllPIs() {
        try {

            const [selectedAcademicYearValue, selectedAcademicYearText] = async_commons.getSelectedAcademicYear();
            if (selectedAcademicYearValue === '') {
                return;
            }

            const willDelete = await async_commons.showConfirmDialog(
                `Deleted PIs in (<span style="color:red">${selectedAcademicYearText}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('dept_pi_removeall_ajax.php', {
                ay: selectedAcademicYearValue
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'All PIs has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'PIs cannot be deleted because they are used in course assessment already.');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function DuplicateCrossPrmsPIs()
    {
        const formContent = `
             <form name="popupfrm" id="popupfrm" onsubmit="return false;">
             <div style="color:blue; font-weight:bold;">Please use with caution when duplicating. If not sure, please contact the system administrator.</div>
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
              <div class="input-group" style="width:100%">
              <span class="input-group-addon" style="width:320px;">Duplicate From - Academic Program & Year<span style="color:red">*</span></span>
                  <div class="input-group" style="width:100%">
                  <span class="input-group-btn"><select name="_AYF" id="_AYF" class="input-sm form-control"><option value=""></option></select></span>
                  </div>
              </div>
              <div class="input-group" style="width:100%">
              <span class="input-group-addon" style="width:320px;">Duplicate To - Academic Year<span style="color:red">*</span></span>
                  <div class="input-group" style="width:100%">
                  <span class="input-group-btn"><select name="_AYT" id="_AYT" class="input-sm form-control"><option value=""></option></select></span>
                  </div>
              </div>
             </td></tr>
             </table></form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">CROSS-PROGRAM DUPLICATE PIs</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> DUPLICATE",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');
                        if (popupForm._AYF.value.isEmpty())
                        {
                            popupForm._AYF.focus();
                            Swal.fire({title:"ERROR", text: "Duplicate From (Academic Program & Year) is not selected!!", icon:"error"});
                            return false;
                        }
                        else if (popupForm._AYT.value.isEmpty())
                        {
                            popupForm._AYT.focus();
                            Swal.fire({title:"ERROR", text: "Duplicate To (Academic Year) is not selected!!", icon:"error"});
                            return false;
                        }

                        DuplicateCrossPrmsPI_Perform(popupForm._AYF.value, popupForm._AYT.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            AsyncGetOptions(3)
                .then(data => {
                    // Add new options - year from
                    const selectYearFrom = document.getElementById('_AYF');
                    data.inProgram.forEach(option => {
                        const optElement = document.createElement('option');
                        optElement.value = option.value;
                        optElement.textContent = option.text;
                        selectYearFrom.appendChild(optElement);
                    });

                    // Add new options - year to
                    const selectYearTo = document.getElementById('_AYT');
                    data.notInProgram.forEach(option => {
                        const optElement = document.createElement('option');
                        optElement.value = option.value;
                        optElement.textContent = option.text;
                        selectYearTo.appendChild(optElement);
                    });
                })
                .catch(error => {
                    console.error('Error loading academic years:', error);
                    Swal.fire({
                        title: "ERROR",
                        text: "Failed to load academic year options",
                        icon: "error"
                    });
                });
        });
    }

    async function DuplicateCrossPrmsPI_Perform(_AYF, _AYT) {
        try {
            const result = await async_commons.makeApiCall('dept_pi_crossprmduplicate_ajax.php', {
                ayf: _AYF,
                ayt: _AYT
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DUPLICATED', 'PIs have been duplicated!');
                    // location.reload();
                    break;
                }
                case ErrorCodes.NO_DATA_IN_SOURCE_YEAR: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        'The selected "DUPLICATE FROM YEAR" does not have PIs.'
                    );
                    DuplicateAssmntRubrics(_AYF, _AYT);
                    break;
                }
                case ErrorCodes.DATA_EXIST_ALREADY_IN_TARGET_YEAR: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        'Duplication cannot be performed. Please remove all existing student outcomes first.'
                    );
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }
</script>
<?php
}
?>

<script class="init">
    $(document).ready(function() {
        const szURL = 'ssps/dept_pi_ssps.php?_AY=';

        DataTable_Info = $("#PerformanceIndicators").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            "stateSave": true,
            "processing": true,
            "serverSide": true,
            "lengthMenu": [ 30, 50, 100, 150, 300 ],
            "ajax": `${szURL}<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>`,
            "oLanguage": {"sInfoFiltered": ""},
            "order": [[ 1, "asc" ], [ 2, "asc" ]], // Sorting by 'SO' and 'PI'
            "columns": [
                { "data": 'AcademicYearInfo' },
                { "data": 'PITXT' },
                {
                    "data": 'Description',
                    "render": function(data, type, row) {
                        // Add the <s> tag around the Description content if it will be removed.
                        if (row.TobeRemoved === 1)
                            return '<s>' + data + '</s>';
                        return data;
                    }
                },
                { "data": 'Comments' },
                { "data": 'Approval' },
                <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                { "data": "" } // used for representing menu options
                <?php } ?>
            ],
            "fnInitComplete": function(oSettings, json) {
                let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                // Add "Clear Filter" button to Filter
                btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                    $('#' + oSettings.sTableId).dataTable().fnFilter('');
                });
            },
            "fnDrawCallback": function() {
                $('#PerformanceIndicators tr td:nth-child(1)').css('text-align', 'center');
                $('#PerformanceIndicators tr td:nth-child(2)').css('text-align', 'center');
                $('#PerformanceIndicators tr td:nth-child(3)').css('text-align', 'center');
            },
            <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
            "columnDefs": [
                {
                    "targets": -1,
                    "data": null,
                    "orderable": false,
                    "defaultContent": "<div style=\"width:100%;text-align:center;\"><button id=\"modify\" class=\"btn btn-danger btn-xs glyphicon glyphicon-wrench\" style=\"min-height: 20px;\"></button>&nbsp;<button id=\"remove\" class=\"btn btn-danger btn-xs glyphicon glyphicon-remove\" style=\"min-height: 20px;\"></button></div>"
                }
            ],
            <?php } ?>
            "buttons": [
                {
                    "extend": 'pdfHtml5',
                    "orientation": 'landscape',
                    "title": getTitleText,
                    "text": '<span class="glyphicon glyphicon-floppy-save"></span> PDF',
                    "className": 'btn btn-xs',
                    "attr": {
                        "style": 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff; margin-left:8px;'
                    },
                    "exportOptions": {
                        "columns": [ 0, 1, 2, 3, 4]
                    },
                    "customize": function(doc) {
                        doc.styles.tableHeader.fontSize = 9;
                        doc.defaultStyle.fontSize = 8; // change default fontsize
                    }
                },
                {
                    "extend": 'excelHtml5',
                    "title": getTitleText,
                    "text": '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    "className": 'btn btn-xs',
                    "attr": {
                        "style": 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff;'
                    },
                    "exportOptions": {
                        "columns": [ 0, 1, 2, 3, 4]
                    }
                }
            ]
        });

        // Helper function for title
        function getTitleText() {
            const program = document.forms["changefrm"]["CH_APR"].options[document.forms["changefrm"]["CH_APR"].selectedIndex].text;
            const academicYear = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].text;
            return `Performance Indicators (${program} ${academicYear})`;
        }

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_Info.ajax.url(tmpURL).load();
        });

        <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
        $('#PerformanceIndicators tbody').on( 'click', '#remove', function () {
            const data = DataTable_Info.row( $(this).parents('tr') ).data();
            RemovePerformanceIndicator(data.Idx, data.AcademicYearInfo, data.PITXT);
        } );

        $('#PerformanceIndicators tbody').on( 'click', '#modify', function () {
            const data = DataTable_Info.row( $(this).parents('tr') ).data();
            ModifyPerformanceIndicator(data.Idx, data.AcademicYearInfo, data.PITXT, data.Description, data.Comments, data.Approval, data.TobeRemoved);
        } );
        <?php } ?>

        // Set the DataTable in AsyncCommons
        async_commons.setDataTable(DataTable_Info);
    } );

</script>

<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">PERFORMANCE INDICATORS (PIs)</span></p>
    </div>

    <div class="pagebacklayout_inner_noborder">
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { // available only to the system administrator
?>
        <div style="display: flex; align-items: center; gap: 10px; border: 2px solid red; padding: 10px; border-radius: 5px; background-color: #e0e0e0;">
            <h5 style="margin: 0;">SYSTEM ADMIN MENUS:</h5>
            <button class="btn btn-default btn-sm" onclick="RemoveAllPIs();return false;" style="color:red;">REMOVE ALL PERFORMANCE INDICATORS</button>
            <button class="btn btn-default btn-sm" onclick="DuplicateCrossPrmsPIs();return false;" style="color:red;">CROSS-PROGRAM DUPLICATE</button>
        </div>
<?php
}
?>

        <div class="pagebacklayout_inner_noborder">
            <?php
            if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                include('control_selprogram.php');
            } else {
                include('control_allprograms.php');
            }
            ?>
        </div>

        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:25%;">
                    <?php echo($AcademicYearSelectionOptions);?>
                </td>
                <td style="width:5%"></td>
                <td style="width:70%; text-align: right">
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <button class="btn btn-default btn-sm" onclick="DuplicatePIs();return false;" style="color:red;">DUPLICATE (DIRECTOR ONLY)</button>
                    <button class="btn btn-danger btn-sm" onclick="AddPerformanceIndicator();return false;">ADD PERFORMANCE INDICATOR</button>
                    <?php } ?>
                    <button class="btn btn-danger btn-sm" onclick="ShowDifferences();return false;">SHOW DIFFERENCES</button>
                </td>
            </tr>
        </table>

        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="PerformanceIndicators" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th style="width:80px">ACADEMIC YEAR</th>
                    <th style="width:100px">PERFORMANCE INDICATOR</th>
                    <th>PI DESCRIPTION</th>
                    <th>REVISION COMMENTS</th>
                    <th>REVISION APPROVAL</th>
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <th style="width:100px" class="no-sort">OPERATION</th>
                    <?php } ?>
                </tr>
                </thead>
            </table>
        </div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-wrench" style="pointer-events: none;"></span>: Modify PI/
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Remove PI
                    <?php } ?>
                </td>
            </tr>
        </table>
    </div>
</div>

<?php include('footer.php');?>

