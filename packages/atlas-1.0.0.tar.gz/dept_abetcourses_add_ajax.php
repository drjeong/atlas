<?php
/**
 * Add Abet Course
 * Description: Adding abet course
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$AcademicYearIdx='';
$Courses='';

if (array_key_exists('ay', $_POST) && array_key_exists('crses', $_POST))
{
    $AcademicYearIdx = trim($_POST['ay']);
    $Courses = trim($_POST['crses']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYearIdx=="" || $AcademicProgramIdx=="" || $Courses==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/../config.php');
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    // convert courses
    $Course_Array = explode( '|', $Courses );
    for ($i=0; $i<count($Course_Array); $i++)
    {
        $Course_Tmp = explode( '_', $Course_Array[$i]);
        $AVCIdx = (int)$Course_Tmp[0];
        $CMCIdx = (int)$Course_Tmp[1];
        $ABETSyllabusIdx = (int)$Course_Tmp[2];

        $query = "CALL SP_AddAbetCourse(?, ?, ?, ?);";
        $params = [$AcademicYearIdx, $AVCIdx, $CMCIdx, $AcademicProgramIdx];
        $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

        if ($result && $DBCONNECTION->num_rows() > 0) {
            $row = $DBCONNECTION->fetch_assoc();
            $AbetSyllabusFileName = $row["AbetSyllabus"];   // Master syllabus filename
            $AcademicYearInfo = $row["AcademicYear"]; // 2024-2025

            if ($AbetSyllabusFileName !== null) {
                // Master Syllabus Creation using Latex
                $target_dir = __DIRECTORY_ABETSYLLABI__ . $AcademicYearInfo . DIRECTORY_SEPARATOR;
                $AbetSyllabusFile = $target_dir . basename($AbetSyllabusFileName);

//            error_log($AbetSyllabusFile);
                if (!file_exists($AbetSyllabusFile)) {
//                    createAbetSyllabusPDF($ABETSyllabusIdx, $AbetSyllabusFile, $AcademicYearIdx, $AcademicProgramIdx);
                    require_once(__DIR__ . '/php_include/AbetSyllabusPDFCreator.php');
                    $creator = new AbetSyllabusPDFCreator($ABETSyllabusIdx, $AbetSyllabusFile, $AcademicYearIdx, $AcademicProgramIdx, 2);
                    $creator->createPDF();
                }
            }
        }
    }
    echo "0x11111111";
} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    echo "0x00000500";  // other DB error

    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'query' => '0x00000500'
    ]));

    error_log($DBCONNECTION->FormatQuery($query, $params));

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!

    echo "0x00000000";
}