<?php
/**
 * Management of Syllabus of Master Courses
 * Description: managing courses
 * Author: Dong Hyun Jeong
 *
 * 09/29/2024 - initial version created
 *
 */

//include('checker_programdirector.php');
include('header.php');

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

?>

<script src="js/datatable-utils-holdsearch.min.js"></script>
<script src="js/datatable-utils-search.min.js"></script>
<script src="js/datatable-utils-rowselector.min.js?v=0.0.001"></script>
<script src="js/datatable-utils-columnvisibility.min.js?v=0.0.004"></script>


<script>

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        SAME_ITEM_EXIST: '0x00200011',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
    };

    async function RemoveSyllabus(SyllabusIdx, CourseIdx, Subject, Num, Title, Version) {
        // if (Version === '1.0') {
        //     Swal.fire({
        //         title: "ERROR",
        //         text: "You are not allowed to remove syllabus version 1.0!!",
        //         icon: "error"
        //     });
        //     return;
        // }

        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted syllabus (<span style="color:red">${Subject} ${Num} ${Title} Version${Version}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('dept_abetsyllabus_remove_ajax.php', {
                sid: SyllabusIdx,
                cid: CourseIdx
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected course has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected course cannot be deleted because it is used already.');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function downloadSyllabus(SyllabusIndex, Subject, Num) {
        try {
            const blob = await async_commons.makeApiCall('create_abetsyllabus_pdf.php', {
                _idx: SyllabusIndex
            }, true, 'blob');

            if (blob.type === "application/pdf") {
                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);

                let AssessmentPDF_FileName = 'abet_syllabus';
                AssessmentPDF_FileName += '_' + String(Subject).toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '_' + String(Num).toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '.pdf';

                link.download = AssessmentPDF_FileName;
                link.click();

                // Clean up
                setTimeout(() => {
                    window.URL.revokeObjectURL(link.href);
                }, 100);

                await async_commons.showSuccessMessage('SUCCESS', 'PDF downloaded successfully!');
            } else {
                throw new Error('Invalid file type received');
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
        }
    }

    function EditSyllabusInfo(index, Subject, Num, Title, Credits, Syllabus)
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_abetsyllabus_edit.php");
        $form.append($(document.createElement('input')).attr('name','cindex').val(index));
        $form.append($(document.createElement('input')).attr('name','Subject').val(Subject));
        $form.append($(document.createElement('input')).attr('name','Title').val(Title));
        $form.append($(document.createElement('input')).attr('name','Num').val(Num));
        $form.append($(document.createElement('input')).attr('name','Credits').val(Credits));
        $form.append($(document.createElement('input')).attr('name','targetindex').val(Syllabus));
        $("body").append($form);
        $form.submit();
    }

</script>

<?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
<script>
    async function AddCourses_Perform(_SELECTEDCOURSES) {
        try {
            const result = await async_commons.makeApiCall('dept_abetsyllabus_add_ajax.php', {
                crses: _SELECTEDCOURSES
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'Course is added!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    var DataTable_List_Courses = null;

    function ApprovalChanges() {
        let selected = DataTable_List_Courses.rows({ selected: true }).data();
        if (selected.length === 0) {
            Swal.fire({title:"ERROR", text: "Please select courses first!", icon:"error"});
            return;
        }

        // create an array for the selected abet courses
        let CourseIdx = '';
        for(let i = 0; i < selected.length; ++i) {
            if (CourseIdx !== '') CourseIdx += "|";
            CourseIdx += encodeURIComponent(selected[i].ABSIdx);
        }
        AssignAssistantsDlg(CourseIdx)
    }

    function AssignAssistantsDlg(CourseIdx) {

        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2"><div class="input-group" style="width:100%">
                <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Approval Information<span style="color:red">*</span></span>
                    <textarea name="_APRVAL" id="_APRVAL" row="6" class="input-sm form-control" style="height:90px" required></textarea>
                </div>
                <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Date (YYYY-MM-DD)<span style="color:red">*</span></span>
                    <input type="text" name="_APRVALDATE" id="_APRVALDATE" class="input-sm form-control" value="<?php echo(date('Y-m-d'));?>" placeholder="YYYY-MM-DD" required>
                </div>
             </div></td></tr>
             </table></form>`

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">UPDATE APPROVAL INFO</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ADD",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');
                        if (ValidateItems(popupForm) === false) return false;

                        UpdateApprovalChanges_Perform(CourseIdx, popupForm._APRVAL.value, popupForm._APRVALDATE.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        });
    }

    function ValidateItems(popupForm) {
        if (!popupForm._APRVAL.value.trim()) {
            Swal.fire({
                title: "ERROR",
                text: "Approval description is not entered!",
                icon: "error",
                didClose: () => {
                    popupForm._APRVAL.focus();
                }
            });
            return false;
        }
        else if (!popupForm._APRVALDATE.value.trim()) {
            Swal.fire({
                title: "ERROR",
                text: "Approval date is not entered!",
                icon: "error",
                didClose: () => {
                    popupForm._APRVALDATE.focus();
                }
            });
            return false;
        }
        else if (!isValidDateFormat(popupForm._APRVALDATE.value.trim())) {
            Swal.fire({
                title: "ERROR",
                text: "Approval date must be in YYYY-MM-DD format!",
                icon: "error",
                didClose: () => {
                    popupForm._APRVALDATE.focus();
                }
            });
            return false;
        }
        return true;
    }

    function isValidDateFormat(dateString) {
        // Check format YYYY-MM-DD
        const regex = /^\d{4}-\d{2}-\d{2}$/;
        if (!regex.test(dateString)) {
            return false;
        }

        // Check if it's a valid date
        const [year, month, day] = dateString.split('-').map(Number);
        const date = new Date(year, month - 1, day); // Create date in local timezone

        return date.getFullYear() === year &&
            date.getMonth() + 1 === month &&
            date.getDate() === day;
    }

    async function UpdateApprovalChanges_Perform(CourseIdx, approvalinfo, approvaldate ) {
        try {
            const result = await async_commons.makeApiCall('dept_abetsyllabus_approval_update_ajax.php', {
                crses: CourseIdx,
                approvalinfo: approvalinfo,
                approvaldate: approvaldate
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Approval information has been updated');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
            // Hide spinner and show notification
            hideFullPageSpinner();
        }
    }


    function AddCourses() {

        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                <table id="selectedcouselist" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                        <tr>
                            <th class="toggle-all" style="width:3px"></th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </form>`;

        const rowSelector = new DataTableRowSelector('selectedcouselist', {
            counterId: 'selectedCount',
            toggleButtonId: 'toggleSelected',
            itemName: 'course'
        });

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD COURSES</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ADD",
                    className: 'btn-success',
                    callback: function() {
                        const popupForm = document.getElementById('popupfrm');
                        let selected = rowSelector.getSelectedData();

                        if (!selected.length) {
                            Swal.fire({
                                title: "ERROR",
                                text: "You need to select at least one course!!",
                                icon: "error"
                            });
                            return false;
                        }

                        const selectedCourses = selected.map(course => course.Idx).join('|');
                        AddCourses_Perform(selectedCourses);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function() {}
                }
            }
        }).on('shown.bs.modal', function() {
        }).find('.modal-dialog').css({
            'margin-top': function() {
                let w = $(window).height();
                let b = $(this).height();
                let h = (w - b) * 0.1;
                return h + "px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"
        }).find('.modal-header').css({
            'cursor': 'move'
        });

        DataTable_CoursesList = $("#selectedcouselist").DataTable({
            processing: true,
            serverSide: false,
            iDisplayLength: 8,
            lengthChange: false,
            select: {
                style: 'multi',
                selector: 'td'
            },
            dom: `t<"row"<"col-sm-6"<"filterControls">><"col-sm-6"p>>`, // add filter controls at the bottom
            initComplete: function() {
                // Initialize the row selector
                rowSelector.init(DataTable_CoursesList);
            },
            ajax: `ssps/dept_abetsyllabus_courselist_ssps.php`,
            order: [[1, 'asc'], [2, 'asc']],
            fnDrawCallback: function() {
                $('#selectedcouselist tr td:nth-child(1)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(2)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(3)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(5)').css('text-align', 'center');

                $('#selectedcouselist tr td:nth-child(2)').css('width', '20px');
                $('#selectedcouselist tr td:nth-child(3)').css('width', '20px');
                $('#selectedcouselist tr td:nth-child(4)').css('width', '200px');
                $('#selectedcouselist tr td:nth-child(5)').css('width', '20px');
                // $('#selectedcouselist tr td:nth-child(4)').css('min-width', '150px');

                rowSelector.updateSelectedCount();
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function(data, type, full, meta) {
                        return '';
                    }
                },
                { data: 'Subject' },
                { data: 'Num' },
                { data: 'Title' },
                { data: 'Credits' }
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets: 'no-sort',
                    orderable: false,
                }
            ]
        });

        // Initialize the column search functionality
        new DataTableSearch('#selectedcouselist', DataTable_CoursesList, false);
    }
</script>
<?php } ?>

<script class="init">
$(document).ready(function() {
	DataTable_List_Courses = $("#coursesyllabusinfo").DataTable({
		dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging // showing Excel button at the beginning with "B"
		processing: true,
        select: true,
		serverSide: true,
        // stateSave: true,
        lengthMenu: [ 50, 100, 150, 300, 500 ],
		search: {
			regex: true
		},
		fnInitComplete: function(oSettings, json) {
		  // Add "Clear Filter" button to Filter
		  let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
		  btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
		  $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
		   $('#' + oSettings.sTableId).dataTable().fnFilter('');
		  });

            // Column visibility
            new DataTableColumnVisibility(DataTable_List_Courses, oSettings.sTableId, {
                skipColumns: ['operation', '']  // must be lowercase letters
            }).build();
		},
		ajax: 'ssps/dept_abetsyllabus_ssps.php',
		oLanguage: {sInfoFiltered: ""},
        columns: [
            {
                "data": null,
                "className": "select-checkbox",
                "defaultContent": "",
                "orderable": false
            },
            { data: 'AcademicYearFrom' },
            { data: 'AcademicYearTo' },
            { data: 'Subject' },
            { data: 'Num' },
            { data: 'Title' },
            { data: 'Credits' },
            { data: 'Requirement' },
            { data: 'SyllabusStatus' },
            { data: 'Coordinator' },
            { data: 'Linked',
                render: function ( data, type, full, meta ) {
                    let content = '';
                    if (data !== null) {
                        content += `linked`;
                    }
                    return content;
                }
            },
            { data: 'Version' },
            { data: 'RevisionDate' },
            { data: 'NeedApproval' },
            { data: 'ApprovalDate' },
            { data: 'ABSIdx',
                render: function ( data, type, full, meta ) {
                    let content =  '<button id="addinfo" alt="Edit Syllabus Info" title="Edit Syllabus Info" class="btn btn-danger btn-xs glyphicon glyphicon-edit" style="min-height: 20px;"></button>&nbsp;';
<?php if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) { ?>
                    content +=  '<button id="remove" alt="Remove Syllabus Info" title="Remove Syllabus Info" class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="min-height: 20px;"></button>&nbsp;';
<?php } ?>

                    if (full.ABSIdx !== null && full.RevisionDate !== null) {
                        content += `<button class="btn btn-success btn-xs" id="downloadpdf" title="Download Syllabus"><i class="glyphicon glyphicon-floppy-save"></i> PDF</button>`;
                    }
                    return content;
                }
            }
        ],
		order: [[ 2, 'asc' ], [ 3, 'asc' ]],
        columnDefs: [
            {
                targets: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14],
                className: 'dt-center'
            },
            {
                targets: 'no-sort',
                orderable: false
            }
        ],
        buttons: [ {
			extend: 'excelHtml5',
            title: 'ALL COURSES\' MASTER SYLLABUS',
            text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
            className: 'btn btn-xs',
            attr: {
                style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
            },
            exportOptions: {
                columns: ':not(:last-child)'   // exclude last column
            }
		}],
        select: {
            style: 'multi'
        },
    });

    async_commons.setDataTable(DataTable_List_Courses);

    // Save individual column searches
    DataTable_List_Courses.columns().every(function(index) {
        $(this.header()).on('keyup change', 'input', function() {
            localStorage.setItem('dtColSearch_' + index, this.value);
        });
    });

    $('#coursesyllabusinfo tbody').on( 'click', '#addinfo', function () {
        const data = DataTable_List_Courses.row( $(this).parents('tr') ).data();
        EditSyllabusInfo(data.Idx, data.Subject, data.Num, data.Title, data.Credits, data.ABSIdx);
        return false;
    } );

    $('#coursesyllabusinfo tbody').on( 'click', '#downloadpdf', function () {
        const data = DataTable_List_Courses.row( $(this).parents('tr') ).data();
        downloadSyllabus(data.ABSIdx, data.Subject, data.Num);
        return false;
    } );

    <?php if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) { ?>
    $('#coursesyllabusinfo tbody').on( 'click', '#remove', function () {
        const data = DataTable_List_Courses.row( $(this).parents('tr') ).data();

        // Double-check if linked (in case button wasn't properly disabled)
        if (data.Linked !== null && data.Linked !== '') {
            Swal.fire({
                title: "CANNOT DELETE",
                text: "This syllabus is currently linked and cannot be deleted. Please unlink it first before attempting to remove it.",
                icon: "warning"
            });
            return false;
        }
        RemoveSyllabus(data.ABSIdx, data.Idx, data.Subject, data.Num, data.Title, data.Version);
        return false;
    } );
    <?php } ?>

    // Initialize the column search functionality
    new DataTableHoldSearch('#coursesyllabusinfo', DataTable_List_Courses, true, true);

    // Enable toggle-all button
    $('#coursesyllabusinfo').on('click', '.toggle-all', function() {
        $(this).closest("tr").toggleClass("selected");
        if ($(this).closest("tr").hasClass("selected")) {
            DataTable_List_Courses.rows({ page: 'current' }).select();
        }
        else {
            DataTable_List_Courses.rows({ page: 'current' }).deselect();
        }
    });

} );

</script>


<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">MASTER COURSE SYLLABUS LIST</span></p>
    </div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
			<td style="width:50%; text-align: left;">
<?php
    include('control_allprograms.php');
?>
            </td>
			<td style="width:50%; text-align:right">
<?php
if (!empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]) && !$_SESSION['ATLAS_LOGIN_OBSERVER']) {
?>
    <button class="btn btn-danger btn-sm" onclick="ApprovalChanges();return false;">APPROVAL</button>
    <button class="btn btn-danger btn-sm" onclick="AddCourses();return false;">ADD COURSE</button>
<?php } ?>
            </td>
		</tr>
		</table>

		<div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="coursesyllabusinfo" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
            <thead>
            <tr>
                <th class="toggle-all" style="width:3px; "></th>
                <th>APPLIED YEAR FROM</th>
                <th>APPLIED YEAR TO</th>
                <th>SUBJ</th>
                <th>NUM</th>
                <th>TITLE</th>
                <th>CREDITS</th>
                <th>REQUIREMENT</th>
                <th>SYLLABUS</th>
                <th>COORDINATOR</th>
                <th>LINKED</th>
                <th>VERSION</th>
                <th>REVISED DATE</th>
                <th>NEED APPROVAL</th>
                <th>APPROVAL DATE</th>
                <th class="no-sort" style="width:100px;">OPERATION</th>
            </tr>
            </thead>
            <thead id="serachbox" class="filters">
                <tr>
                    <th></th>
                    <th>APPLIED YEAR FROM</th>
                    <th>APPLIED YEAR TO</th>
                    <th>SUBJ</th>
                    <th>NUM</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>REQUIREMENT</th>
                    <th>SYLLABUS</th>
                    <th>COORDINATOR</th>
                    <th>LINKED</th>
                    <th>VERSION</th>
                    <th>REVISED DATE</th>
                    <th>NEED APPROVAL</th>
                    <th>APPROVAL DATE</th>
                    <th></th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th></th>
                    <th>APPLIED YEAR FROM</th>
                    <th>APPLIED YEAR TO</th>
                    <th>SUBJ</th>
                    <th>NUM</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>REQUIREMENT</th>
                    <th>SYLLABUS</th>
                    <th>COORDINATOR</th>
                    <th>LINKED</th>
                    <th>VERSION</th>
                    <th>REVISED DATE</th>
                    <th>NEED APPROVAL</th>
                    <th>APPROVAL DATE</th>
                    <th></th>
                </tr>
            </tfoot>
            </table>
		</div>
        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-edit" style="pointer-events: none;"></span>: Edit Syllabus
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Remove Syllabus
                    <?php } ?>
                    <span class="btn btn-success btn-xs glyphicon glyphicon-floppy-save" style="pointer-events: none;"></span>: Download Syllabus
                </td>
            </tr>
        </table>
    </div>
</div>

<!-- On dept_abetsyllabus.php before redirecting -->
<?php
$_SESSION['last_list_page'] = 'dept_abetsyllabus.php';
?>

<?php include('footer.php');?>
