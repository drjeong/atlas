<?php
/**
 * Get Semesters List
 * Description: Retrieve all semesters for dropdown selection
 * Author: Dong Hyun Jeong
 *
 * 08/07/2026 - initial version created
 *
 */

require_once(__DIR__ . '/../checker_programdirector.php');

header('Content-Type: application/json');

try {
    require_once(__DIR__ . '/../php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Fetch all semesters ordered by semester code
    $query = "SELECT Idx, SemesterCode, Explanation 
              FROM Semesters 
              ORDER BY SemesterCode DESC LIMIT 40;";

    $result = $DBCONNECTION->prepare_execute_catch_error($query, []);

    $semesters = [];

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $semesters[] = [
                'Idx' => $row['Idx'],
                'SemesterCode' => $row['SemesterCode'],
                'Explanation' => $row['Explanation']
            ];
        }
    }

    echo json_encode($semesters);

} catch (mysqli_sql_exception $e) {
    error_log("Database Error: " . $e->getMessage() .
        " in " . __FILE__ .
        " on line " . __LINE__);
    echo json_encode([]);
} catch (Exception $e) {
    error_log("General Error: " . $e->getMessage() .
        " in " . __FILE__ .
        " on line " . __LINE__);
    echo json_encode([]);
} finally {
    // Connection cleanup is handled by Dbconnection class destructor
}
