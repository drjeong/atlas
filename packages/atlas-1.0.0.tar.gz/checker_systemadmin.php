<?php
/**
 * Management of Administrator Session
 * Description: validation of the logged-in user's status.
 *          only the person who has system administrator privilege can access management pages.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 *
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check for session hijacking
if (isset($_SESSION['LAST_IP']) && $_SESSION['LAST_IP'] !== $_SERVER['REMOTE_ADDR']) {
    session_destroy();
    header('Location: ./');
    exit;
}

// Check admin status
if (!isset($_SESSION['ATLAS_LOGIN_SYSADMIN']) || $_SESSION['ATLAS_LOGIN_SYSADMIN'] !== true) {
    // Clear session and redirect
    header('Location: main.php');
    exit;
}

// Prevent caching of protected pages
//header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
//header('Cache-Control: post-check=0, pre-check=0', false);
//header('Pragma: no-cache');


//
//
//
//if (!isset($_SESSION)) { session_start(); }
//if (!isset($_SESSION['ATLAS_LOGIN_SYSADMIN'])) {
//    echo ('<script type="text/javascript">');
//    echo ('document.location.href="main.php";');
//    echo ('</script>');
//    exit;
//}
//else
//{
//    if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === false) { // available to Administrator only
//        echo ('<script type="text/javascript">');
//        echo ('document.location.href="main.php";');
//        echo ('</script>');
//        exit;
//    }
//}
