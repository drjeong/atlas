<?php
/**
 * Header
 * Description: displaying information about the system on the header.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2021 - initial version created.
 * 03/20/2024 - modal-open is added to support background scrolling while modal dialog is opened.
 *
 */


header("Expires: Tue, 01 Jan 2000 00:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>ATLAS: Academic Tracking & Learning Assessment System</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="Author" content="">
    <meta name="Keywords" content="">
    <meta name="Description" content="">
    <meta http-equiv="Expires" content="Tue, 01 Jan 2000 00:00:00 GMT">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">

     <!-- CSS dependencies -->
    <link rel="apple-touch-icon" sizes="180x180" href="./favicon_io/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./favicon_io/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./favicon_io/favicon-16x16.png">
    <link rel="shortcut icon" href="./favicon_io/apple-touch-icon.png">
    <link rel="manifest" href="./favicon_io/site.webmanifest">
<!--    <link rel="shortcut icon" href="./images/favicon.png" type="image/png"/>-->

    <link rel="stylesheet" type="text/css" href="/toolbox/jquery-ui-1.11.4.custom/jquery-ui.min.css" />
    <link rel="stylesheet" type="text/css" href="/toolbox/bootstrap-3.3.5-dist/css/bootstrap.min.css?v=3.4.1">
    <link rel="stylesheet" type="text/css" href="/toolbox/sweetalert2-11.4.5/sweetalert2.min.css?v=11.4.5" />
    <link rel="stylesheet" type="text/css" href="/toolbox/SyntaxHighlighter/shCore.css">
    <link rel="stylesheet" type="text/css" href="/toolbox/DataTables/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootbox.css?v=0.0.1">
    <link rel="stylesheet" type="text/css" href="css/table.css" />
    <link rel="stylesheet" type="text/css" href="css/datepickr.css" />
    <link rel="stylesheet" type="text/css" href="css/password.css" />
    <link rel="stylesheet" type="text/css" href="menu/menu.css" />
    <link rel="stylesheet" type="text/css" href="css/style-home.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

     <!-- JS dependencies -->
<!--    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>-->
    <script src="js/jquery-1.11.3.min.js"></script>

    <script src="/toolbox/jquery-ui-1.11.4.custom/jquery-ui.min.js"></script>
    <script src="/toolbox/bootstrap-3.3.5-dist/js/bootstrap.min.js?v=3.4.1"></script>
    <script src="/toolbox/DataTables/datatables.min.js?v=1.000"></script>
    <script src="/toolbox/sweetalert2-11.4.5/sweetalert2.all.min.js?v=11.4.5"></script>
    <script src="/toolbox/SyntaxHighlighter/shCore.js"></script>

    <script src="js/sessionexpire.min.js?v=0.0.101"></script>
    <script src="js/datepickr.min.js?v=0.0.1"></script>
    <script src="js/bootbox.js"></script>
    <script src="js/api_spinner.min.js?v=0.0.1"></script>
    <script src="js/api_commons.min.js?v=0.0.102"></script>
    <script src="js/async_commons.min.js?v=0.0.101"></script>
    <script src="js/changelogininfo.min.js?v=0.0.1"></script>
    <script src="js/disable-navigation.min.js?v=0.0.1"></script>
    <script src="menu/menu.js?v=0.0.1"></script>

    <script>
     String.prototype.isEmpty = String.prototype.isEmpty || function() {
             return !(!!this.trim().length);
         }
    </script>


     <style>
         /* Enable scrollbar for the body when modal is open */
         body.modal-open {
             overflow: auto !important;
         }
     </style>
 </head>

<body>
<?php include('menu.php'); ?>

