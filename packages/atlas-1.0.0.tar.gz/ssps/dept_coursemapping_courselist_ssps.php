<?php
/**
 * Listing courses
 * Description: listing courses in a dialog window
 *
 * 11/19/2024 - initial version created
 *
 */

include_once 'session_handler.php';


$AcademicYearIdx='';
if (array_key_exists('_AY', $_GET))
{
    $AcademicYearIdx = trim($_GET['_AY']);
}

$AcademicProgramIdx = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];
if (!isset($AcademicYearIdx) || !isset($AcademicProgramIdx)) {
    die(json_encode(['error' => 'Missing required parameters']));
}

// DB table to use
$table = 'Courses';

$joinQuery = "FROM `{$table}` AS `CRSES` 
    LEFT JOIN (
        SELECT a.*
        FROM `AbetSyllabus` a
        INNER JOIN (
            SELECT `CourseIndex`, MAX(`major_version`) as max_major
            FROM `AbetSyllabus`
            WHERE ({$AcademicYearIdx} BETWEEN `AcademicYearFrom` AND COALESCE(`AcademicYearTo`, 9999999999))
                AND `AcademicProgram` = {$AcademicProgramIdx}
            GROUP BY `CourseIndex`
        ) b ON a.`CourseIndex` = b.`CourseIndex` AND a.`major_version` = b.max_major
        INNER JOIN (
            SELECT `CourseIndex`, `major_version`, MAX(`minor_version`) as max_minor
            FROM `AbetSyllabus`
            WHERE ({$AcademicYearIdx} BETWEEN `AcademicYearFrom` AND COALESCE(`AcademicYearTo`, 9999999999))
                AND `AcademicProgram` = {$AcademicProgramIdx}
            GROUP BY `CourseIndex`, `major_version`
        ) c ON a.`CourseIndex` = c.`CourseIndex` 
            AND a.`major_version` = c.`major_version` 
            AND a.`minor_version` = c.`max_minor`
        WHERE ({$AcademicYearIdx} BETWEEN a.`AcademicYearFrom` AND COALESCE(a.`AcademicYearTo`, 9999999999))
    ) AS `LATEST_ABET_SYLLABUS` ON (`LATEST_ABET_SYLLABUS`.`CourseIndex` = `CRSES`.`Idx`)
    LEFT JOIN `AcademicPrograms` AS `APS` ON (`APS`.`Idx` = `LATEST_ABET_SYLLABUS`.`AcademicProgram`)";

// Table's primary key
$primaryKey = '`CRSES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`CRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`CRSES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`CRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`CRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`CRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`CRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`APS`.`Idx`', 'dt' => 'APIdx', 'field' => 'APIdx', 'as' => 'APIdx'),
    array( 'db' => '`APS`.`Name`', 'dt' => 'APName', 'field' => 'APName', 'as' => 'APName'),
    array( 'db' => '`LATEST_ABET_SYLLABUS`.`Idx`', 'dt' => 'ASIdx', 'field' => 'ASIdx', 'as' => 'ASIdx')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "  NOT EXISTS (
        SELECT 1 
        FROM `CourseMapping_Courses`
        WHERE `CourseIdx` = `CRSES`.`Idx`
        AND `AcademicYear` = {$AcademicYearIdx}
        AND `AcademicProgram` = {$AcademicProgramIdx} 
    ) 
    AND (`AcademicProgram` = {$AcademicProgramIdx} OR `AcademicProgram` IS NULL)";

$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

