<?php
/**
 * Academic Program Info
 * Description: displaying academic program information
 * Author: Dong Hyun Jeong
 *
 * 02/21/2021 - initial version created
 */


//--------------------------------- DB PROCESS ------------------------------------------------------
function AcademicProgramSelection()
{
    $programs = array();
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();
    $Query = "SELECT `APRGMS`.`Idx` AS `Idx`, `APRGMS`.`Name` AS `AcademicProgram`, `APRGMS`.`Degree` AS `AcademicDegree` 
        FROM `AcademicPrograms` AS `APRGMS` ORDER BY `APRGMS`.`Idx`";

    $DBCONNECTION->sendquery($Query);

    while ($row = $DBCONNECTION->fetch_assoc())
    {
        $programs[] = array(
            'Idx' => $row['Idx'],
            'AcademicProgram' => $row['AcademicProgram'],
            'AcademicDegree' => $row['AcademicDegree']
        );
    }

    unset($DBCONNECTION);

    return $programs;
}