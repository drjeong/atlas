<?php
/**
 * Listing Course Materials
 * Description: listing course materials
 *
 */

include_once 'session_handler.php';


$AvailableCourseIdx='';
if (array_key_exists('_AVC', $_GET))  {
    $AvailableCourseIdx = trim($_GET['_AVC']);
}
else {
    // illegal entry
    exit;
}

// DB table to use
$table = 'AVCourses_InstMaterials';
$joinQuery = "FROM `$table` AS `INSTMATERIALS` ";

// Table's primary key
$primaryKey = '`INSTMATERIALS`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`INSTMATERIALS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`INSTMATERIALS`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`INSTMATERIALS`.`MaterialType`', 'dt' => 'MaterialType', 'field' => 'MaterialType', 'as' => 'MaterialType'),
    array( 'db' => '`INSTMATERIALS`.`MaterialSample`', 'dt' => 'MaterialSample', 'field' => 'MaterialSample', 'as' => 'MaterialSample')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "`INSTMATERIALS`.`AvailableCourseIdx` = '$AvailableCourseIdx'";

$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
