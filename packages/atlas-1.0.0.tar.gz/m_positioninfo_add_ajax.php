<?php
/**
 * Management of Faculty Positions
 * Description: Adding faculty position information
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 09/29/2023 - Add validation check if position name exists.
 * 12/06/2024 - Change to use SP
 *
 */


include('checker_systemadmin.php');

$_Name = (isset($_POST['name'])) ? trim($_POST['name']) : '';
if ($_Name==='') { echo "0x00000011"; exit; }

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // convert unwanted escape strings
    $_Name = $DBCONNECTION->real_escape_string($_Name);

    /////////////////////////////////////////////////////////////////////////////////
    // insert PI
    $query = "CALL SP_AddPosition(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$_Name]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00200011') !== false) {
        echo '0x00200011';  // same item exists already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

