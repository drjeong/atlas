<?php
/**
 * Management of Syllabus of Master Courses
 * Description: managing syllabus information
 * Author: Dong Hyun Jeong
 *
 * 10/07/2024 - initial version created
 *
 */

include('checker_programdirector.php');

$CourseIndex = '';
$Subject = '';
$Title = '';
$Num = '';
$Credits = '';
$OldMajorVersion = '';
$OldMinorVersion = '';
$NewMajorVersion = '';
$NewMinorVersion = '';
$SyllabusIndex_PrevVersion = '';    // used when creating major or minor revision

if (array_key_exists('cindex', $_POST)
    && array_key_exists('Subject', $_POST)
    && array_key_exists('Title', $_POST)
    && array_key_exists('Num', $_POST)
    && array_key_exists('Credits', $_POST)
    && array_key_exists('si', $_POST) )
{
    $CourseIndex = trim($_POST['cindex']);
    $Subject = trim($_POST['Subject']);
    $Num = trim($_POST['Num']);
    $Title = trim($_POST['Title']);
    $Credits = trim($_POST['Credits']);

    $OldMajorVersion = (array_key_exists('OldMajorVersion', $_POST))?trim($_POST['OldMajorVersion']):'';
    $OldMinorVersion = (array_key_exists('OldMinorVersion', $_POST))?trim($_POST['OldMinorVersion']):'';
    $NewMajorVersion = (array_key_exists('NewMajorVersion', $_POST))?trim($_POST['NewMajorVersion']):'';
    $NewMinorVersion = (array_key_exists('NewMinorVersion', $_POST))?trim($_POST['NewMinorVersion']):'';
    $SyllabusIndex_PrevVersion = (array_key_exists('si', $_POST))?trim($_POST['si']):'';
} else {
     // unwanted illegal entry
    header('Location: dept_abetsyllabus.php');
    exit;
}

if ($SyllabusIndex_PrevVersion==""){
    // no required information
    header('Location: dept_abetsyllabus.php');
    exit;
}
include('header.php');

// using convertTextList function
require_once(__DIR__ . '/php_include/listfunc.php');

// fetch academic years
require_once('inc_academicyear_selection.php');
$ListAcademicYears = ListOfAcademicYears();

// Define fields to fetch
$fields = [
        'AcademicYearFrom', 'AcademicYearTo',
        'Description', 'Credits', 'Requirement', 'Pre_requisites',
        'Co_requisites', 'Required_Texts', 'Reference_Texts',
        'Coordinator', 'ObjectivesHeadline', 'Objectives',
        'TopicsCoveredHeadline', 'TopicsCovered', 'LinkedSyllabus', 'AcademicProgram'
];

// Initialize variables with default empty string
$data = array_fill_keys($fields, '');
$data['Idx'] = null;

//--------------------------------- DB PROCESS ------------------------------------------------------
require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

// Fetching basic abet syllabus information
$CourseIndex = $DBCONNECTION->escape_string($CourseIndex); // Assuming $CourseIndex is defined earlier
$query = "SELECT Idx, " . implode(', ', $fields) . " FROM `AbetSyllabus` WHERE `Idx` = ?";
$result = $DBCONNECTION->prepare_execute_catch_error($query, [$SyllabusIndex_PrevVersion]);

if ($result && $DBCONNECTION->num_rows() > 0) {
    $row = $DBCONNECTION->fetch_assoc();
    foreach ($fields as $field) {
        $data[$field] = $row[$field] ?? '';
    }
    $data['Idx'] = $row['Idx'];
    $SyllabusIndex_PrevVersion = $data['Idx'];
}
$data['newversion'] = $NewMajorVersion . '.' . $NewMinorVersion;
$data['AcademicYearFromOld'] = $data['AcademicYearFrom'];
$data['AcademicYearFrom'] = '';
$data['AcademicYearTo'] = null;

//print_r($data);

?>



<script type="text/javascript">
    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010'
    };

    function Back2SyllabusInfo(SyllabusIndex)
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_abetsyllabus_edit.php");
        $form.append($(document.createElement('input')).attr('name','cindex').val("<?php echo ($CourseIndex); ?>"));
        $form.append($(document.createElement('input')).attr('name','Subject').val("<?php echo ($Subject); ?>"));
        $form.append($(document.createElement('input')).attr('name','Title').val("<?php echo ($Title); ?>"));
        $form.append($(document.createElement('input')).attr('name','Num').val("<?php echo ($Num); ?>"));
        $form.append($(document.createElement('input')).attr('name','Credits').val("<?php echo ($Credits); ?>"));
        $form.append($(document.createElement('input')).attr('name','targetindex').val(SyllabusIndex));
        $("body").append($form);
        $form.submit();
    }

    // Function to validate the date format YYYY-MM-DD
    function isValidDate(dateString) {
        // Check if the input matches the format YYYY-MM-DD using a regular expression
        const regex = /^\d{4}-\d{2}-\d{2}$/;
        if (!dateString.match(regex)) return false;

        // Parse the date parts
        const parts = dateString.split("-");
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10);
        const day = parseInt(parts[2], 10);

        // Check the ranges of month and day
        if (month < 1 || month > 12) return false;
        if (day < 1 || day > 31) return false;

        // Handle month-specific day limits (accounting for leap years)
        const monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

        // Adjust for leap years
        if (month === 2) {
            const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
            if (isLeapYear) {
                monthLength[1] = 29;
            }
        }

        return day <= monthLength[month - 1];
    }

    function ValidateItems()
    {
        if (sylalbusfrm.Subject.value.isEmpty() || sylalbusfrm.Num.value.isEmpty())
        { // error
            return false;
        }
        const fields = [
            { element: sylalbusfrm.FromAcademicYears, message: "From Academic Years is not selected!!" },
            { element: sylalbusfrm.Description, message: "Description is not entered!!" },
            { element: sylalbusfrm.Credits, message: "Credits is not entered!!" },
            { element: sylalbusfrm.Requirement, message: "Requirement is not entered!!" },
            { element: sylalbusfrm.Pre_requisites, message: "Pre_requisites is not entered!!" },
            { element: sylalbusfrm.Required_Texts, message: "Required_Texts is not entered!!" },
            { element: sylalbusfrm.Coordinator, message: "Coordinator is not entered!!" },
            { element: sylalbusfrm.Objectives, message: "Objectives is not entered!!" },
            { element: sylalbusfrm.TopicsCovered, message: "TopicsCovered is not entered!!" },
            { element: sylalbusfrm.RevisionDesc, message: "Revision Description is not entered!!" },
            { element: sylalbusfrm.RevisionDate, message: "Revision Date is not entered!!" }
        ];

        for (const field of fields) {
            if (field.element.value.trim() === '') {
                field.element.focus();
                Swal.fire({ title: "ERROR", text: field.message, icon: "error" });
                return false;
            }
        }

        if (!sylalbusfrm.RevisionDate.value.isEmpty()) {
            if (!isValidDate(sylalbusfrm.RevisionDate.value)) {
                sylalbusfrm.RevisionDate.focus();
                Swal.fire({title:"ERROR", text: "Revision date is not valid!!", icon:"error"});
                return false;
            }
        }

        if (!sylalbusfrm.ApprovalDate.value.isEmpty()) {
            if (!isValidDate(sylalbusfrm.ApprovalDate.value)) {
                sylalbusfrm.ApprovalDate.focus();
                Swal.fire({title:"ERROR", text: "Approval date is not valid!!", icon:"error"});
                return false;
            }
        }

        //if (sylalbusfrm.FromAcademicYears.value == "<?php //echo($data['AcademicYearFromOld']);?>//") {
        //    sylalbusfrm.FromAcademicYears.focus();
        //    Swal.fire({title:"ERROR", text: "Applied academic years must be different from the previous version!!", icon:"error"});
        //    return false;
        //}

        return true;
    }

    function SaveRevision()
    {
        if (ValidateItems()===false) return;

        const form = document.getElementById('sylalbusfrm');
        const formData = new FormData(form);

        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                const data = xmlhttp.responseText.trim();
                const [error_code, message] = data.split(':').map(item => item.trim());
                switch(error_code)
                {
                    case"0x11111111": {
                        Swal.fire({
                            title: "UPDATED",
                            text: "The Syllabus Info has been updated!",
                            icon: "success",
                            timer: 2000
                        }).then(function(result){
                            Back2SyllabusInfo(message);
                            //location.reload();
                        });
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }

        xmlhttp.open("POST", "dept_abetsyllabus_revision_save_ajax.php", true);
        xmlhttp.send(formData);
    }

    function confirmBack(event) {
        event.preventDefault(); // Prevent immediate navigation

        Swal.fire({
            title: "BACK TO THE LIST?",
            html: "Current revision has not been saved. Are you sure you want to go back to the list?",
            icon: "question",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, go back!"
        }).then((result) => {
            if (result.isConfirmed) {

                const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_abetsyllabus_edit.php");
                $form.append($(document.createElement('input')).attr('name','cindex').val('<?php echo($CourseIndex);?>'));
                $form.append($(document.createElement('input')).attr('name','Subject').val('<?php echo($Subject);?>'));
                $form.append($(document.createElement('input')).attr('name','Title').val('<?php echo($Title);?>'));
                $form.append($(document.createElement('input')).attr('name','Num').val('<?php echo($Num);?>'));
                $form.append($(document.createElement('input')).attr('name','Credits').val('<?php echo($Credits);?>'));
                $form.append($(document.createElement('input')).attr('name','targetindex').val('<?php echo($SyllabusIndex_PrevVersion);?>'));
                $("body").append($form);
                $form.submit();
                // window.location.href = 'dept_abetsyllabus.php';
            }
        });
    }

</script>

<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;">
            <span class="largeheadline">&nbsp;SYLLABUS - <?php echo(strtoupper("$Subject $Num $Title"));?> </span>
        </p>
        <p style="margin-top:0.2in;text-align:center;">
            <span class="smallheadline" style="color: red">&nbsp;
            <?php if ($NewMajorVersion != $OldMajorVersion) echo "MAJOR REVISION";
                elseif ($NewMinorVersion != $OldMinorVersion) echo "MINOR REVISION"; ?>
                <br>
                Please note that basic syllabus information has been copied from the previous version.
            </span>
        </p>
	</div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
            <td style="width:20%">
                <ul class="nav nav-tabs" style="width:fit-content;">
                    <li class="nav-item">
                        <a href="#" onclick="confirmBack(event)" style="color: white; background-color: #007bff; padding: 8px 15px;">CANCEL (GO BACK)</a>
                    </li>
                </ul>
            </td>
			<td style="width:80%; text-align:right">
            </td>
		</tr>
		</table>

		<div class="CSSTable_SSPSLIST">
            <form name="sylalbusfrm" id="sylalbusfrm" method="" onsubmit="return false;" enctype="multipart/form-data">
                <input type="hidden" name="CourseIndex" value="<?php echo($CourseIndex); ?>">
                <input type="hidden" name="SyllabusIndex" value="<?php echo($SyllabusIndex_PrevVersion); ?>">
                <input type="hidden" name="Subject" value="<?php echo($Subject); ?>">
                <input type="hidden" name="Num" value="<?php echo($Num); ?>">
                <input type="hidden" name="OldMajorVersion" value="<?php echo($OldMajorVersion); ?>">
                <input type="hidden" name="OldMinorVersion" value="<?php echo($OldMinorVersion); ?>">
                <input type="hidden" name="MajorVersion" value="<?php echo($NewMajorVersion); ?>">
                <input type="hidden" name="MinorVersion" value="<?php echo($NewMinorVersion); ?>">
                <input type="hidden" name="AcademicProgram" value="<?php echo($data['AcademicProgram']); ?>">
                <input type="hidden" name="LinkedSyllabus" value="<?php echo($data['LinkedSyllabus']); ?>">

                <table style="border-spacing:0; padding:0; width:100%; ">
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%;">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Current Version<span style="color:red">*</span></span>
                                    <input type="text" name="version" id="version" class="input-sm form-control" value="<?php echo($data['newversion']); ?>" readonly>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%;">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Applied Academic Years<span style="color:red">*</span></span>
                                    <div class="input-group" style="width:100%">
                                        <span class="input-group-addon" style="width:230px;">FROM: </span>
                                        <select name="FromAcademicYears" id="FromAcademicYears" class="input-sm form-control">
                                            <?php if ($data['AcademicYearFrom']=='') echo ('<option value="" selected></option>');?>
                                            <?php foreach ($ListAcademicYears as $ayears): ?>
                                            <option value="<?php echo($ayears['Idx']);?>" <?php echo($ayears['Idx']==$data['AcademicYearFrom']?'selected':'');?>><?php echo($ayears['AcademicYear']);?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="input-group" style="width:100%">
                                        <span class="input-group-addon" style="width:230px;">To: </span>
                                        <select name="ToAcademicYears" id="ToAcademicYears" class="input-sm form-control">
                                            <?php if ($data['AcademicYearTo']==null) echo ('<option value="" selected>Current</option>');
                                            else if ($data['AcademicYearTo']=='') echo ('<option value="" selected></option>'); ?>
                                            <?php foreach ($ListAcademicYears as $ayears): ?>
                                                <option value="<?php echo($ayears['Idx']);?>" <?php echo($ayears['Idx']==$data['AcademicYearTo']?'selected':'');?>><?php echo($ayears['AcademicYear']);?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%;">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Catalog Description<span style="color:red">*</span></span>
                                    <textarea id="Description" name="Description" class="input-sm form-control" style="min-height: 100px;"><?php echo($data['Description']); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%;">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Credits<span style="color:red">*</span></span>
                                    <input type="text" name="Credits" id="Credits" class="input-sm form-control" value="<?php echo($data['Credits']); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Requirement<span style="color:red">*</span></span>
                                    <input type="text" name="Requirement" id="Requirement" class="input-sm form-control" value="<?php echo($data['Requirement']); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%; "><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Pre-requisites<span style="color:red">*</span></span>
                                    <textarea id="Pre_requisites" name="Pre_requisites" class="input-sm form-control" style="min-height: 60px;"><?php echo(convertTextList($data['Pre_requisites'])); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Co-requisites<span style="color:red"></span></span>
                                    <input type="text" name="Co_requisites" id="Co_requisites" class="input-sm form-control" value="<?php echo($data['Co_requisites']); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Required Texts<span style="color:red">*</span></span>
                                    <textarea id="Required_Texts" name="Required_Texts" class="input-sm form-control" style="min-height: 60px;"><?php echo(convertTextList($data['Required_Texts'])); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Reference Texts<span style="color:red"></span></span>
                                    <textarea id="ReferenceTexts" name="ReferenceTexts" class="input-sm form-control" style="min-height: 60px;"><?php echo(convertTextList($data['Reference_Texts'])); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Coordinator<span style="color:red">*</span></span>
                                    <input type="text" name="Coordinator" id="Coordinator" class="input-sm form-control" value="<?php echo($data['Coordinator']); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Objectives<span style="color:red">*</span></span>
                                    <textarea id="ObjectivesHeadline" name="ObjectivesHeadline" class="input-sm form-control" style="min-height: 120px;"><?php echo($data['ObjectivesHeadline']); ?></textarea>
                                    <textarea id="Objectives" name="Objectives" class="input-sm form-control" style="min-height: 120px;"><?php echo(convertTextList($data['Objectives'])); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">TopicsCovered<span style="color:red">*</span></span>
                                    <input type="text" name="TopicsCoveredHeadline" id="TopicsCoveredHeadline" class="input-sm form-control" value="<?php echo($data['TopicsCoveredHeadline']); ?>">
                                    <textarea id="TopicsCovered" name="TopicsCovered" class="input-sm form-control" style="min-height: 280px;"><?php echo(convertTextList($data['TopicsCovered'])); ?></textarea>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Revision Description<span style="color:red">*</span></span>
                                    <input type="text" name="RevisionDesc" id="RevisionDesc" class="input-sm form-control" value="">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td style="border: 1px solid darkgray;">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Revision Date<span style="color:red">*</span></span>
                                    <input type="text" name="RevisionDate" id="RevisionDate" class="input-sm form-control" value="<?php echo date('Y-m-d'); ?>">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Approval Description<span style="color:red"></span></span>
                                    <input type="text" name="ApprovalDesc" id="ApprovalDesc" class="input-sm form-control" value="">
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <div class="input-group" style="width:100%">
                                <div class="input-group" style="width:100%;"><span class="input-group-addon" style="width:250px; color: black; background-color:#efbd47;">Approval Date (YYYY-MM-DD)<span style="color:red"></span></span>
                                    <input type="text" name="ApprovalDate" id="ApprovalDate" class="input-sm form-control" value="">
                                </div>
                            </div>
                        </td>
                    </tr>

                </table>

            </form>

		</div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-floppy-save" onclick="SaveRevision();">&nbsp;SAVE REVISION</button>
                </td>
            </tr>
        </table>

    </div>
</div>

<?php include('footer.php');?>
