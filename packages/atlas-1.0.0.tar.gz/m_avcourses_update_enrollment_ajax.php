<?php
/**
 * Update Enrollment Count for Available Course
 * Author: Dong Hyun Jeong
 */

include_once 'session_handler.php';

// Get parameters
$avcIdx = isset($_POST['avcIdx']) ? intval($_POST['avcIdx']) : 0;
$enrollment = isset($_POST['enrollment']) ? intval($_POST['enrollment']) : 0;

// Validate parameters
if ($avcIdx <= 0 || $enrollment < 0) {
    echo '0x00000001'; // Invalid parameters
    exit;
}

try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Verify the course exists
    $query = "SELECT `Idx` FROM `AVCourses` WHERE `Idx` = ?";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$avcIdx]);
    $row = $result->fetch_assoc();

    if (!$row) {
        echo "0x00000001"; // Invalid parameters - course not found
        exit;
    }

    // Update the enrollment count
    $updateQuery = "UPDATE `AVCourses` 
                    SET `Actual` = ?, `IsManuallyEdited` = 1
                    WHERE `Idx` = ?";
    $DBCONNECTION->prepare_execute_catch_error($updateQuery, [$enrollment, $avcIdx]);

    echo "0x11111111"; // Success

} catch (mysqli_sql_exception $e) {
    error_log("Error updating enrollment: " . $e->getMessage());
    echo "0x00000500"; // Database error
} catch (Exception $e) {
    error_log("Error updating enrollment: " . $e->getMessage());
    echo "0x00000000"; // General error
}
?>