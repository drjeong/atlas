<?php
include_once 'session_handler.php';

$avcIdx = isset($_POST['avcIdx']) ? intval($_POST['avcIdx']) : 0;
$userIdx = isset($_POST['userIdx']) ? intval($_POST['userIdx']) : 0;

if ($avcIdx <= 0 || $userIdx <= 0) {
    echo "0x00000001"; // Invalid parameters
    exit;
}

try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Verify that this instructor is assigned to this course
    $checkQuery = "SELECT COUNT(*) as count FROM `AVCoursesInstructors` 
                   WHERE `AVCourseIdx` = ? AND `Instructor` = ?";
    $checkResult = $DBCONNECTION->prepare_execute_catch_error($checkQuery, [$avcIdx, $userIdx]);
    $checkRow = $checkResult->fetch_assoc();

    if ($checkRow['count'] == 0) {
        echo "0x00000001"; // Instructor not assigned to this course
        exit;
    }

    // Get the email of the new primary instructor
    $emailQuery = "SELECT `Email` FROM `UserAccounts` WHERE `Idx` = ?";
    $emailResult = $DBCONNECTION->prepare_execute_catch_error($emailQuery, [$userIdx]);
    $emailRow = $emailResult->fetch_assoc();

    if (!$emailRow) {
        echo "0x00000001"; // User not found
        exit;
    }

    $primaryEmail = $emailRow['Email'];

    // Update the InstructorEmail field in AVCourses table
    $updateCourseQuery = "UPDATE `AVCourses` 
                         SET `InstructorEmail` = ? 
                         WHERE `Idx` = ?";
    $DBCONNECTION->prepare_execute_catch_error($updateCourseQuery, [$primaryEmail, $avcIdx]);

    echo "0x11111111"; // Success

} catch (mysqli_sql_exception $e) {
    error_log("Error setting primary instructor: " . $e->getMessage());
    echo "0x00000500"; // Database error
} catch (Exception $e) {
    error_log("Error setting primary instructor: " . $e->getMessage());
    echo "0x00000000"; // General error
}
?>