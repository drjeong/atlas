<?php
/**
 * Management of All Courses
 * Description: managing courses
 * Author: Dong Hyun Jeong
 *
 * 03/28/2024 - initial version created
 *
 */


include('checker_programdirector.php');
include('header.php');

?>

<script src="js/datatable-utils-search.min.js"></script>


<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
<script type="text/javascript">

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        SAME_ITEM_EXIST: '0x00200011',
        ITEM_NOT_EXIST: '0x00200012',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
    };


    async function AddCourse_Perform(_Subj, _Num, _Title, _Credits) {
        try {
            const result = await async_commons.makeApiCall('m_courses_add_ajax.php', {
                subj: _Subj,
                num: _Num,
                title: _Title,
                cr: _Credits
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'Course is added successfully!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `The entered course exists already!`
                    );
                    // Re-open the add dialog
                    AddCourse(_Subj, _Num, _Title, _Credits);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }


    function AddCourse(_Subj='', _Num='', _Title='', _Credits='')
    {
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
             <div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%">
                <span class="input-group-addon" style="width:200px;">Subject<span style="color:red">*</span></span>
                <input type="text"
                       name="_Subj"
                       id="_Subj"
                       class="input-sm form-control"
                       value="${_Subj}"
                       placeholder="ex) CSCI, MECH, APCT, ..."
                       required
                       style="text-transform: uppercase;"
                       oninput="this.value = this.value.toUpperCase()">
              </div>
              <div class="input-group" style="width:100%">
                <span class="input-group-addon" style="width:200px;">Number<span style="color:red">*</span></span>
                <input type="text" name="_Num" id="_Num" class="input-sm form-control" value="${_Num}" placeholder="ex) 100, 200, 300, ..." required>
              </div>
              <div class="input-group" style="width:100%">
                <span class="input-group-addon" style="width:200px;">Title<span style="color:red">*</span></span>
                <input type="text" name="_Title" id="_Title" class="input-sm form-control" value="${_Title}" placeholder="ex) Course Title" required>
              </div>
              <div class="input-group" style="width:100%">
                <span class="input-group-addon" style="width:200px;">Credits<span style="color:red">*</span></span>
                <input type="text" name="_Credits" id="_Credits" class="input-sm form-control" value="${_Credits}" placeholder="ex) 3" required>
              </div>
             </div>
             </td></tr>
             </table></form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD COURSE</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;FETCH",
                    className: 'btn-success',
                    callback: function(){
                        if (ValidateItems(popupfrm)===false) return false;
                        AddCourse_Perform(popupfrm._Subj.value, popupfrm._Num.value,
                            popupfrm._Title.value, popupfrm._Credits.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_Subj").focus();
        });
    }

    function ValidateItems(frm)
    {
        const fields = [
            { element: frm._Subj, message: "Subject is not selected!!" },
            { element: frm._Num, message: "Number is not entered!!" },
            { element: frm._Title, message: "Title is not entered!!" },
            { element: frm._Credits, message: "Credits is not entered!!" }
        ];

        for (const field of fields) {
            if (field.element.value.trim() === '') {
                field.element.focus();

                Swal.fire({ title: "ERROR", text: field.message, icon: "error" });
                return false;
            }
        }
        return true;
    }

    async function UpdateCourseInfo(Idx, Subject, Num, Title, TitleUniv, Credits) {
        try {
            const result = await async_commons.makeApiCall('m_courses_update_ajax.php', {
                id: Idx,
                subject: Subject,
                num: Num,
                title: Title,
                titleuniv: TitleUniv,
                credits: Credits
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Information has been updated!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `The entered information exists already!`
                    );
                    // Re-open the add dialog
                    ModifyCourse(Idx, Subject, Num, Title, TitleUniv, Credits);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function RemoveCourse(Idx, Subject, Num, Title){
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted content (<span style="color:red">${Subject} ${Num} ${Title}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('m_course_remove_ajax.php', {
                id: Idx
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected course has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected course cannot be removed!! It has been used already!!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function ModifyCourse(Idx, Subject, Num, Title, TitleUniv, Credits)
    {
        const formContent = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<input type="hidden" name="Idx" value="'+Idx+'">'
            + '<table style="border-spacing:0; padding:0; width:100%;">'
            + '<tr><td colspan="2">'
            + '<div class="input-group" style="width:100%">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Subject<span style="color:red">*</span></span>'
            + '     <input type="text" name="_Subj" id="_Subj" class="input-sm form-control" value="'+Subject+'" required>'
            + ' </div>'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Number<span style="color:red">*</span></span>'
            + '     <input type="text" name="_Num" id="_Num" class="input-sm form-control" value="'+Num+'" required>'
            + ' </div>'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Standard Course Title<span style="color:red">*</span></span>'
            + '     <input type="text" name="_Title" id="_Title" class="input-sm form-control" value="'+Title+'" required>'
            + ' </div>'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Title in Univ. System<span style="color:red">*</span></span>'
            + '     <input type="text" name="_TitleUniv" id="_TitleUniv" class="input-sm form-control" value="'+TitleUniv+'" required>'
            + ' </div>'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Credits<span style="color:red">*</span></span>'
            + '     <input type="text" name="_Credits" id="_Credits" class="input-sm form-control" value="'+Credits+'" required>'
            + ' </div>'
            + '</div>'
            + '</td></tr>'
            + '<tr><td colspan="2" style="padding-top:15px;">'
            + '<div style="background-color:#f8f9fa; padding:10px; border-left:3px solid #007bff; font-size:12px; color:#555;">'
            + '<strong>Note:</strong> The "Title in Univ. System" is used to cross-reference with course syllabus and available courses in the university system.'
            + '</div>'
            + '</td></tr>'
            + '</table></form>';

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">EDIT COURSE INFO</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;UPDATE",
                    className: 'btn-success',
                    callback: function(){
                        if (ValidateItems(popupfrm)===false) return false;
                        UpdateCourseInfo(popupfrm.Idx.value, popupfrm._Subj.value,
                            popupfrm._Num.value, popupfrm._Title.value, popupfrm._TitleUniv.value, popupfrm._Credits.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }

        }).find('.modal-dialog').css({
            'margin-top': function (){
                let w = $( window ).height();
                let b = $(this).height();
                let h = (w-b)*0.2
                return h+"px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"   // enable draggable dialog
        }).find('.modal-header').css({
            'cursor': 'move'            // change mouse cursor for dragging on modal header
        });
    }
</script>
<?php
}
?>

<script class="init">
$(document).ready(function() {

    DataTable_Courses = $("#courseinfo").DataTable({
        dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
        "processing": true,
        "serverSide": true,
        "lengthMenu": [ 50, 100, 150, 300, 500 ],
        "search": {
            "regex": true
        },
        "fnInitComplete": function(oSettings, json) {
            // Add "Clear Filter" button to Filter
            let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
            btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
            $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                $('#' + oSettings.sTableId).dataTable().fnFilter('');
            });
        },
        "ajax": "ssps/m_courses_ssps.php",
        "oLanguage": {"sInfoFiltered": ""},
        "columns": [
            { "data": 'Subject' },
            { "data": 'Num' },
            { "data": 'Title' },
            { "data": 'TitleUniv' },
            { "data": 'Credits' },
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
            { "data": '' } // used for representing menu options
<?php
}
?>
        ],
        "order": [[ 0, 'dsc' ], [ 1, 'asc' ]],
        "fnDrawCallback": function() {
            $('#courseinfo tr td:nth-child(1)').css('text-align', 'center');
            $('#courseinfo tr td:nth-child(2)').css('text-align', 'center');
            $('#courseinfo tr td:nth-child(3)').css('text-align', 'center');
            $('#courseinfo tr td:nth-child(4)').css('text-align', 'center');
            $('#courseinfo tr td:nth-child(5)').css('text-align', 'center');
        },
        "columnDefs": [ {
            "targets"  : 'no-sort',
            "orderable": false,
        }
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
        ,{
                "targets": -1,
                "data": null,
                "orderable": false,
                "defaultContent": "<div style=\"width:100%;text-align:center;\"><button id=\"modify\" class=\"btn btn-danger btn-xs glyphicon glyphicon-wrench\" style=\"min-height: 20px;\"></button>&nbsp;<button id=\"remove\" class=\"btn btn-danger btn-xs glyphicon glyphicon-remove\" style=\"min-height: 20px;\"></button></div>"
        }
<?php
}
?>
        ],
        "buttons": [ {
            "extend": 'excelHtml5',
            "title": 'Available Courses',
            "text": '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
            "className": 'btn btn-xs',
            "attr": {
                "style": 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
            },
        }]
    });


<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
    async_commons.setDataTable(DataTable_Courses);

    $('#courseinfo tbody').on( 'click', '#remove', function () {
        const data = DataTable_Courses.row( $(this).parents('tr') ).data();
        RemoveCourse(data.Idx, data.Subject, data.Num, data.Title);
    } );

    $('#courseinfo tbody').on( 'click', '#modify', function () {
        const data = DataTable_Courses.row( $(this).parents('tr') ).data();
        ModifyCourse(data.Idx, data.Subject, data.Num, data.Title, data.TitleUniv, data.Credits);
    } );
<?php
}
?>

    // Initialize the column search functionality
    new DataTableSearch('#courseinfo', DataTable_Courses);

} );

</script>


<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">&nbsp;COURSES AVAILABLE IN THE UNIVERSITY SYSTEM</span>&nbsp;</p>
        <div class="alert alert-warning" style="width: 80%; margin: 10px auto; text-align: center; padding: 10px;">
            <i class="glyphicon glyphicon-info-sign"></i> Courses are automatically added when uploading available courses.
        </div>
	</div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
			<td style="width:20%">
            </td>
			<td style="width:80%; text-align:right">
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
                <button class="btn btn-danger btn-sm glyphicon glyphicon-download" onclick="AddCourse(); return false;">&nbsp;ADD COURSE</button>
<?php
}
?>
            </td>
		</tr>
		</table>

		<div class="CSSTable_SSPSLIST">
		<table id="courseinfo" class="display" style="border-spacing:0; padding:0; width:100%;">
            <thead>
            <tr>
                <th>SUBJ</th>
                <th>NUM</th>
                <th>STANDARD COURSE TITLE</th>
                <th>TITLE IN UNIVERSITY SYSTEM</th>
                <th>CREDITS</th>
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
                    <th class="no-sort">OPERATION</th>
<?php
}
?>
            </tr>
            </thead>
            <thead id="serachbox" class="filters">
                <tr>
                    <th>SUBJ</th>
                    <th>NUM</th>
                    <th>STANDARD COURSE TITLE</th>
                    <th>TITLE IN UNIVERSITY SYSTEM</th>
				    <th>CREDITS</th>
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
                 <th class="no-sort"></th>
<?php
}
?>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>SUBJ</th>
                    <th>NUM</th>
                    <th>STANDARD COURSE TITLE</th>
                    <th>TITLE IN UNIVERSITY SYSTEM</th>
                    <th>CREDITS</th>
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
                  <th>OPERATION</th>
<?php
}
?>
                </tr>
            </tfoot>
		</table>
		</div>
	</div>
</div>


<?php include('footer.php'); ?>

