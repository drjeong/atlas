<?php
/**
 * Listing Faculty Workloads by Department
 * File: m_fworkloads_bydepts_ssps.php
 * Description: listing faculty workloads with grouped courses filtered by department
 *
 * 08/09/2026 Modified to use Semesters table join instead of FUNC_GetYearSem
 */
include_once 'session_handler.php';

// If either session variable is not set or empty, return empty data
if (empty($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM']) ||
    empty($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO']) ||
    empty($_SESSION['ATLAS_SELECTED_DEPARTMENT'])) {
    echo json_encode(array(
        "draw" => isset($_GET['draw']) ? intval($_GET['draw']) : 0,
        "recordsTotal" => 0,
        "recordsFiltered" => 0,
        "data" => array()
    ));
    exit;
}

require_once(__DIR__ . '/../../config.php');

// DB table to use
$table = 'AVCourses';

// Updated JOIN query to filter by department through Subjects table
$joinQuery = "FROM `{$table}` AS `AVCRSES` 
    INNER JOIN `Subjects` AS `SBJTS` ON (`SBJTS`.`Name`=`AVCRSES`.`Subject`)
    LEFT JOIN `Semesters` AS `SMSTRS` ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
    LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` ON (`AVCRSES`.`Idx`=`AVINSTRUCTORS`.`AVCourseIdx`) 
    INNER JOIN `UserAccounts` AS `UA` ON (`AVINSTRUCTORS`.`Instructor`=`UA`.`Idx` AND `UA`.`Affiliation`='".$_SESSION['ATLAS_SELECTED_DEPARTMENT']."')
    INNER JOIN `AcademicYears` AS `AYS` ON (`AVCRSES`.`Semester` BETWEEN `AYS`.`From` AND `AYS`.`To`)";

// Table's primary key
$primaryKey = 'CRN';

// Array of database columns - simplified for workloads
$columns = array(
    array('db' => '`AVCRSES`.`Semester`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function ($d, $row) {
        return $d; // Return semester code for sorting
    }),
    array('db' => '`AVCRSES`.`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array(
        'db' => '`SMSTRS`.`Explanation`',
        'dt' => 'SemesterTxt',
        'field' => 'SemesterTxt',
        'as' => 'SemesterTxt'
    ),
    array('db' => '`AVCRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array('db' => '`AVCRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array('db' => '`AVCRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array('db' => '`AVCRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array('db' => '`SBJTS`.`Name`', 'dt' => 'SubjectName', 'field' => 'SubjectName', 'as' => 'SubjectName'),
    array('db' => '(SELECT GROUP_CONCAT(`UA2`.`Name` ORDER BY `UA2`.`Name` SEPARATOR \', \') 
                    FROM `AVCoursesInstructors` AS `AVINST2` 
                    LEFT JOIN `UserAccounts` AS `UA2` ON `AVINST2`.`Instructor`=`UA2`.`Idx` 
                    WHERE `AVINST2`.`AVCourseIdx`=`AVCRSES`.`Idx`)',
        'dt' => 'Instructor',
        'field' => 'Instructor',
        'as' => 'Instructor')
);

require('ssp.join.class.php');

// Build WHERE clause for semester range using session variables
$extraWhere = "";

$SemesterFrom = $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM'];
$SemesterTo = $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO'];

// Create semester range filter
if ($SemesterFrom <= $SemesterTo) {
    $extraWhere = "`AVCRSES`.`Semester` BETWEEN '" . $SemesterFrom . "' AND '" . $SemesterTo . "'";
} else {
    // If FROM is greater than TO, swap them
    $extraWhere = "`AVCRSES`.`Semester` BETWEEN '" . $SemesterTo . "' AND '" . $SemesterFrom . "'";
}

// Note: Department filter is already handled in the JOIN clause through Subjects table
// No need to add it to extraWhere

$groupBy = " `AVCRSES`.`Idx` ";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery($_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

