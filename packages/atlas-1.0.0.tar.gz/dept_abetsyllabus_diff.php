<?php
/**
 * Management of Syllabus of Master Courses
 * Description: Show differences of two syllabus versions
 * Author: Dong Hyun Jeong
 *
 * 10/07/2024 - initial version created
 *
 */

//include('checker_programdirector.php');

$CourseIndex = '';
$CurrentSyllabusIndex = '';
$TargetSyllabusIndex = '';
$Subject = '';
$Title = '';
$Num = '';

if (array_key_exists('cindex', $_POST)
    && array_key_exists('currentindex', $_POST)
    && array_key_exists('targetindex', $_POST)
    && array_key_exists('Subject', $_POST)
    && array_key_exists('Title', $_POST)
    && array_key_exists('Num', $_POST) )
{
    $CourseIndex = trim($_POST['cindex']);
    $CurrentSyllabusIndex = trim($_POST['currentindex']);
    $TargetSyllabusIndex = trim($_POST['targetindex']);
    $Subject = trim($_POST['Subject']);
    $Num = trim($_POST['Num']);
    $Title = trim($_POST['Title']);
} else {
    // unwanted illegal entry
    header('Location: dept_abetsyllabus.php');
    exit;
}
include('header.php');

if ($CurrentSyllabusIndex=="" || $TargetSyllabusIndex==""){
    // no required information
    header('Location: dept_abetsyllabus.php');
    exit;
}

// using convertTextList function
require_once(__DIR__ . '/php_include/listfunc.php');

// fetch academic years
require_once('inc_academicyear_selection.php');
$ListAcademicYears = ListOfAcademicYears();

//--------------------------------- DB PROCESS ------------------------------------------------------
require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

// Fetching abet syllabus information for different versions
$results = $DBCONNECTION->callStoredProcedure('SP_AbetSyllabus_FetchDiffInfo', [$CurrentSyllabusIndex, $TargetSyllabusIndex, ]);

//echo ($CurrentSyllabusIndex . ' '.$TargetSyllabusIndex);

// Check if results are returned
$data = null;
if ($results) {
    // Fetch and display the results
    while ($row = $results->fetch_assoc()) {
        $data = $row;
    }
}

//list($data['AcademicYearFrom_1'], $data['AcademicYearFrom_2']) = highlightDifferences($data['AcademicYearFrom_1'], $data['AcademicYearFrom_2']);
//list($data['AcademicYearTo_1'], $data['AcademicYearTo_2']) = highlightDifferences($data['AcademicYearTo_1'], $data['AcademicYearTo_2']);
list($data['Description_1'], $data['Description_2']) = highlightDifferences($data['Description_1'], $data['Description_2']);
list($data['Credits_1'], $data['Credits_2']) = highlightDifferences($data['Credits_1'], $data['Credits_2']);
list($data['Requirement_1'], $data['Requirement_2']) = highlightDifferences($data['Requirement_1'], $data['Requirement_2']);
list($data['Pre_requisites_1'], $data['Pre_requisites_2']) = highlightDifferences($data['Pre_requisites_1'], $data['Pre_requisites_2']);
list($data['Co_requisites_1'], $data['Co_requisites_2']) = highlightDifferences($data['Co_requisites_1'], $data['Co_requisites_2']);
list($data['Required_Texts_1'], $data['Required_Texts_2']) = highlightDifferences($data['Required_Texts_1'], $data['Required_Texts_2']);
list($data['Reference_Texts_1'], $data['Reference_Texts_2']) = highlightDifferences($data['Reference_Texts_1'], $data['Reference_Texts_2']);
list($data['Coordinator_1'], $data['Coordinator_2']) = highlightDifferences($data['Coordinator_1'], $data['Coordinator_2']);
list($data['ObjectivesHeadline_1'], $data['ObjectivesHeadline_2']) = highlightDifferences($data['ObjectivesHeadline_1'], $data['ObjectivesHeadline_2']);
list($data['Objectives_1'], $data['Objectives_2']) = highlightDifferences($data['Objectives_1'], $data['Objectives_2']);
list($data['TopicsCoveredHeadline_1'], $data['TopicsCoveredHeadline_2']) = highlightDifferences($data['TopicsCoveredHeadline_1'], $data['TopicsCoveredHeadline_2']);
list($data['TopicsCovered_1'], $data['TopicsCovered_2']) = highlightDifferences($data['TopicsCovered_1'], $data['TopicsCovered_2']);

?>

<script type="text/javascript">

    function Back2SyllabusInfo()
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_abetsyllabus_edit.php");
        $form.append($(document.createElement('input')).attr('name','cindex').val("<?php echo ($CourseIndex); ?>"));
        $form.append($(document.createElement('input')).attr('name','Subject').val("<?php echo ($Subject); ?>"));
        $form.append($(document.createElement('input')).attr('name','Title').val("<?php echo ($Title); ?>"));
        $form.append($(document.createElement('input')).attr('name','Num').val("<?php echo ($Num); ?>"));
        $form.append($(document.createElement('input')).attr('name','targetindex').val("<?php echo ($CurrentSyllabusIndex); ?>"));
        $("body").append($form);
        $form.submit();
    }

    <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
    function DownloadDiffLatex()
    {
        // Show the full page spinner
        showFullPageSpinner();
        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
            xmlhttp.responseType = "blob";
        } else { // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
                // Hide spinner and show notification
                hideFullPageSpinner();
                const blob = xmlhttp.response;

                // Check if we received a blob response
                if (blob && blob.size > 0) {
                    let link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    <?php
                    $LatexFileName = 'abet_syllabus';
                    $LatexFileName .= '_'. str_replace(" ","_",strtolower($Subject));
                    $LatexFileName .= '_'. str_replace(" ","_",strtolower($Num));
                    $LatexFileName .= '_diff.tex';  // Changed from .pdf to .tex
                    ?>
                    link.download = "<?php echo($LatexFileName); ?>";
                    link.click();

                    // Clean up
                    setTimeout(() => {
                        window.URL.revokeObjectURL(link.href);
                    }, 100);

                    Swal.fire({
                        title: "SUCCESS",
                        text: "LaTeX file downloaded successfully!",
                        icon: "success"
                    });
                }
                else {
                    Swal.fire({
                        title: "ERROR",
                        text: "No content received. Please contact the system administrator!!",
                        icon: "error"
                    });
                }
            }
            else if (xmlhttp.readyState === 4) {
                // Handle error status codes
                hideFullPageSpinner();
                Swal.fire({
                    title: "ERROR",
                    text: "Failed to download file. Please contact the system administrator!!",
                    icon: "error"
                });
            }
        }
        const param = "create_abetsyllabus_diff_latex.php?cidx=<?php echo($CurrentSyllabusIndex); ?>&tidx=<?php echo($TargetSyllabusIndex); ?>&sub="+encodeURIComponent('<?php echo($Subject);?>')+"&num=<?php echo($Num);?>&title="+encodeURIComponent('<?php echo($Title);?>');
        xmlhttp.open("GET", param, true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send();
    }
    <?php } ?>

    function DownloadDiff()
    {
        // Show the full page spinner
        showFullPageSpinner();

        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
            xmlhttp.responseType = "blob";
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                // Hide spinner and show notification
                hideFullPageSpinner();

                const blob = xmlhttp.response;
                if (blob.type === "application/pdf") {
                    // let blob=new Blob([data], { type: "application/pdf" });
                    let link=document.createElement('a');
                    link.href=window.URL.createObjectURL(blob);
                    <?php
                    $AssessmentPDF_FileName = 'abet_syllabus';
                    $AssessmentPDF_FileName .= '_'. str_replace(" ","_",strtolower($Subject));
                    $AssessmentPDF_FileName .= '_'. str_replace(" ","_",strtolower($Num));
                    $AssessmentPDF_FileName .= '_diff.pdf';
                    ?>
                    link.download="<?php echo($AssessmentPDF_FileName); ?>";
                    link.click();

                    // Clean up
                    setTimeout(() => {
                        window.URL.revokeObjectURL(link.href);
                    }, 100);
                }
                else {
                    Swal.fire({title:"ERROR", text: "Unknown error found. Please contact the system administrator!!", icon:"error"});
                }
            }
        }
        const param = "create_abetsyllabus_diff_pdf.php?cidx=<?php echo($CurrentSyllabusIndex); ?>&tidx=<?php echo($TargetSyllabusIndex); ?>&sub="+encodeURIComponent('<?php echo($Subject);?>')+"&num=<?php echo($Num);?>&title="+encodeURIComponent('<?php echo($Title);?>');
        xmlhttp.open("GET", param, true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send();
    }
</script>

<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;">
            <span class="largeheadline">&nbsp;SYLLABUS - <?php echo(strtoupper("$Subject $Num $Title"));?> </span>
        </p>
	</div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
			<td style="width:20%">
                <ul class="nav nav-tabs" style="width:fit-content;">
                    <li class="nav-item"><a href="" onclick="Back2SyllabusInfo(); return false;" style="color: white; background-color: #007bff; padding: 8px 15px;">BACK TO THE SYLLABUS INFO</a></li>
                </ul>
            </td>
			<td style="width:80%; text-align:right">
                <button class="btn btn-success btn-sm" title="Download Syllabus Difference" onclick="DownloadDiff()"><i class="glyphicon glyphicon-floppy-save"></i> Download Syllabus Difference</button>
                <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
                <button class="btn btn-warning btn-sm" title="Download Syllabus Difference" onclick="DownloadDiffLatex()"><i class="glyphicon glyphicon-floppy-save"></i> Latex</button>
                <?php } ?>
            </td>
		</tr>
		</table>


		<div class="CSSTable_SSPSLIST">
                <table style="border-spacing:0; padding:0; width:100%; ">
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Version</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt; font-weight: bold;">
                                    <?php echo($data['Version_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt; font-weight: bold;"><?php echo($data['Version_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Applied Academic Years</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo($data['AcademicYearFrom_1']); ?> ~ <?php echo($data['AcademicYearTo_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;"><?php echo($data['AcademicYearFrom_2']); ?> - <?php echo($data['AcademicYearTo_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Catalog Description</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo($data['Description_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;"><?php echo($data['Description_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Credits</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo($data['Credits_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;"><?php echo($data['Credits_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Requirement</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo($data['Requirement_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;"><?php echo($data['Requirement_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Pre-requisites</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['Pre_requisites_1'], "</br>")); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['Pre_requisites_2'], "</br>")); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Co-requisites</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo($data['Co_requisites_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;"><?php echo($data['Co_requisites_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Required Texts</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['Required_Texts_1'], "</br>")); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['Required_Texts_2'], "</br>")); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Reference Texts</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['Reference_Texts_1'], "</br>")); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['Reference_Texts_2'], "</br>")); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Coordinator</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo($data['Coordinator_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;"><?php echo($data['Coordinator_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Objectives</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['ObjectivesHeadline_1'], "</br>")); ?>
                                    <?php echo(convertTextList($data['Objectives_1'], "</br>")); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['ObjectivesHeadline_2'], "</br>")); ?>
                                    <?php echo(convertTextList($data['Objectives_2'], "</br>")); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Topics Covered</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['TopicsCoveredHeadline_1'], "</br>")); ?>
                                    <?php echo(convertTextList($data['TopicsCovered_1'], "</br>")); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt;">
                                    <?php echo(convertTextList($data['TopicsCoveredHeadline_2'], "</br>")); ?>
                                    <?php echo(convertTextList($data['TopicsCovered_2'], "</br>")); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Revision Description</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt; font-weight: bold;">
                                    <?php echo($data['RevisionDesc_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt; font-weight: bold;"><?php echo($data['RevisionDesc_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Revision Date</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt; font-weight: bold;">
                                    <?php echo($data['RevisionDate_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt; font-weight: bold;"><?php echo($data['RevisionDate_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Approval Description</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt; font-weight: bold;">
                                    <?php echo($data['ApprovalDesc_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt; font-weight: bold;"><?php echo($data['ApprovalDesc_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class="input-group" style="border: 1px solid darkgray; width:100%; display: flex;">
                                <div style="width:250px; background-color:#efbd47;">
                                    <span class="input-group-addon" style="color: black; border:0; background-color:#efbd47;">Approval Date</span>
                                </div>
                                <div style="flex: 1; background-color: lightgray; padding: 10px; font-size: 9pt; font-weight: bold;">
                                    <?php echo($data['ApprovalDate_1']); ?>
                                </div>
                                <div style="flex: 1; background-color: white; padding: 10px; font-size: 9pt; font-weight: bold;"><?php echo($data['ApprovalDate_2']); ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                </table>

		</div>


    </div>
</div>


<?php include('footer.php');?>
