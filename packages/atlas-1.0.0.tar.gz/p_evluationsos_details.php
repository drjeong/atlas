<?php
session_start();
header('Content-Type: application/json');

require_once(__DIR__ . '/php_include/dbconnection_class.php');

try {
    $DBCONNECTION = new Dbconnection();

    $so = $_POST['so'] ?? '';
    $program = $_POST['program'] ?? '';
    $academicYear = $_POST['academicYear'] ?? '';

    if (empty($so) || empty($program)) {
        throw new Exception('Missing required parameters');
    }

    $courses = [];
    $totalScore = 0;
    $totalScores = 0;

    // Determine academic year to query
    if ($academicYear === 'Overall') {
        // Get all academic years from session
        if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS']) && is_array($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
            $academicYearIndices = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
        } else {
            $academicYearIndices = [intval($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'])];
        }
        $academicYearsStr = implode(',', array_map('intval', $academicYearIndices));
    } else {
        // Specific year - lookup the year index
        $yearQuery = "SELECT Idx FROM AcademicYears WHERE AcademicYear = ?";
        $yearResult = $DBCONNECTION->prepare_execute_catch_error($yearQuery, [$academicYear]);

        if ($yearResult && $DBCONNECTION->num_rows() > 0) {
            $yearRow = $DBCONNECTION->fetch_assoc();
            $academicYearsStr = intval($yearRow['Idx']);
        } else {
            throw new Exception('Academic year not found: ' . $academicYear);
        }
    }

    // Query using Scoresheet data to match p_evluationsos_ssps.php
    // Group by course to get aggregated scores per course
    $query = "
        SELECT
            `GPIS`.`AcademicYear` AS AcademicYearIdx,
            `AYS`.`AcademicYear` AS AcademicYear,
            `AVCRSES`.`CourseNo`,
            `AVCRSES`.`Crn`,
            `AVCRSES`.`Title` AS CourseName,
            AVG(`SCSHEET`.`LevelOfAttainment`) AS AVG,
            COUNT(`SCSHEET`.`LevelOfAttainment`) AS TOTAL,
            SUM(`SCSHEET`.`LevelOfAttainment`) AS SUM_SCORES
        FROM `StudentOutcomes` AS `STNTOUTCMS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
        LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
        LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
        LEFT JOIN `AcademicYears` AS `AYS` ON (`GPIS`.`AcademicYear` = `AYS`.`Idx`)
        LEFT JOIN `AVCourses` AS `AVCRSES` ON (`ASSMNTMEASURES`.`AvailableCourseIdx` = `AVCRSES`.`Idx`)
        WHERE `GPIS`.`AcademicProgram` = ?
        AND `GPIS`.`AcademicYear` IN ($academicYearsStr)
        AND `STNTOUTCMS`.`SO` = ?
        AND `STNTOUTCMS`.`TobeRemoved` = 0
        AND `SCSHEET`.`LevelOfAttainment` IS NOT NULL
        GROUP BY `GPIS`.`AcademicYear`, `AYS`.`AcademicYear`, `AVCRSES`.`Idx`, `AVCRSES`.`CourseNo`, `AVCRSES`.`Crn`, `AVCRSES`.`Title`
        HAVING COUNT(`SCSHEET`.`LevelOfAttainment`) > 0
        ORDER BY `AYS`.`AcademicYear` DESC, `AVCRSES`.`CourseNo`, `AVCRSES`.`Crn`
    ";

//    error_log("Scoresheet Query: $query");
//    error_log("Parameters: Program=$program, Years=$academicYearsStr, SO=$so");

    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$program, $so]);

    $rowCount = 0;
    if ($result && $DBCONNECTION->num_rows() > 0) {
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $rowCount++;
            $scoreCount = intval($row['TOTAL']);
            $sumScores = floatval($row['SUM_SCORES']);
            $avgScore = floatval($row['AVG']);

            $totalScore += $sumScores;
            $totalScores += $scoreCount;

//            error_log("Course $rowCount: " . ($row['CourseNo'] ?? 'NULL') . " - Scores: $scoreCount, Sum: $sumScores, Avg: $avgScore");

            $courses[] = [
                'courseNo' => $row['CourseNo'] ?? 'N/A',
                'crn' => $row['Crn'] ?? 'N/A',
                'courseName' => $row['CourseName'] ?? 'Unknown Course',
                'academicYear' => $row['AcademicYear'] ?? 'N/A',
                'scores' => $scoreCount,
                'avgScore' => number_format($avgScore, 2),
                'totalScore' => number_format($sumScores, 2)
            ];
        }
//        error_log("Total courses found: $rowCount, Total scores: $totalScores, Total score sum: $totalScore");
    } else {
//        error_log("No courses found!");

        // Debug: Check if there's any data at all for this SO
        $debugQuery = "
            SELECT 
                COUNT(`SCSHEET`.`LevelOfAttainment`) AS score_count,
                AVG(`SCSHEET`.`LevelOfAttainment`) AS avg_score
            FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
            LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
            LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
            WHERE `GPIS`.`AcademicProgram` = ?
            AND `GPIS`.`AcademicYear` IN ($academicYearsStr)
            AND `STNTOUTCMS`.`SO` = ?
            AND `STNTOUTCMS`.`TobeRemoved` = 0
            AND `SCSHEET`.`LevelOfAttainment` IS NOT NULL
        ";

        $debugResult = $DBCONNECTION->prepare_execute_catch_error($debugQuery, [$program, $so]);

        if ($debugResult && $DBCONNECTION->num_rows() > 0) {
            $debugRow = $DBCONNECTION->fetch_assoc();
//            error_log("Debug - Total scores in system: " . $debugRow['score_count'] . ", Avg: " . $debugRow['avg_score']);

            $totalScores = intval($debugRow['score_count']);
            $totalScore = floatval($debugRow['score_count']) * floatval($debugRow['avg_score']);

            // If we have scores but no course info, add a generic entry
            if ($totalScores > 0) {
                $courses[] = [
                    'courseNo' => 'Multiple',
                    'crn' => 'N/A',
                    'courseName' => 'Courses without detailed information',
                    'academicYear' => $academicYear === 'Overall' ? 'Multiple Years' : $academicYear,
                    'scores' => $totalScores,
                    'avgScore' => number_format($debugRow['avg_score'], 2),
                    'totalScore' => number_format($totalScore, 2)
                ];
            }
        }
    }

    echo json_encode([
        'success' => true,
        'courses' => $courses,
        'totalScore' => number_format($totalScore, 2),
        'totalScores' => $totalScores,
        'debug' => [
            'so' => $so,
            'program' => $program,
            'academicYear' => $academicYear,
            'academicYearsStr' => $academicYearsStr,
            'coursesFound' => count($courses),
            'totalScoresCalculated' => $totalScores
        ]
    ]);

} catch (Exception $e) {
    error_log("Error in p_evluationsos_details.php: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());

    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}