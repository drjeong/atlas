<?php
/**
 * Management of Academic Year
 * Description: remove academic year
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 08/09/2026 - Added directory checking and removal
 *
 */

include('checker_systemadmin.php');

$IDX = (isset($_POST['id'])) ? trim($_POST['id']) : '';

if ($IDX == "") {
    echo "0x00000011";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    require_once(__DIR__ . '/../config.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $IDX = filter_var($IDX, FILTER_VALIDATE_INT);
    if ($IDX === false) {
        throw new Exception('Invalid Index format');
    }

    // First, get the academic year info before deleting
    $query = "SELECT AcademicYear FROM AcademicYears WHERE Idx = ?";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$IDX]);

    if (!$result || $result->num_rows == 0) {
        echo "0x00200012";  // Item not exist
        exit;
    }

    $row = $result->fetch_assoc();
    $academicYear = $row['AcademicYear'];

    // Define directories to check and potentially delete
    $directories = [
        __DIRECTORY_ABETASSESSMENTS__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_ABETSYLLABI__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_COURSEBI__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_INSTRUCTIONAL_MATERIALS__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_COURSEASSIGNMENT_SAMPLES__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_ABETASSESSMENTSURVEY__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_COURSEBINDERS__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_COURSEASSESSMENTREPORTS__ . $academicYear . DIRECTORY_SEPARATOR
    ];

    // Check if any directory contains files
    foreach ($directories as $directory) {
        if (is_dir($directory)) {
            if (!isDirectoryEmpty($directory)) {
                echo "0x09000011";  // Cannot delete: directories contain files
                exit;
            }
        }
    }

    // Delete from database first
    $query = "CALL SP_RemoveAcademicYearInfo(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$IDX]);

    // If DB deletion successful, remove directories
    foreach ($directories as $directory) {
        if (is_dir($directory)) {
            if (!rmdir($directory)) {
                error_log("Warning: Failed to remove directory: {$directory}");
                // Continue even if directory removal fails
            }
        }
    }

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x09000010') !== false) {
        echo '0x09000010';  // Cannot delete: the item is already in use.
    } else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500',
            'file' => __FILE__,
            'line' => __LINE__
        ]));
    }

} catch (Exception $e) {
    error_log("General Error: " . $e->getMessage() .
        " in " . __FILE__ .
        " on line " . __LINE__);
    echo "0x00000000";
} finally {
    // Connection cleanup is handled by Dbconnection class destructor
}

/**
 * Check if directory is empty (no files, but may have subdirectories)
 * Recursively checks all subdirectories
 *
 * @param string $dir Directory path to check
 * @return bool True if empty (no files anywhere), false if contains any files
 */
function isDirectoryEmpty($dir) {
    if (!is_readable($dir)) {
        return false;
    }

    $handle = opendir($dir);
    if (!$handle) {
        return false;
    }

    while (false !== ($entry = readdir($handle))) {
        if ($entry != "." && $entry != "..") {
            $path = $dir . DIRECTORY_SEPARATOR . $entry;

            // If it's a file, directory is not empty
            if (is_file($path)) {
                closedir($handle);
                return false;
            }

            // If it's a directory, check it recursively
            if (is_dir($path)) {
                if (!isDirectoryEmpty($path)) {
                    closedir($handle);
                    return false;
                }
            }
        }
    }

    closedir($handle);
    return true;
}