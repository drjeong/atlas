<?php
/**
 * Listing All Courses
 * File: u_allcourses_ssps.php
 * Description: listing all courses depending on the selected program
 *
 * 08/09/2026 Modified to use Semesters table join instead of FUNC_GetYearSem
 */

include_once 'session_handler.php';

$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = 'AbetCourses';
$joinQuery = " FROM `AbetCourses` AS `ABETCRSES` 
    INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`) 
    INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx`= `AVCRSES`.`Idx`) 
    LEFT JOIN `Semesters` AS `SMSTRS` ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
    LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABETCRSES`.`Idx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
    LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` ON (`ABETCRSES_GPIS`.`SOIdx`=`ABETCRSES_SOS`.`SOIdx` AND `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
    LEFT JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`ABETCRSES_SOS`.`SOIdx`=`STNTOUTCMS`.`Idx`)  
    LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ABETCRSES_GPIS`.`GPIIdx`) 
    LEFT JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (`ACDEMICPRMS`.`Idx`=`ABETCRSES`.`AcademicProgram`) 
    LEFT JOIN `ContinuousImprovement` AS `CNTNUSIMPRVMNT` ON (`CNTNUSIMPRVMNT`.`AvailableCourseIdx`=`AVCRSES`.`Idx` AND `CNTNUSIMPRVMNT`.`AbetCourseIdx`=`ABETCRSES`.`Idx`)";

// Table's primary key
$primaryKey = '`ABETCRSES`.`Idx`';

// Array of database columns
$columns = array(
    array('db' => '`ABETCRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_'.$row[0];
    }),
    array( 'db' => '`ABETCRSES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`ABETCRSES`.`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => '`ABETCRSES`.`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram'),
    array( 'db' => '`ACDEMICPRMS`.`Name`', 'dt' => 'AcademicProgramName', 'field' => 'AcademicProgramName', 'as' => 'AcademicProgramName'),
    array( 'db' => '`AYS`.`AcademicYear`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => '`AVCRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`AVCRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`AVCRSES`.`Instructor`', 'dt' => 'Instructor', 'field' => 'Instructor', 'as' => 'Instructor'),
    array( 'db' => '`AVCRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`AVCRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`AVCRSES`.`Idx`', 'dt' => 'AVCourseIdx', 'field' => 'AVCourseIdx', 'as' => 'AVCourseIdx'),
    array( 'db' => '`AVCRSES`.`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => '`AVCRSES`.`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => '`AVCRSES`.`Actual`', 'dt' => 'Enrollment', 'field' => 'Enrollment', 'as' => 'Enrollment'),
    array( 'db' => '`AVCRSES`.`Syllabus`', 'dt' => 'CourseSyllabus', 'field' => 'CourseSyllabus', 'as' => 'CourseSyllabus', 'formatter' => function( $d, $row ) {
        $return_string = $d;
        if ($return_string == null) $return_string = '';
        return $return_string;
    }),
    array( 'db' => '`SMSTRS`.`Explanation`', 'dt' => 'SemesterTxt', 'field' => 'SemesterTxt', 'as' => 'SemesterTxt'),
    array( 'db' => '`ABETCRSES`.`Syllabus`', 'dt' => 'AbetSyllabus', 'field' => 'AbetSyllabus', 'as' => 'AbetSyllabus', 'formatter' => function( $d, $row ) {
        $return_string = $d;
        if ($return_string == null) $return_string = '';
        return $return_string;
    }),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`ABETCRSES_SOS`.`SOIdx`) ORDER BY `STNTOUTCMS`.`SO` SEPARATOR \', \')', 'dt' => 'SOIdxes', 'field' => 'SOIdxes', 'as' => 'SOIdxes'),
    array( 'db' => 'GROUP_CONCAT(DISTINCT(`STNTOUTCMS`.`SO`) ORDER BY `STNTOUTCMS`.`SO` SEPARATOR \', \')', 'dt' => 'StudentOutcomes', 'field' => 'StudentOutcomes', 'as' => 'StudentOutcomes'),
    array( 'db' => 'GROUP_CONCAT(`ABETCRSES_GPIS`.`GPIIdx` ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI` SEPARATOR \', \')', 'dt' => 'GPIIdxes', 'field' => 'GPIIdxes', 'as' => 'GPIIdxes'),
    array( 'db' => 'GROUP_CONCAT(CONCAT_WS(\'-\',`STNTOUTCMS`.`SO`, `GPIS`.`GPI`) ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI` SEPARATOR \', \')', 'dt' => 'GPIs', 'field' => 'GPIs', 'as' => 'GPIs'),
    array( 'db' => '(SELECT GROUP_CONCAT(CONCAT(gpi_idx, \':\', measure_count) ORDER BY gpi_idx SEPARATOR \', \') FROM (SELECT `ABETCRSES_GPIS`.`GPIIdx` as gpi_idx, COUNT(DISTINCT `ASSSMNT`.`Idx`) as measure_count FROM `AbetCourses_GPIs` AS `ABETCRSES_GPIS` LEFT JOIN `AssessmentMeasures` AS `ASSSMNT` ON (`ASSSMNT`.`AbetCourseIdx`=`ABETCRSES`.`Idx` AND `ASSSMNT`.`GPI`=`ABETCRSES_GPIS`.`GPIIdx`) WHERE `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES`.`Idx` GROUP BY `ABETCRSES_GPIS`.`GPIIdx`) as gpi_counts)', 'dt' => 'AssessmentMeasuresCount', 'field' => 'AssessmentMeasuresCount', 'as' => 'AssessmentMeasuresCount'),
    array(
        'db' => '(SELECT COUNT(DISTINCT `SAMPLES`.`Idx`) 
              FROM `AssessmentMeasures` AS `MEASURES` 
              LEFT JOIN `AssessmentMeasureSamples` AS `SAMPLES` 
                ON (`SAMPLES`.`AssessmentMeasureIdx` = `MEASURES`.`Idx`) 
              WHERE `MEASURES`.`AbetCourseIdx` = `ABETCRSES`.`Idx`)',
        'dt' => 'StudentSamplesCount',
        'field' => 'StudentSamplesCount',
        'as' => 'StudentSamplesCount'
    ),
    // Wrap with MAX() to make it an aggregate function
    array( 'db' => 'MAX(SUBSTRING(`CNTNUSIMPRVMNT`.`FacultyReflection`,1, 2))', 'dt' => 'FacultyReflection', 'field' => 'FacultyReflection', 'as' => 'FacultyReflection')
);

require( 'ssp.join.class.php' );
$extraWhere = "";
if ($AcademicYear != "" && $AcademicYear != "all") {
    if ($extraWhere !="") $extraWhere .= " AND ";
    $extraWhere .= "`ABETCRSES`.`AcademicYear`='".$AcademicYear."'";
}
if ($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] != null)
{
    if ($extraWhere !="") $extraWhere .= " AND ";
    $extraWhere .= "`ACDEMICPRMS`.`Idx`='".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";
}

// Include all non-aggregated columns in GROUP BY
$groupBy = "`ABETCRSES`.`Idx`, `ABETCRSES`.`AcademicYear`, `ABETCRSES`.`AcademicProgram`, `ABETCRSES`.`Syllabus`, `ACDEMICPRMS`.`Name`, `AYS`.`AcademicYear`, `AVCRSES`.`Idx`, `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Instructor`, `AVCRSES`.`Title`, `AVCRSES`.`Credits`, `AVCRSES`.`Semester`, `AVCRSES`.`CRN`, `AVCRSES`.`Actual`, `AVCRSES`.`Syllabus`";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
