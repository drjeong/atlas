<?php
/**
 * Assign Requirement information to Abet Courses
 * Description: This is for assigning requirement information to the selected abet courses
 * Author: Dong Hyun Jeong
 *
 * 01/04/2024 - initial version created
 * 12/14/2025 - revise to handle course and year indexes
 *
 *
 */
?>

<?php
include_once 'session_handler.php';

$coursePairs = '';
$Requirement = '';

if (array_key_exists('coursePairs', $_POST) && array_key_exists('req', $_POST))
{
    $coursePairs = trim($_POST['coursePairs']);
    $Requirement = trim($_POST['req']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'])) ? $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] : '';

if ($coursePairs == "" || $AcademicProgramIdx == "" || $Requirement == ""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate Academic Program
    $AcademicProgramIdx = filter_var($AcademicProgramIdx, FILTER_VALIDATE_INT);
    if ($AcademicProgramIdx === false) {
        throw new Exception('Invalid Academic Program format');
    }

    // Split the pipe-separated pairs
    $pairsArray = explode('|', $coursePairs);

    if (empty($pairsArray)) {
        throw new Exception('No course pairs provided');
    }

    $MultiQuery = "";
    foreach ($pairsArray as $pair) {
        // Split each pair by colon
        $parts = explode(':', $pair);

        if (count($parts) !== 2) {
            throw new Exception('Invalid course pair format');
        }

        // Decode and validate Course Idx
        $AbetCourseIdx = urldecode($parts[0]);
        $AbetCourseIdx = filter_var($AbetCourseIdx, FILTER_VALIDATE_INT);
        if ($AbetCourseIdx === false) {
            throw new Exception('Invalid course index');
        }

        // Decode and validate Academic Year
        $AcademicYearIdx = urldecode($parts[1]);
        $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
        if ($AcademicYearIdx === false) {
            throw new Exception('Invalid Academic Year');
        }

        // Escape requirement string to prevent SQL injection
        $EscapedRequirement = $DBCONNECTION->escape_string($Requirement);

        $MultiQuery .= "CALL SP_UpdateCourseMapping_Requirement($AbetCourseIdx, '$EscapedRequirement', $AcademicYearIdx, $AcademicProgramIdx);";
    }

//    error_log($MultiQuery);
    $DBCONNECTION->sendmultiquery($MultiQuery);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage());
    echo "0x00000000";
}
?>
