<?php
/**
 * Management of User Accounts
 * Description: assign position information to the selected user
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 */


include('checker_systemadmin.php');

$_Position = (isset($_POST['_Position'])) ? trim($_POST['_Position']) : '';
$_UList = (isset($_POST['_UList'])) ? trim($_POST['_UList']) : '';

if ($_Position=='' || $_UList==''){
	echo "0x00000011"; 
	exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // convert unwanted escape strings
    $_Position = $DBCONNECTION->real_escape_string($_Position);

    $Query_Condition = '';
    $users_array = explode( '|', $_UList );
    $users_array = array_unique($users_array); // remove duplicates
    foreach ($users_array as $useridx) {
        if ($Query_Condition != '') $Query_Condition .= " OR ";
        $Query_Condition .= "`Idx`=$useridx";
    }

    /////////////////////////////////////////////////////////////////////////////////
	// Update user account
    $Query = "UPDATE `UserAccounts` SET `Position`=$_Position WHERE " . $Query_Condition;
//	echo $Query;

    $DBCONNECTION->sendmultiquery($Query);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

