<?php
/**
 * Duplicate Cross Program Performance Indicators
 * Description: duplicating performance indicators from other degree program
 * Author: Dong Hyun Jeong
 *
 * 09/29/2023 - initial version created
 * 03/02/2021 - GPI saving routine is changed to use a MySQL stored procedure
 *
 */


include_once 'session_handler.php';

$AcademicProgramYearFrom='';
$AcademicYearIdxTo='';

if (array_key_exists('ayf', $_POST) && array_key_exists('ayt', $_POST) )
{
    $AcademicProgramYearFrom = trim($_POST['ayf']);
    $AcademicYearIdxTo = trim($_POST['ayt']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicProgramYearFrom=="" || $AcademicYearIdxTo==""|| $AcademicProgram==""){
    // no required information
    echo "0x00000101";
    exit;
}

// parse academic year & program
$Tmp = explode("_", $AcademicProgramYearFrom);
$AcademicYearIdxFrom=$Tmp[0];
$AcademicProgramFrom=$Tmp[1];


//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    /////////////////////////////////////////////////////////////////////////////////
    $query = "CALL SP_DuplicateCrossPrmsPIs(?, ?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$AcademicYearIdxFrom, $AcademicYearIdxTo, $AcademicProgramFrom, $AcademicProgram]);

    
    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x09500011') !== false) {
        echo '0x09500011';  // The selected year does not have PIs.
    }
    else if (strpos($errorMessage, '0x09500012') !== false) {
        echo '0x09500012';  // The selected year has PIs already.
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
