<?php
/**
 * Assign SOs to Abet Courses
 * Description: Assigning SOs to the selected abet courses
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 * 04/12/2021 - Change the title "GPI" to "PI"
 *
 */

include_once 'session_handler.php';

$AbetCourseIdxes='';
$AcademicYear='';
$StudentOutcomes='';

if (array_key_exists('ay', $_POST) && array_key_exists('sos', $_POST) && array_key_exists('abetcrs', $_POST))
{
    $AcademicYear = trim($_POST['ay']);
    $StudentOutcomes = trim($_POST['sos']);
    $AbetCourseIdxes = trim($_POST['abetcrs']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYear=="" || $AcademicProgram=="" || $StudentOutcomes=="" || $AbetCourseIdxes==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYear = filter_var($AcademicYear, FILTER_VALIDATE_INT);
    if ($AcademicYear === false) {
        throw new Exception('Invalid Academic Year format');
    }

    $AbetCourseIdxes_Array = explode('|', $AbetCourseIdxes);
    $SOs_Array = explode('|', $StudentOutcomes);

    // Single query with parameters
    $query = "CALL SP_AddAbetCourseSO(?, ?, ?, ?, ?);";

    // Execute each combination separately
    foreach ($AbetCourseIdxes_Array as $AbetCourseIdx) {
        foreach ($SOs_Array as $StudentOutcome) {
            $SO = explode('_', $StudentOutcome); // $SO[0] - SO index, $SO[1] - true/false indicator

            $params = [
                $AbetCourseIdx,
                $SO[0],
                $AcademicYear,
                $AcademicProgram,
                $SO[1]
            ];

            $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);
            if ($result === null) {
                throw new Exception('Query execution failed');
            }
        }
    }
    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500'
    ]));

} catch (Exception $e) {
    error_log($e->getMessage());
    echo "0x00000000";
}

//try {
//    require_once(__DIR__ . '/php_include/dbconnection_class.php');
//    $DBCONNECTION = new Dbconnection();
//
//    // Validate inputs
//    $AcademicYear = filter_var($AcademicYear, FILTER_VALIDATE_INT);
//    if ($AcademicYear === false) {
//        throw new Exception('Invalid Academic Year format');
//    }
//
//    $AbetCourseIdxes_Array = explode( '|', $AbetCourseIdxes );
//    $SOs_Array = explode( '|', $StudentOutcomes );
//
//    $MultiQuery = "";
//    foreach ($AbetCourseIdxes_Array AS $AbetCourseIdx) {
//        foreach ($SOs_Array AS $StudentOutcome) {
//            $SO = explode( '_', $StudentOutcome ); // $SO[0] -  SO index, $SO[1] - true / false indicator
//            $MultiQuery .= "CALL SP_AddAbetCourseSO('$AbetCourseIdx', '$SO[0]', '$AcademicYear', '$AcademicProgram', '$SO[1]');";
//        }
//    }
//
//    $DBCONNECTION->sendmultiquery($MultiQuery);
//
//
//
//    echo "0x11111111";
//} catch (Exception $e) {
//    error_log($e->getMessage()); //Boring error messages from anything else!
//    echo "0x00000000";
//}
