<?php
/**
 * Listing abet courses
 * Description: listing SO/PI differences across programs
 *
 * 02/07/2025 - initial version created
 * 08/09/2026 - Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */
include_once 'session_handler.php';

$AcademicYear = '';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}
// Get the filter parameter
$showOnlyUnmatched = isset($_GET['showOnlyUnmatched']) && $_GET['showOnlyUnmatched'] === 'true';

// DB table to use
$table = '';
$joinQuery = " FROM (
    SELECT 
        A.`Idx`, A.`AVCIdx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Requirement`, A.`Semester`, A.`CRN`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`Syllabus`, A.`AcademicProgramName`, 
        A.`Degree`, A.`Survey`, A.`Enrollment`, A.`Reference`,        
        GROUP_CONCAT(DISTINCT A.`Instructor` ORDER BY A.`Instructor` SEPARATOR ', ') as `Instructor`,
        GROUP_CONCAT(DISTINCT A.`Email` ORDER BY A.`Email` SEPARATOR ', ') as `Email`,
        GROUP_CONCAT(DISTINCT B.`SO` ORDER BY B.`SO` SEPARATOR ', ') as `StudentOutcomes`,
        GROUP_CONCAT(DISTINCT B.`SOIdx` ORDER BY B.`SO` SEPARATOR ', ') as `SOIdxes`,
        GROUP_CONCAT(DISTINCT B.`PIIdx` ORDER BY B.`SO`, B.`PI` SEPARATOR ', ') as `PIIdxes`,
        GROUP_CONCAT(DISTINCT CONCAT_WS('-', B.`SO`, B.`PI`) ORDER BY B.`SO`, B.`PI` SEPARATOR ', ') as `PIs`,
        MAX(IFNULL(C.`HasClassRoster`, 0)) as `HasClassRoster`,
        MAX(IFNULL(E.`HasAssessment`, 0)) as `ExistCrsAssessment`,
        -- Add discrepancy detection columns from pre-computed data
        MAX(COALESCE(DISC.`HasDiscrepancy`, 0)) AS `HasDiscrepancy`,
        MAX(DISC.`OtherPrograms`) AS `OtherPrograms`,
        MAX(DISC.`OtherSOs`) AS `OtherSOs`,
        MAX(DISC.`OtherPIs`) AS `OtherPIs`
    FROM (
        SELECT 
            `ABETCRSES`.`Idx`, 
            `ABETCRSES`.`AcademicYear`, 
            `ABETCRSES`.`Level`, 
            `ABETCRSES`.`AcademicProgram`, 
            `ABETCRSES`.`Requirement`, 
            `ABETCRSES`.`Syllabus`,
            `ABETCRSES`.`Reference`,
            `AYS`.`AcademicYear` AS `AcademicYearInfo`, 
            `SMSTRS`.`Explanation` AS `Semester`,
            `AVCRSES`.`Idx` AS `AVCIdx`,
            `AVCRSES`.`CRN`, 
            `AVCRSES`.`Subject`, 
            `AVCRSES`.`Num`, 
            `AVCRSES`.`Title`, 
            `AVCRSES`.`Survey`, 
            `AVCRSES`.`Credits`, 
            `AVCRSES`.`Actual` AS `Enrollment`,
            `ACDEMICPRMS`.`Name` AS `AcademicProgramName`,
            `ACDEMICPRMS`.`Degree`,
            `UA`.`Name` AS `Instructor`, 
            `UA`.`Email`
        FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AVCourses` AS `AVCRSES` 
            ON `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`
        LEFT JOIN `Semesters` AS `SMSTRS`
            ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` 
            ON `AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`
        LEFT JOIN `UserAccounts` AS `UA` 
            ON `AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`
        INNER JOIN `AcademicYears` AS `AYS` 
            ON `ABETCRSES`.`AcademicYear` = `AYS`.`Idx`
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` 
            ON `ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`
    ) AS A
    INNER JOIN (
        SELECT `AVCourseIdx`
        FROM `AbetCourses`
        GROUP BY `AVCourseIdx`
        HAVING COUNT(DISTINCT `AcademicProgram`) >= 2
    ) AS D ON A.`AVCIdx` = D.`AVCourseIdx`
    LEFT JOIN (
        SELECT 
            `ABETCRSES`.`Idx` AS `AbetCourseIdx`, 
            `ABETCRSES`.`AcademicYear`, 
            `ABETCRSES`.`AcademicProgram`, 
            `STNTOUTCMS`.`Idx` AS `SOIdx`, 
            `STNTOUTCMS`.`SO`, 
            `GPIS`.`Idx` AS `PIIdx`, 
            `GPIS`.`GPI` AS `PI`
        FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` 
            ON `ABETCRSES`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx`
        LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` 
            ON `ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx` 
            AND `ABETCRSES_GPIS`.`AbetCourseIdx` = `ABETCRSES_SOS`.`AbetCourseIdx`
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` 
            ON `ABETCRSES_SOS`.`SOIdx` = `STNTOUTCMS`.`Idx`
        LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON `GPIS`.`Idx` = `ABETCRSES_GPIS`.`GPIIdx`
    ) AS B ON A.`Idx` = B.`AbetCourseIdx` 
        AND A.`AcademicYear` = B.`AcademicYear` 
        AND A.`AcademicProgram` = B.`AcademicProgram`
    LEFT JOIN (
        SELECT 
            `AvailableCourseIdx`, 
            IF(COUNT(*) > 0, 1, 0) AS `HasClassRoster`
        FROM `ClassRoster`
        GROUP BY `AvailableCourseIdx`
    ) AS C ON A.`AVCIdx` = C.`AvailableCourseIdx`
    LEFT JOIN (
        SELECT 
            `AvailableCourseIdx`,
            `AbetCourseIdx`,
            IF(COUNT(*) > 0, 1, 0) AS `HasAssessment`
        FROM `AssessmentMeasures`
        GROUP BY `AvailableCourseIdx`, `AbetCourseIdx`
    ) AS E ON A.`AVCIdx` = E.`AvailableCourseIdx` 
        AND A.`Idx` = E.`AbetCourseIdx`
    -- Optimized discrepancy detection using pre-aggregated data
    LEFT JOIN (
        SELECT 
            AC1.`Idx` AS `AbetCourseIdx`,
            -- Check if discrepancies exist by comparing unique SO/PI combinations
            CASE 
                WHEN COUNT(DISTINCT SO_AGG.`SOString`) > 1 
                  OR COUNT(DISTINCT PI_AGG.`PIString`) > 1 
                THEN 1 
                ELSE 0 
            END AS `HasDiscrepancy`,
            -- Get other programs (excluding current)
            GROUP_CONCAT(
                DISTINCT CASE 
                    WHEN AC2.`Idx` != AC1.`Idx` 
                    THEN CONCAT(AP2.`Name`, ' (', AP2.`Degree`, ')') 
                END 
                ORDER BY AP2.`Name` 
                SEPARATOR '; '
            ) AS `OtherPrograms`,
            -- Get SOs from other programs (only if different)
            GROUP_CONCAT(
                DISTINCT CASE 
                    WHEN AC2.`Idx` != AC1.`Idx` 
                      AND SO_AGG2.`SOString` != SO_AGG1.`SOString`
                    THEN CONCAT(AP2.`Name`, ': [', IFNULL(SO_AGG2.`SOString`, 'None'), ']')
                END
                ORDER BY AP2.`Name`
                SEPARATOR '; '
            ) AS `OtherSOs`,
            -- Get PIs from other programs (only if different)
            GROUP_CONCAT(
                DISTINCT CASE 
                    WHEN AC2.`Idx` != AC1.`Idx` 
                      AND PI_AGG2.`PIString` != PI_AGG1.`PIString`
                    THEN CONCAT(AP2.`Name`, ': [', IFNULL(PI_AGG2.`PIString`, 'None'), ']')
                END
                ORDER BY AP2.`Name`
                SEPARATOR '; '
            ) AS `OtherPIs`
        FROM `AbetCourses` AC1
        INNER JOIN `AVCourses` AVC1 ON AC1.`AVCourseIdx` = AVC1.`Idx`
        -- Join with other programs offering same course
        INNER JOIN `AVCourses` AVC2 
            ON AVC2.`Subject` = AVC1.`Subject`
            AND AVC2.`Num` = AVC1.`Num`
        INNER JOIN `AbetCourses` AC2 
            ON AC2.`AVCourseIdx` = AVC2.`Idx`
            AND AC2.`AcademicYear` = AC1.`AcademicYear`
        INNER JOIN `AcademicPrograms` AP2 
            ON AC2.`AcademicProgram` = AP2.`Idx`
        -- Pre-aggregate SOs for current course (AC1)
        LEFT JOIN (
            SELECT 
                ACS.`AbetCourseIdx`,
                GROUP_CONCAT(DISTINCT SO.`SO` ORDER BY SO.`SO` SEPARATOR ', ') AS `SOString`
            FROM `AbetCourses_SOs` ACS
            INNER JOIN `StudentOutcomes` SO ON ACS.`SOIdx` = SO.`Idx`
            GROUP BY ACS.`AbetCourseIdx`
        ) SO_AGG1 ON SO_AGG1.`AbetCourseIdx` = AC1.`Idx`
        -- Pre-aggregate PIs for current course (AC1)
        LEFT JOIN (
            SELECT 
                ACS.`AbetCourseIdx`,
                GROUP_CONCAT(
                    DISTINCT CONCAT(SO.`SO`, '-', GPI.`GPI`) 
                    ORDER BY SO.`SO`, GPI.`GPI` 
                    SEPARATOR ', '
                ) AS `PIString`
            FROM `AbetCourses_SOs` ACS
            INNER JOIN `StudentOutcomes` SO ON ACS.`SOIdx` = SO.`Idx`
            LEFT JOIN `AbetCourses_GPIs` ACG 
                ON ACG.`AbetCourseIdx` = ACS.`AbetCourseIdx` 
                AND ACG.`SOIdx` = ACS.`SOIdx`
            LEFT JOIN `GeneralPerformanceIndicators` GPI ON ACG.`GPIIdx` = GPI.`Idx`
            GROUP BY ACS.`AbetCourseIdx`
        ) PI_AGG1 ON PI_AGG1.`AbetCourseIdx` = AC1.`Idx`
        -- Pre-aggregate SOs for comparison course (AC2)
        LEFT JOIN (
            SELECT 
                ACS.`AbetCourseIdx`,
                GROUP_CONCAT(DISTINCT SO.`SO` ORDER BY SO.`SO` SEPARATOR ', ') AS `SOString`
            FROM `AbetCourses_SOs` ACS
            INNER JOIN `StudentOutcomes` SO ON ACS.`SOIdx` = SO.`Idx`
            GROUP BY ACS.`AbetCourseIdx`
        ) SO_AGG2 ON SO_AGG2.`AbetCourseIdx` = AC2.`Idx`
        -- Pre-aggregate PIs for comparison course (AC2)
        LEFT JOIN (
            SELECT 
                ACS.`AbetCourseIdx`,
                GROUP_CONCAT(
                    DISTINCT CONCAT(SO.`SO`, '-', GPI.`GPI`) 
                    ORDER BY SO.`SO`, GPI.`GPI` 
                    SEPARATOR ', '
                ) AS `PIString`
            FROM `AbetCourses_SOs` ACS
            INNER JOIN `StudentOutcomes` SO ON ACS.`SOIdx` = SO.`Idx`
            LEFT JOIN `AbetCourses_GPIs` ACG 
                ON ACG.`AbetCourseIdx` = ACS.`AbetCourseIdx` 
                AND ACG.`SOIdx` = ACS.`SOIdx`
            LEFT JOIN `GeneralPerformanceIndicators` GPI ON ACG.`GPIIdx` = GPI.`Idx`
            GROUP BY ACS.`AbetCourseIdx`
        ) PI_AGG2 ON PI_AGG2.`AbetCourseIdx` = AC2.`Idx`
        -- Also need this for the main GROUP BY logic
        LEFT JOIN (
            SELECT 
                ACS.`AbetCourseIdx`,
                GROUP_CONCAT(DISTINCT SO.`SO` ORDER BY SO.`SO` SEPARATOR ', ') AS `SOString`
            FROM `AbetCourses_SOs` ACS
            INNER JOIN `StudentOutcomes` SO ON ACS.`SOIdx` = SO.`Idx`
            GROUP BY ACS.`AbetCourseIdx`
        ) SO_AGG ON SO_AGG.`AbetCourseIdx` = AC2.`Idx`
        LEFT JOIN (
            SELECT 
                ACS.`AbetCourseIdx`,
                GROUP_CONCAT(
                    DISTINCT CONCAT(SO.`SO`, '-', GPI.`GPI`) 
                    ORDER BY SO.`SO`, GPI.`GPI` 
                    SEPARATOR ', '
                ) AS `PIString`
            FROM `AbetCourses_SOs` ACS
            INNER JOIN `StudentOutcomes` SO ON ACS.`SOIdx` = SO.`Idx`
            LEFT JOIN `AbetCourses_GPIs` ACG 
                ON ACG.`AbetCourseIdx` = ACS.`AbetCourseIdx` 
                AND ACG.`SOIdx` = ACS.`SOIdx`
            LEFT JOIN `GeneralPerformanceIndicators` GPI ON ACG.`GPIIdx` = GPI.`Idx`
            GROUP BY ACS.`AbetCourseIdx`
        ) PI_AGG ON PI_AGG.`AbetCourseIdx` = AC2.`Idx`
        GROUP BY AC1.`Idx`, SO_AGG1.`SOString`, PI_AGG1.`PIString`
    ) AS DISC ON A.`Idx` = DISC.`AbetCourseIdx`
    GROUP BY 
        A.`Idx`, A.`AVCIdx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Requirement`, A.`Semester`, A.`CRN`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`Syllabus`, A.`AcademicProgramName`, 
        A.`Degree`, A.`Survey`, A.`Enrollment`, A.`Reference`
    ORDER BY A.`Semester` ASC, A.`CRN` ASC, A.`Subject` ASC, A.`Num` ASC, A.`AcademicProgramName` ASC
) AS combined";

// Table's primary key
$primaryKey = '`Idx`';

// Array of database columns which should be read and sent back to DataTables.
$columns = array(
    array(
        'db' => '`Idx`',
        'dt' => 'DT_RowId',
        'field' => 'DT_RowId',
        'as' => 'DT_RowId',
        'formatter' => function($d, $row) {
            return 'row_' . $d;
        }
    ),
    array('db' => '`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array('db' => '`AVCIdx`', 'dt' => 'AVCIdx', 'field' => 'AVCIdx', 'as' => 'AVCIdx'),
    array('db' => '`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array('db' => '`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array('db' => '`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array('db' => '`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array('db' => '`AcademicProgramName`', 'dt' => 'AcademicProgramName', 'field' => 'AcademicProgramName', 'as' => 'AcademicProgramName'),
    array('db' => '`Degree`', 'dt' => 'Degree', 'field' => 'Degree', 'as' => 'Degree'),
    array('db' => '`StudentOutcomes`', 'dt' => 'StudentOutcomes', 'field' => 'StudentOutcomes', 'as' => 'StudentOutcomes'),
    array('db' => '`PIs`', 'dt' => 'PIs', 'field' => 'PIs', 'as' => 'PIs'),
    // New discrepancy columns
    array(
        'db' => '`HasDiscrepancy`',
        'dt' => 'HasDiscrepancy',
        'field' => 'HasDiscrepancy',
        'as' => 'HasDiscrepancy',
        'formatter' => function($d) {
            return (int)$d;
        }
    ),
    array('db' => '`OtherPrograms`', 'dt' => 'OtherPrograms', 'field' => 'OtherPrograms', 'as' => 'OtherPrograms'),
    array('db' => '`OtherSOs`', 'dt' => 'OtherSOs', 'field' => 'OtherSOs', 'as' => 'OtherSOs'),
    array('db' => '`OtherPIs`', 'dt' => 'OtherPIs', 'field' => 'OtherPIs', 'as' => 'OtherPIs')
);

require('ssp.join.class.php');

$extraWhere = "1=1";

if (!empty($AcademicYear) && $AcademicYear !== "all") {
    // Since $AcademicYear comes from session/GET, validate it's numeric if it should be
    $AcademicYear = filter_var($AcademicYear, FILTER_VALIDATE_INT);
    if ($AcademicYear !== false) {
        $extraWhere .= " AND combined.`AcademicYear` = $AcademicYear";
    }
}

// In your SQL query, add the WHERE condition
if ($showOnlyUnmatched) {
    // Only show rows where HasDiscrepancy = 1
    $extraWhere .= " AND HasDiscrepancy = 1";
}

$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery($_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

