<?php
/**
 * Listing faculty work loads by Department
 * Description: showing faculty workloads
 * Author: Dong Hyun Jeong
 *
 * 01/25/2026 - initial version created
 *
 */


include('checker_programdirector.php');
include('header.php');


if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// Generate the semester range selector
require_once('inc_academicsemester_selection.php'); // Make sure this file contains the new function
$AcademicSemesterRangeSelection = AcademicSemesterSelectionFrom2To();

?>

    <script src="js/datatable-utils-search.min.js"></script>

    <script class="init">
        const szURL = 'ssps/m_fworkloads_bydepts_ssps.php?_SMF=';

        $(document).ready(function() {
            DataTable_Courses = $("#courseinfo").DataTable({
                dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
                processing: true,
                serverSide: false,
                lengthMenu: [ 50, 100, 150, 300, 500 ],
                search: {
                    regex: true
                },
                fnInitComplete: function(oSettings, json) {
                    let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                    btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                    $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                        $('#' + oSettings.sTableId).dataTable().fnFilter('');
                    });
                },
                ajax: {
                    url: szURL,
                    dataSrc: function (json) {
                        // Check if data exists
                        if (!json.data || json.data.length === 0) {
                            return [];
                        }

                        // Group courses by instructor
                        let instructorMap = {};

                        json.data.forEach(function(row) {
                            let instructor = row.Instructor || 'TBA';

                            if (!instructorMap[instructor]) {
                                instructorMap[instructor] = {
                                    instructor: instructor,
                                    courses: []
                                };
                            }

                            // Ensure semesterCode has a value
                            var semesterCode = row.Semester || row.DT_RowId || '';

                            instructorMap[instructor].courses.push({
                                subject: row.Subject || '',
                                num: row.Num || '',
                                credits: row.Credits || '',
                                semester: row.SemesterTxt || '',
                                semesterCode: semesterCode
                            });
                        });

                        // Convert to array and build course strings
                        var result = [];
                        for (var instructor in instructorMap) {
                            var data = instructorMap[instructor];

                            // Group courses by subject+num+credits
                            var courseMap = {};
                            data.courses.forEach(function(course) {
                                var courseKey = course.subject + ' ' + course.num + '/' + course.credits;

                                if (!courseMap[courseKey]) {
                                    courseMap[courseKey] = {
                                        key: courseKey,
                                        semesters: [],
                                        firstSemesterCode: course.semesterCode || '0'
                                    };
                                }

                                courseMap[courseKey].semesters.push({
                                    text: course.semester,
                                    code: course.semesterCode || '0'
                                });
                            });

                            // Convert to array and sort
                            var courseArray = [];
                            for (var key in courseMap) {
                                courseArray.push(courseMap[key]);
                            }

                            // Sort courses by first occurrence (most recent first)
                            courseArray.sort(function(a, b) {
                                var codeA = a.firstSemesterCode || '0';
                                var codeB = b.firstSemesterCode || '0';
                                return codeB.toString().localeCompare(codeA.toString());
                            });

                            // Build course list string
                            var courseList = '';
                            courseArray.forEach(function(course, index) {
                                if (index > 0) {
                                    courseList += ', ';
                                }

                                // Sort semesters in reverse chronological order
                                course.semesters.sort(function(a, b) {
                                    var codeA = a.code || '0';
                                    var codeB = b.code || '0';
                                    return codeB.toString().localeCompare(codeA.toString());
                                });

                                // Build semester string with & separator
                                var semesterStr = course.semesters.map(function(s) {
                                    return s.text;
                                }).join(' & ');

                                courseList += course.key + ' ' + semesterStr;
                            });

                            result.push({
                                instructor: instructor,
                                courseList: courseList,
                                courseCount: data.courses.length
                            });
                        }

                        // Sort by instructor name
                        result.sort(function(a, b) {
                            return a.instructor.localeCompare(b.instructor);
                        });

                        return result;
                    }
                },
                oLanguage: {"sInfoFiltered": ""},
                columns: [
                    {
                        data: 'instructor',
                        title: "Instructor Name"
                    },
                    {
                        data: 'courseList',
                        title: "Classes Taught (Course No./Credit Hrs.) Term and Year"
                    },
                    {
                        data: 'courseCount',
                        title: "Total Courses",
                        className: 'text-center'
                    }
                ],
                order: [[ 0, 'asc' ]],
                fnDrawCallback: function() {
                    $('#courseinfo tr td:nth-child(1)').css('text-align', 'left');
                    $('#courseinfo tr td:nth-child(2)').css('text-align', 'left');
                    $('#courseinfo tr td:nth-child(3)').css('text-align', 'center');
                },
                buttons: [ {
                    extend: 'excelHtml5',
                    title: 'Faculty Workloads',
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                    },
                }]
            });

            new DataTableSearch('#courseinfo', DataTable_Courses);
        });
    </script>

    <div class="pagebacklayout">
        <div style="width:100%; margin-bottom:1.5em;">
            <p style="margin-top:0.2in;text-align:center;">
                <span class="largeheadline">FACULTY WORKLOADS BY DEPARTMENT</span>
            </p>
            <div style="background-color:#f8f9fa; border-left:4px solid #17a2b8; padding:0.75em 1em; margin:1em 0;">
                <p style="margin:0;">
                    <strong>Note:</strong> This report displays faculty workloads organized by department based on course subject assignments.
                    Courses whose subjects are not associated with a department will be excluded from this view.
                    Please verify that all course subjects are properly configured with department associations in the Subjects management page.
                </p>
            </div>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:100%">
                        <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                            <?php include('control_granted_alldepartments.php'); ?>
                            <?php echo($AcademicSemesterRangeSelection);?>
                        </div>
                    </td>
                </tr>
            </table>

            <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
                <table id="courseinfo" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th>Instructor Name</th>
                        <th>Classes Taught (Course No./Credit Hrs.) Term and Year</th>
                        <th>Total Courses</th>
                    </tr>
                    </thead>
                    <thead id="serachbox" class="filters">
                    <tr>
                        <th>Instructor Name</th>
                        <th>Classes Taught</th>
                        <th>Total Courses</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>Instructor Name</th>
                        <th>Classes Taught</th>
                        <th>Total Courses</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

<?php include('footer.php'); ?>