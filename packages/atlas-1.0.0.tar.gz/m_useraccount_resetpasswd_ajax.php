<?php
/**
 * Management of User Accounts
 * Description: removing the selected user
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 */

include('checker_systemadmin.php');


$advisorid=$_GET['id'];
if ($advisorid==''){
    echo "0x00000011";
    exit;
}

$PWD=crypt(gettimeofday(true).$_SESSION['ATLAS_LOGIN_USERIDX'].$_SESSION['ATLAS_LOGIN_USERNAME'],'st'); // randomly generate temporary passowrd
$PWD_Encrypted = hash('sha256', $PWD);

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

	$Query = "UPDATE `UserAccounts` SET `PWD`='$PWD_Encrypted', `ResetPWD` = 1, `LoginFails` = 0 WHERE `Idx`='$advisorid';";
	//echo $Query;

	$result = $DBCONNECTION->sendquery($Query);

    echo "0x11111111";
    echo "]]".$PWD;
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
