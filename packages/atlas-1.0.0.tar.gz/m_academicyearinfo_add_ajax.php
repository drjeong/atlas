<?php
/**
 * Management of Academic Year
 * Description: add academic year
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 08/07/2026 - Modified to use semester indices
 *
 */

include('checker_systemadmin.php');

$academicYear = (isset($_POST['academicYear'])) ? trim($_POST['academicYear']) : '';
$fromSemesterIdx = (isset($_POST['fromSemesterIdx'])) ? intval(trim($_POST['fromSemesterIdx'])) : 0;
$toSemesterIdx = (isset($_POST['toSemesterIdx'])) ? intval(trim($_POST['toSemesterIdx'])) : 0;

// Validate academic year format
if (empty($academicYear)) {
    echo "0x00000011";
    exit;
}

if (!preg_match('/^\d{4}-\d{4}$/', $academicYear)) {
    echo "0x00000011";  // Invalid format
    exit;
}

if ($fromSemesterIdx == 0 || $toSemesterIdx == 0) {
    echo "0x00000011";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    require_once(__DIR__ . '/../config.php');
    $DBCONNECTION = new Dbconnection();

    // Get semester information
    $query = "SELECT SemesterCode, Explanation FROM Semesters WHERE Idx = ?";
    $fromSemester = $DBCONNECTION->prepare_execute_catch_error($query, [$fromSemesterIdx]);

    if (!$fromSemester || $fromSemester->num_rows == 0) {
        echo "0x00200012";  // Item not exist
        exit;
    }
    $fromData = $fromSemester->fetch_assoc();
    $fromCode = $fromData['SemesterCode'];

    $query = "SELECT SemesterCode, Explanation FROM Semesters WHERE Idx = ?";
    $toSemester = $DBCONNECTION->prepare_execute_catch_error($query, [$toSemesterIdx]);

    if (!$toSemester || $toSemester->num_rows == 0) {
        echo "0x00200012";  // Item not exist
        exit;
    }
    $toData = $toSemester->fetch_assoc();
    $toCode = $toData['SemesterCode'];

    // Validate inputs
    $fromCodeInt = filter_var($fromCode, FILTER_VALIDATE_INT);
    $toCodeInt = filter_var($toCode, FILTER_VALIDATE_INT);

    if ($fromCodeInt === false || $toCodeInt === false) {
        throw new Exception('Invalid code format');
    }

    // Validate that to semester is after from semester
    if ($toCodeInt <= $fromCodeInt) {
        echo "0x00000011";  // Invalid semester range
        exit;
    }

    /////////////////////////////////////////////////////////////////////////////////
    // Insert item using stored procedure
    $query = "CALL SP_AddAcademicYear(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query,
        [$academicYear, $fromCodeInt, $toCodeInt]);

    // Define directories to create
    $directories = [
        __DIRECTORY_ABETASSESSMENTS__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_ABETSYLLABI__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_COURSEBI__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_INSTRUCTIONAL_MATERIALS__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_COURSEASSIGNMENT_SAMPLES__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_ABETASSESSMENTSURVEY__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_COURSEBINDERS__ . $academicYear . DIRECTORY_SEPARATOR,
        __DIRECTORY_COURSEASSESSMENTREPORTS__ . $academicYear . DIRECTORY_SEPARATOR
    ];

    // Create directories
    $mode = 0755;  // Owner: rwx, Group: rx, Others: rx
    foreach ($directories as $directory) {
        if (!is_dir($directory) && !mkdir($directory, $mode, true)) {
            throw new Exception("Failed to create directory: {$directory}");
        }
    }

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    $errorMessage = $e->getMessage();

    if (strpos($errorMessage, '0x00200011') !== false) {
        echo '0x00200011';  // Duplicate entry
    } elseif (strpos($errorMessage, '0x00200012') !== false) {
        echo '0x00200012';  // Item not exist
    } else {
        echo "0x00000500";  // General DB error
        error_log(json_encode([
            'success' => false,
            'error' => $errorMessage,
            'errorCode' => '0x00000500',
            'file' => __FILE__,
            'line' => __LINE__
        ]));
    }
} catch (Exception $e) {
    error_log("General Error: " . $e->getMessage() .
        " in " . __FILE__ .
        " on line " . __LINE__);
    echo "0x00000000";
} finally {
    // Connection cleanup is handled by Dbconnection class destructor
}