<?php
/**
 * Management of User Accounts
 * Description: revising the selected user's information
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 */

include('checker_systemadmin.php');

$IDX = (isset($_POST['id'])) ? trim($_POST['id']) : '';
$_Name = (isset($_POST['name'])) ? trim($_POST['name']) : '';
$_Email = (isset($_POST['email'])) ? trim($_POST['email']) : '';
$_Position = (isset($_POST['pos'])) ? trim($_POST['pos']) : '';
$_Affiliation = (isset($_POST['aff'])) ? trim($_POST['aff']) : '';
$_AccessControl = (isset($_POST['acc'])) ? trim($_POST['acc']) : '';

if ($IDX=="" || $_Name=='' || $_Email=='' || $_Position=='' || $_Affiliation==''){
	echo "0x00000011";
	exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $IDX = filter_var($IDX, FILTER_VALIDATE_INT);
    if ($IDX === false) {
        throw new Exception('Invalid Index format');
    }
    $_Position = filter_var($_Position, FILTER_VALIDATE_INT);
    if ($_Position === false) {
        throw new Exception('Invalid Index format');
    }
    $_Affiliation = filter_var($_Affiliation, FILTER_VALIDATE_INT);
    if ($_Affiliation === false) {
        throw new Exception('Invalid Index format');
    }

    // convert unwanted escape strings
    $_Name = $DBCONNECTION->real_escape_string($_Name);
    $_Email = $DBCONNECTION->real_escape_string($_Email);

    /////////////////////////////////////////////////////////////////////////////////
    // insert PI
    $query = "CALL SP_UpdateUserAccount(?, ?, ?, ?, ?, ?);";
//    error_log("$query $IDX, $_Email, $_Name, $_Position, $_Affiliation, $_AccessControl");
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$IDX, $_Email, $_Name, $_Position, $_Affiliation, $_AccessControl]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00200012') !== false) {
        echo '0x00200012';  // item not found
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
