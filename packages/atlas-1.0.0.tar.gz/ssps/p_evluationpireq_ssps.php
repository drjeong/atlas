<?php
/**
 * Evaluation of Performance Indicators by Requirement
 *
 * 12/14/2025 - initial version created
 *
 */
include_once 'session_handler.php';
?>

<?php
require_once ('../php_include/dbconnection_class.php');

// Get parameters from session
$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// Handle academic years - convert from array to string if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
    if (is_array($academicYears)) {
        $IN_AcademicYears = implode(',', $academicYears);
    } else {
        $IN_AcademicYears = $academicYears;
    }
} else {
    $IN_AcademicYears = $IN_AcademicYear;
}

if (empty($IN_AcademicYears)) {
    $IN_AcademicYears = $IN_AcademicYear;
}

// Get requirement filter from GET parameter (optional)
$requirementFilter = isset($_GET['requirement']) ? $_GET['requirement'] : 'All';

// Initialize database connection
$DBCONNECTION = new Dbconnection();
$Data = array();

// Initialize variables
$studentOutcomes = array();
$courses = array();
$requirements = array();

// Query to get all Student Outcomes and their GPIs for the program
$soQuery = "
    SELECT DISTINCT
        STNTOUTCMS.SO,
        STNTOUTCMS.Description AS SODescription,
        GPIS.Idx AS GPIIdx,
        GPIS.GPI AS GPICode
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    ORDER BY STNTOUTCMS.SO, GPIS.GPI
";

$soResults = $DBCONNECTION->sendquery($soQuery);

if ($soResults) {
    while ($row = $soResults->fetch_assoc()) {
        $soKey = $row['SO'];
        if (!isset($studentOutcomes[$soKey])) {
            $studentOutcomes[$soKey] = array(
                'description' => $row['SODescription'],
                'gpis' => array()
            );
        }
        $studentOutcomes[$soKey]['gpis'][] = array(
            'gpiIdx' => $row['GPIIdx'],
            'code' => $row['GPICode']
        );
    }
}

// Query to get distinct requirements first
$requirementQuery = "
    SELECT DISTINCT ABETCRSES.Requirement
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    LEFT JOIN AssessmentMeasures AS ASSMNTMEASURES ON (ASSMNTMEASURES.GPI = GPIS.Idx)
    LEFT JOIN Scoresheet AS SCSHEET ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
    LEFT JOIN AbetCourses AS ABETCRSES ON (SCSHEET.AbetCourseIdx = ABETCRSES.Idx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    AND ABETCRSES.Requirement IS NOT NULL
    AND ABETCRSES.Requirement != ''
    ORDER BY ABETCRSES.Requirement
";

$requirementResults = $DBCONNECTION->sendquery($requirementQuery);
if ($requirementResults) {
    while ($row = $requirementResults->fetch_assoc()) {
        if (!empty($row['Requirement'])) {
            $requirements[] = $row['Requirement'];
        }
    }
}

// Build the WHERE clause for requirement filter
$requirementWhereClause = "";
if ($requirementFilter !== 'All') {
    $requirementFilter = $DBCONNECTION->real_escape_string($requirementFilter);
    $requirementWhereClause = "AND ABETCRSES.Requirement = '{$requirementFilter}'";
}

// Get raw scores first, then consolidate by GPI code
$dataQuery = "
    SELECT
        AVCRSES.CourseNo,
        AVCRSES.Title,
        ABETCRSES.Requirement,
        STNTOUTCMS.SO,
        GPIS.GPI AS GPICode,
        SCSHEET.LevelOfAttainment   
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    LEFT JOIN AssessmentMeasures AS ASSMNTMEASURES ON (ASSMNTMEASURES.GPI = GPIS.Idx)
    LEFT JOIN Scoresheet AS SCSHEET ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
    LEFT JOIN AVCourses AS AVCRSES ON (SCSHEET.AvailableCourseIdx = AVCRSES.Idx)
    LEFT JOIN AbetCourses AS ABETCRSES ON (SCSHEET.AbetCourseIdx = ABETCRSES.Idx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    AND AVCRSES.CourseNo IS NOT NULL
    AND SCSHEET.LevelOfAttainment IS NOT NULL
    {$requirementWhereClause}
    ORDER BY AVCRSES.CourseNo, STNTOUTCMS.SO, GPIS.GPI
";

$dataResults = $DBCONNECTION->sendquery($dataQuery);

// Temporary storage for raw scores
$rawScores = array();

if ($dataResults) {
    while ($row = $dataResults->fetch_assoc()) {
        $courseKey = $row['CourseNo'];

        if (!isset($rawScores[$courseKey])) {
            $rawScores[$courseKey] = array(
                'courseNo' => $row['CourseNo'],
                'title' => $row['Title'],
                'requirement' => $row['Requirement'],
                'scores' => array()
            );
        }

        $soKey = $row['SO'];
        $gpiCode = $row['GPICode'];

        if (!isset($rawScores[$courseKey]['scores'][$soKey])) {
            $rawScores[$courseKey]['scores'][$soKey] = array();
        }

        if (!isset($rawScores[$courseKey]['scores'][$soKey][$gpiCode])) {
            $rawScores[$courseKey]['scores'][$soKey][$gpiCode] = array();
        }

        // Store individual scores (this consolidates across all GPIs with same code)
        $rawScores[$courseKey]['scores'][$soKey][$gpiCode][] = floatval($row['LevelOfAttainment']);
    }
}

// Now calculate averages and counts by GPI code
foreach ($rawScores as $courseKey => $courseData) {
    $courses[$courseKey] = array(
        'courseNo' => $courseData['courseNo'],
        'title' => $courseData['title'],
        'requirement' => $courseData['requirement'],
        'scores' => array(),
        'studentCounts' => array(),
        'studentsAbove2' => array(),
        'studentsAbove3' => array()
    );

    foreach ($courseData['scores'] as $soKey => $gpiData) {
        $courses[$courseKey]['scores'][$soKey] = array();
        $courses[$courseKey]['studentCounts'][$soKey] = array();
        $courses[$courseKey]['studentsAbove2'][$soKey] = array();
        $courses[$courseKey]['studentsAbove3'][$soKey] = array();

        foreach ($gpiData as $gpiCode => $scoresArray) {
            // Calculate average
            $avg = array_sum($scoresArray) / count($scoresArray);

            // Count students
            $totalStudents = count($scoresArray);

            // Count students above 2.0
            $studentsAbove2 = 0;
            foreach ($scoresArray as $score) {
                if ($score >= 2.0) {
                    $studentsAbove2++;
                }
            }

            // Count students above 3.0
            $studentsAbove3 = 0;
            foreach ($scoresArray as $score) {
                if ($score >= 3.0) {
                    $studentsAbove3++;
                }
            }

            $courses[$courseKey]['scores'][$soKey][$gpiCode] = round($avg, 2);
            $courses[$courseKey]['studentCounts'][$soKey][$gpiCode] = $totalStudents;
            $courses[$courseKey]['studentsAbove2'][$soKey][$gpiCode] = $studentsAbove2;
            $courses[$courseKey]['studentsAbove3'][$soKey][$gpiCode] = $studentsAbove3;
        }
    }
}

// Build the response data
$data = array();
foreach ($courses as $course) {
    $row = array(
        'requirement' => $course['requirement'],
        'courseNo' => $course['courseNo'],
        'title' => $course['title']
    );

    foreach ($studentOutcomes as $soKey => $soData) {
        foreach ($soData['gpis'] as $gpiInfo) {
            $gpiCode = $gpiInfo['code'];
            $columnKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'];
            $countKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_count';
            $above2Key = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_above2';
            $above3Key = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_above3';

            // Use the consolidated data by GPI code
            $row[$columnKey] = $course['scores'][$soKey][$gpiCode] ?? '';
            $row[$countKey] = $course['studentCounts'][$soKey][$gpiCode] ?? 0;
            $row[$above2Key] = $course['studentsAbove2'][$soKey][$gpiCode] ?? 0;
            $row[$above3Key] = $course['studentsAbove3'][$soKey][$gpiCode] ?? 0;
        }
    }

    $data[] = $row;
}

// Prepare final response
$Data['data'] = $data;
$Data['studentOutcomes'] = $studentOutcomes;
$Data['requirements'] = $requirements;

header('Content-Type: application/json');
echo json_encode($Data);
?>