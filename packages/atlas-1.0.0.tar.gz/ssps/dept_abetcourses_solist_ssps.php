<?php
/**
 * Listing SOs
 * File: dept_abetcourses_solist_ssps.php
 * Description: listing student outcomes in a dialog window
 *
 *
 *
 */

include_once 'session_handler.php';


$AcademicYear='';
if (array_key_exists('_AY', $_GET))
    $AcademicYear = trim($_GET['_AY']);

// DB table to use
$table = 'StudentOutcomes';
$joinQuery = "FROM `{$table}` ";

// Table's primary key
$primaryKey = 'Idx';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`SO`', 'dt' => 'SO', 'field' => 'SO', 'as' => 'SO'),
    array( 'db' => '`Description`', 'dt' => 'Desc', 'field' => 'Description', 'as' => 'Description')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";
if ($AcademicYear != "" && $AcademicYear != "all") $extraWhere .= " AND `AcademicYear`='".$AcademicYear."' ";


require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere)
);

