<?php
/**
 * Program Assessment Assignments By Courses
 * File: p_aabycrs.php
 * Description: Listing program assessment assignments by courses.
 *
 * 05/04/2021 - Fix error when displaying assignment & assignment description.
 * 
 */

include('header.php');

if ( (!isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM']) || !isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'])) &&
    isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']) ) {
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearsSelection = AcademicYearsSelection($multipleSelection = true, $visibleTogglebutton = false);

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

?>
    <script type="text/javascript">
        $(document).ready(function() {
            // Add event listener to the select element
            $("#_AY").on('change', function() {
                document.academicyear.submit();
            });
        });
    </script>

    <style>
        .so-summary-table {
            width: 100%;
            border-collapse: collapse;
            margin: 30px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            page-break-inside: avoid;
            font-size: 11pt; /* ADD THIS - consistent base font */
        }

        .so-summary-table th {
            background-color: #f8f9fa;
            padding: 12px;
            text-align: left;
            border: 1px solid #dee2e6;
            font-weight: bold;
            font-size: 11pt; /* ADD THIS */
        }

        .so-summary-table td {
            padding: 12px;
            border: 1px solid #dee2e6;
            vertical-align: top;
            font-size: 11pt; /* ADD THIS */
        }

        .so-header {
            background-color: #007bff;
            color: white;
            font-size: 13pt; /* CHANGED from 14pt */
            font-weight: bold;
            padding: 15px;
            text-align: left;
        }

        .pi-header {
            background-color: #e9ecef;
            font-weight: bold;
            padding: 10px;
            font-size: 11pt; /* ADD THIS */
        }

        .score-cell {
            text-align: center;
            font-size: 16pt; /* CHANGED from 18pt to be more consistent */
            font-weight: bold;
            background-color: #f8f9fa;
        }

        .rating-goal {
            background-color: #28a745;
            color: white;
            padding: 8px 10px;
            text-align: center;
            font-weight: bold;
            border-radius: 3px;
            font-size: 11pt; /* ADD THIS */
        }

        .rating-watch {
            background-color: #ffc107;
            color: black;
            padding: 8px 10px;
            text-align: center;
            font-weight: bold;
            border-radius: 3px;
            font-size: 11pt; /* ADD THIS */
        }

        .rating-mitigate {
            background-color: #dc3545;
            color: white;
            padding: 8px 10px;
            text-align: center;
            font-weight: bold;
            border-radius: 3px;
            font-size: 11pt; /* ADD THIS */
        }

        .actions-section {
            background-color: #fff3cd;
            padding: 15px;
            margin: 5px 0;
            border-left: 4px solid #ffc107;
            font-size: 11pt; /* ADD THIS */
        }

        .course-list {
            line-height: 1.8;
            font-size: 11pt;
        }

        .expectation-cell {
            padding: 10px;
            font-size: 11pt; /* CHANGED from 10pt */
        }
    </style>


    <script type="text/javascript">

        $(document).ready(function() {

            // Add event listener to the select element
            $("#_AY").on('change', function() {
                document.academicyear.submit();
            });

            // Add event listeners for changes in both selects
            $("#_AY_FROM").on("change", function () {
                let fromYear = parseInt($("#_AY_FROM").val());
                let toYear = parseInt($("#_AY_TO").val());

                if (fromYear > toYear) {
                    Swal.fire({
                        title: "Warning",
                        text: "The 'From' year cannot be greater than the 'To' year. Setting 'To' year to match 'From' year.",
                        icon: "warning",
                        timer: 2000
                    }).then(() => {
                        $("#_AY_TO").val(fromYear); // Set "To" to match "From"
                        document.academicyear.submit();
                    });
                } else {
                    document.academicyear.submit();
                }
            });

            $("#_AY_TO").on("change", function () {
                let fromYear = parseInt($("#_AY_FROM").val());
                let toYear = parseInt($("#_AY_TO").val());

                if (toYear < fromYear) {
                    Swal.fire({
                        title: "Warning",
                        text: "The 'To' year cannot be less than the 'From' year. Setting 'From' year to match 'To' year.",
                        icon: "warning",
                        timer: 2000
                    }).then(() => {
                        $("#_AY_FROM").val(toYear); // Set "From" to match "To"
                        document.academicyear.submit();
                    });
                } else {
                    document.academicyear.submit();
                }
            });

        });
    </script>

    <div class="pagebacklayout">
        <div class="row">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">STUDENT OUTCOMES ASSESSMENT SUMMARY</span></p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <?php include('control_allprograms.php'); ?>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:30%;">
                        <?php echo($AcademicYearsSelection);?>
                    </td>
                    <td style="width:10%"></td>
                    <td style="width:60%; text-align: right">
                    </td>
                </tr>
            </table>

            <div class='col-md-12'>
                <!-- Page Content -->
                <div id="pagebacklayout_inner_noborder">

                    <?php
                    require_once(__DIR__ . '/php_include/dbconnection_class.php');
                    $DBCONNECTION = new Dbconnection();

                    // Get all Student Outcomes for the selected program and academic year
                    $Query = "SELECT DISTINCT `SO`, `Description` FROM `StudentOutcomes` AS `STNTOUTCMS` 
          WHERE `AcademicProgram`='".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' ";

                    if ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] != "" && $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] != "") {
                        $Query .= " AND `AcademicYear` BETWEEN '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM']."' 
                AND '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO']."'";
                    }

                    $Query .= " ORDER BY `SO`";
                    echo $Query . '<br>';

                    $DBCONNECTION->sendquery($Query);

                    $studentOutcomes = array();
                    while ($row = $DBCONNECTION->fetch_assoc()) {
                        $studentOutcomes[] = $row;
                    }

//                    print_r( $studentOutcomes );

                    if (count($studentOutcomes) == 0) {
                        echo <<<HTML
<div class="boxcontainer">
    <p>
    <h4>No Student Outcomes Available</h4>
    <p>There are no student outcomes defined for the selected program and academic year.</p>
    </p>
</div>
HTML;
                    } else {
                        // Loop through each Student Outcome and display its summary
                        foreach ($studentOutcomes as $soIndex => $soData) {
                            $SO_Number = $soData['SO'];
                            $SO_Description = $soData['Description'];

                            // First, get DISTINCT GPIs for this SO
                            $QueryGPI = "SELECT DISTINCT `PI`.`Idx` as GPIIdx, `PI`.`GPI`, `PI`.`Description` as GPIDescription
            FROM `AbetCourses` AS `ABC` 
            INNER JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` ON (`ABC`.`Idx` = `ABETCRSES_GPIS`.`AbetCourseIdx`) 
            LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABC`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx` 
                                                                 AND `ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx`) 
            LEFT JOIN `GeneralPerformanceIndicators` AS `PI` ON (`ABETCRSES_GPIS`.`GPIIdx` = `PI`.`Idx`) 
            LEFT JOIN `StudentOutcomes` AS `SOS` ON (`ABETCRSES_SOS`.`SOIdx` = `SOS`.`Idx`) 
            WHERE `SOS`.`SO` = '$SO_Number' 
            AND `ABETCRSES_GPIS`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";

                            if ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] != "" && $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] != "") {
                                $QueryGPI .= " AND `ABC`.`AcademicYear` BETWEEN '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM']."' 
               AND '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO']."'";
                            }

                            $QueryGPI .= " ORDER BY `PI`.`GPI`";

                            echo $QueryGPI . '<br>';


                            $ResultGPI = $DBCONNECTION->sendquery($QueryGPI);

                            // Initialize GPI data structure
                            $gpiData = array();

                            while ($RowGPI = $DBCONNECTION->fetch_assoc()) {
                                $gpiKey = $RowGPI['GPI'];

                                $gpiData[$gpiKey] = array(
                                    'GPI' => $RowGPI['GPI'],
                                    'GPIIdx' => $RowGPI['GPIIdx'],
                                    'Description' => $RowGPI['GPIDescription'],
                                    'Courses' => array(),
                                    'AbetCourseIdxList' => array(),
                                    'TotalScore' => 0,
                                    'TotalStudents' => 0,
                                    'StudentsAbove3' => 0,
                                    'AverageScore' => 0,
                                    'PercentageAbove3' => 0
                                );
                            }

                            // Now get all courses for each GPI
                            foreach ($gpiData as $gpiKey => &$data) {
                                $QueryCourses = "SELECT DISTINCT `ABC`.`Idx` as AbetCourseIdx, `CRS`.`CourseNo`, `CRS`.`Title`
                FROM `AbetCourses` AS `ABC` 
                INNER JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` ON (`ABC`.`Idx` = `ABETCRSES_GPIS`.`AbetCourseIdx`) 
                LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABC`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx` 
                                                                     AND `ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx`) 
                LEFT JOIN `StudentOutcomes` AS `SOS` ON (`ABETCRSES_SOS`.`SOIdx` = `SOS`.`Idx`) 
                LEFT JOIN `AVCourses` AS `CRS` ON (`ABC`.`AVCourseIdx` = `CRS`.`Idx`) 
                WHERE `SOS`.`SO` = '$SO_Number' 
                AND `ABETCRSES_GPIS`.`GPIIdx` = '".$data['GPIIdx']."'
                AND `ABETCRSES_GPIS`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";

                                if ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] != "" && $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] != "") {
                                    $QueryCourses .= " AND `ABC`.`AcademicYear` BETWEEN '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM']."' 
                       AND '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO']."'";
                                }

                                $QueryCourses .= " ORDER BY `CRS`.`CourseNo`";

                                echo $QueryCourses . '<br>';

                                $ResultCourses = $DBCONNECTION->sendquery($QueryCourses);

                                while ($RowCourse = $DBCONNECTION->fetch_assoc()) {
                                    $data['Courses'][] = $RowCourse['CourseNo'] . ' ' . $RowCourse['Title'];
                                    $data['AbetCourseIdxList'][] = $RowCourse['AbetCourseIdx'];
                                }
                            }
                            unset($data);

                            // Now calculate scores for all GPIs using your original query structure
                            $DBCONNECTION_SCORES = new Dbconnection();

                            $QueryScores = "
            SELECT 
                `ASSMNTMEASURES`.`GPI` as GPIIdx,
                AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
                COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
                SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE 0 END) AS `ABOVE_THREE`
            FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
            INNER JOIN `Scoresheet` AS `SCSHEET` 
                ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
            INNER JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` 
                ON (`ASSMNTMEASURES`.`AbetCourseIdx` = `ABETCRSES_GPIS`.`AbetCourseIdx` 
                    AND `ASSMNTMEASURES`.`GPI` = `ABETCRSES_GPIS`.`GPIIdx`)
            INNER JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` 
                ON (`ABETCRSES_GPIS`.`AbetCourseIdx` = `ABETCRSES_SOS`.`AbetCourseIdx` 
                    AND `ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx`)
            INNER JOIN `StudentOutcomes` AS `SOS` 
                ON (`ABETCRSES_SOS`.`SOIdx` = `SOS`.`Idx`)
            WHERE `SOS`.`SO` = '$SO_Number'
                AND `ABETCRSES_GPIS`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";

                            if ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM'] != "" && $_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO'] != "") {
                                $QueryScores .= " AND `ABETCRSES_GPIS`.`AcademicYear` BETWEEN '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR_FROM']."' 
                              AND '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR_TO']."'";
                            }

                            $QueryScores .= " GROUP BY `ASSMNTMEASURES`.`GPI`";

                            $DBCONNECTION_SCORES->sendquery($QueryScores);

                            // Apply scores to gpiData
                            while ($rowScore = $DBCONNECTION_SCORES->fetch_assoc()) {
                                $gpiIdx = $rowScore['GPIIdx'];

                                // Find the matching GPI in gpiData by GPIIdx
                                foreach ($gpiData as $gpiKey => &$data) {
                                    if ($data['GPIIdx'] == $gpiIdx) {
                                        $totalStudents = intval($rowScore['TOTAL']);
                                        $studentsAbove3 = intval($rowScore['ABOVE_THREE']);

                                        $data['AverageScore'] = floatval($rowScore['AVG']);
                                        $data['TotalStudents'] = $totalStudents;
                                        $data['StudentsAbove3'] = $studentsAbove3;

                                        if ($totalStudents > 0) {
                                            $data['PercentageAbove3'] = ($studentsAbove3 / $totalStudents) * 100;
                                        } else {
                                            $data['PercentageAbove3'] = 0;
                                        }
                                        break;
                                    }
                                }
                            }
                            unset($data);
                            unset($DBCONNECTION_SCORES);

                            if (count($gpiData) > 0) {
                                // Display Student Outcome Summary Table
                                echo '<table class="so-summary-table">';

                                // Header Row
                                echo '<tr>';
                                echo '<td colspan="' . count($gpiData) . '" class="so-header">';
                                echo $SO_Number . ': ' . $SO_Description;
                                echo '</td>';
                                echo '</tr>';

                                // Performance Indicators Row
                                echo '<tr class="pi-header">';
                                echo '<td colspan="' . count($gpiData) . '">Performance Indicators:</td>';
                                echo '</tr>';

                                // GPI Details - Show each GPI in its own column
                                echo '<tr>';
                                foreach ($gpiData as $gpi => $data) {
                                    echo '<td style="width:' . (100/count($gpiData)) . '%;">';
                                    echo '<strong>' . $SO_Number . '-' . htmlspecialchars($data['GPI']) . '</strong> ' . htmlspecialchars($data['Description']);
                                    echo '</td>';
                                }
                                echo '</tr>';

                                // Courses Involved
                                echo '<tr class="pi-header">';
                                echo '<td colspan="' . count($gpiData) . '">Courses Involved:</td>';
                                echo '</tr>';

                                echo '<tr>';
                                foreach ($gpiData as $gpi => $data) {
                                    echo '<td class="course-list">';
                                    if (count($data['Courses']) > 0) {
                                        // Extract only course subject & number (without titles)
                                        $courseNumbers = array();
                                        foreach ($data['Courses'] as $courseFullName) {
                                            // Extract course number (everything before the title)
                                            // Assuming format is "SUBJ### Title" or "SUBJ ### Title"
                                            $parts = explode(' ', trim($courseFullName));

                                            // Take first part (subject code) and second part if it's numeric
                                            if (count($parts) >= 2 && is_numeric($parts[1])) {
                                                $courseNumbers[] = $parts[0] . ' ' . $parts[1];
                                            } else {
                                                // If no space between subject and number (e.g., CS101)
                                                $courseNumbers[] = $parts[0];
                                            }
                                        }

                                        // Get unique course numbers only
                                        $uniqueCourseNumbers = array_unique($courseNumbers);

                                        // Display courses in a nicely formatted way
                                        $courseChunks = array_chunk($uniqueCourseNumbers, 3);
                                        foreach ($courseChunks as $chunk) {
                                            echo implode(', ', $chunk);
                                            if ($chunk !== end($courseChunks)) {
                                                echo ',<br/>';
                                            }
                                        }
                                    } else {
                                        echo '<em>No courses assigned</em>';
                                    }
                                    echo '</td>';
                                }
                                echo '</tr>';

                                // Average Scores Row
                                echo '<tr class="pi-header">';
                                echo '<td colspan="' . count($gpiData) . '">Average Scores for Performance Indicators</td>';
                                echo '</tr>';

                                echo '<tr>';
                                $totalScore = 0;
                                $countGPIs = 0;
                                foreach ($gpiData as $gpi => $data) {
                                    $score = number_format($data['AverageScore'], 2);
                                    $totalScore += $data['AverageScore'];
                                    $countGPIs++;
                                    echo '<td class="score-cell">' . $score . '</td>';
                                }
                                echo '</tr>';

                                // Overall Average Score
                                $avgScore = $countGPIs > 0 ? $totalScore / $countGPIs : 0;
                                echo '<tr>';
                                echo '<td colspan="' . count($gpiData) . '" class="score-cell" style="background-color:#d1ecf1;">';
                                echo 'Average Score for ' . $SO_Number . ': ' . number_format($avgScore, 2);
                                echo '</td>';
                                echo '</tr>';

                                // Actions To Be Taken
                                echo '<tr class="pi-header">';
                                echo '<td colspan="' . count($gpiData) . '">Actions To Be Taken:</td>';
                                echo '</tr>';

                                echo '<tr>';
                                echo '<td colspan="' . count($gpiData) . '">';

                                foreach ($gpiData as $gpi => $data) {
                                    $score = number_format($data['AverageScore'], 2);
                                    $percentage = number_format($data['PercentageAbove3'], 2);

                                    echo '<div class="actions-section">';
                                    echo '<strong>' . $SO_Number . '-' . $data['GPI'] . ' [Score ' . $score . ']:</strong> ';

                                    if ($data['TotalStudents'] > 0) {
                                        // Generate message based on percentage
                                        if ($percentage > 85) {
                                            echo 'The attainment of ' . $SO_Number . ' through this general performance indicator exceeds expectations. ';
                                        } elseif ($percentage >= 75) {
                                            echo 'The attainment of ' . $SO_Number . ' through this general performance indicator meets the general expectation. ';
                                        } else {
                                            echo 'The attainment of ' . $SO_Number . ' through this general performance indicator is below expectation. ';
                                        }

                                        echo 'A total of ' . $percentage . '% of students have attained a score of 3.0 or more.';

                                        // Add course improvement note if below 75%
                                        if ($percentage < 75 && count($data['Courses']) > 0) {
                                            $courseList = '';
                                            if (count($data['Courses']) > 1) {
                                                $courseList = implode(', ', array_slice($data['Courses'], 0, -1)) . ', and ' . end($data['Courses']);
                                            } else {
                                                $courseList = $data['Courses'][0];
                                            }
                                            echo ' Therefore, courses ' . $courseList . ' will continue building exercises on students\' understanding of this performance indicator.';
                                        }
                                    } else {
                                        echo 'No assessment data available for this performance indicator.';
                                    }

                                    echo '</div>';
                                }
                                echo '</td>';
                                echo '</tr>';

                                echo '</table>';
                            } else {
                                echo '<div class="alert alert-warning">';
                                echo '<strong>' . $SO_Number . ': ' . $SO_Description . '</strong><br/>';
                                echo 'No performance indicator data available for this student outcome.';
                                echo '</div>';
                            }

                            // Add divider between SOs (except for the last one)
                            if ($soIndex < count($studentOutcomes) - 1) {
                                echo '<div class="so-divider"></div>';
                            }
                        } // End foreach ($studentOutcomes)
                    } // End else (studentOutcomes count > 0)

                    unset($DBCONNECTION);
                    ?>

                </div>
                <!-- /#page-content-wrapper -->
            </div>

        </div>
    </div>

<?php include('footer.php');?>