<?php
/**
 * Listing SOs
 * File: dept_so_ssps.php
 * Description: listing student outcomes
 *
 *
 *
 */
include_once 'session_handler.php';



$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = 'StudentOutcomes';
$joinQuery = "FROM `{$table}` AS `SO` INNER JOIN `AcademicPrograms` AS `AP` ON (`SO`.`AcademicProgram` = `AP`.`Idx` AND `SO`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."') INNER JOIN `AcademicYears` AS `AYS` ON (`SO`.`AcademicYear`=`AYS`.`Idx`)";

// Table's primary key
$primaryKey = '`SO`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`SO`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`SO`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`AYS`.`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => '`SO`.`SO`', 'dt' => 'SO', 'field' => 'SO', 'as' => 'SO'),
    array( 'db' => '`SO`.`Description`', 'dt' => 'Description', 'field' => 'Description', 'as' => 'Description'),
    array( 'db' => '`SO`.`Comments`', 'dt' => 'Comments', 'field' => 'Comments', 'as' => 'Comments'),
    array( 'db' => '`SO`.`Approval`', 'dt' => 'Approval', 'field' => 'Approval', 'as' => 'Approval'),
    array( 'db' => '`SO`.`TobeRemoved`', 'dt' => 'TobeRemoved', 'field' => 'TobeRemoved', 'as' => 'TobeRemoved'),
    array( 'db' => '`SO`.`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );

$extraWhere = "`SO`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";

if ($AcademicYear != "" && $AcademicYear != "all") $extraWhere .= " AND `SO`.`AcademicYear`='".$AcademicYear."'";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, '', false)
);

