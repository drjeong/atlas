<?php
/**
 * Management of Semester Information
 * Description: remove semester information
 * Author: Dong Hyun Jeong
 *
 * 08/04/2026 - initial version created
 * 08/05/2026 - revised to handle semester information
 *
 */

include('checker_systemadmin.php');

$IDX = (isset($_POST['id'])) ? trim($_POST['id']) : '';

if ($IDX==""){
    echo "0x00000011";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $IDX = filter_var($IDX, FILTER_VALIDATE_INT);
    if ($IDX === false) {
        throw new Exception('Invalid Index format');
    }

    $query = "CALL SP_RemoveSemesterInfo(?);";

    // Don't assign result yet - let exceptions be thrown
    $DBCONNECTION->prepare_execute_catch_error($query, [$IDX]);

    // If we get here, it was successful
    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    $errorCode = $e->getCode();

    // Log for debugging
    if (strpos($errorMessage, '0x09000010') !== false) {
        echo '0x09000010';  // Cannot delete: the item is already in use.
    }
    // Also check for SQLSTATE 45000 which is user-defined errors
    else if ($errorCode == 1644) { // 1644 is MySQL error code for SIGNAL SQLSTATE '45000'
        // Try to extract custom error code from message
        if (strpos($errorMessage, '0x09000010') !== false) {
            echo '0x09000010';
        } else {
            echo "0x00000500";
        }
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => $e->getCode()
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}