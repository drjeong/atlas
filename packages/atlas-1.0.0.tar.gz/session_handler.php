<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Illegal access (session expired or not logged in)
if (!isset($_SESSION['ATLAS_LOGIN_USERIDX'])) {
    session_destroy();
    header('Location: ./');
    exit;
}
