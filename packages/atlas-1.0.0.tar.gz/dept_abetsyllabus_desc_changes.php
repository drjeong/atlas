<?php
/**
 * Management of Syllabus of ABET Courses
 * Description: listing changes of courses in catalog description
 * Author: Dong Hyun Jeong
 *
 * 09/29/2024 - initial version created
 *
 */


include('header.php');

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

?>

    <script src="js/datatable-utils-holdsearch.min.js"></script>
    <script src="js/datatable-utils-search.min.js"></script>

    <!-- Add jsPDF and jsPDF-AutoTable libraries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js"></script>

    <script>
        // Longest Common Subsequence algorithm for word-level diff
        function computeLCS(oldWords, newWords) {
            const m = oldWords.length;
            const n = newWords.length;
            const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));

            // Build LCS table
            for (let i = 1; i <= m; i++) {
                for (let j = 1; j <= n; j++) {
                    if (oldWords[i - 1] === newWords[j - 1]) {
                        dp[i][j] = dp[i - 1][j - 1] + 1;
                    } else {
                        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                    }
                }
            }

            return dp;
        }

        function buildDiff(oldWords, newWords, dp) {
            let i = oldWords.length;
            let j = newWords.length;
            const oldResult = [];
            const newResult = [];
            const oldResultPlain = []; // For PDF
            const newResultPlain = []; // For PDF

            while (i > 0 || j > 0) {
                if (i > 0 && j > 0 && oldWords[i - 1] === newWords[j - 1]) {
                    // Words match - add to both without highlighting
                    oldResult.unshift(oldWords[i - 1]);
                    newResult.unshift(newWords[j - 1]);
                    oldResultPlain.unshift({ text: oldWords[i - 1], type: 'normal' });
                    newResultPlain.unshift({ text: newWords[j - 1], type: 'normal' });
                    i--;
                    j--;
                } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
                    // Added in new version
                    newResult.unshift(`<span style="background-color: #4caf50; color: white; padding: 2px 4px; border-radius: 2px; font-weight: bold;">${newWords[j - 1]}</span>`);
                    newResultPlain.unshift({ text: newWords[j - 1], type: 'added' });
                    j--;
                } else if (i > 0) {
                    // Deleted from old version
                    oldResult.unshift(`<span style="background-color: #f44336; color: white; padding: 2px 4px; border-radius: 2px; text-decoration: line-through; font-weight: bold;">${oldWords[i - 1]}</span>`);
                    oldResultPlain.unshift({ text: oldWords[i - 1], type: 'deleted' });
                    i--;
                }
            }

            return {
                oldHtml: oldResult.join(' '),
                newHtml: newResult.join(' '),
                oldPlain: oldResultPlain,
                newPlain: newResultPlain
            };
        }

        function highlightDifferences(oldText, newText) {
            if (!oldText && !newText) {
                return { oldHtml: '', newHtml: '', oldPlain: [], newPlain: [] };
            }

            if (!oldText) {
                const words = newText.trim().split(/\s+/);
                const highlighted = words.map(word => {
                    return `<span style="background-color: #4caf50; color: white; padding: 2px 4px; border-radius: 2px; font-weight: bold;">${word}</span>`;
                }).join(' ');
                const plain = words.map(word => ({ text: word, type: 'added' }));
                return { oldHtml: '', newHtml: highlighted, oldPlain: [], newPlain: plain };
            }

            if (!newText) {
                const words = oldText.trim().split(/\s+/);
                const highlighted = words.map(word => {
                    return `<span style="background-color: #f44336; color: white; padding: 2px 4px; border-radius: 2px; text-decoration: line-through; font-weight: bold;">${word}</span>`;
                }).join(' ');
                const plain = words.map(word => ({ text: word, type: 'deleted' }));
                return { oldHtml: highlighted, newHtml: '', oldPlain: plain, newPlain: [] };
            }

            // Split into words (trim and split by whitespace)
            const oldWords = oldText.trim().split(/\s+/);
            const newWords = newText.trim().split(/\s+/);

            // Compute LCS
            const dp = computeLCS(oldWords, newWords);
            const diff = buildDiff(oldWords, newWords, dp);

            return diff;
        }

        // Function to create content for PDF cell with styling information
        function createStyledContentForPDF(plainArray) {
            if (!plainArray || plainArray.length === 0) return { content: '', styles: {} };

            const content = plainArray.map(item => {
                if (item.type === 'added') {
                    return `<<GREEN>>${item.text}<</GREEN>>`;
                } else if (item.type === 'deleted') {
                    return `<<RED>>${item.text}<</RED>>`;
                } else {
                    return item.text;
                }
            }).join(' ');

            return { content: content, styles: {} };
        }

        // Function to export to PDF with colored highlights in table
        function exportToPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF('l', 'mm', 'a4'); // Landscape orientation

            // Get all data from the DataTable
            const data = DataTable_Courses.rows({ search: 'applied' }).data().toArray();

            // Prepare table data - keep original text without markers
            const tableData = data.map(row => {
                return [
                    row.Subject || '',
                    row.Num || '',
                    row.Title || '',
                    row.Credits || '',
                    row.Description || '',
                    row.Version || '',
                    row.PrevDescription || '',
                    row.PrevVersion || ''
                ];
            });

            const selectedText = document.changefrm.CH_APR.selectedOptions[0].text;

            // Add title
            doc.setFontSize(16);
            doc.text(`Course Description Changes - ${selectedText}`, 148, 15, { align: 'center' });

            // Add legend
            doc.setFontSize(9);
            doc.setFillColor(76, 175, 80);
            doc.rect(14, 22, 8, 3, 'F');
            doc.setTextColor(0, 0, 0);
            doc.text('= Added text', 23, 24.5);

            doc.setFillColor(244, 67, 54);
            doc.rect(55, 22, 8, 3, 'F');
            doc.text('= Deleted text', 64, 24.5);

            // Helper function to calculate text height with wrapping
            function calculateTextHeight(text, maxWidth, fontSize) {
                doc.setFontSize(fontSize);
                const words = text.split(' ');
                let lines = 1;
                let currentLine = '';

                words.forEach(word => {
                    const testLine = currentLine + (currentLine ? ' ' : '') + word;
                    const testWidth = doc.getTextWidth(testLine);

                    if (testWidth > maxWidth && currentLine) {
                        lines++;
                        currentLine = word;
                    } else {
                        currentLine = testLine;
                    }
                });

                const lineHeight = fontSize * 0.5; // Approximate line height
                return lines * lineHeight + 4; // Add padding
            }

            // Add table with custom rendering
            doc.autoTable({
                head: [['Subject', 'Num', 'Title', 'Credits', 'New Description', 'New Ver', 'Old Description', 'Old Ver']],
                body: tableData,
                startY: 30,
                styles: {
                    fontSize: 8,
                    cellPadding: 2,
                    overflow: 'linebreak',
                    cellWidth: 'wrap',
                    lineColor: [200, 200, 200],
                    lineWidth: 0.1,
                    minCellHeight: 10
                },
                columnStyles: {
                    0: { cellWidth: 15 },  // Subject
                    1: { cellWidth: 12 },  // Num
                    2: { cellWidth: 35 },  // Title
                    3: { cellWidth: 15 },  // Credits
                    4: { cellWidth: 90 },  // New Description
                    5: { cellWidth: 12 },  // New Version
                    6: { cellWidth: 90 },  // Old Description
                    7: { cellWidth: 12 }   // Old Version
                },
                headStyles: {
                    fillColor: [218, 165, 32],
                    textColor: [0, 0, 0],
                    fontStyle: 'bold',
                    halign: 'center'
                },
                didParseCell: function(data) {
                    if (data.section === 'body') {
                        const rowIndex = data.row.index;
                        const originalRow = DataTable_Courses.rows({ search: 'applied' }).data().toArray()[rowIndex];

                        // Highlight rows with changes
                        if (originalRow && originalRow.PrevDescription && originalRow.PrevDescription !== originalRow.Description) {
                            data.cell.styles.fillColor = [255, 243, 205]; // Light yellow
                        }

                        // Calculate minimum height needed for description columns
                        if (data.column.index === 4 || data.column.index === 6) {
                            const text = data.cell.text.join(' ');
                            const colWidth = data.column.index === 4 ? 70 : 70;
                            const minHeight = calculateTextHeight(text, colWidth - 4, 8);

                            if (!data.row.minHeight || minHeight > data.row.minHeight) {
                                data.row.minHeight = minHeight;
                            }
                            data.cell.styles.minCellHeight = data.row.minHeight;
                        }
                    }
                },
                didDrawCell: function(data) {
                    // Custom rendering for description cells (columns 4 and 6)
                    if (data.section === 'body' && (data.column.index === 4 || data.column.index === 6)) {
                        const rowIndex = data.row.index;
                        const originalRow = DataTable_Courses.rows({ search: 'applied' }).data().toArray()[rowIndex];

                        // Check if this row has changes
                        if (originalRow && originalRow.PrevDescription && originalRow.PrevDescription !== originalRow.Description) {
                            const isNewColumn = data.column.index === 4;
                            const oldText = originalRow.PrevDescription || '';
                            const newText = originalRow.Description || '';

                            // Get the diff
                            const diff = highlightDifferences(oldText, newText);
                            const plainArray = isNewColumn ? diff.newPlain : diff.oldPlain;

                            if (plainArray && plainArray.length > 0) {
                                // Clear the cell
                                doc.setFillColor(data.cell.styles.fillColor[0], data.cell.styles.fillColor[1], data.cell.styles.fillColor[2]);
                                doc.rect(data.cell.x, data.cell.y, data.cell.width, data.cell.height, 'F');

                                // Render styled text with word wrapping
                                let xPos = data.cell.x + data.cell.padding('left');
                                let yPos = data.cell.y + data.cell.padding('top') + 2.8;
                                const maxWidth = data.cell.width - data.cell.padding('left') - data.cell.padding('right');
                                const lineHeight = 4;

                                doc.setFontSize(8);

                                let currentX = xPos;

                                plainArray.forEach((token, idx) => {
                                    const words = token.text.split(' ');

                                    words.forEach((word, wordIdx) => {
                                        if (!word) return;

                                        const spaceWidth = doc.getTextWidth(' ');
                                        const wordWidth = doc.getTextWidth(word);

                                        // Check if word fits on current line
                                        if (currentX + wordWidth > xPos + maxWidth && currentX > xPos) {
                                            // Move to next line
                                            yPos += lineHeight;
                                            currentX = xPos;
                                        }

                                        // Draw background for styled text
                                        if (token.type === 'added') {
                                            doc.setFillColor(76, 175, 80);
                                            doc.rect(currentX, yPos - 2.5, wordWidth, lineHeight - 0.5, 'F');
                                            doc.setTextColor(255, 255, 255);
                                        } else if (token.type === 'deleted') {
                                            doc.setFillColor(244, 67, 54);
                                            doc.rect(currentX, yPos - 2.5, wordWidth, lineHeight - 0.5, 'F');
                                            doc.setTextColor(255, 255, 255);
                                        } else {
                                            doc.setTextColor(0, 0, 0);
                                        }

                                        // Draw the word
                                        doc.text(word, currentX, yPos);
                                        currentX += wordWidth;

                                        // Add space after word (except for last word in token)
                                        if (wordIdx < words.length - 1 || idx < plainArray.length - 1) {
                                            currentX += spaceWidth;
                                        }
                                    });
                                });

                                // Reset text color
                                doc.setTextColor(0, 0, 0);
                            }
                        }
                    }
                },
                rowPageBreak: 'avoid', // Prevent rows from breaking across pages
                margin: { top: 30, left: 10, right: 10, bottom: 20 }
            });

            // Add footer
            const pageCount = doc.internal.getNumberOfPages();
            for (let i = 1; i <= pageCount; i++) {
                doc.setPage(i);
                doc.setFontSize(8);
                doc.text(`Page ${i} of ${pageCount}`, 148, 200, { align: 'center' });
                doc.text(`Generated: ${new Date().toLocaleString()}`, 148, 205, { align: 'center' });
            }

            // Save the PDF
            doc.save('Course_Description_Changes.pdf');
        }
    </script>

    <script class="init">
        $(document).ready(function() {
            DataTable_Courses = $("#coursesyllabusinfo").DataTable({
                dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
                processing: true,
                serverSide: true,
                lengthMenu: [ 50, 100, 150, 300, 500 ],
                search: {
                    regex: true
                },
                fnInitComplete: function(oSettings, json) {
                    let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                    btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                    $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                        $('#' + oSettings.sTableId).dataTable().fnFilter('');
                    });
                },
                ajax: 'ssps/dept_abetsyllabus_desc_changes_ssps.php',
                oLanguage: {sInfoFiltered: ""},
                columns: [
                    { data: 'Subject' },
                    { data: 'Num' },
                    { data: 'Title' },
                    { data: 'Credits' },
                    {
                        data: 'Description',
                        render: function(data, type, row) {
                            if (type === 'display') {
                                if (row.PrevDescription && row.PrevDescription !== data) {
                                    const diff = highlightDifferences(row.PrevDescription, data);
                                    return `<div style="background-color: #e8f5e9; padding: 8px; border-radius: 3px; line-height: 1.8;">${diff.newHtml || '<em>Empty</em>'}</div>`;
                                }
                                return data || '';
                            }
                            return data;
                        }
                    },
                    {
                        data: 'Version',
                        render: function(data, type, row) {
                            if (type === 'display') {
                                return `<strong>${data}</strong>`;
                            }
                            return data;
                        }
                    },
                    {
                        data: 'PrevDescription',
                        render: function(data, type, row) {
                            if (type === 'display') {
                                if (data && data !== row.Description) {
                                    const diff = highlightDifferences(data, row.Description);
                                    return `<div style="background-color: #ffebee; padding: 8px; border-radius: 3px; line-height: 1.8;">${diff.oldHtml || '<em>Empty</em>'}</div>`;
                                }
                                return data || '';
                            }
                            return data;
                        }
                    },
                    {
                        data: 'PrevVersion',
                        render: function(data, type, row) {
                            if (type === 'display') {
                                if (data) {
                                    return `<strong>${data}</strong>`;
                                }
                                return '';
                            }
                            return data;
                        }
                    }
                ],
                order: [[ 0, 'asc' ], [ 1, 'asc' ]],
                fnDrawCallback: function() {
                    $('#coursesyllabusinfo tr td:nth-child(1)').css('text-align', 'center');
                    $('#coursesyllabusinfo tr td:nth-child(2)').css('text-align', 'center');
                    $('#coursesyllabusinfo tr td:nth-child(3)').css('text-align', 'left');
                    $('#coursesyllabusinfo tr td:nth-child(4)').css('text-align', 'center');
                    $('#coursesyllabusinfo tr td:nth-child(5)').css('text-align', 'left');
                    $('#coursesyllabusinfo tr td:nth-child(6)').css('text-align', 'center');
                    $('#coursesyllabusinfo tr td:nth-child(7)').css('text-align', 'left');
                    $('#coursesyllabusinfo tr td:nth-child(8)').css('text-align', 'center');

                    $('#coursesyllabusinfo tbody tr').each(function() {
                        const rowData = DataTable_Courses.row(this).data();
                        if (rowData && rowData.HasChanges === '1') {
                            $(this).css('background-color', '#fff3cd');
                        }
                    });
                },
                columnDefs: [ {
                    targets  : 'no-sort',
                    orderable: false,
                }],
                buttons: [
                    {
                        extend: 'excelHtml5',
                        title: function () {
                            const selectedText = document.changefrm.CH_APR.selectedOptions[0].text;
                            return `Course Description Changes - ${selectedText}`;
                        },
                        text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                        className: 'btn btn-xs',
                        attr: {
                            style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                        },
                    },
                    {
                        text: '<span class="glyphicon glyphicon-floppy-save"></span> PDF with Highlights',
                        className: 'btn btn-xs',
                        attr: {
                            style: 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff;'
                        },
                        action: function (e, dt, node, config) {
                            exportToPDF();
                        }
                    }
                ]
            });

            DataTable_Courses.columns().every(function(index) {
                $(this.header()).on('keyup change', 'input', function() {
                    localStorage.setItem('dtColSearch_' + index, this.value);
                });
            });

            new DataTableHoldSearch('#coursesyllabusinfo', DataTable_Courses, true, true);
        } );
    </script>


    <div class="pagebacklayout">
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSE DESCRIPTION CHANGES</span></p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:100%; text-align: left;">
                        <?php
                        include('control_allprograms.php');
                        ?>
                    </td>
                </tr>
            </table>

            <style>
                .wrap-cell {
                    white-space: normal !important;
                    word-wrap: break-word;
                    padding: 8px !important;
                }

                #coursesyllabusinfo tbody tr {
                    vertical-align: top;
                }

                #coursesyllabusinfo tbody tr td {
                    padding: 8px;
                }

                #coursesyllabusinfo tbody tr td:nth-child(5),
                #coursesyllabusinfo tbody tr td:nth-child(7) {
                    max-width: 400px;
                    word-wrap: break-word;
                }
            </style>

            <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
                <table id="coursesyllabusinfo" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th>SUBJECT</th>
                        <th>NUM</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>NEW CATALOG DESCRIPTION</th>
                        <th>NEW VERSION</th>
                        <th>OLD CATALOG DESCRIPTION</th>
                        <th>OLD VERSION</th>
                    </tr>
                    </thead>
                    <thead id="serachbox" class="filters">
                    <tr>
                        <th>SUBJECT</th>
                        <th>NUM</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>NEW CATALOG DESCRIPTION</th>
                        <th>NEW VERSION</th>
                        <th>OLD CATALOG DESCRIPTION</th>
                        <th>OLD VERSION</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>SUBJECT</th>
                        <th>NUM</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>NEW CATALOG DESCRIPTION</th>
                        <th>NEW VERSION</th>
                        <th>OLD CATALOG DESCRIPTION</th>
                        <th>OLD VERSION</th>
                    </tr>
                    </tfoot>
                </table>
            </div>


            <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt; margin-top: 10px;">
                <tr>
                    <td>
                        <span style="background-color: #fff3cd; padding: 2px 8px; border-radius: 3px;">Highlighted rows</span> indicate courses with changes from previous version
                    </td>
                    <td style="text-align:right;">
                        <span style="background-color: #4caf50; color: white; padding: 2px 8px; border-radius: 3px; font-weight: bold;">Green highlight</span>: Added text &nbsp;&nbsp;
                        <span style="background-color: #f44336; color: white; padding: 2px 8px; border-radius: 3px; text-decoration: line-through; font-weight: bold;">Red highlight</span>: Deleted text
                    </td>
                </tr>
            </table>
        </div>
    </div>

<?php include('footer.php');?>