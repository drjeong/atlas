
// Function to show full-page Bootstrap spinner
// using Bootstrap 3.3.5
let spinnerTimeout;
function showFullPageSpinner() {
	// Check if the full-page loader already exists
	let fullPageLoader = document.getElementById('fullPageLoader');

	if (!fullPageLoader) {
		// Create the full-page loader
		fullPageLoader = document.createElement('div');
		fullPageLoader.id = 'fullPageLoader';
		fullPageLoader.style.position = 'fixed';
		fullPageLoader.style.top = '0';
		fullPageLoader.style.left = '0';
		fullPageLoader.style.width = '100%';
		fullPageLoader.style.height = '100%';
		fullPageLoader.style.backgroundColor = 'rgba(255, 255, 255, 0.7)';
		fullPageLoader.style.display = 'flex';
		fullPageLoader.style.justifyContent = 'center';
		fullPageLoader.style.alignItems = 'center';
		fullPageLoader.style.zIndex = '9999'; // Higher than anything else

		// Create Bootstrap 3.3.5 compatible spinner with larger icon and text
		fullPageLoader.innerHTML = `
            <div class="text-center">
                <div class="spinner" style="margin-bottom: 20px;">
                    <i class="fa fa-spinner fa-spin" style="font-size: 5rem; color: #337ab7;"></i>
                </div>
                <h4 style="color: #337ab7;">Processing...</h4>
            </div>
        `;

		document.body.appendChild(fullPageLoader);
	} else {
		// If it exists, make sure it's visible
		fullPageLoader.style.display = 'flex';
	}

	// Start a timeout to automatically hide the spinner after 2 minutes
	spinnerTimeout = setTimeout(() => {
		hideFullPageSpinner();
		Swal.fire({
			title: "ERROR",
			text: "Unexpected error found. Please contact the system administrator!",
			icon: "error"
		});
	}, 120000); // 120,000 ms = 2 minutes
}


// Function to hide full-page Bootstrap spinner
// using Bootstrap 3.3.5
function hideFullPageSpinner() {
	const fullPageLoader = document.getElementById('fullPageLoader');

	if (fullPageLoader) {
		fullPageLoader.style.display = 'none';
	}

	// Clear the timeout if hideFullPageSpinner is called manually before timeout
	clearTimeout(spinnerTimeout);
}



class FullPageSpinner {
	constructor(options = {}) {
		this.timeout = options.timeout || 120000; // 2 minutes default
		this.message = options.message || 'Processing...';
		this.iconSize = options.iconSize || '5rem';
		this.iconColor = options.iconColor || '#337ab7';
		this.onTimeout = options.onTimeout || this.defaultTimeoutHandler;

		this.spinnerElement = null;
		this.timeoutId = null;

		this.show();
	}

	show() {
		// Check if the full-page loader already exists
		this.spinnerElement = document.getElementById('fullPageLoader');

		if (!this.spinnerElement) {
			// Create the full-page loader
			this.spinnerElement = document.createElement('div');
			this.spinnerElement.id = 'fullPageLoader';
			this.spinnerElement.style.position = 'fixed';
			this.spinnerElement.style.top = '0';
			this.spinnerElement.style.left = '0';
			this.spinnerElement.style.width = '100%';
			this.spinnerElement.style.height = '100%';
			this.spinnerElement.style.backgroundColor = 'rgba(255, 255, 255, 0.7)';
			this.spinnerElement.style.display = 'flex';
			this.spinnerElement.style.justifyContent = 'center';
			this.spinnerElement.style.alignItems = 'center';
			this.spinnerElement.style.zIndex = '9999';

			// Create Bootstrap 3.3.5 compatible spinner with larger icon and text
			this.spinnerElement.innerHTML = `
				<div class="text-center">
					<div class="spinner" style="margin-bottom: 20px;">
						<i class="fa fa-spinner fa-spin" style="font-size: ${this.iconSize}; color: ${this.iconColor};"></i>
					</div>
					<h4 style="color: ${this.iconColor};">${this.message}</h4>
				</div>
			`;

			document.body.appendChild(this.spinnerElement);
		} else {
			// If it exists, make sure it's visible
			this.spinnerElement.style.display = 'flex';
		}

		// Start timeout
		this.timeoutId = setTimeout(() => {
			this.destroy();
			this.onTimeout();
		}, this.timeout);
	}

	hide() {
		if (this.spinnerElement) {
			this.spinnerElement.style.display = 'none';
		}
		this.clearTimeout();
	}

	destroy() {
		this.hide();
		if (this.spinnerElement && this.spinnerElement.parentNode) {
			this.spinnerElement.parentNode.removeChild(this.spinnerElement);
			this.spinnerElement = null;
		}
	}

	clearTimeout() {
		if (this.timeoutId) {
			clearTimeout(this.timeoutId);
			this.timeoutId = null;
		}
	}

	defaultTimeoutHandler() {
		if (typeof Swal !== 'undefined') {
			Swal.fire({
				title: "ERROR",
				text: "Unexpected error found. Please contact the system administrator!",
				icon: "error"
			});
		} else {
			alert("Unexpected error found. Please contact the system administrator!");
		}
	}
}