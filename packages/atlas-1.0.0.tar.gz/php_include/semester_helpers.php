<?php

require_once 'SemesterCodeConfig.php';
require_once 'SemesterCodeManager.php';

/**
 * Get the semester manager instance (singleton pattern)
 * This ensures we only create one instance throughout the application
 */
function getSemesterManager()
{
    static $manager = null;
    if ($manager === null) {
        require_once(__DIR__ . '/../../config.php');
        $config = new SemesterCodeConfig(__SCHOOL_SEMESTER_PATTERN);
        $manager = new SemesterCodeManager($config);
    }
    return $manager;
}

/**
 * @return string - Current Academic Year (ex: 2010-2011)
 */
function getCurrentAcademicYear()
{
    return getSemesterManager()->getAcademicYear();
}

/**
 * Get today's semester code
 */
function getTodaysBannerSemesterCode()
{
    return getSemesterManager()->getCurrentSemesterCode();
}

/**
 * Convert semester code to Banner format text
 * ex) 202710 -> "2026Fall"
 *
 * @param string $code - Semester code (ex: 202710)
 * @return string - Banner format text (ex: 2026Fall)
 * @throws Exception - If code is invalid
 */
function getBannerSemesterText($code)
{
    $manager = getSemesterManager();

    // Handle special case for "Current" - check against all possible "current" codes
    $config = new SemesterCodeConfig(__SCHOOL_SEMESTER_PATTERN);
    $pattern = $config->getPattern();

    // Build list of valid "current" codes based on pattern
    $currentCodes = [];
    foreach ($pattern as $semester => $semCode) {
        if ($semester !== 'year_offset') {
            $currentCodes[] = '9999' . $semCode;
        }
    }

    if (in_array($code, $currentCodes)) {
        return "Current";
    }

    // Parse and format the semester code
    $parsed = $manager->parseSemesterCode($code);

    // Capitalize first letter of semester name
    return $parsed['year'] . ucfirst($parsed['semester']);
}
