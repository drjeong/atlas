<?php
/**
 * Listing User Account Information
 * File: m_useraccount_ssps.php
 * Description: listing user account information
 *
 *
 *
 */
include_once 'session_handler.php';

// DB table to use
$table = 'UserAccounts';
$joinQuery = "FROM `UserAccounts` AS `UA` LEFT JOIN `Affiliations` AS `AFFILATN` ON (`UA`.`Affiliation` = `AFFILATN`.`Idx`) LEFT JOIN `Positions` AS `PSTN` ON (`UA`.`Position` = `PSTN`.`Idx`) LEFT JOIN `AccessControls` AS `ACS` ON (`UA`.`Idx`=`ACS`.`UserAccount`) LEFT JOIN `AcademicPrograms` AS `APS` ON (`APS`.`Idx`=`ACS`.`AcademicProgram`) ";

// Table's primary key
$primaryKey = '`UA`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`UA`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`UA`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`UA`.`Email`', 'dt' => 'Email', 'field' => 'Email', 'as' => 'Email'),
    array( 'db' => '`UA`.`Name`', 'dt' => 'Name', 'field' => 'Name', 'as' => 'Name'),
    array( 'db' => '`UA`.`Position`', 'dt' => 'Position', 'field' => 'Position', 'as' => 'Position'),
    array( 'db' => '`PSTN`.`Name`', 'dt' => 'PositionName', 'field' => 'PositionName', 'as' => 'PositionName'),
    array( 'db' => '`UA`.`Affiliation`', 'dt' => 'Affiliation', 'field' => 'Affiliation', 'as' => 'Affiliation'),
    array( 'db' => '`AFFILATN`.`Name`', 'dt' => 'AffiliationName', 'field' => 'AffiliationName', 'as' => 'AffiliationName'),
    array( 'db' => '`UA`.`LastLogin`', 'dt' => 'LastLogin', 'field' => 'LastLogin', 'as' => 'LastLogin'),
    array( 'db' => '`UA`.`SystemAdmin`', 'dt' => 'SystemAdmin', 'field' => 'SystemAdmin', 'as' => 'SystemAdmin'),
    array( 'db' => '`UA`.`Observer`', 'dt' => 'Observer', 'field' => 'Observer', 'as' => 'Observer'),
    array( 'db' => '`UA`.`Disabled`', 'dt' => 'Disabled', 'field' => 'Disabled', 'as' => 'Disabled'),
    array( 'db' => 'GROUP_CONCAT(`ACS`.`AcademicProgram` SEPARATOR \', \')', 'dt' => 'Cntl', 'field' => 'Cntl', 'as' => 'Cntl'),
    array( 'db' => 'GROUP_CONCAT(`APS`.`Name` SEPARATOR \', \')', 'dt' => 'CntlNames', 'field' => 'CntlNames', 'as' => 'CntlNames')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "";
$groupBy = " `UA`.`Idx` ";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy)
);

