<?php
require_once(__DIR__ . '/../php_include/dbconnection_class.php');

class StudentOutcomeAnalyzer {
    private $db;

    public function __construct(Dbconnection $dbConnection) {
        $this->db = $dbConnection;
    }

    /**
     * Get Student Outcome Analysis
     * Auto-saves to database after calculation
     *
     * @param int $abetCourseIdx
     * @param int $availableCourseIdx
     * @param int $academicProgramIdx
     * @param bool $autoSave Whether to automatically save to database (default: true)
     * @return array Analysis results
     */
    public function getAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx, $autoSave = true) {
        // Validate inputs
        if (empty($abetCourseIdx) || empty($availableCourseIdx) || empty($academicProgramIdx)) {
            throw new InvalidArgumentException('All parameters are required');
        }

        $soInfo = $this->getStudentOutcomeMeasures($abetCourseIdx, $availableCourseIdx, $academicProgramIdx);
        $studentScores = $this->getStudentScores($abetCourseIdx, $availableCourseIdx, $academicProgramIdx);

        $data = $this->calculateAnalysis($soInfo, $studentScores);

        // Auto-save to database
        if ($autoSave && !empty($data)) {
            try {
                $this->db->autocommit(FALSE);
                $this->saveMainAnalysisViaSP($data, $abetCourseIdx, $availableCourseIdx, $academicProgramIdx);
                $this->db->commit();
                $this->db->autocommit(TRUE);
            } catch (Exception $e) {
                $this->db->rollback();
                $this->db->autocommit(TRUE);
                // Log error but don't fail the analysis display
                error_log("Failed to auto-save SO analysis: " . $e->getMessage());
            }
        }

        return $data;
    }

    /**
     * Get Student Outcomes and their measures
     */
    private function getStudentOutcomeMeasures($abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        $stmt = $this->db->prepare("
            SELECT 
                STNTOUTCMS.Idx AS SOIdx,
                STNTOUTCMS.SO AS SO,
                STNTOUTCMS.Description AS Description,
                AM.Idx AS MeasureIdx,
                AM.Measure AS MeasureNumber
            FROM StudentOutcomes AS STNTOUTCMS
            INNER JOIN GeneralPerformanceIndicators AS GPIS 
                ON (GPIS.SOIdx = STNTOUTCMS.Idx AND GPIS.AcademicProgram = ?)
            INNER JOIN AssessmentMeasures AS AM 
                ON (AM.GPI = GPIS.Idx AND AM.AvailableCourseIdx = ? AND AM.AbetCourseIdx = ?)
            WHERE STNTOUTCMS.AcademicProgram = ?
            GROUP BY STNTOUTCMS.Idx, AM.Idx
            ORDER BY STNTOUTCMS.Idx, AM.Measure
        ");

        $stmt->bind_param('iiii', $academicProgramIdx, $availableCourseIdx, $abetCourseIdx, $academicProgramIdx);
        $stmt->execute();
        $results = $stmt->get_result();

        $soInfo = array();
        while ($row = $results->fetch_assoc()) {
            $soIdx = $row['SOIdx'];

            if (!isset($soInfo[$soIdx])) {
                $soInfo[$soIdx] = array(
                    'SO' => $row['SO'],
                    'Description' => $row['Description'],
                    'RequiredMeasures' => array()
                );
            }

            $soInfo[$soIdx]['RequiredMeasures'][] = $row['MeasureIdx'];
        }
        $stmt->close();

        return $soInfo;
    }

    /**
     * Get raw student scores
     */
    private function getStudentScores($abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        $stmt = $this->db->prepare("
            SELECT 
                STNTOUTCMS.Idx AS SOIdx,
                SCSHEET.StudentNo,
                SCSHEET.AssessmentMeasureIdx,
                SCSHEET.LevelOfAttainment,
                AM.Measure
            FROM AssessmentMeasures AS ASSMNTMEASURES
            INNER JOIN GeneralPerformanceIndicators AS GPIS 
                ON (GPIS.Idx = ASSMNTMEASURES.GPI AND GPIS.AcademicProgram = ?)
            INNER JOIN StudentOutcomes AS STNTOUTCMS
                ON (STNTOUTCMS.Idx = GPIS.SOIdx AND STNTOUTCMS.AcademicProgram = ?)
            INNER JOIN Scoresheet AS SCSHEET 
                ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
            INNER JOIN AssessmentMeasures AS AM
                ON (SCSHEET.AssessmentMeasureIdx = AM.Idx)
            WHERE ASSMNTMEASURES.AvailableCourseIdx = ?
              AND ASSMNTMEASURES.AbetCourseIdx = ?
            ORDER BY STNTOUTCMS.Idx, SCSHEET.StudentNo, SCSHEET.AssessmentMeasureIdx
        ");

        $stmt->bind_param('iiii', $academicProgramIdx, $academicProgramIdx, $availableCourseIdx, $abetCourseIdx);
        $stmt->execute();
        $results = $stmt->get_result();

        $studentScores = array();
        while ($row = $results->fetch_assoc()) {
            $soIdx = $row['SOIdx'];
            $studentNo = $row['StudentNo'];
            $measureIdx = $row['AssessmentMeasureIdx'];

            if (!isset($studentScores[$soIdx])) {
                $studentScores[$soIdx] = array();
            }

            if (!isset($studentScores[$soIdx][$studentNo])) {
                $studentScores[$soIdx][$studentNo] = array(
                    'measureData' => array(),
                    'measureDetails' => array()
                );
            }

            if (!isset($studentScores[$soIdx][$studentNo]['measureData'][$measureIdx])) {
                $studentScores[$soIdx][$studentNo]['measureData'][$measureIdx] = floatval($row['LevelOfAttainment']);
                $studentScores[$soIdx][$studentNo]['measureDetails'][] = array(
                    'measureIdx' => $measureIdx,
                    'measure' => $row['Measure'],
                    'score' => floatval($row['LevelOfAttainment'])
                );
            }
        }
        $stmt->close();

        return $studentScores;
    }

    /**
     * Calculate analysis from Student Outcome info and student scores
     */
    private function calculateAnalysis($soInfo, $studentScores) {
        $data = array();

        foreach ($soInfo as $soIdx => $soData) {
            $requiredMeasures = $soData['RequiredMeasures'];
            $totalMeasures = count($requiredMeasures);

            if ($totalMeasures == 0) continue;

            $validStudentAverages = array();
            $studentsAbove2 = 0;
            $studentsAbove3 = 0;
            $studentDetails = array();

            if (isset($studentScores[$soIdx])) {
                foreach ($studentScores[$soIdx] as $studentNo => $studentData) {
                    $studentMeasureData = $studentData['measureData'];
                    $studentMeasureIndices = array_keys($studentMeasureData);
                    $missingMeasures = array_diff($requiredMeasures, $studentMeasureIndices);

                    // Check for missing measures
                    if (count($missingMeasures) > 0) {
                        $studentDetails[] = array(
                            'studentNo' => $studentNo,
                            'measures' => $studentData['measureDetails'],
                            'average' => 0,
                            'included' => false,
                            'reason' => "Missing " . count($missingMeasures) . " required measure(s) for this SO"
                        );
                        continue;
                    }

                    // Check for zero scores
                    $hasZeroScore = false;
                    $zeroMeasures = array();
                    foreach ($requiredMeasures as $requiredMeasureIdx) {
                        if (isset($studentMeasureData[$requiredMeasureIdx]) && $studentMeasureData[$requiredMeasureIdx] == 0) {
                            $hasZeroScore = true;
                            foreach ($studentData['measureDetails'] as $detail) {
                                if ($detail['measureIdx'] == $requiredMeasureIdx) {
                                    $zeroMeasures[] = 'M' . $detail['measure'];
                                    break;
                                }
                            }
                        }
                    }

                    if ($hasZeroScore) {
                        $studentDetails[] = array(
                            'studentNo' => $studentNo,
                            'measures' => $studentData['measureDetails'],
                            'average' => 0,
                            'included' => false,
                            'reason' => "No submission for: " . implode(', ', $zeroMeasures)
                        );
                        continue;
                    }

                    // Calculate average
                    $scoresForAvg = array();
                    foreach ($requiredMeasures as $requiredMeasureIdx) {
                        $scoresForAvg[] = $studentMeasureData[$requiredMeasureIdx];
                    }

                    $studentAvg = array_sum($scoresForAvg) / count($scoresForAvg);
                    $validStudentAverages[] = $studentAvg;

                    if ($studentAvg >= 2.0) $studentsAbove2++;
                    if ($studentAvg >= 3.0) $studentsAbove3++;

                    $studentDetails[] = array(
                        'studentNo' => $studentNo,
                        'measures' => $studentData['measureDetails'],
                        'average' => round($studentAvg, 2),
                        'included' => true
                    );
                }
            }

            $overallAvg = count($validStudentAverages) > 0
                ? array_sum($validStudentAverages) / count($validStudentAverages)
                : 0;

            $data[] = array(
                'DT_RowId' => 'row_' . $soIdx,
                'SOIdx' => $soIdx,
                'SO' => $soData['SO'],
                'SODescription' => $soData['Description'],
                'AVG' => round($overallAvg, 2),
                'TOTAL' => count($validStudentAverages),
                'TOPFIFTY' => $studentsAbove2,
                'TOPTWENTYFIVE' => $studentsAbove3,
                'TotalMeasures' => $totalMeasures,
                'StudentDetails' => $studentDetails
            );
        }

        return $data;
    }

    /**
     * Get analysis formatted for DataTables
     */
    public function getDataTablesResponse($abetCourseIdx, $availableCourseIdx, $academicProgramIdx, $draw = 0) {
        $data = $this->getAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx);

        return array(
            "draw" => intval($draw),
            "recordsTotal" => count($data),
            "recordsFiltered" => count($data),
            "data" => $data
        );
    }

    /**
     * Save analysis results to database using stored procedure
     *
     * @param int $abetCourseIdx
     * @param int $availableCourseIdx
     * @param int $academicProgramIdx
     * @return array Result with success status and message
     */
    public function saveAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        try {
            $analysisData = $this->getAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx, false); // Don't auto-save when explicitly saving

            if (empty($analysisData)) {
                return array(
                    'success' => false,
                    'message' => 'No data to save',
                    'recordsSaved' => 0
                );
            }

            // Start transaction
            $this->db->autocommit(FALSE);

            // Save using stored procedure
            $recordsSaved = $this->saveMainAnalysisViaSP($analysisData, $abetCourseIdx, $availableCourseIdx, $academicProgramIdx);

            // Commit transaction
            $this->db->commit();
            $this->db->autocommit(TRUE);

            return array(
                'success' => true,
                'message' => 'Analysis saved successfully',
                'recordsSaved' => $recordsSaved,
                'timestamp' => date('Y-m-d H:i:s')
            );

        } catch (Exception $e) {
            // Rollback on error
            if ($this->db->vDbconnect != null) {
                $this->db->rollback();
                $this->db->autocommit(TRUE);
            }

            return array(
                'success' => false,
                'message' => 'Error saving analysis: ' . $e->getMessage(),
                'recordsSaved' => 0
            );
        }
    }

    /**
     * Save main analysis data using stored procedure
     */
    private function saveMainAnalysisViaSP($analysisData, $abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        $stmt = $this->db->prepare("
            CALL SP_SaveAnalyzedStudentOutcomes(?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $recordsSaved = 0;

        foreach ($analysisData as $soData) {
            $stmt->bind_param(
                'iiissdiii',
                $availableCourseIdx,
                $abetCourseIdx,
                $academicProgramIdx,
                $soData['SOIdx'],
                $soData['SO'],
                $soData['AVG'],
                $soData['TOTAL'],
                $soData['TOPFIFTY'],
                $soData['TOPTWENTYFIVE']
            );

            if ($stmt->execute()) {
                $recordsSaved++;
            }

            // Clear result set (important for stored procedures)
            while ($stmt->more_results()) {
                $stmt->next_result();
                if ($result = $stmt->get_result()) {
                    $result->free();
                }
            }
        }

        $stmt->close();
        return $recordsSaved;
    }
    /**
     * Retrieve saved analysis from database or force recalculation
     *
     * @param int $abetCourseIdx
     * @param int $availableCourseIdx
     * @param int $academicProgramIdx
     * @param bool $forceCalculate If true, always recalculate and save (default: true)
     * @return array Analysis data (recalculated or from database)
     */
    public function getSavedAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx, $forceCalculate = true) {
        // If forceCalculate is true, always recalculate
        if ($forceCalculate) {
            return $this->getAnalysis($abetCourseIdx, $availableCourseIdx, $academicProgramIdx, true);
        }

        // Otherwise, retrieve from database
        $stmt = $this->db->prepare("
        SELECT * FROM Analyzed_StudentOutcomes
        WHERE AvailableCourseIdx = ? 
          AND AbetCourseIdx = ? 
          AND AcademicProgramIdx = ?
        ORDER BY SOIdx
    ");

        $stmt->bind_param('iii', $availableCourseIdx, $abetCourseIdx, $academicProgramIdx);
        $stmt->execute();
        $result = $stmt->get_result();

        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = array(
                'DT_RowId' => 'row_' . $row['SOIdx'],
                'SOIdx' => $row['SOIdx'],
                'SO' => $row['SO'],
                'AVG' => floatval($row['AVG']),
                'TOTAL' => intval($row['TOTAL']),
                'TOPFIFTY' => intval($row['TOPFIFTY']),
                'TOPTWENTYFIVE' => intval($row['TOPTWENTYFIVE'])
            );
        }

        $stmt->close();

        return $data;
    }

    /**
     * Check if analysis exists for given parameters
     */
    public function analysisExists($abetCourseIdx, $availableCourseIdx, $academicProgramIdx) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as count FROM Analyzed_StudentOutcomes
            WHERE AvailableCourseIdx = ? 
              AND AbetCourseIdx = ? 
              AND AcademicProgramIdx = ?
        ");

        $stmt->bind_param('iii', $availableCourseIdx, $abetCourseIdx, $academicProgramIdx);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();

        return $row['count'] > 0;
    }
}