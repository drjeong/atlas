<?php
/**
 * Academic Semester information selection
 * Description: Listing the academic year information.
 * Author: Dong Hyun Jeong
 *
 * 11/26/2024 - initial version created
 *
 */

function AcademicSemesterSelection(&$semester)  // Note the & symbol
{
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    require_once(__DIR__ . '/php_include/semester_helpers.php');

    $content = "";
    $DBCONNECTION = new Dbconnection();
    $Query = "SELECT DISTINCT(`semester`) AS `SEM` FROM `AVCourses` ORDER BY `Semester` DESC";
    $DBCONNECTION->sendquery($Query);

    // Fetch all semesters and check if the provided semester exists
    $semesters = [];
    $semesterExists = false;
    while ($row = $DBCONNECTION->fetch_assoc()) {
        $semesters[] = $row["SEM"];
        if ($semester == $row["SEM"]) {
            $semesterExists = true;
        }
    }

    // Change $semester if it doesn't exist
    if (!$semesterExists && $semester != 'all') {
        $semester = 'all'; // This will modify the original variable
    }

    $content .='<form name="academicyear" style="font-size:9pt;">';
    $content .='<div class="input-group" style="width:100%">';
    $content .='<span class="input-group-addon" style="width:230px;">BY ACADEMIC YEAR: </span>';
    $content .='<select name="_SM" id="_SM" class="input-sm form-control" style="width:200px;">';
    $content .='<option value="all"' . ($semester == 'all' ? ' selected' : '') . '>ALL</option>';

    foreach ($semesters as $sem) {
        $content .= '<option value="' . $sem . '"';
        if ($semester == $sem) {
            $content .= ' selected';
        }
        $content .= '>' . getBannerSemesterText($sem) . '</option>';
    }

    $content .='</select>';
    $content .='</div>';
    $content .='</form>';

    unset($DBCONNECTION);

    return $content;
}

function AcademicSemesterSelectionFrom2To()
{
    require_once(__DIR__ . '/php_include/semester_helpers.php');

    if (array_key_exists('_SMF', $_POST)) {
        $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM'] = ltrim(rtrim($_POST['_SMF']));
    }

    if (array_key_exists('_SMT', $_POST)) {
        $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO'] = ltrim(rtrim($_POST['_SMT']));
    }

    $content = "";
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();
    $Query = "SELECT DISTINCT(`semester`) AS `SEM` FROM `AVCourses` ORDER BY `Semester` DESC";
    $DBCONNECTION->sendquery($Query);

    $semesters = array();
    while ($row = $DBCONNECTION->fetch_assoc()) {
        $semesters[] = $row["SEM"];
    }

    // Set defaults if not provided
    if (!isset($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM']) || empty($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM'])) {
        if (!empty($semesters)) {
            $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM'] = $semesters[0]; // Most recent semester
        }
    }

    if (!isset($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO']) || empty($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO'])) {
        if (!empty($semesters)) {
            $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO'] = $semesters[0]; // Most recent semester
        }
    }

    $content .= '<form name="academicyear" method="post" style="font-size:9pt;">';
    $content .= '<div class="input-group" style="width:100%">';

    // FROM semester dropdown
    $content .= '<span class="input-group-addon" style="width:115px;">FROM: </span>';
    $content .= '<select name="_SMF" id="_SMF" class="input-sm form-control" style="width:150px;" onchange="this.form.submit();">';
    foreach ($semesters as $sem) {
        $content .= '<option value="' . htmlspecialchars($sem, ENT_QUOTES, 'UTF-8') . '"';
        if (isset($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM']) && $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_FROM'] == $sem) {
            $content .= ' selected';
        }
        $content .= '>' . htmlspecialchars(getBannerSemesterText($sem), ENT_QUOTES, 'UTF-8') . '</option>';
    }
    $content .= '</select>';

    // TO semester dropdown
    $content .= '<span class="input-group-addon" style="width:115px; margin-left:10px;">TO: </span>';
    $content .= '<select name="_SMT" id="_SMT" class="input-sm form-control" style="width:150px;" onchange="this.form.submit();">';
    foreach ($semesters as $sem) {
        $content .= '<option value="' . htmlspecialchars($sem, ENT_QUOTES, 'UTF-8') . '"';
        if (isset($_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO']) && $_SESSION['ATLAS_FACULTY_WORKLOAD_SEMESTER_TO'] == $sem) {
            $content .= ' selected';
        }
        $content .= '>' . htmlspecialchars(getBannerSemesterText($sem), ENT_QUOTES, 'UTF-8') . '</option>';
    }
    $content .= '</select>';

    $content .= '</div>';
    $content .= '</form>';

    unset($DBCONNECTION);

    return $content;
}