<?php
/**
 * PDF Viewer
 * Description: Create a PDF file and download it automatically.
 *
 * 02/04/2025 - add handling instructional materials and course assessment materials
 *
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';

$PDF = '';
$PDFTYPE = '';
$AcademicYearInfo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the raw POST data
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    // Extract parameters
    $PDF = $data['pdf'] ?? null;
    $PDFTYPE = $data['cn'] ?? null;
    $AcademicYearInfo = $data['ayinfo'] ?? null;
}
else {
    $PDF = isset($_GET['pdf']) ? trim($_GET['pdf']) : '';
    $PDFTYPE = isset($_GET['cn']) ? trim($_GET['cn']) : '';
    $AcademicYearInfo = isset($_GET['ayinfo']) ? trim($_GET['ayinfo']) : '';
}

require_once(__DIR__ . '/../config.php');

$PDF_TYPES = [
    '293428384' => __DIRECTORY_ABETSYLLABI__,
    '253438384' => __DIRECTORY_COURSEBI__,
    '213432394' => __DIRECTORY_ABETASSESSMENTS__,
    '213432395' => __DIRECTORY_ABETASSESSMENTS__,   // student samples for each ABET assessment measure
    '223423233' => __DIRECTORY_INSTRUCTIONAL_MATERIALS__,
    '234234234' => __DIRECTORY_COURSEASSIGNMENT_SAMPLES__,
    '2332342321' => __DIRECTORY_ABETASSESSMENTSURVEY__
];

$PDFPATH = $PDF_TYPES[$PDFTYPE] ?? '';

// Ensure that the PDF path exists
if ($PDFPATH === '' || !is_dir($PDFPATH)) {
    exit; // Error: PDF directory doesn't exist
}

// Validate and sanitize the PDF filename and AcademicYearInfo to avoid path traversal
$PDF = basename($PDF); // Remove directory traversal, only allow the file name
$AcademicYearInfo = basename($AcademicYearInfo); // Ensure no path traversal in academic year info

// Construct the full file path
if ($PDFTYPE == '213432395') {
    $FileNamePath = $PDFPATH . '/' . $AcademicYearInfo . '/studentsamples/' . $PDF;
} else {
    $FileNamePath = $PDFPATH . '/' . $AcademicYearInfo . '/' . $PDF;
}

// Check if the file exists before proceeding
if (!file_exists($FileNamePath)) {
    exit; // Error: File does not exist
}

// Set the appropriate headers for downloading the PDF
header('Content-Description: File Transfer');
header("Content-type: application/pdf");
header('Content-Disposition: attachment; filename="' . basename($FileNamePath) . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header("Content-Length: " . filesize($FileNamePath));

// Send the file to the browser
readfile($FileNamePath);