<?php
/**
 * Abet courses
 * Description: Listing abet courses
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 * 04/12/2021 - Change the title "GPI" to "PI"
 * 03/09/2023 - Support allocating course level information
 * 10/05/2023 - Auto update academic year in dialog window (add abet courses)
 * 03/28/2024 - Add searching boxes on table header
 */

include('checker_programdirector.php');
include('header.php');
?>

<?php

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection();

?>

<script src="js/datatable-utils-search.min.js"></script>
<script src="js/datatable-utils-rowselector.min.js?v=0.0.1"></script>

<script src="js/api_pdfviewer.min.js?v=0.0.1"></script>
<script src="/toolbox/ckeditor_4.4.5_full/ckeditor.js"></script>

<script type="text/javascript">

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        NO_SO_DATA: '0x00000100',
        NO_PI_DATA: '0x00000200',
        SAME_ITEM_EXIST: '0x00200011',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
        DATA_COLLECTED_ALREADY: '0x00310001'
    };

    async function AsyncGetOptions(option = 1) {
        try {
            const rawResult = await async_commons.makeApiCall(`api_getoptions.php?sel=ac&op=${option}`, {});
            const result = JSON.parse(rawResult);

            if (result.status === 'ERROR') {
                throw new Error(result.message);
            }

            return result.data;
        } catch (error) {
            await async_commons.handleError(error);
            throw error;
        }
    }


    var DataTable_AbetCourseList = null;
    var DataTable_CoursesList = null;

    //-----------------------------------------
    function AssignLevelToSelectedCourses() {
        // Check if DataTable is empty
        if (DataTable_AbetCourseList.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses
        const selected = DataTable_AbetCourseList.rows({ selected: true }).data();
        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        // Create pipe-separated string of paired course data (Idx:AcademicYear)
        const coursePairs = selected
            .toArray()
            .map(course => `${encodeURIComponent(course.Idx)}:${encodeURIComponent(course.AcademicYear)}`)
            .join('|');

        // Assign level
        AssignLevel(coursePairs);
    }

    function AssignLevel(coursePairs) {
        let DataTable_SOList = null;
        const formContent =
            `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST">
                <div class="input-group" style="width:100%">
                    <span class="input-group-addon" style="width:230px;">Course Level<span style="color:red">*</span></span>
                    <select name="_Level" id="_Level" class="input-sm form-control">
                        <option value=""></option>
                        <option value="1">Introductory</option>
                        <option value="2">Practice</option>
                        <option value="3">Mastery</option>
                    </select>
                </div>
            </div>
        </form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN COURSE LEVEL</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');

                        if (!popupForm._Level.value) {
                            Swal.fire({
                                title: "ERROR",
                                text: "Please select a course level!",
                                icon: "error"
                            });
                            return false;
                        }

                        AssignLevel_Perform(coursePairs, popupForm._Level.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        }).find('.modal-dialog').css({
            'margin-top': function (){
                let w = $( window ).height();
                let b = $(this).height();
                let h = (w-b)*0.1;
                return h+"px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"
        }).find('.modal-header').css({
            'cursor': 'move'
        });
    }

    async function AssignLevel_Perform(coursePairs, _Level) {
        try {
            const result = await async_commons.makeApiCall('dept_abetcourses_assign_level_ajax.php', {
                coursePairs: coursePairs,
                level: _Level
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Level information is assigned!');
                    await async_commons.unselectRowsInDataTable();
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function RemoveAbetCourse(Idx, AcademicYearInfo, Subject, Num, Title, Syllabus) {
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted content (<span style="color:red">${AcademicYearInfo} ${Subject} ${Num} ${Title}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('dept_abetcourses_remove_ajax.php', {
                id: Idx,
                syllabus: Syllabus,
                ayinfo: AcademicYearInfo
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected course has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected course cannot be deleted because it has course assessments. Please remove them first.');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function AddAbetCourses_Perform(_AY, _SELECTEDCOURSES) {
        try {
            const result = await async_commons.makeApiCall('dept_abetcourses_add_ajax.php', {
                ay: _AY,
                crses: _SELECTEDCOURSES
            });

            const code = result.trim();
            await async_commons.reloadDataTable();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.showSuccessMessage('ADDED', 'Abet courses are added');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
            // Hide spinner and show notification
            hideFullPageSpinner();
        }
    }

    function AddCourses2BeAssessed()
    {
        const [selectedAcademicYearValue, selectedAcademicYearText] = async_commons.getSelectedAcademicYear();
        if (selectedAcademicYearValue === '') {
            return;
        }
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>
                    <input type="hidden" name="_AY" id="_AY" class="input-sm form-control" value="${selectedAcademicYearValue}" readonly>
                    <input type="text" name="_AYTXT" id="_AYTXT" class="input-sm form-control" value="${selectedAcademicYearText}" readonly>
                </div>
                <div class="input-group" style="width:100%; margin-top:10px;">
                    <span class="input-group-addon" style="width:230px;">Bulk Select Courses</span>
                    <input type="text" name="bulkCourseInput" id="bulkCourseInput" class="input-sm form-control"
                        placeholder="Enter courses (e.g., CCEN 101, ELEC 225, ELEC 226, APCT 231)">
                    <span class="input-group-btn">
                        <button type="button" class="btn btn-primary btn-sm" id="bulkSelectBtn">
                            <span class="glyphicon glyphicon-check"></span> Select
                        </button>
                    </span>
                </div>
                <table id="selectedcouselist" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th class="no-sort" style="width:3px"></th>
                        <th>SEMESTER</th>
                        <th>CRN</th>
                        <th>SUBJECT</th>
                        <th>NUM</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>INSTRUCTOR(S)</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th>SEMESTER</th>
                        <th>CRN</th>
                        <th>SUBJECT</th>
                        <th>NUM</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>INSTRUCTOR(S)</th>
                    </tr>
                    </tfoot>
                </table>
            </div></form>`;

        const rowSelector = new DataTableRowSelector('selectedcouselist', {
            counterId: 'selectedCount',
            toggleButtonId: 'toggleSelected',
            itemName: 'course'
        });

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD COURSES TO BE ASSESSED</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ADD",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');

                        let selected = rowSelector.getSelectedData();
                        if (!selected.length) {
                            Swal.fire({title: "ERROR", text: "You need to check at least one course!!", icon: "error"});
                            return false;
                        }
                        const selectedCourses = selected.map(course => course.AVCIdx+'_'+course.CMCIdx+'_'+course.AbetSyllabusIdx).join('|'); // separated by '|'
                        AddAbetCourses_Perform(popupForm._AY.value, selectedCourses);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        });
        // console.log(`ssps/dept_abetcourses_courselist_ssps.php?_AY=${selectedAcademicYearValue}`);

        DataTable_CoursesList = $("#selectedcouselist").DataTable({
            processing: true,
            serverSide: true,
            iDisplayLength: 8,
            lengthChange: false,
            select: {
                style: 'multi',
                selector: 'td'
            },
            dom: `t<"row"<"col-sm-6"<"filterControls">><"col-sm-6"p>>`, // add row selector filter controls at the bottom
            initComplete: function() {
                // Initialize the row selector
                rowSelector.init(DataTable_CoursesList);

                // Setup bulk select functionality
                $('#bulkSelectBtn').on('click', function() {
                    const input = $('#bulkCourseInput').val().trim();
                    if (!input) {
                        Swal.fire({
                            title: "Warning",
                            text: "Please enter course codes to select",
                            icon: "warning"
                        });
                        return;
                    }

                    // Parse the input - supports formats like "CCEN 101, ELEC 225" or "CCEN101,ELEC225"
                    const courseEntries = input.split(',').map(entry => entry.trim());
                    const coursesToSelect = [];

                    courseEntries.forEach(entry => {
                        // Match patterns like "CCEN 101" or "CCEN101"
                        const match = entry.match(/^([A-Z]+)\s*(\d+)$/i);
                        if (match) {
                            coursesToSelect.push({
                                subject: match[1].toUpperCase(),
                                num: match[2]
                            });
                        }
                    });

                    if (coursesToSelect.length === 0) {
                        Swal.fire({
                            title: "Error",
                            text: "No valid course codes found. Use format: SUBJ NUM (e.g., CCEN 101, ELEC 225)",
                            icon: "error"
                        });
                        return;
                    }

                    // Select matching rows
                    let selectedCount = 0;
                    DataTable_CoursesList.rows().every(function() {
                        const rowData = this.data();
                        const match = coursesToSelect.some(course =>
                            course.subject === rowData.Subject && course.num === rowData.Num
                        );

                        if (match) {
                            this.select();
                            selectedCount++;
                        }
                    });

                    rowSelector.updateSelectedCount();

                    if (selectedCount > 0) {
                        Swal.fire({
                            title: "Success",
                            text: `Selected ${selectedCount} course(s)`,
                            icon: "success",
                            timer: 1500,
                            showConfirmButton: false
                        });
                    } else {
                        Swal.fire({
                            title: "Warning",
                            text: "No matching courses found in the table",
                            icon: "warning"
                        });
                    }
                });
            },
            ajax: `ssps/dept_abetcourses_courselist_ssps.php?_AY=${selectedAcademicYearValue}`,
            order: [[ 1, 'asc' ], [ 2, 'asc' ]],
            fnDrawCallback: function() {
                $('#selectedcouselist tr td:nth-child(1)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(2)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(3)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(4)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(5)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(7)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(9)').css('text-align', 'center');

                $('#selectedcouselist tr td:nth-child(6)').css('width', '150px');
                $('#selectedcouselist tr td:nth-child(8)').css('width', '100px');

                rowSelector.updateSelectedCount();
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function ( data, type, full, meta ) {
                        return '';
                    }
                },
                { data: 'SemesterTxt' },
                { data: 'CRN' },
                { data: 'Subject' },
                { data: 'Num' },
                { data: 'Title' },
                { data: 'Credits' },
                { data: 'Instructor' }
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets  : 'no-sort',
                    orderable: false,
                }
            ]
        });

        // Initialize the column search functionality
        new DataTableSearch('#selectedcouselist', DataTable_CoursesList, ShowResetBtn=false);
    }

    async function CheckIfMasterSyllabusExist(_IDX, _AY, _SUBJECT, _NUM, _AP) {
        if (_IDX === '' || _AY === '' || _SUBJECT === '' || _NUM === '' || _AP === '') {
            return {
                success: false,
                data: null
            };
        }

        try {
            const rawResult = await async_commons.makeApiCall('dept_abetcourses_checkabetsyllabus_ajax.php', {
                idx: _IDX,
                ay: _AY,
                sub: _SUBJECT,
                num: _NUM,
                ap: _AP
            });

            const result = JSON.parse(rawResult);
            if (result.status === 'ERROR') {
                throw new Error(result.message);
            }

            return {
                success: true,
                data: result.data
            };

        } catch (error) {
            return {
                success: false,
                data: null
            };
        }
    }

    function EvaluateClassRoster(avcIdx, enrollment, crsinfo)
    {
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <style>
                .dropped-student {
                    background-color: #ffebee !important;
                    color: #999 !important;
                    text-decoration: line-through;
                }
                .dropped-student:hover {
                    background-color: #ffcdd2 !important;
                }
            </style>
            <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                <table id="classrosterlist" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th class="no-sort" style="width:40px;"></th>
                        <th style="width:50px;">NO.</th>
                        <th>STUDENT NAME</th>
                        <th>MAJOR</th>
                        <th>ACADEMIC PROGRAM</th>
                        <th>DEGREE</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th>NO.</th>
                        <th>STUDENT NAME</th>
                        <th>MAJOR</th>
                        <th>ACADEMIC PROGRAM</th>
                        <th>DEGREE</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </form>`;

        rowSelector_DataTable_ClassRosterList = new DataTableRowSelector('classrosterlist', {
            counterId: 'selectedCount',
            toggleButtonId: 'toggleSelected',
            itemName: 'student'
        });

        createModalDialog({
            className: "dialogWidth60p",
            title: '<div style="text-align: left;">' +
                '<span class="glyphicon glyphicon-education" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;' +
                '<span style="font-size:16pt;font-weight: bold;">CLASS ROSTER</span><br>' +
                '<span style="font-size:13pt;color:#666;font-weight:normal;margin-top:5px;display:inline-block;margin-left:30px;">' + crsinfo + ' &bull; ' + enrollment + ' Students</span>' +
                '</div>',
            message: formContent,
            buttons: {
                close: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CLOSE",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal', function(){
        });

        DataTable_ClassRosterList = $("#classrosterlist").DataTable({
            processing: true,
            serverSide: false,
            iDisplayLength: 10,
            lengthChange: false,
            select: {
                style: 'multi',
                selector: 'td'
            },
            dom: `<"row"<"col-sm-6"<"filterControls">><"col-sm-6"<"pull-right"B>>>t<"row"<"col-sm-6"><"col-sm-6"p>>`,
            initComplete: function() {
                rowSelector_DataTable_ClassRosterList.init(DataTable_ClassRosterList);
            },
            ajax: `ssps/m_avcourses_classroster_ssps.php?_AVCIDX=${avcIdx}`,
            order: [[ 1, 'asc' ]],
            fnDrawCallback: function() {
                $('#classrosterlist tr td:nth-child(1)').css('text-align', 'center');
                $('#classrosterlist tr td:nth-child(2)').css('text-align', 'center');

                rowSelector_DataTable_ClassRosterList.updateSelectedCount();
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function ( data, type, full, meta ) {
                        return '';
                    }
                },
                { data: 'StudentNo' },
                {
                    data: 'StudentName',
                    render: function(data, type, full, meta) {
                        if (type === 'export') {
                            return full.IsDropped === 1 ? data + ' (DROPPED)' : data;
                        }
                        if (full.IsDropped === 1) {
                            return data + ' <span class="label label-danger">DROPPED</span>';
                        }
                        return data;
                    }
                },
                { data: 'StudentMajor' },
                { data: 'AcademicProgramName' },
                { data: 'Degree' }
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets: 'no-sort',
                    orderable: false,
                }
            ],
            buttons: [
                {
                    extend: 'excelHtml5',
                    title: `CLASS ROSTER ${crsinfo}`,
                    text: '<i class="fa fa-file-excel-o"></i> Export to Excel',
                    className: 'btn btn-success btn-lg',  // Large buttons
                    exportOptions: {
                        columns: [ 1, 2, 3, 4, 5 ],
                        modifier: {
                            selected: null
                        }
                    }
                },
                {
                    extend: 'csvHtml5',
                    title: `CLASS ROSTER ${crsinfo}`,
                    text: '<i class="fa fa-file-text-o"></i> Export to CSV',
                    className: 'btn btn-info btn-lg',  // Large buttons
                    exportOptions: {
                        columns: [ 1, 2, 3, 4, 5 ],
                        modifier: {
                            selected: null
                        }
                    }
                }
            ],
            createdRow: function(row, data, dataIndex) {
                if (data.IsDropped === 1) {
                    $(row).addClass('dropped-student');
                }
            }
        });

        new DataTableSearch('#classrosterlist', DataTable_ClassRosterList, ShowResetBtn=false);
    }

    async function UpdateMasterSyllabus() {

        // Check if DataTable is empty
        if (DataTable_AbetCourseList.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses and convert to array
        const selected = DataTable_AbetCourseList.rows({ selected: true }).data().toArray();

        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        // Show confirmation dialog
        const confirmation = await Swal.fire({
            title: 'Confirm Update',
            html: `
            <p>You have selected <strong>${selected.length}</strong> course(s).</p>
            <p style="margin-top: 10px;">Do you want to update the syllabus for all selected courses by checking the existing Master course syllabus?</p>
        `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, Update All',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            reverseButtons: true
        });

        // If user cancels, exit
        if (!confirmation.isConfirmed) {
            return;
        }

        const totalCourses = selected.length;
        let processedCourses = 0;
        let successCount = 0;
        let errorCount = 0;
        const errorDetails = [];

        // Show progress dialog
        Swal.fire({
            title: 'Updating Master Syllabus',
            html: `
            <div>
                <p>Processing course <span id="current-course">0</span> of ${totalCourses}</p>
                <div style="width: 100%; background-color: #e0e0e0; border-radius: 10px; margin-top: 10px;">
                    <div id="progress-bar" style="width: 0%; height: 30px; background-color: #4caf50; border-radius: 10px; transition: width 0.3s;"></div>
                </div>
                <p id="progress-percent" style="margin-top: 10px; font-weight: bold;">0%</p>
                <p id="current-status" style="margin-top: 5px; font-size: 0.9em; color: #666;"></p>
            </div>
        `,
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        // Helper function to safely update DOM elements
        function updateProgress(processed, total, status = '') {
            const progressPercent = Math.round((processed / total) * 100);

            const currentCourseEl = document.getElementById('current-course');
            const progressBarEl = document.getElementById('progress-bar');
            const progressPercentEl = document.getElementById('progress-percent');
            const statusEl = document.getElementById('current-status');

            if (currentCourseEl) currentCourseEl.textContent = processed;
            if (progressBarEl) progressBarEl.style.width = progressPercent + '%';
            if (progressPercentEl) progressPercentEl.textContent = progressPercent + '%';
            if (statusEl && status) statusEl.textContent = status;
        }

        // Update Syllabus for each selected course sequentially
        for (let i = 0; i < selected.length; i++) {
            const item = selected[i];

            if (item.Idx) {
                const _IDX = item.Idx;
                const _AYINFO = item.AcademicYearInfo;
                const _AY = item.AcademicYear;
                const _SUBJECT = item.Subject;
                const _NUM = item.Num;
                const _TITLE = item.Title;
                const _DEGREE = item.Degree;
                const _AP = item.AcademicProgram;

                // Update status
                updateProgress(processedCourses, totalCourses, `Processing: ${_SUBJECT} ${_NUM}`);

                try {
                    const checkResult = await CheckIfMasterSyllabusExist(_IDX, _AY, _SUBJECT, _NUM, _AP);

                    if (checkResult && checkResult.success) {
                        // Call with silent mode = true
                        const uploadResult = await UploadAutoMasterSyllabusProcess(
                            _IDX, _AYINFO, _AY, _SUBJECT, _NUM, _TITLE, _DEGREE, _AP,
                            checkResult.data,
                            true  // Silent mode
                        );

                        if (uploadResult && uploadResult.success) {
                            successCount++;
                        } else {
                            errorCount++;
                            errorDetails.push(`${_SUBJECT} ${_NUM}: ${uploadResult?.error || 'Upload failed'}`);
                        }
                    } else {
                        errorCount++;
                        errorDetails.push(`${_SUBJECT} ${_NUM}: Syllabus not found`);
                    }
                } catch (error) {
                    console.error(`Error processing course ${_SUBJECT} ${_NUM}:`, error);
                    errorCount++;
                    errorDetails.push(`${_SUBJECT} ${_NUM}: ${error.message || 'Unknown error'}`);
                }

                // Update progress
                processedCourses++;
                updateProgress(processedCourses, totalCourses, `Completed: ${_SUBJECT} ${_NUM}`);

                // Small delay to ensure DOM updates
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }

        // Reload DataTable once after all updates
        await async_commons.reloadDataTable();

        // Show completion message with details
        let errorDetailsHtml = '';
        if (errorCount > 0 && errorDetails.length > 0) {
            errorDetailsHtml = `
            <div style="margin-top: 15px; text-align: left; max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                <strong>Error Details:</strong>
                <ul style="margin: 5px 0; padding-left: 20px;">
                    ${errorDetails.map(detail => `<li>${detail}</li>`).join('')}
                </ul>
            </div>
        `;
        }

        await Swal.fire({
            title: 'Complete!',
            html: `
            <p><strong>Total Processed:</strong> ${processedCourses}</p>
            <p style="color: #4caf50;"><strong>Success:</strong> ${successCount}</p>
            ${errorCount > 0 ? `<p style="color: #f44336;"><strong>Errors:</strong> ${errorCount}</p>` : ''}
            ${errorDetailsHtml}
        `,
            icon: errorCount > 0 ? 'warning' : 'success',
            confirmButtonText: 'OK',
            width: errorCount > 0 ? '600px' : '400px'
        });
    }

    async function UploadMasterSyllabus(_DIALOG_TITLE, _IDX, _AYINFO, _AY, _SUBJECT, _NUM, _TITLE, _DEGREE, _AP) {
        try {
            const result = await CheckIfMasterSyllabusExist(_IDX, _AY, _SUBJECT, _NUM, _AP);

            if (result.success) {
                // Use the new three-button dialog
                const response = await async_commons.showThreeButtonDialog(
                    `Master syllabus has been found on the system, do you want it to be uploaded automatically?`,
                    {
                        title: `${_DIALOG_TITLE}`,
                        confirmButtonText: 'Yes, upload it for me!',
                        denyButtonText: 'No, I will upload it myself!',
                        cancelButtonText: 'Cancel'
                    }
                );

                if (response.isConfirmed) {
                    // User clicked "Yes, upload it for me!"
                    await UploadAutoMasterSyllabusProcess(_IDX, _AYINFO, _AY, _SUBJECT, _NUM, _TITLE, _DEGREE, _AP, result.data);
                } else if (response.isDenied) {
                    // User clicked "No, I will upload it myself!"
                    await UploadManualMasterSyllabusProcess(_DIALOG_TITLE, _IDX, _AYINFO, _AY, _SUBJECT, _NUM, _TITLE, _DEGREE, _AP);
                }
                // else: Cancel - do nothing

                return;
            }

            // Syllabus not found - manual upload
            await UploadManualMasterSyllabusProcess(_DIALOG_TITLE, _IDX, _AYINFO, _AY, _SUBJECT, _NUM, _TITLE, _DEGREE, _AP);

        } catch (error) {
            console.error("Error in UploadAbetSyllabus:", error);
            await async_commons.handleError(error, 'Failed to upload master syllabus');
        }
    }

    async function UploadAutoMasterSyllabusProcess(_IDX="", _AYINFO="", _AY="", _SUBJECT="", _NUM="", _TITLE="", _DEGREE="", _AP="", _SYLLABUS="", _SILENT=false) {
        try {
            const result = await async_commons.makeApiCall('dept_abetcourses_syllabusadd_ajax.php', {
                idx: _IDX,
                ay: _AY,
                sub: _SUBJECT,
                num: _NUM,
                ap: _AP,
                syllabus: _SYLLABUS
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    if (!_SILENT) {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('ADDED', 'Syllabus is added successfully!');
                    }
                    return { success: true, code: code };
                }
                default: {
                    if (!_SILENT) {
                        throw new Error('Unexpected server response');
                    }
                    return { success: false, code: code, error: 'Unexpected server response' };
                }
            }
        } catch (error) {
            if (!_SILENT) {
                await async_commons.handleError(error);
            }
            return { success: false, error: error.message || error };
        }
    }

    function UploadManualMasterSyllabusProcess(_DIALOG_TITLE, _IDX="", _AYINFO="", _AY="", _SUBJECT="", _NUM="", _TITLE="", _DEGREE="", _AP="") {
        const formContent =
            `<form enctype="multipart/form-data" name="popupfrm" id="popupfrm">
             <input type="hidden" name="_IDX" size="30" value="${_IDX}">
             <input type="hidden" name="_AYINFO" size="30" value="${_AYINFO}">
             <input type="hidden" name="_AY" size="30" value="${_AY}">
             <input type="hidden" name="_AP" size="30" value="${_AP}">
             <input type="hidden" name="_DEGREE" size="30" value="${_DEGREE}">
             <input type="hidden" name="_SUBJECT" size="30" value="${_SUBJECT}">
             <input type="hidden" name="_NUM" size="30" value="${_NUM}">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2"><div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">COURSE INFO: ${_AYINFO} ${_SUBJECT} ${_NUM} ${_TITLE} </span>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Syllabus<span style="color:red">* (PDF only, MAX: 2MB)</span></span>
              <input type="file" name="_FILE" id="_FILE" class="input-sm form-control" value="" placeholder="Select Syllabus File" accept=".pdf" onchange="FileSizeValidation('_FILE')" required>
              </div>
             </div></td></tr>
             </table>
            </form>`;

        createModalDialog({
            title: `<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">${_DIALOG_TITLE} MASTER SYLLABUS</span>`,
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> UPLOAD",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');

                        if (popupForm._FILE.files.length === 0)
                        {
                            popupForm._FILE.focus();
                            Swal.fire({title:"ERROR", text: "File is not selected!!", icon:"error"});
                            return false;
                        }
                        if (!FileSizeValidation('_FILE')) return false;
                        UploadManualMasterSyllabusProcess_Perform();
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_FILE").focus();
        });
    }

    async function UploadManualMasterSyllabusProcess_Perform() {
        try {
            // Show the full page spinner
            showFullPageSpinner();

            const formData = new FormData(document.forms.namedItem("popupfrm"));
            const response = await fetch("dept_abetcourses_uploadsyllabus_ajax.php", {
                method: 'POST',
                body: formData
            });
            // Hide spinner and show notification
            hideFullPageSpinner();

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.text();
            const code = result.trim();

            switch (code) {
                case "0x11111111": {
                    await DataTable_AbetCourseList.ajax.reload(null, false);
                    await Swal.fire({
                        icon: 'success',
                        title: "UPLOADED",
                        text: "Master syllabus has been uploaded!",
                        timer: 2000
                    });
                    break;
                }
                case "0x00251400": {
                    await Swal.fire({
                        title: "ERROR",
                        text: "The file uploaded exceeds the limits (2MB)!",
                        icon: "error"
                    });
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await Swal.fire({
                title: "ERROR",
                text: "Unexpected error found. Please contact the system administrator!",
                icon: "error"
            });
        } finally {
        }
    }

    async function removeSyllabus(Idx, AcademicYearInfo, AbetSyllabus) {
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted master syllabus cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('dept_abetcourses_removeabetsyllabus_ajax.php', {
                idx: Idx,
                ayinfo: AcademicYearInfo,
                abetsyllabus: AbetSyllabus
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected master syllabus has been deleted!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    // ----------------------------------------------------------------------------------------------

    function toggleOtherInput(selectElement) {
        const otherInputDiv = document.getElementById('otherInputDiv');
        const otherInput = document.getElementById('_ReqOther');

        if (selectElement.value === 'Other') {
            otherInputDiv.style.display = 'flex';
            otherInput.required = true;
            otherInput.focus();
        } else {
            otherInputDiv.style.display = 'none';
            otherInput.required = false;
            otherInput.value = '';
        }
    }

    function ValidateItems(popupForm)
    {
        if (popupForm._Req.value.isEmpty())
        {
            popupForm._Req.focus();
            Swal.fire({title:"ERROR", text: "Requirement is not selected!!", icon:"error"});

            return false;
        }
        else if (popupForm._Req.value === 'Other')
        {
            if (popupForm._ReqOther.value.isEmpty()) {
                popupForm._ReqOther.focus();
                Swal.fire({title:"ERROR", text: "Requirement is not entered!!", icon:"error"});
                return false;
            }
        }
        return true;
    }

    function AssignReqToSelectedCourses() {
        // Check if DataTable is empty
        if (DataTable_AbetCourseList.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses
        const selected = DataTable_AbetCourseList.rows({ selected: true }).data();
        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        const selectedArray = selected.toArray();

        // Create pipe-separated string of course IDs
        const CourseIdxs = selectedArray
            .map(course => encodeURIComponent(course.Idx))
            .join('|');

        const CourseYears = selectedArray
            .map(course => encodeURIComponent(course.AcademicYear))
            .join('|');

       // academic year - proceed directly
        AssignRequirement(CourseIdxs, CourseYears);
    }

    function AssignRequirement(CourseIdxs, AcademicYears) {
        let DataTable_SOList = null;
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST">
                <div class="input-group" style="width:100%">
                    <span class="input-group-addon" style="width:230px;">Course Requirement<span style="color:red">*</span></span>
                    <select name="_Req" id="_Req" class="input-sm form-control" onchange="toggleOtherInput(this)">
                        <option value=""></option>
                        <option value="Core">Core</option>
                        <option value="Elective">Elective</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div id="otherInputDiv" class="input-group" style="width:100%; display:none; margin-top:10px;">
                    <span class="input-group-addon" style="width:230px;">Enter the Other Requirement:</span>
                    <input type="text" name="_ReqOther" id="_ReqOther" class="input-sm form-control">
                </div>
            </div>
        </form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN COURSE REQUIREMENT</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');
                        if (!ValidateItems(popupForm)) return false;

                        const requirement = (popupForm._Req.value !== 'Other') ? popupForm._Req.value : popupForm._ReqOther.value;

                        AssignRequirement_Perform(CourseIdxs, AcademicYears, requirement);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        }).find('.modal-dialog').css({
            'margin-top': function (){
                let w = $( window ).height();
                let b = $(this).height();
                let h = (w-b)*0.1;
                return h+"px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"
        }).find('.modal-header').css({
            'cursor': 'move'
        });
    }

    async function AssignRequirement_Perform(CourseIdxs, _AYs, _Req) {
        try {
            const result = await async_commons.makeApiCall('dept_abetcourses_assign_requirement_ajax.php', {
                ays: _AYs,
                req: _Req,
                abetcrs: CourseIdxs
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Requirement information is assigned!');
                    await async_commons.unselectRowsInDataTable();
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { // available only to the people who have access controls to programs
?>

    function AssignSOs(AbetCourseIdx, AcademicYear, AcademicYearInfo, SOIdxes)
    {
        const formContent = `
            <form name="popupfrm" id="popupfrm" onsubmit="return false;">
                <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                    <div class="input-group" style="width:100%">
                        <span class="input-group-addon" style="width:230px;">
                            Target Academic Year<span style="color:red">*</span>
                        </span>
                        <input type="text"
                               name="_AY"
                               id="_AY"
                               class="input-sm form-control"
                               value="${AcademicYearInfo}"
                               disabled>
                    </div>
                    <div class="input-group" style="width:100%; margin-top:10px;">
                        <span class="input-group-addon" style="width:230px;">Auto Select SOs</span>
                        <input type="text" name="_AutoSelectSOs" id="_AutoSelectSOs" class="input-sm form-control" placeholder="e.g., SO 1-A, SO 2-A, SO 3-B or SO 1, SO 2, SO 3">
                        <span class="input-group-btn">
                            <button type="button" class="btn btn-primary btn-sm" id="btnAutoSelectSOs">
                                <span class="glyphicon glyphicon-check"></span> Select
                            </button>
                        </span>
                    </div>
                    <table id="solist" class="display" style="border-spacing:0; padding:0; width:100%;">
                        <thead>
                            <tr>
                                <th class="no-sort" style="width:3px"></th>
                                <th>SO</th>
                                <th>DESC</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </form>`;

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN STUDENT OUTCOMES</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){

                        const selected = DataTable_SOList.rows({ selected: true }).data();
                        const unselected  = DataTable_SOList.rows({ selected: false }).data();

                        let checked_unchecked_list = '';
                        for(let i = 0; i < selected.length; ++i) {
                            if (checked_unchecked_list !== '') checked_unchecked_list += '|';
                            checked_unchecked_list += encodeURIComponent(selected[i].Idx + '_true');
                        }
                        for(let i = 0; i < unselected.length; ++i) {
                            if (checked_unchecked_list !== '') checked_unchecked_list += '|';
                            checked_unchecked_list += encodeURIComponent(unselected[i].Idx + '_false');
                        }
                        AssignSOs_Perform(AbetCourseIdx, AcademicYear, checked_unchecked_list);
                    }
                },
                cancel: {
                    label: '<span class="glyphicon glyphicon-remove"></span> CANCEL',
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            // Auto-select button click handler
            $('#btnAutoSelectSOs').on('click', function() {
                const input = $('#_AutoSelectSOs').val().trim();
                if (!input) return;

                // Deselect all rows first
                DataTable_SOList.rows().deselect();

                // Parse the input string
                // Example: "SO 1, SO 2, SO 3"
                const items = input.split(',').map(s => s.trim());

                items.forEach(item => {
                    // Match pattern like "SO 1"
                    const match = item.match(/SO\s*(\d+)/i);
                    if (match) {
                        const soNumber = match[1];

                        // Find and select matching rows in the DataTable
                        DataTable_SOList.rows().every(function() {
                            const data = this.data();
                            // Assuming SO column contains "SO 1" format
                            const soMatch = data.SO.match(/\d+/);

                            if (soMatch && soMatch[0] === soNumber) {
                                this.select();
                            }
                        });
                    }
                });
            });
        });

        let DataTable_SOList = $("#solist").DataTable({
            processing: true,
            serverSide: false,
            iDisplayLength: 8,
            lengthChange: false,
            select: {style: 'multi'},
            sDom: 'tp', // invisible search box & show pagination tabs
            ajax: 'ssps/dept_abetcourses_solist_ssps.php?_AY='+AcademicYear,
            order: [[ 1, 'asc' ]],
            fnDrawCallback: function() {
                $('#solist tr td:nth-child(1)').css('text-align', 'center');
                $('#solist tr td:nth-child(2)').css('text-align', 'center');
                $('#solist tr td:nth-child(3)').css('width', '80%');
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function ( data, type, full, meta ) {
                        let rowId = full.Idx; // // Get Idx
                        if (SOIdxes!=null)
                        {
                            if (SOIdxes.search(rowId) >=0)
                                DataTable_SOList.row('#'+data).select();
                        }
                        return '';
                    }
                },
                { data: 'SO' },
                { data: 'Desc' },
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets  : 'no-sort',
                    orderable: false,
                }
            ]
        });
    }

    async function AssignSOs_Perform(CourseIdx, _AY, CheckedUncheckedSOs) {
        try {
            const result = await async_commons.makeApiCall('dept_abetcourses_so_assign_ajax.php', {
                ay: _AY,
                sos: CheckedUncheckedSOs,
                abetcrs: CourseIdx
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ASSIGNED', 'Student outcomes are assigned!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function AssignPIs(AbetCourseIdx, AcademicYear, AcademicYearInfo, SOIdxes, PIIdxes)
    {
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
                <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                    <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>
                        <input type="text" name="_AY" id="_AY" class="input-sm form-control" value="${AcademicYearInfo}" disabled>
                    </div>
                    <div class="input-group" style="width:100%; margin-top:10px;">
                        <span class="input-group-addon" style="width:230px;">Auto Select PIs</span>
                        <input type="text" name="_AutoSelect" id="_AutoSelect" class="input-sm form-control" placeholder="e.g., SO 1-A, SO 2-A, SO 3-B">
                        <span class="input-group-btn">
                            <button type="button" class="btn btn-primary btn-sm" id="btnAutoSelect">
                                <span class="glyphicon glyphicon-check"></span> Select
                            </button>
                        </span>
                    </div>
                    <table id="gpilist" class="display" style="border-spacing:0; padding:0; width:100%;">
                        <thead>
                        <tr>
                            <th class="no-sort" style="width:3px"></th>
                            <th>SO</th>
                            <th>PI</th>
                            <th>DESC</th>
                        </tr>
                        </thead>
                    </table>
                </div></form>`;

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN PERFORMANCE INDICATORS</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){

                        const selected = DataTable_GPIList.rows({ selected: true }).data();
                        const unselected  = DataTable_GPIList.rows({ selected: false }).data();

                        let checked_unchecked_list = '';
                        for(let i = 0; i < selected.length; ++i) {
                            if (checked_unchecked_list !=='') checked_unchecked_list += "|";
                            checked_unchecked_list += selected[i].SOIdx + "_" + selected[i].PIIdx+"_true";
                        }
                        for(let i = 0; i < unselected.length; ++i) {
                            if (checked_unchecked_list !=='') checked_unchecked_list += "|";
                            checked_unchecked_list += unselected[i].SOIdx + "_" + unselected[i].PIIdx+"_false";
                        }
                        AssignPIs_Perform(AbetCourseIdx, AcademicYear, checked_unchecked_list);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            // Auto-select button click handler
            $('#btnAutoSelect').on('click', function() {
                const input = $('#_AutoSelect').val().trim();
                if (!input) return;

                // Deselect all rows first
                DataTable_GPIList.rows().deselect();

                // Parse the input string
                // Example: "SO 1-A, SO 2-A, SO 3-B"
                const items = input.split(',').map(s => s.trim());
                const notFoundItems = [];

                items.forEach(item => {
                    // Match pattern like "SO 1-A" or "SO 1 - A"
                    const match = item.match(/SO\s*(\d+)\s*-\s*([A-Z])/i);
                    if (match) {
                        const soNumber = match[1];
                        const piLetter = match[2].toUpperCase();
                        let found = false;

                        // Find and select matching rows in the DataTable
                        DataTable_GPIList.rows().every(function() {
                            const data = this.data();
                            // Assuming SO column contains "SO 1" format and GPI contains "A", "B", etc.
                            const soMatch = data.SO.match(/\d+/);
                            const piMatch = data.PI.match(/[A-Z]/i);

                            if (soMatch && piMatch &&
                                soMatch[0] === soNumber &&
                                piMatch[0].toUpperCase() === piLetter) {
                                this.select();
                                found = true;
                            }
                        });

                        // Track items that were not found
                        if (!found) {
                            notFoundItems.push(item);
                        }
                    }
                });

                // Show warning if any items were not found
                if (notFoundItems.length > 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Items Not Found',
                        html: 'The following items were not found:<br><strong>' + notFoundItems.join(', ') + '</strong>',
                        confirmButtonText: 'OK'
                    });
                }
            });
        });

        let DataTable_GPIList = $("#gpilist").DataTable({
            processing: true,
            serverSide: false,
            iDisplayLength: 8,
            select: {
                style: 'multi'
            },
            lengthChange: false,
            sDom: 'tp', // invisible search box & show pagination tabs
            ajax: "ssps/dept_abetcourses_gpilist_ssps.php?_IDX="+encodeURIComponent(AbetCourseIdx)+"&_AY="+AcademicYear+"&_SO="+encodeURIComponent(SOIdxes),
            order: [[ 1, 'asc' ]],
            fnDrawCallback: function() {
                $('#gpilist tr td:nth-child(1)').css('text-align', 'center');
                $('#gpilist tr td:nth-child(2)').css('text-align', 'center');
                $('#gpilist tr td:nth-child(3)').css('text-align', 'center');

                $('#gpilist tr td:nth-child(4)').css('width', '80%');
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function ( data, type, full, meta ) {
                        if (PIIdxes !== '' && PIIdxes != null){
                            let res = PIIdxes.split(',');
                            for(let i = 0; i < res.length; i++) {
                                if (Number(res[i].trim()) === full.PIIdx) {
                                    DataTable_GPIList.row('#'+data).select();
                                }
                            }
                        }
                        return '';
                    }
                },
                { data: 'SO' },
                { data: 'PI' },
                { data: 'Desc' },
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets  : 'no-sort',
                    orderable: false,
                }
            ]
        });
    }

    async function AssignPIs_Perform(AbetCourseIdx, _AY, CheckedUncheckedPIs) {
        try {
            const result = await async_commons.makeApiCall('dept_abetcourses_pi_assign_ajax.php', {
                ay: _AY,
                gpi: CheckedUncheckedPIs,
                abetcrs: AbetCourseIdx
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ASSIGNED', 'GPIS are assigned!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }



<?php
}
?>
</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
    function createQRCodeAndDownload(url, survey_filename_txt) {
        // Create a temporary container (hidden)
        const tempContainer = document.createElement('div');
        tempContainer.style.display = 'none';
        document.body.appendChild(tempContainer);

        // Generate QR code
        const qr = new QRCode(tempContainer, {
            text: url,
            width: 512,
            height: 512,
            colorDark: '#000000',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.H
        });

        // Wait for QR code to generate, then add text and download
        setTimeout(() => {
            const filename = survey_filename_txt.replaceAll(' ', '_') + '.png';
            const qrCanvas = tempContainer.querySelector('canvas');
            if (qrCanvas) {
                // Create a new canvas with extra space for text
                const finalCanvas = document.createElement('canvas');
                const ctx = finalCanvas.getContext('2d');

                // Set canvas size (QR code height + space for text)
                const textHeight = 60; // Space for text at bottom
                finalCanvas.width = qrCanvas.width;
                finalCanvas.height = qrCanvas.height + textHeight;

                // Fill background with white
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(0, 0, finalCanvas.width, finalCanvas.height);

                // Draw QR code on top
                ctx.drawImage(qrCanvas, 0, 0);

                // Add text at bottom
                ctx.fillStyle = '#000000';
                ctx.font = 'bold 24px Arial';
                ctx.textAlign = 'center';
                ctx.fillText(survey_filename_txt, finalCanvas.width / 2, qrCanvas.height + 40);

                // Convert to blob and download
                finalCanvas.toBlob((blob) => {
                    const link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = filename;
                    link.click();

                    // Cleanup
                    URL.revokeObjectURL(link.href);
                    document.body.removeChild(tempContainer);
                });
            } else {
                // Fallback: use image if canvas not available
                const img = tempContainer.querySelector('img');
                if (img) {
                    const link = document.createElement('a');
                    link.href = img.src;
                    link.download = filename;
                    link.click();
                    document.body.removeChild(tempContainer);
                }
            }
        }, 100);
    }

    function generateAndDownload() {
        const url = document.getElementById('url').value;
        const filename = document.getElementById('filename').value || 'qrcode';

        if (!url) {
            alert('Please enter a URL');
            return;
        }

        // Generate and download (no preview)
        createQRCodeAndDownload(url, filename);

        // Show status message
        const status = document.getElementById('status');
        status.textContent = 'QR Code downloaded successfully!';
        status.style.display = 'block';
        setTimeout(() => {
            status.style.display = 'none';
        }, 3000);
    }

    function DownloadQRCodes() {
        // Check if DataTable is empty
        if (DataTable_AbetCourseList.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses and convert to array
        const selected = DataTable_AbetCourseList.rows({ selected: true }).data().toArray();  // Added .toArray()

        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        // Generate and download QR codes for each selected course
        selected.forEach((item, index) => {
            if (item.Survey) {
                const survey_url = item.Survey;
                const survey_filename_txt = item.Semester + ' ' + item.Subject + item.Num + ' ABET Survey';

                setTimeout(() => {
                    createQRCodeAndDownload(survey_url, survey_filename_txt);
                }, index * 300); // 300ms delay between each download
            }
        });
    }

    // New function to create QR code and return as base64 (for email)
    function createQRCodeAsBase64(url, survey_filename_txt) {
        return new Promise((resolve, reject) => {
            // Create a temporary container (hidden)
            const tempContainer = document.createElement('div');
            tempContainer.style.display = 'none';
            document.body.appendChild(tempContainer);

            // Generate QR code
            const qr = new QRCode(tempContainer, {
                text: url,
                width: 512,
                height: 512,
                colorDark: '#000000',
                colorLight: '#ffffff',
                correctLevel: QRCode.CorrectLevel.H
            });

            // Wait for QR code to generate
            setTimeout(() => {
                const qrCanvas = tempContainer.querySelector('canvas');
                if (qrCanvas) {
                    // Create a new canvas with extra space for text
                    const finalCanvas = document.createElement('canvas');
                    const ctx = finalCanvas.getContext('2d');

                    // Set canvas size (QR code height + space for text)
                    const textHeight = 60;
                    finalCanvas.width = qrCanvas.width;
                    finalCanvas.height = qrCanvas.height + textHeight;

                    // Fill background with white
                    ctx.fillStyle = '#ffffff';
                    ctx.fillRect(0, 0, finalCanvas.width, finalCanvas.height);

                    // Draw QR code on top
                    ctx.drawImage(qrCanvas, 0, 0);

                    // Add text at bottom
                    ctx.fillStyle = '#000000';
                    ctx.font = 'bold 24px Arial';
                    ctx.textAlign = 'center';
                    ctx.fillText(survey_filename_txt, finalCanvas.width / 2, qrCanvas.height + 40);

                    // Convert to base64
                    const base64Image = finalCanvas.toDataURL('image/png');

                    // Cleanup
                    document.body.removeChild(tempContainer);

                    resolve(base64Image);
                } else {
                    document.body.removeChild(tempContainer);
                    reject('Failed to generate QR code');
                }
            }, 100);
        });
    }

    // Email function
    async function EmailQRCodes() {
        // Check if DataTable is empty
        if (DataTable_AbetCourseList.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses and convert to array
        const selected = DataTable_AbetCourseList.rows({ selected: true }).data().toArray();

        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        try {
            // Show initial progress
            Swal.fire({
                title: 'Processing...',
                html: `
                <div style="margin: 20px 0;">
                    <div style="font-size: 14px; margin-bottom: 10px;">Generating QR codes...</div>
                    <div style="width: 100%; background-color: #e0e0e0; border-radius: 10px; overflow: hidden;">
                        <div id="progress-bar" style="width: 0%; height: 30px; background-color: #3085d6; transition: width 0.3s; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                            <span id="progress-text">0%</span>
                        </div>
                    </div>
                    <div id="progress-status" style="margin-top: 10px; font-size: 12px; color: #666;">Starting...</div>
                </div>
            `,
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // Helper function to update progress
            function updateProgress(current, total, status) {
                const percent = Math.round((current / total) * 100);
                const progressBar = document.getElementById('progress-bar');
                const progressText = document.getElementById('progress-text');
                const progressStatus = document.getElementById('progress-status');

                if (progressBar) progressBar.style.width = percent + '%';
                if (progressText) progressText.textContent = percent + '%';
                if (progressStatus) progressStatus.textContent = status;
            }

            // Generate QR codes for all selected courses
            const qrCodesData = [];
            const totalItems = selected.length;

            for (let i = 0; i < selected.length; i++) {
                const item = selected[i];

                updateProgress(i + 1, totalItems, `Processing ${i + 1} of ${totalItems} courses...`);

                if (item.Survey) {
                    const survey_url = item.Survey;
                    const survey_filename_txt = item.Semester + ' ' + item.Subject + item.Num + ' ABET Survey';
                    const filename = survey_filename_txt.replaceAll(' ', '_');

                    // Generate QR code as base64
                    const qrCodeBase64 = await createQRCodeAsBase64(survey_url, survey_filename_txt);

                    qrCodesData.push({
                        filename: filename,
                        base64: qrCodeBase64,
                        subject: item.Subject,
                        num: item.Num,
                        title: item.Title,
                        instructor: item.Instructor,
                        email: item.Email
                    });
                }
            }

            if (qrCodesData.length === 0) {
                Swal.fire({
                    title: "ERROR",
                    text: "No valid survey URLs found!",
                    icon: "error"
                });
                return;
            }

            // Update progress for grouping
            updateProgress(totalItems, totalItems, 'Grouping courses by instructor...');

            // Group QR codes by instructor email
            const groupedByInstructor = {};

            qrCodesData.forEach(qrCode => {
                const instructorEmail = qrCode.email;

                if (!groupedByInstructor[instructorEmail]) {
                    groupedByInstructor[instructorEmail] = {
                        instructor: qrCode.instructor,
                        email: qrCode.email,
                        courses: []
                    };
                }

                groupedByInstructor[instructorEmail].courses.push({
                    filename: qrCode.filename,
                    base64: qrCode.base64,
                    subject: qrCode.subject,
                    num: qrCode.num,
                    title: qrCode.title
                });
            });

            // Update progress for sending email
            updateProgress(totalItems, totalItems, 'Sending emails...');

            // Send email with grouped QR codes
            const formData = new FormData();
            formData.append('instructorData', JSON.stringify(groupedByInstructor));

            const response = await fetch('dept_abetcourses_sendqremail.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                const instructorCount = Object.keys(groupedByInstructor).length;
                Swal.fire({
                    title: "Success",
                    text: `${qrCodesData.length} QR code(s) sent to ${instructorCount} instructor(s)!`,
                    icon: "success"
                });
            } else {
                Swal.fire({
                    title: "ERROR",
                    text: result.message || "Failed to send email!",
                    icon: "error"
                });
            }

        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                title: "ERROR",
                text: "An error occurred while generating QR codes!",
                icon: "error"
            });
        }
    }

    // Email Master Syllabus function with CKEditor
    async function EmailMasterSyllabus() {
        // Check if DataTable is empty
        if (DataTable_AbetCourseList.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses and convert to array
        const selected = DataTable_AbetCourseList.rows({ selected: true }).data().toArray();

        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        try {
            // Collect Master syllabus data for all selected courses
            const abetSyllabusData = [];

            for (let i = 0; i < selected.length; i++) {
                const item = selected[i];
                abetSyllabusData.push({
                    AbetSyllabus: item.AbetSyllabus,
                    academicYearInfo: item.AcademicYearInfo,
                    degree: item.degree,
                    semester: item.Semester,
                    subject: item.Subject,
                    num: item.Num,
                    title: item.Title,
                    instructor: item.Instructor,
                    email: item.Email
                });
            }

            if (abetSyllabusData.length === 0) {
                Swal.fire({
                    title: "ERROR",
                    text: "No Master syllabus found for selected courses!",
                    icon: "error"
                });
                return;
            }

            // Group master syllabus by instructor email
            const groupedByInstructor = {};

            abetSyllabusData.forEach(syllabus => {
                const instructorEmail = syllabus.email;

                if (!groupedByInstructor[instructorEmail]) {
                    groupedByInstructor[instructorEmail] = {
                        instructor: syllabus.instructor,
                        email: syllabus.email,
                        courses: []
                    };
                }

                groupedByInstructor[instructorEmail].courses.push({
                    AbetSyllabus: syllabus.AbetSyllabus,
                    academicYearInfo: syllabus.academicYearInfo,
                    degree: syllabus.degree,
                    semester: syllabus.semester,
                    subject: syllabus.subject,
                    num: syllabus.num,
                    title: syllabus.title
                });
            });

            // Generate course list for preview
            let courseListPreview = '<ul style="max-height: 150px; overflow-y: auto; margin: 10px 0; font-size: 12px;">';
            abetSyllabusData.forEach(course => {
                courseListPreview += `<li><strong>${course.subject}${course.num}</strong> - ${course.title} (${course.semester}) [${course.academicYearInfo}]</li>`;
            });
            courseListPreview += '</ul>';

            // Default email content
            const defaultSubject = 'Master Syllabus for Your Courses';
            const defaultMessage = `<p>Dear Prof. [INSTRUCTOR_NAME],</p>

<p>Please find attached the Master syllabus for your courses:</p>

<p>[COURSE_LIST]</p>

<p>The master syllabus PDFs are attached for your reference.</p>

<p>Please ensure that your course syllabus is aligned with the corresponding master syllabus. If you plan to adopt a new required textbook, please contact the curriculum committee to submit a textbook revision proposal.</p>

<p>Thank you for your support of our course assessment process.</p>

<p>Best regards,<br>
ABET Assessment Team</p>`;

            // Create form content for the modal
            const formContent = `
        <form name="emailCustomizationForm" id="emailCustomizationForm" method="" onsubmit="return false;">
            <div style="margin-bottom: 20px;">
                <strong>Selected Courses (${abetSyllabusData.length} courses for ${Object.keys(groupedByInstructor).length} instructor(s)):</strong>
                ${courseListPreview}
            </div>

            <div class="input-group" style="width:100%; margin-bottom: 15px;">
                <span class="input-group-addon" style="width:150px;">Email Subject<span style="color:red">*</span></span>
                <input type="text" name="_emailSubject" id="_emailSubject" class="input-sm form-control" value="${defaultSubject}" required>
            </div>

            <div class="input-group" style="width:100%; margin-bottom: 15px;">
                <span class="input-group-addon" style="width:150px;">CC Emails</span>
                <input type="text" name="_ccEmails" id="_ccEmails" class="input-sm form-control" value="<?php echo($_SESSION['ATLAS_LOGIN_USEREMAIL']);?>" placeholder="email1@domain.com, email2@domain.com">
                <div id="ccEmailError" style="color: red; font-size: 11px; margin-top: 3px; display: none;"></div>
            </div>

            <div style="margin-bottom: 15px;">
                <label for="_emailMessage" style="display: block; margin-bottom: 5px; font-weight: bold;">Email Message<span style="color:red">*</span>:</label>
                <div style="font-size: 11px; color: #666; margin-bottom: 5px;">
                    <strong>Required placeholders:</strong> [INSTRUCTOR_NAME] and [COURSE_LIST] - these will be replaced with actual data for each instructor. Do not remove these.
                </div>
                <textarea name="_emailMessage" id="_emailMessage" rows="12" class="form-control" style="width: 100%;" required>${defaultMessage}</textarea>
                <div id="placeholderError" style="color: red; font-size: 11px; margin-top: 3px; display: none;"></div>
            </div>
        </form>`;

            // Show the modal dialog
            createModalDialog({
                largeSize: true,
                className: "dialogWide",
                title: '<span class="glyphicon glyphicon-envelope" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">CUSTOMIZE EMAIL</span>',
                message: formContent,
                buttons: {
                    ok: {
                        label: "<span class='glyphicon glyphicon-send'></span> SEND EMAILS",
                        className: 'btn-success',
                        callback: function(){
                            const subject = emailCustomizationForm._emailSubject.value.trim();
                            const ccEmails = emailCustomizationForm._ccEmails.value.trim();

                            // Get CKEditor content safely
                            let message = '';
                            if (CKEDITOR.instances['_emailMessage'] && CKEDITOR.instances['_emailMessage'].getData) {
                                message = CKEDITOR.instances['_emailMessage'].getData().trim();
                            }

                            // Clear previous error messages
                            document.getElementById('ccEmailError').style.display = 'none';
                            document.getElementById('placeholderError').style.display = 'none';

                            // Validate subject
                            if (!subject) {
                                Swal.fire({
                                    title: "Validation Error",
                                    text: "Please enter an email subject!",
                                    icon: "error"
                                });
                                return false;
                            }

                            // Validate message
                            if (!message) {
                                Swal.fire({
                                    title: "Validation Error",
                                    text: "Please enter an email message!",
                                    icon: "error"
                                });
                                return false;
                            }

                            // Validate required placeholders
                            if (!message.includes('[INSTRUCTOR_NAME]') || !message.includes('[COURSE_LIST]')) {
                                document.getElementById('placeholderError').textContent =
                                    'Email message must contain both [INSTRUCTOR_NAME] and [COURSE_LIST] placeholders!';
                                document.getElementById('placeholderError').style.display = 'block';

                                Swal.fire({
                                    title: "Validation Error",
                                    text: "Email message must contain both [INSTRUCTOR_NAME] and [COURSE_LIST] placeholders!",
                                    icon: "error"
                                });
                                return false;
                            }

                            // Validate CC emails if provided
                            if (ccEmails) {
                                const emailValidation = validateCCEmails(ccEmails);
                                if (!emailValidation.isValid) {
                                    document.getElementById('ccEmailError').textContent = emailValidation.error;
                                    document.getElementById('ccEmailError').style.display = 'block';

                                    Swal.fire({
                                        title: "Validation Error",
                                        text: emailValidation.error,
                                        icon: "error"
                                    });
                                    return false;
                                }
                            }

                            // Clean up CKEditor before sending
                            safelyDestroyCKEditor('_emailMessage');

                            // Send emails with custom data
                            sendEmailsWithCustomData(groupedByInstructor, abetSyllabusData, subject, ccEmails, message);
                            return true;
                        }
                    },
                    cancel: {
                        label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                        className: 'btn-default',
                        callback: function(){
                            // Clean up on cancel
                            safelyDestroyCKEditor('_emailMessage');
                        }
                    }
                }
            }).on('shown.bs.modal', function(){
                // Safely destroy any existing CKEditor instance
                safelyDestroyCKEditor('_emailMessage');

                // Calculate available height
                const modalHeight = $(this).find('.modal-body').height();
                const headerHeight = 250; // Height of form elements except textarea
                let editorHeight = modalHeight - headerHeight;

                // Set a minimum reasonable height
                editorHeight = Math.max(editorHeight, 300);

                // Apply the height directly to the textarea
                $('#_emailMessage').css('height', editorHeight + 'px');

                // Initialize CKEditor with explicit height setting and error handling
                CKEDITOR.replace('_emailMessage', {
                    toolbar: [
                        ['Bold', 'Italic', 'Underline', '-', 'NumberedList', 'BulletedList'],
                        ['FontSize', 'TextColor', 'BGColor', '-', 'Link'],
                        ['Undo', 'Redo']
                    ],
                    height: editorHeight + 'px',
                    allowedContent: true,
                    enterMode: CKEDITOR.ENTER_P,
                    shiftEnterMode: CKEDITOR.ENTER_BR,

                    // Add event listeners
                    on: {
                        instanceReady: function(evt) {
                            // Focus on the editor after it's ready
                            evt.editor.focus();
                        },
                        change: function(evt) {
                            // Real-time validation for placeholders
                            const content = evt.editor.getData();
                            const errorDiv = document.getElementById('placeholderError');

                            if (content && (!content.includes('[INSTRUCTOR_NAME]') || !content.includes('[COURSE_LIST]'))) {
                                errorDiv.textContent = 'Email message must contain both [INSTRUCTOR_NAME] and [COURSE_LIST] placeholders!';
                                errorDiv.style.display = 'block';
                            } else {
                                errorDiv.style.display = 'none';
                            }
                        }
                    }
                });

                // Add a window resize handler for responsiveness
                $(window).on('resize.ckeditor', function() {
                    if (CKEDITOR.instances['_emailMessage'] && CKEDITOR.instances['_emailMessage'].resize) {
                        const newModalHeight = $('.modal-body').height();
                        const newEditorHeight = Math.max(newModalHeight - headerHeight, 300);
                        CKEDITOR.instances['_emailMessage'].resize('100%', newEditorHeight);
                    }
                });

                // Clean up on modal close
                $(this).on('hidden.bs.modal', function() {
                    $(window).off('resize.ckeditor');
                    safelyDestroyCKEditor('_emailMessage');
                });

                // Focus on subject field initially
                $("#_emailSubject").focus();

                // Add real-time validation for CC emails
                $('#_ccEmails').on('input', function() {
                    const ccEmails = this.value.trim();
                    const errorDiv = document.getElementById('ccEmailError');

                    if (ccEmails) {
                        const validation = validateCCEmails(ccEmails);
                        if (!validation.isValid) {
                            errorDiv.textContent = validation.error;
                            errorDiv.style.display = 'block';
                        } else {
                            errorDiv.style.display = 'none';
                        }
                    } else {
                        errorDiv.style.display = 'none';
                    }
                });
            });

        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                title: "ERROR",
                text: "An error occurred while preparing the email dialog!",
                icon: "error"
            });
        }
    }


    // Helper function to safely destroy CKEditor instances
    function safelyDestroyCKEditor(instanceName) {
        try {
            if (CKEDITOR.instances &&
                CKEDITOR.instances[instanceName] &&
                CKEDITOR.instances[instanceName].destroy &&
                typeof CKEDITOR.instances[instanceName].destroy === 'function') {
                CKEDITOR.instances[instanceName].destroy(true); // true means "no DOM cleanup" which avoids some errors
            }
        } catch (e) {
            console.log('CKEditor cleanup error:', e);
            // Continue despite error
        }

        // Extra safety: check if it's still there and force remove from instances object
        if (CKEDITOR.instances && CKEDITOR.instances[instanceName]) {
            delete CKEDITOR.instances[instanceName];
        }
    }

    // Function to validate CC email addresses
    function validateCCEmails(ccEmails) {
        // Regular expression for email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Split emails by comma and clean up
        const emailArray = ccEmails.split(',').map(email => email.trim()).filter(email => email.length > 0);

        if (emailArray.length === 0) {
            return { isValid: true }; // Empty is valid
        }

        const invalidEmails = [];

        for (let email of emailArray) {
            if (!emailRegex.test(email)) {
                invalidEmails.push(email);
            }
        }

        if (invalidEmails.length > 0) {
            return {
                isValid: false,
                error: `Invalid email format(s): ${invalidEmails.join(', ')}`
            };
        }

        // Check for duplicate emails
        const uniqueEmails = [...new Set(emailArray)];
        if (uniqueEmails.length !== emailArray.length) {
            return {
                isValid: false,
                error: 'Duplicate email addresses found in CC list'
            };
        }

        return { isValid: true };
    }

    // Separate function to handle the actual email sending
    async function sendEmailsWithCustomData(groupedByInstructor, abetSyllabusData, subject, ccEmails, message) {
        try {
            // Show progress dialog
            Swal.fire({
                title: 'Processing...',
                html: `
                <div style="margin: 20px 0;">
                    <div style="font-size: 14px; margin-bottom: 10px;">Sending master syllabus emails...</div>
                    <div style="width: 100%; background-color: #e0e0e0; border-radius: 10px; overflow: hidden;">
                        <div id="progress-bar" style="width: 0%; height: 30px; background-color: #3085d6; transition: width 0.3s; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                            <span id="progress-text">0%</span>
                        </div>
                    </div>
                    <div id="progress-status" style="margin-top: 10px; font-size: 12px; color: #666;">Preparing emails...</div>
                </div>
            `,
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // Helper function to update progress
            function updateProgress(current, total, status) {
                const percent = Math.round((current / total) * 100);
                const progressBar = document.getElementById('progress-bar');
                const progressText = document.getElementById('progress-text');
                const progressStatus = document.getElementById('progress-status');

                if (progressBar) progressBar.style.width = percent + '%';
                if (progressText) progressText.textContent = percent + '%';
                if (progressStatus) progressStatus.textContent = status;
            }

            const totalInstructors = Object.keys(groupedByInstructor).length;
            updateProgress(1, 1, `Sending emails to ${totalInstructors} instructor(s)...`);

            // Send email with grouped master syllabus
            const formData = new FormData();
            formData.append('instructorData', JSON.stringify(groupedByInstructor));
            formData.append('emailSubject', subject);
            formData.append('ccEmails', ccEmails);
            formData.append('emailMessage', message);

            const response = await fetch('dept_abetcourses_sendabetsyllabusemail.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                const instructorCount = Object.keys(groupedByInstructor).length;
                Swal.fire({
                    title: "Success",
                    text: `master syllabus for ${abetSyllabusData.length} course(s) sent to ${instructorCount} instructor(s)!`,
                    icon: "success"
                });

                // Uncheck all selected rows
                DataTable_AbetCourseList.rows({ selected: true }).deselect();

            } else {
                Swal.fire({
                    title: "ERROR",
                    text: result.message || "Failed to send emails!",
                    icon: "error"
                });
            }

        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                title: "ERROR",
                text: "An error occurred while sending master syllabus!",
                icon: "error"
            });
        }
    }
</script>

<script class="init">

    $(document).ready(function() {
        const SelectedAcademicYear = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].value;
        const szURL = 'ssps/dept_abetcourses_ssps.php?_AY=';
        //console.log(`${szURL}<?php //echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>//`);

        DataTable_AbetCourseList = $("#AbetCourses").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            stateSave: true,
            processing: true,
            serverSide: true,
            select: {
                style: 'multi'
            },
            lengthMenu: [30, 50, 100, 150, 200, 300, 400],
            ajax: `${szURL}<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>`,
            oLanguage: {
                sInfoFiltered: ""
            },
            order: [[2, "asc"], [3, "asc"], [4, "asc"]],

            // Column definitions
            columns: [
                {
                    data: null,
                    className: "select-checkbox text-center",
                    defaultContent: "",
                    orderable: false,
                    width: "30px"
                },
                { data: 'Semester', className: 'text-center' },
                { data: 'CRN', className: 'text-center' },
                { data: 'Subject', className: 'text-center' },
                { data: 'Num', className: 'text-center' },
                { data: 'Title', className: 'text-center' },
                { data: 'Credits', className: 'text-center' },
                { data: 'Instructor', className: 'text-center' },
                { data: 'Requirement', className: 'text-center' },
                { data: 'Level', className: 'text-center' },
                { data: 'StudentOutcomes' },
                {
                    data: 'PIs',
                    render: (data, type, row) => {
                        return row.PIs.split(",")
                            .filter(item => item.includes("-"))
                            .map(item => item.trim())
                            .join(", ");
                    }
                },
                {
                    data: 'AbetSyllabus',
                    className: 'text-center',
                    render: (data, type, row) => {
                        let html = '';
                        if (data !== '' && data !== null) {
                            html = `<button class="btn btn-success btn-xs" id="abetsyllabus"
                                data-syllabus="${data}"
                                data-subject="${row.Subject}"
                                data-num="${row.Num}"
                                title="Download Syllabus">
                                <i class="glyphicon glyphicon-floppy-save"></i> PDF
                                </button>
                                <button id="replacesyllabus"
                                class="btn btn-warning btn-xs glyphicon glyphicon-refresh"
                                style="min-height: 20px;"
                                data-avcidx="${row.AVCourseIdx}"
                                data-academicyearinfo="${row.AcademicYearInfo}"
                                data-abetsyllabus="${data}"
                                title="Replace Master Syllabus">
                                </button>
                            `;

                            <?php
                            if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { // available only to the people who have access controls to programs
                            ?>
                            html += `
                                <button id="removesyllabus"
                                class="btn btn-danger btn-xs glyphicon glyphicon-remove-circle"
                                style="min-height: 20px;"
                                data-avcidx="${row.AVCourseIdx}"
                                data-academicyearinfo="${row.AcademicYearInfo}"
                                data-abetsyllabus="${data}"
                                title="Remove Master Syllabus">
                                </button>`;
                            <?php
                            }
                            ?>
                        } else {
                            <?php
                            if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                            ?>
                            html = `<button id="uploadsyllabus" class="btn btn-danger btn-xs glyphicon glyphicon-upload" style="min-height: 20px;" title="Upload Master Syllabus"></button>&nbsp;`;
                            <?php
                            }
                            ?>
                        }
                        return html;
                    }
                },
                { data: 'SyllabusLastUpdated', className: 'text-center' },
                {
                    data: 'Survey',
                    className: 'text-center editable-survey',
                    render: (data, type, row) => {
                        // Display the value as editable text
                        const displayValue = data || '';
                        return `<span class="survey-value" contenteditable="false">${displayValue}</span>`;
                    }
                },
                { data: "", className: 'text-center' }
            ],

            // Styling callbacks
            fnInitComplete: function(settings) {
                const btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + settings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                btnClear.click(() => $('#' + settings.sTableId).dataTable().fnFilter(''));
            },

            fnDrawCallback: function() {
                this.api().state.clear(); // cancel "stateSave" after reload the page

                // Cell widths
                const cellWidths = {
                    2: '80px',
                    3: '80px', 4: '80px'
                };
                const minWidths = {
                    5: '150px', 6: '80px',
                    7: '80px', 8: '80px', 9: '80px', 10: '80px',
                    11: '80px', 12: '150px'
                };

                Object.entries(cellWidths).forEach(([col, width]) => {
                    $(`#AbetCourses tr td:nth-child(${col})`).css('width', width);
                });
                Object.entries(minWidths).forEach(([col, width]) => {
                    $(`#AbetCourses tr td:nth-child(${col})`).css('min-width', width);
                });

                $('#AbetCourses tr td:nth-child(1)').css('vertical-align', 'bottom');
            },
            columnDefs: [
                {
                    targets: 'no-sort',
                    orderable: false
                },
                {
                    targets: -1,
                    data: null,
                    orderable: false,
                    render: function(data, type, row) {
                        const classRosterDisabled = row.HasClassRoster === 1 ? '' : 'disabled';
                        const classRosterTitle = row.HasClassRoster === 1 ? 'Class roster' : 'No class roster available';
                        const classRosterStyle = row.HasClassRoster === 1 ? 'min-height: 20px;' : 'min-height: 20px; opacity: 0.5; cursor: not-allowed;';

                        return '<div>'
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { // available only to the people who have access controls to programs
?>
                        + '<button id="assignso" alt="Assign Student Outcomes" title="Assign Student Outcome" class="btn btn-danger btn-xs glyphicon glyphicon-th-list" style="min-height: 20px;"></button>&nbsp;'
                        + '<button id="assigngpi" alt="Assign Performance Indicators" title="Assign Performance Indicators" class="btn btn-danger btn-xs glyphicon glyphicon-list" style="min-height: 20px;"></button>&nbsp;'
<?php
}
?>
                        + '<button id="evaluateclassroster" alt="Class roster" title="' + classRosterTitle + '" class="btn btn-danger btn-xs glyphicon glyphicon-education" style="' + classRosterStyle + '" ' + classRosterDisabled + '></button>&nbsp;'
                        + '<button id="remove" alt="Remove ABET course" title="Remove ABET course" class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="min-height: 20px;"></button>&nbsp;'
                        + '</div>';
                    }
                }
            ],
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'landscape',
                    title: getTitleText,
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> PDF',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff; margin-left:8px;'
                    },
                    exportOptions: {
                        columns: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                    },
                    customize: doc => {
                        // Font size adjustments
                        doc.styles.tableHeader.fontSize = 9;
                        doc.defaultStyle.fontSize = 8;

                        // Set page size to US Letter
                        doc.pageSize = 'LETTER';

                        // Reduce margins to maximize space (in points, 72 points = 1 inch)
                        doc.pageMargins = [20, 20, 20, 20]; // [left, top, right, bottom]

                        // Set column widths
                        doc.content[1].table.widths = ['7%', '5%', '6%', '6%', '15%', '6%', '10%', '10%', '10%', '12%', '12%'];

                        // Enhanced styling
                        doc.styles.tableHeader.alignment = 'left';
                        doc.styles.tableBodyEven = doc.styles.tableBodyOdd;
                        doc.styles.tableHeader.bold = true;
                    },
                    pageSize: 'LETTER'
                },
                {
                    extend: 'excelHtml5',
                    title: getTitleText,
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff;'
                    },
                    exportOptions: {
                        columns: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                    }
                }
            ]
        });


        // Helper function for title
        function getTitleText() {
            const program = document.forms["changefrm"]["CH_APR"].options[
                document.forms["changefrm"]["CH_APR"].selectedIndex
                ].text;
            const academicYear = document.academicyear._AY.options[
                document.academicyear._AY.selectedIndex
                ].text;
            return `ABET Courses to be Assessed (${program} ${academicYear})`;
        }

        // Handle Survey field inline editing
        $('#AbetCourses').on('click', '.editable-survey', function() {
            const cell = $(this);
            const span = cell.find('.survey-value');

            // Make it editable
            span.attr('contenteditable', 'true');
            span.focus();

            // Select all text
            const range = document.createRange();
            range.selectNodeContents(span[0]);
            const sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);

            // Add visual indicator
            span.css({
                'background-color': '#ffffcc',
                'padding': '2px 5px',
                'border': '1px solid #ccc'
            });
            return false;
        });

        // Handle blur event (when user clicks away)
        $('#AbetCourses').on('blur', '.survey-value', function() {
            const span = $(this);
            const cell = span.closest('td');
            const newValue = span.text().trim();

            // Remove visual indicator
            span.css({
                'background-color': '',
                'padding': '',
                'border': ''
            });
            span.attr('contenteditable', 'false');

            // Get row data
            const row = DataTable_AbetCourseList.row(cell.closest('tr'));
            const rowData = row.data();
            const oldValue = rowData.Survey || '';

            // Only save if value changed
            if (newValue !== oldValue) {
                // Update the row data
                rowData.Survey = newValue;

                // Send AJAX request to save the change
                $.ajax({
                    url: 'dept_abetcourses_update_survey.php',
                    method: 'POST',
                    data: {
                        Idx: rowData.AVCIdx,
                        Subject: rowData.Subject,
                        Num: rowData.Num,
                        CRN: rowData.CRN,
                        Survey: newValue,
                        AcademicYear: '<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>'
                    },
                    success: function(response) {
                        try {
                            const data = typeof response === 'string' ? JSON.parse(response) : response;

                            if (data.success || data.code === '0x11111111') {
                                // Show success indicator with background color change
                                span.css('background-color', '#d4edda');
                                setTimeout(() => {
                                    span.css('background-color', '');
                                }, 1000);

                                // Optional: Show success message with Swal
                                Swal.fire({
                                    title: "Success",
                                    text: "Survey field updated successfully.",
                                    icon: "success",
                                    timer: 2000,
                                    showConfirmButton: false
                                });
                            } else {
                                // Revert on failure
                                span.text(oldValue);

                                Swal.fire({
                                    title: "ERROR",
                                    text: data.error || "Error saving the Survey field. Please try again.",
                                    icon: "error",
                                    timer: 5000
                                });
                            }
                        } catch(e) {
                            // Revert on parsing error
                            span.text(oldValue);

                            Swal.fire({
                                title: "ERROR",
                                text: "Error processing response. Please try again.",
                                icon: "error",
                                timer: 5000
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        // Revert the change on error
                        span.text(oldValue);

                        Swal.fire({
                            title: "ERROR",
                            text: "Error saving the Survey field. Please try again.",
                            icon: "error",
                            timer: 5000
                        });
                    }
                });
            }
        });

        // Handle Enter key to save and blur
        $('#AbetCourses').on('keydown', '.survey-value', function(e) {
            if (e.keyCode === 13) { // Enter key
                e.preventDefault();
                $(this).blur();
            }
            if (e.keyCode === 27) { // Escape key
                e.preventDefault();
                const cell = $(this).closest('td');
                const row = DataTable_AbetCourseList.row(cell.closest('tr'));
                const rowData = row.data();
                $(this).text(rowData.Survey || '');
                $(this).blur();
            }
        });

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_AbetCourseList.ajax.url(tmpURL).load();
        });

        // Initialize the column search functionality
        new DataTableSearch('#AbetCourses', DataTable_AbetCourseList);

        // Set the DataTable in AsyncCommons
        async_commons.setDataTable(DataTable_AbetCourseList);

        $('#AbetCourses').on('click', '.toggle-all', function() {
            $(this).closest("tr").toggleClass("selected");
            if ($(this).closest("tr").hasClass("selected")) {
                DataTable_AbetCourseList.rows({ page: 'current' }).select();
            }
            else {
                DataTable_AbetCourseList.rows({ page: 'current' }).deselect();
            }
        });

        $('#AbetCourses tbody').on( 'click', '#evaluateclassroster', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            EvaluateClassRoster(data.AVCIdx, data.Enrollment, data.AcademicYearInfo + ' - ' + data.CRN + ' - ' + data.Subject + ' ' + data.Num + ' ' + data.Title);
            return false;  // disable row selection action
        } );

        $('#AbetCourses tbody').on( 'click', '#abetsyllabus', function () {
            const data = DataTable_AbetCourseList.row($(this).parents('tr')).data();
            downloadPDF(data.AbetSyllabus, 293428384, data.AcademicYearInfo);
            return false; // disable row selection action
        } );

        $('#AbetCourses tbody').on( 'click', '#remove', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            RemoveAbetCourse(data.Idx, data.AcademicYearInfo, data.Subject, data.Num, data.Title, data.Syllabus);
            return false;  // disable row selection action
        } );

        //
        // $('#AbetCourses tbody').on( 'click', '#uploadsyllabus', function () {
        //     const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
        //     UploadMasterSyllabus(data.Idx, data.AcademicYearInfo, data.AcademicYear, data.Subject, data.Num, data.Title, data.Degree, data.AcademicProgram);
        //     return false;  // disable row selection action
        // } );

        // Handle both upload and replace buttons
        $('#AbetCourses tbody').on('click', '#uploadsyllabus, #replacesyllabus', function () {
            const data = DataTable_AbetCourseList.row($(this).parents('tr')).data();
            const dialog_title = $(this).attr('id') === 'uploadsyllabus' ? 'UPLOAD' : 'REPLACE';
            UploadMasterSyllabus(dialog_title, data.Idx, data.AcademicYearInfo, data.AcademicYear, data.Subject, data.Num, data.Title, data.Degree, data.AcademicProgram);
            return false; // disable row selection action
        });

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { // available only to the people who have access controls to programs
?>
        $('#AbetCourses tbody').on( 'click', '#removesyllabus', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            removeSyllabus(data.Idx, data.AcademicYearInfo, data.AbetSyllabus);
            return false; // disable row selection action
        } );

        $('#AbetCourses tbody').on( 'click', '#assignso', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            AssignSOs(data.Idx, data.AcademicYear, data.AcademicYearInfo, data.SOIdxes);
            return false; // disable row selection action
        } );

        $('#AbetCourses tbody').on( 'click', '#assigngpi', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            if (data.SOIdxes == null)
            {
                Swal.fire({
                    title: "ERROR",
                    text: "Please add Student Outcomes first.",
                    icon: "error",
                    timer: 5000
                }).then(function(result){
                });
                return false;
            }
            AssignPIs(data.Idx, data.AcademicYear, data.AcademicYearInfo, data.SOIdxes, data.PIIdxes);
            return false;  // disable row selection action
        } );
<?php
}
?>
    } );

</script>

<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSES TO BE ASSESSED</p>
        <?php include('control_selprogram.php'); ?>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:20%; min-width:350px;">
                    <?php echo($AcademicYearSelection);?>
                </td>
                <td style="width:5%"></td>
                <td style="width:75%; text-align: right">
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-refresh" onclick="UpdateMasterSyllabus();return false;">&nbsp;UPDATE SYLLABUS</button>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-envelope" onclick="EmailMasterSyllabus();return false;">&nbsp;EMAIL SYLLABUS</button>
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { // available only to the people who have access controls to programs
?>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-th-large" onclick="EmailQRCodes();return false;">&nbsp;EMAIL QR CODES</button>
<?php
}
?>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-th-large" onclick="DownloadQRCodes();return false;">&nbsp;DOWNLOAD SURVEY QR CODES</button>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-th-large" onclick="AssignReqToSelectedCourses();return false;">&nbsp;ASSIGN REQUIREMENT</button>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-th-large" onclick="AssignLevelToSelectedCourses();return false;">&nbsp;ASSIGN LEVEL</button>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-list-alt" onclick="AddCourses2BeAssessed();return false;">&nbsp;ADD COURSES</button>
                </td>
            </tr>
        </table>

        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="AbetCourses" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th class="toggle-all" style="width:3px; "></th>
                    <th style="width:50px">SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>INSTRUCTOR</th>
                    <th>REQUIREMENT</th>
                    <th>LEVEL</th>
                    <th style="width:150px">STUDENT OUTCOMES</th>
                    <th style="width:180px">PERFORMANCE INDICATORS</th>
                    <th>MASTER SYLLABUS</th>
                    <th>MASTER SYLLABUS LAST UPDATED</th>
                    <th>SURVEY</th>
                    <th class="no-sort">OPERATION</th>
                </tr>
                </thead>
                <thead id="serachbox" class="filters">
                <tr>
                    <th></th>
                    <th>SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>INSTRUCTOR</th>
                    <th>REQUIREMENT</th>
                    <th>LEVEL</th>
                    <th style="width:150px">STUDENT OUTCOMES</th>
                    <th style="width:180px">PERFORMANCE INDICATORS</th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th></th>
                    <th>SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>INSTRUCTOR</th>
                    <th>REQUIREMENT</th>
                    <th>LEVEL</th>
                    <th>STUDENT OUTCOMES</th>
                    <th>PERFORMANCE INDICATORS</th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
                </tfoot>
            </table>
        </div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { // available only to the people who have access controls to programs
?>
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-th-list" style="pointer-events: none;"></span>: Assign Student Outcome
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-list" style="pointer-events: none;"></span>: Assign Performance Indicator
<?php
}
?>
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-upload" style="pointer-events: none;"></span>: Upload Master Syllabus
                    <span class="btn btn-warning btn-xs glyphicon glyphicon-refresh" style="pointer-events: none;"></span>: Replace Master Syllabus
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-remove-circle" style="pointer-events: none;"></span>: Remove Master Syllabus
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Remove ABET Course

                    <span class="btn btn-danger btn-xs glyphicon glyphicon-education" style="pointer-events: none;"></span>: Class Roster
                </td>
            </tr>
        </table>
    </div>
</div>


<?php include('footer.php');?>



