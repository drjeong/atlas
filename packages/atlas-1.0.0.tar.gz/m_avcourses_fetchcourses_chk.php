<?php
/**
 * Management of Available Courses
 * Description: checking if fetching available courses from the university website is running or not.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 *
 */


include('checker_systemadmin.php');

$command = 'ps -p '.$_SESSION['ATLAS_AVCOURSES_PID'];
exec($command,$op);
if (!isset($op[1])) 
{ // process is not running
	echo ("0x10001011"); // uploading is completed

	unset($_SESSION['ATLAS_AVCOURSES_PID']); // destroy session
}
else 
{
	echo ("0x10001029"); // uploading is in progress
}
