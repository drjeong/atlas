<?php
/**
 * Listing PIs
 * File: dept_abetcourses_gpilist_ssps.php
 * Description: listing performance indicators in a dialog window
 *
 * 03/09/2023 - Removed the checking of AbetCourseIdx (not necessary to be checked)
 *
 */

include_once 'session_handler.php';


$AcademicYear='';
$StudentOutcomes='';
$AbetCourseIdx='';
if (array_key_exists('_AY', $_GET) ) {
    $AcademicYear = trim($_GET['_AY']);
}
if (array_key_exists('_SO', $_GET) ) {
    $StudentOutcomes = trim($_GET['_SO']);
}
if (array_key_exists('_IDX', $_GET) ) {
    $AbetCourseIdx = trim($_GET['_IDX']);
}

$AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// DB table to use
$table = 'GeneralPerformanceIndicators';
$joinQuery = "FROM `{$table}` AS `GPI` INNER JOIN `StudentOutcomes` AS `SO` ON (`SO`.`Idx` = `GPI`.`SOIdx` AND `SO`.`AcademicProgram` = '".$AcademicProgram."' AND `GPI`.`AcademicProgram` = '".$AcademicProgram."') INNER JOIN `CourseMapping_SOs` AS `CMCRSESSOS` ON (`CMCRSESSOS`.`SOIdx` = `SO`.`Idx` AND `CMCRSESSOS`.`AcademicProgram` = '".$AcademicProgram."') ";


// Table's primary key
$primaryKey = '`GPI`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`GPI`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`GPI`.`Idx`', 'dt' => 'GPIIdx', 'field' => 'GPIIdx', 'as' => 'GPIIdx'),
    array( 'db' => '`SO`.`SO`', 'dt' => 'SO', 'field' => 'SO', 'as' => 'SO'),
    array( 'db' => '`CMCRSESSOS`.`SOIdx`', 'dt' => 'SOIdx', 'field' => 'SOIdx', 'as' => 'SOIdx'),
    array( 'db' => '`GPI`.`GPI`', 'dt' => 'GPI', 'field' => 'GPI', 'as' => 'GPI'),
    array( 'db' => '`GPI`.`Description`', 'dt' => 'Desc', 'field' => 'Description', 'as' => 'Description')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "`GPI`.`AcademicProgram` = '".$AcademicProgram."'";
if ($AcademicYear != "" && $AcademicYear != "all") {
    $extraWhere .= " AND `GPI`.`AcademicYear`='" . $AcademicYear . "'";
}

if ($StudentOutcomes !=""){
    $so_condition = '';
    $SO_Array = explode( ',', $StudentOutcomes );
    foreach($SO_Array AS $SO){
        if ($so_condition != "") $so_condition .= " OR ";
        $so_condition .= "`GPI`.`SOIdx` = ".trim($SO);
    }
    $extraWhere .= " AND (" . $so_condition . ")";
}
//if ($AbetCourseIdx !=""){
//    $extraWhere .= " AND `AbetCourseIdx`='$AbetCourseIdx'";
//}
$groupBy = "`GPI`.`Idx`";


require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

