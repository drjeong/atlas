<?php
/**
 * Assessment Master Rubrics
 * Description: Listing Assessment Master Rubric for the performance indicators
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 * 04/12/2021 - Change the title "GPI" to "PI"
 * 12/08/2021 -- Update duplicate assessment master rubrics selection options
 * 10/08/2024 -- Adding revision comments and approval info
 */

//include('checker_programdirector.php');
include('header.php');

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelectionOptions = AcademicYearSelection();

// loading list of db functions
include('./php_include/dbfunctions.php');

?>


<script>

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        SAME_ITEM_EXIST: '0x00200011',
        NOT_DATA_IN_SOURCE_YEAR: '0x09500011',
        DATA_EXIST_ALREADY_IN_TARGET_YEAR: '0x09500012',
    };

    async function AsyncGetOptions(option = 1) {
        try {
            const rawResult = await async_commons.makeApiCall(`api_getoptions.php?sel=amr&op=${option}`, {});
            const result = JSON.parse(rawResult);

            if (result.status === 'ERROR') {
                throw new Error(result.message);
            }

            return result.data;
        } catch (error) {
            await async_commons.handleError(error);
            throw error;
        }
    }
</script>

<?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true) { ?>
<script>
    async function UpdateAssessmentMasterRubric(_ID, _AY,_GPI, _LOA, _DESC, _CMNTS, _APRVAL, _TobeRemoved) {
        try {
            const result = await async_commons.makeApiCall('dept_assmntrubrics_update_ajax.php', {
                id: _ID,
                desc: _DESC,
                cmnts: _CMNTS,
                aprval: _APRVAL,
                removal: _TobeRemoved
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'The AMR information has been updated!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function ModifyAssessmentMasterRubric(idx, _AY, _GPI, _LOA, _DESC, _CMNTS, _APRVAL, _TobeRemoved)
    {
        const formContent = `
        <form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <table style="border-spacing:0; padding:0; width:100%;">
                <tr><td colspan="2">
                    <div class="input-group" style="width:100%">
                        <div class="input-group" style="width:100%">
                            <span class="input-group-addon" style="width:230px;">Academic Year<span class="required">*</span></span>
                            <input type="text" name="_AY" id="_AY" class="input-sm form-control" disabled value="${_AY || ''}">
                        </div>
                        <div class="input-group" style="width:100%">
                            <span class="input-group-addon" style="width:230px;">Performance Indicator<span class="required">*</span></span>
                            <input type="text" name="_GPI" id="_GPI" class="input-sm form-control" disabled value="${_GPI || ''}">
                        </div>
                        <div class="input-group" style="width:100%">
                            <span class="input-group-addon" style="width:230px;">Level of Attainment<span class="required">*</span></span>
                            <select name="_LOA" id="_LOA" class="input-sm form-control" disabled>
                                <option value=""></option>
                                <option value="1">1. Unsatisfatory</option>
                                <option value="2">2. Developing</option>
                                <option value="3">3. Satisfactory</option>
                                <option value="4">4. Exemplary</option>
                            </select>
                        </div>
                        <div class="input-group" style="width:100%">
                            <span class="input-group-addon" style="width:230px;">Description<span class="required">*</span></span>
                            <textarea name="_DESC" id="_DESC" rows="6" class="input-sm form-control" style="height:90px" required>${_DESC || ''}</textarea>
                        </div>
                        <div class="input-group" style="width:100%">
                            <span class="input-group-addon" style="width:230px;">Revision Comments</span>
                            <textarea name="_CMNTS" id="_CMNTS" rows="6" class="input-sm form-control" style="height:90px" required>${_CMNTS || ''}</textarea>
                        </div>
                        <div class="input-group" style="width:100%">
                            <span class="input-group-addon" style="width:230px;">Revision Approval</span>
                            <textarea name="_APRVAL" id="_APRVAL" rows="6" class="input-sm form-control" style="height:90px" required>${_APRVAL || ''}</textarea>
                        </div>
                        <div class="input-group" style="width:100%;">
                            <label class="checkbox-container" style="width:100%; font-size:9pt;">
                                <input type="checkbox" name="_TobeRemoved" id="_TobeRemoved" value="1">
                                Check if it will be removed.
                            </label>
                        </div>
                    </div>
                </td></tr>
            </table>
        </form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">EDIT ASSESSMENT MASTER RUBRIC </span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> UPDATE",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');

                        if (!ValidateItems(popupForm)) return false;

                        UpdateAssessmentMasterRubric(idx, popupForm._AY.value,
                            popupForm._GPI.value, popupForm._LOA.value,
                            popupForm._DESC.value, popupForm._CMNTS.value,
                            popupForm._APRVAL.value, popupForm._TobeRemoved.checked);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_DESC").focus();
        });

        if (_LOA) {
            document.getElementById('_LOA').value = _LOA;
        }
        if (_TobeRemoved === 1) {
            document.getElementById('_TobeRemoved').checked = true;
        }
    }

    function ValidateItems(popupForm)
    {
        if (popupForm._AY.value.isEmpty())
        {
            popupForm._AY.focus();
            Swal.fire({title:"ERROR", text: "Academic Year information is not selected!!", icon:"error"});

            return false;
        }
        else if (popupForm._GPI.value.isEmpty())
        {
            popupForm._GPI.focus();
            Swal.fire({title:"ERROR", text: "Performance Indicator is not selected!!", icon:"error"});

            return false;
        }
        else if (popupForm._LOA.value.isEmpty())
        {
            popupForm._LOA.focus();
            Swal.fire({title:"ERROR", text: "Level of Attainment is not selected!!", icon:"error"});

            return false;
        }
        else if (popupForm._DESC.value.isEmpty())
        {
            popupForm._DESC.focus();
            Swal.fire({title:"ERROR", text: "Description is not entered!!", icon:"error"});

            return false;
        }
        return true;
    }
</script>
<?php } ?>

<script>

    function ShowDifferences_Perform(_AY1, _AY2)
    {
        const $form=$(document.createElement('form')).css({display:'none'}).attr("method","POST").attr("action","dept_assmntrubrics_diff.php");
        $form.append($(document.createElement('input')).attr('name','_AY1').val(_AY1));
        $form.append($(document.createElement('input')).attr('name','_AY2').val(_AY2));
        $("body").append($form);
        $form.submit();
    }

    function ShowDifferences()
    {
        const formContent = `
             <form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2"><div class="input-group" style="width:100%">
             			<div class="input-group" style="width:100%"><span class="input-group-addon" style="width:250px;">Academic Year 1<span style="color:red">*</span></span>
                  <select name="_AY1" id="_AY1" class="input-sm form-control"><option value=""></option></select>
                      </div>
             			<div class="input-group" style="width:100%"><span class="input-group-addon" style="width:250px;">Academic Year 2<span style="color:red">*</span></span>
                  <select name="_AY2" id="_AY2" class="input-sm form-control"><option value=""></option></select>
                      </div>
             </div></td></tr>
             </table></form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">SHOW DIFFERENCES IN AMRs</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> SHOW",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');
                        if (popupForm._AY1.value.isEmpty())
                        {
                            popupForm._AY1.focus();
                            Swal.fire({title:"ERROR", text: "Academic Year1 information is not selected!!", icon:"error"});
                            return false;
                        }
                        else if (popupForm._AY2.value.isEmpty())
                        {
                            popupForm._AY2.focus();
                            Swal.fire({title:"ERROR", text: "Academic Year2 information is not selected!!", icon:"error"});
                            return false;
                        }
                        else if (popupForm._AY1.value == popupForm._AY2.value)
                        {
                            popupForm._AY1.focus();
                            Swal.fire({title:"ERROR", text: "Academic Year1 & Year2 information cannot be the same!!", icon:"error"});
                            return false;
                        }

                        ShowDifferences_Perform(popupForm._AY1.value, popupForm._AY2.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            // Load the academic year options after the modal is shown
            AsyncGetOptions(2)
                .then(data => {
                    // Function to populate select options
                    const populateSelect = (selectId, options) => {
                        const select = document.getElementById(selectId);
                        options.forEach(({ value, text }) => {
                            const option = document.createElement('option');
                            option.value = value;
                            option.textContent = text;
                            select.appendChild(option);
                        });
                        return select;
                    };

                    // Populate both selects
                    const selectYearFrom = populateSelect('_AY1', data);
                    const selectYearTo = populateSelect('_AY2', data);
                })
                .catch(error => {
                    console.error('Error loading academic years:', error);
                    Swal.fire({
                        title: "ERROR",
                        text: "Failed to load academic year options",
                        icon: "error"
                    });
                });
        });
    }

</script>


<script class="init">
    $(document).ready(function() {
        const szURL = 'ssps/dept_assmntrubrics_ssps.php?_AY=';

        const DataTable_Info = $("#AssessmentMasterRubrics").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            stateSave: true,
            processing: true,
            serverSide: true,
            lengthMenu: [ 30, 50, 100, 150, 300 ],
            ajax: `${szURL}<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>`,
            oLanguage: {sInfoFiltered: ''},
            columns: [
                { data: 'AcademicYearInfo' },
                { data: 'LOATXT' },
                {
                    data: 'Description',
                    render: function(data, type, row) {
                        // Add the <s> tag around the Description content if it will be removed.
                        if (row.TobeRemoved === 1)
                            return '<s>' + data + '</s>';
                        return data;
                    }
                },
                { data: 'Comments' },
                { data: 'Approval' },
                <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                { data: '' } // used for representing menu options
                <?php } ?>
            ],
            fnInitComplete: function(oSettings, json) {
                // Add "Clear Filter" button to Filter
                const btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                    $('#' + oSettings.sTableId).dataTable().fnFilter('');
                });
            },
            fnDrawCallback: function() {
                this.api().state.clear(); // cancel "stateSave" after reload the page
                $('#AssessmentMasterRubrics tr td:nth-child(1)').css('text-align', 'center');
                $('#AssessmentMasterRubrics tr td:nth-child(2)').css('text-align', 'center');
                $('#AssessmentMasterRubrics tr td:nth-child(3)').css('text-align', 'center');
                $('#AssessmentMasterRubrics tr td:nth-child(4)').css('text-align', 'center');
            },
            columnDefs: [
                {
                    targets  : 'no-sort',
                    orderable: false,
                },
                <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                {
                    targets: -1,
                    data: null,
                    orderable: false,
                    defaultContent: '<div style="width:100%;text-align:center;"><button id="modify" class="btn btn-danger btn-xs glyphicon glyphicon-wrench" style="min-height: 20px;"></button></div>'
                }
                <?php } ?>
            ],
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'landscape',
                    title: getTitleText,
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> PDF',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff; margin-left:8px;'
                    },
                    exportOptions: {
                        columns: [ 0, 1, 2, 3, 4 ]
                    },
                    customize: function(doc) {
                        doc.styles.tableHeader.fontSize = 9;
                        doc.defaultStyle.fontSize = 8; // change default fontsize
                    }
                },
                {
                    extend: 'excelHtml5',
                    title: getTitleText,
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff;'
                    },
                    exportOptions: {
                        columns: [ 0, 1, 2, 3, 4 ]
                    }
                }
            ]
        });

        // Helper function for title
        function getTitleText() {
            const program = document.forms["changefrm"]["CH_APR"].options[document.forms["changefrm"]["CH_APR"].selectedIndex].text;
            const academicYear = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].text;
            return `Master Assessment Rubrics (${program} ${academicYear})`;
        }

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_Info.ajax.url(tmpURL).load();
        });

        // Setup - add a text input to each footer cell
        $('#AssessmentMasterRubrics tfoot th').each( function (index, value) {
            const title = $(this).text();
            $(this).html( '<input type="text" placeholder="Search '+title+'" value="'+DataTable_Info.column(index).search()+'" style="color:black; width: 100%;padding:1px;box-sizing: border-box;"/>' );
        } );

        // Apply the search
        DataTable_Info.columns().every( function () {
            let that = this;
            $( 'input', this.footer() ).on( 'keyup change', function () {
                if ( that.search() !== this.value ) {
                    that
                        .search( this.value )
                        .draw();
                }
            });
        } );

        <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
        $('#AssessmentMasterRubrics tbody').on( 'click', '#modify', function () {
            const data = DataTable_Info.row( $(this).parents('tr') ).data();
            ModifyAssessmentMasterRubric(data.Idx, data.AcademicYear, data.GPI, data.LOA, data.Description, data.Comments, data.Approval, data.TobeRemoved);
        } );
        <?php } ?>

        // Set the DataTable in AsyncCommons
        async_commons.setDataTable(DataTable_Info);
    } );

</script>

<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">ASSESSMENT MASTER RUBRICS (AMRs)</span></p>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <?php
        if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
            include('control_selprogram.php');
        } else {
            include('control_allprograms.php');
        }
        ?>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:30%;">
                    <?php
                        if( $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true ) echo($AcademicYearSelectionOptions);
                    ?>
                </td>
                <td style="width:10%;"></td>
                <td style="width:50%; text-align: right">
                    <button class="btn btn-danger btn-sm" onclick="ShowDifferences();return false;">CHECK DIFFERENCES</button>
                </td>
            </tr>
        </table>

        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="AssessmentMasterRubrics" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th style="width:80px">ACADEMIC YEAR</th>
                    <th style="width:100px">LEVEL OF ATTAINMENT</th>
                    <th>LEVEL OF ATTAINMENT DESCRIPTION</th>
                    <th>REVISION COMMENTS</th>
                    <th>REVISION APPROVAL</th>
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <th style="width:100px" class="no-sort">OPERATION</th>
                    <?php } ?>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th>ACADEMIC YEAR</th>
                    <th>LEVEL OF ATTAINMENT</th>
                    <th>LEVEL OF ATTAINMENT DESCRIPTION</th>
                    <th>REVISION COMMENTS</th>
                    <th>REVISION APPROVAL</th>
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <th></th>
                    <?php } ?>
                </tr>
                </tfoot>
            </table>
        </div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-wrench" style="pointer-events: none;"></span>: Modify AMR/
                    <?php } ?>
                </td>
            </tr>
        </table>
    </div>
</div>

<?php include('footer.php');?>

