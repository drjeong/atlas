<?php
/**
 * Listing PIs
 * File: dept_abetcourses_gpilist_ssps.php
 * Description: listing performance indicators in a dialog window
 *
 * 03/09/2023 - Removed the checking of AbetCourseIdx (not necessary to be checked)
 *
 */

include_once 'session_handler.php';

$AcademicYear='';
$StudentOutcomes='';
$AbetCourseIdx='';
if (array_key_exists('_AY', $_GET) ) {
    $AcademicYear = trim($_GET['_AY']);
}
if (array_key_exists('_SO', $_GET) ) {
    $StudentOutcomes = trim($_GET['_SO']);
}
if (array_key_exists('_IDX', $_GET) ) {
    $AbetCourseIdx = trim($_GET['_IDX']);
}

// DB table to use
$table = 'GeneralPerformanceIndicators';
$joinQuery = "FROM `{$table}` AS `PI` 
    INNER JOIN `StudentOutcomes` AS `SO` 
        ON (`SO`.`Idx` = `PI`.`SOIdx` 
        AND `SO`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' 
        AND `PI`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."') 
    INNER JOIN `AbetCourses_SOs` AS `ABETCRSESSOS` 
        ON (`ABETCRSESSOS`.`SOIdx` = `SO`.`Idx` 
        AND `ABETCRSESSOS`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."') ";

// Table's primary key
$primaryKey = '`PI`.`Idx`';

// Array of database columns
$columns = array(
    array('db' => '`PI`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_'.$row[0];
    }),
    array( 'db' => '`PI`.`Idx`', 'dt' => 'PIIdx', 'field' => 'PIIdx', 'as' => 'PIIdx'),
    array( 'db' => '`SO`.`SO`', 'dt' => 'SO', 'field' => 'SO', 'as' => 'SO'),
    array( 'db' => '`ABETCRSESSOS`.`SOIdx`', 'dt' => 'SOIdx', 'field' => 'SOIdx', 'as' => 'SOIdx'),
    array( 'db' => '`PI`.`GPI`', 'dt' => 'PI', 'field' => 'PI', 'as' => 'PI'),
    array( 'db' => '`PI`.`Description`', 'dt' => 'Desc', 'field' => 'Description', 'as' => 'Description')
);

require( 'ssp.join.class.php' );
$extraWhere = "`PI`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";
if ($AcademicYear != "" && $AcademicYear != "all") {
    $extraWhere .= " AND `PI`.`AcademicYear`='" . $AcademicYear . "'";
}

if ($StudentOutcomes !=""){
    $so_condition = '';
    $SO_Array = explode( ',', $StudentOutcomes );
    foreach($SO_Array AS $SO){
        if ($so_condition != "") $so_condition .= " OR ";
        $so_condition .= "`PI`.`SOIdx` = ".intval(trim($SO)); // Added intval for SQL injection protection
    }
    $extraWhere .= " AND (" . $so_condition . ")";
}

// Include all non-aggregated columns in GROUP BY
$groupBy = "`PI`.`Idx`, `PI`.`GPI`, `PI`.`Description`, `SO`.`SO`, `ABETCRSESSOS`.`SOIdx`";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);