<?php
/**
 * Program Assessment Assignments By Courses
 * File: p_aabycrs.php
 * Description: Listing program assessment assignments by courses.
 *
 * -- 03/05/2021 Add an exception handling for assignment description
 * -- 05/22/2026 Fixed undefined array key warnings - Undefined array key "AssignmentDescription"
 *
 */

include('header.php');

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection(false);

$AbetCourseSubject=null;
$AbetCourseNum=null;
if (isset($_POST['_ABTCSUB']) && isset($_POST['_ABTCNUM'])) { // user changed
    $AbetCourseSubject = trim($_POST['_ABTCSUB']);
    $AbetCourseNum = trim($_POST['_ABTCNUM']);
}

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

?>

    <script type="text/javascript">

        function fetchassessmentassignments(abetcsub, abetcnum, ayear)
        {
            let form = document.createElement("form");
            form.method = "POST";
            form.action = "p_aabycrs.php";

            let element;
            element = document.createElement("input");
            element.setAttribute("type", "hidden");
            element.value=ayear;
            element.name="_AY";
            form.appendChild(element);

            element = document.createElement("input");
            element.setAttribute("type", "hidden");
            element.value=abetcsub;
            element.name="_ABTCSUB";
            form.appendChild(element);

            element = document.createElement("input");
            element.setAttribute("type", "hidden");
            element.value=abetcnum;
            element.name="_ABTCNUM";
            form.appendChild(element);

            document.body.appendChild(form);
            form.submit();
        }

        $(document).ready(function() {

            // Add event listener to the select element
            $("#_AY").on('change', function() {
                document.academicyear.submit();
            });
        });
    </script>

    <div class="pagebacklayout">
        <div class="row">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">ASSESSMENT ASSIGNMENTS BY COURSE</p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <?php include('control_allprograms.php'); ?>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:30%;">
                        <div class="row">
                            <div class="col-lg-8"> <!-- Changed to center the component -->
                                <?php echo($AcademicYearSelection);?>
                            </div>
                        </div>
                    </td>
                    <td style="width:10%"></td>
                    <td style="width:60%; text-align: right">
                    </td>
                </tr>
            </table>

            <?php
            require_once(__DIR__ . '/php_include/dbconnection_class.php');
            $DBCONNECTION = new Dbconnection();

            $AbetCourseAvailable = false;

            $Query = "CALL SP_FetchAbetCourses('".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."', '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."');";
            //                echo ($Query);
            $DBCONNECTION->sendquery($Query);

            $coursesList = '';
            while ($row = $DBCONNECTION->fetch_assoc())
            {
                $AbetCourseAvailable = true;
                if ($AbetCourseSubject == null){
                    $AbetCourseSubject = $row['Subject'];
                    $AbetCourseNum = $row['Num'];
                }

                $course = $row['Subject'] . ' ' . $row['Num']. ' ' . $row['Title'];
                $coursesList .= '<a href="#" class="list-group-item list-group-item-action bg-light';
                if ($AbetCourseSubject == $row['Subject'] && $AbetCourseNum == $row['Num']) $coursesList .= ' active ';
                $coursesList .= '" onclick="fetchassessmentassignments(\''.$row['Subject'].'\', \''.$row['Num'].'\', \''.$_SESSION['ATLAS_SELECTED_ACADEMICYEAR'].'\');">'.$course.'</a>';
            }

            if ($AbetCourseAvailable == false){
                // Show full-width message when no courses available
                echo <<<HTML
        <div class='col-md-12'>
            <div class="alert alert-info text-center" role="alert" style="padding: 40px; margin: 20px 0;">
                <h4 class="alert-heading">No ABET Courses Available</h4>
                <p class="mb-0">There are currently no ABET courses available for the selected academic year and program.</p>
                <hr>
                <p class="mb-0">Please select a different academic year or contact your administrator if you believe this is an error.</p>
            </div>
        </div>
HTML;
            } else {
                // Show normal two-column layout when courses exist
                echo <<<HTML
        <div class='col-md-2'>
            <!-- Sidebar -->
            <div class="list-group list-group-flush">
                $coursesList
            </div>
            <!-- /#sidebar-wrapper -->
        </div>

        <div class='col-md-10'>
            <!-- Page Content -->
            <div id="pagebacklayout_inner_noborder">
                <div id="assessment_content">
HTML;

                /////////////////////////////////////////////////////////////////////////////////
                // fetch course assessment information
                $Query = "CALL SP_FetchAbetCourseAssessments('$AbetCourseSubject', '$AbetCourseNum', '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."', '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."');";
                //        echo ($Query);
                $DBCONNECTION->sendquery($Query);
                while ($row = $DBCONNECTION->fetch_assoc()) {
                    $ABCIdx = $row['ABCIdx'];
                    $AVCIdx = $row['AVCIdx'];
                    $SO_array = explode('|', $row['SO']);
                    $DESC_array = explode('|', $row['DESC']);
                    $Instructor = $row['Instructor'];
                    $CourseNo = $row['CourseNo'];
                    $Title = $row['Title'];
                    $Credits = $row['Credits'];
                    $Semester = $row['Semester'];
                    $AssignmentType_array = explode('|', $row['AssignmentType']);
                    $Measures_array = explode('|', $row['Measures']);
                    $AssignmentProblems_array = explode('|', $row['AssignmentProblems']);
                    $AssignmentSamples_array = explode('|', $row['ActualAssmntSamples']);
                    $AssignmentDescriptions_array = explode('|', $row['AssignmentDescriptions']);
                    $AcademicYear = $row['AcademicYear'];

                    // Initialize Measures array - First pass: create structure
                    $Measures = array();
                    foreach($Measures_array as $Measure){
                        if (empty($Measure)) continue; // Skip empty entries
                        $Tmp = explode(':', $Measure);
                        if (isset($Tmp[0]) && $Tmp[0] !== '') {
                            $Measures[$Tmp[0]] = [
                                'idx' => (isset($Tmp[1]) && $Tmp[1] !== '') ? $Tmp[1] : '',
                                'AssignmentProblem' => '',
                                'AssignmentSample' => '',
                                'AssignmentDescription' => ''
                            ];
                        }
                    }

                    // Second pass: Update AssignmentProblem
                    foreach($AssignmentProblems_array as $AssignmentProblem){
                        if (empty($AssignmentProblem)) continue;
                        $Tmp = explode(':', $AssignmentProblem);
                        if (isset($Tmp[0]) && isset($Measures[$Tmp[0]])) {
                            $Measures[$Tmp[0]]['AssignmentProblem'] = (isset($Tmp[1]) && $Tmp[1] !== '') ? $Tmp[1] : '';
                        }
                    }

                    // Third pass: Update AssignmentSample
                    foreach($AssignmentSamples_array as $AssignmentSample){
                        if (empty($AssignmentSample)) continue;
                        $Tmp = explode(':', $AssignmentSample);
                        if (isset($Tmp[0]) && isset($Measures[$Tmp[0]])) {
                            $Measures[$Tmp[0]]['AssignmentSample'] = (isset($Tmp[1]) && $Tmp[1] !== '') ? $Tmp[1] : '';
                        }
                    }

                    // Fourth pass: Update AssignmentDescription
                    foreach($AssignmentDescriptions_array as $AssignmentDescription){
                        if (empty($AssignmentDescription)) continue;
                        $Tmp = explode(':', $AssignmentDescription);
                        if (isset($Tmp[0]) && isset($Measures[$Tmp[0]])) {
                            $Measures[$Tmp[0]]['AssignmentDescription'] = (isset($Tmp[1]) && $Tmp[1] !== '') ? $Tmp[1] : '';
                        }
                    }

                    echo <<<HTML
                    <div class="boxcontainer">
                        <p>
                        <h4>$CourseNo $Title</h4>
                        <h5>
                            Semester: $Semester<br/>
                            Credit Hours: $Credits<br/>
                            Professor: $Instructor
                        </h5>
                        </p>
HTML;
                    for ($i = 0; $i < count($SO_array); $i++) {
                        $SO = $SO_array[$i];
                        $SODESC = $DESC_array[$i];

                        echo <<<HTML
                        <div class="box-row">
                            <div class="box-cell box1">
                                <b> $SODESC </b> 
                            </div>
                            <div class="box-cell box2">
HTML;

                        for ($j=0; $j<count($AssignmentType_array); ++$j) {
                            $AssignmentType = $AssignmentType_array[$j];
                            $AT_array = explode(':', $AssignmentType);

                            // Make sure we have all required parts and the measure exists
                            if (count($AT_array) >= 3 && isset($AT_array[0]) && isset($AT_array[1]) && isset($AT_array[2])) {
                                if ($SO == $AT_array[0] && $AT_array[1] != '' && isset($Measures[$AT_array[1]])) {
                                    $measure = $Measures[$AT_array[1]];

                                    echo ('<div style="width:100%; border: 1px solid black; padding-top: 2px; padding-bottom: 2px; background-color: cornsilk;">');
                                    echo ('<div style="padding-top: 2px; padding-bottom: 2px; background-color: lightsteelblue">');
                                    echo ('<span style="font-weight: bold;">[Measure '.$measure['idx']. ']</span> ');
                                    echo(htmlspecialchars($AT_array[2]));

                                    if (!empty($measure['AssignmentSample'])) {
                                        echo ('&nbsp;<a href="pdf_viewer.php?pdf='.urlencode($measure['AssignmentSample']).'&cn=213432394&ayinfo='.urlencode($AcademicYear).'" style="color: red;">[ACTUAL ASSESSMENT SAMPLE PDF]</a>');
                                    }
                                    echo ('</div>');

                                    echo ('<div style="width:100%; "> ');
                                    if (!empty($measure['AssignmentProblem'])) {
                                        echo('<span style="font-weight: bold;">Problem / Portion:</span> '.htmlspecialchars($measure['AssignmentProblem']) . '<br/>');
                                    }
                                    if (!empty($measure['AssignmentDescription'])) {
                                        echo('<span style="font-weight: bold;">Description:</span> '.htmlspecialchars($measure['AssignmentDescription']));
                                    }
                                    echo ('</div></div>');
                                    echo ('<br/>');
                                }
                            }
                        }
                        echo('</div>');
                        echo('</div>');
                    }
                    echo <<<HTML
                    </div>
                </div>
HTML;

                }

                echo <<<HTML
                </div>
            </div>
            <!-- /#page-content-wrapper -->
        </div>
HTML;
            }

            unset($DBCONNECTION);
            ?>

        </div>
    </div>

<?php include('footer.php');?>