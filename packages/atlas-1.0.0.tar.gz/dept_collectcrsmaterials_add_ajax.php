<?php
/**
 * Add Abet Course
 * Description: Adding abet course
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$AcademicYearIdx='';
$CourseIdxes='';

if (array_key_exists('ay', $_POST) && array_key_exists('crses', $_POST))
{
    $AcademicYearIdx = trim($_POST['ay']);
    $CourseIdxes = trim($_POST['crses']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

if ($AcademicYearIdx=="" || $CourseIdxes==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    $CourseIdxes_Array = explode( '|', $CourseIdxes );

    $MultiQuery = "";
    foreach ($CourseIdxes_Array AS $AvailableCourseIdx) {
        // Validate inputs
        $AvailableCourseIdx = filter_var($AvailableCourseIdx, FILTER_VALIDATE_INT);
        if ($AvailableCourseIdx === false) {
            throw new Exception('Invalid course info');
        }
        $MultiQuery .= "CALL SP_UpdateAvailableCourse_CollectMaterials('$AvailableCourseIdx', 1);";
    }

//    error_log($MultiQuery);
    $DBCONNECTION->sendmultiquery($MultiQuery);

    echo "0x11111111";
} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00310001') !== false) {
        echo '0x00310001';  // Cannot change setting: course materials are collected already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
