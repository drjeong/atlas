<?php
/**
 * Listing courses
 * Description: listing courses in a dialog window
 *
 * 11/19/2024 - initial version created
 *
 */

include_once 'session_handler.php';

$_Subject = (isset($_GET['sub'])) ? trim($_GET['sub']) : '';
$_Num = (isset($_GET['num'])) ? trim($_GET['num']) : '';
$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';

if (empty($AcademicProgramIdx) || empty($_Subject) || empty($_Num)) {
    die(json_encode(['error' => 'Missing required parameters']));
}

// DB table to use
$table = 'AbetSyllabus';

$joinQuery = "FROM `{$table}` AS `ABS` 
    INNER JOIN `Courses` AS `CRSES` 
        ON `ABS`.`CourseIndex` = `CRSES`.`Idx`
    LEFT JOIN `AcademicPrograms` AS `APS`
        ON `ABS`.`AcademicProgram` = `APS`.`Idx`";

// Table's primary key
$primaryKey = '`CRSES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`ABS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`ABS`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`CRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`CRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`CRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`CRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`ABS`.`Idx`', 'dt' => 'ABSIdx', 'field' => 'ABSIdx', 'as' => 'ABSIdx'),
    array( 'db' => '`APS`.`Idx`', 'dt' => 'APIdx', 'field' => 'APIdx', 'as' => 'APIdx'),
    array( 'db' => '`APS`.`Name`', 'dt' => 'APName', 'field' => 'APName', 'as' => 'APName'),
    array( 'db' => '`APS`.`Degree`', 'dt' => 'APDegree', 'field' => 'APDegree', 'as' => 'APDegree')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = " `ABS`.`AcademicProgram` <> {$AcademicProgramIdx} AND `ABS`.`RevisionDate` IS NOT NULL ";
$extraWhere .= " AND `CRSES`.`Subject` = '{$_Subject}' AND `CRSES`.`Num` = '{$_Num}'";
$extraWhere .= " 
    AND (`ABS`.`major_version`, `ABS`.`minor_version`) = (
    SELECT major_version, minor_version
        FROM `AbetSyllabus`
        WHERE `CourseIndex` = `ABS`.`CourseIndex`
        ORDER BY major_version DESC, minor_version DESC
        LIMIT 1
    ) AND `ABS`.`LinkedSyllabus` IS NULL";

$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

