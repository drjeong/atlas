<?php
/**
 * Assign Evaluator to Abet Courses
 * Description: Unassigning evaluator to the selected abet courses
 * Author: Dong Hyun Jeong
 *
 * 03/04/2024 - initial version created
 *
 */

include_once 'session_handler.php';

$AbetCourseIdx='';
if (array_key_exists('abetcrs', $_POST))
{
    $AbetCourseIdx = trim($_POST['abetcrs']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}
if ($AbetCourseIdx==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    $Query = "CALL SP_Evaluator_Unassign(?);";
    $DBCONNECTION->prepare_execute($Query, [$AbetCourseIdx]);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
