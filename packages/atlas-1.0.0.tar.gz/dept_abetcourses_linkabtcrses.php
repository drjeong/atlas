<?php
/**
 * Abet courses
 * Description: Listing abet courses to be shared for multiple degree programs
 * Author: Dong Hyun Jeong
 *
 * 12/20/2025 - initial version created
 */

include('checker_programdirector.php');
include('header.php');
?>

<?php

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection();

?>

    <script src="js/datatable-utils-search.min.js"></script>


    <script type="text/javascript">

        // Constants
        const ErrorCodes = {
            SUCCESS: '0x11111111',
            NO_SO_DATA: '0x00000100',
            NO_PI_DATA: '0x00000200',
            SAME_ITEM_EXIST: '0x00200011',
            CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
            DATA_COLLECTED_ALREADY: '0x00310001'
        };

        var DataTable_AbetCourseList = null;
        var DataTable_CoursesList = null;

        function EvaluateClassRoster(avcIdx, enrollment, crsinfo)
        {
            const formContent =
                `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <style>
                .dropped-student {
                    background-color: #ffebee !important;
                    color: #999 !important;
                    text-decoration: line-through;
                }
                .dropped-student:hover {
                    background-color: #ffcdd2 !important;
                }
            </style>
            <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                <table id="classrosterlist" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th style="width:50px;">NO.</th>
                        <th>STUDENT NAME</th>
                        <th>MAJOR</th>
                        <th>ACADEMIC PROGRAM</th>
                        <th>DEGREE</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>NO.</th>
                        <th>STUDENT NAME</th>
                        <th>MAJOR</th>
                        <th>ACADEMIC PROGRAM</th>
                        <th>DEGREE</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </form>`;

            createModalDialog({
                className: "dialogWidth60p",
                title: '<div style="text-align: left;">' +
                    '<span class="glyphicon glyphicon-education" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;' +
                    '<span style="font-size:16pt;font-weight: bold;">CLASS ROSTER</span><br>' +
                    '<span style="font-size:13pt;color:#666;font-weight:normal;margin-top:5px;display:inline-block;margin-left:30px;">' + crsinfo + ' &bull; ' + enrollment + ' Students</span>' +
                    '</div>',
                message: formContent,
                buttons: {
                    close: {
                        label: "<span class='glyphicon glyphicon-remove'></span> CLOSE",
                        className: 'btn-default',
                        callback: function(){
                        }
                    }
                }
            }).on('shown.bs.modal', function(){
            });

            DataTable_ClassRosterList = $("#classrosterlist").DataTable({
                processing: true,
                serverSide: false,
                iDisplayLength: 10,
                lengthChange: false,
                dom: `<"row"<"col-sm-6"<"filterControls">><"col-sm-6"<"pull-right"B>>>t<"row"<"col-sm-6"><"col-sm-6"p>>`,
                ajax: `ssps/m_avcourses_classroster_ssps.php?_AVCIDX=${avcIdx}`,
                order: [[ 0, 'asc' ]],
                fnDrawCallback: function() {
                    $('#classrosterlist tr td:nth-child(1)').css('text-align', 'center');
                },
                columns: [
                    { data: 'StudentNo' },
                    {
                        data: 'StudentName',
                        render: function(data, type, full, meta) {
                            if (type === 'export') {
                                return full.IsDropped === 1 ? data + ' (DROPPED)' : data;
                            }
                            if (full.IsDropped === 1) {
                                return data + ' <span class="label label-danger">DROPPED</span>';
                            }
                            return data;
                        }
                    },
                    { data: 'StudentMajor' },
                    { data: 'AcademicProgramName' },
                    { data: 'Degree' }
                ],
                columnDefs: [
                    {
                        targets: 'no-sort',
                        orderable: false,
                    }
                ],
                buttons: [
                    {
                        extend: 'excelHtml5',
                        title: `CLASS ROSTER ${crsinfo}`,
                        text: '<i class="fa fa-file-excel-o"></i> EXPORT TO EXCEL',
                        className: 'btn btn-xs',
                        attr: {
                            style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                        },
                        exportOptions: {
                            columns: [ 0, 1, 2, 3, 4 ],
                            modifier: {
                                selected: null
                            }
                        }
                    }
                ],
                createdRow: function(row, data, dataIndex) {
                    if (data.IsDropped === 1) {
                        $(row).addClass('dropped-student');
                    }
                }
            });

            new DataTableSearch('#classrosterlist', DataTable_ClassRosterList, ShowResetBtn=false);
        }

        async function performBulkUpdatePrimaryReference(updates) {
            try {
                // Find the primary course index
                const primaryUpdate = updates.find(u => u.isPrimary);
                const abcIdx_Primary = primaryUpdate ? primaryUpdate.abcIdx : null;

                if (!abcIdx_Primary) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Could not identify the Primary course.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                    return;
                }

                // Filter only courses that actually need updating
                const changesNeeded = updates.filter(update => {
                    const course = DataTable_AbetCourseList.rows().data().toArray().find(c => c.Idx === update.abcIdx);
                    const currentValue = course.ReferenceCrsAssessment === 0 || course.ReferenceCrsAssessment === null ? 0 : 1;
                    return currentValue !== update.newValue;
                });

                // Show progress dialog
                Swal.fire({
                    title: 'Updating Courses...',
                    html: `<p>Processing ${changesNeeded.length} course(s)...</p>
                   <div class="progress">
                       <div class="progress-bar progress-bar-striped active" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                           <span class="sr-only">0% Complete</span>
                       </div>
                   </div>`,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                let completed = 0;
                let errors = [];

                // Process each update sequentially
                for (let i = 0; i < changesNeeded.length; i++) {
                    const update = changesNeeded[i];

                    try {
                        // Make API call
                        const response = await async_commons.makeApiCall('dept_abetcourses_linkabtcrses_ajax.php', {
                            action: 'toggle_reference',
                            avcIdx: update.avcIdx,
                            abcIdx: update.abcIdx,
                            abcIdx_Primary: abcIdx_Primary,
                            reference_value: update.newValue
                        });

                        const code = response.trim();

                        switch (code) {
                            case ErrorCodes.SUCCESS: {
                                completed++;
                                break;
                            }
                            case ErrorCodes.CANNOT_CONNECT_SERVER: {
                                const course = DataTable_AbetCourseList.rows().data().toArray().find(c => c.Idx === update.abcIdx);
                                errors.push(`${course.Subject} ${course.Num}: Cannot connect to server`);
                                break;
                            }
                            default: {
                                const course = DataTable_AbetCourseList.rows().data().toArray().find(c => c.Idx === update.abcIdx);
                                errors.push(`${course.Subject} ${course.Num}: Unexpected response (${code})`);
                                break;
                            }
                        }
                    } catch (error) {
                        const course = DataTable_AbetCourseList.rows().data().toArray().find(c => c.Idx === update.abcIdx);
                        errors.push(`${course.Subject} ${course.Num}: ${error.message}`);
                    }

                    // Update progress bar
                    const progress = ((i + 1) / changesNeeded.length) * 100;
                    $('.progress-bar').css('width', progress + '%').attr('aria-valuenow', progress);
                    $('.progress-bar .sr-only').text(Math.round(progress) + '% Complete');
                }

                // Close progress dialog
                Swal.close();

                // Reload DataTable
                await async_commons.reloadDataTable(DataTable_AbetCourseList);

                // Show results
                if (errors.length === 0) {
                    await async_commons.showSuccessMessage_reloadPage(
                        'UPDATED',
                        `Successfully updated ${completed} course(s)!`,
                        2000,
                        false
                    );
                } else if (completed > 0) {
                    // Partial success
                    await Swal.fire({
                        title: 'Completed with Errors',
                        html: `
                            <p><strong>${completed} course(s) updated successfully</strong></p>
                            <p class="text-danger">${errors.length} course(s) failed:</p>
                            <ul style="text-align: left; max-height: 200px; overflow-y: auto;">
                                ${errors.map(e => `<li>${e}</li>`).join('')}
                            </ul>
                        `,
                        icon: 'warning',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#f0ad4e'
                    });
                } else {
                    // All failed
                    await Swal.fire({
                        title: 'Errors',
                        html: `Failed to update courses:<br><ul style="text-align: left;">${errors.map(e => `<li>${e}</li>`).join('')}</ul>`,
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#f0ad4e'
                    });
                }

            } catch (error) {
                await async_commons.handleError(error);
            }
        }

        async function performUnlinkAllCourses(courses) {
            try {
                // Show loading dialog
                Swal.fire({
                    title: 'Unlinking Courses...',
                    html: '<p>Please wait while we unlink all courses...</p>',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                // Extract avcIdx (should be same for all courses) and abcIdx list
                const avcIdx = courses[0].AVCIdx;
                const abcIdxList = courses.map(course => course.Idx);

                // Make API call to unlink all courses
                const response = await async_commons.makeApiCall('dept_abetcourses_linkabtcrses_unlinkall_ajax.php', {
                    action: 'unlink_all_courses',
                    avcIdx: avcIdx,
                    abcIdxList: abcIdxList
                });

                const code = response.trim();

                // Close loading dialog
                Swal.close();

                switch (code) {
                    case ErrorCodes.SUCCESS: {
                        // Reload DataTable
                        await async_commons.reloadDataTable(DataTable_AbetCourseList);

                        await async_commons.showSuccessMessage_reloadPage(
                            'UNLINKED',
                            `Successfully unlinked ${courses.length} course(s)! All courses are now independent.`,
                            2000,
                            false
                        );
                        break;
                    }
                    case ErrorCodes.CANNOT_CONNECT_SERVER: {
                        await Swal.fire({
                            title: 'Error',
                            text: 'Cannot connect to server',
                            icon: 'error',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#d9534f'
                        });
                        break;
                    }
                    default: {
                        await Swal.fire({
                            title: 'Error',
                            text: `Failed to unlink courses. Error code: ${code}`,
                            icon: 'error',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#d9534f'
                        });
                        break;
                    }
                }

            } catch (error) {
                await async_commons.handleError(error);
            }
        }

    </script>

    <script class="init">
        $(document).ready(function() {
            const SelectedAcademicYear = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].value;
            const szURL = 'ssps/dept_abetcourses_linkabtcrses_ssps.php?_AY=';

            // Helper function to safely get the academic year text
            function getAcademicYearText() {
                try {
                    if (document.forms["academicyear"]) {
                        return document.forms["academicyear"]["_AY"].options[document.forms["academicyear"]["_AY"].selectedIndex].text;
                    }
                    return '';
                } catch(e) {
                    return '';
                }
            }

            DataTable_AbetCourseList = $("#AbetCourses").DataTable({
                dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
                stateSave: true,
                processing: true,
                serverSide: true,
                lengthMenu: [30, 50, 100, 150, 200, 300, 400],
                ajax: `${szURL}<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>`,
                oLanguage: {
                    sInfoFiltered: ""
                },
                // Default ordering by Semester, CRN, Subject, Number
                order: [[0, "asc"], [1, "asc"], [2, "asc"], [3, "asc"]],
                ordering: false,  // Disable all sorting

                // Column definitions
                columns: [
                    { data: 'Semester', className: 'text-center' },
                    { data: 'CRN', className: 'text-center' },
                    { data: 'Subject', className: 'text-center' },
                    { data: 'Num', className: 'text-center' },
                    { data: 'Title', className: 'text-center' },
                    { data: 'Credits', className: 'text-center' },
                    { data: 'Instructor', className: 'text-center' },
                    { data: 'Requirement', className: 'text-center' },
                    { data: 'Level', className: 'text-center' },
                    { data: 'StudentOutcomes' },
                    {
                        data: 'PIs',
                        render: (data, type, row) => {
                            return row.PIs.split(",")
                                .filter(item => item.includes("-"))
                                .map(item => item.trim())
                                .join(", ");
                        }
                    },
                    { data: 'AcademicProgramName' },
                    {
                        data: 'ReferenceCrsAssessment',
                        render: (data, type, row) => {
                            const isPrimary = (data === 0 || data === null);
                            let btnClass = isPrimary ? 'btn-warning' : 'btn-info';
                            let icon = isPrimary ? 'glyphicon-star' : 'glyphicon-link';
                            let text = isPrimary ? 'Primary' : 'Reference';
                            let title = isPrimary ? 'Click to set as Reference' : 'Click to set as Primary';

                            return `<button class="btn ${btnClass} btn-xs toggle-reference"
                            data-avcidx="${row.AVCIdx}"
                            data-abcidx="${row.Idx}"
                            data-current="${data}"
                            title="${title}"
                            style="width: 95px; text-align: center;">
                            <span class="glyphicon ${icon}"></span> ${text}
                            </button>`;
                        }
                    },
                    { data: "", className: 'text-center' }
                ],

                // Styling callbacks
                fnInitComplete: function(settings) {
                    const btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                    btnClear.appendTo($('#' + settings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                    btnClear.click(() => $('#' + settings.sTableId).dataTable().fnFilter(''));
                },

                rowCallback: function(row, data, index) {
                    // Create a unique key for grouping based on SEMESTER, CRN, SUBJECT, NUMBER, TITLE
                    const groupKey = `${data.Semester}-${data.CRN}-${data.Subject}-${data.Num}-${data.Title}`;

                    // Store the key as a data attribute on the row
                    $(row).attr('data-group-key', groupKey);
                },

                fnDrawCallback: function() {
                    this.api().state.clear(); // cancel "stateSave" after reload the page

                    // Cell widths (existing code)
                    const cellWidths = {
                        1: '80px',
                        2: '80px',
                        3: '80px'
                    };
                    const minWidths = {
                        4: '150px',
                        5: '80px',
                        6: '80px',
                        7: '80px',
                        8: '80px',
                        9: '80px',
                        10: '80px',
                        11: '150px'
                    };

                    Object.entries(cellWidths).forEach(([col, width]) => {
                        $(`#AbetCourses tr td:nth-child(${col})`).css('width', width);
                    });
                    Object.entries(minWidths).forEach(([col, width]) => {
                        $(`#AbetCourses tr td:nth-child(${col})`).css('min-width', width);
                    });

                    // Apply alternating background colors to groups
                    const groupedRows = {};
                    $('#AbetCourses tbody tr').each(function() {
                        const groupKey = $(this).attr('data-group-key');
                        if (!groupedRows[groupKey]) {
                            groupedRows[groupKey] = [];
                        }
                        groupedRows[groupKey].push(this);
                    });

                    // Define color palette for groups
                    const colors = [
                        '#f0f8ff', // Alice blue
                        '#fff5ee', // Seashell
                        '#f0fff0', // Honeydew
                        '#fffacd', // Lemon chiffon
                        '#ffe4e1', // Misty rose
                        '#f0ffff', // Azure
                        '#fff0f5', // Lavender blush
                        '#f5f5dc'  // Beige
                    ];

                    let colorIndex = 0;
                    Object.keys(groupedRows).forEach(groupKey => {
                        const rows = groupedRows[groupKey];
                        if (rows.length > 1) {
                            // Only highlight if there are multiple rows in the group
                            const color = colors[colorIndex % colors.length];
                            rows.forEach(row => {
                                $(row).css('background-color', color);
                            });
                            colorIndex++;
                        }
                    });
                },

                columnDefs: [
                    {
                        targets: '_all',  // Apply to all columns
                        orderable: false
                    },
                    {
                        targets: -1,
                        data: null,
                        orderable: false,
                        render: function(data, type, row) {
                            const classRosterDisabled = row.HasClassRoster == 1 ? '' : 'disabled';
                            const classRosterTitle = row.HasClassRoster == 1 ? 'Class roster' : 'No class roster available';
                            const classRosterStyle = row.HasClassRoster == 1 ? 'min-height: 20px;' : 'min-height: 20px; opacity: 0.5; cursor: not-allowed;';

                            return '<div>'
                                + '<button id="evaluateclassroster" alt="Class roster" title="' + classRosterTitle + '" class="btn btn-danger btn-xs glyphicon glyphicon-education" style="' + classRosterStyle + '" ' + classRosterDisabled + '></button>&nbsp;'
                                + '</div>';
                        }
                    }
                ],

                buttons: [
                    {
                        extend: 'pdfHtml5',
                        orientation: 'landscape',
                        title: function() {
                            return `COURSES TO BE SHARED ACROSS PROGRAMS (${getAcademicYearText()})`;
                        },
                        text: '<span class="glyphicon glyphicon-floppy-save"></span> PDF',
                        className: 'btn btn-xs',
                        attr: {
                            style: 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff; margin-left:8px;'
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                        },
                        customize: doc => {
                            // Font size adjustments
                            doc.styles.tableHeader.fontSize = 9;
                            doc.defaultStyle.fontSize = 8;

                            // Set page size to US Letter
                            doc.pageSize = 'LETTER';

                            // Reduce margins to maximize space (in points, 72 points = 1 inch)
                            doc.pageMargins = [20, 20, 20, 20]; // [left, top, right, bottom]

                            // Set column widths
                            doc.content[1].table.widths = ['7%', '5%', '6%', '6%', '11%', '6%', '10%', '10%', '10%', '10%', '10%', '10%'];

                            // Enhanced styling
                            doc.styles.tableHeader.alignment = 'left';
                            doc.styles.tableBodyEven = doc.styles.tableBodyOdd;
                            doc.styles.tableHeader.bold = true;
                        },
                        pageSize: 'LETTER'
                    },
                    {
                        extend: 'excelHtml5',
                        title: function() {
                            return `COURSES TO BE SHARED ACROSS PROGRAMS (${getAcademicYearText()})`;
                        },
                        text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                        className: 'btn btn-xs',
                        attr: {
                            style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff;'
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                        }
                    }
                ]
            });

            // Add event listener to the select element
            $("#_AY").on('change', function() {
                const tmpURL = szURL + this.value;
                DataTable_AbetCourseList.ajax.url(tmpURL).load();
            });

            // Initialize the column search functionality
            if (typeof DataTableSearch !== 'undefined') {
                new DataTableSearch('#AbetCourses', DataTable_AbetCourseList);
            }

            // Set the DataTable in AsyncCommons
            if (typeof async_commons !== 'undefined') {
                async_commons.setDataTable(DataTable_AbetCourseList);
            }

            $('#AbetCourses tbody').on('click', '#evaluateclassroster', function () {
                const data = DataTable_AbetCourseList.row($(this).parents('tr')).data();
                if (typeof EvaluateClassRoster !== 'undefined') {
                    EvaluateClassRoster(data.AVCIdx, data.Enrollment, data.AcademicYearInfo + ' - ' + data.CRN + ' - ' + data.Subject + ' ' + data.Num + ' ' + data.Title);
                }
                return false;  // disable row selection action
            });


            $('#AbetCourses tbody').on('click', '.toggle-reference', function(e) {
                e.preventDefault();
                e.stopPropagation();

                const button = $(this);
                const avcIdx = button.data('avcidx');
                const abcIdx = button.data('abcidx');

                // Get all courses with the same AVCIdx
                const allData = DataTable_AbetCourseList.rows().data().toArray();
                const relatedCourses = allData.filter(course => course.AVCIdx === avcIdx);
                // console.log(relatedCourses);

                // If only one course exists, show a message
                if (relatedCourses.length === 1) {
                    Swal.fire({
                        title: 'No Related Courses',
                        html: '<p>This is the only course instance. It must remain as Primary.</p>',
                        icon: 'info',
                        confirmButtonText: 'OK'
                    });
                    return false;
                }

                // Check if all courses have the same PIs and StudentOutcomes
                const firstCourse = relatedCourses[0];
                const firstPIs = firstCourse.PIs ? firstCourse.PIs.split(',').map(s => s.trim()).sort().join(',') : '';
                const firstSOs = firstCourse.StudentOutcomes ? firstCourse.StudentOutcomes.split(',').map(s => s.trim()).sort().join(',') : '';

                let hasMismatch = false;
                let mismatchDetails = [];

                for (let i = 1; i < relatedCourses.length; i++) {
                    const course = relatedCourses[i];
                    const coursePIs = course.PIs ? course.PIs.split(',').map(s => s.trim()).sort().join(',') : '';
                    const courseSOs = course.StudentOutcomes ? course.StudentOutcomes.split(',').map(s => s.trim()).sort().join(',') : '';

                    if (coursePIs !== firstPIs || courseSOs !== firstSOs) {
                        hasMismatch = true;
                        mismatchDetails.push({
                            course: `${course.Subject} ${course.Num} - ${course.AcademicProgramName}`,
                            pis: course.PIs || 'None',
                            sos: course.StudentOutcomes || 'None'
                        });
                    }
                }

                // If there's a mismatch, show error and prevent proceeding
                if (hasMismatch) {
                    const mismatchListHtml = mismatchDetails.map(detail => `
                    <li style="margin-bottom: 8px;">
                        <strong style="font-size: 13px;">${detail.course}</strong><br>
                        <small style="font-size: 12px;">PIs: ${detail.pis}</small><br>
                        <small style="font-size: 12px;">Student Outcomes: ${detail.sos}</small>
                    </li>
                `).join('');

                    Swal.fire({
                        title: 'Cannot Manage References',
                        html: `
                            <style>
                                .swal2-popup {
                                    width: 800px !important;
                                    max-width: 90% !important;
                                }
                            </style>
                            <div style="text-align: left; font-size: 13px;">
                                <p style="margin-bottom: 12px; font-size: 12px;">
                                    All course instances must have the same Performance Indicators (PIs) and Student Outcomes before managing references.
                                </p>
                                <p style="margin-bottom: 8px; font-size: 13px; font-weight: bold;">Reference Course:</p>
                                <ul style="list-style: none; padding-left: 0; margin-bottom: 12px;">
                                    <li style="margin-bottom: 8px;">
                                        <strong style="font-size: 13px;">${firstCourse.Subject} ${firstCourse.Num} - ${firstCourse.AcademicProgramName}</strong><br>
                                        <small style="font-size: 12px;">PIs: ${firstCourse.PIs || 'None'}</small><br>
                                        <small style="font-size: 12px;">Student Outcomes: ${firstCourse.StudentOutcomes || 'None'}</small>
                                    </li>
                                </ul>
                                <p style="margin-bottom: 8px; font-size: 13px; font-weight: bold;">Courses with different PIs/Outcomes:</p>
                                <ul style="list-style: none; padding-left: 0; margin-bottom: 12px;">
                                    ${mismatchListHtml}
                                </ul>
                                <p class="text-danger" style="margin-top: 12px; font-size: 13px;">
                                    <i class="glyphicon glyphicon-exclamation-sign"></i>
                                    Please ensure all course instances have identical PIs and Student Outcomes before proceeding.
                                </p>
                            </div>
                        `,
                        icon: 'warning',
                        confirmButtonText: 'OK'
                    });
                    return false;
                }

                // Build the course selection interface
                const courseListHtml = relatedCourses.map(course => {
                    const isPrimary = course.ReferenceCrsAssessment === 0 || course.ReferenceCrsAssessment === null;
                    const hasAssessments = course.ExistCrsAssessment === 1;
                    const isCurrent = course.Idx === abcIdx;

                    return `
                        <div class="course-option" style="padding: 12px; margin: 8px 0; border: 1px solid #ddd; border-radius: 4px; ${isCurrent ? 'background-color: #f0f8ff; border-color: #5bc0de;' : ''}">
                            <div style="display: flex; align-items: center; justify-content: space-between; gap: 15px;">
                                <div style="flex: 1; font-size: 14px;">
                                    <strong style="font-size: 15px;">${course.Subject} ${course.Num}</strong>
                                    <span style="font-size: 13px; color: #666;">- ${course.AcademicProgramName}</span>
                                    ${isCurrent ? '<span class="label label-default" style="font-size: 11px; margin-left: 5px;">Current</span>' : ''}
                                    ${hasAssessments ? '<span class="label label-success" style="font-size: 11px; margin-left: 5px;"><i class="glyphicon glyphicon-file"></i> Has Assessments</span>' : ''}
                                </div>
                                <div style="display: flex; gap: 10px; white-space: nowrap;">
                                    <label style="margin: 0; cursor: pointer; font-size: 13px;">
                                        <input type="radio"
                                               name="course_${course.Idx}_type"
                                               value="primary"
                                               data-course-idx="${course.Idx}"
                                               data-has-assessments="${hasAssessments ? 1 : 0}"
                                               ${isPrimary ? 'checked' : ''}
                                               style="margin-right: 5px;"
                                               class="course-type-radio">
                                        <span class="label label-warning" style="font-size: 12px;">Primary</span>
                                    </label>
                                    <label style="margin: 0; cursor: ${hasAssessments ? 'not-allowed' : 'pointer'}; font-size: 13px;" ${hasAssessments ? 'title="Cannot set as Reference - this course has existing assessments that must be removed first"' : ''}>
                                        <input type="radio"
                                               name="course_${course.Idx}_type"
                                               value="reference"
                                               data-course-idx="${course.Idx}"
                                               data-has-assessments="${hasAssessments ? 1 : 0}"
                                               ${!isPrimary ? 'checked' : ''}
                                               ${hasAssessments ? 'disabled' : ''}
                                               style="margin-right: 5px;"
                                               class="course-type-radio"
                                              ${hasAssessments ? 'title="Has existing assessments - cannot be set as Reference"' : ''}>
                                        <span class="label label-info" style="font-size: 12px;">Reference</span>
                                    </label>
                                </div>
                            </div>
                            ${hasAssessments && !isPrimary ? '<small class="text-danger" style="font-size: 12px; display: block; margin-top: 5px;"><i class="glyphicon glyphicon-warning-sign"></i> Cannot be Reference - has existing assessments</small>' : ''}
                        </div>
                    `;
                    }).join('');

                const content = `
                    <form name="courseReferenceForm" id="courseReferenceForm">
                        <div style="text-align: left; font-size: 14px;">
                            <p style="font-size: 15px; margin-bottom: 10px;">
                                <strong>Course:</strong> ${relatedCourses[0].Subject} ${relatedCourses[0].Num} ${relatedCourses[0].Title}
                            </p>
                            <hr>
                            <p style="margin-bottom: 12px; font-size: 13px;">
                                <i class="glyphicon glyphicon-info-sign text-info"></i>
                                Select which course instance should be Primary (contains assessments). All others will automatically be set as References.
                            </p>
                            <p class="text-warning" style="margin-bottom: 15px; font-size: 13px;">
                                <i class="glyphicon glyphicon-exclamation-sign"></i>
                                <strong>Note:</strong> Exactly one course must be set as Primary.
                            </p>
                            <div id="course-list">
                                ${courseListHtml}
                            </div>
                        </div>
                    </form>
                `;

                createModalDialog({
                    title: '<span class="glyphicon glyphicon-link" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">MANAGE COURSE REFERENCES</span>',
                    message: content,
                    buttons: {
                        unlinkAll: {
                            label: "<span class='glyphicon glyphicon-unlink'></span> UNLINK ALL",
                            className: 'btn-danger pull-left',
                            callback: function() {
                                // Close the modal first
                                $('.modal').modal('hide');

                                // Small delay to ensure modal is closed before showing SweetAlert
                                setTimeout(function() {
                                    Swal.fire({
                                        title: 'Confirm Unlink All',
                                        html: `
                                            <div style="text-align: left; font-size: 14px;">
                                                <p style="font-size: 15px; margin-bottom: 10px; color: #d9534f;">
                                                    <i class="glyphicon glyphicon-warning-sign"></i>
                                                    <strong>Warning:</strong> This will break the primary/reference connection for ALL courses listed below:
                                                </p>
                                                <ul style="list-style: none; padding-left: 0; font-size: 14px; margin-top: 15px;">
                                                    ${relatedCourses.map(course => `
                                                        <li style="padding: 5px 0;">
                                                            <strong>${course.Subject} ${course.Num}</strong> - ${course.AcademicProgramName}
                                                        </li>
                                                    `).join('')}
                                                </ul>
                                                <p style="margin-top: 15px; font-size: 13px; color: #666;">
                                                    Each course will become independent and will no longer share assessments.
                                                </p>
                                            </div>
                                        `,
                                        icon: 'warning',
                                        showCancelButton: true,
                                        confirmButtonColor: '#d9534f',
                                        cancelButtonColor: '#6c757d',
                                        confirmButtonText: '<i class="glyphicon glyphicon-unlink"></i> Yes, Unlink All',
                                        cancelButtonText: '<i class="glyphicon glyphicon-remove"></i> Cancel',
                                        customClass: {
                                            confirmButton: 'swal-custom-button',
                                            cancelButton: 'swal-custom-button',
                                            title: 'swal-custom-title'
                                        }
                                    }).then((confirmResult) => {
                                        if (confirmResult.isConfirmed) {
                                            // Perform unlink for all courses
                                            performUnlinkAllCourses(relatedCourses);
                                        }
                                    });
                                }, 300);

                                return true; // Allow modal to close
                            }
                        },
                        ok: {
                            label: "<span class='glyphicon glyphicon-ok'></span> SAVE CHANGES",
                            className: 'btn-success',
                            callback: function() {
                                // Check how many Primary courses are selected
                                const primaryRadios = document.querySelectorAll('.course-type-radio[value="primary"]:checked');
                                const primaryCount = primaryRadios.length;

                                if (primaryCount === 0) {
                                    Swal.fire({
                                        title: 'Validation Error',
                                        text: 'Please select one Primary course',
                                        icon: 'error',
                                        confirmButtonText: 'OK'
                                    });
                                    return false; // Prevent modal from closing
                                }

                                if (primaryCount > 1) {
                                    Swal.fire({
                                        title: 'Validation Error',
                                        text: 'Please select only ONE Primary course. All others must be References.',
                                        icon: 'error',
                                        confirmButtonText: 'OK'
                                    });
                                    return false; // Prevent modal from closing
                                }

                                // Now we know exactly one Primary is selected
                                const primaryRadio = document.querySelector('.course-type-radio[value="primary"]:checked');
                                const primaryIdx = parseInt(primaryRadio.dataset.courseIdx);

                                // Build array of updates needed
                                const updates = relatedCourses.map(course => ({
                                    avcIdx: course.AVCIdx,
                                    abcIdx: course.Idx,
                                    newValue: course.Idx === primaryIdx ? 0 : 1, // 0 = Primary, 1 = Reference
                                    isPrimary: course.Idx === primaryIdx
                                }));

                                // Check if there are any changes
                                const hasChanges = updates.some(u => {
                                    const course = relatedCourses.find(c => c.Idx === u.abcIdx);
                                    const currentStatus = (course.ReferenceCrsAssessment === 0 || course.ReferenceCrsAssessment === null) ? 'Primary' : 'Reference';
                                    const newStatus = u.isPrimary ? 'Primary' : 'Reference';
                                    return currentStatus !== newStatus;
                                });

                                if (!hasChanges) {
                                    Swal.fire({
                                        title: 'No Changes',
                                        text: 'No changes were made.',
                                        icon: 'info',
                                        confirmButtonText: 'OK'
                                    });
                                    return false; // Prevent modal from closing
                                }

                                // Show confirmation with changes
                                const changesList = updates.map(u => {
                                    const course = relatedCourses.find(c => c.Idx === u.abcIdx);
                                    const currentStatus = (course.ReferenceCrsAssessment === 0 || course.ReferenceCrsAssessment === null) ? 'Primary' : 'Reference';
                                    const newStatus = u.isPrimary ? 'Primary' : 'Reference';
                                    const changed = currentStatus !== newStatus;

                                    return `
                                        <li style="padding: 5px 0;">
                                            ${course.Subject} ${course.Num} - ${course.AcademicProgramName}:
                                            ${changed ? `<span class="text-muted">${currentStatus}</span> → <strong class="text-danger">${newStatus}</strong>`
                                                            : `<span class="text-muted">${currentStatus} (no change)</span>`}
                                        </li>
                                    `;
                                }).join('');

                                // Close the modal first, then show confirmation
                                $('.modal').modal('hide');

                                // Small delay to ensure modal is closed before showing SweetAlert
                                setTimeout(function() {
                                    Swal.fire({
                                        title: 'Confirm Changes',
                                        html: `
                                            <div style="text-align: left; font-size: 14px;">
                                                <p style="font-size: 15px; margin-bottom: 10px;">The following changes will be applied:</p>
                                                <ul style="list-style: none; padding-left: 0; font-size: 14px;">
                                                    ${changesList}
                                                </ul>
                                            </div>
                                        `,
                                        icon: 'question',
                                        showCancelButton: true,
                                        confirmButtonColor: '#5cb85c',
                                        cancelButtonColor: '#6c757d',
                                        confirmButtonText: '<i class="glyphicon glyphicon-ok"></i> Confirm',
                                        cancelButtonText: '<i class="glyphicon glyphicon-remove"></i> Cancel',
                                        customClass: {
                                            confirmButton: 'swal-custom-button',
                                            cancelButton: 'swal-custom-button',
                                            title: 'swal-custom-title'
                                        }
                                    }).then((confirmResult) => {
                                        if (confirmResult.isConfirmed) {
                                            performBulkUpdatePrimaryReference(updates);
                                        }
                                        // If cancelled, do nothing
                                    });
                                }, 300);

                                return true; // Allow modal to close
                            }
                        },
                        cancel: {
                            label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                            className: 'btn-default',
                            callback: function() {
                                // Modal will close automatically
                            }
                        }
                    }
                }).on('shown.bs.modal', function() {
                    // Add event listeners for radio buttons - when Primary is selected, set all others to Reference
                    $('.course-type-radio[value="primary"]').on('change', function() {
                        if (this.checked) {
                            const selectedCourseIdx = $(this).data('course-idx');

                            // Set all OTHER courses to Reference
                            $('.course-type-radio').each(function() {
                                const currentCourseIdx = $(this).data('course-idx');
                                const isReference = $(this).val() === 'reference';
                                const isDisabled = $(this).prop('disabled');

                                if (currentCourseIdx !== selectedCourseIdx && isReference && !isDisabled) {
                                    $(this).prop('checked', true);
                                }
                            });
                        }
                    });

                    // Focus on the first radio button
                    $('.course-type-radio:first').focus();
                });

                return false;
            });
        });

    </script>

    <div class="pagebacklayout">
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">LINK SERVICE COURSE TO DIFFERENT PROGRAMS (ONE TO MANY)</p>

            <p style="margin:0.2in auto 0;text-align:center;max-width:1000px;">
                Only the ABET courses (same course numbers) that are added for assessment in multiple degree programs will be displayed.
                Marking each course as "Primary" or "Reference" will allow instructors to add assessment measures only to the primary course and automatically copied to the reference course(s).
            </p>
        </div>


        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:20%; min-width:350px;">
                        <?php echo($AcademicYearSelection);?>
                    </td>
                    <td style="width:5%"></td>
                    <td style="width:75%; text-align: right">
                    </td>
                </tr>
            </table>


            <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
                <table id="AbetCourses" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th style="width:50px">SEMESTER</th>
                        <th>CRN</th>
                        <th>SUBJECT</th>
                        <th>NUMBER</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>INSTRUCTOR</th>
                        <th>REQUIREMENT</th>
                        <th>LEVEL</th>
                        <th>STUDENT OUTCOMES</th>
                        <th>PERFORMANCE INDICATORS</th>
                        <th>PROGRAM NAME</th>
                        <th>PRIMARY / REFERENCE</th>
                        <th class="no-sort">OPERATION</th>
                    </tr>
                    </thead>
                    <thead id="serachbox" class="filters">
                    <tr>
                        <th>SEMESTER</th>
                        <th>CRN</th>
                        <th>SUBJECT</th>
                        <th>NUMBER</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>INSTRUCTOR</th>
                        <th>REQUIREMENT</th>
                        <th>LEVEL</th>
                        <th>STUDENT OUTCOMES</th>
                        <th>PERFORMANCE INDICATORS</th>
                        <th>PROGRAM NAME</th>
                        <th>PRIMARY / REFERENCE</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>SEMESTER</th>
                        <th>CRN</th>
                        <th>SUBJECT</th>
                        <th>NUMBER</th>
                        <th>TITLE</th>
                        <th>CREDITS</th>
                        <th>INSTRUCTOR</th>
                        <th>REQUIREMENT</th>
                        <th>LEVEL</th>
                        <th>STUDENT OUTCOMES</th>
                        <th>PERFORMANCE INDICATORS</th>
                        <th>PROGRAM NAME</th>
                        <th>PRIMARY / REFERENCE</th>
                        <th></th>
                    </tr>
                    </tfoot>
                </table>
            </div>

            <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
                <tr>
                    <td>
                        <span style="color:red;font-weight:bold;"></span></td>
                    <td style="text-align:right;">
                        <span class="btn btn-danger btn-xs glyphicon glyphicon-education" style="pointer-events: none;"></span>: Class Roster
                        <span class="btn btn-danger btn-xs glyphicon glyphicon-star-empty" style="pointer-events: none;"></span>: Primary / Reference
                    </td>
                </tr>
            </table>
        </div>
    </div>


<?php include('footer.php');?>