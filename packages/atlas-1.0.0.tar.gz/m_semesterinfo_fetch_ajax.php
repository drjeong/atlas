<?php
/**
 * Management of Semester Information
 * Description: fetching available semester information from the university website.
 * Author: Dong Hyun Jeong
 *
 * 08/07/2026 - initial version created
 */

include('checker_systemadmin.php');

header('Content-Type: application/json');

function GetSemesterInfo($CURL)
{
    require_once(__DIR__ . '/../config.php');

    $url = __BANNER_TERMS_API_URL__;

    // Create temporary cookie file
    $cookie = tempnam(sys_get_temp_dir(), 'cookie_');

    // Clear any previous options
    curl_reset($CURL);

    // Basic options
    curl_setopt($CURL, CURLOPT_URL, $url);
    curl_setopt($CURL, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($CURL, CURLOPT_TIMEOUT, 60);
    curl_setopt($CURL, CURLOPT_FOLLOWLOCATION, true);

    // SSL options - let cURL use default certificate bundle
    curl_setopt($CURL, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($CURL, CURLOPT_SSL_VERIFYHOST, 2);

    // Updated User Agent
    curl_setopt($CURL, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");

    // Cookie handling with temp file
    curl_setopt($CURL, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($CURL, CURLOPT_COOKIESESSION, true);
    curl_setopt($CURL, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($CURL, CURLOPT_REFERER, $url);

    // Accept JSON
    curl_setopt($CURL, CURLOPT_HTTPHEADER, array(
        'Accept: application/json',
        'Content-Type: application/json'
    ));

    // Execute request
    $data = curl_exec($CURL);

    // Check for cURL errors
    if ($data === false) {
        $error = curl_error($CURL);
        $errno = curl_errno($CURL);

        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return [
            'success' => false,
            'message' => "cURL Error ($errno): $error"
        ];
    }

    // Check HTTP status
    $httpCode = curl_getinfo($CURL, CURLINFO_HTTP_CODE);
    if ($httpCode >= 400) {
        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return [
            'success' => false,
            'message' => "HTTP Error $httpCode. Server returned error."
        ];
    }

    // Check if data is empty
    if (empty($data)) {
        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return [
            'success' => false,
            'message' => 'No connection to the university server. Please try again later!'
        ];
    }

    // Parse JSON response
    $semesters = json_decode($data, true);

    // Check if JSON parsing was successful
    if (json_last_error() !== JSON_ERROR_NONE) {
        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return [
            'success' => false,
            'message' => 'Invalid JSON response: ' . json_last_error_msg()
        ];
    }

    // Check if we got an array
    if (!is_array($semesters) || empty($semesters)) {
        // Clean up temp cookie file
        if (file_exists($cookie)) {
            unlink($cookie);
        }

        return [
            'success' => false,
            'message' => 'No semester data found.'
        ];
    }

    // Clean up temp cookie file
    if (file_exists($cookie)) {
        unlink($cookie);
    }

    return [
        'success' => true,
        'semesters' => $semesters
    ];
}

try {
    // Create curl resource
    $CURL = curl_init();
    if (!$CURL) {
        throw new Exception("Failed to initialize cURL");
    }

    $result = GetSemesterInfo($CURL);
    curl_close($CURL);

    echo json_encode($result);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}