<?php
/**
 * Listing Type of Assessments
 * File: u_course_typeofassmnts_ssps.php
 * Description: listing type of assessments of the selected course
 *
 *
 *
 */


include_once 'session_handler.php';


$AvailableCourseIdx='';
if (array_key_exists('_AVC', $_GET))
    $AvailableCourseIdx = trim($_GET['_AVC']);

// DB table to use
$table = 'TypeOfAssignments';
$joinQuery = "FROM `$table` AS `TYOASMNTS` ";


// Table's primary key
$primaryKey = '`TYOASMNTS`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`TYOASMNTS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`TYOASMNTS`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`TYOASMNTS`.`AssignmentType`', 'dt' => 'AssignmentType', 'field' => 'AssignmentType', 'as' => 'AssignmentType'),
    array( 'db' => '`TYOASMNTS`.`NumAssignments`', 'dt' => 'NumAssignments', 'field' => 'NumAssignments', 'as' => 'NumAssignments'),
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "`TYOASMNTS`.`AvailableCourseIdx` = '$AvailableCourseIdx'";
//$extraWhere .= " AND `TYOASMNTS`.`UserIdx`='". $_SESSION['ATLAS_LOGIN_USERIDX']."'";
$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
