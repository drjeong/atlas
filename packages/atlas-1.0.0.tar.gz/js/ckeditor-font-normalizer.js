/**
 * CKEditor Font Normalizer
 * Ensures consistent font styling within CKEditor instances
 */
const CKEditorFontNormalizer = {
    /**
     * Initialize a CKEditor instance with consistent font styling
     * @param {string} textareaId - The ID of the textarea to replace with CKEditor
     * @param {Object} options - Configuration options
     * @returns {CKEDITOR.editor} The CKEditor instance
     */
    init: function(textareaId, options = {}) {
        // First ensure any existing instance is properly destroyed
        this.destroy(textareaId);

        // Give a small delay to ensure the old instance is fully cleaned up
        // This helps prevent conflicts between destroy and create operations
        return new Promise((resolve) => {
            setTimeout(() => {
                // Default options
                const defaults = {
                    readOnly: false,
                    toolbar: [['Bold', 'Italic', '-', 'NumberedList', 'BulletedList']],
                    height: '250px',
                    onReady: null,
                    onChange: null,
                    fontStyles: null
                };

                // Merge options with defaults
                options = {...defaults, ...options};

                // Get the textarea element
                const textarea = document.getElementById(textareaId);
                if (!textarea) {
                    console.error(`Textarea with ID '${textareaId}' not found.`);
                    resolve(null);
                    return;
                }

                // Reset display style that might have been changed
                textarea.style.display = '';

                // Get font styling (from options, data attributes, or computed style)
                const fontStyles = options.fontStyles || this.getFontStyles(textarea);

                // Store font styles as data attributes for future reference
                this.storeFontStyles(textarea, fontStyles);

                // Create CKEditor configuration
                const editorConfig = {
                    // Basic settings
                    toolbar: options.readOnly ? [] : options.toolbar,
                    readOnly: options.readOnly,
                    height: options.height,
                    allowedContent: true,
                    enterMode: CKEDITOR.ENTER_BR,
                    entities: false,
                    autoParagraph: false,
                    resize_enabled: !options.readOnly,

                    // Remove plugins that could change font styling
                    removePlugins: 'font,fontSize,colorbutton,colordialog' +
                        (options.readOnly ? ',elementspath,scayt,wsc' : ''),

                    // Override font size options if font plugin is loaded
                    fontSize_sizes: `${fontStyles.fontSize}/Default;${fontStyles.fontSize}/${fontStyles.fontSize}`,

                    // Override font options if font plugin is loaded
                    font_names: `${fontStyles.fontFamily.split(',')[0].trim().replace(/['"]/g, '')}/Default`,

                    // Apply consistent styling through CSS
                    contentsCss: [
                        CKEDITOR.basePath + 'contents.css',
                        this.generateFontCss(fontStyles, options.readOnly)
                    ],

                    // Event handling
                    on: {
                        instanceReady: (evt) => {
                            this.applyEditorStyling(evt.editor, fontStyles, options);
                            if (typeof options.onReady === 'function') {
                                options.onReady(evt.editor);
                            }
                            resolve(evt.editor);
                        },

                        change: (evt) => {
                            this.normalizeContentFontStyling(evt.editor, fontStyles);
                            if (typeof options.onChange === 'function') {
                                options.onChange(evt.editor);
                            }
                        },

                        dataReady: (evt) => {
                            this.normalizeContentFontStyling(evt.editor, fontStyles);
                        },

                        paste: (evt) => {
                            // Let the paste happen, then normalize
                            setTimeout(() => {
                                this.normalizeContentFontStyling(evt.editor, fontStyles);
                            }, 0);
                        },

                        afterPasteFromWord: (evt) => {
                            this.normalizeContentFontStyling(evt.editor, fontStyles);
                        }
                    }
                };

                // Create the CKEditor instance
                try {
                    const editor = CKEDITOR.replace(textareaId, editorConfig);
                    // If instanceReady doesn't fire for some reason, resolve anyway
                    setTimeout(() => {
                        if (editor && !editor.instanceReady) {
                            resolve(editor);
                        }
                    }, 1000);

                    return editor;
                } catch (e) {
                    console.error('Error creating CKEditor instance:', e);
                    resolve(null);
                    return null;
                }
            }, 50); // Small delay to ensure cleanup
        });
    },

    /**
     * Get font styles from an element
     * @param {HTMLElement} element - The element to get styles from
     * @returns {Object} Font style properties
     */
    getFontStyles: function(element) {
        // Try to get from data attributes first
        if (element.dataset.fontFamily && element.dataset.fontSize && element.dataset.fontColor) {
            return {
                fontFamily: element.dataset.fontFamily,
                fontSize: element.dataset.fontSize,
                fontColor: element.dataset.fontColor,
                backgroundColor: element.dataset.backgroundColor || '#ffffff'
            };
        }

        // Fallback to computed style
        const computedStyle = window.getComputedStyle(element);
        return {
            fontFamily: computedStyle.getPropertyValue('font-family') || 'Arial, sans-serif',
            fontSize: computedStyle.getPropertyValue('font-size') || '14px',
            fontColor: computedStyle.getPropertyValue('color') || '#000000',
            backgroundColor: computedStyle.getPropertyValue('background-color') || '#ffffff'
        };
    },

    /**
     * Store font styles as data attributes
     * @param {HTMLElement} element - The element to store styles on
     * @param {Object} fontStyles - The font styles to store
     */
    storeFontStyles: function(element, fontStyles) {
        element.dataset.fontFamily = fontStyles.fontFamily;
        element.dataset.fontSize = fontStyles.fontSize;
        element.dataset.fontColor = fontStyles.fontColor;
        element.dataset.backgroundColor = fontStyles.backgroundColor;
    },

    /**
     * Generate CSS for consistent font styling
     * @param {Object} fontStyles - Font style properties
     * @param {boolean} isReadOnly - Whether the editor is in readonly mode
     * @returns {string} CSS rules
     */
    generateFontCss: function(fontStyles, isReadOnly) {
        return `
            /* Base styles for all content */
            body.cke_editable, body {
                font-family: ${fontStyles.fontFamily} !important;
                font-size: ${fontStyles.fontSize} !important;
                color: ${fontStyles.fontColor} !important;
                background-color: ${isReadOnly ? '#f5f5f5' : fontStyles.backgroundColor};
                line-height: 1.6;
            }
            
            /* Force all elements to use the same font properties */
            body.cke_editable *,
            body *,
            p, div, span, h1, h2, h3, h4, h5, h6, 
            ul, ol, li, dl, dt, dd,
            table, tr, td, th, caption,
            a, strong, em, b, i, u, s, 
            blockquote, pre, code {
                font-family: ${fontStyles.fontFamily} !important;
                font-size: ${fontStyles.fontSize} !important;
                color: ${fontStyles.fontColor} !important;
            }
            
            /* Attribute selectors for inline styles */
            [style*="font-size"] {
                font-size: ${fontStyles.fontSize} !important;
            }
            
            [style*="font-family"] {
                font-family: ${fontStyles.fontFamily} !important;
            }
            
            [style*="color"] {
                color: ${fontStyles.fontColor} !important;
            }
            
            /* Selection styling */
            ::selection {
                background: #b5d6fd;
                color: ${fontStyles.fontColor};
            }
            
            /* Remove focus outline */
            .cke_focus, .cke_editable:focus {
                outline: none !important;
            }
            
            /* Force links to maintain the same color */
            a, a:link, a:visited, a:hover, a:active {
                color: ${fontStyles.fontColor} !important;
                text-decoration: underline;
            }
        `;
    },

    /**
     * Apply styling to the editor UI and content
     * @param {CKEDITOR.editor} editor - The CKEditor instance
     * @param {Object} fontStyles - Font style properties
     * @param {Object} options - Configuration options
     */
    applyEditorStyling: function(editor, fontStyles, options) {
        // Style the editor container
        const editorElement = editor.container.$;

        if (options.readOnly) {
            editorElement.style.border = '1px solid #ccc';
            editorElement.style.borderRadius = '4px';
        }

        // Apply styles to the editable area
        const $editable = $(editor.editable().$);
        $editable.css({
            'font-family': fontStyles.fontFamily,
            'font-size': fontStyles.fontSize,
            'color': fontStyles.fontColor,
            'background-color': options.readOnly ? '#f5f5f5' : fontStyles.backgroundColor
        });

        // Add style element to the editor document
        if (editor.document && editor.document.getHead()) {
            const style = new CKEDITOR.dom.element('style');
            style.setAttribute('type', 'text/css');
            style.setText(`
                /* Force consistent font styling */
                body, body * {
                    font-family: ${fontStyles.fontFamily} !important;
                    font-size: ${fontStyles.fontSize} !important;
                    color: ${fontStyles.fontColor} !important;
                }
                
                /* Override any inline styles */
                [style*="font-size"],
                [style*="font-family"],
                [style*="color"] {
                    font-family: ${fontStyles.fontFamily} !important;
                    font-size: ${fontStyles.fontSize} !important;
                    color: ${fontStyles.fontColor} !important;
                }
            `);
            editor.document.getHead().append(style);
        }

        // Normalize any existing content
        this.normalizeContentFontStyling(editor, fontStyles);
    },

    /**
     * Normalize font styling in editor content
     * @param {CKEDITOR.editor} editor - The CKEditor instance
     * @param {Object} fontStyles - Font style properties
     */
    normalizeContentFontStyling: function(editor, fontStyles) {
        // Skip if we don't have an editor instance or document
        if (!editor || !editor.document || !editor.document.getBody()) return;

        // Get or create a style element in the document head
        let styleElement = editor.document.getHead().findOne('style#font-normalizer-styles');

        if (!styleElement) {
            styleElement = new CKEDITOR.dom.element('style');
            styleElement.setAttribute('id', 'font-normalizer-styles');
            styleElement.setAttribute('type', 'text/css');
            editor.document.getHead().append(styleElement);
        }

        // Set global CSS rules instead of inline styles
        styleElement.setText(`
        /* Base styles for all content */
        body {
            font-family: ${fontStyles.fontFamily} !important;
            font-size: ${fontStyles.fontSize} !important;
            color: ${fontStyles.fontColor} !important;
            line-height: 1.6;
        }
        
        /* Force all elements to use the same font properties */
        p, div, span, h1, h2, h3, h4, h5, h6, 
        ul, ol, li, dl, dt, dd,
        table, tr, td, th, caption,
        a, strong, em, b, i, u, s, 
        blockquote, pre, code,
        [style*="font-size"],
        [style*="font-family"],
        [style*="color"] {
            font-family: ${fontStyles.fontFamily} !important;
            font-size: ${fontStyles.fontSize} !important;
            color: ${fontStyles.fontColor} !important;
        }
    `);

        // Fix entity encoding issues in the HTML source
        const bodyElement = editor.document.getBody();
        const htmlContent = bodyElement.getHtml();

        // Fix double-encoded entities
        let fixedHtml = htmlContent
            // Fix double-encoded non-breaking spaces
            .replace(/&amp;amp;nbsp;/g, '&nbsp;')
            .replace(/&amp;nbsp;/g, '&nbsp;')
            // Fix other common double-encoded entities
            .replace(/&amp;amp;quot;/g, '&quot;')
            .replace(/&amp;quot;/g, '&quot;')
            .replace(/&amp;amp;lt;/g, '&lt;')
            .replace(/&amp;lt;/g, '&lt;')
            .replace(/&amp;amp;gt;/g, '&gt;')
            .replace(/&amp;gt;/g, '&gt;')
            .replace(/&amp;amp;apos;/g, '&apos;')
            .replace(/&amp;apos;/g, '&apos;')
            .replace(/&amp;amp;amp;/g, '&amp;')
            .replace(/&amp;amp;/g, '&amp;');

        // Apply the fixed HTML if changes were made
        if (htmlContent !== fixedHtml) {
            bodyElement.setHtml(fixedHtml);
        }

        // Clean up existing inline styles
        const allElements = bodyElement.find('*');

        for (let i = 0; i < allElements.count(); i++) {
            const element = allElements.getItem(i);

            // Skip elements that shouldn't have text styling
            if (['script', 'style', 'br', 'hr'].includes(element.getName())) continue;

            // Fix common attributes that might contain encoded entities
            const commonAttributes = ['style', 'title', 'alt', 'href', 'src', 'data-*'];

            commonAttributes.forEach(attrPattern => {
                if (attrPattern === 'data-*') {
                    // Handle data attributes specially
                    const attrs = element.$.attributes;
                    if (attrs) {
                        for (let j = 0; j < attrs.length; j++) {
                            const attr = attrs[j];
                            if (attr.name.startsWith('data-') && attr.value) {
                                fixAttributeValue(element, attr.name);
                            }
                        }
                    }
                } else if (element.hasAttribute(attrPattern)) {
                    fixAttributeValue(element, attrPattern);
                }
            });

            // Remove existing font styling from inline styles
            if (element.hasAttribute('style')) {
                let style = element.getAttribute('style');

                // Remove existing font styling
                style = style.replace(/font-family\s*:\s*[^;]+;?/gi, '');
                style = style.replace(/font-size\s*:\s*[^;]+;?/gi, '');
                style = style.replace(/color\s*:\s*[^;]+;?/gi, '');

                // Clean up leftover semicolons and empty style attributes
                style = style.replace(/;\s*;/g, ';').trim();

                if (style === '' || style === ';') {
                    element.removeAttribute('style');
                } else {
                    element.setAttribute('style', style);
                }
            }

            // Remove any font tags or attributes
            if (element.getName() === 'font') {
                if (element.hasAttribute('size')) element.removeAttribute('size');
                if (element.hasAttribute('face')) element.removeAttribute('face');
                if (element.hasAttribute('color')) element.removeAttribute('color');
            }

            // Remove any span tags that only exist for styling
            if (element.getName() === 'span' &&
                !element.hasAttributes() &&
                element.getChildCount() === 1 &&
                element.getChild(0).type === CKEDITOR.NODE_TEXT) {
                element.replaceWithChildren();
            }
        }

        // Helper function to fix encoded entities in attribute values
        function fixAttributeValue(element, attrName) {
            const attrValue = element.getAttribute(attrName);
            if (attrValue && (
                attrValue.includes('&amp;amp;') ||
                attrValue.includes('&amp;nbsp;') ||
                attrValue.includes('&amp;quot;') ||
                attrValue.includes('&amp;lt;') ||
                attrValue.includes('&amp;gt;')
            )) {
                const fixedAttrValue = attrValue
                    .replace(/&amp;amp;nbsp;/g, '&nbsp;')
                    .replace(/&amp;nbsp;/g, '&nbsp;')
                    .replace(/&amp;amp;quot;/g, '&quot;')
                    .replace(/&amp;quot;/g, '&quot;')
                    .replace(/&amp;amp;lt;/g, '&lt;')
                    .replace(/&amp;lt;/g, '&lt;')
                    .replace(/&amp;amp;gt;/g, '&gt;')
                    .replace(/&amp;gt;/g, '&gt;')
                    .replace(/&amp;amp;apos;/g, '&apos;')
                    .replace(/&amp;apos;/g, '&apos;')
                    .replace(/&amp;amp;amp;/g, '&amp;')
                    .replace(/&amp;amp;/g, '&amp;');

                element.setAttribute(attrName, fixedAttrValue);
            }
        }

        // Also add a fix when data is submitted
        editor.on('beforeGetData', function() {
            const html = editor.document.getBody().getHtml();
            const fixedHtml = html
                .replace(/&amp;amp;nbsp;/g, '&nbsp;')
                .replace(/&amp;nbsp;/g, '&nbsp;')
                .replace(/&amp;amp;quot;/g, '&quot;')
                .replace(/&amp;quot;/g, '&quot;')
                .replace(/&amp;amp;lt;/g, '&lt;')
                .replace(/&amp;lt;/g, '&lt;')
                .replace(/&amp;amp;gt;/g, '&gt;')
                .replace(/&amp;gt;/g, '&gt;')
                .replace(/&amp;amp;apos;/g, '&apos;')
                .replace(/&amp;apos;/g, '&apos;')
                .replace(/&amp;amp;amp;/g, '&amp;')
                .replace(/&amp;amp;/g, '&amp;');

            if (html !== fixedHtml) {
                editor.document.getBody().setHtml(fixedHtml);
            }
        });
    },

    /**
     * Safely destroy a CKEditor instance
     * @param {string} editorId - The ID of the CKEditor instance to destroy
     */
    destroy: function(editorId) {
        try {
            if (CKEDITOR.instances[editorId]) {
                // Check if editor is fully initialized with an editable component
                const editor = CKEDITOR.instances[editorId];

                // Special handling to avoid the "Cannot read properties of null (reading 'clearCustomData')" error
                if (editor.status === 'ready' && editor.editable() !== null) {
                    // Normal destroy for fully initialized editors
                    editor.destroy();
                } else {
                    // For editors not fully initialized, use a more careful approach
                    if (editor.container) {
                        editor.container.remove();
                    }

                    // Remove from CKEDITOR.instances without calling destroy
                    delete CKEDITOR.instances[editorId];

                    // Re-enable the original textarea if it exists
                    const textarea = document.getElementById(editorId);
                    if (textarea) {
                        textarea.style.display = '';
                    }
                }
            }
        } catch (e) {
            console.error('Error destroying CKEditor instance:', e);

            // Fallback cleanup approach
            try {
                delete CKEDITOR.instances[editorId];

                // Re-enable original textarea
                const textarea = document.getElementById(editorId);
                if (textarea) {
                    textarea.style.display = '';
                }

                // Remove any remaining CKEditor elements
                const container = document.getElementById(editorId + '_container');
                if (container) {
                    container.parentNode.removeChild(container);
                }
            } catch (fallbackError) {
                console.error('Fallback cleanup also failed:', fallbackError);
            }
        }
    }
};