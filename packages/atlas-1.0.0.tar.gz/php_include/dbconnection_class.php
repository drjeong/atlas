<?php 
require_once ('notify_user.php');

class Dbconnection
{
    var $vDbname;		// Database name
	var $vDbconnect = null;	// Connection variable
	var $vDbtable;		// Database table
	var $vUserid;		// Database user id
	var $vUserpwd;		// Database user pwd
	var $vHostname;		// Database Host name
	var $vResult;		// Query result
	var $vQuery;

    function __construct() {
        require_once(__DIR__ . '/../../config.php');
		$this->vHostname = __DB_HOSTNAME;
		$this->vDbname = __DB_DBNAME;
		$this->vUserid = __DB_USERID;
		$this->vUserpwd = __DB_USERPWD;
		$this->vResult = null;
		$this->dbconnect();
	}

	function __destruct () {
		$this->dbclose();
	}

    /**
     * Set autocommit mode
     * @param bool $mode TRUE to enable autocommit, FALSE to disable
     * @return bool
     */
    function autocommit($mode) {
        if ($this->vDbconnect == null) return false;
        return mysqli_autocommit($this->vDbconnect, $mode);
    }

    /**
     * Commit current transaction
     * @return bool
     */
    function commit() {
        if ($this->vDbconnect == null) return false;
        return mysqli_commit($this->vDbconnect);
    }

    /**
     * Rollback current transaction
     * @return bool
     */
    function rollback() {
        if ($this->vDbconnect == null) return false;
        return mysqli_rollback($this->vDbconnect);
    }

    /**
     * Start a transaction
     * @return bool
     */
    function begin_transaction() {
        if ($this->vDbconnect == null) return false;
        return mysqli_begin_transaction($this->vDbconnect);
    }

    function escape_string($param) {
        if(is_array($param))
            return array_map(__METHOD__, $param);

        if(!empty($param) && is_string($param)) {
            return str_replace(array('\\', "\0", "\n", "\r", "'", '"', "\x1a"), array('\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z'), $param);
        }
        return $param;
    }

	function real_escape_string($item)
	{
		$tmp = mysqli_real_escape_string($this->vDbconnect, $item);
		return ($tmp);
	}

	function dbconnect()
	{
	    $this->vDbconnect = new mysqli($this->vHostname, $this->vUserid, $this->vUserpwd, $this->vDbname);
        // Check connection
        if ($this->vDbconnect -> connect_errno) {
            $this->db_connection_error();
            unset($this->vDbconnect);
            $this->vDbconnect = null;
        }
	}

    function prepare($query) {
        if ($this->vDbconnect == null) return null;

        $stmt = $this->vDbconnect->prepare($query);
        if (!$stmt) {
            $this->query_error();
        }
        return $stmt;
    }

    function formatQuery($query, $params) {
        $indexed = $params === array_values($params);
        foreach($params as $k => $v) {
            if(is_string($v)) {
                $v = "'".addslashes($v)."'";
            } elseif(is_null($v)) {
                $v = 'NULL';
            } elseif(is_array($v)) {
                $v = implode(',', $v);
            }

            if($indexed) {
                $query = preg_replace('/\?/', $v, $query, 1);
            } else {
                $query = str_replace(":$k", $v, $query);
            }
        }
        return $query;
    }

    function formatQueryStoredProcedure($procedureName, $params = []) {
        $formattedParams = [];

        foreach($params as $param) {
            if(is_string($param)) {
                $formattedParams[] = "'".addslashes($param)."'";
            } elseif(is_null($param)) {
                $formattedParams[] = 'NULL';
            } elseif(is_array($param)) {
                $formattedParams[] = implode(',', $param);
            } elseif(is_bool($param)) {
                $formattedParams[] = $param ? '1' : '0';
            } else {
                // For integers, floats, and other numeric types
                $formattedParams[] = $param;
            }
        }

        $paramString = implode(', ', $formattedParams);
        return "CALL $procedureName($paramString)";
    }

    function prepare_execute($query, $params = [])
    {
        if ($this->vDbconnect == null) return null;

        $this->free_result(); // free result first

        $stmt = $this->vDbconnect->prepare($query);
        if (!$stmt) {
            $this->query_error();
            return null;
        }

        if (!empty($params)) {
            $types = '';
            $bindParams = [];
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } elseif (is_string($param)) {
                    $types .= 's';
                } else {
                    $types .= 'b';
                }
                $bindParams[] = $param;
            }
            array_unshift($bindParams, $types);
            call_user_func_array([$stmt, 'bind_param'], $this->refValues($bindParams));
        }

        $executed = $stmt->execute();
        if (!$executed) {
            $this->query_error();
            return null;
        }

        $this->vResult = $stmt->get_result();
        return $this->vResult;
    }

    function prepare_execute_catch_error($query, $params = [])
    {
        try {
            if ($this->vDbconnect == null) {
                throw new Exception('Database connection is null');
            }

            $this->free_result(); // free result first

            $stmt = $this->vDbconnect->prepare($query);
            if (!$stmt) {
                throw new mysqli_sql_exception(
                    'Prepare failed: ' . $this->vDbconnect->error,
                    $this->vDbconnect->errno
                );
            }

            if (!empty($params)) {
                $types = '';
                $bindParams = [];
                foreach ($params as $param) {
                    if (is_null($param)) {
                        $types .= 'i'; // or 's' depending on the column type
                        $bindParams[] = null;
                    } elseif (is_int($param)) {
                        $types .= 'i';
                        $bindParams[] = $param;
                    } elseif (is_float($param)) {
                        $types .= 'd';
                        $bindParams[] = $param;
                    } elseif (is_string($param)) {
                        $types .= 's';
                        $bindParams[] = $param;
                    } else {
                        $types .= 'b';
                        $bindParams[] = $param;
                    }
                }
                array_unshift($bindParams, $types);

                if (!call_user_func_array([$stmt, 'bind_param'], $this->refValues($bindParams))) {
                    throw new mysqli_sql_exception(
                        'Bind param failed: ' . $stmt->error,
                        $stmt->errno
                    );
                }
            }

            if (!$stmt->execute()) {
                throw new mysqli_sql_exception(
                    'Execute failed: ' . $stmt->error,
                    $stmt->errno
                );
            }

            // Check if this is a SELECT query or a modification query (INSERT/UPDATE/DELETE)
            $result = $stmt->get_result();

            // For SELECT queries, get_result() returns mysqli_result or false on error
            // For INSERT/UPDATE/DELETE, get_result() returns false (not an error - just no result set)
            if ($result === false) {
                // Check if there was actually an error
                if ($stmt->errno) {
                    throw new mysqli_sql_exception(
                        'Get result failed: ' . $stmt->error,
                        $stmt->errno
                    );
                }
                // No error - this was an INSERT/UPDATE/DELETE query
                // Return TRUE to indicate success, not false
                $this->vResult = null;
                return true;
            }

            // This was a SELECT query with results
            $this->vResult = $result;
            return $this->vResult;

        } catch (mysqli_sql_exception $e) {
            // Log the error details
            $err_message = sprintf(
                "Database error in prepare_execute: [%d] %s\nQuery: %s\nParams: %s",
                $e->getCode(),
                $e->getMessage(),
                $query,
                json_encode($params)
            );
            error_log($err_message);
            $this->notify_error_to_admin($err_message);

            // RE-THROW the exception instead of returning false
            throw $e;
        }
    }

    // New method to call any stored procedure with parameters
    function callStoredProcedure($procedureName, $params = []) {
        if ($this->vDbconnect == null) return null;

        // Create a placeholder string for the parameters
        $placeholders = rtrim(str_repeat('?, ', count($params)), ', ');

        // Prepare the SQL statement to call the stored procedure
        $stmt = $this->vDbconnect->prepare("CALL $procedureName($placeholders)");
        if (!$stmt) {
            $this->query_error();
        }

        // Determine parameter types
        $types = '';
        foreach ($params as $param) {
            if (is_null($param)) {
                $types .= 'i'; // Handle NULL as integer for your case
            } elseif (is_int($param)) {
                $types .= 'i'; // integer
            } elseif (is_float($param)) {
                $types .= 'd'; // double
            } elseif (is_string($param)) {
                $types .= 's'; // string
            } else {
                $types .= 'b'; // blob (default)
            }
        }

        // Bind the parameters
        $binded = $stmt->bind_param($types, ...$params);
        if (!$binded) {
            $this->query_error();
        }

        // Execute the stored procedure
        $executed = $stmt->execute();
        if (!$executed) {
            $this->query_error();
        }

        // Get the result
        $this->vResult = $stmt->get_result();
        return $this->vResult;
    }

    private function refValues($arr)
    {
        if (strnatcmp(phpversion(),'5.3') >= 0) {
            $refs = [];
            foreach($arr as $key => $value)
                $refs[$key] = &$arr[$key];
            return $refs;
        }
        return $arr;
    }

    function send_insert_query_get_insert_id($query)
    {
        if ($this->vDbconnect == null) return;

        $this->free_result(); // free result first

        $this->vQuery = $query;
        $this->vResult = mysqli_query($this->vDbconnect, $query) or die ($this->query_error());
        if ($this->vResult) // successful
        {
            $last_id = mysqli_insert_id($this->vDbconnect);
            return $last_id;
        }
        return $this->vResult;
    }

	function sendquery($query)
	{
	    if ($this->vDbconnect == null) return;

		$this->free_result(); // free result first

		$this->vQuery = $query;
		$this->vResult = mysqli_query($this->vDbconnect, $query) or die ($this->query_error());
		return $this->vResult;
	}

	function sendmultiquery($query)
	{
        if ($this->vDbconnect == null) return;

		$this->free_result(); // free result first

		$this->vQuery = $query;
		$this->vResult = mysqli_multi_query($this->vDbconnect, $query) or die ($this->query_error());

		// https://dev.mysql.com/doc/connectors/en/apis-php-mysqli.multi-query.html
		// mysqli_multi_query Returns FALSE if the first statement failed. 
		// To retrieve subsequent errors from other statements you have to call mysqli_next_result first.
		if (!$this->vResult && mysqli_errno($this->vDbconnect)!=0) $this->query_error();
		while (mysqli_next_result($this->vDbconnect)) {
			$this->vResult = mysqli_next_result($this->vDbconnect);
			if (!$this->vResult && mysqli_errno($this->vDbconnect)!=0) $this->query_error();

			//important to make mysqli_more_results false:
			$discard = mysqli_store_result($this->vDbconnect);
		}
	}

	function gettotalcount($query)
	{
        if ($this->vDbconnect == null) return;

		$this->vQuery = $query;
		$this->vResult = mysqli_query($this->vDbconnect, $query) or die ($this->query_error());
		return (mysqli_num_rows($this->vResult));
	}

	function free_result()
	{
        if ($this->vDbconnect == null) return;

		do {
			if ($res = $this->vDbconnect->store_result()) {
				$res->fetch_all(MYSQLI_ASSOC);
				$res->free();
			}
		} while ($this->vDbconnect->more_results() && $this->vDbconnect->next_result());
	}

	function num_rows()
	{
        if ($this->vDbconnect == null) return;

		if ($this->vResult==null || $this->vResult==false) return 0;
		return (mysqli_num_rows($this->vResult));
	}

	function fetch_assoc()
	{
        if ($this->vDbconnect == null) return;

		if ($this->vResult==null || $this->vResult==false) return 0;
		return (mysqli_fetch_assoc($this->vResult));
	}	

    function get_last_error() {
        if ($this->vDbconnect != null) {
            return mysqli_error($this->vDbconnect);
        }
        return "No connection";
    }

    function db_connection_error()
    {
        $LoginUserName = '';
        if (isset($_SESSION['ATLAS_LOGIN_USERNAME'])) {
            $LoginUserName = $_SESSION['ATLAS_LOGIN_USERNAME'];
        }

        Notify_Admin("Failed to connect to MySQL: (" . mysqli_connect_errno() . ") " . mysqli_connect_error());

        throw new Exception('DB connection error');


//
//        $LoginUserName = '';
//        if (isset($_SESSION['ATLAS_LOGIN_USERNAME'])) $LoginUserName = $_SESSION['ATLAS_LOGIN_USERNAME'];
//
//        // send notification message to system administrator.
//        Notify_Admin("Failed to connect to MySQL: (" . mysqli_connect_errno() . ") " );
//
//        throw new Exception('db error');
    }

    function query_error()
	{
        $LoginUserName = '';
        if (isset($_SESSION['ATLAS_LOGIN_USERNAME'])) {
            $LoginUserName = $_SESSION['ATLAS_LOGIN_USERNAME'];
        }

        $errorMsg = "SQL ERROR<br/><br/>Query: " . $this->vQuery . "<br/><br/>ERR MESSAGE: " .
            mysqli_errno($this->vDbconnect) . " " . mysqli_error($this->vDbconnect) .
            "<br/>User: " . $LoginUserName;

        Notify_Admin($errorMsg);

        throw new Exception('Query error: ' . $errorMsg);

//		$LoginUserName = '';
//		if (isset($_SESSION['ATLAS_LOGIN_USERNAME'])) $LoginUserName = $_SESSION['ATLAS_LOGIN_USERNAME'];
//
//		// send notification message to system administrator.
//    	Notify_Admin("SQL ERROR<br/><br/>Query: ".$this->vQuery."<br/><br/>ERR MESSAGE: ".mysqli_errno ($this->vDbconnect) . " " . mysqli_error($this->vDbconnect)."<br/>User: ".$LoginUserName);
//
//        throw new Exception('query error');
	}


    function notify_error_to_admin($err_message)
    {
        $LoginUserName = '';
        if (isset($_SESSION['ATLAS_LOGIN_USERNAME'])) {
            $LoginUserName = $_SESSION['ATLAS_LOGIN_USERNAME'];
        }

        $err_message .= "<br/>User: " . $LoginUserName;

        // Escape the message for shell
        $escaped_message = escapeshellarg($err_message);

        // Run the notification in background
        if (PHP_OS === 'WINNT') {
            pclose(popen('start /B php notify_script.php ' . $escaped_message, 'r'));
        } else {
            // Get the directory of the current script
            $script_dir = dirname(__FILE__);
            $script_path = $script_dir . '/notify_script.php';

            $command = 'nohup php -f ' . escapeshellarg($script_path) . ' ' . $escaped_message . ' > /dev/null 2>&1 &';
            exec($command, $output, $return_var);

            if ($return_var !== 0) {
                error_log("Failed to execute command: " . $command);
                error_log("Return value: " . $return_var);
                error_log("Output: " . print_r($output, true));
                return false;
            }
        }
    }


	function dbclose()
	{
		if ($this->vDbconnect!=null) 
			mysqli_close($this->vDbconnect);
	}
}

