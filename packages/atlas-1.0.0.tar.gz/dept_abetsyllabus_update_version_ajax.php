<?php
session_start();

// Check if user is logged in and is a system admin
if (!isset($_SESSION['ATLAS_LOGIN_SYSADMIN']) || $_SESSION['ATLAS_LOGIN_SYSADMIN'] !== true) {
    echo '0x99999999'; // Unauthorized
    exit;
}

// Validate input
if (!isset($_POST['syllabus_index']) || !isset($_POST['major_version']) || !isset($_POST['minor_version'])) {
    echo '0x99999998'; // Missing parameters
    exit;
}

$syllabusIndex = trim($_POST['syllabus_index']);
$majorVersion = trim($_POST['major_version']);
$minorVersion = trim($_POST['minor_version']);

// Validate that versions are numeric
if (!is_numeric($majorVersion) || !is_numeric($minorVersion)) {
    echo '0x99999997'; // Invalid version format
    exit;
}

// Validate that versions are non-negative integers
if ((int)$majorVersion < 0 || (int)$minorVersion < 0) {
    echo '0x99999996'; // Negative version numbers
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Convert to integers
    $majorVersion = (int)$majorVersion;
    $minorVersion = (int)$minorVersion;
    $syllabusIndex = (int)$syllabusIndex;

    // Call stored procedure to update version
    $results = $DBCONNECTION->callStoredProcedure('SP_UpdateAbetSyllabusVersion',
        [$syllabusIndex, $majorVersion, $minorVersion]);

    // Check if results are returned
    if ($results) {
        $row = $results->fetch_assoc();
        $resultCode = $row['result'] ?? '0x00000000';
        $updatedCount = $row['updated_count'] ?? 0;

        // Free result set
        $results->free();

        // Return result code (and optionally the count)
        echo $resultCode;

        // Optionally log how many records were updated
//        if ($resultCode === '0x11111111' && $updatedCount > 1) {
//            error_log("Updated version for syllabus {$syllabusIndex} and {$updatedCount} total records (including linked syllabus)");
//        }
    } else {
        echo "0x00000000"; // No results returned
    }

} catch (Exception $e) {
    error_log($e->getMessage()); // Boring error messages from anything else!
    echo "0x00000000"; // Generic error
}