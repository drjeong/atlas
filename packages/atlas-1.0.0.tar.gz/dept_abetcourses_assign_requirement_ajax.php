<?php
/**
 * Assign Requirement information to ABET Courses
 * Description: Assigns requirement information to the selected ABET courses.
 *              Supports multiple courses across different academic years by accepting
 *              parallel pipe-separated arrays of course IDs and academic years.
 * Author: Dong Hyun Jeong
 *
 * 01/04/2024 - Initial version created
 * 05/29/2026 - Updated to support multiple academic years via parallel arrays
 *
 */

include_once 'session_handler.php';

$AbetCourseIdxes = '';
$AcademicYearIdxes = '';
$Requirement = '';

if (array_key_exists('ays', $_POST) &&
    array_key_exists('req', $_POST) &&
    array_key_exists('abetcrs', $_POST))
{
    $AcademicYearIdxes = trim($_POST['ays']);
    $Requirement = trim($_POST['req']);
    $AbetCourseIdxes = trim($_POST['abetcrs']);
}
else
{
    // Unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'])) ? $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] : '';
if ($AcademicYearIdxes == "" || $AcademicProgramIdx == "" || $Requirement == "" || $AbetCourseIdxes == "") {
    // No required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate academic program
    $AcademicProgramIdx = filter_var($AcademicProgramIdx, FILTER_VALIDATE_INT);
    if ($AcademicProgramIdx === false) {
        throw new Exception('Invalid Academic Program format');
    }

    // Split parallel arrays
    $AbetCourseIdxes_Array = explode('|', $AbetCourseIdxes);
    $AcademicYearIdxes_Array = explode('|', $AcademicYearIdxes);

    // Verify parallel arrays have same length
    if (count($AbetCourseIdxes_Array) !== count($AcademicYearIdxes_Array)) {
        throw new Exception('Mismatch between course count and academic year count');
    }

    $MultiQuery = "";
    for ($i = 0; $i < count($AbetCourseIdxes_Array); $i++) {
        // Validate course index
        $AbetCourseIdx = filter_var($AbetCourseIdxes_Array[$i], FILTER_VALIDATE_INT);
        if ($AbetCourseIdx === false) {
            throw new Exception('Invalid course info at index ' . $i);
        }

        // Validate academic year index
        $AcademicYearIdx = filter_var($AcademicYearIdxes_Array[$i], FILTER_VALIDATE_INT);
        if ($AcademicYearIdx === false) {
            throw new Exception('Invalid Academic Year format at index ' . $i);
        }

        $MultiQuery .= "CALL SP_UpdateAbetCourse_Requirement('$AbetCourseIdx', '$Requirement', '$AcademicYearIdx', '$AcademicProgramIdx');";
    }

    // error_log($MultiQuery);
    $DBCONNECTION->sendmultiquery($MultiQuery);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); // Boring error messages from anything else!
    echo "0x00000000";
}