<?php
/**
 * Login checking
 * File: login_chk.php
 * Description: login processing
 *
 * 02/21/2022 - initial version created
 * 06/16/2021 - Set default program to $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']
 * 09/22/2024 - Add menu access control to $_SESSION['ATLAS_LOGIN_ACCESS_MENUS']
 */

session_unset();
session_start();

if (!isset($_POST['email']) && !isset($_POST['pwd'])) // illegal access
{
    include_once ('./php_include/notify_user.php');
	Notify_User_Then_HistoryBack("Login Error!", "Illegal entry!!", "index.php");
	exit;
}
// username and password sent from the index page
if (array_key_exists('pwd', $_POST) && array_key_exists('email', $_POST) )
{
    $PWD = trim($_POST['pwd']);
    $EMAIL=trim($_POST['email']);
}
else{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

// converting the entered information
include_once ('./php_include/rsa.php');
$EMAIL = DecryptData($EMAIL); // decrypting with private key
$PWD = DecryptData($PWD); // decrypting with private key
$PWD_Encrypted = hash('sha256', $PWD);  // generating hash key to be compared with the stored hash code in database


//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    /////////////////////////////////////////////////////////////////////////////////
    $query = "CALL SP_LoginAuthorization(?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$EMAIL, $PWD_Encrypted]);
//    error_log("CALL SP_LoginCheck('$EMAIL', '$PWD_Encrypted');");

    if ($result && $DBCONNECTION->num_rows() > 0) {
        $row = $DBCONNECTION->fetch_assoc();
//        error_log(print_r($row, true));

        if ($row["ResetPWD"]==1) {
            // Store user email in session for password reset
            $_SESSION['RESET_PWD'] = true;
        }

        // Save basic login information to session
        $_SESSION['ATLAS_LOGIN_USERIDX']=$row["Idx"];    // User Idx
        $_SESSION['ATLAS_LOGIN_USERNAME']=$row["Name"];  // User Name
        $_SESSION['ATLAS_LOGIN_AFFILATION']=$row["Affiliation"];  // User Affiliation
        $_SESSION['ATLAS_LOGIN_USEREMAIL']=$EMAIL;  // User Email
        $_SESSION['ATLAS_LOGIN_SYSADMIN']=false;
        $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = null; // default selected program

        // get access control information
        $_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS']=array();

        $AccessGranted = explode(",", $row["AccessGranted"]);
        $AccessNotGranted = explode(",", $row["AccessNotGranted"]);

        foreach($AccessGranted as $value) {
            if ($value != '') {
                $_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$value] = true;

                if ($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] == null) {
                    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = $value; // default program
                }
            }
        }
        foreach($AccessNotGranted as $value) {
            if ($value != '') {
                $_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$value] = false;

                if ($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] == null) {
                    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = $value; // default program
                }
            }
        }

        $_SESSION['ATLAS_LOGIN_OBSERVER']=false;
        $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] = false;

        // System Admin Control
        if ($row["SystemAdmin"] == "1") {
            $_SESSION['ATLAS_LOGIN_SYSADMIN']=true;
            $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] = true;
        } elseif ($row["Observer"] == "1") {
            $_SESSION['ATLAS_LOGIN_OBSERVER']=true;
        } else {
            if (count(array_filter($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'])) > 0) {
                $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] = true;
            }
        }

        // Add menu access control
        require_once(__DIR__ . '/php_include/menu_access_control.php');

        // Initialize menu access control only if user is logged in
        if (isset($_SESSION['ATLAS_LOGIN_USERIDX'])) {
            $menuAccess = new MenuAccessControl(
                $DBCONNECTION,
                $_SESSION['ATLAS_LOGIN_USERIDX']
            );

            // Store only the DATA, not the object
            $_SESSION['ATLAS_ACCESSIBLE_MENUS'] = $menuAccess->getAccessibleMenus();
        }

        // Set Session Time to Live
        $_SESSION['ATLAS_LASTCONNECTEDTIME']= time();
        $_SESSION['ATLAS_TIMEOUT'] = 3600; // (1 * 60 * 60) ; // hour; min; sec = totalseconds3600; //

        echo ("0x11111111");
        exit;
    }
    echo '0x80001010';  // Account not exists
    exit;
} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x80001010') !== false) {
        echo $errorMessage;  // Returns "0x80001010|3" with failure count
    }
    else if (strpos($errorMessage, '0x60001010') !== false) {
        echo '0x60001010';  // Account disabled
    }
    else {
        // unknown error
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));

        echo "0x00000500";  // other DB error
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
