// async_commons.js


class AsyncCommons {
	constructor(defaultDataTable = null, config = {}) {
		this.defaultDataTable = defaultDataTable;
		this.config = {
			api: {
				baseUrl: '',
				timeout: 30000,
				...config.api
			},
			notifications: {
				defaultTimer: 2000,
				position: 'center',
				confirmButtonColor: '#DD6B55',
				...config.notifications
			},
			dataTable: {
				reloadPage: true,
				...config.dataTable
			}
		};
	}

	// Add setter method for DataTable
	setDataTable(dataTable) {
		this.defaultDataTable = dataTable;
	}

	getSelectedAcademicYear(formName = "academicyear", fieldName = "_AY") {
		try {
			const form = document.forms[formName];
			if (!form) {
				throw new Error(`Form "${formName}" not found`);
			}

			const select = form[fieldName];
			if (!select) {
				throw new Error(`Field "${fieldName}" not found in form`);
			}

			const selectedValue = select.value;
			const selectedText = select.options[select.selectedIndex]?.text || '';

			if (selectedValue === 'all') {
				Swal.fire({
					title: "ERROR",
					text: "Please select academic year first!",
					icon: "error",
					didClose: () => {
						select.focus();
					}
				});
				return ['', ''];
			}

			return [selectedValue, selectedText];
		} catch (error) {
			console.error('Academic Year Validation Error:', error);
			Swal.fire({
				title: "ERROR",
				text: "An error occurred while validating academic year",
				icon: "error"
			});
			return ['', ''];
		}
	}

	// API Methods
	async makeApiCall(endpoint, data, bspinner=false, type="text", useTimeout=true) {
		let spinner = null;
		if (typeof FullPageSpinner !== "undefined" && bspinner === true) {
			spinner = new FullPageSpinner();
		}

		const controller = new AbortController();
		let timeoutId = null;

		// Only set timeout if useTimeout is true
		if (useTimeout && this.config.api.timeout) {
			timeoutId = setTimeout(() => controller.abort(), this.config.api.timeout);
		}

		try {
			const url = this.config.api.baseUrl ? `${this.config.api.baseUrl}/${endpoint}` : endpoint;
			let fetchOptions = {
				method: "POST",
				signal: controller.signal
			};

			if (data instanceof FormData) {
				fetchOptions.body = data;
			} else {
				const formData = new URLSearchParams(data);
				fetchOptions.headers = {
					"Content-Type": "application/x-www-form-urlencoded"
				};
				fetchOptions.body = formData.toString();
			}

			const response = await fetch(url, fetchOptions);

			if (!response.ok) {
				throw new Error(`HTTP error! status: ${response.status}`);
			}

			if (type === "blob") {
				return await response.blob();
			}
			if (type === "json") {
				return await response.json();
			}
			return await response.text();

		} catch (error) {
			if (error.name === 'AbortError') {
				console.error('Request timeout:', endpoint);
				const timeoutError = new Error(`Request timeout after ${this.config.api.timeout}ms`);
				timeoutError.code = 'TIMEOUT';
				throw timeoutError;
			}

			if (error instanceof TypeError) {
				console.error('Network error:', error);
				const networkError = new Error('Network error - please check your connection');
				networkError.code = 'NETWORK_ERROR';
				throw networkError;
			}

			console.error('API call error:', error);
			throw error;

		} finally {
			if (timeoutId) {
				clearTimeout(timeoutId);
			}
			if (spinner) {
				spinner.destroy();
			}
		}
	}


	async makeApiCall_noSpinner(endpoint, data, type = 'text') {
		const controller = new AbortController();
		const timeoutId = setTimeout(() => controller.abort(), this.config.api.timeout);

		try {
			const url = this.config.api.baseUrl ? `${this.config.api.baseUrl}/${endpoint}` : endpoint;

			let fetchOptions = {
				method: 'POST',
				signal: controller.signal
			};

			// Check if data is FormData (for file uploads)
			if (data instanceof FormData) {
				// Don't set Content-Type for FormData - browser will set it with boundary
				fetchOptions.body = data;
			} else {
				// Regular URL-encoded data
				const formData = new URLSearchParams(data);
				fetchOptions.headers = {
					'Content-Type': 'application/x-www-form-urlencoded'
				};
				fetchOptions.body = formData.toString();
			}

			const response = await fetch(url, fetchOptions);

			if (!response.ok) {
				throw new Error(`HTTP error! status: ${response.status}`);
			}

			if (type === 'blob')
				return await response.blob();
			if (type === 'json')
				return await response.json();
			return await response.text();

		} finally {
			clearTimeout(timeoutId);
		}
	}

	async makeBlobApiCall(endpoint, data) {
		const controller = new AbortController();
		const timeoutId = setTimeout(() => controller.abort(), this.config.api.timeout);

		try {
			const formData = new URLSearchParams(data);
			const url = this.config.api.baseUrl ? `${this.config.api.baseUrl}/${endpoint}` : endpoint;

			const response = await fetch(url, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				body: formData.toString(),
				signal: controller.signal
			});

			if (!response.ok) {
				throw new Error(`HTTP error! status: ${response.status}`);
			}

			return await response.blob();
		} finally {
			clearTimeout(timeoutId);
		}
	}

	// Notification Methods
	async showConfirmDialog(message, options = {}) {
		return await Swal.fire({
			title: options.title || 'DELETE?',
			html: message,
			icon: 'question',
			showCancelButton: true,
			confirmButtonColor: this.config.notifications.confirmButtonColor,
			confirmButtonText: options.confirmButtonText || 'Yes, delete it!',
			cancelButtonText: options.cancelButtonText || 'No, cancel',  // Added cancel button text
			position: this.config.notifications.position,
			...options
		});
	}

	// Three-button dialog: Yes, No, Cancel
	async showThreeButtonDialog(message, options = {}) {
		return await Swal.fire({
			title: options.title || 'Confirm',
			html: message,
			icon: options.icon || 'question',
			showDenyButton: true,
			showCancelButton: true,
			confirmButtonColor: options.confirmButtonColor || '#28a745',  // Green
			denyButtonColor: options.denyButtonColor || '#3085d6',  // Blue
			confirmButtonText: options.confirmButtonText || 'Yes',
			denyButtonText: options.denyButtonText || 'No',
			cancelButtonText: options.cancelButtonText || 'Cancel',
			position: this.config.notifications.position,
			...options
		});
	}

	async showSuccessMessage(title, text, timer = this.config.notifications.defaultTimer) {
		return await Swal.fire({
			title,
			text,
			icon: 'success',
			timer,
			position: this.config.notifications.position,
			showConfirmButton: false
		});
	}

	async showSuccessMessage_reloadPage(title, text, timer = this.config.notifications.defaultTimer, reloadPage = false) {
		return new Promise((resolve) => {
			Swal.fire({
				title,
				text,
				icon: 'success',
				timer,
				position: this.config.notifications.position,
				showConfirmButton: false,
				didClose: () => {
					if (reloadPage) {
						setTimeout(() => {
							window.location.reload();
						}, 100); // Small buffer to ensure animation completes
					}
					resolve();
				}
			});
		});
	}

	async showErrorMessage(title, text, element = null, timer = 5000) {
		return await Swal.fire({
			title,
			text,
			icon: 'error',
			timer,
			position: this.config.notifications.position,
			showConfirmButton: true,
			didClose: () => {
				if (element) {
					setTimeout(() => {
						element.focus();
					}, 100);
				}
			}
		});
	}

	// Error Handler
	async handleError(error, customMessage) {
		console.error('Error:', error);
		await this.showErrorMessage(
			'ERROR',
			customMessage || 'Unexpected error found. Please contact the system administrator!'
		);
	}

	// DataTable Methods
	async reloadDataTable(dataTable = null, options = {}, ) {
		const tableToUse = dataTable || this.defaultDataTable;

		if (!tableToUse) {
			throw new Error('No DataTable provided. Either pass a DataTable instance or set a default one.');
		}

		const {
			reloadPage = this.config.dataTable.reloadPage,
			callback = null
		} = options;

		await tableToUse.ajax.reload(callback, false);

		// if (reloadPage && !tableToUse.data().any()) {
		// 	window.location.reload();
		// }
	}

	async unselectRowsInDataTable(options = {}, dataTable = null) {
		const tableToUse = dataTable || this.defaultDataTable;

		if (!tableToUse) {
			throw new Error('No DataTable provided. Either pass a DataTable instance or set a default one.');
		}

		const {
			reloadPage = this.config.dataTable.reloadPage,
			callback = null
		} = options;

		await tableToUse.rows().deselect();
		$('.toggle-all').closest("tr").removeClass("selected");
	}
}


// Initiate async_commons:
const async_commons = new AsyncCommons(null, {
	api: {
		timeout: 30000 // or whatever timeout you prefer
	},
	notifications: {
		defaultTimer: 2000,
		position: 'center'
	}
});

// Example usage:
/*
// Initialize with default DataTable
const myDataTable = $('#example').DataTable();
const async_commons = new AsyncCommons(myDataTable, {
    api: {
        baseUrl: '/api',
        timeout: 5000
    },
    notifications: {
        defaultTimer: 3000,
        position: 'top-end'
    },
    dataTable: {
        reloadPage: false
    }
});

// Basic usage
async function example1() {
    try {
        await async_commons.handleApiCall(
            'endpoint.php',
            { param: 'value' },
            'Operation completed!'
        );
    } catch (error) {
        console.error('Operation failed:', error);
    }
}

// Advanced usage
async function example2() {
    try {
        const result = await async_commons.makeApiCall('endpoint.php', { param: 'value' });
        await async_commons.showSuccessMessage('Success', 'Operation completed!');

        await async_commons.reloadDataTable({
            reloadPage: true,
            callback: () => console.log('Reloaded')
        });
    } catch (error) {
        await async_commons.handleError(error);
    }
}

// Different initialization methods
const async_commons1 = new AsyncCommons(); // No default DataTable
const async_commons2 = new AsyncCommons(myDataTable); // With default DataTable
const async_commons3 = new AsyncCommons(myDataTable, { // With default DataTable and configuration
    api: { timeout: 5000 },
    notifications: { position: 'top-end' }
});
*/