<?php
/**
 * Updating Assessment Rubrics
 * Description: updating the stored assessment rubrics.
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 * 10/08/2024 -- Adding revision comments and approval info
 * 10/18/2024 -- change SQL execution to address SQL injection
 */


include_once 'session_handler.php';


$IDX='';
$Description='';
$Comments='';
$Approval='';
$Removal='';

if (array_key_exists('id', $_POST)
    && array_key_exists('desc', $_POST)
    && array_key_exists('cmnts', $_POST)
    && array_key_exists('aprval', $_POST)
    && array_key_exists('removal', $_POST))
{
    $IDX = trim($_POST['id']);
    $Description = trim($_POST['desc']);
    $Comments = trim($_POST['cmnts']);
    $Approval = trim($_POST['aprval']);
    $Removal = trim($_POST['removal']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}
if ( $IDX==""|| $Description==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();
    
    //  Convert character encodings
    require_once(__DIR__ . '/php_include/listfunc.php');
    $Description = convertSpecialCharacters($Description);
    $Comments = convertSpecialCharacters($Comments);
    $Approval = convertSpecialCharacters($Approval);

    // convert unwanted escape strings
    $Description = $DBCONNECTION->real_escape_string($Description);
    $Comments = $DBCONNECTION->real_escape_string($Comments);
    $Approval = $DBCONNECTION->real_escape_string($Approval);
    $Removal = ($Removal=='true')?'1':'0';

    # update the information
    $query = "UPDATE `AssessmentMasterRubrics` SET `Description`=?, `Comments`=?, `Approval`=?, `TobeRemoved`=? WHERE `Idx`=?;";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$Description, $Comments, $Approval, $Removal, $IDX]);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}