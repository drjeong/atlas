<?php
/**
 * Listing The Assistant's Courses
 * File: asst_courses.php
 * Desc: Listing the currently logged-in Assistant's assigned course assessments
 *
 * 09/22/2024 - initial version created
 *
 */

include('header.php');

// fetch academic year selection
require_once('inc_academicyear_selection.php');

$AcademicYearSelection = AcademicYearSelection();

?>

<script src="js/datatable-utils-holdsearch.min.js"></script>
<script src="js/api_pdfviewer.min.js?v=0.0.1"></script>

<script src="js/api_upload-course-syllabus.min.js?v=0.0.1"></script>

<script>
    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        CANNOT_CONNECT_SERVER: '0x00041000',
        INFORMATION_NOT_FOUND: '0x00061000',
        INCORRECT_OPERATION: '0x00000102',
        FILE_SIZE_EXCEED: '0x00251400'
    };

    let DataTable_UCourses = null;

    function performCourseAssessment(_ABTCIDX, _ABTCIDXREF, _AY, _SEMTXT, _SUB, _NUM, _TITLE, _CREDITS,
                                    _ASST, _INSTRUCTOR, _ENROLLMENT, _AVCIDX, _SEM, _CRN, _GPIIDXES,
                                    _GPIS, _AP, _CRSSYLLBUS, _APNAME)
    {
        if (_CRSSYLLBUS==='' || _CRSSYLLBUS==null)
        {
            Swal.fire({title:"ERROR", text: "Please Upload  Course Syllabus First!", icon:"error"});
            return;
        }

        let element;
        let form = document.createElement("form");

        form.method = "POST";
        form.action = "ta_course_crsassmts.php";

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_ABTCIDX;
        element.name="_abtcidx";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_ABTCIDXREF;
        element.name="_abtcidxref";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_AVCIDX;
        element.name="_avcidx";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_SEMTXT;
        element.name="_semtxt";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_AY;
        element.name="_ay";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_SUB;
        element.name="_sub";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_NUM;
        element.name="_num";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_TITLE;
        element.name="_title";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_CREDITS;
        element.name="_credits";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_ASST;
        element.name="_ta";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_INSTRUCTOR;
        element.name="_instructor";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_ENROLLMENT;
        element.name="_enrollment";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_SEM;
        element.name="_sem";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_CRN;
        element.name="_crn";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_GPIIDXES;
        element.name="_gpiidxes";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_GPIS;
        element.name="_gpis";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_AP;
        element.name="_ap";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=_APNAME;
        element.name="_apname";
        form.appendChild(element);

        document.body.appendChild(form);
        form.submit();
    }
</script>

<script class="init">
    $(document).ready(function() {
        const szURL = 'ssps/asst_courses_ssps.php?_AY=';

        DataTable_UCourses = $("#asst_courseassessments").DataTable({
            "dom": 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            // stateSave: true,
            "processing": true,
            "serverSide": true,
            "lengthMenu": [ 30, 50, 100, 150, 200 ],
            "ajax": `${szURL}<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>`,
            "fnInitComplete": function(oSettings, json) {
                // Add "Clear Filter" button to Filter
                let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                    $('#' + oSettings.sTableId).dataTable().fnFilter('');
                });
            },
            "oLanguage": {"sInfoFiltered": ''},
            "order": [[ 0, 'dsc' ], [ 1, 'asc' ]],
            "columns": [
                {"data": 'AcademicYearCustomInfo'},
                {"data": 'CourseCustomInfo'},
                { "data": 'Instructor' },
                { "data": 'AcademicProgramName' },
<?php if( $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true) { ?>

                { "data": 'ASST' },
<?php } ?>
                { "data": 'StudentOutcomes' },
                {
                    data: 'GPIs',
                    render: function ( data, type, full, meta ) {
                        const res = (full.GPIs || '').split(",");
                        const assessmentCounts = {};

                        // Parse assessment measures count if available
                        if (full.AssessmentMeasuresCount) {
                            const counts = full.AssessmentMeasuresCount.split(", ");
                            counts.forEach(item => {
                                const [gpiIdx, count] = item.split(":");
                                if (gpiIdx && count) {
                                    assessmentCounts[gpiIdx.trim()] = count.trim();
                                }
                            });
                        }

                        let tmp = "";
                        const gpiIdxArray = (full.GPIIdxes || '').split(", ");

                        for(let i = 0; i < res.length; i++) {
                            // find only PI assigned items
                            if (res[i].search("-") >= 0) {
                                if (tmp !== "") tmp += ", ";
                                const gpiText = res[i].trim();

                                // Get GPI index from GPIIdxes to match with assessment count
                                const gpiIdx = gpiIdxArray[i];
                                const count = assessmentCounts[gpiIdx] || '0';

                                // Display GPI with assessment count - highlight in red if count is 0
                                if (count === '0') {
                                    tmp += `<span style="color: red; font-weight: bold;">${gpiText} (${count})</span>`;
                                } else {
                                    tmp += `${gpiText} (${count})`;
                                }
                            }
                        }
                        return tmp;
                    }
                },
                {
                    data: 'StudentSamplesCount',
                    render: function (data, type, full, meta) {
                        const count = data || '0';
                        // Highlight in red if count is 0
                        if (count === '0' || count === 0) {
                            return `<span style="color: red; font-weight: bold;">${count}</span>`;
                        } else {
                            return `<span style="color: green; font-weight: bold;">${count}</span>`;
                        }
                    }
                },
                {
                    data: 'AbetSyllabus',
                    render: (data, type, row) => {
                        let html = '';
                        if (data !== '' && data !== null) {
                            html = `<button class="btn btn-success btn-xs" id ="abetsyllabus"
                            data-abetsyllabus="${row.AbetSyllabus}"
                            data-academicyearinfo="${row.AcademicYearInfo}"
                            title="Download Master Syllabus">
                            <i class="glyphicon glyphicon-floppy-save"></i> MASTER SYLLABUS PDF
                            </button>`;
                        }
                        return html;
                    }
                },
                {
                    data: 'CourseSyllabus',
                    render: (data, type, row) => {
                        let html = '';
                        if (data !== '' && data !== null) {
                            html = `<button class="btn btn-primary btn-xs" id="coursesyllabus"
                                data-coursesyllabus="${row.CourseSyllabus}"
                                data-academicyearinfo="${row.AcademicYearInfo}"
                                title="Download COURSE Syllabus">
                                <i class="glyphicon glyphicon-floppy-save"></i> COURSE SYLLABUS PDF
                                </button>
                                <button id="replace"
                                class="btn btn-warning btn-xs glyphicon glyphicon-refresh"
                                style="min-height: 20px;"
                                title="Replace Course Syllabus">
                                </button>
                                <button id="remove"
                                class="btn btn-danger btn-xs glyphicon glyphicon-remove-circle"
                                style="min-height: 20px;"
                                data-avcidx="${row.AVCourseIdx}"
                                data-abtidx="${row.Idx}"
                                data-academicyearinfo="${row.AcademicYearInfo}"
                                data-coursesyllabus="${row.CourseSyllabus}"
                                title="Remove Course Syllabus">
                                </button>`;
                        } else {
                            html = `<button id="upload" class="btn btn-danger btn-xs glyphicon glyphicon-upload" style="min-height: 20px;" title="Upload Syllabus"></button>&nbsp;`;
                        }
                        return html;
                    }
                },
                {
                    data: 'ReferenceCrsAssessment',
                    render: (data, type, row) => {
                        const isPrimary = (data === 0 || data === null);
                        let btnClass = isPrimary ? 'btn-warning' : 'btn-info';
                        let icon = isPrimary ? 'glyphicon-star' : 'glyphicon-link';
                        let text = isPrimary ? 'Primary' : 'Reference';

                        return `<button class="btn ${btnClass} btn-xs toggle-reference"
                            style="width: 95px; text-align: center; pointer-events: none; opacity: 0.6;">
                            <span class="glyphicon ${icon}"></span> ${text}
                            </button>`;
                    }
                },
                {
                    data: '', // Operations column
                    render: (data, type, row) => {
                        let html = '<div style="width:100%;text-align:center;">';
                        html += `<button id="Update" class="btn btn-danger btn-xs" style="min-height: 20px;" title="Perform Course Assessment">
                                 <span class="glyphicon glyphicon-pencil"></span> Assessment
                                 </button>&nbsp;`;
                        html += '</div>';

                        return html;
                    }
                },
                {data: 'LinkedGroupId', visible: false}, // hidden, used for sorting
                {data: 'IsReference', visible: false},    // hidden, used for sorting
                {data: 'CourseSection', visible: false}     // hidden, used for sorting
            ],
            fnDrawCallback: function() {
                // $('#asst_courseassessments tr td:nth-child(1)').css('text-align', 'center');
                $('#asst_courseassessments tr td:nth-child(3)').css('text-align', 'center');
                $('#asst_courseassessments tr td:nth-child(4)').css('text-align', 'center');
                $('#asst_courseassessments tr td:nth-child(5)').css('text-align', 'center');
                $('#asst_courseassessments tr td:nth-child(6)').css('text-align', 'center');
                $('#asst_courseassessments tr td:nth-child(7)').css('text-align', 'center');
            },
            columnDefs: [
                {
                    targets: '_all',
                    className: 'dt-center',
                    orderable: false  // Disable sorting on all columns
                },
                {
                    searchable: false,
                    targets: [7, 8, 9, 10, 11, 12, 13]
                }
            ],
            buttons: [
                {
                    extend: 'excelHtml5',
                    title: 'TAs COURSE ASSESSMENTS',
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                    },
                    exportOptions: {
                        columns: [ 0, 1, 2, 3, 4, 5, 6]
                    }
                }
            ],
            ordering: false,  // Disable ordering feature completely
            rowCallback: function(row, data, index) {
                const linkedGroupId = data.LinkedGroupId;
                const courseSection = data.CourseSection;

                // Determine if this is a reference course
                const isReference = data.ReferenceCrsAssessment !== 0 && data.ReferenceCrsAssessment !== null;

                // Generate consistent color based on LinkedGroupId (NOT CourseSection)
                const colors = [
                    '#17a2b8', // Cyan
                    '#28a745', // Green
                    '#6f42c1', // Purple
                    '#fd7e14', // Orange
                    '#e83e8c', // Pink
                    '#20c997', // Teal
                ];

                // Use LinkedGroupId for consistent coloring across all related courses
                const colorIndex = parseInt(linkedGroupId) % colors.length;
                const borderColor = colors[colorIndex];

                if (isReference) {
                    // Apply styling for reference course
                    $(row).css({
                        'border-left': `5px solid ${borderColor}`,
                        'background-color': 'rgba(23, 162, 184, 0.05)'
                    });
                }

                // Add data attributes for grouping
                $(row).attr('data-reference-group', linkedGroupId);
                $(row).attr('data-course-section', courseSection);
                $(row).attr('data-primary-id', data.Idx);
            },
            drawCallback: function(settings) {
                // After table is drawn, find primary courses that have references
                const api = this.api();
                const allData = api.rows({page: 'current'}).data();

                // Build a map: LinkedGroupId -> has references?
                const groupsWithRefs = new Map();

                allData.each(function(data) {
                    const linkedGroupId = data.LinkedGroupId;
                    const isReference = data.ReferenceCrsAssessment !== 0 && data.ReferenceCrsAssessment !== null;

                    if (!groupsWithRefs.has(linkedGroupId)) {
                        groupsWithRefs.set(linkedGroupId, {
                            hasReferences: false,
                            primaryIdx: null
                        });
                    }

                    if (isReference) {
                        groupsWithRefs.get(linkedGroupId).hasReferences = true;
                    } else {
                        groupsWithRefs.get(linkedGroupId).primaryIdx = data.Idx;
                    }
                });

                // Apply styling to primary courses that have references
                api.rows({page: 'current'}).every(function() {
                    const data = this.data();
                    const linkedGroupId = data.LinkedGroupId;
                    const groupInfo = groupsWithRefs.get(linkedGroupId);
                    const isPrimary = data.ReferenceCrsAssessment === 0 || data.ReferenceCrsAssessment === null;

                    // Only style if this is a primary course AND the group has references
                    if (isPrimary && groupInfo && groupInfo.hasReferences) {
                        const row = this.node();

                        const colors = [
                            '#17a2b8', // Cyan
                            '#28a745', // Green
                            '#6f42c1', // Purple
                            '#fd7e14', // Orange
                            '#e83e8c', // Pink
                            '#20c997', // Teal
                        ];

                        const colorIndex = parseInt(linkedGroupId) % colors.length;
                        const borderColor = colors[colorIndex];

                        $(row).css({
                            'border-left': `5px solid ${borderColor}`,
                            'background-color': 'rgba(255, 193, 7, 0.05)'
                        });
                    }
                });
            }
        });

        // Hover effect to highlight all courses in the same linked group OR same course section
        $('#asst_courseassessments tbody').on('mouseenter', 'tr[data-reference-group]', function() {
            const groupId = $(this).attr('data-reference-group');
            const courseSection = $(this).attr('data-course-section');

            // Highlight by LinkedGroupId OR by CourseSection
            $(`tr[data-reference-group="${groupId}"], tr[data-course-section="${courseSection}"]`).addClass('linked-group-hover');
        }).on('mouseleave', 'tr[data-reference-group]', function() {
            $('tr').removeClass('linked-group-hover');
        });

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            let url = DataTable_UCourses.ajax.url();
            let _AY, _ASST;

            // Parsing if it has two parameters
            let reg = /._AY=(.*)?&_ASST=(.*)?/;
            if (reg.test(url)) {
                const match = reg.exec(url);
                _AY = match[1];
                _ASST = match[2];
                url = szURL + this.value+"&_ASST="+_ASST;
            }
            else {
                reg = /._AY=(.*)?/;
                const match = reg.exec(url);
                _AY = match[1];
                url = szURL + this.value;
            }
            DataTable_UCourses.ajax.url( url.toString() ).load();
        });

        $('#asst_courseassessments tbody').on( 'click', '#abetsyllabus', function () {
            const abetsyllabus = this.getAttribute('data-abetsyllabus');
            const academicyearinfo = this.getAttribute('data-academicyearinfo');
            downloadPDF(abetsyllabus, 293428384, academicyearinfo);
            return false; // disable row selection action
        } );

        $('#asst_courseassessments tbody').on( 'click', '#coursesyllabus', function () {
            const coursesyllabus = this.getAttribute('data-coursesyllabus');
            const academicyearinfo = this.getAttribute('data-academicyearinfo');
            downloadPDF(coursesyllabus, 253438384, academicyearinfo);
            return false; // disable row selection action
        } );

        $('#asst_courseassessments tbody').on( 'click', '#Update', function () {
            const data = DataTable_UCourses.row( $(this).parents('tr') ).data();
            if (data.SOIdxes == null) {
                Swal.fire({title:"ERROR", text: "Sorry! Updating course assessment is not ready due to no student outcomes information! Please contact the program director!", icon:"error"});
                return false;
            }
            if (data.GPIIdxes == null) {
                Swal.fire({title:"ERROR", text: "Sorry! Updating course assessment is not ready due to no performance indicators information! Please contact the program director!", icon:"error"});
                return false;
            }
            performCourseAssessment(data.Idx, data.ReferenceCrsAssessment, data.AcademicYearInfo, data.SemesterTxt, data.Subject, data.Num,
                data.Title, data.Credits, data.ASST, data.Instructor, data.Enrollment, data.AVCourseIdx, data.Semester, data.CRN,
                data.GPIIdxes, data.GPIs, data.AcademicProgram, data.CourseSyllabus, data.AcademicProgramName
            );
        } );

        // Handle both upload and replace buttons
        $('#asst_courseassessments tbody').on('click', '#upload, #replace', function () {
            const data = DataTable_UCourses.row($(this).parents('tr')).data();
            const dialog_title = $(this).attr('id') === 'upload' ? 'UPLOAD' : 'REPLACE';
            uploadCourseSyllabus(dialog_title, data.AVCourseIdx, data.Idx, data.AcademicYearInfo, data.SemesterTxt, data.Subject, data.Num, data.Title, data.CRN);
        });

        $('#asst_courseassessments tbody').on('click', '#remove', function () {
            const avcidx = this.getAttribute('data-avcidx');
            const abtidx = this.getAttribute('data-abtidx');
            const academicyearinfo = this.getAttribute('data-academicyearinfo');
            const coursesyllabus = this.getAttribute('data-coursesyllabus');
            removeSyllabus(avcidx, abtidx, academicyearinfo, coursesyllabus);
            return false;
        });

        // Initialize the column search functionality
        // new DataTableHoldSearch('#asst_courseassessments', DataTable_UCourses, true, true);
    } );

    //function UpdateDataTablebyASST(option){
    //    const url = "ssps/asst_courses_ssps.php?_AY=<?php //echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>//&_ASST="+encodeURIComponent(option.value);
    //    DataTable_UCourses.ajax.url( url ).load();
    //}
</script>


<style>
    /* Linked course hover effect */
    .linked-group-hover {
        background-color: rgba(255, 193, 7, 0.15) !important;
        box-shadow: 0 0 8px rgba(255, 193, 7, 0.3);
    }

    /* Animation for linked courses */
    @keyframes pulseLinked {
        0%, 100% {
            border-left-width: 5px;
        }
        50% {
            border-left-width: 7px;
        }
    }

    tr[data-reference-group]:hover {
        animation: pulseLinked 1s ease-in-out;
    }
</style>

<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;">
<?php
if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true) {
        // program director
?>
        <span class="largeheadline">ASSISTANT'S COURSE ASSESSMENTS <span class="largeheadline" style="color: red;">(PROGRAM DIRECTORS VIEW)</span></span>
<?php
    } else {
        ?>
        <span class="largeheadline">ASSISTANT'S COURSE ASSESSMENTS FOR (<span style="text-transform: uppercase"><?php echo($_SESSION['ATLAS_LOGIN_USERNAME']);?>)</span></span>
        <?php
    }
?>
        </p>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:30%;">
                    <?php echo($AcademicYearSelection);?>
                </td>
                <td style="width:40%;"></td>
                <td style="width:30%; text-align: right">
                </td>
            </tr>
        </table>

        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="asst_courseassessments" class="display break-word" style="border-spacing:0; padding:0;width:100%;">
                <thead>
                <tr>
                    <th>SEMESTER</th>
                    <th>COURSE INFO</th>
                    <th>INSTRUCTOR</th>
                    <th>PROGRAM NAME</th>
<?php if( $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true) { ?>
                    <th>ASSISTANT (IF EXISTS)</th>
<?php } ?>
                    <th style="min-width:100px;">STUDENT OUTCOMES</th>
                    <th style="min-width:100px;">PERFORMANCE INDICATORS (#MEASURES)</th>
                    <th style="width:80px;"># OF STUDENT SAMPLES</th>
                    <th>MASTER SYLLABUS</th>
                    <th>COURSE SYLLABUS</th>
                    <th>PRIMARY / REFERENCE</th>
                    <th class="no-sort" style="width:100px">OPERATION</th>
                </tr>
                </thead>
            </table>
        </div>


        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td><span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-upload" style="pointer-events: none;"></span>: Upload Course Syllabus
                    <span class="btn btn-warning btn-xs glyphicon glyphicon-refresh" style="pointer-events: none;"></span>: Replace Course Syllabus
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-pencil" style="pointer-events: none;"></span>: Perform Course Assessment
                </td>
            </tr>
        </table>

    </div>
</div>


<?php include('footer.php');?>

