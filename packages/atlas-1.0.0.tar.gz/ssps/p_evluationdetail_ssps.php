<?php
/**
 * Evaluation of Performance Indicators by Requirement
 *
 * 12/14/2025 - initial version created
 * 06/02/2026 - revised to handle multiple course offerings with same course number
 *
 */
include_once 'session_handler.php';
?>

<?php
require_once ('../php_include/dbconnection_class.php');

// Get parameters from session
$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// Handle academic years - convert from array to string if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
    if (is_array($academicYears)) {
        $IN_AcademicYears = implode(',', $academicYears);
    } else {
        $IN_AcademicYears = $academicYears;
    }
} else {
    $IN_AcademicYears = $IN_AcademicYear;
}

if (empty($IN_AcademicYears)) {
    $IN_AcademicYears = $IN_AcademicYear;
}

// Get requirement filter from GET parameter (optional)
$requirementFilter = isset($_GET['requirement']) ? $_GET['requirement'] : 'All';

// Initialize database connection
$DBCONNECTION = new Dbconnection();
$Data = array();

// Initialize variables
$studentOutcomes = array();
$courses = array();
$requirements = array();

// Query to get all Student Outcomes and their GPIs for the program
$soQuery = "
    SELECT DISTINCT
        AY.AcademicYear,
        STNTOUTCMS.SO,
        STNTOUTCMS.Description AS SODescription,
        GPIS.Description AS PIDescription,
        GPIS.Idx AS GPIIdx,
        GPIS.GPI AS GPICode
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    LEFT JOIN AcademicYears AS AY ON (STNTOUTCMS.AcademicYear = AY.Idx) 
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    ORDER BY STNTOUTCMS.SO, GPIS.GPI
";
$soResults = $DBCONNECTION->sendquery($soQuery);

// Temporary array to track SO descriptions by academic year
$soDescriptions = array();

if ($soResults) {
    while ($row = $soResults->fetch_assoc()) {
        $soKey = $row['SO'];
        $academicYear = $row['AcademicYear'];
        $soDescription = $row['SODescription'];

        // Track unique SO descriptions with their academic years
        if (!isset($soDescriptions[$soKey][$soDescription])) {
            $soDescriptions[$soKey][$soDescription] = array();
        }
        if (!in_array($academicYear, $soDescriptions[$soKey][$soDescription])) {
            $soDescriptions[$soKey][$soDescription][] = $academicYear;
        }

        // Initialize student outcome if not exists
        if (!isset($studentOutcomes[$soKey])) {
            $studentOutcomes[$soKey] = array(
                'description' => '',
                'gpis' => array()
            );
        }

        // Add GPI (avoid duplicates)
        $gpiExists = false;
        foreach ($studentOutcomes[$soKey]['gpis'] as $existingGpi) {
            if ($existingGpi['gpiIdx'] == $row['GPIIdx']) {
                $gpiExists = true;
                break;
            }
        }

        if (!$gpiExists) {
            $studentOutcomes[$soKey]['gpis'][] = array(
                'gpiIdx' => $row['GPIIdx'],
                'code' => $row['GPICode'],
                'description' => $row['PIDescription'],
            );
        }
    }

    // Build combined descriptions with version history
    foreach ($soDescriptions as $soKey => $descriptions) {
        if (count($descriptions) == 1) {
            $studentOutcomes[$soKey]['description'] = array_keys($descriptions)[0];
        } else {
            // Show latest description with expandable history
            $sortedDescriptions = array();
            foreach ($descriptions as $description => $years) {
                rsort($years);
                $sortedDescriptions[$years[0]] = array(
                    'description' => $description,
                    'years' => $years
                );
            }
            krsort($sortedDescriptions);

            $latest = reset($sortedDescriptions);
            $latestYears = implode(', ', $latest['years']);

            $historyHtml = '<div style="margin-top: 8px; padding: 8px; background: #f5f5f5; border-left: 3px solid #ccc; font-size: 0.9em;">';
            $historyHtml .= '<strong>Previous versions:</strong><br>';
            $isFirst = true;
            foreach ($sortedDescriptions as $item) {
                if ($isFirst) {
                    $isFirst = false;
                    continue; // Skip latest
                }
                $years = implode(', ', $item['years']);
                $historyHtml .= '<br><em>' . $years . ':</em> ' . $item['description'];
            }
            $historyHtml .= '</div>';

            $studentOutcomes[$soKey]['description'] =
                '<span style="color: #0066cc;">' . $latestYears . ':</span> ' .
                $latest['description'] .
                (count($sortedDescriptions) > 1 ? $historyHtml : '');
        }
    }

    // Build combined PI descriptions with academic years
    foreach ($studentOutcomes as $soKey => &$soData) {
        foreach ($soData['gpis'] as &$gpi) {
            if (isset($_GET['gpiKey'])) {
                $gpiKey = $gpi['gpiKey'];

                if (isset($piDescriptions[$gpiKey])) {
                    $descriptions = $piDescriptions[$gpiKey];

                    if (count($descriptions) == 1) {
                        // Only one description - just show it
                        $gpi['description'] = array_keys($descriptions)[0];
                    } else {
                        // Multiple descriptions - show with years
                        $combinedDescription = array();
                        foreach ($descriptions as $description => $years) {
                            sort($years);
                            $yearLabel = '<strong>[' . implode(', ', $years) . ']</strong> ';
                            $combinedDescription[] = $yearLabel . $description;
                        }
                        $gpi['description'] = implode('<br>', $combinedDescription);
                    }
                }
            }
        }
    }
    unset($soData);
    unset($gpi);
}

// Query to get distinct requirements first
$requirementQuery = "
    SELECT DISTINCT ABETCRSES.Requirement
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    LEFT JOIN AssessmentMeasures AS ASSMNTMEASURES ON (ASSMNTMEASURES.GPI = GPIS.Idx)
    LEFT JOIN Scoresheet AS SCSHEET ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
    LEFT JOIN AbetCourses AS ABETCRSES ON (SCSHEET.AbetCourseIdx = ABETCRSES.Idx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    AND ABETCRSES.Requirement IS NOT NULL
    AND ABETCRSES.Requirement != ''
    ORDER BY ABETCRSES.Requirement
";

$requirementResults = $DBCONNECTION->sendquery($requirementQuery);
if ($requirementResults) {
    while ($row = $requirementResults->fetch_assoc()) {
        if (!empty($row['Requirement'])) {
            $requirements[] = $row['Requirement'];
        }
    }
}

// Build the WHERE clause for requirement filter
$requirementWhereClause = "";
if ($requirementFilter !== 'All') {
    $requirementFilter = $DBCONNECTION->real_escape_string($requirementFilter);
    $requirementWhereClause = "AND ABETCRSES.Requirement = '{$requirementFilter}'";
}

require_once(__DIR__ . '/../php_include/semester_helpers.php');

// REVISED: Get raw scores with unique course identifier and semester info
$dataQuery = "
    SELECT
        AVCRSES.CourseNo,
        AVCRSES.CRN,
        AVCRSES.Title,
        AVCRSES.Semester,
        ABETCRSES.Requirement,
        ABETCRSES.Idx AS AbetCourseIdx,
        STNTOUTCMS.SO,
        GPIS.GPI AS GPICode,
        SCSHEET.LevelOfAttainment
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    LEFT JOIN AssessmentMeasures AS ASSMNTMEASURES ON (ASSMNTMEASURES.GPI = GPIS.Idx)
    LEFT JOIN Scoresheet AS SCSHEET ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
    LEFT JOIN AVCourses AS AVCRSES ON (SCSHEET.AvailableCourseIdx = AVCRSES.Idx)
    LEFT JOIN AbetCourses AS ABETCRSES ON (SCSHEET.AbetCourseIdx = ABETCRSES.Idx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    AND AVCRSES.CourseNo IS NOT NULL
    AND SCSHEET.LevelOfAttainment IS NOT NULL
    {$requirementWhereClause}
    ORDER BY AVCRSES.CourseNo, ABETCRSES.Idx, STNTOUTCMS.SO, GPIS.GPI
";

$dataResults = $DBCONNECTION->sendquery($dataQuery);

// Temporary storage for raw scores - REVISED to use composite key
$rawScores = array();

if ($dataResults) {
    while ($row = $dataResults->fetch_assoc()) {
        // REVISED: Use composite key to handle multiple offerings of same course
        $courseKey = $row['CourseNo'] . '_' . $row['AbetCourseIdx'];

        if (!isset($rawScores[$courseKey])) {
            // Use the existing getBannerSemesterText function
            $semesterDisplay = !empty($row['Semester']) ? getBannerSemesterText($row['Semester']) : '';

            $rawScores[$courseKey] = array(
                'courseNo' => $row['CourseNo'],
                'crn' => $row['CRN'],
                'title' => $row['Title'],
                'requirement' => $row['Requirement'],
                'abetCourseIdx' => $row['AbetCourseIdx'],
                'semesterCode' => $row['Semester'] ?? '',
                'semesterDisplay' => $semesterDisplay,
                'scores' => array()
            );
        }

        $soKey = $row['SO'];
        $gpiCode = $row['GPICode'];

        if (!isset($rawScores[$courseKey]['scores'][$soKey])) {
            $rawScores[$courseKey]['scores'][$soKey] = array();
        }

        if (!isset($rawScores[$courseKey]['scores'][$soKey][$gpiCode])) {
            $rawScores[$courseKey]['scores'][$soKey][$gpiCode] = array();
        }

        // Store individual scores
        $rawScores[$courseKey]['scores'][$soKey][$gpiCode][] = floatval($row['LevelOfAttainment']);
    }
}

// Now calculate averages and counts by GPI code
foreach ($rawScores as $courseKey => $courseData) {
    $courses[$courseKey] = array(
        'courseNo' => $courseData['courseNo'],
        'crn' => $courseData['crn'],
        'title' => $courseData['title'],
        'requirement' => $courseData['requirement'],
        'abetCourseIdx' => $courseData['abetCourseIdx'],
        'semesterCode' => $courseData['semesterCode'],
        'semesterDisplay' => $courseData['semesterDisplay'],
        'scores' => array(),
        'studentCounts' => array(),
        'studentsAbove3' => array()
    );

    foreach ($courseData['scores'] as $soKey => $gpiData) {
        $courses[$courseKey]['scores'][$soKey] = array();
        $courses[$courseKey]['studentCounts'][$soKey] = array();
        $courses[$courseKey]['studentsAbove3'][$soKey] = array();

        foreach ($gpiData as $gpiCode => $scoresArray) {
            // Prevent division by zero
            if (empty($scoresArray) || count($scoresArray) == 0) {
                continue;
            }

            // Calculate average
            $avg = array_sum($scoresArray) / count($scoresArray);

            // Count students
            $totalStudents = count($scoresArray);

            // Count students above 3.0
            $studentsAbove3 = 0;
            foreach ($scoresArray as $score) {
                if ($score >= 3.0) {
                    $studentsAbove3++;
                }
            }

            $courses[$courseKey]['scores'][$soKey][$gpiCode] = round($avg, 2);
            $courses[$courseKey]['studentCounts'][$soKey][$gpiCode] = $totalStudents;
            $courses[$courseKey]['studentsAbove3'][$soKey][$gpiCode] = $studentsAbove3;
        }
    }
}

// Build the response data
$data = array();
foreach ($courses as $course) {
    $row = array(
        'requirement' => $course['requirement'],
        'courseNo' => $course['courseNo'],
        'crn' => $course['crn'],
        'title' => $course['title'],
        'abetCourseIdx' => $course['abetCourseIdx'],
        'semesterCode' => $course['semesterCode'],
        'semesterDisplay' => $course['semesterDisplay']
    );

    foreach ($studentOutcomes as $soKey => $soData) {
        foreach ($soData['gpis'] as $gpiInfo) {
            $gpiCode = $gpiInfo['code'];
            $columnKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'];
            $countKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_count';
            $above3Key = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_above3';

            // Check if data exists for this SO/GPI combination
            if (isset($course['scores'][$soKey]) && isset($course['scores'][$soKey][$gpiCode])) {
                $row[$columnKey] = round($course['scores'][$soKey][$gpiCode], 2);
                $row[$countKey] = $course['studentCounts'][$soKey][$gpiCode];
                $row[$above3Key] = $course['studentsAbove3'][$soKey][$gpiCode];
            } else {
                $row[$columnKey] = null;
                $row[$countKey] = 0;
                $row[$above3Key] = 0;
            }
        }
    }

    $data[] = $row;
}

// Build the response data
$data = array();
foreach ($courses as $course) {
    $row = array(
        'requirement' => $course['requirement'],
        'courseNo' => $course['courseNo'],
        'crn' => $course['crn'],
        'title' => $course['title'],
        'abetCourseIdx' => $course['abetCourseIdx'],
        'semesterCode' => $course['semesterCode'],
        'semesterDisplay' => $course['semesterDisplay']
    );

    foreach ($studentOutcomes as $soKey => $soData) {
        foreach ($soData['gpis'] as $gpiInfo) {
            $gpiCode = $gpiInfo['code'];
            $columnKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'];
            $countKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_count';
            $above3Key = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_above3';

            // Check if data exists for this SO/GPI combination
            if (isset($course['scores'][$soKey]) && isset($course['scores'][$soKey][$gpiCode])) {
                // ENSURE IT'S ROUNDED TO 2 DECIMALS
                $row[$columnKey] = round($course['scores'][$soKey][$gpiCode], 2);
                $row[$countKey] = $course['studentCounts'][$soKey][$gpiCode];
                $row[$above3Key] = $course['studentsAbove3'][$soKey][$gpiCode];
            } else {
                $row[$columnKey] = null;  // Changed from '' to null
                $row[$countKey] = 0;
                $row[$above3Key] = 0;
            }
        }
    }

    $data[] = $row;
}

// Prepare final response
$Data['data'] = $data;
$Data['studentOutcomes'] = $studentOutcomes;
$Data['requirements'] = $requirements;

header('Content-Type: application/json');
echo json_encode($Data);


//require_once ('../php_include/dbconnection_class.php');
//
//// Get parameters from session
//$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
//$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];
//
//// Handle academic years - convert from array to string if needed
//if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
//    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
//    if (is_array($academicYears)) {
//        $IN_AcademicYears = implode(',', $academicYears);
//    } else {
//        $IN_AcademicYears = $academicYears;
//    }
//} else {
//    $IN_AcademicYears = $IN_AcademicYear;
//}
//
//if (empty($IN_AcademicYears)) {
//    $IN_AcademicYears = $IN_AcademicYear;
//}
//
//// Get requirement filter from GET parameter (optional)
//$requirementFilter = isset($_GET['requirement']) ? $_GET['requirement'] : 'All';
//
//// Initialize database connection
//$DBCONNECTION = new Dbconnection();
//$Data = array();
//
//// Initialize variables
//$studentOutcomes = array();
//$courses = array();
//$requirements = array();
//
//// Query to get all Student Outcomes and their GPIs for the program
//$soQuery = "
//    SELECT DISTINCT
//        AY.AcademicYear,
//        STNTOUTCMS.SO,
//        STNTOUTCMS.Description AS SODescription,
//        GPIS.Description AS PIDescription,
//        GPIS.Idx AS GPIIdx,
//        GPIS.GPI AS GPICode
//    FROM StudentOutcomes AS STNTOUTCMS
//    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
//    LEFT JOIN AcademicYears AS AY ON (STNTOUTCMS.AcademicYear = AY.Idx)
//    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
//    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
//    AND GPIS.TobeRemoved = 0
//    ORDER BY STNTOUTCMS.SO, GPIS.GPI
//";
//$soResults = $DBCONNECTION->sendquery($soQuery);
//
//// Temporary array to track SO descriptions by academic year
//$soDescriptions = array();
//
//if ($soResults) {
//    while ($row = $soResults->fetch_assoc()) {
//        $soKey = $row['SO'];
//        $academicYear = $row['AcademicYear'];
//        $soDescription = $row['SODescription'];
//
//        // Track unique SO descriptions with their academic years
//        if (!isset($soDescriptions[$soKey][$soDescription])) {
//            $soDescriptions[$soKey][$soDescription] = array();
//        }
//        if (!in_array($academicYear, $soDescriptions[$soKey][$soDescription])) {
//            $soDescriptions[$soKey][$soDescription][] = $academicYear;
//        }
//
//        // Initialize student outcome if not exists
//        if (!isset($studentOutcomes[$soKey])) {
//            $studentOutcomes[$soKey] = array(
//                'description' => '',
//                'gpis' => array()
//            );
//        }
//
//        // Add GPI (avoid duplicates)
//        $gpiExists = false;
//        foreach ($studentOutcomes[$soKey]['gpis'] as $existingGpi) {
//            if ($existingGpi['gpiIdx'] == $row['GPIIdx']) {
//                $gpiExists = true;
//                break;
//            }
//        }
//
//        if (!$gpiExists) {
//            $studentOutcomes[$soKey]['gpis'][] = array(
//                'gpiIdx' => $row['GPIIdx'],
//                'code' => $row['GPICode'],
//                'description' => $row['PIDescription'],
//            );
//        }
//    }
//
//    // Build combined descriptions with version history
//    foreach ($soDescriptions as $soKey => $descriptions) {
//        if (count($descriptions) == 1) {
//            $studentOutcomes[$soKey]['description'] = array_keys($descriptions)[0];
//        } else {
//            // Show latest description with expandable history
//            $sortedDescriptions = array();
//            foreach ($descriptions as $description => $years) {
//                rsort($years);
//                $sortedDescriptions[$years[0]] = array(
//                    'description' => $description,
//                    'years' => $years
//                );
//            }
//            krsort($sortedDescriptions);
//
//            $latest = reset($sortedDescriptions);
//            $latestYears = implode(', ', $latest['years']);
//
//            $historyHtml = '<div style="margin-top: 8px; padding: 8px; background: #f5f5f5; border-left: 3px solid #ccc; font-size: 0.9em;">';
//            $historyHtml .= '<strong>Previous versions:</strong><br>';
//            $isFirst = true;
//            foreach ($sortedDescriptions as $item) {
//                if ($isFirst) {
//                    $isFirst = false;
//                    continue; // Skip latest
//                }
//                $years = implode(', ', $item['years']);
//                $historyHtml .= '<br><em>' . $years . ':</em> ' . $item['description'];
//            }
//            $historyHtml .= '</div>';
//
//            $studentOutcomes[$soKey]['description'] =
//                '<span style="color: #0066cc;">' . $latestYears . ':</span> ' .
//                $latest['description'] .
//                (count($sortedDescriptions) > 1 ? $historyHtml : '');
//        }
//    }
//
//    // Build combined PI descriptions with academic years
//    foreach ($studentOutcomes as $soKey => &$soData) {
//        foreach ($soData['gpis'] as &$gpi) {
//            if (isset($_GET['gpiKey'])) {
//                $gpiKey = $gpi['gpiKey'];
//
//                if (isset($piDescriptions[$gpiKey])) {
//                    $descriptions = $piDescriptions[$gpiKey];
//
//                    if (count($descriptions) == 1) {
//                        // Only one description - just show it
//                        $gpi['description'] = array_keys($descriptions)[0];
//                    } else {
//                        // Multiple descriptions - show with years
//                        $combinedDescription = array();
//                        foreach ($descriptions as $description => $years) {
//                            sort($years);
//                            $yearLabel = '<strong>[' . implode(', ', $years) . ']</strong> ';
//                            $combinedDescription[] = $yearLabel . $description;
//                        }
//                        $gpi['description'] = implode('<br>', $combinedDescription);
//                    }
//                }
//            }
//        }
//    }
//    unset($soData);
//    unset($gpi);
//}
//
////print_r($studentOutcomes);
//
//
//// Query to get distinct requirements first
//$requirementQuery = "
//    SELECT DISTINCT ABETCRSES.Requirement
//    FROM StudentOutcomes AS STNTOUTCMS
//    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
//    LEFT JOIN AssessmentMeasures AS ASSMNTMEASURES ON (ASSMNTMEASURES.GPI = GPIS.Idx)
//    LEFT JOIN Scoresheet AS SCSHEET ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
//    LEFT JOIN AbetCourses AS ABETCRSES ON (SCSHEET.AbetCourseIdx = ABETCRSES.Idx)
//    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
//    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
//    AND GPIS.TobeRemoved = 0
//    AND ABETCRSES.Requirement IS NOT NULL
//    AND ABETCRSES.Requirement != ''
//    ORDER BY ABETCRSES.Requirement
//";
//
//$requirementResults = $DBCONNECTION->sendquery($requirementQuery);
//if ($requirementResults) {
//    while ($row = $requirementResults->fetch_assoc()) {
//        if (!empty($row['Requirement'])) {
//            $requirements[] = $row['Requirement'];
//        }
//    }
//}
//
//// Build the WHERE clause for requirement filter
//$requirementWhereClause = "";
//if ($requirementFilter !== 'All') {
//    $requirementFilter = $DBCONNECTION->real_escape_string($requirementFilter);
//    $requirementWhereClause = "AND ABETCRSES.Requirement = '{$requirementFilter}'";
//}
//
//// NEW APPROACH: Get raw scores first, then consolidate by GPI code
//$dataQuery = "
//    SELECT
//        AVCRSES.CourseNo,
//        AVCRSES.Title,
//        ABETCRSES.Requirement,
//        STNTOUTCMS.SO,
//        GPIS.GPI AS GPICode,
//        SCSHEET.LevelOfAttainment
//    FROM StudentOutcomes AS STNTOUTCMS
//    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
//    LEFT JOIN AssessmentMeasures AS ASSMNTMEASURES ON (ASSMNTMEASURES.GPI = GPIS.Idx)
//    LEFT JOIN Scoresheet AS SCSHEET ON (ASSMNTMEASURES.Idx = SCSHEET.AssessmentMeasureIdx)
//    LEFT JOIN AVCourses AS AVCRSES ON (SCSHEET.AvailableCourseIdx = AVCRSES.Idx)
//    LEFT JOIN AbetCourses AS ABETCRSES ON (SCSHEET.AbetCourseIdx = ABETCRSES.Idx)
//    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
//    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
//    AND GPIS.TobeRemoved = 0
//    AND AVCRSES.CourseNo IS NOT NULL
//    AND SCSHEET.LevelOfAttainment IS NOT NULL
//    {$requirementWhereClause}
//    ORDER BY AVCRSES.CourseNo, STNTOUTCMS.SO, GPIS.GPI
//";
//
//$dataResults = $DBCONNECTION->sendquery($dataQuery);
//
//// Temporary storage for raw scores
//$rawScores = array();
//
//if ($dataResults) {
//    while ($row = $dataResults->fetch_assoc()) {
//        $courseKey = $row['CourseNo'];
//
//        if (!isset($rawScores[$courseKey])) {
//            $rawScores[$courseKey] = array(
//                'courseNo' => $row['CourseNo'],
//                'title' => $row['Title'],
//                'requirement' => $row['Requirement'],
//                'scores' => array()
//            );
//        }
//
//        $soKey = $row['SO'];
//        $gpiCode = $row['GPICode'];
//
//        if (!isset($rawScores[$courseKey]['scores'][$soKey])) {
//            $rawScores[$courseKey]['scores'][$soKey] = array();
//        }
//
//        if (!isset($rawScores[$courseKey]['scores'][$soKey][$gpiCode])) {
//            $rawScores[$courseKey]['scores'][$soKey][$gpiCode] = array();
//        }
//
//        // Store individual scores (this consolidates across all GPIs with same code)
//        $rawScores[$courseKey]['scores'][$soKey][$gpiCode][] = floatval($row['LevelOfAttainment']);
//    }
//}
//
//// Now calculate averages and counts by GPI code
//foreach ($rawScores as $courseKey => $courseData) {
//    $courses[$courseKey] = array(
//        'courseNo' => $courseData['courseNo'],
//        'title' => $courseData['title'],
//        'requirement' => $courseData['requirement'],
//        'scores' => array(),
//        'studentCounts' => array(),
//        'studentsAbove3' => array()
//    );
//
//    foreach ($courseData['scores'] as $soKey => $gpiData) {
//        $courses[$courseKey]['scores'][$soKey] = array();
//        $courses[$courseKey]['studentCounts'][$soKey] = array();
//        $courses[$courseKey]['studentsAbove3'][$soKey] = array();
//
//        foreach ($gpiData as $gpiCode => $scoresArray) {
//            // Calculate average
//            $avg = array_sum($scoresArray) / count($scoresArray);
//
//            // Count students
//            $totalStudents = count($scoresArray);
//
//            // Count students above 3.0
//            $studentsAbove3 = 0;
//            foreach ($scoresArray as $score) {
//                if ($score >= 3.0) {
//                    $studentsAbove3++;
//                }
//            }
//
//            $courses[$courseKey]['scores'][$soKey][$gpiCode] = round($avg, 1);
//            $courses[$courseKey]['studentCounts'][$soKey][$gpiCode] = $totalStudents;
//            $courses[$courseKey]['studentsAbove3'][$soKey][$gpiCode] = $studentsAbove3;
//        }
//    }
//}
//
//// Build the response data
//$data = array();
//foreach ($courses as $course) {
//    $row = array(
//        'requirement' => $course['requirement'],
//        'courseNo' => $course['courseNo'],
//        'title' => $course['title']
//    );
//
//    foreach ($studentOutcomes as $soKey => $soData) {
//        foreach ($soData['gpis'] as $gpiInfo) {
//            $gpiCode = $gpiInfo['code'];
//            $columnKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'];
//            $countKey = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_count';
//            $above3Key = 'SO' . $soKey . '_GPI' . $gpiInfo['gpiIdx'] . '_above3';
//
//            // Use the consolidated data by GPI code
//            $row[$columnKey] = $course['scores'][$soKey][$gpiCode] ?? '';
//            $row[$countKey] = $course['studentCounts'][$soKey][$gpiCode] ?? 0;
//            $row[$above3Key] = $course['studentsAbove3'][$soKey][$gpiCode] ?? 0;
//        }
//    }
//
//    $data[] = $row;
//}
//
//// Prepare final response
//$Data['data'] = $data;
//$Data['studentOutcomes'] = $studentOutcomes;
//$Data['requirements'] = $requirements;
//
//header('Content-Type: application/json');
//echo json_encode($Data);
