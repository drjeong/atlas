<?php
/**
 * Create PDF file
 * Description: It requires latex to be installed on the server.
 *      Check necessary components in LatexTemplate.php under php_include
 * Author: Dong Hyun Jeong
 *
 * 06/30/2021 - initial version created
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';

$AbetCourseIdx='';
$AvailableCourseIdx='';
$AcademicProgramIdx='';
$AcademicYear = '';
$ForceRegenerate = false;

if (isset($_POST['_ABTC']) && isset($_POST['_AVC']) && isset($_POST['_AP']) && isset($_POST['_AY'])) {
    // Sanitize and validate inputs (assuming these should be numeric)
    $AbetCourseIdx = filter_var(trim($_POST['_ABTC']), FILTER_VALIDATE_INT);
    $AvailableCourseIdx = filter_var(trim($_POST['_AVC']), FILTER_VALIDATE_INT);
    $AcademicProgramIdx = filter_var(trim($_POST['_AP']), FILTER_VALIDATE_INT);
    $AcademicYear = trim($_POST['_AY']);
    if (isset($_POST['_FORCE'])) {
        $ForceRegenerate = trim($_POST['_FORCE']) == '1' ? true : false;
    }

    // Verify that required values are valid
    if ($AbetCourseIdx === false || $AvailableCourseIdx === false || $AcademicProgramIdx === false || empty($AcademicYear)) {
        exit('Invalid parameters');
    }
} else {
    exit('Missing required parameters');
}

//print_r($data);
//exit;
require_once 'php_include/mail_attachment.php';
try {
    require_once(__DIR__ . '/../config.php');
    $COURSEASSESSMENTREPORT_PDF_PATH = __DIRECTORY_COURSEASSESSMENTREPORTS__ . "$AcademicYear". DIRECTORY_SEPARATOR ;

    require_once('fetch_courseassessments_data.php');
    $data = fetchCourseAssessmentData($AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, $AcademicYear);

    // previously created course binder can be downloadable.
    if ($ForceRegenerate === false) {
        $pdf_f = $COURSEASSESSMENTREPORT_PDF_PATH . $data['pdf_filename'];
//        error_log($pdf_f);

        if (file_exists($pdf_f)) {
            if (ob_get_level()) {
                ob_end_clean();
            }

            header('Content-Type: application/pdf');
            header('Content-Length: ' . filesize($pdf_f));
            header('Content-Disposition: attachment; filename="' . $data['pdf_filename'] . '"');
            header('Cache-Control: private, must-revalidate');

            $handle = fopen($pdf_f, 'rb');
            fpassthru($handle);
            fclose($handle);
            exit;
        }
    }

    // Check if we got data or an error code
    if (is_array($data)) {
        require_once(__DIR__ . '/php_include/LatexTemplate.php');
        LatexTemplate::createToCPDF(
            $data, 'create_assessment_pdf.tex',
            $data['pdf_filename'], 1/*0:screen / 1:download*/,
            $COURSEASSESSMENTREPORT_PDF_PATH);

    } else {
        echo $data; // return error code
    }

} catch(Exception $e) {
    NotifyAdminByEmail('Error: Create PDF', $e -> getMessage());
    error_log($e -> getMessage());

    echo ('0x23894723');    // Error
    exit;
}



