<?php
/**
 * Listing courses
 * File: dept_abetcourses_shared_diffsubj_crslist_ssps.php
 * Description: listing courses in a dialog window - shows courses in AbetCourses
 *
 * 03/26/2026 - initial version created.
 * 08/09/2026 - Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */

require_once 'json_response_handler.php';

$AcademicYear = '';
$AcademicYear_From = '';
$AcademicYear_To = '';

// Check both POST and GET for _AY parameter
if (array_key_exists('_AY', $_POST)) {
    $AcademicYear = trim($_POST['_AY']);
} elseif (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
}

if ($AcademicYear == "" || $AcademicYear == "all") {
    echo json_encode(['error' => 'Invalid academic year']);
    exit;
}

// fetching academic year range
require_once(__DIR__ . '/../php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();
$Query = "SELECT `From`, `To` FROM `AcademicYears` WHERE `Idx`=?;";
$result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AcademicYear]);
if ($result && $DBCONNECTION->num_rows() > 0) {
    $row = $DBCONNECTION->fetch_assoc();
    $AcademicYear_From = $row['From'];
    $AcademicYear_To = $row['To'];
} else {
    echo json_encode(['error' => 'Academic year not found']);
    exit;
}
unset($DBCONNECTION);

if (!isset($AcademicYear) || !isset($AcademicYear_From) || !isset($AcademicYear_To)) {
    echo json_encode(['error' => 'Missing required parameters']);
    exit;
}

$AcademicYear = intval($AcademicYear);
$AcademicYear_From = intval($AcademicYear_From);
$AcademicYear_To = intval($AcademicYear_To);

// DB table to use
$table = '';
$joinQuery = " FROM (
    SELECT 
        A.`Idx`, A.`AVCIdx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`AcademicProgramName`, A.`Requirement`, A.`Semester`, A.`CRN`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`Degree`, A.`Reference`, A.`Linked`,
        GROUP_CONCAT(DISTINCT A.`Instructor` ORDER BY A.`Instructor` SEPARATOR ', ') as `Instructor`,
        NULLIF(GROUP_CONCAT(DISTINCT B.`SO` ORDER BY B.`SO` SEPARATOR ', '), '') as `StudentOutcomes`,
        NULLIF(GROUP_CONCAT(DISTINCT B.`SOIdx` ORDER BY B.`SO` SEPARATOR ', '), '') as `SOIdxes`,
        NULLIF(GROUP_CONCAT(DISTINCT B.`PIIdx` ORDER BY B.`SO`, B.`PI` SEPARATOR ', '), '') as `PIIdxes`,
        NULLIF(GROUP_CONCAT(DISTINCT CONCAT_WS('-',B.`SO`, B.`PI`) ORDER BY B.`SO`, B.`PI` SEPARATOR ', '), '') as `PIs`,
        IFNULL(C.`HasClassRoster`, 0) as `HasClassRoster`,
        D.`ProgramCount`
    FROM (
        SELECT `ABETCRSES`.`Idx`, `ABETCRSES`.`AcademicYear`, `ABETCRSES`.`Level`, 
            `AYS`.`AcademicYear` AS `AcademicYearInfo`, 
            `ABETCRSES`.`AcademicProgram`, `ABETCRSES`.`Requirement`, 
            `ABETCRSES`.`Reference`, `ABETCRSES`.`Linked`,
            `SMSTRS`.`Explanation` AS `Semester`,
            `AVCRSES`.`Idx` AS `AVCIdx`, `AVCRSES`.`Semester` AS `AVCSemester`,
            `AVCRSES`.`CRN`, `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Title`, 
            `AVCRSES`.`Credits`, `ACDEMICPRMS`.`Degree`, `ACDEMICPRMS`.`Name` AS `AcademicProgramName`,
            `UA`.`Name` AS `Instructor`
        FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AVCourses` AS `AVCRSES` 
            ON `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`
        LEFT JOIN `Semesters` AS `SMSTRS`
            ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
        INNER JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` 
            ON `AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`
        INNER JOIN `UserAccounts` AS `UA` 
            ON `AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`
        INNER JOIN `AcademicYears` AS `AYS` 
            ON `ABETCRSES`.`AcademicYear` = `AYS`.`Idx`
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` 
            ON `ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`
    ) AS A
    LEFT JOIN (
        SELECT `ABETCRSES`.`Idx` AS `AbetCourseIdx`, `ABETCRSES`.`AcademicYear`, 
            `ABETCRSES`.`AcademicProgram`, `STNTOUTCMS`.`Idx` AS `SOIdx`, 
            `STNTOUTCMS`.`SO`, `GPIS`.`Idx` AS `PIIdx`, `GPIS`.`GPI` AS `PI`
        FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` 
            ON `ABETCRSES`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx`
        LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` 
            ON `ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx` 
            AND `ABETCRSES_GPIS`.`AbetCourseIdx` = `ABETCRSES_SOS`.`AbetCourseIdx`
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` 
            ON `ABETCRSES_SOS`.`SOIdx` = `STNTOUTCMS`.`Idx`
        LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON `GPIS`.`Idx` = `ABETCRSES_GPIS`.`GPIIdx`
        WHERE `GPIS`.`Idx` IS NOT NULL
    ) AS B ON A.`Idx` = B.`AbetCourseIdx` 
        AND A.`AcademicYear` = B.`AcademicYear` 
        AND A.`AcademicProgram` = B.`AcademicProgram`
    LEFT JOIN (
        SELECT `AvailableCourseIdx`, 
            CASE 
                WHEN COUNT(*) > 0 THEN 1 
                ELSE 0 
            END AS `HasClassRoster`
        FROM `ClassRoster`
        GROUP BY `AvailableCourseIdx`
    ) AS C ON A.`AVCIdx` = C.`AvailableCourseIdx`
    LEFT JOIN (
        SELECT 
            `AVCRSES`.`CRN`,
            COUNT(DISTINCT `ABETCRSES`.`AcademicProgram`) AS `ProgramCount`
        FROM `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AVCourses` AS `AVCRSES` 
            ON `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`
        WHERE `AVCRSES`.`Semester` BETWEEN $AcademicYear_From AND $AcademicYear_To
            AND `ABETCRSES`.`Linked` IS NULL
        GROUP BY `AVCRSES`.`CRN`
    ) AS D ON A.`CRN` = D.`CRN`
    WHERE A.`AVCSemester` BETWEEN $AcademicYear_From AND $AcademicYear_To 
        AND A.`Linked` IS NULL
    GROUP BY A.`Idx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Semester`, A.`CRN`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`Degree`, A.`AVCIdx`, A.`Reference`, A.`Linked`, A.`AVCSemester`
    HAVING `StudentOutcomes` IS NOT NULL 
        AND `PIs` IS NOT NULL
        AND D.`ProgramCount` = 1
) AS combined";

// Table's primary key
$primaryKey = 'Idx';

// Array of database columns
$columns = array(
    array('db' => 'Idx', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId',
        'formatter' => function( $d, $row ) {
            return 'row_'.$d;
        }
    ),
    array( 'db' => 'Idx', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => 'AVCIdx', 'dt' => 'AVCIdx', 'field' => 'AVCIdx', 'as' => 'AVCIdx'),
    array( 'db' => 'Idx', 'dt' => 'ABTIdx', 'field' => 'ABTIdx', 'as' => 'ABTIdx'),
    array( 'db' => 'Semester', 'dt' => 'SemesterTxt', 'field' => 'SemesterTxt', 'as' => 'SemesterTxt'),
    array( 'db' => 'CRN', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => 'Subject', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => 'Num', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => 'Title', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => 'Credits', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => 'Instructor', 'dt' => 'Instructor', 'field' => 'Instructor', 'as' => 'Instructor'),
    array( 'db' => 'StudentOutcomes', 'dt' => 'StudentOutcomes', 'field' => 'StudentOutcomes', 'as' => 'StudentOutcomes'),
    array( 'db' => 'PIs', 'dt' => 'PerformanceIndicators', 'field' => 'PerformanceIndicators', 'as' => 'PerformanceIndicators'),
    array( 'db' => 'AcademicProgramName', 'dt' => 'AcademicProgramName', 'field' => 'AcademicProgramName', 'as' => 'AcademicProgramName'),
    array( 'db' => 'Reference', 'dt' => 'ReferenceCrsAssessment', 'field' => 'ReferenceCrsAssessment', 'as' => 'ReferenceCrsAssessment'),
    array(
        'db' => 'Reference',
        'dt' => 'LinkedGroupId',
        'field' => 'LinkedGroupId',
        'as' => 'LinkedGroupId',
        'formatter' => function( $d, $row ) {
            return ($d === null || $d == 0) ? $row['Idx'] : $d;
        }
    ),
    array(
        'db' => 'Reference',
        'dt' => 'IsReference',
        'field' => 'IsReference',
        'as' => 'IsReference',
        'formatter' => function( $d, $row ) {
            return ($d === null || $d == 0) ? 0 : 1;
        }
    )
);

require( 'ssp.join.class.php' );

// No extra WHERE needed since filtering is done in HAVING clause
$extraWhere = "";
$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');

try {
    $result = SSP::joinquery(
        $_REQUEST,
        getSqlConnAttributes(),
        $table,
        $primaryKey,
        $columns,
        $joinQuery,
        $extraWhere,
        $groupBy,
        false
    );

    echo json_encode($result, JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    error_log('DataTables Error: ' . $e->getMessage());
    echo json_encode([
        'draw' => isset($_REQUEST['draw']) ? intval($_REQUEST['draw']) : 0,
        'recordsTotal' => 0,
        'recordsFiltered' => 0,
        'data' => [],
        'error' => 'Database error occurred'
    ]);
}

