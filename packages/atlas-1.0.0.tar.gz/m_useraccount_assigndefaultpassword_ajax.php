<?php
/**
 * Management of User Accounts
 * Description: assign randomly generated temporary password to the selected user
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 */


include('checker_systemadmin.php');


$_UList=$_POST['_UList'];

if ($_UList==''){
	echo "0x00000011"; 
	exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    /////////////////////////////////////////////////////////////////////////////////
    // Update user account

    $Multi_Query = '';
    $users_array = explode( '|', $_UList );
    $users_array = array_unique($users_array); // remove duplicates
    foreach ($users_array as $useridx) {
        $Query = "SELECT `Name` FROM `UserAccounts` WHERE `Idx`= $useridx;";
        $DBCONNECTION->sendquery($Query);
        if($row  = $DBCONNECTION->fetch_assoc()) {
            $Name = $row["Name"];
            $PWD_Encrypted = hash('sha256', $Name);  // generating hash key to be compared with the stored hash code in database

            $Multi_Query .= "UPDATE `UserAccounts` SET `PWD`='$PWD_Encrypted', `ResetPWD` = 1, `LoginFails` = 0 WHERE `Idx`= $useridx;";
        }
    }
    //echo ($Multi_Query);
    $DBCONNECTION->sendmultiquery($Multi_Query);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

