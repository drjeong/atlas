<?php
session_start();

// Security check - only system admins can access
if (!isset($_SESSION['ATLAS_LOGIN_SYSADMIN']) || $_SESSION['ATLAS_LOGIN_SYSADMIN'] !== true) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit;
}

$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    $query = "SELECT 
                Idx,
                Name,
                Email,
                CASE 
                    WHEN Observer = 1 THEN 'Observer'
                    ELSE 'User'
                END AS UserType
              FROM UserAccounts 
              WHERE Disabled = 0 
              AND SystemAdmin = 0"; // Exclude other admins from preview

    if (!empty($searchTerm)) {
        $query .= " AND (Name LIKE ? OR Email LIKE ?)";
        $searchParam = '%' . $searchTerm . '%';
        $params = [$searchParam, $searchParam]; // Fixed: Only 2 parameters for 2 placeholders
    } else {
        $params = [];
    }

    $query .= " ORDER BY Name ASC LIMIT 100";

    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    $users = [];
    if ($result && $DBCONNECTION->num_rows() > 0) {
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $users[] = $row;
        }
    }

    echo json_encode(['success' => true, 'users' => $users]);
    exit;

} catch (Exception $e) {
    error_log('Get Users List Error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Database error']);
    exit;
}