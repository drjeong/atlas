<?php
include_once 'session_handler.php';

$avcIdx = isset($_POST['avcIdx']) ? intval($_POST['avcIdx']) : 0;

if ($avcIdx <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid course ID'
    ]);
    exit;
}

try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Join with UserAccounts to get instructor details
    $query = "SELECT 
                aci.`Idx`, 
                aci.`AVCourseIdx`, 
                aci.`Instructor` as UserIdx,
                ua.`Name` as InstructorName,
                ua.`Email` as InstructorEmail
              FROM `AVCoursesInstructors` aci
              LEFT JOIN `UserAccounts` ua ON aci.`Instructor` = ua.`Idx`
              WHERE aci.`AVCourseIdx` = ? 
              ORDER BY ua.`Name` ASC";

    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$avcIdx]);

    // Get the primary instructor email from AVCourses
    $primaryEmailQuery = "SELECT `InstructorEmail` FROM `AVCourses` WHERE `Idx` = ?";
    $primaryResult = $DBCONNECTION->prepare_execute_catch_error($primaryEmailQuery, [$avcIdx]);
    $primaryRow = $primaryResult->fetch_assoc();
    $primaryEmail = $primaryRow ? $primaryRow['InstructorEmail'] : '';

    $instructors = [];
    while ($row = $result->fetch_assoc()) {
        $instructors[] = [
            'Idx' => $row['Idx'],
            'AVCourseIdx' => $row['AVCourseIdx'],
            'UserIdx' => $row['UserIdx'],
            'InstructorName' => $row['InstructorName'],
            'InstructorEmail' => $row['InstructorEmail'],
            'IsPrimary' => ($row['InstructorEmail'] == $primaryEmail) ? 1 : 0
        ];
    }

    echo json_encode([
        'success' => true,
        'instructors' => $instructors
    ]);

} catch (mysqli_sql_exception $e) {
    error_log("Error fetching instructors: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred'
    ]);
} catch (Exception $e) {
    error_log("Error fetching instructors: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error occurred'
    ]);
}
?>