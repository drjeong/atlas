<?php
/**
 * Class for handling latex templating
 * Description: Handle latex templating. After formatting latex file, run a latex compiler to generate a PDF.
 * 			Compilation runs twice to create TOC (table of content) and map it to PDF.
 *
 * Necessary Modules: texlive-xetex (Latex) and ttf-mscorefonts-installer (Font)
 * Installation Procedures (Ubuntu):
 * 			- sudo apt-get install texlive-xetex
 * 			- sudo apt-get --reinstall install ttf-mscorefonts-installer
 *
 * Author: Dong Hyun Jeong
 *
 * 04/20/2023 - initial version created
 * 03/15/2024 - fixed error while processing PDF due to special symbols
 * 05/23/2024 - removed temporary TOC file
 * 04/02/2026 - revised text and html conversion to latex format
 */

class LatexTemplate {

    /**
     * Creates a PDF document with Table of Contents from a LaTeX template
     *
     * @param array  $data             Data to be used in LaTeX generation
     * @param string $template_tex_file Path to LaTeX template file
     * @param string $outp_file        Desired output filename
     * @param int    $display          Display mode: 0 for inline display, 1 for download, 2 for email attachment, 3 for save only (batch)
     * @param string $temp_save_path   Path to save the PDF file (optional)
     * @throws Exception If PDF creation fails
     * @return bool|void Returns true for mode 3, void for other modes
     */
    public static function createToCPDF($data, $template_tex_file, $outp_file, $display = 0, $temp_save_path = null) {
        // Validate template file
        if (!file_exists($template_tex_file)) {
            throw new Exception('LaTeX template file not found: ' . $template_tex_file);
        }

        // Create temporary base file
        $tempBase = tempnam(sys_get_temp_dir(), 'tex-');
        if ($tempBase === false) {
            throw new Exception('Failed to create temporary file');
        }

        // Define temporary files
        $tex_f = $tempBase . '.tex';
        $aux_f = $tempBase . '.aux';
        $log_f = $tempBase . '.log';
        $toc_f = $tempBase . '.toc';
        $pdf_f = $tempBase . '.pdf';
        $clean_pdf_f = $tempBase . '_clean.pdf';

        try {
            // Generate LaTeX content from template
            extract($data);
            ob_start();
            include($template_tex_file);
            $tex_content = ob_get_clean();

            if (file_put_contents($tex_f, $tex_content) === false) {
                throw new Exception('Failed to write to temporary tex file');
            }

            // Compile PDF using xelatex
            $cmd = sprintf("xelatex -interaction nonstopmode -halt-on-error %s",
                escapeshellarg($tex_f));

            chdir(sys_get_temp_dir());

            // First pass for initial compilation
            exec($cmd, $output, $returnCode1);

            // Second pass to generate Table of Contents
            exec($cmd, $output, $returnCode2);

            // Check TOC generation
            if (file_exists($toc_f) && filesize($toc_f) == 0) {
                $log_msg = file_exists($log_f) ? file_get_contents($log_f) : 'No log file available';
                NotifyAdminByEmail('Error: Create TOC for PDF', 'Unable to create TOC.' . $log_msg, $tex_f);
            }

            // Check if PDF was created successfully
            if (!file_exists($pdf_f)) {
                $log_msg = file_exists($log_f) ? file_get_contents($log_f) : 'No log file available';
                $tex_msg = file_exists($tex_f) ? file_get_contents($tex_f) : 'No tex file available';

                NotifyAdminByEmail('Error: Create PDF', 'Unable to create PDF.', $tex_f);

                throw new Exception(
                    "PDF generation failed (Return codes: $returnCode1, $returnCode2)\n\n" .
                    "==== TEX CONTENT ====\n" . $tex_msg . "\n\n" .
                    "==== LOG CONTENT ====\n" . $log_msg
                );
            }

            // The following is not used since it takes time to process it.
            // POST-PROCESS WITH GHOSTSCRIPT to create a clean PDF
//            $gs_cmd = sprintf(
//                "gs -q -dNOPAUSE -dBATCH -dSAFER " .
//                "-sDEVICE=pdfwrite -dCompatibilityLevel=1.7 " .
//                "-dPDFSETTINGS=/prepress " .
//                "-dEmbedAllFonts=true " .
//                "-dSubsetFonts=true " .
//                "-dAutoRotatePages=/None " .
//                "-dColorImageDownsampleType=/Bicubic " .
//                "-dColorImageResolution=300 " .
//                "-dGrayImageDownsampleType=/Bicubic " .
//                "-dGrayImageResolution=300 " .
//                "-dMonoImageDownsampleType=/Bicubic " .
//                "-dMonoImageResolution=300 " .
//                "-dDownsampleColorImages=false " .
//                "-dDownsampleGrayImages=false " .
//                "-dDownsampleMonoImages=false " .
//                "-dCompressFonts=false " .
//                "-dPreserveHalftoneInfo=true " .
//                "-dPreserveOPIComments=true " .
//                "-dPreserveOverprintSettings=true " .
//                "-dUCRandBGInfo=/Preserve " .
//                "-sOutputFile=%s %s 2>&1",
//                escapeshellarg($clean_pdf_f),
//                escapeshellarg($pdf_f)
//            );
//
//            exec($gs_cmd, $gs_output, $gs_return);

            // Use cleaned PDF if Ghostscript succeeded, otherwise use original
            $final_pdf = (file_exists($clean_pdf_f) && filesize($clean_pdf_f) > 0)
                ? $clean_pdf_f
                : $pdf_f;

            // Determine the file to output
            $output_file = $final_pdf;

            // Save to permanent location if specified
            if ($temp_save_path !== null) {
                // Ensure destination directory exists
                if (!is_dir($temp_save_path)) {
                    throw new Exception('Destination directory does not exist: ' . $temp_save_path);
                }

                $destination = $temp_save_path . $outp_file;

                // Delete existing file to ensure fresh copy
                if (file_exists($destination)) {
                    clearstatcache(true, $destination);
                    if (!unlink($destination)) {
                        throw new Exception('Failed to delete existing PDF: ' . $destination);
                    }
                }

                // Copy the cleaned PDF to destination
                if (!copy($final_pdf, $destination)) {
                    $error = error_get_last();
                    throw new Exception('Failed to copy PDF to destination: ' . ($error['message'] ?? 'Unknown error'));
                }

                // Clear stat cache for the new file
                clearstatcache(true, $destination);

                // For modes that output to browser, use the destination file
                // This ensures the saved file is exactly what gets downloaded
                if ($display !== 2) {
                    $output_file = $destination;
                }
            }

            // Handle output based on display mode
            if ($display == 3) {
                // Mode 3: Save only for batch processing (no output to browser)
                return true;
            } elseif ($display == 2) {
                // Mode 2: Email attachment (plain text header)
                header('Content-Type: text/plain');
            } else {
                // Mode 0 or 1: Output PDF to browser
                if (!file_exists($output_file)) {
                    throw new Exception('Output PDF file not found: ' . $output_file);
                }

                // Clear any output buffers
                if (ob_get_level()) {
                    ob_end_clean();
                }

                header('Content-Type: application/pdf');
                header('Content-Length: ' . filesize($output_file));
                header('Cache-Control: public, must-revalidate, max-age=0');
                header('Pragma: public');
                header('Expires: 0');
                header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');

                if ($display === 0) {
                    header('Content-Disposition: inline; filename="' . basename($outp_file) . '"');
                } else {
                    header('Content-Disposition: attachment; filename="' . basename($outp_file) . '"');
                }

                $handle = fopen($output_file, 'rb');
                fpassthru($handle);
                fclose($handle);
            }

        } finally {
            // Cleanup temporary files only (not the saved destination file)
            $tempFiles = [$tex_f, $aux_f, $log_f, $toc_f, $pdf_f, $clean_pdf_f, $tempBase];
            foreach ($tempFiles as $file) {
                if (file_exists($file)) {
                    @unlink($file);
                }
            }
        }
    }

	/**
	 * Creates a PDF document from a LaTeX template
	 *
	 * @param array  $data             Data to be used in LaTeX generation
	 * @param string $template_tex_file Path to LaTeX template file
	 * @param string $outp_file        Desired output filename
	 * @param int    $display          Display mode: 0 for inline display, 1 for download
	 * @throws Exception If PDF creation fails
	 * @return void
	 */
    public static function createPDF($data, $template_tex_file, $outp_file, $display = 0) {
        require_once __FILE_CONFIG__;
        $template_tex_file = __DIRECTORY_WEBHOME__ . '/' . $template_tex_file;

        // Validate template file
        if (!file_exists($template_tex_file)) {
            throw new Exception('LaTeX template file not found: ' . $template_tex_file);
        }

        // Create temporary base file
        $tempBase = tempnam(sys_get_temp_dir(), 'tex-');
        if ($tempBase === false) {
            throw new Exception('Failed to create temporary file');
        }

        // Define temporary files
        $tex_f = $tempBase . '.tex';
        $aux_f = $tempBase . '.aux';
        $log_f = $tempBase . '.log';
        $pdf_f = $tempBase . '.pdf';

        try {
            // Generate LaTeX content from template
            extract($data);
            ob_start();
            include($template_tex_file);
            $tex_content = ob_get_clean();

            if (file_put_contents($tex_f, $tex_content) === false) {
                throw new Exception('Failed to write to temporary tex file');
            }

            // Compile PDF using xelatex
            $cmd = sprintf("xelatex -interaction nonstopmode -halt-on-error %s",
                escapeshellarg($tex_f));

            chdir(sys_get_temp_dir());
            exec($cmd, $output, $returnCode);

            // Check if PDF was created successfully
            if (!file_exists($pdf_f)) {
                $log_msg = file_exists($log_f) ? file_get_contents($log_f) : 'No log file available';
                $tex_msg = file_exists($tex_f) ? file_get_contents($tex_f) : 'No tex file available';

                NotifyAdminByEmail('Error: Create PDF', 'Not able to create PDF.', $tex_f);

                throw new Exception(
                    "PDF generation failed (Return code: $returnCode)\n\n" .
                    "==== TEX CONTENT ====\n" . $tex_msg . "\n\n" .
                    "==== LOG CONTENT ====\n" . $log_msg
                );
            }

            $clean_pdf_f = $tempBase . '_clean.pdf';

            // The following is not used since it takes time to process it.
            // POST-PROCESS WITH GHOSTSCRIPT to create a clean PDF
//            $gs_cmd = sprintf(
//                "gs -q -dNOPAUSE -dBATCH -dSAFER " .
//                "-sDEVICE=pdfwrite -dCompatibilityLevel=1.7 " .
//                "-dPDFSETTINGS=/prepress " .
//                "-dEmbedAllFonts=true " .
//                "-dSubsetFonts=true " .
//                "-dAutoRotatePages=/None " .
//                "-dColorImageDownsampleType=/Bicubic " .
//                "-dColorImageResolution=300 " .
//                "-dGrayImageDownsampleType=/Bicubic " .
//                "-dGrayImageResolution=300 " .
//                "-dMonoImageDownsampleType=/Bicubic " .
//                "-dMonoImageResolution=300 " .
//                "-dDownsampleColorImages=false " .
//                "-dDownsampleGrayImages=false " .
//                "-dDownsampleMonoImages=false " .
//                "-dCompressFonts=false " .
//                "-dPreserveHalftoneInfo=true " .
//                "-dPreserveOPIComments=true " .
//                "-dPreserveOverprintSettings=true " .
//                "-dUCRandBGInfo=/Preserve " .
//                "-sOutputFile=%s %s 2>&1",
//                escapeshellarg($clean_pdf_f),
//                escapeshellarg($pdf_f)
//            );

//            exec($gs_cmd, $gs_output, $gs_return);

            // Use cleaned PDF if Ghostscript succeeded, otherwise use original
            $final_pdf = (file_exists($clean_pdf_f) && filesize($clean_pdf_f) > 0)
                ? $clean_pdf_f
                : $pdf_f;

            // Handle different display modes
            if ($display === 0 || $display === 1) {
                // Clear any previous output
                if (ob_get_level()) {
                    ob_end_clean();
                }

                header('Content-Type: application/pdf');
                header('Content-Length: ' . filesize($final_pdf));
                header('Cache-Control: public, must-revalidate, max-age=0');
                header('Pragma: public');
                header('Expires: 0');
                header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');

                if ($display === 0) {
                    header('Content-Disposition: inline; filename="' . basename($outp_file) . '"');
                } else {
                    header('Content-Disposition: attachment; filename="' . basename($outp_file) . '"');
                }

                // Read and output file
                $handle = fopen($final_pdf, 'rb');
                fpassthru($handle);
                fclose($handle);

            } else if ($display === 2) { // Save to local folder
                if (empty($outp_file)) {
                    throw new Exception('Output filename not specified for local save');
                }

                // Ensure the directory exists
                $dir = dirname($outp_file);
                if (!is_dir($dir)) {
                    if (!mkdir($dir, 0755, true)) {
                        throw new Exception('Failed to create output directory: ' . $dir);
                    }
                }

                // Copy the cleaned file to destination
                if (!copy($final_pdf, $outp_file)) {
                    $error = error_get_last();
                    throw new Exception('Failed to save PDF to: ' . $outp_file . ' - ' . ($error['message'] ?? 'Unknown error'));
                }

                // Verify the file was saved
                if (!file_exists($outp_file)) {
                    throw new Exception('PDF file was not saved successfully to: ' . $outp_file);
                }
            }

        } finally {
            // Cleanup all temporary files
            $clean_pdf_f = $tempBase . '_clean.pdf';
            $tempFiles = [$tex_f, $aux_f, $log_f, $pdf_f, $clean_pdf_f, $tempBase];
            foreach ($tempFiles as $file) {
                if (file_exists($file)) {
                    @unlink($file);
                }
            }
        }
    }

    /**
     * Creates a LaTeX document from a template and returns the content
     *
     * @param array  $data             Data to be used in LaTeX generation
     * @param string $template_tex_file Path to LaTeX template file
     * @param string $outp_file        Desired output filename (optional, for display=1 or display=2)
     * @param int    $display          Display mode: 0 for inline display, 1 for download, 2 for save to file
     * @throws Exception If LaTeX creation fails
     * @return string LaTeX content (when display=0 and no output)
     */
    public static function createLatex($data, $template_tex_file, $outp_file = '', $display = 0) {
        require_once __FILE_CONFIG__;
        $template_tex_file = __DIRECTORY_WEBHOME__ . '/' . $template_tex_file;

        // Validate template file
        if (!file_exists($template_tex_file)) {
            throw new Exception('LaTeX template file not found: ' . $template_tex_file);
        }

        try {
            // Generate LaTeX content from template
            ob_start();
            include($template_tex_file);
            $latex_content = ob_get_clean();

            // Handle different display modes
            if ($display === 0) {
                // Return content for inline use
                header('Content-Type: text/plain; charset=utf-8');
                header('Content-Length: ' . strlen($latex_content));
                echo $latex_content;
                return $latex_content;

            } else if ($display === 1) {
                // Download as .tex file
                if (empty($outp_file)) {
                    $outp_file = 'document.tex';
                }
                header('Content-Type: text/x-tex; charset=utf-8');
                header('Content-Length: ' . strlen($latex_content));
                header('Content-Disposition: attachment; filename="' . $outp_file . '"');
                echo $latex_content;
                return $latex_content;

            } else if ($display === 2) {
                // Save to local file
                if (empty($outp_file)) {
                    throw new Exception('Output filename not specified for local save');
                }

                // Ensure the directory exists
                $dir = dirname($outp_file);
                if (!is_dir($dir)) {
                    if (!mkdir($dir, 0755, true)) {
                        throw new Exception('Failed to create output directory');
                    }
                }

                // Write content to file
                if (file_put_contents($outp_file, $latex_content) === false) {
                    throw new Exception('Failed to save LaTeX to: ' . $outp_file);
                }

                return $latex_content;
            }

            return $latex_content;

        } catch (Exception $e) {
            NotifyAdminByEmail('Error: Create LaTeX', 'Not able to create LaTeX file.', $template_tex_file);
            throw $e;
        }
    }

	/**
	 * Series of substitutions to sanitise text for use in LaTeX.
	 *
	 */
    public static function replaceSpecialCharacters($text) {
        $text = self::latexToPlainText(html_entity_decode($text));

        $text = str_replace("||", " || ", $text);

        // handle new lines
        $text = str_replace('\\r\\n', ' \\\\ ', $text);
        $text = str_replace(["\r\n", "\r", "\n"], ' \\\\ ', $text);

        // First temporarily mark groups of four backslashes
        $text = str_replace('\\\\', '__FOURSLASHES__', $text);
        // Then replace remaining single backslashes
        $text = str_replace('\\', '\\textbackslash{}', $text);
        // Finally restore the four backslashes
        $text = str_replace('__FOURSLASHES__', '\\\\', $text);

        // Remove non-printable characters
        $text = preg_replace('/[\x00-\x1F\x7F-\xFF]/', '', $text);

        // LaTeX special characters
//        $text = str_replace("$", "\\$", $text);
//        $text = str_replace("#", "\\#", $text);
//        $text = str_replace("%", "\\%", $text);

        return trim($text);
    }

    public static function latexToPlainText($text) {
        // Replace LaTeX quote commands with regular quotes
        $text = str_replace("\\textquotesingle{}", "'", $text);
        $text = str_replace("\\textquotedbl{}", '"', $text);
        $text = str_replace("\\textasciigrave{}", "`", $text);

        // Replace LaTeX special characters
        $text = str_replace("\\textasciicircum{}", "^", $text);
        $text = str_replace("\\textasciitilde{}", "~", $text);
        $text = str_replace("\\textless{}", "<", $text);
        $text = str_replace("\\textgreater{}", ">", $text);
        $text = str_replace("\\textbackslash{}", "\\", $text);

        // Unescape LaTeX special characters
        $text = str_replace("\\{", "{", $text);
        $text = str_replace("\\}", "}", $text);
        $text = str_replace("\\$", "$", $text);
        $text = str_replace("\\&", "&", $text);
        $text = str_replace("\\#", "#", $text);
        $text = str_replace("\\_", "_", $text);
        $text = str_replace("\\%", "%", $text);

        // Handle line breaks
        $text = str_replace('\\\\', "\n", $text);

        return $text;
    }

    public static function processTextWithUrls($text) {
        // Step 1: PROTECT URLs with placeholders that won't be modified
        $urls = [];
        $urlPattern = '/\b(?:https?|ftp):\/\/[^\s\)\]\},]+/i';

        $text = preg_replace_callback($urlPattern, function($matches) use (&$urls) {
            $placeholder = 'XXXXXXXXXURLPROTECTXXXXXXXXXXX' . count($urls) . 'XXXXXXXXXURLPROTECTXXXXXXXXXXX';
            $urls[$placeholder] = $matches[0];
            return $placeholder;
        }, $text);

        // Step 2: Process text (URLs are protected with X's - safe from escaping)
        $text = self::replaceSpecialCharacters($text);
        $text = self::plainTextToLatex($text);

        // Step 3: RESTORE URLs
        foreach ($urls as $placeholder => $url) {
            $text = str_replace($placeholder, $url, $text);
        }

        // Step 4: Convert URLs to \url{...}
        $text = self::convertTextToLatexUrl($text);

        return $text;
    }

    public static function convertTextToLatexUrl($text) {
        // Define a pattern to detect URLs (http/https/ftp or www.)
        $url_pattern = '/\b(?:(?:https?|ftp):\/\/|www\.)[^\s]+/i';

        // Replace URLs with \url{} format
        $text_with_urls = preg_replace_callback($url_pattern, function($matches) {
            $url = $matches[0];

            // If URL starts with www. but no protocol, add http://
            if (stripos($url, 'www.') === 0) {
                $url = 'http://' . $url;
            }

            return '\url{' . $url . '}';
        }, $text);

        return $text_with_urls;
    }

    public static function plainTextToLatex($text) {
        // Step 1: Decode HTML entities first
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Step 2: Convert both literal \r\n strings AND actual newlines to \n
        $text = str_replace(['\\r\\n', '\\n', '\\r'], "\n", $text);
        $text = str_replace(["\r\n", "\r"], "\n", $text);

        // Step 3: Protect existing LaTeX math expressions
        $mathExpressions = [];
        $mathCounter = 0;

        $text = preg_replace_callback(
            '/(\\\\\(.*?\\\\\)|\$\$[^\n]*?\$\$|\$[^\$\n]+?\$)/s',
            function($matches) use (&$mathExpressions, &$mathCounter) {
                $placeholder = "XMATHPLACEHOLDERX{$mathCounter}XMATHPLACEHOLDERX";
                $mathExpressions[$placeholder] = $matches[0];
                $mathCounter++;
                return $placeholder;
            },
            $text
        );

        $text = preg_replace_callback(
            '/(\\\\\[.*?\\\\\]|\$\$\n.*?\n\$\$)/s',
            function($matches) use (&$mathExpressions, &$mathCounter) {
                $placeholder = "XMATHPLACEHOLDERX{$mathCounter}XMATHPLACEHOLDERX";
                $mathExpressions[$placeholder] = $matches[0];
                $mathCounter++;
                return $placeholder;
            },
            $text
        );

        // Step 4: Escape LaTeX special characters in plain text
        $escapeMap = [
            '&'  => '\\&',
            '%'  => '\\%',
            '$'  => '\\$',
            '#'  => '\\#',
            '_'  => '\\_',
            '{'  => '\\{',
            '}'  => '\\}',
            '~'  => '\\textasciitilde{}',
            '^'  => '\\textasciicircum{}',
        ];

        foreach ($escapeMap as $char => $escaped) {
            $text = str_replace($char, $escaped, $text);
        }

        // Step 5: Restore math expressions
        foreach ($mathExpressions as $placeholder => $mathExpr) {
            $text = str_replace($placeholder, $mathExpr, $text);
        }

        // Step 6: Handle newlines
        $text = preg_replace('/\n+/', " \\\\\n\n", $text);

        return trim($text);
    }

    /**
     * Converts HTML content to LaTeX format for inclusion in LaTeX documents
     *
     * @param string $htmlContent HTML content (can be single or double-encoded)
     * @return string The converted LaTeX content
     */
    public static function htmlToLatex($htmlContent, $paragraphSpacing = '1em') {
        $html = $htmlContent;

        // Decode entities (including double encoding)
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5);
        $html = str_replace(
            ['&nbsp;', '&amp;', '&lt;', '&gt;', '&quot;', '&apos;'],
            [' ', '&', '<', '>', '"', "'"],
            $html
        );
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5); // Final pass

        // Protect existing LaTeX math expressions BEFORE any other processing
        $mathExpressions = [];
        $mathCounter = 0;

        $html = preg_replace_callback(
            '/(\\\\\(.*?\\\\\)|\\\\\[.*?\\\\\]|\$\$.*?\$\$|\$[^\$\n]+?\$)/s',
            function($matches) use (&$mathExpressions, &$mathCounter) {
                $placeholder = "XMATHX{$mathCounter}XMATHX";
                $mathExpressions[$placeholder] = $matches[0];
                $mathCounter++;
                return $placeholder;
            },
            $html
        );

        // Convert lists to LaTeX
        $html = preg_replace_callback('/<ul[^>]*>(.*?)<\/ul>/s', function($matches) {
            $content = $matches[1];
            $items = preg_replace('/<li[^>]*>(.*?)<\/li>/s', '||ITEM|| $1', $content);
            return "||BEGIN-ITEMIZE||\n" . $items . "\n||END-ITEMIZE||";
        }, $html);

        $html = preg_replace_callback('/<ol[^>]*>(.*?)<\/ol>/s', function($matches) {
            $content = $matches[1];
            $items = preg_replace('/<li[^>]*>(.*?)<\/li>/s', '||ITEM|| $1', $content);
            return "||BEGIN-ENUMERATE||\n" . $items . "\n||END-ENUMERATE||";
        }, $html);

        // Convert headings
        $html = preg_replace('/<h[1-6][^>]*>(.*?)<\/h[1-6]>/is', "\n\n||TEXTBF-OPEN||$1||CLOSE-BRACE||\n\n", $html);

        // Special handling for formatting tags with newlines
        $html = preg_replace_callback('/<(strong|b)[^>]*>(.*?)<\/(strong|b)>/s', function($matches) {
            $parts = preg_split('/(\n+)/', $matches[2], -1, PREG_SPLIT_DELIM_CAPTURE);
            $result = '';
            for ($i = 0; $i < count($parts); $i++) {
                if ($i % 2 == 0 && trim($parts[$i]) !== '') {
                    $result .= '||TEXTBF-OPEN||' . $parts[$i] . '||CLOSE-BRACE||';
                } else {
                    $result .= $parts[$i];
                }
            }
            return $result;
        }, $html);

        $html = preg_replace_callback('/<(em|i)[^>]*>(.*?)<\/(em|i)>/s', function($matches) {
            $parts = preg_split('/(\n+)/', $matches[2], -1, PREG_SPLIT_DELIM_CAPTURE);
            $result = '';
            for ($i = 0; $i < count($parts); $i++) {
                if ($i % 2 == 0 && trim($parts[$i]) !== '') {
                    $result .= '||TEXTIT-OPEN||' . $parts[$i] . '||CLOSE-BRACE||';
                } else {
                    $result .= $parts[$i];
                }
            }
            return $result;
        }, $html);

        $html = preg_replace_callback('/<u[^>]*>(.*?)<\/u>/s', function($matches) {
            $parts = preg_split('/(\n+)/', $matches[1], -1, PREG_SPLIT_DELIM_CAPTURE);
            $result = '';
            for ($i = 0; $i < count($parts); $i++) {
                if ($i % 2 == 0 && trim($parts[$i]) !== '') {
                    $result .= '||UNDERLINE-OPEN||' . $parts[$i] . '||CLOSE-BRACE||';
                } else {
                    $result .= $parts[$i];
                }
            }
            return $result;
        }, $html);

        // Convert structural HTML to newlines
        $html = preg_replace('/<br\s*\/?>/i', "\n", $html);
        $html = preg_replace('/<\/p>\s*<p[^>]*>/i', "\n\n", $html);
        $html = preg_replace('/<\/?p[^>]*>/i', "\n", $html);

        // Strip all other tags
        $html = strip_tags($html);

        // Final decode (in case something slipped through)
        if (preg_match('/&[a-zA-Z0-9]+;/', $html)) {
            $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5);
        }

        // Escape LaTeX special characters (but NOT backslash from our placeholders)
        $escapeMap = [
            '#'  => '\\#',
            '$'  => '\\$',
            '%'  => '\\%',
            '&'  => '\\&',
            '_'  => '\\_',
            '{'  => '\\{',
            '}'  => '\\}',
            '^'  => '\\textasciicircum{}',
            '~'  => '\\textasciitilde{}',
        ];

        foreach ($escapeMap as $char => $escaped) {
            $html = str_replace($char, $escaped, $html);
        }

        // Restore LaTeX commands from placeholders
        $restorePatterns = [
            '/\|\|BEGIN-ITEMIZE\|\|/',
            '/\|\|END-ITEMIZE\|\|/',
            '/\|\|BEGIN-ENUMERATE\|\|/',
            '/\|\|END-ENUMERATE\|\|/',
            '/\|\|ITEM\|\|/',
            '/\|\|TEXTBF-OPEN\|\|/',
            '/\|\|TEXTIT-OPEN\|\|/',
            '/\|\|UNDERLINE-OPEN\|\|/',
            '/\|\|CLOSE-BRACE\|\|/',
        ];

        $restoreReplacements = [
            '\\begin{itemize}',
            '\\end{itemize}',
            '\\begin{enumerate}',
            '\\end{enumerate}',
            '\\item',
            '\\textbf{',
            '\\textit{',
            '\\underline{',
            '}',
        ];

        $html = preg_replace($restorePatterns, $restoreReplacements, $html);

        // Restore protected math expressions
        foreach ($mathExpressions as $placeholder => $mathExpr) {
            $html = str_replace($placeholder, $mathExpr, $html);
        }

        // Ensure proper line breaks around LaTeX environments
        $html = preg_replace_callback('/\\\\begin\{(itemize|enumerate)\}\s*/', function($m) {
            return "\\begin{{$m[1]}}\n";
        }, $html);

        $html = preg_replace_callback('/\s*\\\\end\{(itemize|enumerate)\}/', function($m) {
            return "\n\\end{{$m[1]}}";
        }, $html);

        // Handle paragraph spacing
        $html = preg_replace("/\n{3,}/", "\n\n\\vspace{{$paragraphSpacing}}\n\n", $html);

        return trim($html);
    }



    /**
     * Converts HTML content to LaTeX format for inclusion in LaTeX documents
     *
     * @param string $htmlContent HTML content (can be single or double-encoded)
     * @return string The converted LaTeX content
     */
    public static function htmlToLatexInsidetcolorbox($htmlContent, $paragraphSpacing = '1em') {
        $html = $htmlContent;

        // Decode entities (including double encoding)
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5);
        $html = str_replace(
            ['&nbsp;', '&amp;', '&lt;', '&gt;', '&quot;', '&apos;'],
            [' ', '&', '<', '>', '"', "'"],
            $html
        );
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5); // Final pass

        // Protect existing LaTeX math expressions BEFORE any other processing
        $mathExpressions = [];
        $mathCounter = 0;

        $html = preg_replace_callback(
            '/(\\\\\(.*?\\\\\)|\\\\\[.*?\\\\\]|\$\$.*?\$\$|\$[^\$\n]+?\$)/s',
            function($matches) use (&$mathExpressions, &$mathCounter) {
                $placeholder = "XMATHX{$mathCounter}XMATHX";
                $mathExpressions[$placeholder] = $matches[0];
                $mathCounter++;
                return $placeholder;
            },
            $html
        );

        // Strip data attributes from all tags
        $html = preg_replace('/\s+data-[a-z\-]+="[^"]*"/i', '', $html);

        // Convert lists to LaTeX
        $html = preg_replace_callback('/<ul[^>]*>(.*?)<\/ul>/s', function($matches) {
            $content = $matches[1];
            $items = preg_replace('/<li[^>]*>(.*?)<\/li>/s', '||ITEM|| $1', $content);
            return "||BEGIN-ITEMIZE||\n" . $items . "\n||END-ITEMIZE||";
        }, $html);

        $html = preg_replace_callback('/<ol[^>]*>(.*?)<\/ol>/s', function($matches) {
            $content = $matches[1];
            $items = preg_replace('/<li[^>]*>(.*?)<\/li>/s', '||ITEM|| $1', $content);
            return "||BEGIN-ENUMERATE||\n" . $items . "\n||END-ENUMERATE||";
        }, $html);

        // Convert headings
        $html = preg_replace('/<h[1-6][^>]*>(.*?)<\/h[1-6]>/is', "\n\n||TEXTBF-OPEN||$1||TEXTBF-CLOSE||\n\n", $html);

        // Convert <br> tags FIRST to prevent them from being inside formatting tags
        $html = preg_replace('/<br\s*\/?>\s*<br\s*\/?>/i', "||DOUBLE-NEWLINE||", $html);
        $html = preg_replace('/<br\s*\/?>/i', "||NEWLINE||", $html);

        // Convert paragraph tags
        $html = preg_replace('/<\/p>\s*<p[^>]*>/i', "||DOUBLE-NEWLINE||", $html);
        $html = preg_replace('/<\/?p[^>]*>/i', "\n", $html);

        // NOW handle formatting tags - they won't span across line breaks anymore
        $html = preg_replace('/<(strong|b)[^>]*>(.*?)<\/(strong|b)>/s', '||TEXTBF-OPEN||$2||TEXTBF-CLOSE||', $html);
        $html = preg_replace('/<(em|i)[^>]*>(.*?)<\/(em|i)>/s', '||TEXTIT-OPEN||$2||TEXTIT-CLOSE||', $html);
        $html = preg_replace('/<u[^>]*>(.*?)<\/u>/s', '||UNDERLINE-OPEN||$1||UNDERLINE-CLOSE||', $html);

        // Strip all other tags
        $html = strip_tags($html);

        // Final decode (in case something slipped through)
        if (preg_match('/&[a-zA-Z0-9]+;/', $html)) {
            $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5);
        }

        // Escape LaTeX special characters (but NOT backslash from our placeholders)
        $escapeMap = [
            '#'  => '\\#',
            '$'  => '\\$',
            '%'  => '\\%',
            '&'  => '\\&',
            '_'  => '\\_',
            '{'  => '\\{',
            '}'  => '\\}',
            '^'  => '\\textasciicircum{}',
            '~'  => '\\textasciitilde{}',
        ];

        foreach ($escapeMap as $char => $escaped) {
            $html = str_replace($char, $escaped, $html);
        }

        // Restore LaTeX commands from placeholders
        $html = str_replace('||BEGIN-ITEMIZE||', '\\begin{itemize}', $html);
        $html = str_replace('||END-ITEMIZE||', '\\end{itemize}', $html);
        $html = str_replace('||BEGIN-ENUMERATE||', '\\begin{enumerate}', $html);
        $html = str_replace('||END-ENUMERATE||', '\\end{enumerate}', $html);
        $html = str_replace('||ITEM||', '\\item ', $html);
        $html = str_replace('||DOUBLE-NEWLINE||', "\\smallbreak\n", $html);
        $html = str_replace('||NEWLINE||', "\\smallbreak\n", $html);
        $html = str_replace('||TEXTBF-OPEN||', '\\begin{bfseries}', $html);
        $html = str_replace('||TEXTBF-CLOSE||', '\\end{bfseries}', $html);
        $html = str_replace('||TEXTIT-OPEN||', '\\textit{', $html);
        $html = str_replace('||TEXTIT-CLOSE||', '}', $html);
        $html = str_replace('||UNDERLINE-OPEN||', '\\underline{', $html);
        $html = str_replace('||UNDERLINE-CLOSE||', '}', $html);

        // Restore protected math expressions
        foreach ($mathExpressions as $placeholder => $mathExpr) {
            $html = str_replace($placeholder, $mathExpr, $html);
        }

        // Ensure proper line breaks around LaTeX environments
        $html = preg_replace_callback('/\\\\begin\{(itemize|enumerate)\}\s*/', function($m) {
            return "\\begin{{$m[1]}}\n";
        }, $html);

        $html = preg_replace_callback('/\s*\\\\end\{(itemize|enumerate)\}/', function($m) {
            return "\n\\end{{$m[1]}}";
        }, $html);

        // Handle paragraph spacing
        $html = preg_replace("/\n{3,}/", "\n\n\\vspace{{$paragraphSpacing}}\n\n", $html);

        return trim($html);
    }

    /**
     * Validates LaTeX content for potential compilation errors
     * Caution: all special characters in $data are treated by calling the function replaceSpecialCharacters().
     * @param array $data Data to be validated for LaTeX compilation
     * @return array ['valid' => bool, 'errors' => array]
     */
    public static function validateTreatedLaTeXContent($data) {
        $result = [
            'valid' => true,
            'errors' => [],
            'error_fields' => []
        ];

        try {
            // Combine all data into tex_content first
            $tex_content = '';
            foreach ($data as $value) {
                if (is_array($value)) {
                    $tex_content .= self::arrayToString($value) . "\n";
                } else {
                    $tex_content .= strval($value) . "\n";
                }
            }
            $tex_content = self::plainTextToLatex($tex_content);

            // Test complete document first
            $test_content = "\\documentclass{article}\n" .
                "\\usepackage[utf8]{inputenc}\n" .
                "\\usepackage{amsmath}\n" .
                "\\begin{document}\n" .
                $tex_content .
                "\n\\end{document}";

            $tempBase = tempnam(sys_get_temp_dir(), 'tex-validate-');
            if ($tempBase === false) {
                throw new Exception('Failed to create temporary file');
            }

            $tex_f = $tempBase . '.tex';
            $log_f = $tempBase . '.log';

            try {
                if (file_put_contents($tex_f, $test_content) === false) {
                    throw new Exception('Failed to write to temporary tex file for complete document');
                }

                $cmd = sprintf("xelatex -interaction nonstopmode -halt-on-error -no-pdf %s 2>&1",
                    escapeshellarg($tex_f));

                chdir(sys_get_temp_dir());
                exec($cmd, $output, $returnCode);

                // If complete document fails, test individual fields
                if ($returnCode !== 0) {
                    // Test each field individually to identify problematic ones
                    foreach ($data as $key => $value) {
                        $field_content = '';
                        if (is_array($value)) {
                            $field_content = self::arrayToString($value);
                        } else {
                            $field_content = strval($value);
                        }
                        $field_content = self::replaceSpecialCharacters($field_content);

                        // Create a test document for this field
                        $test_content = "\\documentclass{article}\n" .
                            "\\usepackage[utf8]{inputenc}\n" .
                            "\\usepackage{amsmath}\n" .
                            "\\begin{document}\n" .
                            $field_content .
                            "\n\\end{document}";

                        $field_tempBase = tempnam(sys_get_temp_dir(), 'tex-validate-');
                        if ($field_tempBase === false) {
                            throw new Exception('Failed to create temporary file');
                        }

                        $field_tex_f = $field_tempBase . '.tex';
                        $field_log_f = $field_tempBase . '.log';

                        try {
                            if (file_put_contents($field_tex_f, $test_content) === false) {
                                throw new Exception("Failed to write to temporary tex file for field: $key");
                            }

                            $cmd = sprintf("xelatex -interaction nonstopmode -halt-on-error -no-pdf %s 2>&1",
                                escapeshellarg($field_tex_f));

                            exec($cmd, $output, $returnCode);

                            if ($returnCode !== 0) {
                                if (file_exists($field_log_f)) {
                                    $log_content = file_get_contents($field_log_f);
                                    preg_match_all('/^!(.*?)$/m', $log_content, $error_matches);
                                    foreach ($error_matches[1] as $error) {
                                        if (!in_array($key, $result['error_fields'])) {
                                            $result['error_fields'][] = $key;
                                            $result['errors'][] = "Field '$key': LaTeX Error: " . trim($error);
                                        }
                                    }
                                } else {
                                    if (!in_array($key, $result['error_fields'])) {
                                        $result['error_fields'][] = $key;
                                        $result['errors'][] = "Field '$key': Compilation failed without log file";
                                    }
                                }
                            }
                        } finally {
                            @unlink($field_tex_f);
                            @unlink($field_log_f);
                            @unlink($field_tempBase);
                        }
                    }
                }
            } finally {
                @unlink($tex_f);
                @unlink($log_f);
                @unlink($tempBase);
            }

            $result['valid'] = empty($result['errors']);
            return $result;

        } catch (Exception $e) {
            $result['valid'] = false;
            $result['errors'][] = 'Validation error: ' . $e->getMessage();
            return $result;
        }
    }

    /**
     * Validates LaTeX content for potential compilation errors
     *
     * @param array $data Data to be validated for LaTeX compilation
     * @return array ['valid' => bool, 'errors' => array]
     */
    public static function validateLaTeXContent($data) {
        $result = [
            'valid' => true,
            'errors' => []
        ];

        // Common problematic patterns in LaTeX
        $problemPatterns = [
            // Special characters that need escaping
            '([^\\\\])[$&%#_{}~^]' => 'Unescaped special character: $1',

            // Unicode characters that might cause issues
            '[^\x00-\x7F]+' => 'Non-ASCII character detected',

            // Common incorrect usage
            '\\\[^a-zA-Z\s{}]' => 'Invalid escape sequence',

            // Unmatched braces
            '(?<!\\\\)({(?![^{}]*}))' => 'Unmatched opening brace',
            '(?<!\\\\)(}(?![^{}]*{))' => 'Unmatched closing brace',

            // Math mode errors
            '(?<!\\\\)\$[^$]*$' => 'Unclosed math mode',

            // Common undefined control sequences
            '\\\\[a-zA-Z]+' => 'Potential undefined command',

            // File paths with spaces or special characters
            'includegraphics\{[^}]*\s+[^}]*\}' => 'File path contains spaces',

            // Potential verbatim environment issues
            '\\\\begin\{verbatim\}.*\\\\end\{verbatim\}' => 'Check verbatim environment',
        ];

        try {
            // Convert array data to string content for testing
            $tex_content = '';
            foreach ($data as $key => $value) {
                if (is_array($value)) {
                    // Handle nested arrays by converting to string
                    $tex_content .= self::arrayToString($value) . "\n";
                } else {
                    $tex_content .= strval($value) . "\n";
                }
            }

            // Create a minimal test document
            $test_content = "\\documentclass{article}\n" .
                "\\usepackage[utf8]{inputenc}\n" .
                "\\usepackage{amsmath}\n" .
                "\\begin{document}\n" .
                $tex_content .
                "\n\\end{document}";

            // Check for problematic patterns
            foreach ($problemPatterns as $pattern => $error) {
                if (preg_match_all('/' . $pattern . '/u', $tex_content, $matches, PREG_OFFSET_CAPTURE)) {
                    foreach ($matches[0] as $match) {
                        $line = substr_count(substr($tex_content, 0, $match[1]), "\n") + 1;
                        $key = array_search($match[0], $data);
                        $context = $key !== false ? " in field '$key'" : "";
                        $result['errors'][] = "$error$context at line $line: '{$match[0]}'";
                    }
                }
            }

            // Perform a test compilation if no basic errors found
            if (empty($result['errors'])) {
                $tempBase = tempnam(sys_get_temp_dir(), 'tex-validate-');
                if ($tempBase === false) {
                    throw new Exception('Failed to create temporary file');
                }

                $tex_f = $tempBase . '.tex';
                $log_f = $tempBase . '.log';

                try {
                    // Write test content to temporary file
                    if (file_put_contents($tex_f, $test_content) === false) {
                        throw new Exception('Failed to write to temporary tex file');
                    }

                    // Test compilation
                    $cmd = sprintf("xelatex -interaction nonstopmode -halt-on-error -no-pdf %s 2>&1",
                        escapeshellarg($tex_f));

                    chdir(sys_get_temp_dir());
                    exec($cmd, $output, $returnCode);

                    // Check compilation errors
                    if ($returnCode !== 0) {
                        if (file_exists($log_f)) {
                            $log_content = file_get_contents($log_f);
                            preg_match_all('/^!(.*?)$/m', $log_content, $error_matches);
                            foreach ($error_matches[1] as $error) {
                                $result['errors'][] = 'LaTeX Error: ' . trim($error);
                            }
                        } else {
                            $result['errors'][] = 'Compilation failed without log file';
                        }
                    }
                } finally {
                    // Cleanup temporary files
                    @unlink($tex_f);
                    @unlink($log_f);
                    @unlink($tempBase);
                }
            }

            $result['valid'] = empty($result['errors']);
            return $result;

        } catch (Exception $e) {
            $result['valid'] = false;
            $result['errors'][] = 'Validation error: ' . $e->getMessage();
            return $result;
        }
    }

    /**
     * Helper function to convert nested arrays to string
     *
     * @param array $arr Array to convert
     * @return string
     */
    private static function arrayToString($arr) {
        $result = '';
        foreach ($arr as $key => $value) {
            if (is_array($value)) {
                $result .= self::arrayToString($value) . "\n";
            } else {
                $result .= strval($value) . "\n";
            }
        }
        return $result;
    }

}
