<?php
if (isset($argv[1])) {
    require_once ('notify_user.php');
    Notify_Admin($argv[1]);
}