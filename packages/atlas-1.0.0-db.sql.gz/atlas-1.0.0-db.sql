-- MySQL dump 10.13  Distrib 8.4.10, for Linux (x86_64)
--
-- Host: localhost    Database: atlas_db
-- ------------------------------------------------------
-- Server version	8.4.10-0ubuntu0.26.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AVCourses`
--

DROP TABLE IF EXISTS `AVCourses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AVCourses` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `Semester` int NOT NULL,
  `CRN` int NOT NULL,
  `Subject` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Num` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CourseNo` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Section` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Credits` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Days` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Times` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DateRange` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Instructor` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `InstructorEmail` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Level` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Capacity` smallint DEFAULT NULL,
  `Actual` smallint DEFAULT NULL,
  `Syllabus` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Sync` tinyint(1) NOT NULL DEFAULT '0',
  `crsbinder_updated` tinyint NOT NULL DEFAULT '0',
  `CollectMaterials` tinyint NOT NULL DEFAULT '0',
  `Survey` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SurveyReport` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `IsManuallyEdited` tinyint DEFAULT '0',
  PRIMARY KEY (`Idx`),
  KEY `Title` (`Title`)
) ENGINE=InnoDB AUTO_INCREMENT=2013 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AVCourses`
--

LOCK TABLES `AVCourses` WRITE;
/*!40000 ALTER TABLE `AVCourses` DISABLE KEYS */;
/*!40000 ALTER TABLE `AVCourses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AVCoursesInstructors`
--

DROP TABLE IF EXISTS `AVCoursesInstructors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AVCoursesInstructors` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AVCourseIdx` int NOT NULL,
  `Instructor` int NOT NULL,
  PRIMARY KEY (`Idx`),
  KEY `AVCourseIdx` (`AVCourseIdx`,`Instructor`),
  KEY `Instructor` (`Instructor`),
  CONSTRAINT `AVCoursesInstructors_ibfk_1` FOREIGN KEY (`AVCourseIdx`) REFERENCES `AVCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AVCoursesInstructors_ibfk_2` FOREIGN KEY (`Instructor`) REFERENCES `UserAccounts` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3681 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AVCoursesInstructors`
--

LOCK TABLES `AVCoursesInstructors` WRITE;
/*!40000 ALTER TABLE `AVCoursesInstructors` DISABLE KEYS */;
/*!40000 ALTER TABLE `AVCoursesInstructors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AVCourses_Assistants`
--

DROP TABLE IF EXISTS `AVCourses_Assistants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AVCourses_Assistants` (
  `AVCourseIdx` int NOT NULL,
  `Assistant` int NOT NULL,
  PRIMARY KEY (`AVCourseIdx`,`Assistant`) USING BTREE,
  KEY `TA` (`Assistant`),
  CONSTRAINT `AVCourses_Assistants_ibfk_1` FOREIGN KEY (`Assistant`) REFERENCES `UserAccounts` (`Idx`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AVCourses_Assistants`
--

LOCK TABLES `AVCourses_Assistants` WRITE;
/*!40000 ALTER TABLE `AVCourses_Assistants` DISABLE KEYS */;
/*!40000 ALTER TABLE `AVCourses_Assistants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AVCourses_CrsMaterials`
--

DROP TABLE IF EXISTS `AVCourses_CrsMaterials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AVCourses_CrsMaterials` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AvailableCourseIdx` int NOT NULL,
  `AssmntType` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `AssmntNum` int DEFAULT NULL,
  `AssmntSample` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `StudentSample1` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `StudentSample2` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `StudentSample3` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  KEY `AvailableCourseIdx` (`AvailableCourseIdx`),
  CONSTRAINT `AVCourses_CrsMaterials_ibfk_1` FOREIGN KEY (`AvailableCourseIdx`) REFERENCES `AVCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1006 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AVCourses_CrsMaterials`
--

LOCK TABLES `AVCourses_CrsMaterials` WRITE;
/*!40000 ALTER TABLE `AVCourses_CrsMaterials` DISABLE KEYS */;
/*!40000 ALTER TABLE `AVCourses_CrsMaterials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AVCourses_InstMaterials`
--

DROP TABLE IF EXISTS `AVCourses_InstMaterials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AVCourses_InstMaterials` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AvailableCourseIdx` int NOT NULL,
  `MaterialType` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `MaterialSample` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Idx`),
  KEY `AvailableCourseIdx` (`AvailableCourseIdx`),
  CONSTRAINT `AVCourses_InstMaterials_ibfk_1` FOREIGN KEY (`AvailableCourseIdx`) REFERENCES `AVCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=852 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AVCourses_InstMaterials`
--

LOCK TABLES `AVCourses_InstMaterials` WRITE;
/*!40000 ALTER TABLE `AVCourses_InstMaterials` DISABLE KEYS */;
/*!40000 ALTER TABLE `AVCourses_InstMaterials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AbetCourses`
--

DROP TABLE IF EXISTS `AbetCourses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AbetCourses` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AcademicYear` int DEFAULT NULL,
  `AVCourseIdx` int NOT NULL,
  `Requirement` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Level` tinyint DEFAULT NULL,
  `CollectMaterials` tinyint DEFAULT NULL,
  `AcademicProgram` int NOT NULL,
  `Syllabus` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SyllabusLastUpdated` date DEFAULT NULL,
  `CrsAssessmentUpdated` tinyint NOT NULL DEFAULT '0',
  `Reference` int DEFAULT NULL,
  `Linked` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `Idx` (`Idx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `CourseIdx` (`AVCourseIdx`),
  KEY `AcademicYear` (`AcademicYear`),
  CONSTRAINT `AbetCourses_ibfk_1` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetCourses_ibfk_3` FOREIGN KEY (`AcademicYear`) REFERENCES `AcademicYears` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetCourses_ibfk_4` FOREIGN KEY (`AVCourseIdx`) REFERENCES `AVCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1611 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AbetCourses`
--

LOCK TABLES `AbetCourses` WRITE;
/*!40000 ALTER TABLE `AbetCourses` DISABLE KEYS */;
/*!40000 ALTER TABLE `AbetCourses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AbetCourses_Assistants`
--

DROP TABLE IF EXISTS `AbetCourses_Assistants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AbetCourses_Assistants` (
  `AbetCourseIdx` int NOT NULL,
  `Assistant` int NOT NULL,
  PRIMARY KEY (`AbetCourseIdx`,`Assistant`) USING BTREE,
  KEY `TA` (`Assistant`),
  CONSTRAINT `AbetCourses_Assistants_ibfk_1` FOREIGN KEY (`Assistant`) REFERENCES `UserAccounts` (`Idx`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AbetCourses_Assistants`
--

LOCK TABLES `AbetCourses_Assistants` WRITE;
/*!40000 ALTER TABLE `AbetCourses_Assistants` DISABLE KEYS */;
/*!40000 ALTER TABLE `AbetCourses_Assistants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AbetCourses_Evaluators`
--

DROP TABLE IF EXISTS `AbetCourses_Evaluators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AbetCourses_Evaluators` (
  `AbetCourseIdx` int NOT NULL,
  `Evaluator` int NOT NULL,
  PRIMARY KEY (`AbetCourseIdx`,`Evaluator`) USING BTREE,
  KEY `Evaluator` (`Evaluator`),
  CONSTRAINT `AbetCourses_Evaluators_ibfk_1` FOREIGN KEY (`Evaluator`) REFERENCES `UserAccounts` (`Idx`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AbetCourses_Evaluators`
--

LOCK TABLES `AbetCourses_Evaluators` WRITE;
/*!40000 ALTER TABLE `AbetCourses_Evaluators` DISABLE KEYS */;
/*!40000 ALTER TABLE `AbetCourses_Evaluators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AbetCourses_GPIs`
--

DROP TABLE IF EXISTS `AbetCourses_GPIs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AbetCourses_GPIs` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `GPIIdx` int NOT NULL DEFAULT '0',
  `AbetCourseIdx` int NOT NULL,
  `SOIdx` int NOT NULL,
  `AcademicYear` int DEFAULT NULL,
  `AcademicProgram` int NOT NULL,
  PRIMARY KEY (`Idx`),
  KEY `GPI` (`GPIIdx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `AcademicYear` (`AcademicYear`),
  KEY `AbetCourse` (`AbetCourseIdx`),
  KEY `SOIdx` (`SOIdx`),
  CONSTRAINT `AbetCourses_GPIs_ibfk_2` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetCourses_GPIs_ibfk_4` FOREIGN KEY (`AcademicYear`) REFERENCES `AcademicYears` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetCourses_GPIs_ibfk_6` FOREIGN KEY (`GPIIdx`) REFERENCES `GeneralPerformanceIndicators` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetCourses_GPIs_ibfk_7` FOREIGN KEY (`AbetCourseIdx`) REFERENCES `AbetCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetCourses_GPIs_ibfk_8` FOREIGN KEY (`SOIdx`) REFERENCES `StudentOutcomes` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4877 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AbetCourses_GPIs`
--

LOCK TABLES `AbetCourses_GPIs` WRITE;
/*!40000 ALTER TABLE `AbetCourses_GPIs` DISABLE KEYS */;
/*!40000 ALTER TABLE `AbetCourses_GPIs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AbetCourses_SOs`
--

DROP TABLE IF EXISTS `AbetCourses_SOs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AbetCourses_SOs` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `SOIdx` int DEFAULT NULL,
  `AbetCourseIdx` int DEFAULT NULL,
  `AcademicYear` int DEFAULT NULL,
  `AcademicProgram` int NOT NULL,
  PRIMARY KEY (`Idx`),
  KEY `SO` (`SOIdx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `AbetCourse` (`AbetCourseIdx`),
  KEY `AcademicYear` (`AcademicYear`),
  CONSTRAINT `AbetCourses_SOs_ibfk_2` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetCourses_SOs_ibfk_5` FOREIGN KEY (`AcademicYear`) REFERENCES `AcademicYears` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetCourses_SOs_ibfk_6` FOREIGN KEY (`SOIdx`) REFERENCES `StudentOutcomes` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetCourses_SOs_ibfk_7` FOREIGN KEY (`AbetCourseIdx`) REFERENCES `AbetCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3928 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AbetCourses_SOs`
--

LOCK TABLES `AbetCourses_SOs` WRITE;
/*!40000 ALTER TABLE `AbetCourses_SOs` DISABLE KEYS */;
/*!40000 ALTER TABLE `AbetCourses_SOs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AbetSyllabus`
--

DROP TABLE IF EXISTS `AbetSyllabus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AbetSyllabus` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `CourseIndex` int NOT NULL,
  `major_version` int NOT NULL DEFAULT '1',
  `minor_version` int NOT NULL DEFAULT '0',
  `AcademicYearFrom` int DEFAULT NULL,
  `AcademicYearTo` int DEFAULT NULL,
  `Description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `Credits` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Requirement` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Pre_requisites` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Co_requisites` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Required_Texts` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `Reference_Texts` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `Coordinator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ObjectivesHeadline` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `Objectives` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `TopicsCoveredHeadline` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `TopicsCovered` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `RevisionDesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `RevisionDate` date DEFAULT NULL,
  `ApprovalDesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ApprovalDate` date DEFAULT NULL,
  `AcademicProgram` int DEFAULT NULL,
  `LinkedSyllabus` int DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  KEY `CourseIndex` (`CourseIndex`),
  KEY `AcademicYearFrom` (`AcademicYearFrom`),
  KEY `AcademicYearTo` (`AcademicYearTo`),
  KEY `AcademicProgram` (`AcademicProgram`),
  CONSTRAINT `AbetSyllabus_ibfk_1` FOREIGN KEY (`CourseIndex`) REFERENCES `Courses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AbetSyllabus_ibfk_2` FOREIGN KEY (`AcademicYearFrom`) REFERENCES `AcademicYears` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AbetSyllabus_ibfk_3` FOREIGN KEY (`AcademicYearTo`) REFERENCES `AcademicYears` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AbetSyllabus_ibfk_4` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=376 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AbetSyllabus`
--

LOCK TABLES `AbetSyllabus` WRITE;
/*!40000 ALTER TABLE `AbetSyllabus` DISABLE KEYS */;
/*!40000 ALTER TABLE `AbetSyllabus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AbetSyllabus_RevisionHistory`
--

DROP TABLE IF EXISTS `AbetSyllabus_RevisionHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AbetSyllabus_RevisionHistory` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `AbetSyllabus` int NOT NULL,
  `RevisionDesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ApprovalDesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ApprovalDate` date DEFAULT NULL,
  PRIMARY KEY (`idx`),
  KEY `AbetSyllabus` (`AbetSyllabus`),
  CONSTRAINT `AbetSyllabus_RevisionHistory_ibfk_1` FOREIGN KEY (`AbetSyllabus`) REFERENCES `AbetSyllabus` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AbetSyllabus_RevisionHistory`
--

LOCK TABLES `AbetSyllabus_RevisionHistory` WRITE;
/*!40000 ALTER TABLE `AbetSyllabus_RevisionHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `AbetSyllabus_RevisionHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AcademicPrograms`
--

DROP TABLE IF EXISTS `AcademicPrograms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AcademicPrograms` (
  `Idx` int NOT NULL,
  `Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Degree` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Department` int DEFAULT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `Major` (`Name`),
  KEY `Department` (`Department`),
  CONSTRAINT `AcademicPrograms_ibfk_1` FOREIGN KEY (`Department`) REFERENCES `Affiliations` (`Idx`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AcademicPrograms`
--

LOCK TABLES `AcademicPrograms` WRITE;
/*!40000 ALTER TABLE `AcademicPrograms` DISABLE KEYS */;
INSERT INTO `AcademicPrograms` VALUES (411424103,'Computer Science','BSCS',1441209656,'2020-12-02 08:52:58');
/*!40000 ALTER TABLE `AcademicPrograms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AcademicYears`
--

DROP TABLE IF EXISTS `AcademicYears`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AcademicYears` (
  `Idx` int NOT NULL,
  `AcademicYear` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `From` int NOT NULL,
  `To` int NOT NULL,
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `AcademicYear` (`AcademicYear`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AcademicYears`
--

LOCK TABLES `AcademicYears` WRITE;
/*!40000 ALTER TABLE `AcademicYears` DISABLE KEYS */;
/*!40000 ALTER TABLE `AcademicYears` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AccessControls`
--

DROP TABLE IF EXISTS `AccessControls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AccessControls` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AcademicProgram` int DEFAULT NULL,
  `UserAccount` int DEFAULT NULL,
  `Control` int DEFAULT '1',
  PRIMARY KEY (`Idx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `UserAccount` (`UserAccount`),
  CONSTRAINT `AccessControls_ibfk_1` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `AccessControls_ibfk_2` FOREIGN KEY (`UserAccount`) REFERENCES `UserAccounts` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=342 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AccessControls`
--

LOCK TABLES `AccessControls` WRITE;
/*!40000 ALTER TABLE `AccessControls` DISABLE KEYS */;
/*!40000 ALTER TABLE `AccessControls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Affiliations`
--

DROP TABLE IF EXISTS `Affiliations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Affiliations` (
  `Idx` int NOT NULL,
  `Name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Level` int DEFAULT '1',
  PRIMARY KEY (`Idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Affiliations`
--

LOCK TABLES `Affiliations` WRITE;
/*!40000 ALTER TABLE `Affiliations` DISABLE KEYS */;
INSERT INTO `Affiliations` VALUES (1441209656,'Department of Computer Science',1),(1459018425,'School of Engineering',0),(1470943928,'Department of Civil Engineering',1),(1470944598,'Department of Electrical Engineering',1),(1470945143,'Department of Mechanical Engineering',1);
/*!40000 ALTER TABLE `Affiliations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Analyzed_PerformanceIndicators`
--

DROP TABLE IF EXISTS `Analyzed_PerformanceIndicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Analyzed_PerformanceIndicators` (
  `AvailableCourseIdx` int NOT NULL,
  `AbetCourseIdx` int NOT NULL,
  `AcademicProgramIdx` int NOT NULL,
  `GPIIdx` int NOT NULL,
  `GPI` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g., SO1-PI1',
  `AVG` decimal(5,2) DEFAULT NULL COMMENT 'Overall average score',
  `TOTAL` int DEFAULT NULL COMMENT 'Total students included in calculation',
  `TOPFIFTY` int DEFAULT NULL COMMENT 'Students >= 2.0',
  `TOPTWENTYFIVE` int DEFAULT NULL COMMENT 'Students >= 3.0',
  PRIMARY KEY (`AvailableCourseIdx`,`AbetCourseIdx`,`AcademicProgramIdx`,`GPIIdx`),
  KEY `idx_gpi` (`GPIIdx`),
  KEY `idx_academic_program` (`AcademicProgramIdx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Stores analyzed Performance Indicator data per course';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Analyzed_PerformanceIndicators`
--

LOCK TABLES `Analyzed_PerformanceIndicators` WRITE;
/*!40000 ALTER TABLE `Analyzed_PerformanceIndicators` DISABLE KEYS */;
/*!40000 ALTER TABLE `Analyzed_PerformanceIndicators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Analyzed_StudentOutcomes`
--

DROP TABLE IF EXISTS `Analyzed_StudentOutcomes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Analyzed_StudentOutcomes` (
  `AvailableCourseIdx` int NOT NULL,
  `AbetCourseIdx` int NOT NULL,
  `AcademicProgramIdx` int NOT NULL,
  `SOIdx` int NOT NULL,
  `SO` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g., SO1, SO2',
  `AVG` decimal(5,2) DEFAULT NULL COMMENT 'Overall average score',
  `TOTAL` int DEFAULT NULL COMMENT 'Total students included in calculation',
  `TOPFIFTY` int DEFAULT NULL COMMENT 'Students >= 2.0',
  `TOPTWENTYFIVE` int DEFAULT NULL COMMENT 'Students >= 3.0',
  PRIMARY KEY (`AvailableCourseIdx`,`AbetCourseIdx`,`AcademicProgramIdx`,`SOIdx`),
  KEY `idx_so` (`SOIdx`),
  KEY `idx_academic_program` (`AcademicProgramIdx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Stores analyzed Student Outcome data per course';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Analyzed_StudentOutcomes`
--

LOCK TABLES `Analyzed_StudentOutcomes` WRITE;
/*!40000 ALTER TABLE `Analyzed_StudentOutcomes` DISABLE KEYS */;
/*!40000 ALTER TABLE `Analyzed_StudentOutcomes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssessmentMasterRubrics`
--

DROP TABLE IF EXISTS `AssessmentMasterRubrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AssessmentMasterRubrics` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AcademicYear` int DEFAULT NULL,
  `LevelofAttainment` int NOT NULL,
  `Description` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `Approval` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TobeRemoved` tinyint NOT NULL DEFAULT '0',
  `GPIIdx` int DEFAULT NULL,
  `AcademicProgram` int NOT NULL,
  PRIMARY KEY (`Idx`),
  KEY `GPIIdx` (`GPIIdx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `AcademicYear` (`AcademicYear`),
  CONSTRAINT `AssessmentMasterRubrics_ibfk_1` FOREIGN KEY (`GPIIdx`) REFERENCES `GeneralPerformanceIndicators` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AssessmentMasterRubrics_ibfk_2` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AssessmentMasterRubrics_ibfk_3` FOREIGN KEY (`AcademicYear`) REFERENCES `AcademicYears` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4229 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssessmentMasterRubrics`
--

LOCK TABLES `AssessmentMasterRubrics` WRITE;
/*!40000 ALTER TABLE `AssessmentMasterRubrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssessmentMasterRubrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssessmentMeasureSamples`
--

DROP TABLE IF EXISTS `AssessmentMeasureSamples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AssessmentMeasureSamples` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AssessmentMeasureIdx` int NOT NULL,
  `SampleFile` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  KEY `idx_assessment_measure` (`AssessmentMeasureIdx`),
  CONSTRAINT `fk_assessment_measure` FOREIGN KEY (`AssessmentMeasureIdx`) REFERENCES `AssessmentMeasures` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=807 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssessmentMeasureSamples`
--

LOCK TABLES `AssessmentMeasureSamples` WRITE;
/*!40000 ALTER TABLE `AssessmentMeasureSamples` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssessmentMeasureSamples` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AssessmentMeasures`
--

DROP TABLE IF EXISTS `AssessmentMeasures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AssessmentMeasures` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `GPI` int NOT NULL,
  `Measure` int NOT NULL,
  `AssignmentType` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `AssignmentNum` int DEFAULT NULL,
  `AssignmentProblem` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `AssignmentDescription` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `AvailableCourseIdx` int DEFAULT NULL,
  `AbetCourseIdx` int DEFAULT NULL,
  `ActualAssmntSample` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Idx`),
  KEY `GPI` (`GPI`),
  KEY `AvailableCourseIdx` (`AvailableCourseIdx`),
  KEY `AbetCourseIdx` (`AbetCourseIdx`),
  CONSTRAINT `AssessmentMeasures_ibfk_2` FOREIGN KEY (`GPI`) REFERENCES `GeneralPerformanceIndicators` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AssessmentMeasures_ibfk_3` FOREIGN KEY (`AvailableCourseIdx`) REFERENCES `AVCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `AssessmentMeasures_ibfk_4` FOREIGN KEY (`AbetCourseIdx`) REFERENCES `AbetCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3974 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AssessmentMeasures`
--

LOCK TABLES `AssessmentMeasures` WRITE;
/*!40000 ALTER TABLE `AssessmentMeasures` DISABLE KEYS */;
/*!40000 ALTER TABLE `AssessmentMeasures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AttainmentThresholds`
--

DROP TABLE IF EXISTS `AttainmentThresholds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AttainmentThresholds` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `ProgramIdx` int NOT NULL,
  `ThresholdType` enum('basic','proficiency') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ScoreThreshold` decimal(3,1) NOT NULL,
  `GreenThreshold` decimal(5,2) NOT NULL,
  `YellowThreshold` decimal(5,2) NOT NULL,
  `Label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ModifiedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CreatedBy` int DEFAULT NULL,
  `ModifiedBy` int DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `unique_program_type` (`ProgramIdx`,`ThresholdType`),
  KEY `ProgramIdx` (`ProgramIdx`),
  CONSTRAINT `AttainmentThresholds_ibfk_1` FOREIGN KEY (`ProgramIdx`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AttainmentThresholds`
--

LOCK TABLES `AttainmentThresholds` WRITE;
/*!40000 ALTER TABLE `AttainmentThresholds` DISABLE KEYS */;
INSERT INTO `AttainmentThresholds` VALUES (1,411424103,'basic',2.0,90.00,80.00,'Basic Competency (≥2.0)','2026-07-17 12:43:24','2026-07-18 13:25:31',NULL,NULL),(16,411424103,'proficiency',3.0,80.00,70.00,'Proficiency (≥3.0)','2026-07-17 12:43:24','2026-07-18 13:25:31',NULL,NULL);
/*!40000 ALTER TABLE `AttainmentThresholds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClassRoster`
--

DROP TABLE IF EXISTS `ClassRoster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ClassRoster` (
  `AvailableCourseIdx` int NOT NULL,
  `StudentNo` int NOT NULL,
  `StudentName` varbinary(256) DEFAULT NULL,
  `StudentMajor` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `IsDropped` tinyint NOT NULL DEFAULT '0',
  `AcademicProgramIdx` int DEFAULT NULL,
  PRIMARY KEY (`AvailableCourseIdx`,`StudentNo`) USING BTREE,
  KEY `AcademicProgramIdx` (`AcademicProgramIdx`),
  CONSTRAINT `ClassRoster_ibfk_2` FOREIGN KEY (`AcademicProgramIdx`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClassRoster`
--

LOCK TABLES `ClassRoster` WRITE;
/*!40000 ALTER TABLE `ClassRoster` DISABLE KEYS */;
/*!40000 ALTER TABLE `ClassRoster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContinuousImprovement`
--

DROP TABLE IF EXISTS `ContinuousImprovement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ContinuousImprovement` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `FacultyReflection` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `EvaluatorsReflection` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `NumStudents` int DEFAULT NULL,
  `AvailableCourseIdx` int DEFAULT NULL,
  `AbetCourseIdx` int DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  KEY `AbetCourseIdx` (`AbetCourseIdx`),
  KEY `AvailableCourse` (`AvailableCourseIdx`),
  CONSTRAINT `ContinuousImprovement_ibfk_1` FOREIGN KEY (`AvailableCourseIdx`) REFERENCES `AVCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ContinuousImprovement_ibfk_2` FOREIGN KEY (`AbetCourseIdx`) REFERENCES `AbetCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=594 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContinuousImprovement`
--

LOCK TABLES `ContinuousImprovement` WRITE;
/*!40000 ALTER TABLE `ContinuousImprovement` DISABLE KEYS */;
/*!40000 ALTER TABLE `ContinuousImprovement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CourseMapping_Courses`
--

DROP TABLE IF EXISTS `CourseMapping_Courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CourseMapping_Courses` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AcademicYear` int DEFAULT NULL,
  `CourseIdx` int DEFAULT NULL,
  `Requirement` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Level` tinyint DEFAULT NULL,
  `AcademicProgram` int DEFAULT NULL,
  `AbetSyllabus` int DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `CourseIdx` (`CourseIdx`),
  KEY `AcademicYear` (`AcademicYear`),
  KEY `AbetSyllabus` (`AbetSyllabus`),
  CONSTRAINT `CourseMapping_Courses_ibfk_1` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_Courses_ibfk_3` FOREIGN KEY (`AcademicYear`) REFERENCES `AcademicYears` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_Courses_ibfk_4` FOREIGN KEY (`CourseIdx`) REFERENCES `Courses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_Courses_ibfk_5` FOREIGN KEY (`AbetSyllabus`) REFERENCES `AbetSyllabus` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3033 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CourseMapping_Courses`
--

LOCK TABLES `CourseMapping_Courses` WRITE;
/*!40000 ALTER TABLE `CourseMapping_Courses` DISABLE KEYS */;
/*!40000 ALTER TABLE `CourseMapping_Courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CourseMapping_GPIs`
--

DROP TABLE IF EXISTS `CourseMapping_GPIs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CourseMapping_GPIs` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `GPIIdx` int NOT NULL DEFAULT '0',
  `AbetCourseIdx` int NOT NULL,
  `SOIdx` int NOT NULL,
  `AcademicYear` int DEFAULT NULL,
  `AcademicProgram` int NOT NULL,
  PRIMARY KEY (`Idx`),
  KEY `GPI` (`GPIIdx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `AcademicYear` (`AcademicYear`),
  KEY `AbetCourse` (`AbetCourseIdx`),
  KEY `SOIdx` (`SOIdx`),
  CONSTRAINT `CourseMapping_GPIs_ibfk_2` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_GPIs_ibfk_4` FOREIGN KEY (`AcademicYear`) REFERENCES `AcademicYears` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_GPIs_ibfk_6` FOREIGN KEY (`GPIIdx`) REFERENCES `GeneralPerformanceIndicators` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_GPIs_ibfk_7` FOREIGN KEY (`AbetCourseIdx`) REFERENCES `CourseMapping_Courses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_GPIs_ibfk_8` FOREIGN KEY (`SOIdx`) REFERENCES `StudentOutcomes` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8913 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CourseMapping_GPIs`
--

LOCK TABLES `CourseMapping_GPIs` WRITE;
/*!40000 ALTER TABLE `CourseMapping_GPIs` DISABLE KEYS */;
/*!40000 ALTER TABLE `CourseMapping_GPIs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CourseMapping_SOs`
--

DROP TABLE IF EXISTS `CourseMapping_SOs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CourseMapping_SOs` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `SOIdx` int DEFAULT NULL,
  `AbetCourseIdx` int DEFAULT NULL,
  `AcademicYear` int DEFAULT NULL,
  `AcademicProgram` int NOT NULL,
  PRIMARY KEY (`Idx`),
  KEY `SO` (`SOIdx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `AbetCourse` (`AbetCourseIdx`),
  KEY `AcademicYear` (`AcademicYear`),
  CONSTRAINT `CourseMapping_SOs_ibfk_2` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_SOs_ibfk_5` FOREIGN KEY (`AcademicYear`) REFERENCES `AcademicYears` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_SOs_ibfk_6` FOREIGN KEY (`SOIdx`) REFERENCES `StudentOutcomes` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CourseMapping_SOs_ibfk_7` FOREIGN KEY (`AbetCourseIdx`) REFERENCES `CourseMapping_Courses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5905 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CourseMapping_SOs`
--

LOCK TABLES `CourseMapping_SOs` WRITE;
/*!40000 ALTER TABLE `CourseMapping_SOs` DISABLE KEYS */;
/*!40000 ALTER TABLE `CourseMapping_SOs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Courses`
--

DROP TABLE IF EXISTS `Courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Courses` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `Subject` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Num` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `TitleUniv` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Course title appeared in the university system',
  `Credits` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `Idx` (`Idx`)
) ENGINE=InnoDB AUTO_INCREMENT=331 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Courses`
--

LOCK TABLES `Courses` WRITE;
/*!40000 ALTER TABLE `Courses` DISABLE KEYS */;
/*!40000 ALTER TABLE `Courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DebugLog`
--

DROP TABLE IF EXISTS `DebugLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DebugLog` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `LogTime` datetime DEFAULT CURRENT_TIMESTAMP,
  `ProcedureName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `Data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`Idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DebugLog`
--

LOCK TABLES `DebugLog` WRITE;
/*!40000 ALTER TABLE `DebugLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `DebugLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GeneralPerformanceIndicators`
--

DROP TABLE IF EXISTS `GeneralPerformanceIndicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GeneralPerformanceIndicators` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AcademicYear` int DEFAULT NULL,
  `SOIdx` int DEFAULT NULL,
  `GPI` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `Approval` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TobeRemoved` tinyint NOT NULL DEFAULT '0',
  `AcademicProgram` int DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `SOIdx` (`SOIdx`),
  KEY `AcademicYear` (`AcademicYear`),
  CONSTRAINT `GeneralPerformanceIndicators_ibfk_1` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `GeneralPerformanceIndicators_ibfk_2` FOREIGN KEY (`SOIdx`) REFERENCES `StudentOutcomes` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `GeneralPerformanceIndicators_ibfk_3` FOREIGN KEY (`AcademicYear`) REFERENCES `AcademicYears` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1153 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GeneralPerformanceIndicators`
--

LOCK TABLES `GeneralPerformanceIndicators` WRITE;
/*!40000 ALTER TABLE `GeneralPerformanceIndicators` DISABLE KEYS */;
/*!40000 ALTER TABLE `GeneralPerformanceIndicators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LoginHistory`
--

DROP TABLE IF EXISTS `LoginHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LoginHistory` (
  `UserIdx` int NOT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `No` (`UserIdx`,`Date`),
  CONSTRAINT `LoginHistory_ibfk_1` FOREIGN KEY (`UserIdx`) REFERENCES `UserAccounts` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LoginHistory`
--

LOCK TABLES `LoginHistory` WRITE;
/*!40000 ALTER TABLE `LoginHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `LoginHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MainMenuGroups`
--

DROP TABLE IF EXISTS `MainMenuGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MainMenuGroups` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `MenuCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `MenuName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `DisplayOrder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `MenuCode` (`MenuCode`),
  KEY `idx_display_order` (`DisplayOrder`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MainMenuGroups`
--

LOCK TABLES `MainMenuGroups` WRITE;
/*!40000 ALTER TABLE `MainMenuGroups` DISABLE KEYS */;
INSERT INTO `MainMenuGroups` VALUES (1,'COURSE_ASSESSMENTS','Course Assessments',1),(2,'ASSESSMENTS_SUMMARY','Assessments Summary',2),(3,'ABET_ASSESSMENTS','ABET Assessments',3),(4,'INFO_MANAGEMENT','Information Management',4);
/*!40000 ALTER TABLE `MainMenuGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Positions`
--

DROP TABLE IF EXISTS `Positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Positions` (
  `Idx` int NOT NULL,
  `Name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Level` int NOT NULL DEFAULT '0',
  `AccessMyCourseAssessments` tinyint NOT NULL DEFAULT '1',
  `AccessTACourseAssessments` tinyint NOT NULL DEFAULT '0',
  `AccessCourseEvaluation` tinyint NOT NULL DEFAULT '1',
  `AccessAssessmentsSummary` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`Idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Positions`
--

LOCK TABLES `Positions` WRITE;
/*!40000 ALTER TABLE `Positions` DISABLE KEYS */;
INSERT INTO `Positions` VALUES (85818,'Guest (ABET Team Chair)',0,1,0,1,1),(999999997,'Guest (ABET PEV)',0,0,0,0,1),(999999998,'Teaching Assistant',0,0,1,0,0),(999999999,'System Administrator',0,1,1,1,1),(1442712301,'Assistant Professor',1,1,0,1,1),(1442712330,'Professor',1,1,0,1,1),(1459026765,'Dean',0,1,0,1,1),(1459026801,'Associate Dean',0,1,0,1,1),(1604934061,'Adjunct Professor',0,1,0,1,1),(1605925355,'Lecturer',0,1,0,1,1),(1611852737,'Staff',0,1,0,1,1),(1613754671,'Visiting Assistant Professor',0,1,0,1,1),(2147483647,'Associate Professor',1,1,0,1,1);
/*!40000 ALTER TABLE `Positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Scoresheet`
--

DROP TABLE IF EXISTS `Scoresheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Scoresheet` (
  `AvailableCourseIdx` int NOT NULL,
  `AbetCourseIdx` int NOT NULL,
  `AssessmentMeasureIdx` int NOT NULL,
  `StudentNo` int NOT NULL,
  `LevelOfAttainment` int DEFAULT NULL,
  `AcademicProgramIdx` int DEFAULT NULL,
  PRIMARY KEY (`AvailableCourseIdx`,`AbetCourseIdx`,`AssessmentMeasureIdx`,`StudentNo`),
  KEY `AssessmentMeasureIdx` (`AssessmentMeasureIdx`),
  KEY `AcademicProgramIdx` (`AcademicProgramIdx`),
  KEY `AbetCourseIdx` (`AbetCourseIdx`),
  CONSTRAINT `Scoresheet_ibfk_1` FOREIGN KEY (`AssessmentMeasureIdx`) REFERENCES `AssessmentMeasures` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Scoresheet_ibfk_2` FOREIGN KEY (`AcademicProgramIdx`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Scoresheet`
--

LOCK TABLES `Scoresheet` WRITE;
/*!40000 ALTER TABLE `Scoresheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `Scoresheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Scoresheet_Columns`
--

DROP TABLE IF EXISTS `Scoresheet_Columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Scoresheet_Columns` (
  `AvailableCourseIdx` int NOT NULL,
  `AbetCourseIdx` int NOT NULL,
  `StudentNo` int NOT NULL,
  `CustomColumnInfo` varbinary(256) DEFAULT NULL,
  `AcademicProgramIdx` int DEFAULT NULL,
  `IsRemoved` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`AvailableCourseIdx`,`AbetCourseIdx`,`StudentNo`) USING BTREE,
  KEY `AcademicProgramIdx` (`AcademicProgramIdx`),
  CONSTRAINT `Scoresheet_Columns_ibfk_2` FOREIGN KEY (`AcademicProgramIdx`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Scoresheet_Columns`
--

LOCK TABLES `Scoresheet_Columns` WRITE;
/*!40000 ALTER TABLE `Scoresheet_Columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `Scoresheet_Columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Semesters`
--

DROP TABLE IF EXISTS `Semesters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Semesters` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `SemesterCode` int NOT NULL,
  `Explanation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `UK_SemesterCode` (`SemesterCode`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Semesters`
--

LOCK TABLES `Semesters` WRITE;
/*!40000 ALTER TABLE `Semesters` DISABLE KEYS */;
/*!40000 ALTER TABLE `Semesters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StudentOutcomes`
--

DROP TABLE IF EXISTS `StudentOutcomes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `StudentOutcomes` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AcademicYear` int DEFAULT NULL,
  `SO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `Approval` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TobeRemoved` tinyint NOT NULL DEFAULT '0',
  `AcademicProgram` int DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  KEY `AcademicProgram` (`AcademicProgram`),
  KEY `AcademicYear` (`AcademicYear`),
  CONSTRAINT `StudentOutcomes_ibfk_1` FOREIGN KEY (`AcademicProgram`) REFERENCES `AcademicPrograms` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `StudentOutcomes_ibfk_2` FOREIGN KEY (`AcademicYear`) REFERENCES `AcademicYears` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=424 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StudentOutcomes`
--

LOCK TABLES `StudentOutcomes` WRITE;
/*!40000 ALTER TABLE `StudentOutcomes` DISABLE KEYS */;
/*!40000 ALTER TABLE `StudentOutcomes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SubMenuGroups`
--

DROP TABLE IF EXISTS `SubMenuGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SubMenuGroups` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `GroupCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `GroupName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ParentMenuCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `DisplayOrder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `GroupCode` (`GroupCode`),
  KEY `idx_display_order` (`DisplayOrder`),
  KEY `ParentMenuCode` (`ParentMenuCode`),
  CONSTRAINT `SubMenuGroups_ibfk_1` FOREIGN KEY (`ParentMenuCode`) REFERENCES `MainMenuGroups` (`MenuCode`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SubMenuGroups`
--

LOCK TABLES `SubMenuGroups` WRITE;
/*!40000 ALTER TABLE `SubMenuGroups` DISABLE KEYS */;
INSERT INTO `SubMenuGroups` VALUES (1,'MY_COURSE_ASSESSMENTS','My Course Assessments','COURSE_ASSESSMENTS',1),(2,'ASSISTANT_MENUS','Assistant\'s Menus','COURSE_ASSESSMENTS',2),(3,'REFERENCE_MATERIALS','Reference Materials','COURSE_ASSESSMENTS',3),(4,'ASSESSMENTS_FOR_DIRECTORS','Assessments for Program Directors','COURSE_ASSESSMENTS',4),(5,'ASSESSMENT_ASSIGNMENTS','Assessment Assignments','ASSESSMENTS_SUMMARY',1),(6,'EVALUATION_SO_PI','Evaluation of SO and PI','ASSESSMENTS_SUMMARY',2),(7,'COURSE_LEVEL_EVALUATION','Course-Level Evaluation','ASSESSMENTS_SUMMARY',3),(8,'SO_PI_MAPPINGS','SO & PI Mappings','ABET_ASSESSMENTS',1),(9,'ABET_ASSESSMENTS_GROUP','Assessments','ABET_ASSESSMENTS',2),(10,'SYLLABUS','Syllabus','ABET_ASSESSMENTS',3),(11,'INFO_LIST','InformationList','INFO_MANAGEMENT',1),(12,'FACULTY_WORKLOADS','Faculty Workloads','INFO_MANAGEMENT',2),(13,'AV_COURSES','Available Courses','INFO_MANAGEMENT',3);
/*!40000 ALTER TABLE `SubMenuGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Subjects`
--

DROP TABLE IF EXISTS `Subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Subjects` (
  `Idx` int NOT NULL,
  `Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Department` int DEFAULT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Idx`),
  KEY `Department` (`Department`),
  CONSTRAINT `Subjects_ibfk_2` FOREIGN KEY (`Department`) REFERENCES `Affiliations` (`Idx`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Subjects`
--

LOCK TABLES `Subjects` WRITE;
/*!40000 ALTER TABLE `Subjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `Subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TypeOfAssignments`
--

DROP TABLE IF EXISTS `TypeOfAssignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TypeOfAssignments` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `AssignmentType` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NumAssignments` int NOT NULL,
  `Editable` tinyint(1) NOT NULL DEFAULT '1',
  `AvailableCourseIdx` int DEFAULT NULL,
  `AbetCourseIdx` int DEFAULT NULL,
  PRIMARY KEY (`Idx`),
  KEY `AbetCourseIdx` (`AbetCourseIdx`),
  KEY `AvailableCourseIdx` (`AvailableCourseIdx`),
  CONSTRAINT `TypeOfAssignments_ibfk_3` FOREIGN KEY (`AbetCourseIdx`) REFERENCES `AbetCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `TypeOfAssignments_ibfk_4` FOREIGN KEY (`AvailableCourseIdx`) REFERENCES `AVCourses` (`Idx`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TypeOfAssignments`
--

LOCK TABLES `TypeOfAssignments` WRITE;
/*!40000 ALTER TABLE `TypeOfAssignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `TypeOfAssignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserAccounts`
--

DROP TABLE IF EXISTS `UserAccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserAccounts` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `Email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `PWD` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Position` int DEFAULT NULL,
  `Affiliation` int DEFAULT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `LastLogin` timestamp NULL DEFAULT NULL,
  `Observer` tinyint NOT NULL DEFAULT '0',
  `SystemAdmin` tinyint NOT NULL DEFAULT '0',
  `Disabled` tinyint(1) NOT NULL DEFAULT '0',
  `ResetPWD` tinyint NOT NULL DEFAULT '0',
  `LoginFails` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `Email` (`Email`),
  KEY `Affiliation` (`Affiliation`),
  KEY `Position` (`Position`),
  CONSTRAINT `UserAccounts_ibfk_1` FOREIGN KEY (`Affiliation`) REFERENCES `Affiliations` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `UserAccounts_ibfk_2` FOREIGN KEY (`Position`) REFERENCES `Positions` (`Idx`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=285 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserAccounts`
--

LOCK TABLES `UserAccounts` WRITE;
/*!40000 ALTER TABLE `UserAccounts` DISABLE KEYS */;
INSERT INTO `UserAccounts` VALUES (111,'admin@atlas.edu','15a1c481c9955117804fe517f399d60441c1488bfd057f6ec5cca3b90e6bb137','Administrator',999999999,NULL,'2021-01-28 17:29:49','2026-09-11 17:45:40',0,1,0,0,0);
/*!40000 ALTER TABLE `UserAccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserMenuPermissions`
--

DROP TABLE IF EXISTS `UserMenuPermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserMenuPermissions` (
  `Idx` int NOT NULL AUTO_INCREMENT,
  `UserIdx` int NOT NULL,
  `MenuCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `MenuGroupCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GrantedBy` int DEFAULT NULL,
  `GrantedDate` datetime DEFAULT NULL,
  `CreatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Idx`),
  UNIQUE KEY `unique_user_menu_group` (`UserIdx`,`MenuCode`,`MenuGroupCode`),
  KEY `idx_user` (`UserIdx`),
  KEY `idx_menu` (`MenuCode`),
  KEY `idx_menu_group` (`MenuGroupCode`)
) ENGINE=InnoDB AUTO_INCREMENT=773 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserMenuPermissions`
--

LOCK TABLES `UserMenuPermissions` WRITE;
/*!40000 ALTER TABLE `UserMenuPermissions` DISABLE KEYS */;
INSERT INTO `UserMenuPermissions` VALUES (7,12,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 10:19:51','2026-02-04 15:19:51','2026-02-04 15:19:51'),(8,12,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 10:19:52','2026-02-04 15:19:52','2026-02-04 15:19:52'),(9,12,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 10:19:52','2026-02-04 15:19:52','2026-02-04 15:19:52'),(11,12,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 10:19:54','2026-02-04 15:19:54','2026-02-04 15:19:54'),(28,12,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 10:32:01','2026-02-04 15:32:01','2026-02-04 15:32:01'),(29,12,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 10:32:22','2026-02-04 15:32:22','2026-02-04 15:32:22'),(31,12,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 10:32:34','2026-02-04 15:32:34','2026-02-04 15:32:34'),(32,12,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 10:32:35','2026-02-04 15:32:35','2026-02-04 15:32:35'),(34,126,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 10:55:31','2026-02-04 15:55:31','2026-02-04 15:55:31'),(40,126,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 10:55:31','2026-02-04 15:55:31','2026-02-04 15:55:31'),(117,12,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 10:58:18','2026-02-04 15:58:18','2026-02-04 15:58:18'),(204,36,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:09:48','2026-02-04 16:09:48','2026-02-04 16:09:48'),(205,7,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:09:48','2026-02-04 16:09:48','2026-02-04 16:09:48'),(215,20,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:09:48','2026-02-04 16:09:48','2026-02-04 16:09:48'),(218,60,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:09:48','2026-02-04 16:09:48','2026-02-04 16:09:48'),(219,67,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:09:48','2026-02-04 16:09:48','2026-02-04 16:09:48'),(220,59,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:09:48','2026-02-04 16:09:48','2026-02-04 16:09:48'),(223,80,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:09:56','2026-02-04 16:09:56','2026-02-04 16:09:56'),(224,30,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:09:56','2026-02-04 16:09:56','2026-02-04 16:09:56'),(231,65,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:09:56','2026-02-04 16:09:56','2026-02-04 16:09:56'),(232,31,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(233,131,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(234,123,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(235,22,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(236,8,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(237,99,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(238,129,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(239,46,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(240,126,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(241,114,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(242,57,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(243,19,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(244,62,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(245,91,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(246,79,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(247,133,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(248,134,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(249,115,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(250,17,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(251,41,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(252,77,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(253,13,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(254,14,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(255,45,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(256,130,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(257,53,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(258,50,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(259,12,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(260,76,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:10:03','2026-02-04 16:10:03','2026-02-04 16:10:03'),(261,114,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(262,57,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(263,53,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(264,19,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(265,59,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(266,50,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(267,76,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(268,31,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(269,131,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(270,123,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(271,62,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(272,22,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(273,91,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(274,17,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(275,8,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(276,41,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(277,77,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(278,99,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(279,13,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(280,36,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(281,7,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(282,129,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(283,20,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(284,79,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(285,14,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(286,60,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(287,67,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(288,80,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(289,30,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(290,133,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(291,134,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(292,46,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(293,115,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(294,45,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(295,130,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(296,65,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:14:41','2026-02-04 16:14:41','2026-02-04 16:14:41'),(297,126,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(298,114,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(299,57,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(300,53,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(301,59,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(302,19,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(303,76,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(304,50,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(305,31,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(306,131,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(307,123,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(308,62,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(309,22,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(310,91,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(311,17,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(312,8,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(313,41,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(314,77,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(315,99,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(316,13,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(317,36,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(318,7,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(319,129,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(320,20,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(321,14,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(322,79,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(323,60,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(324,67,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(325,80,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(326,30,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(327,133,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(328,46,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(329,134,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(330,115,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(331,45,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(332,130,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(333,65,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:14:51','2026-02-04 16:14:51','2026-02-04 16:14:51'),(334,126,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(335,114,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(336,53,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(337,57,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(338,59,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(339,19,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(340,50,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(341,76,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(342,31,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(343,131,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(344,123,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(345,22,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(346,62,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(347,91,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(348,17,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(349,8,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(350,41,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(351,77,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(352,7,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(353,99,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(354,13,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(355,36,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(356,129,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(357,20,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(358,14,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(359,79,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(360,60,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(361,67,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(362,80,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(363,30,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(364,133,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(365,46,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(366,115,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(367,134,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(368,45,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(369,130,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(370,65,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:15:01','2026-02-04 16:15:01','2026-02-04 16:15:01'),(371,126,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(372,114,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(373,57,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(374,53,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(375,59,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(376,19,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(377,50,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(378,76,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(379,31,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(380,131,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(381,123,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(382,62,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(383,22,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(384,91,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(385,17,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(386,41,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(387,8,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(388,77,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(389,99,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(390,13,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(391,7,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(392,36,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(393,129,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(394,20,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(395,14,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(396,79,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(397,60,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(398,67,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(399,80,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(400,30,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(401,133,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(402,46,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(403,134,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(404,115,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(405,45,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(406,130,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(407,65,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:15:03','2026-02-04 16:15:03','2026-02-04 16:15:03'),(408,126,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(409,114,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(410,57,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(411,53,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(412,59,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(413,19,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(414,50,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(415,76,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(416,31,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(417,131,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:04','2026-02-04 16:15:04','2026-02-04 16:15:04'),(418,123,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(419,62,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(420,22,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(421,91,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(422,17,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(423,8,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(424,41,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(425,77,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(426,99,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(427,13,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(428,36,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(429,7,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(430,129,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(431,20,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(432,14,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(433,79,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(434,60,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(435,67,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(436,80,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(437,30,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(438,133,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(439,46,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(440,134,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(441,115,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(442,45,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(443,130,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(444,65,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:15:05','2026-02-04 16:15:05','2026-02-04 16:15:05'),(445,19,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:15:23','2026-02-04 16:15:23','2026-02-04 16:15:23'),(446,19,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:15:26','2026-02-04 16:15:26','2026-02-04 16:15:26'),(447,19,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:27','2026-02-04 16:15:27','2026-02-04 16:15:27'),(448,19,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:15:28','2026-02-04 16:15:28','2026-02-04 16:15:28'),(449,96,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(450,101,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(451,116,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(452,114,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(453,144,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(454,57,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(455,110,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(456,53,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(457,128,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(458,59,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(459,37,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(460,50,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(461,148,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(462,85,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(463,142,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(464,147,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(465,118,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(466,86,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(467,76,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(468,112,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:50','2026-02-04 16:15:50','2026-02-04 16:15:50'),(469,136,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(470,31,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(471,131,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(472,123,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(473,38,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(474,124,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(475,22,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(476,62,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(477,91,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(478,17,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(479,102,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(480,98,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(481,8,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(482,41,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(483,77,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(484,99,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(485,247,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(486,13,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(487,36,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(488,7,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(489,129,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(490,20,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(491,18,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(492,149,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(493,143,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(494,97,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(495,14,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(496,120,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(497,79,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(498,60,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(499,117,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(500,67,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(501,78,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(502,80,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(503,30,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(504,133,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(505,46,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(506,134,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(507,100,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(508,135,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(509,127,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(510,145,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(511,132,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(512,115,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(513,146,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(514,45,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(515,95,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(516,125,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(517,130,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(518,1,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(519,65,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(520,92,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(521,94,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(522,93,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-04 11:15:51','2026-02-04 16:15:51','2026-02-04 16:15:51'),(523,53,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:16:19','2026-02-04 16:16:19','2026-02-04 16:16:19'),(524,53,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:16:21','2026-02-04 16:16:21','2026-02-04 16:16:21'),(525,53,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:16:22','2026-02-04 16:16:22','2026-02-04 16:16:22'),(526,65,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:16:50','2026-02-04 16:16:50','2026-02-04 16:16:50'),(527,65,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:16:52','2026-02-04 16:16:52','2026-02-04 16:16:52'),(528,65,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:16:53','2026-02-04 16:16:53','2026-02-04 16:16:53'),(529,67,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:17:02','2026-02-04 16:17:02','2026-02-04 16:17:02'),(530,67,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:17:03','2026-02-04 16:17:03','2026-02-04 16:17:03'),(531,67,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:17:04','2026-02-04 16:17:04','2026-02-04 16:17:04'),(532,41,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:17:13','2026-02-04 16:17:13','2026-02-04 16:17:13'),(533,41,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:17:14','2026-02-04 16:17:14','2026-02-04 16:17:14'),(534,41,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:17:15','2026-02-04 16:17:15','2026-02-04 16:17:15'),(535,20,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:17:23','2026-02-04 16:17:23','2026-02-04 16:17:23'),(536,20,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:17:24','2026-02-04 16:17:24','2026-02-04 16:17:24'),(537,20,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:17:25','2026-02-04 16:17:25','2026-02-04 16:17:25'),(538,37,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:17:32','2026-02-04 16:17:32','2026-02-04 16:17:32'),(539,37,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:17:33','2026-02-04 16:17:33','2026-02-04 16:17:33'),(540,37,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:17:34','2026-02-04 16:17:34','2026-02-04 16:17:34'),(541,37,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:17:36','2026-02-04 16:17:36','2026-02-04 16:17:36'),(542,37,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:17:37','2026-02-04 16:17:37','2026-02-04 16:17:37'),(543,37,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:17:37','2026-02-04 16:17:37','2026-02-04 16:17:37'),(544,37,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:17:38','2026-02-04 16:17:38','2026-02-04 16:17:38'),(545,37,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:17:39','2026-02-04 16:17:39','2026-02-04 16:17:39'),(546,37,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:17:40','2026-02-04 16:17:40','2026-02-04 16:17:40'),(547,86,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:17:57','2026-02-04 16:17:57','2026-02-04 16:17:57'),(548,86,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:17:59','2026-02-04 16:17:59','2026-02-04 16:17:59'),(549,86,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:18:00','2026-02-04 16:18:00','2026-02-04 16:18:00'),(550,86,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:18:01','2026-02-04 16:18:01','2026-02-04 16:18:01'),(551,86,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:18:03','2026-02-04 16:18:03','2026-02-04 16:18:03'),(552,86,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:18:04','2026-02-04 16:18:04','2026-02-04 16:18:04'),(553,86,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:18:05','2026-02-04 16:18:05','2026-02-04 16:18:05'),(554,86,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:18:06','2026-02-04 16:18:06','2026-02-04 16:18:06'),(555,86,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:18:06','2026-02-04 16:18:06','2026-02-04 16:18:06'),(556,77,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:18:13','2026-02-04 16:18:13','2026-02-04 16:18:13'),(557,77,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:18:14','2026-02-04 16:18:14','2026-02-04 16:18:14'),(558,77,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:18:15','2026-02-04 16:18:15','2026-02-04 16:18:15'),(559,30,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:18:28','2026-02-04 16:18:28','2026-02-04 16:18:28'),(560,30,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:18:29','2026-02-04 16:18:29','2026-02-04 16:18:29'),(561,30,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:18:30','2026-02-04 16:18:30','2026-02-04 16:18:30'),(562,130,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:18:37','2026-02-04 16:18:37','2026-02-04 16:18:37'),(563,130,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:18:38','2026-02-04 16:18:38','2026-02-04 16:18:38'),(564,130,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:18:39','2026-02-04 16:18:39','2026-02-04 16:18:39'),(565,14,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:18:47','2026-02-04 16:18:47','2026-02-04 16:18:47'),(566,14,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:18:48','2026-02-04 16:18:48','2026-02-04 16:18:48'),(567,14,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:18:49','2026-02-04 16:18:49','2026-02-04 16:18:49'),(568,17,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:18:55','2026-02-04 16:18:55','2026-02-04 16:18:55'),(569,17,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:18:56','2026-02-04 16:18:56','2026-02-04 16:18:56'),(570,17,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:18:57','2026-02-04 16:18:57','2026-02-04 16:18:57'),(571,91,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:19:06','2026-02-04 16:19:06','2026-02-04 16:19:06'),(572,91,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:19:08','2026-02-04 16:19:08','2026-02-04 16:19:08'),(573,91,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:19:09','2026-02-04 16:19:09','2026-02-04 16:19:09'),(574,57,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:19:16','2026-02-04 16:19:16','2026-02-04 16:19:16'),(575,57,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-02-04 11:19:17','2026-02-04 16:19:17','2026-02-04 16:19:17'),(576,57,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-02-04 11:19:18','2026-02-04 16:19:18','2026-02-04 16:19:18'),(577,96,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:19:58','2026-02-04 16:19:58','2026-02-04 16:19:58'),(578,101,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:01','2026-02-04 16:20:01','2026-02-04 16:20:01'),(579,85,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:09','2026-02-04 16:20:09','2026-02-04 16:20:09'),(580,147,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:10','2026-02-04 16:20:10','2026-02-04 16:20:10'),(581,118,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:11','2026-02-04 16:20:11','2026-02-04 16:20:11'),(582,112,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:14','2026-02-04 16:20:14','2026-02-04 16:20:14'),(583,136,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:15','2026-02-04 16:20:15','2026-02-04 16:20:15'),(584,38,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:16','2026-02-04 16:20:16','2026-02-04 16:20:16'),(585,124,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:17','2026-02-04 16:20:17','2026-02-04 16:20:17'),(586,98,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:20','2026-02-04 16:20:20','2026-02-04 16:20:20'),(587,102,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:21','2026-02-04 16:20:21','2026-02-04 16:20:21'),(589,18,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:26','2026-02-04 16:20:26','2026-02-04 16:20:26'),(590,97,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:29','2026-02-04 16:20:29','2026-02-04 16:20:29'),(591,120,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:30','2026-02-04 16:20:30','2026-02-04 16:20:30'),(592,117,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:35','2026-02-04 16:20:35','2026-02-04 16:20:35'),(593,78,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:36','2026-02-04 16:20:36','2026-02-04 16:20:36'),(594,100,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:40','2026-02-04 16:20:40','2026-02-04 16:20:40'),(595,135,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:41','2026-02-04 16:20:41','2026-02-04 16:20:41'),(596,127,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:43','2026-02-04 16:20:43','2026-02-04 16:20:43'),(597,145,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:45','2026-02-04 16:20:45','2026-02-04 16:20:45'),(598,132,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:20:46','2026-02-04 16:20:46','2026-02-04 16:20:46'),(602,146,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:20:56','2026-02-04 16:20:56','2026-02-04 16:20:56'),(603,146,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:20:57','2026-02-04 16:20:57','2026-02-04 16:20:57'),(604,146,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:20:58','2026-02-04 16:20:58','2026-02-04 16:20:58'),(605,146,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:21:00','2026-02-04 16:21:00','2026-02-04 16:21:00'),(607,146,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:21:02','2026-02-04 16:21:02','2026-02-04 16:21:02'),(608,95,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:21:07','2026-02-04 16:21:07','2026-02-04 16:21:07'),(609,125,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:21:08','2026-02-04 16:21:08','2026-02-04 16:21:08'),(610,92,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:21:09','2026-02-04 16:21:09','2026-02-04 16:21:09'),(611,94,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:21:11','2026-02-04 16:21:11','2026-02-04 16:21:11'),(612,93,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:21:12','2026-02-04 16:21:12','2026-02-04 16:21:12'),(613,144,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:21:29','2026-02-04 16:21:29','2026-02-04 16:21:29'),(614,148,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:21:30','2026-02-04 16:21:30','2026-02-04 16:21:30'),(615,142,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:21:31','2026-02-04 16:21:31','2026-02-04 16:21:31'),(616,247,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:21:32','2026-02-04 16:21:32','2026-02-04 16:21:32'),(617,149,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:21:33','2026-02-04 16:21:33','2026-02-04 16:21:33'),(618,143,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:21:34','2026-02-04 16:21:34','2026-02-04 16:21:34'),(625,1,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-02-04 11:23:45','2026-02-04 16:23:45','2026-02-04 16:23:45'),(629,1,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:23:55','2026-02-04 16:23:55','2026-02-04 16:23:55'),(630,38,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:23:56','2026-02-04 16:23:56','2026-02-04 16:23:56'),(631,38,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:23:57','2026-02-04 16:23:57','2026-02-04 16:23:57'),(632,1,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:23:58','2026-02-04 16:23:58','2026-02-04 16:23:58'),(633,38,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:23:59','2026-02-04 16:23:59','2026-02-04 16:23:59'),(634,1,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:24:00','2026-02-04 16:24:00','2026-02-04 16:24:00'),(635,38,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:24:02','2026-02-04 16:24:02','2026-02-04 16:24:02'),(636,1,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:24:03','2026-02-04 16:24:03','2026-02-04 16:24:03'),(637,38,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:24:06','2026-02-04 16:24:06','2026-02-04 16:24:06'),(638,1,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:24:07','2026-02-04 16:24:07','2026-02-04 16:24:07'),(640,110,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-04 11:26:12','2026-02-04 16:26:12','2026-02-04 16:26:12'),(641,110,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-02-04 11:26:16','2026-02-04 16:26:16','2026-02-04 16:26:16'),(642,110,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-02-04 11:26:18','2026-02-04 16:26:18','2026-02-04 16:26:18'),(643,110,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-02-04 11:26:19','2026-02-04 16:26:19','2026-02-04 16:26:19'),(644,110,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-02-04 11:26:20','2026-02-04 16:26:20','2026-02-04 16:26:20'),(645,110,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 11:26:22','2026-02-04 16:26:22','2026-02-04 16:26:22'),(647,57,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:42:29','2026-02-04 16:42:29','2026-02-04 16:42:29'),(648,53,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:42:30','2026-02-04 16:42:30','2026-02-04 16:42:30'),(649,53,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:42:32','2026-02-04 16:42:32','2026-02-04 16:42:32'),(650,57,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:42:33','2026-02-04 16:42:33','2026-02-04 16:42:33'),(651,57,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:42:34','2026-02-04 16:42:34','2026-02-04 16:42:34'),(652,53,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:42:35','2026-02-04 16:42:35','2026-02-04 16:42:35'),(653,19,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:42:37','2026-02-04 16:42:37','2026-02-04 16:42:37'),(654,12,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:42:38','2026-02-04 16:42:38','2026-02-04 16:42:38'),(655,12,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:42:39','2026-02-04 16:42:39','2026-02-04 16:42:39'),(656,19,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:42:41','2026-02-04 16:42:41','2026-02-04 16:42:41'),(657,19,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:42:42','2026-02-04 16:42:42','2026-02-04 16:42:42'),(658,12,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:42:43','2026-02-04 16:42:43','2026-02-04 16:42:43'),(659,91,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:42:45','2026-02-04 16:42:45','2026-02-04 16:42:45'),(660,17,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:42:46','2026-02-04 16:42:46','2026-02-04 16:42:46'),(661,17,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:42:47','2026-02-04 16:42:47','2026-02-04 16:42:47'),(662,91,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:42:48','2026-02-04 16:42:48','2026-02-04 16:42:48'),(663,91,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:42:49','2026-02-04 16:42:49','2026-02-04 16:42:49'),(664,17,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:42:50','2026-02-04 16:42:50','2026-02-04 16:42:50'),(665,41,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:42:53','2026-02-04 16:42:53','2026-02-04 16:42:53'),(666,77,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:42:54','2026-02-04 16:42:54','2026-02-04 16:42:54'),(667,41,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:42:57','2026-02-04 16:42:57','2026-02-04 16:42:57'),(668,77,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:42:57','2026-02-04 16:42:57','2026-02-04 16:42:57'),(669,41,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:42:59','2026-02-04 16:42:59','2026-02-04 16:42:59'),(670,77,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:43:00','2026-02-04 16:43:00','2026-02-04 16:43:00'),(671,20,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:43:01','2026-02-04 16:43:01','2026-02-04 16:43:01'),(672,14,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:43:02','2026-02-04 16:43:02','2026-02-04 16:43:02'),(673,20,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:43:03','2026-02-04 16:43:03','2026-02-04 16:43:03'),(674,14,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:43:04','2026-02-04 16:43:04','2026-02-04 16:43:04'),(675,20,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:43:05','2026-02-04 16:43:05','2026-02-04 16:43:05'),(676,14,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:43:06','2026-02-04 16:43:06','2026-02-04 16:43:06'),(677,67,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:43:07','2026-02-04 16:43:07','2026-02-04 16:43:07'),(678,30,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:43:08','2026-02-04 16:43:08','2026-02-04 16:43:08'),(679,67,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:43:09','2026-02-04 16:43:09','2026-02-04 16:43:09'),(680,30,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:43:10','2026-02-04 16:43:10','2026-02-04 16:43:10'),(681,67,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:43:11','2026-02-04 16:43:11','2026-02-04 16:43:11'),(682,30,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:43:12','2026-02-04 16:43:12','2026-02-04 16:43:12'),(683,130,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:43:13','2026-02-04 16:43:13','2026-02-04 16:43:13'),(684,65,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:43:15','2026-02-04 16:43:15','2026-02-04 16:43:15'),(685,65,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:43:16','2026-02-04 16:43:16','2026-02-04 16:43:16'),(686,130,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:43:17','2026-02-04 16:43:17','2026-02-04 16:43:17'),(687,130,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:43:18','2026-02-04 16:43:18','2026-02-04 16:43:18'),(688,65,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:43:19','2026-02-04 16:43:19','2026-02-04 16:43:19'),(689,126,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:08','2026-02-04 16:47:08','2026-02-04 16:47:08'),(690,114,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:09','2026-02-04 16:47:09','2026-02-04 16:47:09'),(691,59,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:11','2026-02-04 16:47:11','2026-02-04 16:47:11'),(692,50,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:12','2026-02-04 16:47:12','2026-02-04 16:47:12'),(693,31,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:15','2026-02-04 16:47:15','2026-02-04 16:47:15'),(694,76,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:16','2026-02-04 16:47:16','2026-02-04 16:47:16'),(695,131,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:21','2026-02-04 16:47:21','2026-02-04 16:47:21'),(696,123,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:22','2026-02-04 16:47:22','2026-02-04 16:47:22'),(697,62,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:23','2026-02-04 16:47:23','2026-02-04 16:47:23'),(698,22,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:24','2026-02-04 16:47:24','2026-02-04 16:47:24'),(699,8,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:32','2026-02-04 16:47:32','2026-02-04 16:47:32'),(700,99,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:33','2026-02-04 16:47:33','2026-02-04 16:47:33'),(701,13,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:34','2026-02-04 16:47:34','2026-02-04 16:47:34'),(702,36,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:35','2026-02-04 16:47:35','2026-02-04 16:47:35'),(703,7,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:36','2026-02-04 16:47:36','2026-02-04 16:47:36'),(704,129,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:37','2026-02-04 16:47:37','2026-02-04 16:47:37'),(705,45,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:39','2026-02-04 16:47:39','2026-02-04 16:47:39'),(706,115,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:40','2026-02-04 16:47:40','2026-02-04 16:47:40'),(707,134,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:41','2026-02-04 16:47:41','2026-02-04 16:47:41'),(708,46,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:42','2026-02-04 16:47:42','2026-02-04 16:47:42'),(709,133,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:43','2026-02-04 16:47:43','2026-02-04 16:47:43'),(710,80,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:44','2026-02-04 16:47:44','2026-02-04 16:47:44'),(711,60,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:45','2026-02-04 16:47:45','2026-02-04 16:47:45'),(712,79,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:47:46','2026-02-04 16:47:46','2026-02-04 16:47:46'),(713,110,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-04 11:48:18','2026-02-04 16:48:18','2026-02-04 16:48:18'),(714,110,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-04 11:48:19','2026-02-04 16:48:19','2026-02-04 16:48:19'),(715,110,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:48:20','2026-02-04 16:48:20','2026-02-04 16:48:20'),(716,38,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:48:25','2026-02-04 16:48:25','2026-02-04 16:48:25'),(717,1,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-04 11:48:26','2026-02-04 16:48:26','2026-02-04 16:48:26'),(718,248,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 19:36:29','2026-02-05 00:36:29','2026-02-05 00:36:29'),(719,249,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-02-04 19:36:34','2026-02-05 00:36:34','2026-02-05 00:36:34'),(720,251,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-02-11 11:39:32','2026-02-11 16:39:32','2026-02-11 16:39:32'),(721,251,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-11 11:39:32','2026-02-11 16:39:32','2026-02-11 16:39:32'),(722,37,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-15 10:28:00','2026-02-15 15:28:00','2026-02-15 15:28:00'),(723,86,'INFO_MANAGEMENT','INFO_LIST',111,'2026-02-15 10:28:00','2026-02-15 15:28:00','2026-02-15 15:28:00'),(724,37,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-15 10:28:03','2026-02-15 15:28:03','2026-02-15 15:28:03'),(725,86,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-02-15 10:28:03','2026-02-15 15:28:03','2026-02-15 15:28:03'),(726,86,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-15 10:28:04','2026-02-15 15:28:04','2026-02-15 15:28:04'),(727,37,'INFO_MANAGEMENT','AV_COURSES',111,'2026-02-15 10:28:04','2026-02-15 15:28:04','2026-02-15 15:28:04'),(730,249,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-02-21 03:42:49','2026-02-21 08:42:49','2026-02-21 08:42:49'),(731,253,'COURSE_ASSESSMENTS','MY_COURSE_ASSESSMENTS',111,'2026-03-12 14:34:58','2026-03-12 18:34:58','2026-03-12 18:34:58'),(732,253,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-03-12 14:35:00','2026-03-12 18:35:00','2026-03-12 18:35:00'),(733,253,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-03-12 14:35:02','2026-03-12 18:35:02','2026-03-12 18:35:02'),(734,253,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-03-12 14:35:04','2026-03-12 18:35:04','2026-03-12 18:35:04'),(735,253,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-03-12 14:35:08','2026-03-12 18:35:08','2026-03-12 18:35:08'),(736,253,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-03-12 14:35:09','2026-03-12 18:35:09','2026-03-12 18:35:09'),(737,253,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-03-12 14:35:10','2026-03-12 18:35:10','2026-03-12 18:35:10'),(738,253,'INFO_MANAGEMENT','AV_COURSES',111,'2026-03-12 14:35:14','2026-03-12 18:35:14','2026-03-12 18:35:14'),(739,131,'INFO_MANAGEMENT','FACULTY_WORKLOADS',111,'2026-03-20 15:14:36','2026-03-20 19:14:36','2026-03-20 19:14:36'),(740,147,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-03-21 20:18:07','2026-03-22 00:18:07','2026-03-22 00:18:07'),(741,147,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-03-21 20:18:07','2026-03-22 00:18:07','2026-03-22 00:18:07'),(742,147,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-03-21 20:18:08','2026-03-22 00:18:08','2026-03-22 00:18:08'),(743,147,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-03-21 20:18:12','2026-03-22 00:18:12','2026-03-22 00:18:12'),(744,147,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-03-21 20:18:29','2026-03-22 00:18:29','2026-03-22 00:18:29'),(745,97,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-03-21 20:18:34','2026-03-22 00:18:34','2026-03-22 00:18:34'),(746,97,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-03-21 20:18:36','2026-03-22 00:18:36','2026-03-22 00:18:36'),(747,97,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-03-21 20:18:37','2026-03-22 00:18:37','2026-03-22 00:18:37'),(748,97,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-03-21 20:18:37','2026-03-22 00:18:37','2026-03-22 00:18:37'),(749,97,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-03-21 20:18:39','2026-03-22 00:18:39','2026-03-22 00:18:39'),(750,97,'INFO_MANAGEMENT','AV_COURSES',111,'2026-03-21 20:18:44','2026-03-22 00:18:44','2026-03-22 00:18:44'),(751,147,'INFO_MANAGEMENT','AV_COURSES',111,'2026-03-21 20:18:46','2026-03-22 00:18:46','2026-03-22 00:18:46'),(754,76,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-06-09 23:26:14','2026-06-09 23:26:14','2026-06-09 23:26:14'),(755,76,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-06-09 23:26:28','2026-06-09 23:26:28','2026-06-09 23:26:28'),(756,147,'COURSE_ASSESSMENTS','ASSESSMENTS_FOR_DIRECTORS',111,'2026-07-23 16:11:47','2026-07-23 16:11:47','2026-07-23 16:11:47'),(757,147,'COURSE_ASSESSMENTS','ASSISTANT_MENUS',111,'2026-07-23 16:11:49','2026-07-23 16:11:49','2026-07-23 16:11:49'),(758,147,'ABET_ASSESSMENTS','ABET_ASSESSMENTS_GROUP',111,'2026-07-23 16:11:53','2026-07-23 16:11:53','2026-07-23 16:11:53'),(761,281,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-08-16 14:11:38','2026-08-16 14:11:38','2026-08-16 14:11:38'),(762,281,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-08-16 14:11:39','2026-08-16 14:11:39','2026-08-16 14:11:39'),(763,281,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-08-16 14:11:41','2026-08-16 14:11:41','2026-08-16 14:11:41'),(764,281,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-08-16 14:11:42','2026-08-16 14:11:42','2026-08-16 14:11:42'),(765,281,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-08-16 14:11:43','2026-08-16 14:11:43','2026-08-16 14:11:43'),(766,281,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-08-16 14:11:44','2026-08-16 14:11:44','2026-08-16 14:11:44'),(767,282,'COURSE_ASSESSMENTS','REFERENCE_MATERIALS',111,'2026-08-16 14:55:35','2026-08-16 14:55:35','2026-08-16 14:55:35'),(768,282,'ASSESSMENTS_SUMMARY','ASSESSMENT_ASSIGNMENTS',111,'2026-08-16 14:55:37','2026-08-16 14:55:37','2026-08-16 14:55:37'),(769,282,'ASSESSMENTS_SUMMARY','EVALUATION_SO_PI',111,'2026-08-16 14:55:37','2026-08-16 14:55:37','2026-08-16 14:55:37'),(770,282,'ABET_ASSESSMENTS','SO_PI_MAPPINGS',111,'2026-08-16 14:55:39','2026-08-16 14:55:39','2026-08-16 14:55:39'),(771,282,'ASSESSMENTS_SUMMARY','COURSE_LEVEL_EVALUATION',111,'2026-08-16 14:55:39','2026-08-16 14:55:39','2026-08-16 14:55:39'),(772,282,'ABET_ASSESSMENTS','SYLLABUS',111,'2026-08-16 14:55:40','2026-08-16 14:55:40','2026-08-16 14:55:40');
/*!40000 ALTER TABLE `UserMenuPermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log` (
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `msg` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'atlas_db'
--
/*!50003 DROP FUNCTION IF EXISTS `FUNC_GetCourseLevel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  FUNCTION `FUNC_GetCourseLevel`(IN_Level INT) RETURNS varchar(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci
    DETERMINISTIC
BEGIN

	DECLARE lvl VARCHAR(20);

    IF (IN_Level = 1) THEN
        SET lvl = 'Introductory';
    ELSEIF (IN_Level = 2) THEN
        SET lvl = 'Practice';
    ELSEIF (IN_Level = 3) THEN
        SET lvl = 'Mastery';
    ELSE
        SET lvl = '';
    END IF;

RETURN (lvl);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_ChangeAcademicYears` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_ChangeAcademicYears`(
    IN p_SyllabysIndex INT,
    IN p_FromAcademicYears INT
)
BEGIN

    DECLARE previous_AcademicYearIdx INT;

    # find a previous academic year based on the current academic year information
    SELECT prev.Idx INTO previous_AcademicYearIdx
    FROM AcademicYears AS curr
             JOIN AcademicYears AS prev
                  ON prev.From < curr.From
    WHERE curr.Idx = p_FromAcademicYears
    ORDER BY prev.From DESC
        LIMIT 1;

    UPDATE `AbetSyllabus`
    SET `AcademicYearTo`=previous_AcademicYearIdx
    WHERE `Idx`=p_SyllabysIndex;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_Edit_FetchInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_Edit_FetchInfo`(
    IN p_CourseIndex INT,
    IN p_SyllabusIndex INT,
    IN p_AcademicProgramIndex INT
)
BEGIN
    WITH MainInfo AS (
        SELECT
            a.`Idx`,
            a.`major_version`,
            a.`minor_version`,
            a.`AcademicYearFrom`,
            a.`AcademicYearTo`,
            a.`Description`,
            a.`Credits`,
            a.`Requirement`,
            a.`Pre_requisites`,
            a.`Co_requisites`,
            a.`Required_Texts`,
            a.`Reference_Texts`,
            a.`Coordinator`,
            a.`ObjectivesHeadline`,
            a.`Objectives`,
            a.`TopicsCoveredHeadline`,
            a.`TopicsCovered`,
            a.`RevisionDesc`,
            a.`RevisionDate`,
            a.`ApprovalDesc`,
            a.`ApprovalDate`,
            a.`LinkedSyllabus` as LinkedTo,
            CASE
                WHEN a.major_version = (
                    SELECT b.major_version
                    FROM `AbetSyllabus` b
                    WHERE b.`CourseIndex` = a.`CourseIndex`
                      AND b.`AcademicProgram` = p_AcademicProgramIndex
                    ORDER BY b.major_version DESC, b.minor_version DESC
                    LIMIT 1
                )
                AND a.minor_version = (
                    SELECT c.minor_version
                    FROM `AbetSyllabus` c
                    WHERE c.`CourseIndex` = a.`CourseIndex`
                      AND c.`AcademicProgram` = p_AcademicProgramIndex
                      AND c.major_version = a.major_version
                    ORDER BY c.minor_version DESC
                    LIMIT 1
                )
                THEN 1
                ELSE 0
            END as is_latest_version,
            (SELECT COUNT(*)
             FROM `AbetSyllabus` linking
             WHERE linking.`LinkedSyllabus` = a.`Idx`) as LinkedByCount
        FROM `AbetSyllabus` a
        WHERE a.`Idx` = p_SyllabusIndex
            AND a.`AcademicProgram` = p_AcademicProgramIndex
    )
    SELECT
        m.*,
        -- Linked syllabus information
        ref.`major_version` as linked_course_major_version,
        ref.`minor_version` as linked_course_minor_version,
        ref.`AcademicYearFrom` as linked_course_AcademicYearFrom,
        ref.`AcademicYearTo` as linked_course_AcademicYearTo,
        CONCAT(crses.`Subject`, ' ', crses.`Num`, ' ', crses.`Title`)  as linked_course_Course,
        aps.`Name` as linked_course_AcademicProgramName,
        aps.`Degree` as linked_course_AcademicProgramDegree
    FROM MainInfo m
    LEFT JOIN `AbetSyllabus` ref ON ref.`Idx` = m.`LinkedTo`
    LEFT JOIN `Courses` crses ON crses.`Idx` = ref.`CourseIndex`
    LEFT JOIN `AcademicPrograms` aps ON aps.`Idx` = ref.`AcademicProgram`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_Edit_Save` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_Edit_Save`(
    IN p_syllabus_index INT,
    IN p_major_version INT,
    IN p_minor_version INT,
    IN p_FromAcademicYears INT,
    IN p_ToAcademicYears INT,
    IN p_Subject VARCHAR(255),
    IN p_Num VARCHAR(255),
    IN p_Description TEXT,
    IN p_Credits TEXT,
    IN p_Requirement TEXT,
    IN p_Pre_requisites TEXT,
    IN p_Co_requisites TEXT,
    IN p_Required_Texts TEXT,
    IN p_Reference_Texts TEXT,
    IN p_Coordinator TEXT,
    IN p_ObjectivesHeadline TEXT,
    IN p_Objectives TEXT,
    IN p_TopicsCoveredHeadline TEXT,
    IN p_TopicsCovered TEXT,
    IN p_RevisionDesc TEXT,
    IN p_RevisionDate TEXT,
    IN p_ApprovalDesc TEXT,
    IN p_ApprovalDate TEXT
)
BEGIN

    -- Declare variables
    DECLARE v_old_FromAcademicYears INT;
    DECLARE v_old_ToAcademicYears INT;
    DECLARE v_CourseIndex INT;
    DECLARE v_AcademicProgram INT;
    DECLARE v_previous_AcademicYearTo INT;

    -- Declare handlers
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- GET OLD ACADEMIC YEAR VALUES AND COURSE INFO
    SELECT `AcademicYearFrom`, `AcademicYearTo`, `CourseIndex`, `AcademicProgram`
    INTO v_old_FromAcademicYears, v_old_ToAcademicYears, v_CourseIndex, v_AcademicProgram
    FROM `AbetSyllabus`
    WHERE `Idx` = p_syllabus_index;

    -- ALWAYS UPDATE PREVIOUS VERSION'S AcademicYearTo
    -- Calculate what the previous version's AcademicYearTo should be
    -- It should be the academic year immediately before the new AcademicYearFrom
    SELECT `Idx`
    INTO v_previous_AcademicYearTo
    FROM `AcademicYears`
    WHERE `Idx` < p_FromAcademicYears
    ORDER BY `Idx` DESC
    LIMIT 1;

    -- Update the previous version's AcademicYearTo if it exists
    -- Find the previous version by checking same CourseIndex, AcademicProgram, and lower version
    IF v_previous_AcademicYearTo IS NOT NULL THEN
        UPDATE `AbetSyllabus`
        SET `AcademicYearTo` = v_previous_AcademicYearTo
        WHERE `CourseIndex` = v_CourseIndex
          AND `AcademicProgram` = v_AcademicProgram
          AND `Idx` <> p_syllabus_index
          AND (
              `major_version` < p_major_version
              OR (`major_version` = p_major_version AND `minor_version` < p_minor_version)
          )
        ORDER BY `major_version` DESC, `minor_version` DESC
        LIMIT 1;
    END IF;

    -- UPDATE MAIN MASTER SYLLABUS FIRST
    UPDATE `AbetSyllabus`
    SET `major_version`=p_major_version,
        `minor_version`=p_minor_version,
        `AcademicYearFrom`=p_FromAcademicYears,
        `AcademicYearTo`=p_ToAcademicYears,
        `Description`=p_Description,
        `Credits`=p_Credits,
        `Requirement`=p_Requirement,
        `Pre_requisites`=p_Pre_requisites,
        `Co_requisites`=p_Co_requisites,
        `Required_Texts`=p_Required_Texts,
        `Reference_Texts`=p_Reference_Texts,
        `Coordinator`=p_Coordinator,
        `ObjectivesHeadline`=p_ObjectivesHeadline,
        `Objectives`=p_Objectives,
        `TopicsCoveredHeadline`=p_TopicsCoveredHeadline,
        `TopicsCovered`=p_TopicsCovered,
        `RevisionDesc`=p_RevisionDesc,
        `RevisionDate`=p_RevisionDate,
        `ApprovalDesc`=p_ApprovalDesc,
        `ApprovalDate`=p_ApprovalDate
    WHERE `Idx`=p_syllabus_index;

    -- Clear AbetSyllabus reference for master course that are outside the new range
    UPDATE `CourseMapping_Courses` cmc
    INNER JOIN `AcademicYears` ay ON cmc.`AcademicYear` = ay.`Idx`
    SET cmc.`AbetSyllabus` = NULL
    WHERE cmc.`AbetSyllabus` = p_syllabus_index
      AND cmc.`CourseIdx` = v_CourseIndex
      AND cmc.`AcademicProgram` = v_AcademicProgram
      AND (ay.`Idx` < p_FromAcademicYears OR
           (p_ToAcademicYears IS NOT NULL AND ay.`Idx` > p_ToAcademicYears));

    -- Set AbetSyllabus reference for master course in the new range
    UPDATE `CourseMapping_Courses` cmc
    INNER JOIN `AcademicYears` ay ON cmc.`AcademicYear` = ay.`Idx`
    SET cmc.`AbetSyllabus` = p_syllabus_index
    WHERE cmc.`CourseIdx` = v_CourseIndex
      AND cmc.`AcademicProgram` = v_AcademicProgram
      AND (cmc.`AbetSyllabus` IS NULL OR cmc.`AbetSyllabus` = p_syllabus_index)
      AND ay.`Idx` >= p_FromAcademicYears
      AND (p_ToAcademicYears IS NULL OR ay.`Idx` <= p_ToAcademicYears);

    -- UPDATE ALL LINKED SYLLABUS CONTENT
    UPDATE `AbetSyllabus`
    SET `major_version`=p_major_version,
        `minor_version`=p_minor_version,
        `AcademicYearFrom`=p_FromAcademicYears,
        `AcademicYearTo`=p_ToAcademicYears,
        `Description`=p_Description,
        `Credits`=p_Credits,
        `Requirement`=p_Requirement,
        `Pre_requisites`=p_Pre_requisites,
        `Co_requisites`=p_Co_requisites,
        `Required_Texts`=p_Required_Texts,
        `Reference_Texts`=p_Reference_Texts,
        `Coordinator`=p_Coordinator,
        `ObjectivesHeadline`=p_ObjectivesHeadline,
        `Objectives`=p_Objectives,
        `TopicsCoveredHeadline`=p_TopicsCoveredHeadline,
        `TopicsCovered`=p_TopicsCovered,
        `RevisionDesc`=p_RevisionDesc,
        `RevisionDate`=p_RevisionDate,
        `ApprovalDesc`=p_ApprovalDesc,
        `ApprovalDate`=p_ApprovalDate
    WHERE `LinkedSyllabus` = p_syllabus_index;

    -- Clear AbetSyllabus reference for LINKED courses that are outside the new range
    UPDATE `CourseMapping_Courses` cmc
    INNER JOIN `AcademicYears` ay ON cmc.`AcademicYear` = ay.`Idx`
    INNER JOIN `AbetSyllabus` abs ON cmc.`AbetSyllabus` = abs.`Idx`
    SET cmc.`AbetSyllabus` = NULL
    WHERE abs.`LinkedSyllabus` = p_syllabus_index
      AND cmc.`CourseIdx` = abs.`CourseIndex`
      AND cmc.`AcademicProgram` = abs.`AcademicProgram`
      AND (ay.`Idx` < p_FromAcademicYears OR
           (p_ToAcademicYears IS NOT NULL AND ay.`Idx` > p_ToAcademicYears));

    -- Set AbetSyllabus reference for LINKED courses in the new range
    UPDATE `CourseMapping_Courses` cmc
    INNER JOIN `AcademicYears` ay ON cmc.`AcademicYear` = ay.`Idx`
    INNER JOIN `AbetSyllabus` abs ON abs.`LinkedSyllabus` = p_syllabus_index
    SET cmc.`AbetSyllabus` = abs.`Idx`
    WHERE cmc.`CourseIdx` = abs.`CourseIndex`
      AND cmc.`AcademicProgram` = abs.`AcademicProgram`
      AND (cmc.`AbetSyllabus` IS NULL OR cmc.`AbetSyllabus` = abs.`Idx`)
      AND ay.`Idx` >= p_FromAcademicYears
      AND (p_ToAcademicYears IS NULL OR ay.`Idx` <= p_ToAcademicYears);

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_Edit_Update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_Edit_Update`(
    IN p_syllabus_index INT,
    IN p_major_version INT,
    IN p_minor_version INT,
    IN p_FromAcademicYears INT,
    IN p_ToAcademicYears INT,
    IN p_Subject VARCHAR(255),
    IN p_Num VARCHAR(255),
    IN p_Description TEXT,
    IN p_Credits TEXT,
    IN p_Requirement TEXT,
    IN p_Pre_requisites TEXT,
    IN p_Co_requisites TEXT,
    IN p_Required_Texts TEXT,
    IN p_Reference_Texts TEXT,
    IN p_Coordinator TEXT,
    IN p_ObjectivesHeadline TEXT,
    IN p_Objectives TEXT,
    IN p_TopicsCoveredHeadline TEXT,
    IN p_TopicsCovered TEXT,
    IN p_RevisionDesc TEXT,
    IN p_RevisionDate TEXT,
    IN p_ApprovalDesc TEXT,
    IN p_ApprovalDate TEXT
)
BEGIN

    -- Declare variables
    DECLARE v_done BOOLEAN DEFAULT FALSE;
    DECLARE v_LinkedABETSyllabusIdx INT;
    DECLARE v_old_FromAcademicYears INT;
    DECLARE v_old_ToAcademicYears INT;
    DECLARE v_CourseIndex INT;
    DECLARE v_AcademicProgram INT;
    DECLARE v_previous_AcademicYearTo INT;

    -- Declare cursor for linked syllabus
    DECLARE cursor_linked_syllabus CURSOR FOR
        SELECT `Idx`
        FROM `AbetSyllabus`
        WHERE `LinkedSyllabus` = p_syllabus_index;

    -- Declare handlers
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- GET OLD ACADEMIC YEAR VALUES AND COURSE INFO
    SELECT `AcademicYearFrom`, `AcademicYearTo`, `CourseIndex`, `AcademicProgram`
    INTO v_old_FromAcademicYears, v_old_ToAcademicYears, v_CourseIndex, v_AcademicProgram
    FROM `AbetSyllabus`
    WHERE `Idx` = p_syllabus_index;

    -- ALWAYS UPDATE PREVIOUS VERSION'S AcademicYearTo
    -- Calculate what the previous version's AcademicYearTo should be
    -- It should be the academic year immediately before the new AcademicYearFrom
    SELECT `Idx`
    INTO v_previous_AcademicYearTo
    FROM `AcademicYears`
    WHERE `Idx` < p_FromAcademicYears
    ORDER BY `Idx` DESC
    LIMIT 1;

    -- Update the previous version's AcademicYearTo if it exists
    -- Find the previous version by checking same CourseIndex, AcademicProgram, and lower version
    IF v_previous_AcademicYearTo IS NOT NULL THEN
        UPDATE `AbetSyllabus`
        SET `AcademicYearTo` = v_previous_AcademicYearTo
        WHERE `CourseIndex` = v_CourseIndex
          AND `AcademicProgram` = v_AcademicProgram
          AND `Idx` <> p_syllabus_index
          AND (
              `major_version` < p_major_version
              OR (`major_version` = p_major_version AND `minor_version` < p_minor_version)
          )
        ORDER BY `major_version` DESC, `minor_version` DESC
        LIMIT 1;
    END IF;

    -- UPDATE MAIN MASTER SYLLABUS FIRST
    UPDATE `AbetSyllabus`
    SET `major_version`=p_major_version,
        `minor_version`=p_minor_version,
        `AcademicYearFrom`=p_FromAcademicYears,
        `AcademicYearTo`=p_ToAcademicYears,
        `Description`=p_Description,
        `Credits`=p_Credits,
        `Requirement`=p_Requirement,
        `Pre_requisites`=p_Pre_requisites,
        `Co_requisites`=p_Co_requisites,
        `Required_Texts`=p_Required_Texts,
        `Reference_Texts`=p_Reference_Texts,
        `Coordinator`=p_Coordinator,
        `ObjectivesHeadline`=p_ObjectivesHeadline,
        `Objectives`=p_Objectives,
        `TopicsCoveredHeadline`=p_TopicsCoveredHeadline,
        `TopicsCovered`=p_TopicsCovered,
        `RevisionDesc`=p_RevisionDesc,
        `RevisionDate`=p_RevisionDate,
        `ApprovalDesc`=p_ApprovalDesc,
        `ApprovalDate`=p_ApprovalDate
    WHERE `Idx`=p_syllabus_index;

    -- Clear AbetSyllabus reference for courses that are outside the new range
    UPDATE `CourseMapping_Courses` cmc
    INNER JOIN `AcademicYears` ay ON cmc.`AcademicYear` = ay.`Idx`
    SET cmc.`AbetSyllabus` = NULL
    WHERE cmc.`AbetSyllabus` = p_syllabus_index
      AND cmc.`CourseIdx` = v_CourseIndex
      AND cmc.`AcademicProgram` = v_AcademicProgram
      AND (ay.`Idx` < p_FromAcademicYears OR
           (p_ToAcademicYears IS NOT NULL AND ay.`Idx` > p_ToAcademicYears));

    -- Set AbetSyllabus reference for courses in the new range
    UPDATE `CourseMapping_Courses` cmc
    INNER JOIN `AcademicYears` ay ON cmc.`AcademicYear` = ay.`Idx`
    SET cmc.`AbetSyllabus` = p_syllabus_index
    WHERE cmc.`CourseIdx` = v_CourseIndex
      AND cmc.`AcademicProgram` = v_AcademicProgram
      AND (cmc.`AbetSyllabus` IS NULL OR cmc.`AbetSyllabus` = p_syllabus_index)
      AND ay.`Idx` >= p_FromAcademicYears
      AND (p_ToAcademicYears IS NULL OR ay.`Idx` <= p_ToAcademicYears);


    -- UPDATE ALL LINKED SYLLABUS
    OPEN cursor_linked_syllabus;

    read_loop: LOOP
        FETCH cursor_linked_syllabus INTO v_LinkedABETSyllabusIdx;

        IF v_done THEN
            LEAVE read_loop;
        END IF;

        IF v_LinkedABETSyllabusIdx IS NOT NULL THEN
            UPDATE `AbetSyllabus`
            SET `Description`=p_Description,
                `Credits`=p_Credits,
                `Requirement`=p_Requirement,
                `Pre_requisites`=p_Pre_requisites,
                `Co_requisites`=p_Co_requisites,
                `Required_Texts`=p_Required_Texts,
                `Reference_Texts`=p_Reference_Texts,
                `Coordinator`=p_Coordinator,
                `ObjectivesHeadline`=p_ObjectivesHeadline,
                `Objectives`=p_Objectives,
                `TopicsCoveredHeadline`=p_TopicsCoveredHeadline,
                `TopicsCovered`=p_TopicsCovered,
                `RevisionDesc`=p_RevisionDesc,
                `RevisionDate`=p_RevisionDate,
                `ApprovalDesc`=p_ApprovalDesc,
                `ApprovalDate`=p_ApprovalDate
            WHERE `Idx`=v_LinkedABETSyllabusIdx;
        END IF;
    END LOOP;

    CLOSE cursor_linked_syllabus;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_FetchDiffInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_FetchDiffInfo`(
    IN p_CurrentAbetSyllabusIndex INT,
    IN p_TargetAbetSyllabusIndex INT
)
BEGIN

SELECT
    CONCAT(a.major_version, '.', a.minor_version) AS Version_1,
    CONCAT(b.major_version, '.', b.minor_version) AS Version_2,
    ayf1.AcademicYear AS AcademicYearFrom_1, ayf2.AcademicYear AS AcademicYearFrom_2,
    ayt1.AcademicYear AS AcademicYearTo_1, ayt2.AcademicYear AS AcademicYearTo_2,
    a.Description AS Description_1, b.Description AS Description_2,
    a.Credits AS Credits_1, b.Credits AS Credits_2,
    a.Requirement AS Requirement_1, b.Requirement AS Requirement_2,
    a.Pre_requisites AS Pre_requisites_1, b.Pre_requisites AS Pre_requisites_2,
    a.Co_requisites AS Co_requisites_1, b.Co_requisites AS Co_requisites_2,
    a.Required_Texts AS Required_Texts_1, b.Required_Texts AS Required_Texts_2,
    a.Reference_Texts AS Reference_Texts_1, b.Reference_Texts AS Reference_Texts_2,
    a.Coordinator AS Coordinator_1, b.Coordinator AS Coordinator_2,
    a.ObjectivesHeadline AS ObjectivesHeadline_1, b.ObjectivesHeadline AS ObjectivesHeadline_2,
    a.Objectives AS Objectives_1, b.Objectives AS Objectives_2,
    a.TopicsCoveredHeadline AS TopicsCoveredHeadline_1, b.TopicsCoveredHeadline AS TopicsCoveredHeadline_2,
    a.TopicsCovered AS TopicsCovered_1, b.TopicsCovered AS TopicsCovered_2,
    a.RevisionDesc AS RevisionDesc_1, b.RevisionDesc AS RevisionDesc_2,
    a.RevisionDate AS RevisionDate_1, b.RevisionDate AS RevisionDate_2,
    a.ApprovalDesc AS ApprovalDesc_1, b.ApprovalDesc AS ApprovalDesc_2,
    a.ApprovalDate AS ApprovalDate_1, b.ApprovalDate AS ApprovalDate_2
FROM AbetSyllabus a
         INNER JOIN AbetSyllabus b ON a.Idx = p_CurrentAbetSyllabusIndex AND b.Idx = p_TargetAbetSyllabusIndex
         LEFT JOIN AcademicYears ayf1 ON a.AcademicYearFrom = ayf1.Idx
         LEFT JOIN AcademicYears ayf2 ON b.AcademicYearFrom = ayf2.Idx
         LEFT JOIN AcademicYears ayt1 ON a.AcademicYearTo = ayt1.Idx
         LEFT JOIN AcademicYears ayt2 ON b.AcademicYearTo = ayt2.Idx
    LIMIT 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_FetchInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_FetchInfo`(
    IN p_AbetSyllabusIndex INT
)
BEGIN

    SELECT
        `CRSES`.`Subject`, `CRSES`.`Num`, `CRSES`.`Title`, `CRSES`.`Credits`,
        `ABETSYLBUS`.`CourseIndex`,
        `ABETSYLBUS`.`major_version`, `ABETSYLBUS`.`minor_version`,
        `AYRS1`.`AcademicYear` AS `AcademicYearFrom`,
        `AYRS2`.`AcademicYear` AS `AcademicYearTo`,
        `ABETSYLBUS`.`Description`, `ABETSYLBUS`.`Credits`, `ABETSYLBUS`.`Requirement`,
        `ABETSYLBUS`.`Pre_requisites`, `ABETSYLBUS`.`Co_requisites`,
        `ABETSYLBUS`.`Required_Texts`, `ABETSYLBUS`.`Reference_Texts`,
        `ABETSYLBUS`.`Coordinator`,
        `ABETSYLBUS`.`ObjectivesHeadline`, `ABETSYLBUS`.`Objectives`,
        `ABETSYLBUS`.`TopicsCoveredHeadline`, `ABETSYLBUS`.`TopicsCovered`,
        `ABETSYLBUS`.`RevisionDesc`,
        `ABETSYLBUS`.`ApprovalDesc`, `ABETSYLBUS`.`ApprovalDate`,
        `APS`.`Name`, `APS`.`Degree`
    FROM `AbetSyllabus` AS `ABETSYLBUS`
            LEFT JOIN `Courses` AS `CRSES` ON (`ABETSYLBUS`.`CourseIndex` = `CRSES`.`Idx`)
            LEFT JOIN `AcademicYears` AS `AYRS1` ON (`ABETSYLBUS`.`AcademicYearFrom` = `AYRS1`.`Idx`)
            LEFT JOIN `AcademicYears` AS `AYRS2` ON (`ABETSYLBUS`.`AcademicYearTo` = `AYRS2`.`Idx`)
            LEFT JOIN `AcademicPrograms` AS `APS` ON (`ABETSYLBUS`.`AcademicProgram` = `APS`.`Idx`)
    WHERE `ABETSYLBUS`.`Idx` = p_AbetSyllabusIndex;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_FetchPIs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_FetchPIs`(
    IN p_CourseIndex INT,
    IN p_SyllabusIndex INT,
    IN p_AcademicYearFromIdx INT,
    IN p_AcademicYearToIdx INT,
    IN p_AcademicProgramIdx INT
)
BEGIN

    IF p_AcademicYearToIdx IS NOT NULL THEN
        BEGIN

            IF p_AcademicYearFromIdx = p_AcademicYearToIdx THEN
--                ex, 2020-2021 ~ 2020-2021

                BEGIN
                    SELECT DISTINCT `SO`.`SO`, `PI`.`GPI`, `PI`.`Description`, `PI`.`Comments`, `PI`.`Approval`
                    FROM `GeneralPerformanceIndicators` AS `PI`
                             INNER JOIN `StudentOutcomes` AS `SO` ON (`SO`.`Idx`=`PI`.`SOIdx`)
                             INNER JOIN `CourseMapping_GPIs` AS `CM_PIS` ON (`PI`.`Idx`=`CM_PIS`.`GPIIdx`)
                             INNER JOIN `CourseMapping_Courses` AS `CM_CRSES` ON (`CM_CRSES`.`Idx`=`CM_PIS`.`AbetCourseIdx`)
                             INNER JOIN `Courses` AS `CRSES` ON (`CM_CRSES`.`CourseIdx`=`CRSES`.`Idx` AND `CRSES`.`Idx`=p_CourseIndex)
                             LEFT JOIN `AcademicYears` AS `AYS` ON (`AYS`.`Idx`=`CM_PIS`.`AcademicYear`)
                    WHERE `AYS`.`Idx` = p_AcademicYearFromIdx
                      AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
                    ORDER BY `SO`.`SO`, `PI`.`GPI`;
                END;
            ELSE
                BEGIN

--                ex, 2020-2021 ~ 2023-2024

                    SELECT DISTINCT `SO`.`SO`, `PI`.`GPI`, `PI`.`Description`, `PI`.`Comments`, `PI`.`Approval`
                    FROM `GeneralPerformanceIndicators` AS `PI`
                             INNER JOIN `StudentOutcomes` AS `SO` ON (`SO`.`Idx`=`PI`.`SOIdx`)
                             INNER JOIN `CourseMapping_GPIs` AS `CM_PIS` ON (`PI`.`Idx`=`CM_PIS`.`GPIIdx`)
                             INNER JOIN `CourseMapping_Courses` AS `CM_CRSES` ON (`CM_CRSES`.`Idx`=`CM_PIS`.`AbetCourseIdx`)
                             INNER JOIN `Courses` AS `CRSES` ON (`CM_CRSES`.`CourseIdx`=`CRSES`.`Idx` AND `CRSES`.`Idx`=p_CourseIndex)
                             LEFT JOIN `AcademicYears` AS `AYS` ON (`AYS`.`Idx`=`CM_PIS`.`AcademicYear`)
                    WHERE `AYS`.`Idx` = (
                        SELECT `AYEARS`.`Idx`
                        FROM AcademicYears `AYEARS`
                                 JOIN `AbetSyllabus` `ABS` ON (`AYEARS`.`Idx` >= p_AcademicYearFromIdx AND `AYEARS`.`Idx` <= p_AcademicYearToIdx)
                                 JOIN `CourseMapping_Courses` `CMCRSES` ON (`AYEARS`.Idx = `CMCRSES`.AcademicYear)
                                 INNER JOIN `CourseMapping_GPIs` AS `CM_PIS` ON (`CM_PIS`.`AbetCourseIdx`=`CMCRSES`.`Idx`)
                                 INNER JOIN `Courses` `crses` ON (`CMCRSES`.`CourseIdx` = `crses`.Idx)
                        WHERE `ABS`.Idx = p_SyllabusIndex
                          AND `crses`.`Idx`=p_CourseIndex
                          AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
                        ORDER BY `AYEARS`.`From` DESC LIMIT 1
                        )
                      AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
                    ORDER BY `SO`.`SO`, `PI`.`GPI`;

                END;
            END IF;
        END;
    ELSE
        BEGIN

            IF p_AcademicYearFromIdx IS NULL THEN
                SELECT `AcademicYearFrom` INTO p_AcademicYearFromIdx FROM `AbetSyllabus` t1
                WHERE CourseIndex = p_CourseIndex
                  AND AcademicProgram = p_AcademicProgramIdx
                  AND (major_version, minor_version) = (
                    SELECT major_version, minor_version
                    FROM `AbetSyllabus` t2
                    WHERE t2.CourseIndex = t1.CourseIndex
                    ORDER BY major_version DESC, minor_version DESC
                    LIMIT 1
                    );
            END IF;

--                ex, 2020-2021 ~ Current

            SELECT DISTINCT `SO`.`SO`, `PI`.`GPI`, `PI`.`Description`, `PI`.`Comments`, `PI`.`Approval`
            FROM `GeneralPerformanceIndicators` AS `PI`
                     INNER JOIN `StudentOutcomes` AS `SO` ON (`SO`.`Idx`=`PI`.`SOIdx`)
                     INNER JOIN `CourseMapping_GPIs` AS `CM_PIS` ON (`PI`.`Idx`=`CM_PIS`.`GPIIdx`)
                     INNER JOIN `CourseMapping_Courses` AS `CM_CRSES` ON (`CM_CRSES`.`Idx`=`CM_PIS`.`AbetCourseIdx`)
                     INNER JOIN `Courses` AS `CRSES` ON (`CM_CRSES`.`CourseIdx`=`CRSES`.`Idx` AND `CRSES`.`Idx`=p_CourseIndex)
                     LEFT JOIN `AcademicYears` AS `AYS` ON (`AYS`.`Idx`=`CM_PIS`.`AcademicYear`)
            WHERE `AYS`.`Idx` = (
                SELECT `AYEARS`.`Idx`
                FROM AcademicYears `AYEARS`
                         JOIN AbetSyllabus `ABS` ON (`AYEARS`.`Idx` >= p_AcademicYearFromIdx)
                         JOIN `CourseMapping_Courses` `CMCRSES` ON (`AYEARS`.Idx = `CMCRSES`.AcademicYear)
                         INNER JOIN `CourseMapping_GPIs` AS `CM_PIS` ON (`CM_PIS`.`AbetCourseIdx`=`CMCRSES`.`Idx`)
                         INNER JOIN `Courses` `crses` ON (`CMCRSES`.`CourseIdx` = `crses`.Idx)
                WHERE `ABS`.Idx = p_SyllabusIndex
                  AND `crses`.`Idx`=p_CourseIndex
                  AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
                ORDER BY `AYEARS`.`From` DESC LIMIT 1
                )
              AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
            ORDER BY `SO`.`SO`, `PI`.`GPI`;


        END;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_FetchRevisionHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_FetchRevisionHistory`(
    IN p_CourseIndex INT,
    IN p_AcademicProgramIdx INT
)
BEGIN

    SELECT `Idx`, `major_version`, `minor_version`, `RevisionDesc`, `RevisionDate`, `ApprovalDate`, `ApprovalDesc`
    FROM `AbetSyllabus`
    WHERE `CourseIndex` = p_CourseIndex
      AND `AcademicProgram` = p_AcademicProgramIdx
    ORDER BY `major_version`, `minor_version` DESC;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_FetchSOs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_FetchSOs`(
    IN p_CourseIndex INT,
    IN p_SyllabusIndex INT,
    IN p_AcademicYearFromIdx INT,
    IN p_AcademicYearToIdx INT,
    IN p_AcademicProgramIdx INT
)
BEGIN

    IF p_AcademicYearToIdx IS NOT NULL THEN
        BEGIN

            IF p_AcademicYearFromIdx = p_AcademicYearToIdx THEN
--                ex, 2020-2021 ~ 2020-2021

                BEGIN
                    SELECT DISTINCT `SO`.`SO`, `SO`.`Description`, `SO`.`Comments`, `SO`.`Approval`
                    FROM `StudentOutcomes` AS `SO`
                         INNER JOIN `CourseMapping_SOs` AS `CM_SOS` ON (`SO`.`Idx`=`CM_SOS`.`SOIdx`)
                         INNER JOIN `CourseMapping_Courses` AS `CM_CRSES` ON (`CM_CRSES`.`Idx`=`CM_SOS`.`AbetCourseIdx`)
                         INNER JOIN `Courses` AS `CRSES` ON (`CM_CRSES`.`CourseIdx`=`CRSES`.`Idx` AND `CRSES`.`Idx`=p_CourseIndex)
                         LEFT JOIN `AcademicYears` AS `AYS` ON (`AYS`.`Idx`=`CM_SOS`.`AcademicYear`)
                    WHERE `AYS`.`Idx` = p_AcademicYearFromIdx
                        AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
                    ORDER BY `SO`.`SO`;
                END;
            ELSE
                BEGIN
--                ex, 2020-2021 ~ 2023-2024

                SELECT DISTINCT `SO`.`SO`, `SO`.`Description`, `SO`.`Comments`, `SO`.`Approval`
                FROM `StudentOutcomes` AS `SO`
                         INNER JOIN `CourseMapping_SOs` AS `CM_SOS` ON (`SO`.`Idx`=`CM_SOS`.`SOIdx`)
                         INNER JOIN `CourseMapping_Courses` AS `CM_CRSES` ON (`CM_CRSES`.`Idx`=`CM_SOS`.`AbetCourseIdx`)
                         INNER JOIN `Courses` AS `CRSES` ON (`CM_CRSES`.`CourseIdx`=`CRSES`.`Idx` AND `CRSES`.`Idx`=p_CourseIndex)
                         LEFT JOIN `AcademicYears` AS `AYS` ON (`AYS`.`Idx`=`CM_SOS`.`AcademicYear`)
                WHERE `AYS`.`Idx` = (
                    SELECT `AYEARS`.`Idx`
                    FROM `AcademicYears` `AYEARS`
                             JOIN `AbetSyllabus` `abs` ON (`AYEARS`.`Idx` >= p_AcademicYearFromIdx AND `AYEARS`.`Idx` <= p_AcademicYearToIdx)
                             JOIN `CourseMapping_Courses` `CMCRSES` ON (`AYEARS`.Idx = `CMCRSES`.AcademicYear)
                             INNER JOIN `CourseMapping_SOs` AS `CM_SOS` ON (`CM_SOS`.`AbetCourseIdx`=`CMCRSES`.`Idx`)
                             INNER JOIN `Courses` `crses` ON (`CMCRSES`.CourseIdx = `crses`.Idx)
                    WHERE `abs`.Idx = p_SyllabusIndex
                      AND `crses`.`Idx`=p_CourseIndex
                      AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
                    ORDER BY `AYEARS`.`From` DESC LIMIT 1
                    )
                  AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
                ORDER BY `SO`.`SO`;

                END;
            END IF;

       END;

    ELSE
        BEGIN

            IF p_AcademicYearFromIdx IS NULL THEN
                SELECT `AcademicYearFrom` INTO p_AcademicYearFromIdx FROM `AbetSyllabus` t1
                WHERE CourseIndex = p_CourseIndex
                  AND AcademicProgram = p_AcademicProgramIdx
                  AND (major_version, minor_version) = (
                    SELECT major_version, minor_version
                    FROM `AbetSyllabus` t2
                    WHERE t2.CourseIndex = t1.CourseIndex
                    ORDER BY major_version DESC, minor_version DESC
                    LIMIT 1
                    );
            END IF;

--                ex, 2020-2021 ~ Current

            SELECT DISTINCT `SO`.`SO`, `SO`.`Description`, `SO`.`Comments`, `SO`.`Approval`
            FROM `StudentOutcomes` AS `SO`
                     INNER JOIN `CourseMapping_SOs` AS `CM_SOS` ON (`SO`.`Idx`=`CM_SOS`.`SOIdx`)
                     INNER JOIN `CourseMapping_Courses` AS `CM_CRSES` ON (`CM_CRSES`.`Idx`=`CM_SOS`.`AbetCourseIdx`)
                     INNER JOIN `Courses` AS `CRSES` ON (`CM_CRSES`.`CourseIdx`=`CRSES`.`Idx` AND `CRSES`.`Idx`=p_CourseIndex)
                     LEFT JOIN `AcademicYears` AS `AYS` ON (`AYS`.`Idx`=`CM_SOS`.`AcademicYear`)
            WHERE `AYS`.`Idx` = (
                SELECT `AYEARS`.`Idx`
                FROM `AcademicYears` `AYEARS`
                         JOIN `AbetSyllabus` `abs` ON (`AYEARS`.`Idx` >= p_AcademicYearFromIdx)
                         JOIN `CourseMapping_Courses` `CMCRSES` ON (`AYEARS`.Idx = `CMCRSES`.AcademicYear)
                         INNER JOIN `CourseMapping_SOs` AS `CM_SOS` ON (`CM_SOS`.`AbetCourseIdx`=`CMCRSES`.`Idx`)
                         INNER JOIN `Courses` `crses` ON (`CMCRSES`.CourseIdx = `crses`.Idx)
                WHERE `abs`.Idx = p_SyllabusIndex
                  AND `crses`.`Idx`=p_CourseIndex
                  AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
                ORDER BY `AYEARS`.`From` DESC LIMIT 1
                )
              AND `CM_CRSES`.`AcademicProgram` = p_AcademicProgramIdx
            ORDER BY `SO`.`SO`;

        END;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_RevisionAdd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_RevisionAdd`(
    IN p_PrevSyllabusIndex INT,
    IN p_courseIndex INT,
    IN p_major_version INT,
    IN p_minor_version INT,
    IN p_major_version_diff INT,
    IN p_minor_version_diff INT,
    IN p_FromAcademicYears INT,
    IN p_ToAcademicYears INT,
    IN p_Subject VARCHAR(255),
    IN p_Num VARCHAR(255),
    IN p_Description TEXT,
    IN p_Credits TEXT,
    IN p_Requirement TEXT,
    IN p_Pre_requisites TEXT,
    IN p_Co_requisites TEXT,
    IN p_Required_Texts TEXT,
    IN p_Reference_Texts TEXT,
    IN p_Coordinator TEXT,
    IN p_ObjectivesHeadline TEXT,
    IN p_Objectives TEXT,
    IN p_TopicsCoveredHeadline TEXT,
    IN p_TopicsCovered TEXT,
    IN p_RevisionDesc TEXT,
    IN p_RevisionDate TEXT,
    IN p_ApprovalDesc TEXT,
    IN p_ApprovalDate TEXT,
    IN p_AcademicProgram INT
)
BEGIN
    -- Declare variables
    DECLARE v_new_syllabus_idx INT;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Insert syllabus
    INSERT INTO `AbetSyllabus` (
        `CourseIndex`,
        `major_version`,
        `minor_version`,
        `AcademicYearFrom`,
        `AcademicYearTo`,
        `Description`,
        `Credits`,
        `Requirement`,
        `Pre_requisites`,
        `Co_requisites`,
        `Required_Texts`,
        `Reference_Texts`,
        `Coordinator`,
        `ObjectivesHeadline`,
        `Objectives`,
        `TopicsCoveredHeadline`,
        `TopicsCovered`,
        `RevisionDesc`,
        `RevisionDate`,
        `ApprovalDesc`,
        `ApprovalDate`,
        `AcademicProgram`
    ) VALUES (
        p_courseIndex,
        p_major_version,
        p_minor_version,
        p_FromAcademicYears,
        p_ToAcademicYears,
        p_Description,
        p_Credits,
        p_Requirement,
        p_Pre_requisites,
        p_Co_requisites,
        p_Required_Texts,
        p_Reference_Texts,
        p_Coordinator,
        p_ObjectivesHeadline,
        p_Objectives,
        p_TopicsCoveredHeadline,
        p_TopicsCovered,
        p_RevisionDesc,
        p_RevisionDate,
        p_ApprovalDesc,
        p_ApprovalDate,
        p_AcademicProgram
    );

    -- Get inserted syllabus ID
    SET v_new_syllabus_idx = LAST_INSERT_ID();

    -- Update previous syllabus academic year information
    CALL SP_AbetSyllabus_ChangeAcademicYears(p_PrevSyllabusIndex, p_FromAcademicYears);

    -- Updated linked syllabus
    CALL SP_AbetSyllabus_RevisionAdd_UpdateLinkedCourses(
        p_PrevSyllabusIndex,
        v_new_syllabus_idx,
        p_courseIndex,
        p_major_version_diff,
        p_minor_version_diff,
        p_FromAcademicYears,
        p_ToAcademicYears,
        p_Subject,
        p_Num,
        p_Description,
        p_Credits,
        p_Pre_requisites,
        p_Co_requisites,
        p_Required_Texts,
        p_Reference_Texts,
        p_Coordinator,
        p_ObjectivesHeadline,
        p_Objectives,
        p_TopicsCoveredHeadline,
        p_TopicsCovered,
        p_RevisionDesc,
        p_RevisionDate);

    -- Return new syllabus ID
    SELECT v_new_syllabus_idx AS 'AddedSyllabusIndex';

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AbetSyllabus_RevisionAdd_UpdateLinkedCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AbetSyllabus_RevisionAdd_UpdateLinkedCourses`(
    IN p_OldSyllabusIndex INT,
    IN p_NewSyllabusIndex INT,
    IN p_courseIndex INT,
    IN p_major_version_diff INT,
    IN p_minor_version_diff INT,
    IN p_FromAcademicYears INT,
    IN p_ToAcademicYears INT,
    IN p_Subject VARCHAR(255),
    IN p_Num VARCHAR(255),
    IN p_Description TEXT,
    IN p_Credits TEXT,
    IN p_Pre_requisites TEXT,
    IN p_Co_requisites TEXT,
    IN p_Required_Texts TEXT,
    IN p_Reference_Texts TEXT,
    IN p_Coordinator TEXT,
    IN p_ObjectivesHeadline TEXT,
    IN p_Objectives TEXT,
    IN p_TopicsCoveredHeadline TEXT,
    IN p_TopicsCovered TEXT,
    IN p_RevisionDesc TEXT,
    IN p_RevisionDate TEXT
)
BEGIN
    -- Declare variables
    DECLARE v_done BOOLEAN DEFAULT FALSE;
    DECLARE v_LinkedABETSyllabusIdx INT;
    DECLARE v_major_version INT;
    DECLARE v_minor_version INT;
    DECLARE v_updated_major_version INT;
    DECLARE v_updated_minor_version INT;
    DECLARE v_AcademicProgramIdx INT;
    DECLARE v_Requirement VARCHAR(255);

    -- Declare cursor
    DECLARE cursor_linked_syllabus CURSOR FOR
        SELECT `Idx`, `major_version`, `minor_version`, `Requirement`, `AcademicProgram`
        FROM `AbetSyllabus`
        WHERE `LinkedSyllabus` = p_OldSyllabusIndex;

    -- Declare handlers
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Input validation
    IF p_OldSyllabusIndex IS NULL OR p_NewSyllabusIndex IS NULL OR p_courseIndex IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Required parameters cannot be NULL';
    END IF;

    OPEN cursor_linked_syllabus;

    read_loop: LOOP
        FETCH cursor_linked_syllabus INTO
            v_LinkedABETSyllabusIdx,
            v_major_version,
            v_minor_version,
            v_Requirement,
            v_AcademicProgramIdx;

        IF v_done THEN
            LEAVE read_loop;
        END IF;

        IF v_LinkedABETSyllabusIdx IS NOT NULL AND v_AcademicProgramIdx IS NOT NULL THEN
            -- Calculate new versions
            SET v_updated_major_version = v_major_version + p_major_version_diff;
            SET v_updated_minor_version = v_minor_version + p_minor_version_diff;

            -- Insert new syllabus
            INSERT INTO `AbetSyllabus` (
                `CourseIndex`,
                `major_version`,
                `minor_version`,
                `AcademicYearFrom`,
                `AcademicYearTo`,
                `Description`,
                `Credits`,
                `Requirement`,
                `Pre_requisites`,
                `Co_requisites`,
                `Required_Texts`,
                `Reference_Texts`,
                `Coordinator`,
                `ObjectivesHeadline`,
                `Objectives`,
                `TopicsCoveredHeadline`,
                `TopicsCovered`,
                `RevisionDesc`,
                `RevisionDate`,
                `AcademicProgram`,
                `LinkedSyllabus`
            ) VALUES (
                p_courseIndex,
                v_updated_major_version,
                v_updated_minor_version,
                p_FromAcademicYears,
                p_ToAcademicYears,
                p_Description,
                p_Credits,
                v_Requirement,
                p_Pre_requisites,
                p_Co_requisites,
                p_Required_Texts,
                p_Reference_Texts,
                p_Coordinator,
                p_ObjectivesHeadline,
                p_Objectives,
                p_TopicsCoveredHeadline,
                p_TopicsCovered,
                p_RevisionDesc,
                p_RevisionDate,
                v_AcademicProgramIdx,
                p_NewSyllabusIndex
            );

            -- Update academic years
            CALL SP_AbetSyllabus_ChangeAcademicYears(v_LinkedABETSyllabusIdx, p_FromAcademicYears);
        END IF;
    END LOOP;

    CLOSE cursor_linked_syllabus;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAbetCourse` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAbetCourse`(
    IN IN_AcademicYear INT,
    IN IN_AVCourseIdx INT,
    IN IN_CMCourseIdx INT,
    IN IN_AcademicProgram INT
)
BEGIN
    DECLARE v_course_level INT;
    DECLARE v_course_requirement VARCHAR(255);
    DECLARE v_ABET_syllabus INT;
    DECLARE v_InsertedAbetCourseIdx INT;
    DECLARE v_Degree VARCHAR(255);
    DECLARE v_AcademicYear VARCHAR(255);
    DECLARE v_CourseNum VARCHAR(255);
    DECLARE v_AbetSyllabus VARCHAR(255);

    START TRANSACTION;

    IF NOT EXISTS (
        SELECT 1 FROM `AbetCourses`
        WHERE `AcademicYear` = IN_AcademicYear
        AND `AVCourseIdx` = IN_AVCourseIdx
        AND `AcademicProgram` = IN_AcademicProgram
    ) THEN
    BEGIN
        -- Get course level once
        SELECT `Level`, `Requirement`, `AbetSyllabus`
        INTO v_course_level, v_course_requirement, v_ABET_syllabus
        FROM `CourseMapping_Courses` AS `CMCRSES`
        WHERE `CMCRSES`.`Idx` = IN_CMCourseIdx;

        -- Insert main record
        INSERT INTO `AbetCourses`
        (`AcademicYear`, `AVCourseIdx`, `Requirement`, `Level`, `AcademicProgram`)
        VALUES
        (IN_AcademicYear, IN_AVCourseIdx, v_course_requirement, v_course_level, IN_AcademicProgram);

        -- Fetch inserted item index number
        SET v_InsertedAbetCourseIdx = LAST_INSERT_ID();

        -- Copy SOs and PIs
        CALL SP_AddAbetCourse_FetchAndInsertSOs(IN_CMCourseIdx, IN_AcademicYear, IN_AcademicProgram, v_InsertedAbetCourseIdx);
        CALL SP_AddAbetCourse_FetchAndInsertPIs(IN_CMCourseIdx, IN_AcademicYear, IN_AcademicProgram, v_InsertedAbetCourseIdx);

        IF v_ABET_syllabus IS NULL THEN
           -- No Syllabus exists
            SELECT NULL AS `AcademicYear`, NULL AS `AbetSyllabus`;

        ELSE
        -- ABET syllabus creation from uploaded syllabus (LaTex generation)
        -- Below, it will create a syllabus name and pass it back to PHP to create PDF with LaTex.
            -- Fetch required information
            SELECT LOWER(`Degree`) INTO v_Degree
            FROM `AcademicPrograms`
            WHERE `Idx` = IN_AcademicProgram;

            SELECT `AcademicYear` INTO v_AcademicYear
            FROM `AcademicYears`
            WHERE `Idx` = IN_AcademicYear;

            SELECT LOWER(CONCAT(`Subject`, '_', `Num`)) INTO v_CourseNum
            FROM `AVCourses`
            WHERE `Idx` = IN_AVCourseIdx;

            -- Create abet syllabus file name
            SET v_AbetSyllabus = CONCAT('abet_syllabus_', v_AcademicYear, '_', v_Degree, '_', v_CourseNum, '.pdf');

            -- Update Syllabus PDF information
            UPDATE `AbetCourses`
            SET `Syllabus` = v_AbetSyllabus
            WHERE `Idx` = v_InsertedAbetCourseIdx;

            -- Return necessary information for creating ABET file
            SELECT v_AcademicYear AS `AcademicYear`, v_AbetSyllabus AS `AbetSyllabus`;
        END IF;
    END;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAbetCoursePI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAbetCoursePI`(IN IN_PIIdx INT, IN IN_AbetCourseIdx INT,
    IN IN_SOIdx INT, IN IN_AcademicYear INT, IN IN_AcademicProgram INT, IN IN_GPIChecked VARCHAR(5) )
BEGIN
	START TRANSACTION;

	IF IN_GPIChecked = 'true' THEN # if GPIcheck is enabled
    BEGIN
    	IF (SELECT COUNT(*) FROM `AbetCourses_GPIs`
    	    WHERE `GPIIdx`=IN_PIIdx AND `AbetCourseIdx`=IN_AbetCourseIdx
    	        AND `SOIdx`=IN_SOIdx AND `AcademicYear`=IN_AcademicYear
    	        AND `AcademicProgram`=IN_AcademicProgram)=0 THEN # no item exists
    	BEGIN
    	    # Insert PI
        	INSERT INTO `AbetCourses_GPIs`(`GPIIdx`, `AbetCourseIdx`, `SOIdx`, `AcademicYear`, `AcademicProgram`)
        	VALUES (IN_PIIdx, IN_AbetCourseIdx, IN_SOIdx, IN_AcademicYear, IN_AcademicProgram);
    	END;
    	END IF;
    END;
    ELSE    # if GPIcheck is not enabled
    BEGIN
            DELETE FROM `AbetCourses_GPIs`
            WHERE `AbetCourseIdx`=IN_AbetCourseIdx AND `SOIdx`=IN_SOIdx
                AND `GPIIdx`=IN_PIIdx AND `AcademicYear`=IN_AcademicYear
                AND `AcademicProgram`=IN_AcademicProgram LIMIT 1;
    END;
    END IF;
    
	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAbetCourseSO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAbetCourseSO`(IN IN_AbetCourseIdx INT, IN IN_SOIdx INT,
    IN IN_AcademicYear INT, IN IN_AcademicProgram INT, IN IN_SOChecked VARCHAR(5) )
BEGIN
	START TRANSACTION;
	
	IF IN_SOChecked = 'true' THEN
    BEGIN
        -- Student outcome is checked
    	IF (SELECT COUNT(*) FROM `AbetCourses_SOs`
    	    WHERE `AbetCourseIdx`=IN_AbetCourseIdx AND `SOIdx`=IN_SOIdx
    	        AND `AcademicYear`=IN_AcademicYear AND `AcademicProgram`=IN_AcademicProgram)=0 THEN # no item exists
    	BEGIN
        	INSERT INTO `AbetCourses_SOs`(`AbetCourseIdx`, `SOIdx`, `AcademicYear`, `AcademicProgram`)
        	    VALUES (IN_AbetCourseIdx, IN_SOIdx, IN_AcademicYear, IN_AcademicProgram);
    	END;
    	END IF;
    END;
    ELSE
    BEGIN
        -- Student outcome is not checked
        DELETE FROM `AbetCourses_GPIs`
        WHERE `AbetCourseIdx`=IN_AbetCourseIdx AND `SOIdx`=IN_SOIdx
        AND `AcademicYear`=IN_AcademicYear AND `AcademicProgram`=IN_AcademicProgram;

        DELETE FROM `AbetCourses_SOs`
        WHERE `AbetCourseIdx`=IN_AbetCourseIdx AND `SOIdx`=IN_SOIdx
        AND `AcademicYear`=IN_AcademicYear AND `AcademicProgram`=IN_AcademicProgram LIMIT 1;
    END;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAbetCourse_FetchAndInsertPIs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAbetCourse_FetchAndInsertPIs`(
    IN IN_CMCourseIdx INT,
    IN IN_AcademicYear VARCHAR(255),
    IN IN_AcademicProgram VARCHAR(255),
    IN InsertedAbetCourseIdx INT
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE gpi_idx INT;
    DECLARE so_idx INT;

    -- Declare cursor
    DECLARE gpi_cursor CURSOR FOR
    SELECT `GPIIdx`, `SOIdx`
    FROM `CourseMapping_Courses` AS `CM_CRSES`
             INNER JOIN `CourseMapping_GPIs` AS `CM_PIS`
                        ON (`CM_CRSES`.`Idx` = `CM_PIS`.`AbetCourseIdx`)
    WHERE `CM_CRSES`.`Idx` = IN_CMCourseIdx;

    -- Declare handler
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

        -- Open cursor
    OPEN gpi_cursor;

    read_loop: LOOP
            FETCH gpi_cursor INTO gpi_idx, so_idx;

            IF done THEN
                LEAVE read_loop;
    END IF;

            -- Insert into target table
    INSERT INTO `AbetCourses_GPIs`
    (`GPIIdx`, `AbetCourseIdx`, `SOIdx`, `AcademicYear`, `AcademicProgram`)
    VALUES
        (gpi_idx, InsertedAbetCourseIdx, so_idx, IN_AcademicYear, IN_AcademicProgram);

    END LOOP;

        -- Close cursor
    CLOSE gpi_cursor;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAbetCourse_FetchAndInsertSOs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAbetCourse_FetchAndInsertSOs`(
    IN IN_CMCourseIdx INT,
    IN IN_AcademicYear VARCHAR(255),
    IN IN_AcademicProgram VARCHAR(255),
    IN IN_InsertedAbetCourseIdx INT
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE so_idx INT;

    -- Declare cursor
    DECLARE so_cursor CURSOR FOR
    SELECT `SOIdx`
    FROM `CourseMapping_Courses` AS `CM_CRSES`
             INNER JOIN `CourseMapping_SOs` AS `CM_SOS`
                        ON (`CM_CRSES`.`Idx` = `CM_SOS`.`AbetCourseIdx`)
    WHERE `CM_CRSES`.`Idx` = IN_CMCourseIdx;

    -- Declare handler for when no rows found
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

        -- Open cursor
    OPEN so_cursor;

    read_loop: LOOP
            FETCH so_cursor INTO so_idx;

            IF done THEN
                LEAVE read_loop;
    END IF;

            -- Insert into target table
    INSERT INTO `AbetCourses_SOs`
    (`SOIdx`, `AbetCourseIdx`, `AcademicYear`, `AcademicProgram`)
    VALUES
        (so_idx, IN_InsertedAbetCourseIdx, IN_AcademicYear, IN_AcademicProgram);

    END LOOP;

        -- Close cursor
    CLOSE so_cursor;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAbetSyllabus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAbetSyllabus`(IN IN_AcademicYear INT, IN IN_Syllabus VARCHAR(256), IN IN_CourseSubject VARCHAR(5), IN IN_CourseNum VARCHAR(5), IN IN_AcademicProgram INT)
BEGIN
	START TRANSACTION;

    UPDATE `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx`=`AVCRSES`.`Idx`)
        SET `ABETCRSES`.`Syllabus` = IN_Syllabus, `ABETCRSES`.`SyllabusLastUpdated`=CURDATE()
    WHERE `ABETCRSES`.`AcademicYear`=IN_AcademicYear AND `ABETCRSES`.`AcademicProgram`=IN_AcademicProgram
    AND `AVCRSES`.`Subject`=IN_CourseSubject AND `AVCRSES`.`Num`=IN_CourseNum;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAbetSyllabus_Courses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAbetSyllabus_Courses`(
    IN IN_CourseIdx INT,
    IN IN_AcademicProgram INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `AbetSyllabus`
       WHERE `CourseIndex`=IN_CourseIdx AND `AcademicProgram`=IN_AcademicProgram) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same item exists already
    END IF;

    INSERT INTO `AbetSyllabus`(`CourseIndex`, `AcademicProgram`)
    VALUES (IN_CourseIdx, IN_AcademicProgram);

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAcademicYear` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAcademicYear`(
    IN IN_AcademicYearInfo VARCHAR(20),
    IN IN_AcademicYearFromCode INT,
    IN IN_AcademicYearTomCode INT
)
BEGIN
    DECLARE newIndex INT;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `AcademicYears` WHERE `AcademicYear` = IN_AcademicYearInfo) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same item exists already
    END IF;

    IF (SELECT COUNT(*) FROM `AcademicYears`)=0 THEN # no item exists
        SET newIndex = FLOOR(1 + RAND() * 1577854800); -- Jan 01 2020 (default)
    ELSE
        SELECT MAX(Idx)+1 INTO newIndex FROM `AcademicYears`;
    END IF;

    INSERT INTO `AcademicYears`(`Idx`, `AcademicYear`, `From`, `To`)
    VALUES (newIndex,IN_AcademicYearInfo,IN_AcademicYearFromCode,IN_AcademicYearTomCode);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAffiliation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAffiliation`(
    IN IN_Name VARCHAR(200)
)
BEGIN
    DECLARE randomIndex INT;
    DECLARE attemptCount INT DEFAULT 0;
    DECLARE MAX_ATTEMPTS INT DEFAULT 10;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `Affiliations` WHERE `Name` = IN_Name) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already
    END IF;

    -- Attempt to insert with unique random ID
    WHILE attemptCount < MAX_ATTEMPTS DO
        SET randomIndex = FLOOR(1 + RAND() * 1000000);
    BEGIN
        DECLARE CONTINUE HANDLER FOR 1062
        BEGIN
            SET attemptCount = attemptCount + 1;
        END;

        INSERT INTO `Affiliations` (`IDX`, `Name`) VALUES (randomIndex, IN_Name);

        IF ROW_COUNT() > 0 THEN
            SET attemptCount = MAX_ATTEMPTS; -- Exit loop on successful insert
        END IF;
    END;
    END WHILE;

    -- Check if insertion was successful
    IF attemptCount = MAX_ATTEMPTS AND
       NOT EXISTS (SELECT 1 FROM `Affiliations` WHERE `IDX` = randomIndex AND `Name` = IN_Name) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Failed to insert unique position after maximum attempts';
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAssessmentMasterRubrics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAssessmentMasterRubrics`(
    IN IN_AcademicYear INT,
    IN IN_GPIIdx INT,
    IN IN_AcademicProgram INT
)
BEGIN
    START TRANSACTION;

    # Insert rubrics for all 4 levels of attainment
    INSERT INTO `AssessmentMasterRubrics` (`AcademicYear`, `LevelofAttainment`, `GPIIdx`, `AcademicProgram`)
    VALUES (IN_AcademicYear, 1, IN_GPIIdx, IN_AcademicProgram)
    ON DUPLICATE KEY UPDATE
                           `AcademicYear` = IN_AcademicYear,
                           `LevelofAttainment` = 1,
                           `GPIIdx` = IN_GPIIdx,
                           `AcademicProgram` = IN_AcademicProgram;

    INSERT INTO `AssessmentMasterRubrics` (`AcademicYear`, `LevelofAttainment`, `GPIIdx`, `AcademicProgram`)
    VALUES (IN_AcademicYear, 2, IN_GPIIdx, IN_AcademicProgram)
        ON DUPLICATE KEY UPDATE
                             `AcademicYear` = IN_AcademicYear,
                             `LevelofAttainment` = 2,
                             `GPIIdx` = IN_GPIIdx,
                             `AcademicProgram` = IN_AcademicProgram;

    INSERT INTO `AssessmentMasterRubrics` (`AcademicYear`, `LevelofAttainment`, `GPIIdx`, `AcademicProgram`)
    VALUES (IN_AcademicYear, 3, IN_GPIIdx, IN_AcademicProgram)
        ON DUPLICATE KEY UPDATE
                             `AcademicYear` = IN_AcademicYear,
                             `LevelofAttainment` = 3,
                             `GPIIdx` = IN_GPIIdx,
                             `AcademicProgram` = IN_AcademicProgram;

    INSERT INTO `AssessmentMasterRubrics` (`AcademicYear`, `LevelofAttainment`, `GPIIdx`, `AcademicProgram`)
    VALUES (IN_AcademicYear, 4, IN_GPIIdx, IN_AcademicProgram)
        ON DUPLICATE KEY UPDATE
                             `AcademicYear` = IN_AcademicYear,
                             `LevelofAttainment` = 4,
                             `GPIIdx` = IN_GPIIdx,
                             `AcademicProgram` = IN_AcademicProgram;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAssessmentMeasure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAssessmentMeasure`(
    IN IN_PI INT,
    IN IN_AssignmentType VARCHAR(256),
    IN IN_AssignmentNum INT,
    IN IN_AssignmentProblem VARCHAR(1024),
    IN IN_AssignmentDescription TEXT,
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT,
    IN IN_StudentEnrollment INT,
    IN IN_ActualAssmntSample VARCHAR(256)
)
BEGIN
    -- Declare variables
    DECLARE IN_MeasureIdx INT;
    DECLARE IN_ASSMNTIdx INT;
    DECLARE v_IsLinked INT DEFAULT 0;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Input validation (BEFORE transaction starts)
    IF IN_StudentEnrollment <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001011'; -- Invalid student enrollment
    END IF;

    IF IN_StudentEnrollment > 100 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001013'; -- Student enrollment exceeds maximum limit
    END IF;

    IF IN_PI IS NULL OR IN_AssignmentType IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001012'; -- Required fields missing
    END IF;

    -- Check if assignment exists
    IF EXISTS (
        SELECT 1 FROM `AssessmentMeasures`
        WHERE `GPI` = IN_PI
        AND `AssignmentType` = IN_AssignmentType
        AND (
            (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
            OR
            (`AssignmentNum` = IN_AssignmentNum)
        )
        AND `AssignmentProblem` = IN_AssignmentProblem
        AND `AbetCourseIdx` = IN_AbetCourseIdx
        AND `AvailableCourseIdx` = IN_AvailableCourseIdx
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001010'; -- Item exists already
    END IF;

    -- Check if this course is part of a linked group
    SELECT IFNULL(`Linked`, 0) INTO v_IsLinked
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdx;

    -- START TRANSACTION AFTER all validation passes
    START TRANSACTION;

    -- Find measure index number
    SELECT IFNULL(Max(`Measure`), 0)+1 INTO IN_MeasureIdx
    FROM `AssessmentMeasures`
    WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
    AND `AbetCourseIdx` = IN_AbetCourseIdx;

    -- Find assessment sample file
    IF IN_ActualAssmntSample = '' THEN
        SELECT IFNULL(`ActualAssmntSample`, '') INTO IN_ActualAssmntSample
        FROM `AssessmentMeasures`
        WHERE `ActualAssmntSample` <> ''
        AND `AssignmentType` = IN_AssignmentType
        AND (
            (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
            OR
            (`AssignmentNum` = IN_AssignmentNum)
        )
        AND `AvailableCourseIdx` = IN_AvailableCourseIdx
        AND `AbetCourseIdx` = IN_AbetCourseIdx
        LIMIT 1;
    END IF;

    -- Insert assessment measure
    INSERT INTO `AssessmentMeasures`(
        `GPI`, `Measure`, `AssignmentType`,
        `AssignmentNum`, `AssignmentProblem`, `AssignmentDescription`,
        `AvailableCourseIdx`, `AbetCourseIdx`, `ActualAssmntSample`
    ) VALUES (
        IN_PI, IN_MeasureIdx, IN_AssignmentType,
        IN_AssignmentNum, IN_AssignmentProblem, IN_AssignmentDescription,
        IN_AvailableCourseIdx, IN_AbetCourseIdx, IN_ActualAssmntSample
    );

    SET IN_ASSMNTIdx = LAST_INSERT_ID();

    -- Update actual assessment sample information for related measures
    IF IN_ActualAssmntSample <> '' THEN
        UPDATE `AssessmentMeasures`
        SET `ActualAssmntSample` = IN_ActualAssmntSample
        WHERE `AssignmentType` = IN_AssignmentType
        AND (
            (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
            OR
            (`AssignmentNum` = IN_AssignmentNum)
        )
        AND `AvailableCourseIdx` = IN_AvailableCourseIdx
        AND `AbetCourseIdx` = IN_AbetCourseIdx;
    END IF;

    -- Create scoresheet entries for all enrolled students
    IF NOT EXISTS (
        SELECT 1 FROM `Scoresheet`
        WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
        AND `AbetCourseIdx` = IN_AbetCourseIdx
        AND `AssessmentMeasureIdx` = IN_ASSMNTIdx
    ) THEN
        INSERT INTO `Scoresheet` (
            `AvailableCourseIdx`, `AbetCourseIdx`,
            `AssessmentMeasureIdx`, `StudentNo`, `AcademicProgramIdx`
        )
        SELECT
            IN_AvailableCourseIdx,
            IN_AbetCourseIdx,
            IN_ASSMNTIdx,
            numbers.n,
            IN_AcademicProgramIdx
        FROM (
            SELECT a.N + b.N * 10 + 1 as n
            FROM
                (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a,
                (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b
        ) numbers
        WHERE numbers.n <= IN_StudentEnrollment;
    END IF;

    -- Initialize continuous improvement record if not exists
    INSERT INTO `ContinuousImprovement`(
        `NumStudents`, `AvailableCourseIdx`, `AbetCourseIdx`
    )
    SELECT IN_StudentEnrollment, IN_AvailableCourseIdx, IN_AbetCourseIdx
    WHERE NOT EXISTS (
        SELECT 1
        FROM `ContinuousImprovement`
        WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
        AND `AbetCourseIdx` = IN_AbetCourseIdx
    );

    -- Replicate to related courses based on course type
    IF v_IsLinked = 1 THEN
        -- This is a linked course with different available courses
        CALL SP_AddAssessmentMeasureForLinkedCourses(
            IN_PI, IN_MeasureIdx, IN_AssignmentType, IN_AssignmentNum, IN_AssignmentProblem,
            IN_AssignmentDescription, IN_AvailableCourseIdx, IN_AbetCourseIdx,
            IN_AcademicProgramIdx, IN_ActualAssmntSample
        );
    ELSE
        -- This is a regular reference course with same available course
        CALL SP_AddAssessmentMeasureForReferenceCourses(
            IN_PI, IN_MeasureIdx, IN_AssignmentType, IN_AssignmentNum, IN_AssignmentProblem,
            IN_AssignmentDescription, IN_AvailableCourseIdx, IN_AbetCourseIdx,
            IN_AcademicProgramIdx, IN_StudentEnrollment, IN_ActualAssmntSample
        );
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAssessmentMeasureForLinkedCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAssessmentMeasureForLinkedCourses`(
    IN IN_PI INT,
    IN IN_MeasureIdx INT,
    IN IN_AssignmentType VARCHAR(256),
    IN IN_AssignmentNum INT,
    IN IN_AssignmentProblem VARCHAR(1024),
    IN IN_AssignmentDescription TEXT,
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT,
    IN IN_ActualAssmntSample VARCHAR(256)
)
BEGIN
    DECLARE v_Done INT DEFAULT FALSE;
    DECLARE v_LinkedAbetCourseIdx INT;
    DECLARE v_LinkedAvailCourseIdx INT;
    DECLARE v_LinkedAcademicProgramIdx INT;
    DECLARE v_LinkedGPIIdx INT;
    DECLARE v_StudentEnrollment INT;
    DECLARE v_NewAssessmentIdx INT;
    DECLARE v_BaseSO VARCHAR(50);
    DECLARE v_BaseGPI VARCHAR(50);
    DECLARE v_ActualAssmntSample VARCHAR(256);
    DECLARE v_ErrorMessage VARCHAR(512);

    -- Cursor for linked courses that reference the primary course
    DECLARE linked_cursor CURSOR FOR
        SELECT DISTINCT
            ac.`Idx` AS AbetCourseIdx,
            ac.`AVCourseIdx`,
            ac.`AcademicProgram`
        FROM `AbetCourses` ac
        WHERE ac.`Linked` = 1
        AND ac.`Reference` = IN_AbetCourseIdx  -- Reference points to the primary course
        AND ac.`AVCourseIdx` != IN_AvailableCourseIdx;  -- Only courses with different AvailableCourse

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_Done = TRUE;

    -- Get the SO and GPI from the primary course
    SELECT so.SO, gpi.GPI
    INTO v_BaseSO, v_BaseGPI
    FROM `GeneralPerformanceIndicators` gpi
    INNER JOIN `StudentOutcomes` so ON gpi.SOIdx = so.Idx
    WHERE gpi.Idx = IN_PI
    AND gpi.AcademicProgram = IN_AcademicProgramIdx;

    -- Open cursor and loop through linked courses
    OPEN linked_cursor;

    read_loop: LOOP
        SET v_Done = FALSE;

        FETCH linked_cursor INTO v_LinkedAbetCourseIdx, v_LinkedAvailCourseIdx, v_LinkedAcademicProgramIdx;

        IF v_Done THEN
            LEAVE read_loop;
        END IF;

        -- Find the matched GPI for the linked course
        -- Match by SO name and GPI name across courses, using linked course's program
        SET v_LinkedGPIIdx = NULL;

        SELECT gpi_linked.Idx INTO v_LinkedGPIIdx
        FROM `AbetCourses_GPIs` ac_gpi_linked
        INNER JOIN `GeneralPerformanceIndicators` gpi_linked ON ac_gpi_linked.GPIIdx = gpi_linked.Idx
        INNER JOIN `StudentOutcomes` so_linked ON gpi_linked.SOIdx = so_linked.Idx
        WHERE ac_gpi_linked.AbetCourseIdx = v_LinkedAbetCourseIdx
        AND ac_gpi_linked.AcademicProgram = v_LinkedAcademicProgramIdx
        AND so_linked.SO = v_BaseSO
        AND gpi_linked.GPI = v_BaseGPI
        AND so_linked.AcademicProgram = v_LinkedAcademicProgramIdx
        AND gpi_linked.AcademicProgram = v_LinkedAcademicProgramIdx
        LIMIT 1;

        -- Error if no matching GPI found
        IF v_LinkedGPIIdx IS NULL THEN
            -- Output debug query as a SELECT statement
            SELECT CONCAT(
                'SELECT gpi_linked.Idx ',
                'FROM `AbetCourses_GPIs` ac_gpi_linked ',
                'INNER JOIN `GeneralPerformanceIndicators` gpi_linked ON ac_gpi_linked.GPIIdx = gpi_linked.Idx ',
                'INNER JOIN `StudentOutcomes` so_linked ON gpi_linked.SOIdx = so_linked.Idx ',
                'WHERE ac_gpi_linked.AbetCourseIdx = ', v_LinkedAbetCourseIdx, ' ',
                'AND ac_gpi_linked.AcademicProgram = ', v_LinkedAcademicProgramIdx, ' ',
                'AND so_linked.SO = ''', v_BaseSO, ''' ',
                'AND gpi_linked.GPI = ''', v_BaseGPI, ''' ',
                'AND so_linked.AcademicProgram = ', v_LinkedAcademicProgramIdx, ' ',
                'AND gpi_linked.AcademicProgram = ', v_LinkedAcademicProgramIdx, ';'
            ) AS DebugQuery;

            SET v_ErrorMessage = CONCAT(
                'No matching GPI for linked course: LinkedCourse=', v_LinkedAbetCourseIdx,
                ', SO=', v_BaseSO,
                ', GPI=', v_BaseGPI,
                ', Program=', v_LinkedAcademicProgramIdx
            );

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = v_ErrorMessage;
        END IF;

        -- Check if assessment measure already exists with matched GPI
        IF EXISTS (
            SELECT 1 FROM `AssessmentMeasures`
            WHERE `GPI` = v_LinkedGPIIdx
            AND `Measure` = IN_MeasureIdx
            AND `AssignmentType` = IN_AssignmentType
            AND (
                (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
                OR
                (`AssignmentNum` = IN_AssignmentNum)
            )
            AND `AssignmentProblem` = IN_AssignmentProblem
            AND `AbetCourseIdx` = v_LinkedAbetCourseIdx
            AND `AvailableCourseIdx` = v_LinkedAvailCourseIdx
        ) THEN
            -- Skip if already exists
            ITERATE read_loop;
        END IF;

        -- Get enrollment count from AVCourses.Actual field
        SET v_StudentEnrollment = NULL;

        SELECT `Actual` INTO v_StudentEnrollment
        FROM `AVCourses`
        WHERE `Idx` = v_LinkedAvailCourseIdx
        LIMIT 1;

        -- If no enrollment data found or invalid, skip this course
        IF v_StudentEnrollment IS NULL OR v_StudentEnrollment <= 0 THEN
            -- Skip silently - enrollment data not set yet
            ITERATE read_loop;
        END IF;

        -- Validate enrollment
        IF v_StudentEnrollment > 100 THEN
            ITERATE read_loop;
        END IF;

        -- Find assessment sample file for this linked course
        SET v_ActualAssmntSample = IN_ActualAssmntSample;
        IF v_ActualAssmntSample = '' THEN
            SELECT IFNULL(`ActualAssmntSample`, '') INTO v_ActualAssmntSample
            FROM `AssessmentMeasures`
            WHERE `ActualAssmntSample` <> ''
            AND `AssignmentType` = IN_AssignmentType
            AND (
                (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
                OR
                (`AssignmentNum` = IN_AssignmentNum)
            )
            AND `AvailableCourseIdx` = v_LinkedAvailCourseIdx
            AND `AbetCourseIdx` = v_LinkedAbetCourseIdx
            LIMIT 1;
        END IF;

        -- Insert the assessment measure for this linked course with matched GPI
        INSERT INTO `AssessmentMeasures`(
            `GPI`, `Measure`, `AssignmentType`,
            `AssignmentNum`, `AssignmentProblem`, `AssignmentDescription`,
            `AvailableCourseIdx`, `AbetCourseIdx`, `ActualAssmntSample`
        ) VALUES (
            v_LinkedGPIIdx, IN_MeasureIdx, IN_AssignmentType,
            IN_AssignmentNum, IN_AssignmentProblem, IN_AssignmentDescription,
            v_LinkedAvailCourseIdx, v_LinkedAbetCourseIdx, v_ActualAssmntSample
        );

        SET v_NewAssessmentIdx = LAST_INSERT_ID();

        -- Create scoresheet entries for enrolled students
        IF NOT EXISTS (
            SELECT 1 FROM `Scoresheet`
            WHERE `AvailableCourseIdx` = v_LinkedAvailCourseIdx
            AND `AbetCourseIdx` = v_LinkedAbetCourseIdx
            AND `AssessmentMeasureIdx` = v_NewAssessmentIdx
        ) THEN
            INSERT INTO `Scoresheet` (
                `AvailableCourseIdx`, `AbetCourseIdx`,
                `AssessmentMeasureIdx`, `StudentNo`, `AcademicProgramIdx`
            )
            SELECT
                v_LinkedAvailCourseIdx,
                v_LinkedAbetCourseIdx,
                v_NewAssessmentIdx,
                numbers.n,
                v_LinkedAcademicProgramIdx
            FROM (
                SELECT a.N + b.N * 10 + 1 as n
                FROM
                    (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                     UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a,
                    (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                     UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b
            ) numbers
            WHERE numbers.n <= v_StudentEnrollment;
        END IF;

        -- Initialize continuous improvement with enrollment from AVCourses.Actual
        INSERT INTO `ContinuousImprovement`(
            `NumStudents`, `AvailableCourseIdx`, `AbetCourseIdx`
        )
        SELECT v_StudentEnrollment, v_LinkedAvailCourseIdx, v_LinkedAbetCourseIdx
        WHERE NOT EXISTS (
            SELECT 1
            FROM `ContinuousImprovement`
            WHERE `AvailableCourseIdx` = v_LinkedAvailCourseIdx
            AND `AbetCourseIdx` = v_LinkedAbetCourseIdx
        );

    END LOOP;

    CLOSE linked_cursor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAssessmentMeasureForReferenceCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAssessmentMeasureForReferenceCourses`(
    IN IN_PI INT,
    IN IN_MeasureIdx INT,
    IN IN_AssignmentType VARCHAR(256),
    IN IN_AssignmentNum INT,
    IN IN_AssignmentProblem VARCHAR(1024),
    IN IN_AssignmentDescription TEXT,
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT,
    IN IN_StudentEnrollment INT,
    IN IN_ActualAssmntSample VARCHAR(256)
)
BEGIN
    -- Declare variables
    DECLARE IN_ASSMNTIdx INT;
    DECLARE v_RefCourseIdx INT;
    DECLARE v_RefAcademicProgramIdx INT;
    DECLARE v_RefGPIIdx INT;
    DECLARE v_BaseSO VARCHAR(50);
    DECLARE v_BaseGPI VARCHAR(50);
    DECLARE v_Done INT DEFAULT FALSE;
    DECLARE v_ActualAssmntSample VARCHAR(256);
    DECLARE v_ErrorMessage VARCHAR(512);

    -- Cursor to iterate through all reference courses
    DECLARE ref_cursor CURSOR FOR
        SELECT `Idx`
        FROM `AbetCourses`
        WHERE `AVCourseIdx` = IN_AvailableCourseIdx
        AND `Reference` = IN_AbetCourseIdx;

    -- Handler only for cursor exhaustion
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_Done = TRUE;

    -- Get the SO and GPI from the base course
    SELECT so.SO, gpi.GPI
    INTO v_BaseSO, v_BaseGPI
    FROM `GeneralPerformanceIndicators` gpi
    INNER JOIN `StudentOutcomes` so ON gpi.SOIdx = so.Idx
    WHERE gpi.Idx = IN_PI
    AND gpi.AcademicProgram = IN_AcademicProgramIdx;

    -- Open cursor to process all reference courses
    OPEN ref_cursor;

    read_loop: LOOP
        -- Reset v_Done before fetch to avoid premature exit
        SET v_Done = FALSE;

        FETCH ref_cursor INTO v_RefCourseIdx;

        IF v_Done THEN
            LEAVE read_loop;
        END IF;

        -- Get the AcademicProgramIdx for this reference course
        SELECT `AcademicProgram` INTO v_RefAcademicProgramIdx
        FROM `AbetCourses`
        WHERE `Idx` = v_RefCourseIdx;

        -- Find the matched GPI for the reference course
        -- Match by SO name and GPI name across courses, using reference course's program
        SET v_RefGPIIdx = NULL;

        SELECT gpi_ref.Idx INTO v_RefGPIIdx
        FROM `AbetCourses_GPIs` ac_gpi_ref
        INNER JOIN `GeneralPerformanceIndicators` gpi_ref ON ac_gpi_ref.GPIIdx = gpi_ref.Idx
        INNER JOIN `StudentOutcomes` so_ref ON gpi_ref.SOIdx = so_ref.Idx
        WHERE ac_gpi_ref.AbetCourseIdx = v_RefCourseIdx
        AND ac_gpi_ref.AcademicProgram = v_RefAcademicProgramIdx
        AND so_ref.SO = v_BaseSO
        AND gpi_ref.GPI = v_BaseGPI
        AND so_ref.AcademicProgram = v_RefAcademicProgramIdx
        AND gpi_ref.AcademicProgram = v_RefAcademicProgramIdx
        LIMIT 1;

        -- Error if no matching GPI found
        IF v_RefGPIIdx IS NULL THEN
            -- Output debug query as a SELECT statement
            SELECT CONCAT(
                'SELECT gpi_ref.Idx ',
                'FROM `AbetCourses_GPIs` ac_gpi_ref ',
                'INNER JOIN `GeneralPerformanceIndicators` gpi_ref ON ac_gpi_ref.GPIIdx = gpi_ref.Idx ',
                'INNER JOIN `StudentOutcomes` so_ref ON gpi_ref.SOIdx = so_ref.Idx ',
                'WHERE ac_gpi_ref.AbetCourseIdx = ', v_RefCourseIdx, ' ',
                'AND ac_gpi_ref.AcademicProgram = ', v_RefAcademicProgramIdx, ' ',
                'AND so_ref.SO = ''', v_BaseSO, ''' ',
                'AND gpi_ref.GPI = ''', v_BaseGPI, ''' ',
                'AND so_ref.AcademicProgram = ', v_RefAcademicProgramIdx, ' ',
                'AND gpi_ref.AcademicProgram = ', v_RefAcademicProgramIdx, ';'
            ) AS DebugQuery;

            SET v_ErrorMessage = CONCAT(
                'No matching GPI: RefCourse=', v_RefCourseIdx,
                ', SO=', v_BaseSO,
                ', GPI=', v_BaseGPI,
                ', Program=', v_RefAcademicProgramIdx
            );

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = v_ErrorMessage;
        END IF;

        -- Find assessment sample file for this reference course
        SET v_ActualAssmntSample = IN_ActualAssmntSample;
        IF v_ActualAssmntSample = '' THEN
            SELECT IFNULL(`ActualAssmntSample`, '') INTO v_ActualAssmntSample
            FROM `AssessmentMeasures`
            WHERE `ActualAssmntSample` <> ''
            AND `AssignmentType` = IN_AssignmentType
            AND (
                (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
                OR
                (`AssignmentNum` = IN_AssignmentNum)
            )
            AND `AvailableCourseIdx` = IN_AvailableCourseIdx
            AND `AbetCourseIdx` = v_RefCourseIdx
            LIMIT 1;
        END IF;

        -- Insert assessment measure for this reference course with matched GPI
        INSERT INTO `AssessmentMeasures`(
            `GPI`, `Measure`, `AssignmentType`,
            `AssignmentNum`, `AssignmentProblem`, `AssignmentDescription`,
            `AvailableCourseIdx`, `AbetCourseIdx`, `ActualAssmntSample`
        ) VALUES (
            v_RefGPIIdx, IN_MeasureIdx, IN_AssignmentType,
            IN_AssignmentNum, IN_AssignmentProblem, IN_AssignmentDescription,
            IN_AvailableCourseIdx, v_RefCourseIdx, v_ActualAssmntSample
        );

        SET IN_ASSMNTIdx = LAST_INSERT_ID();

        -- Create scoresheet entries for all enrolled students in this reference course
        IF NOT EXISTS (
            SELECT 1 FROM `Scoresheet`
            WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
            AND `AbetCourseIdx` = v_RefCourseIdx
            AND `AssessmentMeasureIdx` = IN_ASSMNTIdx
        ) THEN
            INSERT INTO `Scoresheet` (
                `AvailableCourseIdx`, `AbetCourseIdx`,
                `AssessmentMeasureIdx`, `StudentNo`, `AcademicProgramIdx`
            )
            SELECT
                IN_AvailableCourseIdx,
                v_RefCourseIdx,
                IN_ASSMNTIdx,
                numbers.n,
                v_RefAcademicProgramIdx
            FROM (
                SELECT a.N + b.N * 10 + 1 as n
                FROM
                    (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                     UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) a,
                    (SELECT 0 AS N UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4
                     UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) b
            ) numbers
            WHERE numbers.n <= IN_StudentEnrollment;
        END IF;

        -- Initialize continuous improvement record for this reference course if not exists
        INSERT INTO `ContinuousImprovement`(
            `NumStudents`, `AvailableCourseIdx`, `AbetCourseIdx`
        )
        SELECT IN_StudentEnrollment, IN_AvailableCourseIdx, v_RefCourseIdx
        WHERE NOT EXISTS (
            SELECT 1
            FROM `ContinuousImprovement`
            WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
            AND `AbetCourseIdx` = v_RefCourseIdx
        );

    END LOOP;

    CLOSE ref_cursor;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAssessmentMeasureStudentSample` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAssessmentMeasureStudentSample`(
    IN IN_AssessmentMeasureIdx INT,
    IN IN_StudentSampleFile VARCHAR(512)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Input validation (BEFORE transaction starts)
    IF IN_AssessmentMeasureIdx IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001020'; -- Assessment measure index required
    END IF;

    IF IN_StudentSampleFile IS NULL OR IN_StudentSampleFile = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001021'; -- Student sample file path required
    END IF;

    -- Check if assessment measure exists
    IF NOT EXISTS (
        SELECT 1 FROM `AssessmentMeasures`
        WHERE `Idx` = IN_AssessmentMeasureIdx
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001020'; -- Assessment measure not found
    END IF;

    -- Check if this sample file already exists for this measure
    IF EXISTS (
        SELECT 1 FROM `AssessmentMeasureSamples`
        WHERE `AssessmentMeasureIdx` = IN_AssessmentMeasureIdx
        AND `SampleFile` = IN_StudentSampleFile
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001010'; -- Duplicate entry
    END IF;

    -- START TRANSACTION AFTER all validation passes
    START TRANSACTION;

    -- Insert the student sample record
    INSERT INTO `AssessmentMeasureSamples` (
        `AssessmentMeasureIdx`,
        `SampleFile`
    ) VALUES (
        IN_AssessmentMeasureIdx,
        IN_StudentSampleFile
    );

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAVCourse` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAVCourse`(
    IN IN_semester INT,
    IN IN_CRN INT,
    IN IN_subject VARCHAR(5),
    IN IN_num VARCHAR(5),
    IN IN_coursenum VARCHAR(20),
    IN IN_section VARCHAR(3),
    IN IN_title VARCHAR(200),
    IN IN_credits VARCHAR(20),
    IN IN_type VARCHAR(30),
    IN IN_days VARCHAR(5),
    IN IN_times VARCHAR(30),
    IN IN_location VARCHAR(100),
    IN IN_daterange VARCHAR(50),
    IN IN_instructorname VARCHAR(200),
    IN IN_instructoremail VARCHAR(200),
    IN IN_level VARCHAR(5),
    IN IN_capacity INT,
    IN IN_actual INT
)
BEGIN
    DECLARE v_AVCourseIDX INT;
    DECLARE v_IsManuallyEdited TINYINT DEFAULT 0;
    DECLARE v_SkipProcessing TINYINT DEFAULT 0;
    DECLARE v_cnt INT;
    DECLARE v_i INT DEFAULT 1;
    DECLARE v_InstructorName VARCHAR(200);
    DECLARE v_InstructorEmail VARCHAR(200);
    DECLARE v_UserIdx INT;
    DECLARE v_exists INT;

    START TRANSACTION;

    -- Check if course exists and get manual edit flag
    SELECT `Idx`, IFNULL(`IsManuallyEdited`, 0)
    INTO v_AVCourseIDX, v_IsManuallyEdited
    FROM `AVCourses`
    WHERE `Semester` = IN_semester
      AND `CRN` = IN_CRN
      AND `CourseNo` = IN_coursenum
      AND `Subject` = IN_subject
      AND `Section` = IN_section
    LIMIT 1;

    IF v_AVCourseIDX IS NULL THEN
        -- Insert new course
        INSERT INTO `AVCourses` (
            `Semester`, `CRN`, `Subject`, `Num`, `CourseNo`, `Section`,
            `Title`, `Credits`, `Type`, `Days`, `Times`, `Location`,
            `DateRange`, `Instructor`, `InstructorEmail`, `Level`,
            `Capacity`, `Actual`, `Sync`
        ) VALUES (
            IN_semester, IN_CRN, IN_subject, IN_num, IN_coursenum,
            IN_section, IN_title, IN_credits, IN_type, IN_days, IN_times,
            IN_location, IN_daterange, IN_instructorname, IN_instructoremail,
            IN_level, IN_capacity, IN_actual, 0
        );

        SET v_AVCourseIDX = LAST_INSERT_ID();

        -- Clear existing instructor assignments for new course
        DELETE FROM `AVCoursesInstructors` WHERE `AVCourseIdx` = v_AVCourseIDX;
    ELSE
        -- Check if manually edited before updating
        IF v_IsManuallyEdited = 0 THEN
            -- Update existing course (only if NOT manually edited)
            UPDATE `AVCourses`
            SET `Subject` = IN_subject,
                `Num` = IN_num,
                `Section` = IN_section,
                `Title` = IN_title,
                `Credits` = IN_credits,
                `Type` = IN_type,
                `Days` = IN_days,
                `Times` = IN_times,
                `Location` = IN_location,
                `DateRange` = IN_daterange,
                `Instructor` = IN_instructorname,
                `InstructorEmail` = IN_instructoremail,
                `Capacity` = IN_capacity,
                `Actual` = IN_actual,
                `Sync` = 0
            WHERE `Idx` = v_AVCourseIDX;

            -- Clear existing instructor assignments before re-adding
            DELETE FROM `AVCoursesInstructors` WHERE `AVCourseIdx` = v_AVCourseIDX;
        ELSE
            -- Course was manually edited: only update certain info and Sync flag
            UPDATE `AVCourses`
            SET `Days` = IN_days,
                `Times` = IN_times,
                `Location` = IN_location,
                `Sync` = 0
            WHERE `Idx` = v_AVCourseIDX;

            -- Skip the rest of processing for manually edited courses
            SET v_SkipProcessing = 1;
        END IF;
    END IF;

    -- Only continue processing if not manually edited
    IF v_SkipProcessing = 0 THEN
        -- Insert course info
        CALL SP_CourseInfo_AddCourse(IN_subject, IN_num, IN_title, IN_credits);

        -- Process instructors with both name and email
        IF IN_instructorname != '' AND IN_instructoremail != '' THEN
            SET v_cnt = 1 + (LENGTH(IN_instructorname) - LENGTH(REPLACE(IN_instructorname, '|', '')));

            WHILE v_i <= v_cnt DO
                SET v_InstructorName = TRIM(REPLACE(
                    SUBSTRING(SUBSTRING_INDEX(IN_instructorname, '|', v_i),
                        LENGTH(SUBSTRING_INDEX(IN_instructorname, '|', v_i - 1)) + 1),
                    '|', ''
                ));

                SET v_InstructorEmail = TRIM(REPLACE(
                    SUBSTRING(SUBSTRING_INDEX(IN_instructoremail, '|', v_i),
                        LENGTH(SUBSTRING_INDEX(IN_instructoremail, '|', v_i - 1)) + 1),
                    '|', ''
                ));

                IF v_InstructorName != '' AND v_InstructorEmail != '' THEN
                    -- Check if user exists
                    SELECT `Idx` INTO v_UserIdx
                    FROM `UserAccounts`
                    WHERE `Email` = v_InstructorEmail
                    LIMIT 1;

                    IF v_UserIdx IS NULL THEN
                        -- Insert new user
                        INSERT INTO `UserAccounts` (`Email`, `Name`)
                        VALUES (v_InstructorEmail, v_InstructorName);

                        SET v_UserIdx = LAST_INSERT_ID();
                    END IF;

                    -- Link instructor to course (no duplicate check needed since we deleted all above)
                    INSERT INTO `AVCoursesInstructors` (`AVCourseIdx`, `Instructor`)
                    VALUES (v_AVCourseIDX, v_UserIdx);
                END IF;

                SET v_i = v_i + 1;
            END WHILE;
        END IF;

        -- Process instructor by name only (if email not provided)
        IF IN_instructorname != '' AND IN_instructoremail = '' THEN
            SELECT `Idx` INTO v_UserIdx
            FROM `UserAccounts`
            WHERE `Name` = IN_instructorname
            LIMIT 1;

            IF v_UserIdx IS NOT NULL THEN
                INSERT INTO `AVCoursesInstructors` (`AVCourseIdx`, `Instructor`)
                VALUES (v_AVCourseIDX, v_UserIdx);
            END IF;
        END IF;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAVCourses_SynEnd` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAVCourses_SynEnd`(IN IN_semester INT)
BEGIN
	START TRANSACTION;

    # remove all courses that are not synced
    DELETE FROM `AVCourses` WHERE `Semester`=IN_semester AND `Sync`=1;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddAVCourses_SynStart` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddAVCourses_SynStart`(IN IN_semester INT)
BEGIN
	START TRANSACTION;

    # set all courses that are in synchronization process
	UPDATE `AVCourses` SET `Sync`=1 WHERE `Semester`=IN_semester;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddBatchPIs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddBatchPIs`(
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT,
    IN IN_CourseSubject VARCHAR(5),
    IN IN_CourseNum VARCHAR(5),
    IN IN_StudentOutcome VARCHAR(50),
    IN IN_PerformanceIndicator VARCHAR(20)
)
BEGIN
    DECLARE v_CourseIdx INT;
    DECLARE v_SOIdx INT;
    DECLARE v_GPIIdx INT;
    DECLARE v_NewAbetCourseIdx INT;

    -- Modified error handler to handle NULL case
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;

        -- Initialize variables with default values
        SET @sqlstate = '00000';
        SET @errno = 0;
        SET @text = 'Unknown error';

        -- Get the actual error information if available
        GET DIAGNOSTICS CONDITION 1
            @sqlstate = RETURNED_SQLSTATE,
            @errno = MYSQL_ERRNO,
            @text = MESSAGE_TEXT;

        SET @full_error = CONCAT('Error: ', @errno, ' (', @sqlstate, '): ', @text);
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = @full_error;
    END;

    -- Rest of your procedure remains exactly the same
    START TRANSACTION;

    -- Get CourseIdx using subject and number through join
    SELECT cmc.CourseIdx INTO v_CourseIdx
    FROM CourseMapping_Courses cmc
             INNER JOIN Courses c ON cmc.CourseIdx = c.Idx
    WHERE c.Subject = IN_CourseSubject
      AND c.Num = IN_CourseNum
      AND cmc.AcademicYear = IN_AcademicYear
      AND cmc.AcademicProgram = IN_AcademicProgram
        LIMIT 1;

    IF v_CourseIdx IS NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Course not found';
    END IF;

        -- Get SOIdx
    SELECT Idx INTO v_SOIdx
    FROM StudentOutcomes
    WHERE SO = IN_StudentOutcome
      AND AcademicYear = IN_AcademicYear
      AND AcademicProgram = IN_AcademicProgram
        LIMIT 1;

    IF v_SOIdx IS NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Student Outcome not found';
    END IF;

        -- Get GPIIdx from GeneralPerformanceIndicators
    SELECT Idx INTO v_GPIIdx
    FROM GeneralPerformanceIndicators
    WHERE SOIdx = v_SOIdx
      AND GPI = IN_PerformanceIndicator
      AND AcademicYear = IN_AcademicYear
      AND AcademicProgram = IN_AcademicProgram
        LIMIT 1;

    IF v_GPIIdx IS NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Performance Indicator not found';
    END IF;

        -- Check for existing mapping in CourseMapping_Courses
    IF NOT EXISTS (
        SELECT 1 FROM CourseMapping_Courses
        WHERE CourseIdx = v_CourseIdx
        AND AcademicYear = IN_AcademicYear
        AND AcademicProgram = IN_AcademicProgram
    ) THEN
        -- Insert into CourseMapping_Courses
        INSERT INTO CourseMapping_Courses (
            AcademicYear,
            CourseIdx,
            Level,
            AcademicProgram
        ) VALUES (
            IN_AcademicYear,
            v_CourseIdx,
            1,
            IN_AcademicProgram
        );

        SET v_NewAbetCourseIdx = LAST_INSERT_ID();
    ELSE
            -- Get existing AbetCourseIdx
    SELECT Idx INTO v_NewAbetCourseIdx
    FROM CourseMapping_Courses
    WHERE CourseIdx = v_CourseIdx
      AND AcademicYear = IN_AcademicYear
      AND AcademicProgram = IN_AcademicProgram;
    END IF;

    -- Check if SO mapping already exists
    IF NOT EXISTS (
        SELECT 1 FROM CourseMapping_SOs
        WHERE SOIdx = v_SOIdx
        AND AbetCourseIdx = v_NewAbetCourseIdx
        AND AcademicYear = IN_AcademicYear
        AND AcademicProgram = IN_AcademicProgram
    ) THEN
        -- Insert into CourseMapping_SOs
        INSERT INTO CourseMapping_SOs (
            SOIdx,
            AbetCourseIdx,
            AcademicYear,
            AcademicProgram
        ) VALUES (
            v_SOIdx,
            v_NewAbetCourseIdx,
            IN_AcademicYear,
            IN_AcademicProgram
        );
    END IF;

    -- Check if GPI mapping already exists
    IF NOT EXISTS (
        SELECT 1 FROM CourseMapping_GPIs
        WHERE GPIIdx = v_GPIIdx
        AND AbetCourseIdx = v_NewAbetCourseIdx
        AND SOIdx = v_SOIdx
        AND AcademicYear = IN_AcademicYear
        AND AcademicProgram = IN_AcademicProgram
    ) THEN
        -- Insert into CourseMapping_GPIs
        INSERT INTO CourseMapping_GPIs (
            GPIIdx,
            AbetCourseIdx,
            SOIdx,
            AcademicYear,
            AcademicProgram
        ) VALUES (
            v_GPIIdx,
            v_NewAbetCourseIdx,
            v_SOIdx,
            IN_AcademicYear,
            IN_AcademicProgram
        );
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddCourse` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddCourse`(
    IN IN_Subject VARCHAR(5),
    IN IN_Num VARCHAR(5),
    IN IN_Title VARCHAR(200),
    IN IN_Credits VARCHAR(20)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `Courses` WHERE `Subject` = IN_Subject AND `Num` = IN_Num AND `Title` = IN_Title) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already
    END IF;

    INSERT INTO `Courses`(`Subject`, `Num`, `Title`, `TitleUniv`, `Credits`)
    VALUES (IN_Subject, IN_Num, IN_Title, IN_Title, IN_Credits);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddCourseAssessmentMaterials` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddCourseAssessmentMaterials`(
    IN IN_AvailableCourseIdx INT,
    IN AssmntType VARCHAR(256),
    IN AssmntNum INT,
    IN IN_AssmntSample VARCHAR(256)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Insert assessment
    INSERT INTO `AVCourses_CrsMaterials`(`AvailableCourseIdx`,
                                     `AssmntType`, `AssmntNum`,
                                     `AssmntSample`)
    VALUES (IN_AvailableCourseIdx, AssmntType, AssmntNum, IN_AssmntSample);

    -- Update the record to indicate the course binder material has been changed.
    UPDATE `AVCourses`
    SET `crsbinder_updated` = 1
    WHERE `Idx` = IN_AvailableCourseIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddCourseInstructor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddCourseInstructor`(
    IN IN_AvcIdx INT,
    IN IN_UserIdx INT,
    IN IN_IsPrimary INT
)
BEGIN
    DECLARE v_instructorString TEXT;
    DECLARE v_primaryEmail VARCHAR(255);
    DECLARE v_currentEmail VARCHAR(255);

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if this instructor is already assigned to this course
    IF EXISTS (SELECT 1 FROM `AVCoursesInstructors`
               WHERE `AVCourseIdx` = IN_AvcIdx AND `Instructor` = IN_UserIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00000002'; -- Instructor already assigned
    END IF;

    -- Insert new instructor
    INSERT INTO `AVCoursesInstructors` (`AVCourseIdx`, `Instructor`)
    VALUES (IN_AvcIdx, IN_UserIdx);

    -- Get all instructors for this course with their names (concatenated)
    SELECT GROUP_CONCAT(ua.`Name` ORDER BY ua.`Name` ASC SEPARATOR ', ')
    INTO v_instructorString
    FROM `AVCoursesInstructors` aci
    LEFT JOIN `UserAccounts` ua ON aci.`Instructor` = ua.`Idx`
    WHERE aci.`AVCourseIdx` = IN_AvcIdx AND ua.`Name` IS NOT NULL;

    -- Determine primary instructor email
    IF IN_IsPrimary = 1 AND IN_UserIdx > 0 THEN
        -- Get email of the new primary instructor
        SELECT `Email` INTO v_primaryEmail
        FROM `UserAccounts`
        WHERE `Idx` = IN_UserIdx;
    ELSE
        -- Keep existing primary email
        SELECT `InstructorEmail` INTO v_currentEmail
        FROM `AVCourses`
        WHERE `Idx` = IN_AvcIdx;

        SET v_primaryEmail = v_currentEmail;
    END IF;

    -- Update AVCourses table
    UPDATE `AVCourses`
    SET `Instructor` = IFNULL(v_instructorString, ''),
        `InstructorEmail` = IFNULL(v_primaryEmail, ''),
        `IsManuallyEdited` = 1
    WHERE `Idx` = IN_AvcIdx;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddCourseMapping_Courses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddCourseMapping_Courses`(
    IN IN_AcademicYear INT,
    IN IN_CourseIdx INT,
    IN IN_ABETSyllabusIdx INT,
    IN IN_AcademicProgram INT
)
BEGIN
    DECLARE v_Requirement VARCHAR(255) DEFAULT NULL;

    START TRANSACTION;

    IF IN_ABETSyllabusIdx IS NOT NULL THEN
        SELECT `Requirement` INTO v_Requirement FROM `AbetSyllabus`
        WHERE `Idx` = IN_ABETSyllabusIdx;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM `CourseMapping_Courses`
        WHERE `AcademicYear`=IN_AcademicYear
          AND `CourseIdx`=IN_CourseIdx
          AND `AcademicProgram`=IN_AcademicProgram) THEN
    BEGIN

        INSERT INTO `CourseMapping_Courses`(`AcademicYear`, `CourseIdx`, `Requirement`, `AcademicProgram`, `AbetSyllabus`)
        VALUES (IN_AcademicYear, IN_CourseIdx, v_Requirement, IN_AcademicProgram, IN_ABETSyllabusIdx);

    END;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddCourseMapping_GPI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddCourseMapping_GPI`(IN IN_GPIIdx INT, IN IN_AbetCourseIdx INT,
    IN IN_SOIdx INT, IN IN_AcademicYear INT, IN IN_AcademicProgram INT, IN IN_GPIChecked VARCHAR(5) )
BEGIN
	START TRANSACTION;

	IF IN_GPIChecked = 'true' THEN # if GPIcheck is enabled
    BEGIN
    	IF (SELECT COUNT(*) FROM `CourseMapping_GPIs`
    	    WHERE `GPIIdx`=IN_GPIIdx AND `AbetCourseIdx`=IN_AbetCourseIdx
    	        AND `SOIdx`=IN_SOIdx AND `AcademicYear`=IN_AcademicYear
    	        AND `AcademicProgram`=IN_AcademicProgram)=0 THEN # no item exists
    	BEGIN
    	    # Insert PI
        	INSERT INTO `CourseMapping_GPIs`(`GPIIdx`, `AbetCourseIdx`, `SOIdx`, `AcademicYear`, `AcademicProgram`)
        	VALUES (IN_GPIIdx, IN_AbetCourseIdx, IN_SOIdx, IN_AcademicYear, IN_AcademicProgram);
    	END;
    	END IF;
    END;
    ELSE    # if GPIcheck is not enabled
    BEGIN
            DELETE FROM `CourseMapping_GPIs`
            WHERE `AbetCourseIdx`=IN_AbetCourseIdx AND `SOIdx`=IN_SOIdx
                AND `GPIIdx`=IN_GPIIdx AND `AcademicYear`=IN_AcademicYear
                AND `AcademicProgram`=IN_AcademicProgram LIMIT 1;
    END;
    END IF;
    
	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddCourseMapping_SOs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddCourseMapping_SOs`(IN IN_AbetCourseIdx INT, IN IN_SOIdx INT,
    IN IN_AcademicYear INT, IN IN_AcademicProgram INT, IN IN_SOChecked VARCHAR(5) )
BEGIN
	START TRANSACTION;
	
	IF IN_SOChecked = 'true' THEN # Student outcome is checked
    BEGIN
    	IF (SELECT COUNT(*) FROM `CourseMapping_SOs`
    	    WHERE `AbetCourseIdx`=IN_AbetCourseIdx AND `SOIdx`=IN_SOIdx
    	        AND `AcademicYear`=IN_AcademicYear AND `AcademicProgram`=IN_AcademicProgram)=0 THEN # no item exists
    	BEGIN
        	INSERT INTO `CourseMapping_SOs`(`AbetCourseIdx`, `SOIdx`, `AcademicYear`, `AcademicProgram`)
        	    VALUES (IN_AbetCourseIdx, IN_SOIdx, IN_AcademicYear, IN_AcademicProgram);
    	END;
    	END IF;
    END;
    ELSE    # Student outcome is not checked
    BEGIN
            DELETE FROM `CourseMapping_GPIs`
            WHERE `AbetCourseIdx`=IN_AbetCourseIdx AND `SOIdx`=IN_SOIdx
            AND `AcademicYear`=IN_AcademicYear AND `AcademicProgram`=IN_AcademicProgram;

            DELETE FROM `CourseMapping_SOs`
            WHERE `AbetCourseIdx`=IN_AbetCourseIdx AND `SOIdx`=IN_SOIdx
            AND `AcademicYear`=IN_AcademicYear AND `AcademicProgram`=IN_AcademicProgram LIMIT 1;
    END;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddInstructionalMaterial` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddInstructionalMaterial`(
    IN IN_AvailableCourseIdx INT,
    IN IN_MaterialType VARCHAR(256),
    IN IN_MateiralSample VARCHAR(256)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Insert assessment
    INSERT INTO `AVCourses_InstMaterials`(`AvailableCourseIdx`, `MaterialType`, `MaterialSample`)
    VALUES (IN_AvailableCourseIdx, IN_MaterialType, IN_MateiralSample);

    -- Update the record to indicate the course binder material has been changed.
    UPDATE `AVCourses`
    SET `crsbinder_updated` = 1
    WHERE `Idx` = IN_AvailableCourseIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddPI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddPI`(IN IN_AcademicYear INT, IN IN_SOIdx INT,
    IN IN_PI VARCHAR(50), IN IN_Description VARCHAR(2048), IN IN_AcademicProgram INT)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `GeneralPerformanceIndicators`
            WHERE `AcademicYear`=IN_AcademicYear
            AND `SOIdx`=IN_SOIdx AND `GPI`=IN_PI
            AND `AcademicProgram`=IN_AcademicProgram) THEN
            SIGNAL SQLSTATE '45000'
            SET  MESSAGE_TEXT = '0x00200011'; -- The same PI exists already

    ELSE
        BEGIN

            -- update the student outcome information
            INSERT INTO `GeneralPerformanceIndicators`
                (`AcademicYear`, `SOIdx`, `GPI`, `Description`, `AcademicProgram`)
            VALUES (IN_AcademicYear, IN_SOIdx, IN_PI,
                    IN_Description, IN_AcademicProgram);

            SELECT LAST_INSERT_ID() INTO @IN_PIIdx;

            -- Call the separate stored procedure for Assessment Master Rubrics
            CALL SP_AddAssessmentMasterRubrics(IN_AcademicYear, @IN_PIIdx, IN_AcademicProgram);

        END;
    END IF;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddPosition` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddPosition`(
    IN IN_PositionName VARCHAR(200)
)
BEGIN
    DECLARE randomIndex INT;
    DECLARE attemptCount INT DEFAULT 0;
    DECLARE MAX_ATTEMPTS INT DEFAULT 10;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `Positions` WHERE `Name` = IN_PositionName) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already
    END IF;

    -- Attempt to insert with unique random ID
    WHILE attemptCount < MAX_ATTEMPTS DO
        SET randomIndex = FLOOR(1 + RAND() * 1000000);
    BEGIN
        DECLARE CONTINUE HANDLER FOR 1062
        BEGIN
            SET attemptCount = attemptCount + 1;
        END;

        INSERT INTO `Positions` (`IDX`, `Name`) VALUES (randomIndex, IN_PositionName);

        IF ROW_COUNT() > 0 THEN
            SET attemptCount = MAX_ATTEMPTS; -- Exit loop on successful insert
        END IF;
    END;
    END WHILE;

    -- Check if insertion was successful
    IF attemptCount = MAX_ATTEMPTS AND
       NOT EXISTS (SELECT 1 FROM `Positions` WHERE `IDX` = randomIndex AND `Name` = IN_PositionName) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Failed to insert unique position after maximum attempts';
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddProgram`(
    IN IN_ProgramName VARCHAR(200),
    IN IN_DegreeName VARCHAR(20),
    IN IN_DepartmentNameCode INT
)
BEGIN
    DECLARE randomIndex INT;
    DECLARE attemptCount INT DEFAULT 0;
    DECLARE MAX_ATTEMPTS INT DEFAULT 10;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `AcademicPrograms` WHERE `Name` = IN_ProgramName) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already
    END IF;

    -- Attempt to insert with unique random ID
    WHILE attemptCount < MAX_ATTEMPTS DO
        SET randomIndex = FLOOR(1 + RAND() * 1000000);
    BEGIN
        DECLARE CONTINUE HANDLER FOR 1062
        BEGIN
            SET attemptCount = attemptCount + 1;
        END;

        INSERT INTO `AcademicPrograms` (`Idx`, `Name`, `Degree`, `Department`)
        VALUES (randomIndex, IN_ProgramName, IN_DegreeName, IN_DepartmentNameCode);

        IF ROW_COUNT() > 0 THEN
            SET attemptCount = MAX_ATTEMPTS; -- Exit loop on successful insert
        END IF;
    END;
    END WHILE;

    -- Check if insertion was successful
    IF attemptCount = MAX_ATTEMPTS AND
       NOT EXISTS (SELECT 1 FROM `AcademicPrograms` WHERE `Idx` = randomIndex AND `Name` = IN_ProgramName) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Failed to insert unique name after maximum attempts';
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddSemesterInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddSemesterInfo`(
    IN p_SemesterCode INT,
    IN p_Explanation VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Check if duplicate entry error
        DECLARE error_msg VARCHAR(255);
        GET DIAGNOSTICS CONDITION 1 error_msg = MESSAGE_TEXT;
        
        IF error_msg LIKE '%Duplicate entry%' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x00200011';
        ELSE
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x00000500';
        END IF;
        ROLLBACK;
    END;
    
    START TRANSACTION;
    
    -- Check if semester code already exists
    IF EXISTS (SELECT 1 FROM Semesters WHERE SemesterCode = p_SemesterCode) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x00200011';
    END IF;
    
    -- Insert new semester
    INSERT INTO Semesters (SemesterCode, Explanation)
    VALUES (p_SemesterCode, p_Explanation);
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddSO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddSO`(
    IN IN_SO VARCHAR(50),
    IN IN_Description VARCHAR(2048),
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `StudentOutcomes`
                        WHERE `AcademicYear`=IN_AcademicYear
                             AND `SO`=IN_SO
                             AND `AcademicProgram`=IN_AcademicProgram) THEN
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x00200011'; -- The same SO exists already

    ELSE
        INSERT INTO `StudentOutcomes`(`AcademicYear`, `SO`, `Description`, `AcademicProgram`)
            VALUES (IN_AcademicYear, IN_SO, IN_Description, IN_AcademicProgram);

    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddStudentToClassRoster` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddStudentToClassRoster`(
    IN IN_AvailableCourseIdx INT,
    IN IN_DB_EncryptionKey VARCHAR(255),
    IN IN_StudentDataJSON LONGTEXT
)
BEGIN
    DECLARE v_StudentCount INT DEFAULT 0;
    DECLARE v_StudentIndex INT DEFAULT 0;
    DECLARE v_StudentNo INT;
    DECLARE v_Name VARCHAR(256);
    DECLARE v_Major VARCHAR(256);
    DECLARE v_AcademicProgramIdx INT;
    DECLARE v_AcademicProgramIdxStr VARCHAR(50);

    -- Error handling: rollback transaction on any SQL exception
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Get the count of students in the JSON array
    SET v_StudentCount = JSON_LENGTH(IN_StudentDataJSON);

    -- Update the count of students as student enrollment
    UPDATE `AVCourses` SET `Actual` =  v_StudentCount
    WHERE `Idx`=IN_AvailableCourseIdx;

    -- Loop through each student in the JSON array
    WHILE v_StudentIndex < v_StudentCount DO
        -- Extract name and major from JSON
        SET v_Name = JSON_UNQUOTE(JSON_EXTRACT(IN_StudentDataJSON, CONCAT('$[', v_StudentIndex, '].name')));
        SET v_Major = JSON_UNQUOTE(JSON_EXTRACT(IN_StudentDataJSON, CONCAT('$[', v_StudentIndex, '].major')));

        -- Extract academicProgramIdx as string first, then convert to INT or NULL
        SET v_AcademicProgramIdxStr = JSON_UNQUOTE(JSON_EXTRACT(IN_StudentDataJSON, CONCAT('$[', v_StudentIndex, '].academicProgramIdx')));

        -- Convert to INT, handling 'null' string as SQL NULL
        IF v_AcademicProgramIdxStr IS NULL OR v_AcademicProgramIdxStr = 'null' OR TRIM(v_AcademicProgramIdxStr) = '' THEN
            SET v_AcademicProgramIdx = NULL;
        ELSE
            SET v_AcademicProgramIdx = CAST(v_AcademicProgramIdxStr AS UNSIGNED);
        END IF;

        -- Convert empty major to NULL for consistency
        IF v_Major IS NOT NULL AND TRIM(v_Major) = '' THEN
            SET v_Major = NULL;
        END IF;

        -- Only process if name is not null/empty
        -- major and academicProgramIdx can be NULL or empty
        IF v_Name IS NOT NULL AND TRIM(v_Name) != '' THEN

            -- Generate StudentNo based on index (sequential: 1, 2, 3, ...)
            SET v_StudentNo = v_StudentIndex + 1;

            -- Check if record exists for this student and course combination
            IF EXISTS (SELECT 1 FROM `ClassRoster`
                WHERE `StudentNo` = v_StudentNo
                AND `AvailableCourseIdx` = IN_AvailableCourseIdx) THEN

                -- Update existing record with encrypted student name
                -- NOTE: IsDropped flag is NOT modified - preserves existing status
                UPDATE `ClassRoster`
                SET `StudentName` = AES_ENCRYPT(v_Name, IN_DB_EncryptionKey),
                    `StudentMajor` = v_Major,
                    `AcademicProgramIdx` = v_AcademicProgramIdx
                WHERE `StudentNo` = v_StudentNo
                  AND `AvailableCourseIdx` = IN_AvailableCourseIdx;

            ELSE
                -- Insert new record with encrypted student name
                -- major and academicProgramIdx can be NULL
                INSERT INTO `ClassRoster`(
                    `AvailableCourseIdx`,
                    `StudentNo`,
                    `StudentName`,
                    `StudentMajor`,
                    `AcademicProgramIdx`,
                    `IsDropped`
                )
                VALUES (
                    IN_AvailableCourseIdx,
                    v_StudentNo,
                    AES_ENCRYPT(v_Name, IN_DB_EncryptionKey),
                    v_Major,  -- Can be NULL
                    v_AcademicProgramIdx,  -- Can be NULL
                    0      -- New students default to IsDropped = 0
                );
            END IF;

        END IF;

        SET v_StudentIndex = v_StudentIndex + 1;
    END WHILE;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddSubject` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddSubject`(
    IN IN_SubjectName VARCHAR(50),
    IN IN_DepartmentNameCode INT
)
BEGIN
    DECLARE randomIndex INT;
    DECLARE attemptCount INT DEFAULT 0;
    DECLARE MAX_ATTEMPTS INT DEFAULT 10;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing subject name
    IF EXISTS (SELECT 1 FROM `Subjects` WHERE `Name` = IN_SubjectName) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already
    END IF;

    -- Attempt to insert with unique random ID
    WHILE attemptCount < MAX_ATTEMPTS DO
        SET randomIndex = FLOOR(1 + RAND() * 1000000);
    BEGIN
        DECLARE CONTINUE HANDLER FOR 1062
        BEGIN
            SET attemptCount = attemptCount + 1;
        END;

        INSERT INTO `Subjects` (`Idx`, `Name`, `Department`)
        VALUES (randomIndex, IN_SubjectName, IN_DepartmentNameCode);

        IF ROW_COUNT() > 0 THEN
            SET attemptCount = MAX_ATTEMPTS; -- Exit loop on successful insert
        END IF;
    END;
    END WHILE;

    -- Check if insertion was successful
    IF attemptCount = MAX_ATTEMPTS AND
       NOT EXISTS (SELECT 1 FROM `Subjects` WHERE `Idx` = randomIndex AND `Name` = IN_SubjectName) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Failed to insert unique name after maximum attempts';
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_AddUserAccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_AddUserAccount`(
    IN IN_Name VARCHAR(50),
    IN IN_PWD VARCHAR(256),
    IN IN_Email VARCHAR(50),
    IN IN_Position INT,
    IN IN_Affiliation INT,
    IN IN_AccessControl VARCHAR(512))
BEGIN
    DECLARE InsertedUserAccountIdx INT;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `UserAccounts` WHERE `Email`=IN_Email) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200011'; -- info exits

    ELSEIF EXISTS (SELECT 1 FROM `UserAccounts` WHERE `Name`=IN_Name) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- info exits

    ELSE
        BEGIN

            INSERT INTO `UserAccounts` (`Email`, `PWD`, `Name`, `Position`, `Affiliation`)
                VALUES (IN_Email, IN_PWD, IN_Name, IN_Position, IN_Affiliation);

            # fetch last inserted id
            SELECT LAST_INSERT_ID() INTO InsertedUserAccountIdx;

            CALL SP_UpdateUserAccessControl(InsertedUserAccountIdx, IN_AccessControl);

        END;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_Assign_Assistant_ABETCrs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_Assign_Assistant_ABETCrs`(
    IN p_ABETCourseIdx INT,
    IN p_NewlyCheckedList TEXT,
    IN p_NewlyUncheckedList TEXT
)
BEGIN
    DECLARE v_error_message VARCHAR(500);
    DECLARE v_is_primary INT DEFAULT 0;
    DECLARE v_is_reference INT DEFAULT 0;
    DECLARE v_primary_course_idx INT DEFAULT NULL;

    -- Declare error handler
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        GET DIAGNOSTICS CONDITION 1
            v_error_message = MESSAGE_TEXT;
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_error_message;
    END;

    -- Validation: Check if ABETCourseIdx exists
    IF NOT EXISTS (SELECT 1 FROM `AbetCourses` WHERE `Idx` = p_ABETCourseIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid ABETCourseIdx: Course does not exist';
    END IF;

    -- Validate input lists contain only numbers and commas
    IF p_NewlyCheckedList IS NOT NULL AND p_NewlyCheckedList REGEXP '[^0-9,]' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid NewlyCheckedList: Must contain only numbers and commas';
    END IF;

    IF p_NewlyUncheckedList IS NOT NULL AND p_NewlyUncheckedList REGEXP '[^0-9,]' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid NewlyUncheckedList: Must contain only numbers and commas';
    END IF;

    START TRANSACTION;

    -- Determine if this course is a primary course (has references pointing to it)
    SELECT COUNT(*) INTO v_is_primary
    FROM `AbetCourses`
    WHERE `Reference` = p_ABETCourseIdx;

    -- Determine if this course is a reference course (points to a primary)
    SELECT `Reference` INTO v_primary_course_idx
    FROM `AbetCourses`
    WHERE `Idx` = p_ABETCourseIdx;

    IF v_primary_course_idx IS NOT NULL THEN
        SET v_is_reference = 1;
    END IF;

    -- Process newly unchecked assistants (remove them)
    IF p_NewlyUncheckedList IS NOT NULL AND TRIM(p_NewlyUncheckedList) != '' THEN
        -- Remove from current course
        SET @sql_delete = CONCAT(
            'DELETE FROM `AbetCourses_Assistants` ',
            'WHERE `AbetCourseIdx` = ', p_ABETCourseIdx,
            ' AND `Assistant` IN (', p_NewlyUncheckedList, ')'
        );
        PREPARE stmt_delete FROM @sql_delete;
        EXECUTE stmt_delete;
        DEALLOCATE PREPARE stmt_delete;

        -- If this is a primary course, remove from all reference courses
        IF v_is_primary > 0 THEN
            SET @sql_delete_refs = CONCAT(
                'DELETE FROM `AbetCourses_Assistants` ',
                'WHERE `AbetCourseIdx` IN (SELECT `Idx` FROM `AbetCourses` WHERE `Reference` = ', p_ABETCourseIdx, ') ',
                'AND `Assistant` IN (', p_NewlyUncheckedList, ')'
            );
            PREPARE stmt_delete_refs FROM @sql_delete_refs;
            EXECUTE stmt_delete_refs;
            DEALLOCATE PREPARE stmt_delete_refs;
        END IF;

        -- If this is a reference course, remove from the primary course
        IF v_is_reference = 1 THEN
            SET @sql_delete_primary = CONCAT(
                'DELETE FROM `AbetCourses_Assistants` ',
                'WHERE `AbetCourseIdx` = ', v_primary_course_idx,
                ' AND `Assistant` IN (', p_NewlyUncheckedList, ')'
            );
            PREPARE stmt_delete_primary FROM @sql_delete_primary;
            EXECUTE stmt_delete_primary;
            DEALLOCATE PREPARE stmt_delete_primary;

            -- Also remove from all other reference courses pointing to the same primary
            SET @sql_delete_siblings = CONCAT(
                'DELETE FROM `AbetCourses_Assistants` ',
                'WHERE `AbetCourseIdx` IN (SELECT `Idx` FROM `AbetCourses` WHERE `Reference` = ', v_primary_course_idx, ' AND `Idx` != ', p_ABETCourseIdx, ') ',
                'AND `Assistant` IN (', p_NewlyUncheckedList, ')'
            );
            PREPARE stmt_delete_siblings FROM @sql_delete_siblings;
            EXECUTE stmt_delete_siblings;
            DEALLOCATE PREPARE stmt_delete_siblings;
        END IF;
    END IF;

    -- Process newly checked assistants (add them)
    IF p_NewlyCheckedList IS NOT NULL AND TRIM(p_NewlyCheckedList) != '' THEN
        SET @values = CONCAT(
            '(', p_ABETCourseIdx, ',',
            REPLACE(TRIM(p_NewlyCheckedList), ',', CONCAT('),(', p_ABETCourseIdx, ',')),
            ')'
        );

        -- Add to current course
        SET @sql_insert = CONCAT(
            'INSERT INTO `AbetCourses_Assistants` (`AbetCourseIdx`, `Assistant`) ',
            'VALUES ', @values,
            ' ON DUPLICATE KEY UPDATE `AbetCourseIdx` = `AbetCourseIdx`'
        );
        PREPARE stmt_insert FROM @sql_insert;
        EXECUTE stmt_insert;
        DEALLOCATE PREPARE stmt_insert;

        -- If this is a primary course, add to all reference courses
        IF v_is_primary > 0 THEN
            SET @sql_insert_refs = CONCAT(
                'INSERT INTO `AbetCourses_Assistants` (`AbetCourseIdx`, `Assistant`) ',
                'SELECT `Idx`, assistant_id FROM `AbetCourses` ',
                'CROSS JOIN (SELECT ', REPLACE(TRIM(p_NewlyCheckedList), ',', ' AS assistant_id UNION ALL SELECT '), ' AS assistant_id) AS assistants ',
                'WHERE `Reference` = ', p_ABETCourseIdx,
                ' ON DUPLICATE KEY UPDATE `AbetCourseIdx` = `AbetCourseIdx`'
            );
            PREPARE stmt_insert_refs FROM @sql_insert_refs;
            EXECUTE stmt_insert_refs;
            DEALLOCATE PREPARE stmt_insert_refs;
        END IF;

        -- If this is a reference course, add to the primary course
        IF v_is_reference = 1 THEN
            SET @values_primary = CONCAT(
                '(', v_primary_course_idx, ',',
                REPLACE(TRIM(p_NewlyCheckedList), ',', CONCAT('),(', v_primary_course_idx, ',')),
                ')'
            );

            SET @sql_insert_primary = CONCAT(
                'INSERT INTO `AbetCourses_Assistants` (`AbetCourseIdx`, `Assistant`) ',
                'VALUES ', @values_primary,
                ' ON DUPLICATE KEY UPDATE `AbetCourseIdx` = `AbetCourseIdx`'
            );
            PREPARE stmt_insert_primary FROM @sql_insert_primary;
            EXECUTE stmt_insert_primary;
            DEALLOCATE PREPARE stmt_insert_primary;

            -- Also add to all other reference courses pointing to the same primary
            SET @sql_insert_siblings = CONCAT(
                'INSERT INTO `AbetCourses_Assistants` (`AbetCourseIdx`, `Assistant`) ',
                'SELECT `Idx`, assistant_id FROM `AbetCourses` ',
                'CROSS JOIN (SELECT ', REPLACE(TRIM(p_NewlyCheckedList), ',', ' AS assistant_id UNION ALL SELECT '), ' AS assistant_id) AS assistants ',
                'WHERE `Reference` = ', v_primary_course_idx, ' AND `Idx` != ', p_ABETCourseIdx,
                ' ON DUPLICATE KEY UPDATE `AbetCourseIdx` = `AbetCourseIdx`'
            );
            PREPARE stmt_insert_siblings FROM @sql_insert_siblings;
            EXECUTE stmt_insert_siblings;
            DEALLOCATE PREPARE stmt_insert_siblings;
        END IF;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_Assign_Assistant_CollectCrsMaterials` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_Assign_Assistant_CollectCrsMaterials`(
    IN p_AVCourseIdx INT,
    IN p_NewlyCheckedList TEXT,
    IN p_NewlyUncheckedList TEXT
)
BEGIN
    DECLARE exit_handler BOOLEAN DEFAULT FALSE;

    -- Declare error handler
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        SET exit_handler = TRUE;
        ROLLBACK;
    END;

    START TRANSACTION;

    -- Process newly unchecked assistants (remove them)
    IF p_NewlyUncheckedList IS NOT NULL AND p_NewlyUncheckedList != '' THEN
        SET @sql_delete = CONCAT('DELETE FROM `AVCourses_Assistants`
                                  WHERE `AVCourseIdx` = ', p_AVCourseIdx,
                                 ' AND `Assistant` IN (', p_NewlyUncheckedList, ')');
        PREPARE stmt_delete FROM @sql_delete;
        EXECUTE stmt_delete;
        DEALLOCATE PREPARE stmt_delete;
    END IF;

    -- Process newly checked assistants (add them)
    IF p_NewlyCheckedList IS NOT NULL AND p_NewlyCheckedList != '' THEN
        -- Simpler approach using direct string manipulation
        SET @values = '';
        SET @temp_checked_list = p_NewlyCheckedList;

        -- Loop through comma-separated values and build the VALUES clause
        SET @values = CONCAT('(', p_AVCourseIdx, ',',
                            REPLACE(@temp_checked_list, ',', CONCAT('),(', p_AVCourseIdx, ',')),
                            ')');

        IF @values IS NOT NULL AND @values != '' THEN
            SET @sql_insert = CONCAT('INSERT INTO `AVCourses_Assistants` (`AVCourseIdx`, `Assistant`)
                                     VALUES ', @values,
                                    ' ON DUPLICATE KEY UPDATE `AVCourseIdx` = VALUES(`AVCourseIdx`)');
            PREPARE stmt_insert FROM @sql_insert;
            EXECUTE stmt_insert;
            DEALLOCATE PREPARE stmt_insert;
        END IF;
    END IF;

    -- If no errors occurred, commit the transaction
    IF NOT exit_handler THEN
        COMMIT;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ChangeUserPassword` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ChangeUserPassword`(
    IN IN_Idx INT,
    IN IN_OldPWD_Encrypted VARCHAR(255),
    IN IN_NewPWD_Encrypted VARCHAR(255)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if user exists with the correct password
    IF NOT EXISTS (SELECT 1 FROM `UserAccounts` WHERE `Idx`=IN_Idx AND `PWD`=IN_OldPWD_Encrypted) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00201000'; -- Current Password is not matched
    END IF;

    -- Update the password
    UPDATE `UserAccounts`
    SET `PWD`=IN_NewPWD_Encrypted, ResetPWD=0, LoginFails=0
    WHERE `Idx`=IN_Idx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CheckCourseMaterialsForDuplication` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CheckCourseMaterialsForDuplication`(
    IN IN_SourceAvcIdx INT,
    IN IN_TargetAvcIdx INT
)
BEGIN
    DECLARE v_SourceAVCourseExists INT DEFAULT 0;
    DECLARE v_TargetAVCourseExists INT DEFAULT 0;
    DECLARE v_SourceMaterialCount INT DEFAULT 0;
    DECLARE v_TargetMaterialCount INT DEFAULT 0;

    -- Validate that source available course exists
    SELECT COUNT(*) INTO v_SourceAVCourseExists
    FROM `AVCourses`
    WHERE `Idx` = IN_SourceAvcIdx;

    IF v_SourceAVCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- Source available course does not exist
    END IF;

    -- Validate that target available course exists
    SELECT COUNT(*) INTO v_TargetAVCourseExists
    FROM `AVCourses`
    WHERE `Idx` = IN_TargetAvcIdx;

    IF v_TargetAVCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- Target available course does not exist
    END IF;

    -- Check if source has materials
    SELECT
        (SELECT COUNT(*) FROM `AVCourses_InstMaterials` WHERE `AvailableCourseIdx` = IN_SourceAvcIdx) +
        (SELECT COUNT(*) FROM `AVCourses_CrsMaterials` WHERE `AvailableCourseIdx` = IN_SourceAvcIdx)
    INTO v_SourceMaterialCount;

    IF v_SourceMaterialCount = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x09500011'; -- Source course has no materials to duplicate
    END IF;

    -- Check if target already has materials
    SELECT
        (SELECT COUNT(*) FROM `AVCourses_InstMaterials` WHERE `AvailableCourseIdx` = IN_TargetAvcIdx) +
        (SELECT COUNT(*) FROM `AVCourses_CrsMaterials` WHERE `AvailableCourseIdx` = IN_TargetAvcIdx)
    INTO v_TargetMaterialCount;

    IF v_TargetMaterialCount > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x09500012'; -- Target course already has materials
    END IF;

    -- Return course information for file path construction
    -- Extract year and semester from Semesters.Explanation, return lowercase for file naming
    -- Get AcademicYear from AcademicYears table for directory structure
    SELECT
        -- Source course info
        SourceAY.AcademicYear AS SourceAcademicYear,
        SUBSTRING_INDEX(SourceSem.Explanation, ' ', -1) AS SourceYear,
        LOWER(SUBSTRING_INDEX(SourceSem.Explanation, ' ', 1)) AS SourceSemesterName,
        LOWER(SourceAVC.Subject) AS SourceSubject,
        SourceAVC.Num AS SourceCourseNum,
        SourceAVC.CRN AS SourceCRN,

        -- Target course info
        TargetAY.AcademicYear AS TargetAcademicYear,
        SUBSTRING_INDEX(TargetSem.Explanation, ' ', -1) AS TargetYear,
        LOWER(SUBSTRING_INDEX(TargetSem.Explanation, ' ', 1)) AS TargetSemesterName,
        LOWER(TargetAVC.Subject) AS TargetSubject,
        TargetAVC.Num AS TargetCourseNum,
        TargetAVC.CRN AS TargetCRN
    FROM `AVCourses` AS SourceAVC
    INNER JOIN `Semesters` AS SourceSem ON SourceAVC.Semester = SourceSem.SemesterCode
    INNER JOIN `AcademicYears` AS SourceAY ON SourceSem.SemesterCode >= SourceAY.From AND SourceSem.SemesterCode <= SourceAY.To
    CROSS JOIN `AVCourses` AS TargetAVC
    INNER JOIN `Semesters` AS TargetSem ON TargetAVC.Semester = TargetSem.SemesterCode
    INNER JOIN `AcademicYears` AS TargetAY ON TargetSem.SemesterCode >= TargetAY.From AND TargetSem.SemesterCode <= TargetAY.To
    WHERE SourceAVC.Idx = IN_SourceAvcIdx
      AND TargetAVC.Idx = IN_TargetAvcIdx;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ChkAbetCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ChkAbetCourses`( IN IN_AcademicYear INT, IN IN_AcademicProgram INT )
BEGIN
    SELECT COUNT(`ABETCRSES`.`Idx`) as `COUNT`
    FROM `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`)
        INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`)
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
    WHERE `ABETCRSES`.`AcademicProgram`=IN_AcademicProgram AND `AYS`.`Idx`=IN_AcademicYear
    ORDER BY `AVCRSES`.`Subject`, `AVCRSES`.`Num`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ChkAbetCourses_MultiYears` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ChkAbetCourses_MultiYears`(
    IN IN_AcademicYears TEXT,
    IN IN_AcademicProgram INT
)
BEGIN

    SET @sql = CONCAT(
        'SELECT COUNT(`ABETCRSES`.`Idx`) as `COUNT`
        FROM `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`)
        INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`)
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        WHERE `ABETCRSES`.`AcademicProgram` = ', IN_AcademicProgram, '
        AND `AYS`.`Idx` IN (', IN_AcademicYears, ')
        ORDER BY `AVCRSES`.`Subject`, `AVCRSES`.`Num`'
    );

    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ChkAbetSyllabusExist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ChkAbetSyllabusExist`(
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicYearIdx INT,
    IN IN_AcademicProgramIdx INT,
    IN IN_Subject VARCHAR(5),
    IN IN_Num VARCHAR(5)
)
BEGIN
SELECT `CM_CRSES`.`AbetSyllabus` AS `AbetSyllabus`
FROM `CourseMapping_Courses` AS `CM_CRSES`
         INNER JOIN `CourseMapping_SOs` AS `CM_SOS`
                    ON (`CM_SOS`.`AbetCourseIdx` = `CM_CRSES`.`Idx`)
         INNER JOIN `CourseMapping_GPIs` AS `CM_GPIS`
                    ON (`CM_GPIS`.`AbetCourseIdx` = `CM_CRSES`.`Idx`)
         INNER JOIN `AbetSyllabus` AS `ABETSYLBUS`
                    ON (`CM_CRSES`.`AbetSyllabus` = `ABETSYLBUS`.`Idx`
                        AND `CM_CRSES`.`AcademicYear` = IN_AcademicYearIdx
                        AND `ABETSYLBUS`.`AcademicProgram` = IN_AcademicProgramIdx
                        AND `CM_CRSES`.`AcademicProgram` = IN_AcademicProgramIdx)
         INNER JOIN `Courses` AS `CRSES`
                    ON (`CM_CRSES`.`CourseIdx` = `CRSES`.`Idx`
                        AND `CRSES`.`Subject` = IN_Subject
                        AND `CRSES`.`Num` = IN_Num);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ChkActualAssessmentSample` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ChkActualAssessmentSample`(IN IN_AssignmentType VARCHAR(256), IN IN_AssignmentNum INT,
    IN IN_AvailableCourseIdx INT, IN IN_AbetCourseIdx INT)
BEGIN

    IF IN_AssignmentNum IS NULL THEN
    BEGIN
        SELECT * FROM `AssessmentMeasures`
            WHERE `AssignmentType` = IN_AssignmentType
                AND `AssignmentNum` IS NULL
                AND `AbetCourseIdx` = IN_AbetCourseIdx
                AND `AvailableCourseIdx` = IN_AvailableCourseIdx
                AND `ActualAssmntSample` <> '';
    END;
    ELSE
    BEGIN
        SELECT * FROM `AssessmentMeasures`
            WHERE `AssignmentType` = IN_AssignmentType
                AND `AssignmentNum` = IN_AssignmentNum
                AND `AbetCourseIdx` = IN_AbetCourseIdx
                AND `AvailableCourseIdx` = IN_AvailableCourseIdx
                AND `ActualAssmntSample` <> '';
    END;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ChkCourseAssessment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ChkCourseAssessment`(
    IN IN_AssessmentType VARCHAR(256),
    IN IN_AssessmentNum INT,
    IN IN_AvailableCourseIdx INT)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Input validation
    IF IN_AssessmentType IS NULL OR IN_AvailableCourseIdx IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Required parameters cannot be NULL';
    END IF;

    -- Query based on AssessmentNum
    IF IN_AssessmentNum IS NULL THEN
        SELECT *
        FROM `AVCourses_CrsMaterials`
        WHERE `AssmntType` = IN_AssessmentType
        AND `AssmntNum` IS NULL
        AND `AvailableCourseIdx` = IN_AvailableCourseIdx;
    ELSE
        SELECT *
        FROM `AVCourses_CrsMaterials`
        WHERE `AssmntType` = IN_AssessmentType
        AND `AssmntNum` = IN_AssessmentNum
        AND `AvailableCourseIdx` = IN_AvailableCourseIdx;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ChkIfAbetSyllabusExist` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ChkIfAbetSyllabusExist`(
    IN IN_CourseMappingIdx INT
)
BEGIN
    SELECT `ABETSYLBUS`.`Idx` AS `AbetSyllabus`
    FROM `CourseMapping_Courses` AS `CM_CRSES`
         INNER JOIN `AbetSyllabus` AS `ABETSYLBUS`
                    ON (`ABETSYLBUS`.`CourseIndex` = `CM_CRSES`.`CourseIdx`
                        AND `ABETSYLBUS`.`AcademicProgram` = `CM_CRSES`.`AcademicProgram`
                        AND `CM_CRSES`.`AcademicYear` >= `ABETSYLBUS`.`AcademicYearFrom`
                        AND (`CM_CRSES`.`AcademicYear` <= `ABETSYLBUS`.`AcademicYearTo`
                             OR `ABETSYLBUS`.`AcademicYearTo` IS NULL))
    WHERE `CM_CRSES`.`Idx` = IN_CourseMappingIdx
    ORDER BY `ABETSYLBUS`.`major_version` DESC, `ABETSYLBUS`.`minor_version` DESC
    LIMIT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CopySyllabusInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CopySyllabusInfo`(
    IN p_TargetSyllabusIndex INT,
    IN p_SourceSyllabusIndex INT
)
BEGIN
    DECLARE rows_affected INT;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Input validation
    IF p_SourceSyllabusIndex = p_TargetSyllabusIndex THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00300013'; -- Source and target cannot be the same
    END IF;

    -- Check if source syllabus exists
    IF NOT EXISTS (SELECT 1 FROM `AbetSyllabus` WHERE `Idx` = p_SourceSyllabusIndex) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00300011'; -- Source syllabus not found
    END IF;

    -- Check if target syllabus exists
    IF NOT EXISTS (SELECT 1 FROM `AbetSyllabus` WHERE `Idx` = p_TargetSyllabusIndex) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00300012'; -- Target syllabus not found
    END IF;

    -- Get source syllabus data
    SELECT
        `Description`, `Credits`, `Requirement`,
        `Pre_requisites`, `Co_requisites`, `Required_Texts`,
        `Reference_Texts`, `Coordinator`, `Objectives`, `TopicsCovered`
    INTO
        @Description, @Credits, @Requirement,
        @Pre_requisites, @Co_requisites, @Required_Texts,
        @Reference_Texts, @Coordinator, @Objectives, @TopicsCovered
    FROM `AbetSyllabus`
    WHERE `Idx` = p_SourceSyllabusIndex;

    -- Update target syllabus
    UPDATE `AbetSyllabus`
    SET
        `Description` = @Description,
        `Credits` = @Credits,
--         `Requirement` = @Requirement, // requirement should not be copied
        `Pre_requisites` = @Pre_requisites,
        `Co_requisites` = @Co_requisites,
        `Required_Texts` = @Required_Texts,
        `Reference_Texts` = @Reference_Texts,
        `Coordinator` = @Coordinator,
        `Objectives` = @Objectives,
        `TopicsCovered` = @TopicsCovered,
        `LinkedSyllabus` = p_SourceSyllabusIndex
    WHERE `Idx` = p_TargetSyllabusIndex;


    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CourseInfo_AddCourse` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CourseInfo_AddCourse`(IN IN_Subject VARCHAR(5), IN IN_Num VARCHAR(5),
    IN IN_Title VARCHAR(200), IN IN_Credits VARCHAR(20))
BEGIN
	START TRANSACTION;

	IF (SELECT COUNT(*) FROM `Courses` WHERE `Subject`=IN_Subject AND `Num`=IN_Num)=0 THEN # no item
	BEGIN
		INSERT INTO `Courses`(`Subject`, `Num`, `Title`, `Credits`) VALUES (IN_Subject, IN_Num, IN_Title, IN_Credits);
	END;
	END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CourseInfo_Manual_AddCourse` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CourseInfo_Manual_AddCourse`(IN IN_Subject VARCHAR(5), IN IN_Num VARCHAR(5),
                                                IN IN_Title VARCHAR(200), IN IN_Credits VARCHAR(20))
BEGIN
	START TRANSACTION;

	IF (SELECT COUNT(*) FROM `Courses` WHERE `Subject`=IN_Subject AND `Num`=IN_Num)=0 THEN # no item
	BEGIN
		INSERT INTO `Courses`(`Subject`, `Num`, `Title`, `Credits`) VALUES (IN_Subject, IN_Num, IN_Title, IN_Credits);
		SELECT "0x11111111" AS 'MESSAGE'; # added successfully
	END;
	ELSE
	BEGIN
		SELECT "0x80201010" AS 'MESSAGE'; # item already exists
	END;
	END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreateAbetSyllabusPDF_FetchRevisionHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreateAbetSyllabusPDF_FetchRevisionHistory`(
    IN p_CourseIndex INT
)
BEGIN

    SELECT `Idx`, `major_version`, `minor_version`, `RevisionDesc`, `RevisionDate`, `ApprovalDate`, `ApprovalDesc`
    FROM `AbetSyllabus` WHERE `CourseIndex` = p_CourseIndex ORDER BY `major_version`, `minor_version` DESC;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchABETCourseAssessmentMeasures` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchABETCourseAssessmentMeasures`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN

    SELECT `ASSMNTMEASURES`.`Measure`, `GPIS`.`GPI`, `ASSMNTMEASURES`.`Idx` AS `MSRIdx`, `STNTOUTCMS`.`SO`,
           `ASSMNTMEASURES`.`AssignmentType`, `ASSMNTMEASURES`.`AssignmentNum`, `ASSMNTMEASURES`.`AssignmentProblem`,
           `ASSMNTMEASURES`.`AssignmentDescription`, `ASSMNTMEASURES`.`ActualAssmntSample`
    FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
             INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
                        ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram`=IN_AcademicProgramIdx)
             INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
                        ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramIdx)
    WHERE `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx AND `ASSMNTMEASURES`.`AbetCourseIdx`= IN_AbetCourseIdx
    ORDER BY `ASSMNTMEASURES`.`Idx`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchABETCourseAssessmentMeasuresNSamples` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchABETCourseAssessmentMeasuresNSamples`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN

    SELECT
        `ASSMNTMEASURES`.`Measure`,
        `GPIS`.`GPI`,
        `ASSMNTMEASURES`.`Idx` AS `MSRIdx`,
        `STNTOUTCMS`.`SO`,
        `ASSMNTMEASURES`.`AssignmentType`,
        `ASSMNTMEASURES`.`AssignmentNum`,
        `ASSMNTMEASURES`.`AssignmentProblem`,
        `ASSMNTMEASURES`.`AssignmentDescription`,
        `ASSMNTMEASURES`.`ActualAssmntSample`,
        COALESCE(
            GROUP_CONCAT(
                `SAMPLES`.`SampleFile`
                ORDER BY `SAMPLES`.`Idx`
                SEPARATOR '|'
            ),
            ''
        ) AS `StudentSamples`
    FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
    INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
        ON (`GPIS`.`Idx` = `ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram` = IN_AcademicProgramIdx)
    INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
        ON (`GPIS`.`SOIdx` = `STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram` = IN_AcademicProgramIdx)
    LEFT JOIN `AssessmentMeasureSamples` AS `SAMPLES`
        ON `SAMPLES`.`AssessmentMeasureIdx` = `ASSMNTMEASURES`.`Idx`
    WHERE
        `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx
        AND `ASSMNTMEASURES`.`AbetCourseIdx` = IN_AbetCourseIdx
    GROUP BY
        `ASSMNTMEASURES`.`Idx`,
        `ASSMNTMEASURES`.`Measure`,
        `GPIS`.`GPI`,
        `STNTOUTCMS`.`SO`,
        `ASSMNTMEASURES`.`AssignmentType`,
        `ASSMNTMEASURES`.`AssignmentNum`,
        `ASSMNTMEASURES`.`AssignmentProblem`,
        `ASSMNTMEASURES`.`AssignmentDescription`,
        `ASSMNTMEASURES`.`ActualAssmntSample`
    ORDER BY
        `ASSMNTMEASURES`.`Idx`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchABETCourseAverageAssessmentScores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchABETCourseAverageAssessmentScores`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN

    SELECT `ASSMNTMEASURES`.`Measure`, `ASSMNTMEASURES`.`AssignmentDescription` AS `AssignmentDesc`,
       `ASSMNTMEASURES`.`AssignmentType`, `ASSMNTMEASURES`.`AssignmentNum`,
       AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
       COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
       SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE NULL END) AS `TOPFIFTY`,
       SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE NULL END) AS `TOPTWENTYFIVE`
    FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
         INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
                    ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram`=IN_AcademicProgramIdx)
         INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
                    ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramIdx)
         INNER JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)
    WHERE `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx AND `ASSMNTMEASURES`.`AbetCourseIdx`= IN_AbetCourseIdx
    GROUP BY `ASSMNTMEASURES`.`Idx` ORDER BY `ASSMNTMEASURES`.`Measure`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchABETCourseAveragePIScores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchABETCourseAveragePIScores`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN

    SELECT CONCAT(`STNTOUTCMS`.`SO`, '-', `GPIS`.`GPI`) AS `GPI`, `GPIS`.`Description`,
       AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
       COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
       SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE NULL END) AS `TOPFIFTY`,
       SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE NULL END) AS `TOPTWENTYFIVE`
    FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
         INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
                    ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram`=IN_AcademicProgramIdx)
         INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
                    ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramIdx)
         INNER JOIN `Scoresheet` AS `SCSHEET`
                    ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)
    WHERE `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx AND `ASSMNTMEASURES`.`AbetCourseIdx`= IN_AbetCourseIdx
    GROUP BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchABETCourseAverageSOScores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchABETCourseAverageSOScores`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN
    
    SELECT `STNTOUTCMS`.`SO`, `STNTOUTCMS`.`Description`,
       AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
       COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
       SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE NULL END) AS `TOPFIFTY`,
       SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE NULL END) AS `TOPTWENTYFIVE`
    FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
         INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
                    ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram`=IN_AcademicProgramIdx)
         INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
                    ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramIdx)
         INNER JOIN `Scoresheet` AS `SCSHEET`
                    ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)
    WHERE `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx AND `ASSMNTMEASURES`.`AbetCourseIdx`= IN_AbetCourseIdx
    GROUP BY `STNTOUTCMS`.`SO`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchABETCourseContinuousImprovement` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchABETCourseContinuousImprovement`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT
)
BEGIN

    SELECT `FacultyReflection`, `EvaluatorsReflection`
    FROM `ContinuousImprovement` AS `CNTIMPRVMNT`
    WHERE `CNTIMPRVMNT`.`AvailableCourseIdx` = IN_AvailableCourseIdx
      AND `CNTIMPRVMNT`.`AbetCourseIdx` = IN_AbetCourseIdx;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchABETCourseMaterRubrics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchABETCourseMaterRubrics`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN

    SELECT `GPIS`.`GPI`, `STNTOUTCMS`.`SO`, `ASSMNTMSTRRBRICS`.`LevelofAttainment`, `ASSMNTMSTRRBRICS`.`Description`
    FROM `AssessmentMeasures` AS `ASSMNTEXMPLES`
             INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
                        ON (`GPIS`.`Idx`=`ASSMNTEXMPLES`.`GPI` AND `GPIS`.`AcademicProgram`=IN_AcademicProgramIdx)
             INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
                        ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramIdx)
             INNER JOIN `AssessmentMasterRubrics` AS `ASSMNTMSTRRBRICS`
                        ON (`GPIS`.`Idx`=`ASSMNTMSTRRBRICS`.`GPIIdx`)
    WHERE `ASSMNTEXMPLES`.`AvailableCourseIdx` = IN_AvailableCourseIdx AND `ASSMNTEXMPLES`.`AbetCourseIdx`= IN_AbetCourseIdx
    GROUP BY `SOIdx`, `GPIIdx`, `ASSMNTMSTRRBRICS`.`LevelofAttainment`
    ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI`, `ASSMNTMSTRRBRICS`.`LevelofAttainment`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchABETCoursePerStudentAveragePIScores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchABETCoursePerStudentAveragePIScores`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN
    -- Get total measures per GPI
    WITH GPIMeasureCounts AS (
        SELECT
            `GPIS`.`Idx` AS GPIIdx,
            CONCAT(`STNTOUTCMS`.`SO`, '-', `GPIS`.`GPI`) AS GPI,
            `GPIS`.`Description` AS GPIDescription,
            COUNT(DISTINCT `ASSMNTMEASURES`.`Idx`) AS TotalMeasures
        FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
            ON (`GPIS`.`Idx` = `ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram` = IN_AcademicProgramIdx)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
            ON (`GPIS`.`SOIdx` = `STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram` = IN_AcademicProgramIdx)
        WHERE `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx
          AND `ASSMNTMEASURES`.`AbetCourseIdx` = IN_AbetCourseIdx
        GROUP BY `GPIS`.`Idx`, `STNTOUTCMS`.`SO`, `GPIS`.`GPI`, `GPIS`.`Description`
    ),
    -- Get student scores per GPI (excluding NULL scores)
    StudentGPIScores AS (
        SELECT
            `GPIS`.`Idx` AS GPIIdx,
            CONCAT(`STNTOUTCMS`.`SO`, '-', `GPIS`.`GPI`) AS GPI,
            `GPIS`.`Description` AS GPIDescription,
            `SCSHEET`.`StudentNo`,
            `ASSMNTMEASURES`.`Measure`,
            `SCSHEET`.`LevelOfAttainment` AS Score
        FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
            ON (`GPIS`.`Idx` = `ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram` = IN_AcademicProgramIdx)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
            ON (`GPIS`.`SOIdx` = `STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram` = IN_AcademicProgramIdx)
        INNER JOIN `Scoresheet` AS `SCSHEET`
            ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
        WHERE `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx
          AND `ASSMNTMEASURES`.`AbetCourseIdx` = IN_AbetCourseIdx
          AND `SCSHEET`.`LevelOfAttainment` IS NOT NULL
    ),
    -- Calculate student averages (only students with all measures)
    StudentGPIAverages AS (
        SELECT
            `SGS`.`GPIIdx`,
            `SGS`.`GPI`,
            `SGS`.`GPIDescription`,
            `SGS`.`StudentNo`,
            COUNT(DISTINCT `SGS`.`Measure`) AS MeasureCount,
            AVG(`SGS`.`Score`) AS StudentAverage
        FROM StudentGPIScores AS `SGS`
        GROUP BY `SGS`.`GPIIdx`, `SGS`.`GPI`, `SGS`.`GPIDescription`, `SGS`.`StudentNo`
    )
    -- Calculate GPI averages and percentages across students
    SELECT
        `SGA`.`GPI`,
        `SGA`.`GPIDescription`,
        COUNT(DISTINCT `SGA`.`StudentNo`) AS StudentCount,
        ROUND(AVG(`SGA`.`StudentAverage`), 4) AS AverageScore,
        ROUND(
            (SUM(CASE WHEN `SGA`.`StudentAverage` >= 2 THEN 1 ELSE 0 END) * 100.0) / 
            COUNT(DISTINCT `SGA`.`StudentNo`),
            2
        ) AS PercentDeveloping,
        ROUND(
            (SUM(CASE WHEN `SGA`.`StudentAverage` >= 3 THEN 1 ELSE 0 END) * 100.0) / 
            COUNT(DISTINCT `SGA`.`StudentNo`),
            2
        ) AS PercentSatisfactory
    FROM StudentGPIAverages AS `SGA`
    INNER JOIN GPIMeasureCounts AS `GMC`
        ON `SGA`.`GPIIdx` = `GMC`.`GPIIdx`
    WHERE `SGA`.`MeasureCount` = `GMC`.`TotalMeasures`
    GROUP BY `SGA`.`GPI`, `SGA`.`GPIDescription`
    ORDER BY `SGA`.`GPI`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchABETCoursePerStudentAverageSOScores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchABETCoursePerStudentAverageSOScores`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN
    -- Get total measures per SO
    WITH SOMeasureCounts AS (
        SELECT
            `STNTOUTCMS`.`Idx` AS SOIdx,
            `STNTOUTCMS`.`SO`,
            `STNTOUTCMS`.`Description`,
            COUNT(DISTINCT `ASSMNTMEASURES`.`Idx`) AS TotalMeasures
        FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
            ON (`GPIS`.`Idx` = `ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram` = IN_AcademicProgramIdx)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
            ON (`GPIS`.`SOIdx` = `STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram` = IN_AcademicProgramIdx)
        WHERE `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx
          AND `ASSMNTMEASURES`.`AbetCourseIdx` = IN_AbetCourseIdx
        GROUP BY `STNTOUTCMS`.`Idx`, `STNTOUTCMS`.`SO`, `STNTOUTCMS`.`Description`
    ),
    -- Get student scores per SO (excluding NULL scores)
    StudentSOScores AS (
        SELECT
            `STNTOUTCMS`.`Idx` AS SOIdx,
            `STNTOUTCMS`.`SO`,
            `STNTOUTCMS`.`Description`,
            `SCSHEET`.`StudentNo`,
            `ASSMNTMEASURES`.`Measure`,
            `SCSHEET`.`LevelOfAttainment` AS Score
        FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS`
            ON (`GPIS`.`Idx` = `ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram` = IN_AcademicProgramIdx)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
            ON (`GPIS`.`SOIdx` = `STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram` = IN_AcademicProgramIdx)
        INNER JOIN `Scoresheet` AS `SCSHEET`
            ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
        WHERE `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx
          AND `ASSMNTMEASURES`.`AbetCourseIdx` = IN_AbetCourseIdx
          AND `SCSHEET`.`LevelOfAttainment` IS NOT NULL
    ),
    -- Calculate student averages (only students with all measures)
    StudentSOAverages AS (
        SELECT
            `SSS`.`SOIdx`,
            `SSS`.`SO`,
            `SSS`.`Description`,
            `SSS`.`StudentNo`,
            COUNT(DISTINCT `SSS`.`Measure`) AS MeasureCount,
            AVG(`SSS`.`Score`) AS StudentAverage
        FROM StudentSOScores AS `SSS`
        GROUP BY `SSS`.`SOIdx`, `SSS`.`SO`, `SSS`.`Description`, `SSS`.`StudentNo`
    )
    -- Calculate SO averages and percentages across students
    SELECT
        `SSA`.`SO`,
        `SSA`.`Description`,
        COUNT(DISTINCT `SSA`.`StudentNo`) AS StudentCount,
        ROUND(AVG(`SSA`.`StudentAverage`), 4) AS AverageScore,
        ROUND(
            (SUM(CASE WHEN `SSA`.`StudentAverage` >= 2 THEN 1 ELSE 0 END) * 100.0) / 
            COUNT(DISTINCT `SSA`.`StudentNo`),
            2
        ) AS PercentDeveloping,
        ROUND(
            (SUM(CASE WHEN `SSA`.`StudentAverage` >= 3 THEN 1 ELSE 0 END) * 100.0) / 
            COUNT(DISTINCT `SSA`.`StudentNo`),
            2
        ) AS PercentSatisfactory
    FROM StudentSOAverages AS `SSA`
    INNER JOIN SOMeasureCounts AS `SMC`
        ON `SSA`.`SOIdx` = `SMC`.`SOIdx`
    WHERE `SSA`.`MeasureCount` = `SMC`.`TotalMeasures`
    GROUP BY `SSA`.`SO`, `SSA`.`Description`
    ORDER BY `SSA`.`SO`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchAvailableAbetCourseInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchAvailableAbetCourseInfo`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT
)
BEGIN
    -- Fetch comprehensive course information for PDF generation
    SELECT
        -- Get semester explanation directly from Semesters table (e.g., "Spring 2026", "Fall 2025")
        `SMSTRS`.`Explanation` AS `Semester`,

        -- Basic course identifiers
        `AVCRSES`.`CRN`,                    -- Course Reference Number (e.g., "28138")
        `AVCRSES`.`Subject`,                -- Subject code (e.g., "CVEN" for Civil Engineering)
        `AVCRSES`.`Num`,                    -- Course number (e.g., "206")
        `AVCRSES`.`Title`,                  -- Full course title (e.g., "Mechanics Solids")
        `AVCRSES`.`Credits`,                -- Credit hours (e.g., 3)
        `AVCRSES`.`SurveyReport`,           -- Survey Report

        -- Syllabus information from both tables
        `AVCRSES`.`Syllabus`,               -- Regular course syllabus filename (e.g., "syllabus_2026_spring_cven_206_crn28138.pdf")
        `ABTCRSES`.`Syllabus` AS `ABETSyllabus`,  -- ABET-specific syllabus (NULL if not available)

        -- Aggregate all instructors into comma-separated list (alphabetically sorted)
        -- Single instructor: "James Dean"
        -- Multiple instructors: "John Doe, James Dean"
        GROUP_CONCAT(DISTINCT `UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR ', ') AS `Instructor`,

        -- Academic program information
        `ACDEMICPRMS`.`Degree`,             -- Degree abbreviation (e.g., "BSCE" for Bachelor of Science in Civil Engineering)

        -- Course binder update status
        `AVCRSES`.`crsbinder_updated` AS `BinderUpdated`  -- Boolean: 1 = updated, 0 = not updated

    FROM `AVCourses` AS `AVCRSES`

    -- Join to get semester explanation from Semesters table
    LEFT JOIN `Semesters` AS `SMSTRS`
        ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`

    -- Join to get ABET course information (ABETSyllabus may be NULL)
    LEFT JOIN `AbetCourses` AS `ABTCRSES`
        ON `AVCRSES`.`Idx` = `ABTCRSES`.`AVCourseIdx`

    -- Join to get academic program/degree abbreviation (e.g., BSCE, BSCS)
    LEFT JOIN `AcademicPrograms` AS `ACDEMICPRMS`
        ON `ABTCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`

    -- Join to get instructor assignments (courses may have multiple instructors)
    LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS`
        ON `AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`

    -- Join to get actual instructor names from user accounts
    LEFT JOIN `UserAccounts` AS `UA`
        ON `AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`

    -- Filter for the specific course
    WHERE `AVCRSES`.`Idx` = IN_AvailableCourseIdx
        AND `ABTCRSES`.`Idx` = IN_AbetCourseIdx

    -- Group by all non-aggregated columns
    GROUP BY
        `AVCRSES`.`Idx`,
        `SMSTRS`.`Explanation`,
        `AVCRSES`.`CRN`,
        `AVCRSES`.`Subject`,
        `AVCRSES`.`Num`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,
        `AVCRSES`.`SurveyReport`,
        `AVCRSES`.`Syllabus`,
        `ABTCRSES`.`Syllabus`,
        `ACDEMICPRMS`.`Degree`,
        `AVCRSES`.`crsbinder_updated`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchAvailableCourseAMs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchAvailableCourseAMs`(IN IN_AvailableCourseIdx INT)
BEGIN

    SELECT `AssmntType`, `AssmntNum`, `AssmntSample`, `StudentSample1`, `StudentSample2`, `StudentSample3`
    FROM `AVCourses_CrsMaterials`
    WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
    ORDER BY `AssmntType`, `AssmntNum`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchAvailableCourseIMs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchAvailableCourseIMs`(IN IN_AvailableCourseIdx INT)
BEGIN

    SELECT `MaterialType`, `MaterialSample`
    FROM `AVCourses_InstMaterials`
    WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
    ORDER BY `MaterialType`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_CreatePDF_FetchAvailableCourseInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_CreatePDF_FetchAvailableCourseInfo`(
    IN IN_AvailableCourseIdx INT
)
BEGIN
    -- Fetch comprehensive course information for PDF generation
    SELECT
        -- Get semester explanation directly from Semesters table (e.g., "Spring 2026", "Fall 2025")
        `SMSTRS`.`Explanation` AS `Semester`,

        -- Basic course identifiers
        `AVCRSES`.`CRN`,                    -- Course Reference Number (e.g., "28138")
        `AVCRSES`.`Subject`,                -- Subject code (e.g., "CVEN" for Civil Engineering)
        `AVCRSES`.`Num`,                    -- Course number (e.g., "206")
        `AVCRSES`.`Title`,                  -- Full course title (e.g., "Mechanics Solids")
        `AVCRSES`.`Credits`,                -- Credit hours (e.g., 3)
        `AVCRSES`.`SurveyReport`,           -- Survey Report

        -- Syllabus information from both tables
        `AVCRSES`.`Syllabus`,               -- Regular course syllabus filename (e.g., "syllabus_2026_spring_cven_206_crn28138.pdf")
        `ABTCRSES`.`Syllabus` AS `ABETSyllabus`,  -- ABET-specific syllabus (NULL if not available)

        -- Aggregate all instructors into comma-separated list (alphabetically sorted)
        -- Single instructor: "James Dean"
        -- Multiple instructors: "John Doe, James Dean"
        GROUP_CONCAT(DISTINCT `UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR ', ') AS `Instructor`,

        -- Academic program information
        `ACDEMICPRMS`.`Degree`,             -- Degree abbreviation (e.g., "BSCE" for Bachelor of Science in Civil Engineering)

        -- Course binder update status
        `AVCRSES`.`crsbinder_updated` AS `BinderUpdated`  -- Boolean: 1 = updated, 0 = not updated

    FROM `AVCourses` AS `AVCRSES`

    -- Join to get semester explanation from Semesters table
    LEFT JOIN `Semesters` AS `SMSTRS`
        ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`

    -- Join to get ABET course information (ABETSyllabus may be NULL)
    LEFT JOIN `AbetCourses` AS `ABTCRSES`
        ON `AVCRSES`.`Idx` = `ABTCRSES`.`AVCourseIdx`

    -- Join to get academic program/degree abbreviation (e.g., BSCE, BSCS)
    LEFT JOIN `AcademicPrograms` AS `ACDEMICPRMS`
        ON `ABTCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`

    -- Join to get instructor assignments (courses may have multiple instructors)
    LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS`
        ON `AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`

    -- Join to get actual instructor names from user accounts
    LEFT JOIN `UserAccounts` AS `UA`
        ON `AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`

    -- Filter for the specific course
    WHERE `AVCRSES`.`Idx` = IN_AvailableCourseIdx

    -- Group by all non-aggregated columns
    GROUP BY
        `AVCRSES`.`Idx`,
        `SMSTRS`.`Explanation`,
        `AVCRSES`.`CRN`,
        `AVCRSES`.`Subject`,
        `AVCRSES`.`Num`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,
        `AVCRSES`.`SurveyReport`,
        `AVCRSES`.`Syllabus`,
        `ABTCRSES`.`Syllabus`,
        `ACDEMICPRMS`.`Degree`,
        `AVCRSES`.`crsbinder_updated`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_DuplicateAbetCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_DuplicateAbetCourses`(IN IN_AcademicYearSource INT, IN IN_AcademicYearDest INT, IN IN_AcademicProgram INT)
BEGIN
	DECLARE done TINYINT DEFAULT FALSE; -- A boolean variable to tell us when the cursor is out of data
	DECLARE _AbetCourseIdx INT;
	DECLARE _SOIdx INT;
	DECLARE _Syllabus VARCHAR (256);
	DECLARE _GPIIdx INT;

	-- cursor1 is an arbitrary label, an identifier for the cursor
	DECLARE cursor1 CURSOR FOR  ###################################### FETCHING INFORMATION #########################
        SELECT DISTINCT `T1`.`Idx` AS `AbetCourseIdx`, `T2`.`Syllabus`, `T3`.`Dest_SOIdx`, `T3`.`Dest_GPIIdx` FROM
            ( SELECT `ABETCRSES`.`Idx`, `ABETCRSES`.`AVCourseIdx`, `ABETCRSES`.`Syllabus`, `AVCRSES`.`CourseNo`
              FROM `AbetCourses` AS `ABETCRSES`
                       LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABETCRSES`.`Idx`=`ABETCRSES_SOS`.`AbetCourseIdx`)
                       LEFT JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`STNTOUTCMS`.`Idx`=`ABETCRSES_SOS`.`SOIdx`)
                       LEFT JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx`=`AVCRSES`.`Idx`)
              WHERE `ABETCRSES`.`AcademicYear`=IN_AcademicYearDest AND `ABETCRSES`.`AcademicProgram`=IN_AcademicProgram AND `ABETCRSES_SOS`.`SOIdx` IS NULL
            ) AS `T1`
                INNER JOIN
            ( SELECT `ABETCRSES`.`Idx`, `ABETCRSES`.`AVCourseIdx`,
                     `STNTOUTCMS`.`SO`, `GPIS`.`GPI`, `ABETCRSES`.`Syllabus`,
                     `ABETCRSES_SOS`.`SOIdx`, `ABETCRSES_GPIS`.`GPIIdx`,
                     `AVCRSES`.`CourseNo`
              FROM `AbetCourses` AS `ABETCRSES`
                       LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABETCRSES`.`Idx`=`ABETCRSES_SOS`.`AbetCourseIdx`)
                       LEFT JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`STNTOUTCMS`.`Idx`=`ABETCRSES_SOS`.`SOIdx`)
                       LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` ON (`ABETCRSES_GPIS`.`SOIdx`=`ABETCRSES_SOS`.`SOIdx` AND `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES_SOS`.`AbetCourseIdx`)
                       LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ABETCRSES_GPIS`.`GPIIdx`)
                       LEFT JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx`=`AVCRSES`.`Idx`)
              WHERE `ABETCRSES`.`AcademicYear`=IN_AcademicYearSource AND `ABETCRSES`.`AcademicProgram`=IN_AcademicProgram
            ) AS `T2`
            ON (`T1`.`CourseNo` = `T2`.`CourseNo`)
                INNER JOIN
            ( SELECT `STNTOUTCMS`.`Idx` AS `Dest_SOIdx`, `STNTOUTCMS`.`SO`, `GPIS`.`Idx` AS `Dest_GPIIdx`, `GPIS`.`GPI`
              FROM `StudentOutcomes` AS `STNTOUTCMS`
                       INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
              WHERE `STNTOUTCMS`.`AcademicYear`=IN_AcademicYearDest
                AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgram ) AS `T3`
            ON (`T2`.`SO` = `T3`.`SO` AND `T2`.`GPI` = `T3`.`GPI`)
        ORDER BY `T1`.`AVCourseIdx`;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	START TRANSACTION;

    -- fetch academic year information
    SELECT `AcademicYear` INTO @String_AcademicYearSrc FROM `AcademicYears` WHERE `Idx`=IN_AcademicYearSource;
    SELECT `AcademicYear` INTO @String_AcademicYearDest FROM `AcademicYears` WHERE `Idx`=IN_AcademicYearDest;

	-- open the cursor
	OPEN cursor1;
	dataLoop: LOOP
		FETCH NEXT FROM cursor1 INTO _AbetCourseIdx, _Syllabus, _SOIdx, _GPIIdx;
		IF done THEN
			LEAVE dataLoop;
		ELSEIF _AbetCourseIdx IS NOT NULL AND _SOIdx IS NOT NULL AND _GPIIdx IS NOT NULL THEN
		    BEGIN
		        -- Insert SO for the selected Abet course
                IF (SELECT COUNT(*) FROM `AbetCourses_SOs` WHERE `SOIdx`=_SOIdx AND `AbetCourseIdx`=_AbetCourseIdx
                        AND `AcademicYear`=IN_AcademicYearDest AND `AcademicProgram`=IN_AcademicProgram)=0 THEN
                    INSERT INTO `AbetCourses_SOs`(`SOIdx`, `AbetCourseIdx`, `AcademicYear`, `AcademicProgram`)
                        VALUES (_SOIdx, _AbetCourseIdx, IN_AcademicYearDest, IN_AcademicProgram);
                END IF;

                -- Insert PI for the selected Abet course
                IF (SELECT COUNT(*) FROM `AbetCourses_GPIs` WHERE `GPIIdx`=_GPIIdx AND `AbetCourseIdx`=_AbetCourseIdx
                        AND `SOIdx`=_SOIdx AND `AcademicYear`=IN_AcademicYearDest AND `AcademicProgram`=IN_AcademicProgram)=0 THEN
                    INSERT INTO `AbetCourses_GPIs`(`GPIIdx`, `AbetCourseIdx`, `SOIdx`, `AcademicYear`, `AcademicProgram`)
                        VALUES (_GPIIdx, _AbetCourseIdx, _SOIdx, IN_AcademicYearDest, IN_AcademicProgram);
                END IF;

                -- Update syllabus information
                IF _Syllabus IS NOT NULL AND _Syllabus <> '' THEN
                    UPDATE `AbetCourses` SET `Syllabus` = REPLACE(_Syllabus, @String_AcademicYearSrc, @String_AcademicYearDest)
                        WHERE `Idx`=_AbetCourseIdx AND `Syllabus`='';
                END IF;
            END;
		END IF;
	END LOOP dataLoop;

	CLOSE cursor1;

    -- Replace Academic Year information in Syllabus File Name

	COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_DuplicateAssmntRubrics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_DuplicateAssmntRubrics`(
    IN p_AcademicYearFrom VARCHAR(20),
    IN p_AcademicYearTo VARCHAR(20),
    IN p_AcademicProgram VARCHAR(50)
)
BEGIN
    -- Declare variables for error handling
    DECLARE v_source_exists INT;

    -- Check if source information exists
    SELECT COUNT(*) INTO v_source_exists
    FROM `AssessmentMasterRubrics` AS amr
    WHERE amr.`AcademicYear` = p_AcademicYearFrom
      AND amr.`AcademicProgram` = p_AcademicProgram
      AND amr.`Description` IS NOT NULL;

    IF v_source_exists = 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x09500011';
    END IF;

        -- Update assessment rubrics using a derived table
    UPDATE AssessmentMasterRubrics dest
        INNER JOIN (
        SELECT
        dest_amr.Idx AS dest_idx,
        src_amr.Description AS src_description
        FROM AssessmentMasterRubrics dest_amr
        INNER JOIN GeneralPerformanceIndicators dest_gpi ON dest_gpi.Idx = dest_amr.GPIIdx
        INNER JOIN StudentOutcomes dest_so ON dest_so.Idx = dest_gpi.SOIdx
        INNER JOIN StudentOutcomes src_so ON src_so.SO = dest_so.SO
        INNER JOIN GeneralPerformanceIndicators src_gpi ON src_gpi.SOIdx = src_so.Idx
        AND src_gpi.GPI = dest_gpi.GPI
        INNER JOIN AssessmentMasterRubrics src_amr ON src_amr.GPIIdx = src_gpi.Idx
        AND src_amr.LevelofAttainment = dest_amr.LevelofAttainment
        WHERE dest_amr.AcademicYear = p_AcademicYearTo
        AND dest_amr.AcademicProgram = p_AcademicProgram
        AND dest_amr.Description IS NULL
        AND src_so.AcademicYear = p_AcademicYearFrom
        AND src_so.AcademicProgram = p_AcademicProgram
        AND src_amr.Description IS NOT NULL
        ) src_data ON dest.Idx = src_data.dest_idx
        SET dest.Description = src_data.src_description;

    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_DuplicateCourseMapping_Courses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_DuplicateCourseMapping_Courses`(
    IN IN_AcademicYearSource INT,
    IN IN_AcademicYearDest INT,
    IN IN_AcademicProgram INT
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE newCourseIdx INT;
    DECLARE oldCourseIdx INT;

    -- Cursor to store the mapping between old and new course indices
    DECLARE course_cursor CURSOR FOR
    SELECT Idx FROM CourseMapping_Courses
    WHERE AcademicYear = IN_AcademicYearSource
      AND AcademicProgram = IN_AcademicProgram;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Check if source year has data
    IF NOT EXISTS (SELECT 1 FROM `CourseMapping_Courses`
                        WHERE `AcademicYear`=IN_AcademicYearSource
                             AND `AcademicProgram`=IN_AcademicProgram) THEN
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09500011'; -- source year data does not exist
    END IF;

    -- Check if source and destination years are the same
    IF IN_AcademicYearSource = IN_AcademicYearDest THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Source and destination academic years cannot be the same';
    END IF;

        -- Start transaction to ensure data consistency
    START TRANSACTION;

    -- First duplicate CourseMapping_Courses only if records don't exist
    INSERT INTO CourseMapping_Courses (AcademicYear, CourseIdx, Requirement, Level, AcademicProgram, AbetSyllabus)
    SELECT
        IN_AcademicYearDest,
        src.CourseIdx,
        src.Requirement,
        src.Level,
        src.AcademicProgram,
        src.AbetSyllabus
    FROM CourseMapping_Courses src
    WHERE src.AcademicYear = IN_AcademicYearSource
      AND src.AcademicProgram = IN_AcademicProgram
      AND NOT EXISTS (
        SELECT 1
        FROM CourseMapping_Courses dest
        WHERE dest.AcademicYear = IN_AcademicYearDest
          AND dest.CourseIdx = src.CourseIdx
          AND dest.AcademicProgram = src.AcademicProgram
    );

    -- Open cursor to get old and new course mappings
    OPEN course_cursor;

    read_loop: LOOP
            FETCH course_cursor INTO oldCourseIdx;
            IF done THEN
                LEAVE read_loop;
    END IF;

        -- Get the new course index that was just inserted
    SELECT Idx INTO newCourseIdx
    FROM CourseMapping_Courses
    WHERE AcademicYear = IN_AcademicYearDest
      AND CourseIdx = (
        SELECT CourseIdx
        FROM CourseMapping_Courses
        WHERE Idx = oldCourseIdx
    )
      AND AcademicProgram = IN_AcademicProgram;

    -- Duplicate CourseMapping_GPIs only if records don't exist
    INSERT INTO CourseMapping_GPIs (GPIIdx, AbetCourseIdx, SOIdx, AcademicYear, AcademicProgram)
    SELECT
        dest_gpi.Idx,  -- Use the destination GPI Idx
        newCourseIdx,
        dest_so.Idx,   -- Use the destination SO Idx
        IN_AcademicYearDest,
        src.AcademicProgram
    FROM CourseMapping_GPIs src
             -- Join to get source SO
             INNER JOIN StudentOutcomes src_so ON src.SOIdx = src_so.Idx
        -- Join to get destination SO
             INNER JOIN StudentOutcomes dest_so ON dest_so.SO = src_so.SO
        AND dest_so.AcademicYear = IN_AcademicYearDest
        AND dest_so.AcademicProgram = IN_AcademicProgram
        -- Join to get source GPI
             INNER JOIN GeneralPerformanceIndicators src_gpi ON src.GPIIdx = src_gpi.Idx
        -- Join to get destination GPI
             INNER JOIN GeneralPerformanceIndicators dest_gpi ON dest_gpi.GPI = src_gpi.GPI
        AND dest_gpi.AcademicYear = IN_AcademicYearDest
        AND dest_gpi.AcademicProgram = IN_AcademicProgram
        AND dest_gpi.SOIdx = dest_so.Idx
    WHERE src.AbetCourseIdx = oldCourseIdx
      AND src.AcademicProgram = IN_AcademicProgram
      AND NOT EXISTS (
        SELECT 1
        FROM CourseMapping_GPIs dest
        WHERE dest.AcademicYear = IN_AcademicYearDest
          AND dest.GPIIdx = dest_gpi.Idx
          AND dest.AbetCourseIdx = newCourseIdx
          AND dest.SOIdx = dest_so.Idx
          AND dest.AcademicProgram = src.AcademicProgram
    );

    -- Duplicate CourseMapping_SOs only if records don't exist
    INSERT INTO CourseMapping_SOs (SOIdx, AbetCourseIdx, AcademicYear, AcademicProgram)
    SELECT
        dest_so.Idx,  -- Use the destination SO Idx
        newCourseIdx,
        IN_AcademicYearDest,
        src.AcademicProgram
    FROM CourseMapping_SOs src
             INNER JOIN StudentOutcomes src_so ON src.SOIdx = src_so.Idx
             INNER JOIN StudentOutcomes dest_so ON dest_so.SO = src_so.SO
        AND dest_so.AcademicYear = IN_AcademicYearDest
        AND dest_so.AcademicProgram = IN_AcademicProgram
    WHERE src.AbetCourseIdx = oldCourseIdx
      AND src.AcademicProgram = IN_AcademicProgram
      AND NOT EXISTS (
        SELECT 1
        FROM CourseMapping_SOs dest
        WHERE dest.AcademicYear = IN_AcademicYearDest
          AND dest.SOIdx = dest_so.Idx
          AND dest.AbetCourseIdx = newCourseIdx
          AND dest.AcademicProgram = src.AcademicProgram
    );

    END LOOP;

    CLOSE course_cursor;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_DuplicateCourseMaterialsRecords` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_DuplicateCourseMaterialsRecords`(
    IN IN_SourceAvcIdx INT,
    IN IN_TargetAvcIdx INT,
    IN IN_InstMaterialsMapping JSON,
    IN IN_CrsMaterialsMapping JSON
)
BEGIN
    DECLARE v_SourceAVCourseExists INT DEFAULT 0;
    DECLARE v_TargetAVCourseExists INT DEFAULT 0;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Validate that source available course exists
    SELECT COUNT(*) INTO v_SourceAVCourseExists
    FROM `AVCourses`
    WHERE `Idx` = IN_SourceAvcIdx;

    IF v_SourceAVCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- Source available course does not exist
    END IF;

    -- Validate that target available course exists
    SELECT COUNT(*) INTO v_TargetAVCourseExists
    FROM `AVCourses`
    WHERE `Idx` = IN_TargetAvcIdx;

    IF v_TargetAVCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- Target available course does not exist
    END IF;

    -- Duplicate Instructional Materials with new file names from JSON mapping
    INSERT INTO `AVCourses_InstMaterials` (
        `AvailableCourseIdx`,
        `MaterialType`,
        `MaterialSample`
    )
    SELECT
        IN_TargetAvcIdx,
        `MaterialType`,
        CASE
            WHEN `MaterialSample` IS NOT NULL AND `MaterialSample` != '' THEN
                COALESCE(
                    JSON_UNQUOTE(JSON_EXTRACT(IN_InstMaterialsMapping, CONCAT('$."', `MaterialSample`, '"'))),
                    `MaterialSample`
                )
            ELSE
                `MaterialSample`
        END AS `MaterialSample`
    FROM `AVCourses_InstMaterials`
    WHERE `AvailableCourseIdx` = IN_SourceAvcIdx;

    -- Duplicate Course Assignment Materials with assessment samples only (NO student samples)
    INSERT INTO `AVCourses_CrsMaterials` (
        `AvailableCourseIdx`,
        `AssmntType`,
        `AssmntNum`,
        `AssmntSample`,
        `StudentSample1`,
        `StudentSample2`,
        `StudentSample3`
    )
    SELECT
        IN_TargetAvcIdx,
        `AssmntType`,
        `AssmntNum`,
        CASE
            WHEN `AssmntSample` IS NOT NULL AND `AssmntSample` != '' THEN
                COALESCE(
                    JSON_UNQUOTE(JSON_EXTRACT(
                        IN_CrsMaterialsMapping,
                        CONCAT('$."', `AssmntType`, '_', COALESCE(`AssmntNum`, 'NULL'), '".AssmntSample')
                    )),
                    `AssmntSample`
                )
            ELSE
                `AssmntSample`
        END AS `AssmntSample`,
        NULL AS `StudentSample1`,  -- Do not duplicate student samples
        NULL AS `StudentSample2`,  -- Do not duplicate student samples
        NULL AS `StudentSample3`   -- Do not duplicate student samples
    FROM `AVCourses_CrsMaterials`
    WHERE `AvailableCourseIdx` = IN_SourceAvcIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_DuplicateCrossPrmsAssmntRubrics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_DuplicateCrossPrmsAssmntRubrics`(
    IN IN_AcademicYearSource INT,
    IN IN_AcademicYearDest INT,
    IN IN_AcademicProgramSource INT,
    IN IN_AcademicProgramDest INT
)
BEGIN
	DECLARE done TINYINT DEFAULT FALSE; -- A boolean variable to tell us when the cursor is out of data
	DECLARE _IdxFrom INT;
	DECLARE _IdxTo INT;

	-- cursor1 is an arbitrary label, an identifier for the cursor
	DECLARE cursor1
		CURSOR FOR
        SELECT TBLSOURCE.`Idx` AS `IdxFrom`, TBLDEST.`Idx` AS `IdxTo`
        FROM
            (SELECT `STNTOUTCMS`.`SO`,
                `GPIS`.`GPI`,
                `ASSMNTMSTRRBRICS`.`Idx`,
                `ASSMNTMSTRRBRICS`.`LevelofAttainment`,
                `ASSMNTMSTRRBRICS`.`Description`
            FROM `StudentOutcomes` AS `STNTOUTCMS`
                LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx`)
                LEFT JOIN `AssessmentMasterRubrics` AS `ASSMNTMSTRRBRICS` ON (`GPIS`.`Idx`=`ASSMNTMSTRRBRICS`.`GPIIdx`)
            WHERE `ASSMNTMSTRRBRICS`.`Description` IS NOT NULL
                AND `STNTOUTCMS`.`AcademicYear`=IN_AcademicYearSource
                AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramSource) AS TBLSOURCE
        INNER JOIN
            (SELECT `STNTOUTCMS`.`SO`,
                `GPIS`.`GPI`,
                `ASSMNTMSTRRBRICS`.`Idx`,
                `ASSMNTMSTRRBRICS`.`LevelofAttainment`,
                `ASSMNTMSTRRBRICS`.`Description`
            FROM `StudentOutcomes` AS `STNTOUTCMS`
                LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx`)
                LEFT JOIN `AssessmentMasterRubrics` AS `ASSMNTMSTRRBRICS` ON (`GPIS`.`Idx`=`ASSMNTMSTRRBRICS`.`GPIIdx`)
            WHERE `ASSMNTMSTRRBRICS`.`Description` IS NULL
                AND `STNTOUTCMS`.`AcademicYear`=IN_AcademicYearDest
                AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramDest) AS TBLDEST
        ON (TBLSOURCE.`SO`=TBLDEST.`SO` AND TBLSOURCE.`GPI`=TBLDEST.`GPI`
            AND TBLSOURCE.`LevelofAttainment`=TBLDEST.`LevelofAttainment`);

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	START TRANSACTION;
	-- open the cursor
	OPEN cursor1;

	dataLoop: LOOP
		FETCH NEXT FROM cursor1 INTO _IdxFrom, _IdxTo;
		IF done THEN
			LEAVE dataLoop;
		ELSEIF _IdxFrom IS NOT NULL AND _IdxTo IS NOT NULL THEN
            UPDATE `AssessmentMasterRubrics` T1,
                (SELECT `Description` FROM `AssessmentMasterRubrics` WHERE `Idx`=_IdxFrom) T2
                SET T1.`Description`=T2.`Description`
            WHERE `Idx`=_IdxTo;
		END IF;
	END LOOP dataLoop;

	CLOSE cursor1;
	COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_DuplicateCrossPrmsPIs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_DuplicateCrossPrmsPIs`(
    IN IN_AcademicYearSource INT,
    IN IN_AcademicYearDest INT,
    IN IN_AcademicProgramSource INT,
    IN IN_AcademicProgramDest INT
)
BEGIN
	DECLARE done TINYINT DEFAULT FALSE; -- A boolean variable to tell us when the cursor is out of data
	DECLARE _SOIdx  INT;
    DECLARE _GPI VARCHAR (50);
    DECLARE _Description VARCHAR (2048);

	-- cursor1 is an arbitrary label, an identifier for the cursor
	DECLARE cursor1
		CURSOR FOR
        SELECT TBLDEST.`Idx` AS `SOIdx`, TBLSOURCE.`GPI`, TBLSOURCE.`Description`
        FROM
            (SELECT `STNTOUTCMS`.`SO`, `GPIS`.`GPI`, `GPIS`.`Description` FROM `StudentOutcomes` AS `STNTOUTCMS`
                LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx`)
            WHERE `STNTOUTCMS`.`AcademicYear`=IN_AcademicYearSource
                AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramSource) AS TBLSOURCE
            INNER JOIN
            (SELECT `STNTOUTCMS`.`Idx`, `STNTOUTCMS`.`SO` FROM `StudentOutcomes` AS `STNTOUTCMS`
            WHERE `STNTOUTCMS`.`AcademicYear`=IN_AcademicYearDest
                AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramDest) AS TBLDEST
        ON (TBLSOURCE.`SO`=TBLDEST.`SO`);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;
    IF NOT EXISTS (SELECT 1 FROM `GeneralPerformanceIndicators`
       WHERE `AcademicYear`=IN_AcademicYearSource AND `AcademicProgram`=IN_AcademicProgramSource) THEN
            SIGNAL SQLSTATE '45000'
            SET  MESSAGE_TEXT = '0x09500011'; -- no data in the source

    ELSEIF EXISTS (SELECT 1 FROM `GeneralPerformanceIndicators`
       WHERE `AcademicYear`=IN_AcademicYearDest AND `AcademicProgram`=IN_AcademicProgramDest) THEN
            SIGNAL SQLSTATE '45000'
            SET  MESSAGE_TEXT = '0x09500012'; -- data exists in the target

    ELSE
        BEGIN

        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
            -- open the cursor
            OPEN cursor1;

            dataLoop: LOOP
                    FETCH NEXT FROM cursor1 INTO _SOIdx, _GPI, _Description;
                    IF done THEN
                        LEAVE dataLoop;
                    ELSEIF _SOIdx IS NOT NULL AND _GPI IS NOT NULL AND _Description IS NOT NULL THEN
            BEGIN
            INSERT INTO `GeneralPerformanceIndicators`
            (`AcademicYear`, `SOIdx`, `GPI`, `Description`, `AcademicProgram`)
            VALUES (IN_AcademicYearDest, _SOIdx, _GPI, _Description, IN_AcademicProgramDest);

            SELECT LAST_INSERT_ID() INTO @IN_GPIIdx;

            -- Call the separate stored procedure for Assessment Master Rubrics
            CALL SP_AddAssessmentMasterRubrics(IN_AcademicYearDest, @IN_GPIIdx, IN_AcademicProgramDest);
            END;
            END IF;
            END LOOP dataLoop;

            CLOSE cursor1;

            CALL SP_DuplicateCrossPrmsAssmntRubrics(
                    IN_AcademicYearSource, IN_AcademicYearDest, IN_AcademicProgramSource, IN_AcademicProgramDest);

        END;
    END IF;


	COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_DuplicateCrossPrmsStudentOutcomes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_DuplicateCrossPrmsStudentOutcomes`(
    IN IN_AcademicYearFrom INT,
    IN IN_AcademicYearTo INT,
    IN IN_AcademicProgramFrom INT,
    IN IN_AcademicProgramTo INT
)
BEGIN
	DECLARE done TINYINT DEFAULT FALSE; -- A boolean variable to tell us when the cursor is out of data
	DECLARE _FromSO VARCHAR (50);
	DECLARE _FromDesc VARCHAR (2048);

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    IF NOT EXISTS (SELECT 1 FROM `StudentOutcomes`
        WHERE `AcademicYear`=IN_AcademicYearFrom AND `AcademicProgram`=IN_AcademicProgramFrom) THEN
   -- The selected year does not have student outcomes.
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09500011';

    ELSEIF EXISTS (SELECT 1 FROM `StudentOutcomes`
            WHERE `AcademicYear`=IN_AcademicYearTo AND `AcademicProgram`=IN_AcademicProgramTo) THEN
       -- The selected year has student outcomes already.
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09500012';

    ELSE
    BEGIN

        -- cursor1 is an arbitrary label, an identifier for the cursor
        DECLARE cursor1
            CURSOR FOR
            SELECT `STNTOUTCMS`.`SO`, `STNTOUTCMS`.`Description`
                FROM `StudentOutcomes` AS `STNTOUTCMS`
                WHERE `STNTOUTCMS`.`AcademicYear`=IN_AcademicYearFrom
                    AND `STNTOUTCMS`.`AcademicProgram`=IN_AcademicProgramFrom;

        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
        START TRANSACTION;
        -- open the cursor
        OPEN cursor1;

        dataLoop: LOOP
            FETCH NEXT FROM cursor1 INTO _FromSO, _FromDesc;
            IF done THEN
                LEAVE dataLoop;
            ELSEIF _FromSO IS NOT NULL AND _FromDesc IS NOT NULL THEN
                INSERT INTO `StudentOutcomes`(`AcademicYear`, `SO`, `Description`, `AcademicProgram`)
                VALUES (IN_AcademicYearTo, _FromSO, _FromDesc, IN_AcademicProgramTo);
            END IF;
        END LOOP dataLoop;

        CLOSE cursor1;
        COMMIT;

    END;
    END IF;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_DuplicatePI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_DuplicatePI`(
    IN p_AcademicYearFrom VARCHAR(20),
    IN p_AcademicYearTo VARCHAR(20),
    IN p_AcademicProgram VARCHAR(50)
)
BEGIN
    -- Declare variables for error handling
    DECLARE v_source_exists INT;
    DECLARE v_target_exists INT;
    DECLARE v_done INT DEFAULT FALSE;
    DECLARE v_last_gpi_idx INT;

    -- Cursor variables
    DECLARE v_academic_year VARCHAR(20);
    DECLARE v_so_idx INT;
    DECLARE v_gpi VARCHAR(50);
    DECLARE v_description TEXT;


    -- Declare cursor for GPI insertion
    DECLARE pi_cursor CURSOR FOR
    SELECT
        p_AcademicYearTo,
        new_so.Idx,
        gpi.GPI,
        gpi.Description
    FROM `StudentOutcomes` AS old_so
             INNER JOIN `GeneralPerformanceIndicators` AS gpi
                        ON gpi.SOIdx = old_so.Idx
             INNER JOIN `StudentOutcomes` AS new_so
                        ON new_so.SO = old_so.SO
                            AND new_so.AcademicYear = p_AcademicYearTo
                            AND new_so.AcademicProgram = p_AcademicProgram
    WHERE old_so.AcademicYear = p_AcademicYearFrom
      AND old_so.AcademicProgram = p_AcademicProgram;


    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Declare handler for cursor
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    -- Check if source information exists
    SELECT COUNT(*) INTO v_source_exists
    FROM `GeneralPerformanceIndicators`
    WHERE `AcademicYear` = p_AcademicYearFrom
      AND `AcademicProgram` = p_AcademicProgram;

    IF v_source_exists = 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x09500011';
    END IF;

    -- Check if target information already exists
    SELECT COUNT(*) INTO v_target_exists
    FROM `GeneralPerformanceIndicators`
    WHERE `AcademicYear` = p_AcademicYearTo
      AND `AcademicProgram` = p_AcademicProgram;

    IF v_target_exists > 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x09500012';
    END IF;

        -- Start transaction
    START TRANSACTION;

    -- Open cursor
    OPEN pi_cursor;

    -- Loop through cursor
    pi_loop: LOOP
            FETCH pi_cursor INTO v_academic_year, v_so_idx, v_gpi, v_description;

            IF v_done THEN
                LEAVE pi_loop;
    END IF;

    -- Insert new GPI
    INSERT INTO `GeneralPerformanceIndicators`
    (`AcademicYear`, `SOIdx`, `GPI`, `Description`, `AcademicProgram`)
    VALUES
        (v_academic_year, v_so_idx, v_gpi, v_description, p_AcademicProgram);

    -- Get the last inserted ID
    SET v_last_gpi_idx = LAST_INSERT_ID();

    -- Call SP_AddAssessmentMasterRubrics for the newly inserted GPI
    CALL SP_AddAssessmentMasterRubrics(v_academic_year, v_last_gpi_idx, p_AcademicProgram);

    END LOOP;

    -- Close cursor
    CLOSE pi_cursor;

    CALL SP_DuplicateAssmntRubrics(p_AcademicYearFrom, p_AcademicYearTo, p_AcademicProgram);

    -- Commit transaction
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_DuplicateSO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_DuplicateSO`(
    IN IN_AcademicYearFrom INT,
    IN IN_AcademicYearTo INT,
    IN IN_AcademicProgram INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF NOT EXISTS (SELECT 1 FROM `StudentOutcomes`
            WHERE `AcademicYear`=IN_AcademicYearFrom AND `AcademicProgram`=IN_AcademicProgram) THEN
       -- The selected year does not have student outcomes.
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09500011';

    ELSEIF EXISTS (SELECT 1 FROM `StudentOutcomes`
            WHERE `AcademicYear`=IN_AcademicYearTo AND `AcademicProgram`=IN_AcademicProgram) THEN
       -- The selected year has student outcomes already.
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09500012';

    ELSE
        -- Proceed with duplication
        INSERT INTO `StudentOutcomes`
            (`AcademicYear`, `SO`, `Description`, `AcademicProgram`)
            SELECT
                IN_AcademicYearTo, `SO`, `Description`, `AcademicProgram`
            FROM
                `StudentOutcomes`
            WHERE
                `AcademicYear` = IN_AcademicYearFrom
              AND `AcademicProgram` = IN_AcademicProgram;

    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_Evaluator_Assign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_Evaluator_Assign`(IN IN_AbetCourseIdx INT, IN IN_EvaluatorIdx INT)
BEGIN
	START TRANSACTION;

    INSERT INTO `AbetCourses_Evaluators`(`AbetCourseIdx`, `Evaluator`)
    VALUES (IN_AbetCourseIdx, IN_EvaluatorIdx);

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_Evaluator_Unassign` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_Evaluator_Unassign`(IN IN_AbetCourseIdx INT)
BEGIN
	START TRANSACTION;

    DELETE FROM `AbetCourses_Evaluators` WHERE `AbetCourseIdx` = IN_AbetCourseIdx;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAbetCourseAssessments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAbetCourseAssessments`(
    IN IN_AbetCourseSubject VARCHAR(5),
    IN IN_AbetCourseNum VARCHAR(5),
    IN IN_AcademicProgram INT,
    IN IN_AcademicYear INT
)
BEGIN

    SELECT
        `ABETCRSES`.`Idx` AS `ABCIdx`,
        `AVCRSES`.`Idx` AS `AVCIdx`,
        GROUP_CONCAT(DISTINCT `STNTOUTCMS`.`SO` ORDER BY `STNTOUTCMS`.`SO` SEPARATOR '|') AS `SO`,
        GROUP_CONCAT(DISTINCT CONCAT_WS(': ', `STNTOUTCMS`.`SO`, `STNTOUTCMS`.`Description`) ORDER BY `STNTOUTCMS`.`SO` SEPARATOR '|') AS `DESC`,
        GROUP_CONCAT(DISTINCT `UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR ',') AS `Instructor`,
        `AVCRSES`.`CourseNo`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,

        -- Get semester explanation directly from Semesters table
        `SMSTRS`.`Explanation` AS `Semester`,

        GROUP_CONCAT(CONCAT_WS(':', `STNTOUTCMS`.`SO`, `ASSMNTMEASURES`.`Idx`, CONCAT(`ASSMNTMEASURES`.`AssignmentType`, ' ', `ASSMNTMEASURES`.`AssignmentNum`)) SEPARATOR '|') AS `AssignmentType`,
        GROUP_CONCAT(CONCAT(`ASSMNTMEASURES`.`Idx`, ':', `ASSMNTMEASURES`.`Measure`) ORDER BY `ASSMNTMEASURES`.`Measure` SEPARATOR '|') AS `Measures`,
        GROUP_CONCAT(CONCAT(`ASSMNTMEASURES`.`Idx`, ':', `ASSMNTMEASURES`.`AssignmentProblem`) ORDER BY `ASSMNTMEASURES`.`Measure` SEPARATOR '|') AS `AssignmentProblems`,
        GROUP_CONCAT(CONCAT(`ASSMNTMEASURES`.`Idx`, ':', `ASSMNTMEASURES`.`ActualAssmntSample`) ORDER BY `ASSMNTMEASURES`.`Measure` SEPARATOR '|') AS `ActualAssmntSamples`,
        GROUP_CONCAT(CONCAT(`ASSMNTMEASURES`.`Idx`, ':', `ASSMNTMEASURES`.`AssignmentDescription`) ORDER BY `ASSMNTMEASURES`.`Measure` SEPARATOR '|') AS `AssignmentDescriptions`,
        `AYS`.`AcademicYear`

    FROM `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AcademicYears` AS `AYS`
            ON (`ABETCRSES`.`AcademicYear` = `AYS`.`Idx`)
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS`
            ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        INNER JOIN `AVCourses` AS `AVCRSES`
            ON (`AYS`.`From` <= `AVCRSES`.`Semester` AND `AYS`.`To` >= `AVCRSES`.`Semester` AND `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`)

        -- Join to get semester explanation from Semesters table
        LEFT JOIN `Semesters` AS `SMSTRS`
            ON (`AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`)

        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS`
            ON (`AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`)
        INNER JOIN `UserAccounts` AS `UA`
            ON (`AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`)
        INNER JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS`
            ON (`ABETCRSES`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx`)
        LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS`
            ON (`ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx` AND `ABETCRSES_GPIS`.`AbetCourseIdx` = `ABETCRSES_SOS`.`AbetCourseIdx`)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
            ON (`ABETCRSES_SOS`.`SOIdx` = `STNTOUTCMS`.`Idx`)
        LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES`
            ON (`ASSMNTMEASURES`.`AvailableCourseIdx` = `AVCRSES`.`Idx` AND `ASSMNTMEASURES`.`AbetCourseIdx` = `ABETCRSES`.`Idx` AND `ASSMNTMEASURES`.`GPI` = `ABETCRSES_GPIS`.`GPIIdx`)

    WHERE `AVCRSES`.`Subject` = IN_AbetCourseSubject
        AND `AVCRSES`.`Num` = IN_AbetCourseNum
        AND `ABETCRSES`.`AcademicYear` = IN_AcademicYear
        AND `ABETCRSES`.`AcademicProgram` = IN_AcademicProgram

    GROUP BY `ABETCRSES`.`Idx`, `AVCRSES`.`Idx`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAbetCourseAssessmentsBySO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAbetCourseAssessmentsBySO`(
    IN IN_SOIdx INT,
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT
        `ABETCRSES`.`Idx` AS `ABCIdx`,
        `AVCRSES`.`Idx` AS `AVCIdx`,
        GROUP_CONCAT(DISTINCT `STNTOUTCMS`.`SO` ORDER BY `STNTOUTCMS`.`SO` SEPARATOR '|') AS `SO`,
        GROUP_CONCAT(DISTINCT `UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR ',') AS `Instructor`,
        `AVCRSES`.`CourseNo`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,

        -- Get semester explanation directly from Semesters table
        `SMSTRS`.`Explanation` AS `Semester`,

        GROUP_CONCAT(CONCAT_WS(':', `STNTOUTCMS`.`SO`, `ASSMNTMEASURES`.`Idx`, CONCAT(`ASSMNTMEASURES`.`AssignmentType`, ' ', `ASSMNTMEASURES`.`AssignmentNum`, ' ', `ASSMNTMEASURES`.`AssignmentProblem`), `ASSMNTMEASURES`.`AssignmentDescription`) SEPARATOR '|') AS `AssignmentType`

    FROM `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AcademicYears` AS `AYS`
            ON (`ABETCRSES`.`AcademicYear` = `AYS`.`Idx`)
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS`
            ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        INNER JOIN `AVCourses` AS `AVCRSES`
            ON (`AYS`.`From` <= `AVCRSES`.`Semester` AND `AYS`.`To` >= `AVCRSES`.`Semester` AND `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`)

        -- Join to get semester explanation from Semesters table
        LEFT JOIN `Semesters` AS `SMSTRS`
            ON (`AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`)

        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS`
            ON (`AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`)
        INNER JOIN `UserAccounts` AS `UA`
            ON (`AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`)
        INNER JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS`
            ON (`ABETCRSES`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx`)
        LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS`
            ON (`ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx` AND `ABETCRSES_GPIS`.`AbetCourseIdx` = `ABETCRSES_SOS`.`AbetCourseIdx`)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
            ON (`ABETCRSES_SOS`.`SOIdx` = `STNTOUTCMS`.`Idx`)
        LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES`
            ON (`ASSMNTMEASURES`.`AvailableCourseIdx` = `AVCRSES`.`Idx` AND `ASSMNTMEASURES`.`AbetCourseIdx` = `ABETCRSES`.`Idx` AND `ASSMNTMEASURES`.`GPI` = `ABETCRSES_GPIS`.`GPIIdx`)

    WHERE `STNTOUTCMS`.`Idx` = IN_SOIdx
        AND `ABETCRSES`.`AcademicYear` = IN_AcademicYear
        AND `ABETCRSES`.`AcademicProgram` = IN_AcademicProgram

    GROUP BY `STNTOUTCMS`.`SO`, `ABETCRSES`.`Idx`, `AVCRSES`.`Idx`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAbetCourseCntinusImprvmnt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAbetCourseCntinusImprvmnt`(
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT
        `ABETCRSES`.`Idx` AS `ABCIdx`,
        `AVCRSES`.`Idx` AS `AVCIdx`,
        `AVCRSES`.`CourseNo`,
        GROUP_CONCAT(DISTINCT `UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR ',') AS `Instructor`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,
        `SMSTRS`.`Explanation` AS `Semester`,
        `CNTNUSIMPRVMNT`.`FacultyReflection`

    FROM `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AcademicYears` AS `AYS`
            ON (`ABETCRSES`.`AcademicYear` = `AYS`.`Idx`)
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS`
            ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        INNER JOIN `AVCourses` AS `AVCRSES`
            ON (`AYS`.`From` <= `AVCRSES`.`Semester` AND `AYS`.`To` >= `AVCRSES`.`Semester` AND `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`)
        LEFT JOIN `Semesters` AS `SMSTRS`
            ON (`AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`)
        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS`
            ON (`AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`)
        INNER JOIN `UserAccounts` AS `UA`
            ON (`AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`)
        LEFT JOIN `ContinuousImprovement` AS `CNTNUSIMPRVMNT`
            ON (`CNTNUSIMPRVMNT`.`AvailableCourseIdx` = `AVCRSES`.`Idx` AND `CNTNUSIMPRVMNT`.`AbetCourseIdx` = `ABETCRSES`.`Idx`)

    WHERE `ABETCRSES`.`AcademicYear` = IN_AcademicYear
        AND `ABETCRSES`.`AcademicProgram` = IN_AcademicProgram

    GROUP BY
        `ABETCRSES`.`Idx`,
        `AVCRSES`.`Idx`,
        `AVCRSES`.`CourseNo`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,
        `SMSTRS`.`Explanation`,
        `CNTNUSIMPRVMNT`.`FacultyReflection`
    ORDER BY `AVCRSES`.`CourseNo`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAbetCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAbetCourses`(IN IN_AcademicYear INT, IN IN_AcademicProgram INT )
BEGIN
        SELECT `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Title`
        FROM `AbetCourses` AS `ABETCRSES`
            INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`)
            INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`)
            INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        WHERE `ABETCRSES`.`AcademicProgram`=IN_AcademicProgram AND `AYS`.`Idx`=IN_AcademicYear
        GROUP BY `AVCRSES`.`Subject`, `AVCRSES`.`Num`
        ORDER BY `AVCRSES`.`Subject`, `AVCRSES`.`Num` ASC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears`()
BEGIN

    SELECT DISTINCT `Idx`, `AcademicYear`, `From`, `To`
    FROM `AcademicYears`
    ORDER BY `AcademicYear` DESC LIMIT 10;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears_AMRExistence_InProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears_AMRExistence_InProgram`(
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT DISTINCT
        AY.Idx,
        AY.AcademicYear
    FROM AssessmentMasterRubrics AMR
             INNER JOIN AcademicYears AY
                        ON AMR.AcademicYear = AY.Idx
    WHERE AMR.AcademicProgram = IN_AcademicProgram
    ORDER BY AY.AcademicYear DESC
        LIMIT 10;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears_CMExistence_InProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears_CMExistence_InProgram`(
    IN IN_AcademicProgram INT
)
BEGIN


    SELECT AY.Idx, AY.AcademicYear
    FROM AcademicYears AS AY
             INNER JOIN CourseMapping_Courses AS CM ON CM.AcademicYear = AY.Idx
    WHERE CM.AcademicProgram = IN_AcademicProgram
    GROUP BY AY.Idx, AY.AcademicYear
    ORDER BY AY.AcademicYear DESC
        LIMIT 10;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears_CMNonExistence_InProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears_CMNonExistence_InProgram`(
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT AY.Idx, AY.AcademicYear
    FROM AcademicYears AS AY
         LEFT JOIN CourseMapping_Courses AS CM ON (CM.AcademicYear = AY.Idx AND CM.AcademicProgram = IN_AcademicProgram)
         INNER JOIN GeneralPerformanceIndicators AS GPI ON (GPI.AcademicYear = AY.Idx AND GPI.AcademicProgram = IN_AcademicProgram)
    WHERE CM.Idx IS NULL
    GROUP BY AY.Idx, AY.AcademicYear
    ORDER BY AY.AcademicYear DESC
        LIMIT 10;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears_PIExistence_InOtherPrograms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears_PIExistence_InOtherPrograms`(
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT DISTINCT
        AP.Idx AS APIdx,
        AP.Name,
        AY.Idx AS AYIdx,
        AY.AcademicYear
    FROM AcademicPrograms AP
             INNER JOIN GeneralPerformanceIndicators PI
                        ON PI.AcademicProgram = AP.Idx
             LEFT JOIN AcademicYears AY
                       ON PI.AcademicYear = AY.Idx
    WHERE AP.Idx != IN_AcademicProgram
    ORDER BY AY.AcademicYear DESC
        LIMIT 20;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears_PIExistence_InProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears_PIExistence_InProgram`(
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT DISTINCT
        `AY`.`Idx`,
        `AY`.`AcademicYear`
    FROM `GeneralPerformanceIndicators` AS `PI`
        INNER JOIN `AcademicYears` AS `AY`
            ON (`PI`.`AcademicYear`=`AY`.`Idx`)
    WHERE `AcademicProgram`=IN_AcademicProgram
    ORDER BY
        `AY`.`AcademicYear` DESC
        LIMIT 10;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears_PINonExistence_InProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears_PINonExistence_InProgram`(
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT DISTINCT AY.*
    FROM AcademicYears AY
             INNER JOIN StudentOutcomes SO ON AY.Idx = SO.AcademicYear
    WHERE SO.AcademicProgram = IN_AcademicProgram
      AND NOT EXISTS (
        SELECT 1
        FROM GeneralPerformanceIndicators GPI
        WHERE GPI.SOIdx = SO.Idx
          AND GPI.AcademicProgram = IN_AcademicProgram
    )
    ORDER BY AY.AcademicYear DESC
        LIMIT 10;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears_SOExistence_InOtherPrograms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears_SOExistence_InOtherPrograms`(
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT DISTINCT
        AY.`Idx` AS AYIdx,
        AY.`AcademicYear`,
        AP.`Idx` AS APIdx,
        AP.`Name`
    FROM
        `StudentOutcomes` AS SO
            INNER JOIN `AcademicYears` AS AY
                       ON SO.`AcademicYear` = AY.`Idx`
            INNER JOIN `AcademicPrograms` AS AP
                        ON SO.`AcademicProgram` = AP.`Idx`
    WHERE
        SO.`AcademicProgram` <> IN_AcademicProgram
    ORDER BY
        AY.`AcademicYear` DESC
        LIMIT 20;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears_SOExistence_InProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears_SOExistence_InProgram`(
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT DISTINCT
        AY.`Idx`,
        AY.`AcademicYear`
    FROM
        `StudentOutcomes` AS SO
            INNER JOIN `AcademicYears` AS AY
                       ON SO.`AcademicYear` = AY.`Idx`
    WHERE
        SO.`AcademicProgram` = IN_AcademicProgram
    ORDER BY
        AY.`AcademicYear` DESC
        LIMIT 10;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAcademicYears_SONonExistence_InProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAcademicYears_SONonExistence_InProgram`(
    IN IN_AcademicProgram INT
)
BEGIN
    SELECT
        AY.`Idx`,
        AY.`AcademicYear`
    FROM
        `AcademicYears` AS AY
    WHERE
        AY.`Idx` NOT IN (
            SELECT DISTINCT
                SO.`AcademicYear`
            FROM
                `StudentOutcomes` AS SO
            WHERE
                SO.`AcademicProgram` = IN_AcademicProgram
        )
    ORDER BY
        AY.`AcademicYear` DESC
        LIMIT 10;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAllAbetCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAllAbetCourses`(IN IN_AcademicProgram INT )
BEGIN

        SELECT `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Title`
        FROM `AbetCourses` AS `ABETCRSES`
            INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`)
            INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`)
            INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        WHERE `ABETCRSES`.`AcademicProgram`=IN_AcademicProgram GROUP BY `AVCRSES`.`Subject`, `AVCRSES`.`Num`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchAssmntRubrics_DiffInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchAssmntRubrics_DiffInfo`(
    IN p_AcademicYear1 INT,
    IN p_AcademicYear2 INT,
    IN p_AcademicProgram INT
)
BEGIN

    SELECT
        t1.SO,
        t1.GPI,
        t1.LevelofAttainment as LOA,
        t1.AcademicProgram,
        ap.Name,
        ap.Degree,
        t1.Description AS Description_1,
        t2.Description AS Description_2,
        t1.Comments AS Comments_1,
        t2.Comments AS Comments_2,
        t1.TobeRemoved AS TobeRemoved_1,
        t2.TobeRemoved AS TobeRemoved_2,
        t1.Approval AS Approval_1,
        t2.Approval AS Approval_2,
        t1.AcademicYear AS AcademicYear_1,
        t2.AcademicYear AS AcademicYear_2
FROM
        (SELECT
            so1.SO, pi1.GPI, ay1.AcademicYear, ar1.LevelofAttainment, ar1.Description,
            ar1.Comments, ar1.Approval, ar1.TobeRemoved, pi1.AcademicProgram
         FROM `AssessmentMasterRubrics` ar1
                INNER JOIN `GeneralPerformanceIndicators` pi1
                            ON ar1.GPIIdx = pi1.Idx
                  INNER JOIN `StudentOutcomes` so1
                            ON pi1.SOIdx = so1.Idx
                  LEFT JOIN `AcademicYears` ay1
                            ON ay1.Idx = pi1.AcademicYear
         WHERE pi1.AcademicYear = p_AcademicYear1 AND pi1.AcademicProgram = p_AcademicProgram
        ) t1
            JOIN
        (SELECT
             so2.SO, pi2.GPI, ay2.AcademicYear, ar2.LevelofAttainment, ar2.Description,
            ar2.Comments, ar2.Approval, ar2.TobeRemoved
         FROM `AssessmentMasterRubrics` ar2
                INNER JOIN `GeneralPerformanceIndicators` pi2
                           ON ar2.GPIIdx = pi2.Idx
                  INNER JOIN `StudentOutcomes` so2
                             ON pi2.SOIdx = so2.Idx
                  LEFT JOIN `AcademicYears` ay2
                            ON ay2.Idx = pi2.AcademicYear
         WHERE pi2.AcademicYear = p_AcademicYear2 AND pi2.AcademicProgram = p_AcademicProgram
        ) t2
        ON t1.SO = t2.SO AND t1.GPI = t2.GPI AND t1.LevelofAttainment = t2.LevelofAttainment
            LEFT JOIN `AcademicPrograms` ap
                      ON ap.Idx = t1.AcademicProgram
    ORDER BY t1.SO, t1.GPI, t1.LevelofAttainment;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchClassRoster` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchClassRoster`(
    IN p_AvailableCourseIdx INT,
    IN IN_DB_EncryptionKey VARCHAR(255)
)
BEGIN
    -- Retrieve student roster with decrypted information and academic program details
    -- Include ALL students (both active and dropped)
    SELECT
        cr.`StudentNo`,
        IFNULL(CAST(AES_DECRYPT(cr.`StudentName`, IN_DB_EncryptionKey) AS CHAR), '') AS `StudentName`,
        cr.`StudentMajor`,
        IFNULL(cr.`IsDropped`, 0) AS `IsDropped`,
        ap.`Idx` AS `AcademicProgramIdx`,
        ap.`Name` AS `AcademicProgramName`,
        ap.`Degree`
    FROM
        `ClassRoster` cr
    LEFT JOIN
        `AcademicPrograms` ap ON cr.`AcademicProgramIdx` = ap.`Idx`
    WHERE
        cr.`AvailableCourseIdx` = p_AvailableCourseIdx
    ORDER BY
        cr.`StudentNo` ASC;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchCourseLevelEvaluationResults` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchCourseLevelEvaluationResults`(
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT
        `ABETCRSES`.`Idx` AS `ABCIdx`,
        `AVCRSES`.`Idx` AS `AVCIdx`,
        `STNTOUTCMS`.`SO` AS `SO`,
        GROUP_CONCAT(DISTINCT `UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR ',') AS `Instructor`,
        `AVCRSES`.`CourseNo`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,

        -- Get semester explanation directly from Semesters table
        `SMSTRS`.`Explanation` AS `Semester`,

        AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
        COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
        SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE NULL END) AS `TOPFIFTY`,
        SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE NULL END) AS `TOPTWENTYFIVE`,
        `STNTOUTCMS`.`Idx` AS `SO_Order`

    FROM `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AcademicYears` AS `AYS`
            ON (`ABETCRSES`.`AcademicYear` = `AYS`.`Idx`)
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS`
            ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        INNER JOIN `AVCourses` AS `AVCRSES`
            ON (`AYS`.`From` <= `AVCRSES`.`Semester` AND `AYS`.`To` >= `AVCRSES`.`Semester` AND `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`)

        -- Join to get semester explanation from Semesters table
        LEFT JOIN `Semesters` AS `SMSTRS`
            ON (`AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`)

        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS`
            ON (`AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`)
        INNER JOIN `UserAccounts` AS `UA`
            ON (`AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`)
        INNER JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS`
            ON (`ABETCRSES`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx`)
        LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS`
            ON (`ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx` AND `ABETCRSES_GPIS`.`AbetCourseIdx` = `ABETCRSES_SOS`.`AbetCourseIdx`)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS`
            ON (`ABETCRSES_SOS`.`SOIdx` = `STNTOUTCMS`.`Idx`)
        LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES`
            ON (`ASSMNTMEASURES`.`AvailableCourseIdx` = `AVCRSES`.`Idx` AND `ASSMNTMEASURES`.`AbetCourseIdx` = `ABETCRSES`.`Idx` AND `ASSMNTMEASURES`.`GPI` = `ABETCRSES_GPIS`.`GPIIdx`)
        LEFT JOIN `Scoresheet` AS `SCSHEET`
            ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)

    WHERE `ABETCRSES`.`AcademicYear` = IN_AcademicYear
        AND `ABETCRSES`.`AcademicProgram` = IN_AcademicProgram
        AND EXISTS (
            SELECT 1
            FROM `AssessmentMeasures` AS `AM_CHECK`
            INNER JOIN `Scoresheet` AS `SC_CHECK`
                ON (`AM_CHECK`.`Idx` = `SC_CHECK`.`AssessmentMeasureIdx`)
            WHERE `AM_CHECK`.`AvailableCourseIdx` = `AVCRSES`.`Idx`
                AND `AM_CHECK`.`AbetCourseIdx` = `ABETCRSES`.`Idx`
                AND `SC_CHECK`.`LevelOfAttainment` IS NOT NULL
        )

    GROUP BY
        `ABETCRSES`.`Idx`,
        `AVCRSES`.`Idx`,
        `STNTOUTCMS`.`SO`,
        `AVCRSES`.`CourseNo`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,
        `SMSTRS`.`Explanation`,
        `STNTOUTCMS`.`Idx`

    ORDER BY `AVCRSES`.`CourseNo`, `STNTOUTCMS`.`Idx`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchCourseMetadata` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchCourseMetadata`(
    IN IN_AbetCourseIdx INT,
    IN IN_AvailableCourseIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN
    SELECT
        COALESCE(ci.`NumStudents`, 0) AS `NumStudents`,
        (SELECT
            CASE
                WHEN EXISTS (
                    SELECT 1
                    FROM `ClassRoster` cr_check
                    WHERE cr_check.`AvailableCourseIdx` = IN_AvailableCourseIdx
                    AND cr_check.`AcademicProgramIdx` = IN_AcademicProgramIdx
                ) THEN (
                    SELECT COUNT(*)
                    FROM `ClassRoster` cr
                    WHERE cr.`AvailableCourseIdx` = IN_AvailableCourseIdx
                    AND cr.`AcademicProgramIdx` = IN_AcademicProgramIdx
                    AND (cr.`IsDropped` = 0 OR cr.`IsDropped` IS NULL)
                )
                ELSE NULL
            END
        ) AS `ClassRosterCount`,
        COALESCE(
            CASE
                WHEN ci.`FacultyReflection` IS NOT NULL
                    AND ci.`FacultyReflection` != ''
                THEN 1
                ELSE 0
            END, 0
        ) AS `IsCourseLocked`
    FROM (SELECT 1) dummy
    LEFT JOIN `ContinuousImprovement` ci
        ON ci.`AbetCourseIdx` = IN_AbetCourseIdx
        AND ci.`AvailableCourseIdx` = IN_AvailableCourseIdx;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchGPIInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchGPIInfo`( IN IN_AbetCourseIdx INT, IN IN_AcademicYear VARCHAR(20), IN IN_AcademicProgram INT )
BEGIN

    SELECT `ABETCRSES_GPIS`.`GPIIdx`, `STNTOUTCMS`.`SO`, `GPIS`.`GPI`, `GPIS`.`Description`
    FROM `AbetCourses_GPIs` AS `ABETCRSES_GPIS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`ABETCRSES_GPIS`.`GPIIdx` = `GPIS`.`Idx`)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`ABETCRSES_GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx`)
        INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES_GPIS`.`AcademicYear`=`AYS`.`Idx`)
    WHERE `ABETCRSES_GPIS`.`AbetCourseIdx`=IN_AbetCourseIdx
        AND `AYS`.`AcademicYear`=IN_AcademicYear
        AND `ABETCRSES_GPIS`.`AcademicProgram`=IN_AcademicProgram
    ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchGPIInfo2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchGPIInfo2`( IN IN_AbetCourseIdx INT, IN IN_AcademicYear VARCHAR(20), IN IN_AcademicProgram INT )
BEGIN
    DECLARE V_PrimaryCourseIdx INT;
    DECLARE V_IsReference INT;
    
    -- Check if the provided course is a Reference
    SELECT `Reference`, IFNULL(`Reference`, IN_AbetCourseIdx)
    INTO V_IsReference, V_PrimaryCourseIdx
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdx;
    
    -- If Reference column has a value, use that as the Primary course index
    -- Otherwise, use the provided course index (it's already Primary)
    IF V_IsReference IS NOT NULL AND V_IsReference > 0 THEN
        SET V_PrimaryCourseIdx = V_IsReference;
    ELSE
        SET V_PrimaryCourseIdx = IN_AbetCourseIdx;
    END IF;

    -- Fetch GPIs using the Primary course index
    SELECT `ABETCRSES_GPIS`.`GPIIdx`, `STNTOUTCMS`.`SO`, `GPIS`.`GPI`, `GPIS`.`Description`
    FROM `AbetCourses_GPIs` AS `ABETCRSES_GPIS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`ABETCRSES_GPIS`.`GPIIdx` = `GPIS`.`Idx`)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`ABETCRSES_GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx`)
        INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES_GPIS`.`AcademicYear`=`AYS`.`Idx`)
    WHERE `ABETCRSES_GPIS`.`AbetCourseIdx` = V_PrimaryCourseIdx
        AND `AYS`.`AcademicYear` = IN_AcademicYear
        AND `ABETCRSES_GPIS`.`AcademicProgram` = IN_AcademicProgram
    ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchGPIInfoWithLockStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchGPIInfoWithLockStatus`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicYear VARCHAR(20),
    IN IN_AcademicProgram INT
)
BEGIN
    -- Return lock status and GPI data in one result set
    SELECT
        `ABETCRSES_GPIS`.`GPIIdx`,
        `STNTOUTCMS`.`SO`,
        `GPIS`.`GPI`,
        `GPIS`.`Description`,
        -- Add lock status as a column in every row
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM `ContinuousImprovement`
                WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
                    AND `AbetCourseIdx` = IN_AbetCourseIdx
                    AND `FacultyReflection` IS NOT NULL
                    AND `FacultyReflection` != ''
            ) THEN 1
            ELSE 0
        END AS `IsCourseLocked`
    FROM `AbetCourses_GPIs` AS `ABETCRSES_GPIS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`ABETCRSES_GPIS`.`GPIIdx` = `GPIS`.`Idx`)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`ABETCRSES_GPIS`.`SOIdx` = `STNTOUTCMS`.`Idx`)
        INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES_GPIS`.`AcademicYear` = `AYS`.`Idx`)
    WHERE `ABETCRSES_GPIS`.`AbetCourseIdx` = IN_AbetCourseIdx
        AND `AYS`.`AcademicYear` = IN_AcademicYear
        AND `ABETCRSES_GPIS`.`AcademicProgram` = IN_AcademicProgram
    ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchInstructorsInfoForSendingEmails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchInstructorsInfoForSendingEmails`(
    IN IN_ConditionStatement TEXT
)
BEGIN

    -- Build dynamic SQL with Semesters table join
    SET @sql_text = CONCAT("
        SELECT
            `SMSTRS`.`Explanation` AS `Semester`,
            GROUP_CONCAT(CONCAT_WS(' ', `AVCRSES`.`CourseNo`, `AVCRSES`.`Title`) SEPARATOR ', ') AS `Courses`,
            `UA`.`Name`,
            `UA`.`Email`
        FROM `AVCourses` AS `AVCRSES`
            LEFT JOIN `Semesters` AS `SMSTRS`
                ON (`AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`)
            LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS`
                ON (`AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`)
            INNER JOIN `UserAccounts` AS `UA`
                ON (`AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`)
        WHERE `AVCRSES`.`Idx` = ", IN_ConditionStatement, "
        GROUP BY `SMSTRS`.`Explanation`, `AVINSTRUCTORS`.`Instructor`
        ORDER BY `AVINSTRUCTORS`.`Instructor`, `AVCRSES`.`Semester`
    ");

    PREPARE stmt FROM @sql_text;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchOverallAbetCourseAssessmentsByGPI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchOverallAbetCourseAssessmentsByGPI`(IN IN_AcademicYear INT, IN IN_AcademicProgram INT )
BEGIN

    SELECT
        AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
        COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
        SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE NULL END) AS `TOPFIFTY`,
        SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE NULL END) AS `TOPTWENTYFIVE`,
        CONCAT_WS('-',`STNTOUTCMS`.`SO`, `GPIS`.`GPI`) AS `GPI`,
        `GPIS`.`Idx` AS `GPIIdx`,
        `GPIS`.`Description` AS `GPIDescription`
    FROM `StudentOutcomes` AS `STNTOUTCMS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
        LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI`=`GPIS`.`Idx`)
        LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)
    WHERE `GPIS`.`AcademicYear`=IN_AcademicYear AND `GPIS`.`AcademicProgram`=IN_AcademicProgram AND `GPIS`.`TobeRemoved`=0
    GROUP BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI` ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchOverallAbetCourseAssessmentsByGPI_MultiYears` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchOverallAbetCourseAssessmentsByGPI_MultiYears`(
    IN IN_AcademicYears TEXT,
    IN IN_AcademicProgram INT
)
BEGIN

    -- Dynamic SQL to fetch yearly results
    SET @sql = CONCAT(
        'SELECT
            `GPIS`.`AcademicYear` AS `AcademicYearIdx`,
            `AYS`.`AcademicYear` AS `AcademicYear`,
            AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
            COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE 0 END) AS `TOPFIFTY`,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE 0 END) AS `TOPTWENTYFIVE`,
            CONCAT_WS(''-'', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`) AS `GPI`,
            `GPIS`.`Idx` AS `GPIIdx`,
            `GPIS`.`Description` AS `GPIDescription`
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
            LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI`=`GPIS`.`Idx`)
            LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)
            LEFT JOIN `AcademicYears` AS `AYS` ON (`GPIS`.`AcademicYear` = `AYS`.`Idx`)
        WHERE `GPIS`.`AcademicProgram` = ', IN_AcademicProgram, '
        AND `GPIS`.`AcademicYear` IN (', IN_AcademicYears, ')
        AND `GPIS`.`TobeRemoved` = 0
        GROUP BY `GPIS`.`AcademicYear`, `STNTOUTCMS`.`SO`, `GPIS`.`GPI`

        UNION ALL

        SELECT
            "Overall" AS `AcademicYearIdx`,
            "Overall" AS `AcademicYear`,
            AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
            COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE 0 END) AS `TOPFIFTY`,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE 0 END) AS `TOPTWENTYFIVE`,
            CONCAT_WS(''-'', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`) AS `GPI`,
            `GPIS`.`Idx` AS `GPIIdx`,
            `GPIS`.`Description` AS `GPIDescription`
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
            LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI`=`GPIS`.`Idx`)
            LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)
        WHERE `GPIS`.`AcademicProgram` = ', IN_AcademicProgram, '
        AND `GPIS`.`AcademicYear` IN (', IN_AcademicYears, ')
        AND `GPIS`.`TobeRemoved` = 0
        GROUP BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI`'
    );

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchOverallAbetCourseAssessmentsBySO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchOverallAbetCourseAssessmentsBySO`(IN IN_AcademicYear INT, IN IN_AcademicProgram INT )
BEGIN

    SELECT
        AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
        COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
        SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE NULL END) AS `TOPFIFTY`,
        SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE NULL END) AS `TOPTWENTYFIVE`,
        `STNTOUTCMS`.`SO` AS `SO`,
        `STNTOUTCMS`.`Idx` AS `SOIdx`,
        `STNTOUTCMS`.`Description` AS `SODescription`
    FROM `StudentOutcomes` AS `STNTOUTCMS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
        LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI`=`GPIS`.`Idx`)
        LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`)
    WHERE `GPIS`.`AcademicYear`=IN_AcademicYear AND `GPIS`.`AcademicProgram`=IN_AcademicProgram AND `STNTOUTCMS`.`TobeRemoved`=0
    GROUP BY `STNTOUTCMS`.`SO` ORDER BY `STNTOUTCMS`.`SO`;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchOverallAbetCourseAssessmentsBySO_MultiYears` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchOverallAbetCourseAssessmentsBySO_MultiYears`(
    IN IN_AcademicYears TEXT,
    IN IN_AcademicProgram INT
)
BEGIN

    SET @sql = CONCAT(
        'SELECT
            `GPIS`.`AcademicYear` AS `AcademicYearIdx`,
            `AYS`.`AcademicYear` AS `AcademicYear`,
            AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
            COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE 0 END) AS `TOPFIFTY`,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE 0 END) AS `TOPTWENTYFIVE`,
            `STNTOUTCMS`.`SO` AS `SO`,
            `STNTOUTCMS`.`Idx` AS `SOIdx`,
            `STNTOUTCMS`.`Description` AS `SODescription`
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
            LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
            LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
            LEFT JOIN `AcademicYears` AS `AYS` ON (`GPIS`.`AcademicYear` = `AYS`.`Idx`)
        WHERE `GPIS`.`AcademicProgram` = ', IN_AcademicProgram, '
        AND `GPIS`.`AcademicYear` IN (', IN_AcademicYears, ')
        AND `STNTOUTCMS`.`TobeRemoved` = 0
        GROUP BY `GPIS`.`AcademicYear`, `STNTOUTCMS`.`SO`

        UNION ALL

        SELECT
            "Overall" AS `AcademicYearIdx`,
            "Overall" AS `AcademicYear`,
            AVG(`SCSHEET`.`LevelOfAttainment`) AS `AVG`,
            COUNT(`SCSHEET`.`LevelOfAttainment`) AS `TOTAL`,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE 0 END) AS `TOPFIFTY`,
            SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE 0 END) AS `TOPTWENTYFIVE`,
            `STNTOUTCMS`.`SO` AS `SO`,
            `STNTOUTCMS`.`Idx` AS `SOIdx`,
            `STNTOUTCMS`.`Description` AS `SODescription`
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
            LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
            LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
        WHERE `GPIS`.`AcademicProgram` = ', IN_AcademicProgram, '
        AND `GPIS`.`AcademicYear` IN (', IN_AcademicYears, ')
        AND `STNTOUTCMS`.`TobeRemoved` = 0
        GROUP BY `STNTOUTCMS`.`SO`
        ORDER BY `AcademicYear`, `SO`'
    );

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchOverallAbetCourseAssessmentsBySO_PerStudent` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchOverallAbetCourseAssessmentsBySO_PerStudent`(
    IN IN_AcademicYear INT, 
    IN IN_AcademicProgram INT
)
BEGIN
    -- Get all Student Outcomes for this program/year
    WITH AllStudentOutcomes AS (
        SELECT DISTINCT
            `STNTOUTCMS`.`Idx` AS SOIdx,
            `STNTOUTCMS`.`SO`,
            `STNTOUTCMS`.`Description`
        FROM `StudentOutcomes` AS `STNTOUTCMS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
        WHERE `GPIS`.`AcademicYear` = IN_AcademicYear 
          AND `GPIS`.`AcademicProgram` = IN_AcademicProgram 
          AND `STNTOUTCMS`.`TobeRemoved` = 0
    ),
    -- Calculate student averages per SO from all their assessment scores
    StudentSOScores AS (
        SELECT
            `STNTOUTCMS`.`Idx` AS SOIdx,
            `STNTOUTCMS`.`SO`,
            `STNTOUTCMS`.`Description`,
            `SCSHEET`.`StudentNo`,
            `SCSHEET`.`LevelOfAttainment` AS Score
        FROM `StudentOutcomes` AS `STNTOUTCMS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
        INNER JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` 
            ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
        INNER JOIN `Scoresheet` AS `SCSHEET` 
            ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
        WHERE `GPIS`.`AcademicYear` = IN_AcademicYear 
          AND `GPIS`.`AcademicProgram` = IN_AcademicProgram 
          AND `STNTOUTCMS`.`TobeRemoved` = 0
          AND `SCSHEET`.`LevelOfAttainment` IS NOT NULL
    ),
    -- Calculate average score per student per SO
    StudentSOAverages AS (
        SELECT
            `SOIdx`,
            `SO`,
            `Description`,
            `StudentNo`,
            AVG(`Score`) AS StudentAverage
        FROM StudentSOScores
        GROUP BY `SOIdx`, `SO`, `Description`, `StudentNo`
    ),
    -- Calculate SO statistics across all students (only for SOs with data)
    SOStatistics AS (
        SELECT
            AVG(`StudentAverage`) AS `AVG`,
            COUNT(DISTINCT `StudentNo`) AS `TOTAL`,
            SUM(CASE WHEN `StudentAverage` >= 2 THEN 1 ELSE 0 END) AS `TOPFIFTY`,
            SUM(CASE WHEN `StudentAverage` >= 3 THEN 1 ELSE 0 END) AS `TOPTWENTYFIVE`,
            `SO`,
            `SOIdx`,
            `Description` AS `SODescription`
        FROM StudentSOAverages
        GROUP BY `SO`, `SOIdx`, `Description`
    )
    -- Left join to include all SOs, even those without student data
    SELECT
        COALESCE(`SOStats`.`AVG`, 0.0) AS `AVG`,
        COALESCE(`SOStats`.`TOTAL`, 0) AS `TOTAL`,
        COALESCE(`SOStats`.`TOPFIFTY`, 0) AS `TOPFIFTY`,
        COALESCE(`SOStats`.`TOPTWENTYFIVE`, 0) AS `TOPTWENTYFIVE`,
        `AllSOs`.`SO`,
        `AllSOs`.`SOIdx`,
        `AllSOs`.`Description` AS `SODescription`
    FROM AllStudentOutcomes AS `AllSOs`
    LEFT JOIN SOStatistics AS `SOStats`
        ON `AllSOs`.`SOIdx` = `SOStats`.`SOIdx`
    ORDER BY `AllSOs`.`SO`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchOverallAbetCourseAssessmentsBySO_PerStudent_MultiYears` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchOverallAbetCourseAssessmentsBySO_PerStudent_MultiYears`(
    IN IN_AcademicYears VARCHAR(255), 
    IN IN_AcademicProgram INT
)
BEGIN
    -- Get all Student Outcomes for this program/years
    WITH AllStudentOutcomes AS (
        SELECT DISTINCT
            `STNTOUTCMS`.`Idx` AS SOIdx,
            `STNTOUTCMS`.`SO`,
            `STNTOUTCMS`.`Description`
        FROM `StudentOutcomes` AS `STNTOUTCMS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
        WHERE FIND_IN_SET(`GPIS`.`AcademicYear`, IN_AcademicYears) > 0
          AND `GPIS`.`AcademicProgram` = IN_AcademicProgram 
          AND `STNTOUTCMS`.`TobeRemoved` = 0
    ),
    -- Calculate student averages per SO from all their assessment scores
    StudentSOScores AS (
        SELECT
            `GPIS`.`AcademicYear` AS AcademicYearIdx,
            `STNTOUTCMS`.`Idx` AS SOIdx,
            `STNTOUTCMS`.`SO`,
            `STNTOUTCMS`.`Description`,
            `SCSHEET`.`StudentNo`,
            `SCSHEET`.`LevelOfAttainment` AS Score
        FROM `StudentOutcomes` AS `STNTOUTCMS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
        INNER JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` 
            ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
        INNER JOIN `Scoresheet` AS `SCSHEET` 
            ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
        WHERE FIND_IN_SET(`GPIS`.`AcademicYear`, IN_AcademicYears) > 0
          AND `GPIS`.`AcademicProgram` = IN_AcademicProgram 
          AND `STNTOUTCMS`.`TobeRemoved` = 0
          AND `SCSHEET`.`LevelOfAttainment` IS NOT NULL
    ),
    -- Calculate average score per student per SO per year
    StudentSOAverages AS (
        SELECT
            `AcademicYearIdx`,
            `SOIdx`,
            `SO`,
            `Description`,
            `StudentNo`,
            AVG(`Score`) AS StudentAverage
        FROM StudentSOScores
        GROUP BY `AcademicYearIdx`, `SOIdx`, `SO`, `Description`, `StudentNo`
    ),
    -- Calculate SO statistics across all students (only for SOs with data)
    SOStatistics AS (
        SELECT
            AVG(`StudentAverage`) AS `AVG`,
            COUNT(DISTINCT `StudentNo`) AS `TOTAL`,
            SUM(CASE WHEN `StudentAverage` >= 2 THEN 1 ELSE 0 END) AS `TOPFIFTY`,
            SUM(CASE WHEN `StudentAverage` >= 3 THEN 1 ELSE 0 END) AS `TOPTWENTYFIVE`,
            `SO`,
            `SOIdx`,
            `Description` AS `SODescription`
        FROM StudentSOAverages
        GROUP BY `SO`, `SOIdx`, `Description`
    )
    -- Left join to include all SOs, even those without student data
    SELECT
        COALESCE(`SOStats`.`AVG`, 0.0) AS `AVG`,
        COALESCE(`SOStats`.`TOTAL`, 0) AS `TOTAL`,
        COALESCE(`SOStats`.`TOPFIFTY`, 0) AS `TOPFIFTY`,
        COALESCE(`SOStats`.`TOPTWENTYFIVE`, 0) AS `TOPTWENTYFIVE`,
        `AllSOs`.`SO`,
        `AllSOs`.`SOIdx`,
        `AllSOs`.`Description` AS `SODescription`
    FROM AllStudentOutcomes AS `AllSOs`
    LEFT JOIN SOStatistics AS `SOStats`
        ON `AllSOs`.`SOIdx` = `SOStats`.`SOIdx`
    ORDER BY `AllSOs`.`SO`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchOverallAbetCourseAssessmentsSODetail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchOverallAbetCourseAssessmentsSODetail`(
    IN IN_AcademicYears TEXT,
    IN IN_AcademicProgram INT
)
BEGIN
    SET @sql = CONCAT(
        '-- Result Set 1: Overall SO Summary
        SELECT
            "SO_SUMMARY" AS ResultType,
            `STNTOUTCMS`.`SO` AS SO,
            MIN(`STNTOUTCMS`.`Idx`) AS SOIdx,
            MIN(`STNTOUTCMS`.`Description`) AS SODescription,
            NULL AS GPIIdx,
            NULL AS GPICode,
            NULL AS GPIDescription,
            NULL AS CourseCode,
            NULL AS CoursePrefix,
            NULL AS CourseNumber,
            NULL AS CourseTitle,
            NULL AS CourseType,
            ROUND(AVG(`SS`.`LevelOfAttainment`), 2) AS AVG,
            COUNT(`SS`.`LevelOfAttainment`) AS TOTAL,
            SUM(CASE WHEN `SS`.`LevelOfAttainment` >= 3.5 THEN 1 ELSE 0 END) AS TOPFIFTY,
            SUM(CASE WHEN `SS`.`LevelOfAttainment` >= 3.75 THEN 1 ELSE 0 END) AS TOPTWENTYFIVE,
            SUM(CASE WHEN `SS`.`LevelOfAttainment` >= 3.0 THEN 1 ELSE 0 END) AS COUNT_3_OR_MORE
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
            INNER JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
            INNER JOIN `Scoresheet` AS `SS` ON (`ASSMNTMEASURES`.`Idx` = `SS`.`AssessmentMeasureIdx`)
        WHERE `GPIS`.`AcademicProgram` = ', IN_AcademicProgram, '
        AND `GPIS`.`AcademicYear` IN (', IN_AcademicYears, ')
        AND `STNTOUTCMS`.`TobeRemoved` = 0
        AND `GPIS`.`TobeRemoved` = 0
        AND `SS`.`LevelOfAttainment` IS NOT NULL
        GROUP BY `STNTOUTCMS`.`SO`

        UNION ALL

        -- Result Set 2: Performance Indicators per SO (deduplicated across years)
        SELECT
            "PERFORMANCE_INDICATORS" AS ResultType,
            `STNTOUTCMS`.`SO` AS SO,
            MIN(`STNTOUTCMS`.`Idx`) AS SOIdx,
            NULL AS SODescription,
            MIN(`GPIS`.`Idx`) AS GPIIdx,
            `GPIS`.`GPI` AS GPICode,
            MIN(`GPIS`.`Description`) AS GPIDescription,
            NULL AS CourseCode,
            NULL AS CoursePrefix,
            NULL AS CourseNumber,
            NULL AS CourseTitle,
            NULL AS CourseType,
            NULL AS AVG,
            NULL AS TOTAL,
            NULL AS TOPFIFTY,
            NULL AS TOPTWENTYFIVE,
            NULL AS COUNT_3_OR_MORE
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
        WHERE `GPIS`.`AcademicYear` IN (', IN_AcademicYears, ')
            AND `GPIS`.`AcademicProgram` = ', IN_AcademicProgram, '
            AND `STNTOUTCMS`.`TobeRemoved` = 0
            AND `GPIS`.`TobeRemoved` = 0
        GROUP BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI`

        UNION ALL

        -- Result Set 3: Courses per SO - Aggregated across all GPIs
        SELECT
            "COURSES_PER_GPI" AS ResultType,
            `STNTOUTCMS`.`SO` AS SO,
            NULL AS SOIdx,
            NULL AS SODescription,
            NULL AS GPIIdx,
            NULL AS GPICode,
            NULL AS GPIDescription,
            CONCAT(TRIM(`AVCOURSES`.`Subject`), " ", TRIM(`AVCOURSES`.`Num`)) AS CourseCode,
            TRIM(`AVCOURSES`.`Subject`) AS CoursePrefix,
            CAST(TRIM(`AVCOURSES`.`Num`) AS UNSIGNED) AS CourseNumber,
            MIN(`AVCOURSES`.`Title`) AS CourseTitle,
            MIN(`ABETCOURSES`.`Requirement`) AS CourseType,
            ROUND(AVG(`SS`.`LevelOfAttainment`), 2) AS AVG,
            COUNT(`SS`.`LevelOfAttainment`) AS TOTAL,
            SUM(CASE WHEN `SS`.`LevelOfAttainment` >= 3.5 THEN 1 ELSE 0 END) AS TOPFIFTY,
            SUM(CASE WHEN `SS`.`LevelOfAttainment` >= 3.75 THEN 1 ELSE 0 END) AS TOPTWENTYFIVE,
            SUM(CASE WHEN `SS`.`LevelOfAttainment` >= 3.0 THEN 1 ELSE 0 END) AS COUNT_3_OR_MORE
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
            INNER JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
            INNER JOIN `Scoresheet` AS `SS` ON (`ASSMNTMEASURES`.`Idx` = `SS`.`AssessmentMeasureIdx`)
            LEFT JOIN `AVCourses` AS `AVCOURSES` ON (`SS`.`AvailableCourseIdx` = `AVCOURSES`.`Idx`)
            LEFT JOIN `AbetCourses` AS `ABETCOURSES` ON (`SS`.`AbetCourseIdx` = `ABETCOURSES`.`Idx`)
        WHERE `GPIS`.`AcademicYear` IN (', IN_AcademicYears, ')
            AND `GPIS`.`AcademicProgram` = ', IN_AcademicProgram, '
            AND `STNTOUTCMS`.`TobeRemoved` = 0
            AND `GPIS`.`TobeRemoved` = 0
            AND `SS`.`LevelOfAttainment` IS NOT NULL
            AND `AVCOURSES`.`Subject` IS NOT NULL
        GROUP BY `STNTOUTCMS`.`SO`, TRIM(`AVCOURSES`.`Subject`), TRIM(`AVCOURSES`.`Num`)

        UNION ALL

        -- Result Set 4: GPI scores with Core/Elective breakdown (CONSOLIDATED BY GPI CODE)
        SELECT
            "GPI_SCORES" AS ResultType,
            `STNTOUTCMS`.`SO` AS SO,
            NULL AS SOIdx,
            NULL AS SODescription,
            MIN(`GPIS`.`Idx`) AS GPIIdx,
            `GPIS`.`GPI` AS GPICode,
            NULL AS GPIDescription,
            NULL AS CourseCode,
            NULL AS CoursePrefix,
            NULL AS CourseNumber,
            NULL AS CourseTitle,
            `ABETCOURSES`.`Requirement` AS CourseType,
            ROUND(AVG(`SS`.`LevelOfAttainment`), 2) AS AVG,
            COUNT(`SS`.`LevelOfAttainment`) AS TOTAL,
            NULL AS TOPFIFTY,
            NULL AS TOPTWENTYFIVE,
            SUM(CASE WHEN `SS`.`LevelOfAttainment` >= 3.0 THEN 1 ELSE 0 END) AS COUNT_3_OR_MORE
        FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx`=`GPIS`.`SOIdx`)
            INNER JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
            INNER JOIN `Scoresheet` AS `SS` ON (`ASSMNTMEASURES`.`Idx` = `SS`.`AssessmentMeasureIdx`)
            LEFT JOIN `AbetCourses` AS `ABETCOURSES` ON (`SS`.`AbetCourseIdx` = `ABETCOURSES`.`Idx`)
        WHERE `GPIS`.`AcademicYear` IN (', IN_AcademicYears, ')
            AND `GPIS`.`AcademicProgram` = ', IN_AcademicProgram, '
            AND `STNTOUTCMS`.`TobeRemoved` = 0
            AND `GPIS`.`TobeRemoved` = 0
            AND `SS`.`LevelOfAttainment` IS NOT NULL
        GROUP BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI`, `ABETCOURSES`.`Requirement`

        ORDER BY
            SO,
            ResultType,
            GPICode,
            CourseType,
            CoursePrefix,
            CourseNumber,
            CourseCode'
    );

    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchPI_DiffInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchPI_DiffInfo`(
    IN p_AcademicYear1 INT,
    IN p_AcademicYear2 INT,
    IN p_AcademicProgram INT
)
BEGIN
    
    SELECT
        t1.SO,
        t1.GPI,
        t1.AcademicProgram,
        ap.Name,
        ap.Degree,
        t1.Description AS Description_1,
        t2.Description AS Description_2,
        t1.Comments AS Comments_1,
        t2.Comments AS Comments_2,
        t1.TobeRemoved AS TobeRemoved_1,
        t2.TobeRemoved AS TobeRemoved_2,
        t1.Approval AS Approval_1,
        t2.Approval AS Approval_2,
        t1.AcademicYear AS AcademicYear_1,
        t2.AcademicYear AS AcademicYear_2
    
    FROM
        (SELECT
             so1.`SO`, pi1.GPI, ay1.AcademicYear, pi1.Description, pi1.Comments, pi1.Approval, pi1.TobeRemoved,
             pi1.AcademicProgram
         FROM `GeneralPerformanceIndicators` pi1
                  INNER JOIN `StudentOutcomes` so1
                             ON pi1.SOIdx = so1.Idx
                  LEFT JOIN `AcademicYears` ay1
                            ON ay1.Idx = pi1.AcademicYear
         WHERE pi1.AcademicYear = p_AcademicYear1 AND pi1.AcademicProgram = p_AcademicProgram
        ) t1
            JOIN
        (SELECT
             so2.`SO`, pi2.GPI, ay2.AcademicYear, pi2.Description, pi2.Comments, pi2.Approval, pi2.TobeRemoved
         FROM `GeneralPerformanceIndicators` pi2
                  INNER JOIN `StudentOutcomes` so2
                             ON pi2.SOIdx = so2.Idx
                  LEFT JOIN `AcademicYears` ay2
                            ON ay2.Idx = pi2.AcademicYear
         WHERE pi2.AcademicYear = p_AcademicYear2 AND pi2.AcademicProgram = p_AcademicProgram
        ) t2
        ON t1.GPI = t2.GPI AND t1.SO = t2.SO
            LEFT JOIN `AcademicPrograms` ap
                      ON ap.Idx = t1.AcademicProgram
    ORDER BY t1.SO, t1.GPI;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchScoreSheetAssessmentMeasures` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchScoreSheetAssessmentMeasures`( IN IN_AbetCourseIdx INT, IN IN_AvailableCourseIdx INT )
BEGIN
        SELECT
            `ASSMNTMEASURES`.`Idx`,
            `ASSMNTMEASURES`.`Measure`,
            `ASSMNTMEASURES`.`AssignmentType`,
            `ASSMNTMEASURES`.`AssignmentNum`,
            `ASSMNTMEASURES`.`AssignmentProblem`,
            `ASSMNTMEASURES`.`AssignmentDescription`,
            CONCAT_WS('-',`STNTOUTCMS`.`SO`, `GPIS`.`GPI`) AS GPI,
            `GPIS`.`Idx` AS `GPIIdx`
        FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI`)
            INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx`)
        WHERE `ASSMNTMEASURES`.`AbetCourseIdx` = IN_AbetCourseIdx AND `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx
        ORDER BY `ASSMNTMEASURES`.`Measure`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchScoreSheetAssessmentMeasuresGPI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchScoreSheetAssessmentMeasuresGPI`( IN IN_AbetCourseIdx INT, IN IN_AvailableCourseIdx INT )
BEGIN

    SELECT DISTINCT
        `GPIS`.`Idx` AS `GPIIdx`,
        `ASSMNTMASTRRBRICS`.`LevelofAttainment`,
        `ASSMNTMASTRRBRICS`.`Description`
    FROM `AssessmentMeasures` AS `ASSMNTMEASURES`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI`)
        INNER JOIN `AssessmentMasterRubrics` AS `ASSMNTMASTRRBRICS` ON (`GPIS`.`Idx`=`ASSMNTMASTRRBRICS`.`GPIIdx`)
    WHERE `ASSMNTMEASURES`.`AbetCourseIdx` = IN_AbetCourseIdx AND `ASSMNTMEASURES`.`AvailableCourseIdx` = IN_AvailableCourseIdx
    ORDER BY `AssignmentType`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchScoreSheetAssessmentMeasurestInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchScoreSheetAssessmentMeasurestInfo`(IN IN_AssessmentMeasureIdx INT)
BEGIN

    SELECT
        `SCRSHEET`.`StudentNo`,
        AES_DECRYPT(`SCRSHEET_CLM`.`CustomColumnInfo`, 'ABET Course Assessment System') AS `ColumnInfo`,
        `SCRSHEET`.`LevelOfAttainment`,
        `SCRSHEET`.`AcademicProgramIdx`
    FROM `Scoresheet` AS `SCRSHEET`
        INNER JOIN `AcademicPrograms` AS `ACADMICPRGMS` ON (`SCRSHEET`.`AcademicProgramIdx` = `ACADMICPRGMS`.`Idx`)
        LEFT JOIN `Scoresheet_Columns` AS `SCRSHEET_CLM` ON (`SCRSHEET`.`StudentNo` = `SCRSHEET_CLM`.`StudentNo`
            AND `SCRSHEET`.`AvailableCourseIdx` = `SCRSHEET_CLM`.`AvailableCourseIdx`
            AND `SCRSHEET`.`AbetCourseIdx` = `SCRSHEET_CLM`.`AbetCourseIdx`
            AND `SCRSHEET`.`AcademicProgramIdx` = `SCRSHEET_CLM`.`AcademicProgramIdx`)
    WHERE `SCRSHEET`.`AssessmentMeasureIdx` = IN_AssessmentMeasureIdx
    ORDER BY `SCRSHEET`.`StudentNo`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchScoreSheetAssessmentMeasurestInfoDisplay` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchScoreSheetAssessmentMeasurestInfoDisplay`(IN IN_AssessmentMeasureIdx INT)
BEGIN

    SELECT
        `SCRSHEET`.`StudentNo`,
        AES_DECRYPT(`SCRSHEET_CLM`.`CustomColumnInfo`, 'ABET Course Assessment System') AS `CustomColumnInfo`,
        `SCRSHEET`.`LevelOfAttainment`,
        `SCRSHEET`.`AcademicProgramIdx`
    FROM `Scoresheet` AS `SCRSHEET`
        INNER JOIN `AcademicPrograms` AS `ACADMICPRGMS` ON (`SCRSHEET`.`AcademicProgramIdx` = `ACADMICPRGMS`.`Idx`)
        LEFT JOIN `Scoresheet_Columns` AS `SCRSHEET_CLM` ON (`SCRSHEET`.`StudentNo` = `SCRSHEET_CLM`.`StudentNo`
            AND `SCRSHEET`.`AvailableCourseIdx` = `SCRSHEET_CLM`.`AvailableCourseIdx`
            AND `SCRSHEET`.`AbetCourseIdx` = `SCRSHEET_CLM`.`AbetCourseIdx`
            AND `SCRSHEET`.`AcademicProgramIdx` = `SCRSHEET_CLM`.`AcademicProgramIdx`)
    WHERE `SCRSHEET`.`AssessmentMeasureIdx` = IN_AssessmentMeasureIdx
    ORDER BY `SCRSHEET`.`StudentNo`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchScoreSheetAssessmentMeasurestInfoPrint` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchScoreSheetAssessmentMeasurestInfoPrint`(IN IN_AssessmentMeasureIdx INT)
BEGIN
    -- Retrieve the AvailableCourseIdx for this AssessmentMeasure
    DECLARE v_AvailableCourseIdx INT;

    SELECT `AvailableCourseIdx`
    INTO v_AvailableCourseIdx
    FROM `Scoresheet`
    WHERE `AssessmentMeasureIdx` = IN_AssessmentMeasureIdx
    LIMIT 1;

    -- Determine if ClassRoster exists for this course and apply appropriate filtering
    IF EXISTS (SELECT 1 FROM `ClassRoster` WHERE `AvailableCourseIdx` = v_AvailableCourseIdx) THEN
        -- ClassRoster exists: Filter by matching AcademicProgramIdx to prevent cross-program data access
        SELECT
            `SCRSHEET`.`StudentNo`,
            AES_DECRYPT(`SCRSHEET_CLM`.`CustomColumnInfo`, 'ABET Course Assessment System') AS `CustomColumnInfo`,
            `SCRSHEET`.`LevelOfAttainment`,
            `SCRSHEET`.`AcademicProgramIdx`
        FROM `Scoresheet` AS `SCRSHEET`
            INNER JOIN `AcademicPrograms` AS `ACADMICPRGMS`
                ON `SCRSHEET`.`AcademicProgramIdx` = `ACADMICPRGMS`.`Idx`
            INNER JOIN `ClassRoster` AS `CLSRSTR` ON (
                `SCRSHEET`.`AvailableCourseIdx` = `CLSRSTR`.`AvailableCourseIdx`
                AND `SCRSHEET`.`StudentNo` = `CLSRSTR`.`StudentNo`
                AND `SCRSHEET`.`AcademicProgramIdx` = `CLSRSTR`.`AcademicProgramIdx`
            )
            LEFT JOIN `Scoresheet_Columns` AS `SCRSHEET_CLM` ON (
                `SCRSHEET`.`StudentNo` = `SCRSHEET_CLM`.`StudentNo`
                AND `SCRSHEET`.`AvailableCourseIdx` = `SCRSHEET_CLM`.`AvailableCourseIdx`
                AND `SCRSHEET`.`AbetCourseIdx` = `SCRSHEET_CLM`.`AbetCourseIdx`
                AND `SCRSHEET`.`AcademicProgramIdx` = `SCRSHEET_CLM`.`AcademicProgramIdx`
            )
        WHERE `SCRSHEET`.`AssessmentMeasureIdx` = IN_AssessmentMeasureIdx
        ORDER BY `SCRSHEET`.`StudentNo`;
    ELSE
        -- ClassRoster doesn't exist: Return all scoresheet records without program filtering
        SELECT
            `SCRSHEET`.`StudentNo`,
            AES_DECRYPT(`SCRSHEET_CLM`.`CustomColumnInfo`, 'ABET Course Assessment System') AS `CustomColumnInfo`,
            `SCRSHEET`.`LevelOfAttainment`,
            `SCRSHEET`.`AcademicProgramIdx`
        FROM `Scoresheet` AS `SCRSHEET`
            INNER JOIN `AcademicPrograms` AS `ACADMICPRGMS`
                ON `SCRSHEET`.`AcademicProgramIdx` = `ACADMICPRGMS`.`Idx`
            LEFT JOIN `Scoresheet_Columns` AS `SCRSHEET_CLM` ON (
                `SCRSHEET`.`StudentNo` = `SCRSHEET_CLM`.`StudentNo`
                AND `SCRSHEET`.`AvailableCourseIdx` = `SCRSHEET_CLM`.`AvailableCourseIdx`
                AND `SCRSHEET`.`AbetCourseIdx` = `SCRSHEET_CLM`.`AbetCourseIdx`
                AND `SCRSHEET`.`AcademicProgramIdx` = `SCRSHEET_CLM`.`AcademicProgramIdx`
            )
        WHERE `SCRSHEET`.`AssessmentMeasureIdx` = IN_AssessmentMeasureIdx
        ORDER BY `SCRSHEET`.`StudentNo`;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchScoreSheetMasterRubrics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchScoreSheetMasterRubrics`( IN IN_GPIIdexes TEXT)
BEGIN

	#-------------------------------------------------------------------------------------------------------
	SET @sql_text = CONCAT("SELECT CONCAT_WS('-', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`) AS `GPI`,
        `ASSMNTMSTRRBRICS`.`LevelOfAttainment` AS `LOA`,
        `ASSMNTMSTRRBRICS`.`Description` AS `DESC`
    FROM `AssessmentMasterRubrics` AS `ASSMNTMSTRRBRICS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ASSMNTMSTRRBRICS`.`GPIIdx`)
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx`)
    WHERE ", IN_GPIIdexes ," ORDER BY `GPIIdx`, `LevelofAttainment`;");
	PREPARE stmt FROM @sql_text;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchSelectedAbetCourseCntinusImprvmnts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchSelectedAbetCourseCntinusImprvmnts`(
    IN IN_AbetCourseSubject VARCHAR(5),
    IN IN_AbetCourseNum VARCHAR(5),
    IN IN_AcademicProgram INT
)
BEGIN

    SELECT
        `ABETCRSES`.`Idx` AS `ABCIdx`,
        `AVCRSES`.`Idx` AS `AVCIdx`,
        `AVCRSES`.`CourseNo`,
        GROUP_CONCAT(DISTINCT `UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR ',') AS `Instructor`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,
        `SMSTRS`.`Explanation` AS `Semester`,
        `CNTNUSIMPRVMNT`.`FacultyReflection`

    FROM `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AcademicYears` AS `AYS`
            ON (`ABETCRSES`.`AcademicYear` = `AYS`.`Idx`)
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS`
            ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        INNER JOIN `AVCourses` AS `AVCRSES`
            ON (`AYS`.`From` <= `AVCRSES`.`Semester` AND `AYS`.`To` >= `AVCRSES`.`Semester` AND `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`)
        LEFT JOIN `Semesters` AS `SMSTRS`
            ON (`AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`)
        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS`
            ON (`AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`)
        INNER JOIN `UserAccounts` AS `UA`
            ON (`AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`)
        LEFT JOIN `ContinuousImprovement` AS `CNTNUSIMPRVMNT`
            ON (`CNTNUSIMPRVMNT`.`AvailableCourseIdx` = `AVCRSES`.`Idx` AND `CNTNUSIMPRVMNT`.`AbetCourseIdx` = `ABETCRSES`.`Idx`)

    WHERE `AVCRSES`.`Subject` = IN_AbetCourseSubject
        AND `AVCRSES`.`Num` = IN_AbetCourseNum
        AND `ABETCRSES`.`AcademicProgram` = IN_AcademicProgram

    GROUP BY
        `ABETCRSES`.`Idx`,
        `AVCRSES`.`Idx`,
        `AVCRSES`.`CourseNo`,
        `AVCRSES`.`Title`,
        `AVCRSES`.`Credits`,
        `SMSTRS`.`Explanation`,
        `CNTNUSIMPRVMNT`.`FacultyReflection`
    ORDER BY `AVCRSES`.`CourseNo`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchSOs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchSOs`(
    IN p_AcademicYear INT,
    IN p_AcademicProgram INT
)
BEGIN

    SELECT `Idx`, `SO`
    FROM `StudentOutcomes`
    WHERE `AcademicYear`=p_AcademicYear AND `AcademicProgram`=p_AcademicProgram
    ORDER BY `SO`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchSO_DiffInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchSO_DiffInfo`(
    IN p_AcademicYear1 INT,
    IN p_AcademicYear2 INT,
    IN p_AcademicProgram INT
)
BEGIN

    SELECT
        t1.SO,
        t1.AcademicProgram,
        ap.Name, ap.Degree,
        t1.Description AS Description_1,
        t2.Description AS Description_2,
        t1.Comments AS Comments_1,
        t2.Comments AS Comments_2,
        t1.Approval AS Approval_1,
        t2.Approval AS Approval_2,
        t1.TobeRemoved AS TobeRemoved_1,
        t2.TobeRemoved AS TobeRemoved_2,
        ay1.AcademicYear AS AcademicYear_1,
        ay2.AcademicYear AS AcademicYear_2

    FROM
        StudentOutcomes t1
            JOIN
        StudentOutcomes t2
        ON
            t1.SO = t2.SO
                AND t1.AcademicProgram = t2.AcademicProgram
                AND t1.AcademicYear = p_AcademicYear1
                AND t2.AcademicYear = p_AcademicYear2
            LEFT JOIN `AcademicYears` ay1 ON ay1.Idx = p_AcademicYear1
            LEFT JOIN `AcademicYears` ay2 ON ay2.Idx = p_AcademicYear2
            LEFT JOIN `AcademicPrograms` ap ON ap.Idx = t1.AcademicProgram

    WHERE
        t1.AcademicProgram = p_AcademicProgram
      AND t2.AcademicProgram = p_AcademicProgram
    ORDER BY t1.SO;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_FetchSyllabusDuplicateInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_FetchSyllabusDuplicateInfo`(IN IN_AcademicYearSource INT, IN IN_AcademicYearDest INT, IN IN_AcademicProgram INT)
BEGIN

    SELECT DISTINCT `T_SRC`.`Syllabus` AS `Src_Syllabus`, `T_DEST`.`Syllabus` AS `Dest_Syllabus`,
                    `T_SRC`.`AcademicYear` AS `Src_AcademicYear`, `T_DEST`.`AcademicYear` AS `Dest_AcademicYear` FROM
        ( SELECT `ABETCRSES`.`Idx`, `ABETCRSES`.`AVCourseIdx`, `ABETCRSES`.`Syllabus`,
                 `AVCRSES`.`CourseNo`,  `ACYRS`.`AcademicYear`
          FROM `AbetCourses` AS `ABETCRSES`
                   LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABETCRSES`.`Idx`=`ABETCRSES_SOS`.`AbetCourseIdx`)
                   LEFT JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`STNTOUTCMS`.`Idx`=`ABETCRSES_SOS`.`SOIdx`)
                   LEFT JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx`=`AVCRSES`.`Idx`)
                   LEFT JOIN `AcademicYears` AS `ACYRS` ON (`ACYRS`.`Idx`=`ABETCRSES`.`AcademicYear`)
          WHERE `ABETCRSES`.`AcademicYear`=IN_AcademicYearDest AND `ABETCRSES`.`AcademicProgram`=IN_AcademicProgram
        ) AS `T_DEST`
            INNER JOIN
        ( SELECT `ABETCRSES`.`Idx`, `ABETCRSES`.`AVCourseIdx`,
                 `STNTOUTCMS`.`SO`, `GPIS`.`GPI`, `ABETCRSES`.`Syllabus`,
                 `ABETCRSES_SOS`.`SOIdx`, `ABETCRSES_GPIS`.`GPIIdx`,
                 `AVCRSES`.`CourseNo`,  `ACYRS`.`AcademicYear`
          FROM `AbetCourses` AS `ABETCRSES`
                   LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABETCRSES`.`Idx`=`ABETCRSES_SOS`.`AbetCourseIdx`)
                   LEFT JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`STNTOUTCMS`.`Idx`=`ABETCRSES_SOS`.`SOIdx`)
                   LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` ON (`ABETCRSES_GPIS`.`SOIdx`=`ABETCRSES_SOS`.`SOIdx` AND `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES_SOS`.`AbetCourseIdx`)
                   LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ABETCRSES_GPIS`.`GPIIdx`)
                   LEFT JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx`=`AVCRSES`.`Idx`)
                   LEFT JOIN `AcademicYears` AS `ACYRS` ON (`ACYRS`.`Idx`=`ABETCRSES`.`AcademicYear`)
          WHERE `ABETCRSES`.`AcademicYear`=IN_AcademicYearSource AND `ABETCRSES`.`AcademicProgram`=IN_AcademicProgram
        ) AS `T_SRC`
        ON (`T_DEST`.`CourseNo` = `T_SRC`.`CourseNo`)
    ORDER BY `T_DEST`.`AVCourseIdx`;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_GetSampleFilesToDelete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_GetSampleFilesToDelete`(
    IN IN_Idx INT
)
BEGIN
    -- Declare variables
    DECLARE v_AvailableCourseIdx INT;
    DECLARE v_AbetCourseIdx INT;
    DECLARE v_AssignmentType VARCHAR(256);
    DECLARE v_AssignmentNum INT;
    DECLARE v_AssignmentProblem VARCHAR(1024);
    DECLARE v_Measure INT;
    DECLARE v_IsLinked INT DEFAULT 0;

    -- Find details of the assessment measure being removed
    SELECT
        `AvailableCourseIdx`,
        `AbetCourseIdx`,
        `AssignmentType`,
        `AssignmentNum`,
        `AssignmentProblem`,
        `Measure`
    INTO
        v_AvailableCourseIdx,
        v_AbetCourseIdx,
        v_AssignmentType,
        v_AssignmentNum,
        v_AssignmentProblem,
        v_Measure
    FROM `AssessmentMeasures`
    WHERE `Idx` = IN_Idx;

    -- Check if this course is part of a linked group
    SELECT IFNULL(`Linked`, 0) INTO v_IsLinked
    FROM `AbetCourses`
    WHERE `Idx` = v_AbetCourseIdx;

    -- Create temporary table to store measures that will be deleted
    DROP TEMPORARY TABLE IF EXISTS temp_measures_to_delete;
    CREATE TEMPORARY TABLE temp_measures_to_delete (
        MeasureIdx INT PRIMARY KEY
    );

    -- Add the primary measure
    INSERT INTO temp_measures_to_delete (MeasureIdx)
    VALUES (IN_Idx);

    -- Add measures from related courses based on course type
    IF v_IsLinked = 1 THEN
        -- Linked courses: Match by measure number, assignment type and num
        INSERT INTO temp_measures_to_delete (MeasureIdx)
        SELECT am.`Idx`
        FROM `AssessmentMeasures` am
        INNER JOIN `AbetCourses` ac ON am.`AbetCourseIdx` = ac.`Idx`
        WHERE ac.`Linked` = 1
        AND am.`AvailableCourseIdx` != v_AvailableCourseIdx
        AND am.`AssignmentType` = v_AssignmentType
        AND am.`AssignmentNum` = v_AssignmentNum
        AND am.`Measure` = v_Measure
        AND EXISTS (
            SELECT 1 FROM `AbetCourses` ac_target
            WHERE ac_target.`Idx` = v_AbetCourseIdx
            AND ac.`LinkNumber` = ac_target.`LinkNumber`
        );
    ELSE
        -- Reference courses: Match by assignment type, num and problem
        INSERT INTO temp_measures_to_delete (MeasureIdx)
        SELECT `Idx`
        FROM `AssessmentMeasures`
        WHERE `AvailableCourseIdx` = v_AvailableCourseIdx
        AND `AbetCourseIdx` != v_AbetCourseIdx
        AND `AssignmentType` = v_AssignmentType
        AND `AssignmentNum` = v_AssignmentNum
        AND `AssignmentProblem` = v_AssignmentProblem;
    END IF;

    -- Create a second temporary table to avoid reopen error
    DROP TEMPORARY TABLE IF EXISTS temp_measures_to_delete_copy;
    CREATE TEMPORARY TABLE temp_measures_to_delete_copy AS
    SELECT MeasureIdx FROM temp_measures_to_delete;

    -- Get sample files that will be orphaned (not used by any other measures)
    SELECT DISTINCT
        ams.`SampleFile`
    FROM `AssessmentMeasureSamples` ams
    INNER JOIN temp_measures_to_delete tmd ON ams.`AssessmentMeasureIdx` = tmd.MeasureIdx
    WHERE NOT EXISTS (
        SELECT 1
        FROM `AssessmentMeasureSamples` ams2
        WHERE ams2.`SampleFile` = ams.`SampleFile`
        AND ams2.`AssessmentMeasureIdx` NOT IN (
            SELECT MeasureIdx FROM temp_measures_to_delete_copy
        )
    )
    ORDER BY ams.`SampleFile`;

    -- Clean up temporary tables
    DROP TEMPORARY TABLE IF EXISTS temp_measures_to_delete;
    DROP TEMPORARY TABLE IF EXISTS temp_measures_to_delete_copy;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_GetUserSessionData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_GetUserSessionData`(
    IN p_UserIdx INT
)
BEGIN
    SELECT
        `UA`.Idx,
        `UA`.Name,
        `UA`.Affiliation,
        `UA`.Email,
        `UA`.Observer,
        GROUP_CONCAT(DISTINCT CASE
                WHEN `ACS`.`Idx` IS NOT NULL THEN `APS`.`Idx`
            END) AS `AccessGranted`,
        GROUP_CONCAT(DISTINCT CASE
                WHEN `ACS`.`Idx` IS NULL THEN `APS`.`Idx`
            END) AS `AccessNotGranted`
    FROM `UserAccounts` AS `UA`
             CROSS JOIN `AcademicPrograms` AS `APS`
             LEFT JOIN `AccessControls` AS `ACS`
                   ON (`UA`.`Idx` = `ACS`.`UserAccount`
                       AND `ACS`.`AcademicProgram` = `APS`.`Idx`)
    WHERE `UA`.Idx = p_UserIdx
    AND `UA`.Disabled = 0
    GROUP BY `UA`.Idx;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_GetYearSem` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_GetYearSem`(
    IN IN_SemesterCode INT,
    OUT OUT_YearSem VARCHAR(50),
    OUT OUT_ErrorCode VARCHAR(10)
)
BEGIN
    DECLARE v_Count INT;

    -- Initialize output
    SET OUT_YearSem = '';
    SET OUT_ErrorCode = '0x11111111';

    -- Check if semester exists and get explanation
    SELECT COUNT(*), MAX(Explanation)
    INTO v_Count, OUT_YearSem
    FROM Semesters
    WHERE SemesterCode = IN_SemesterCode;

    IF v_Count = 0 THEN
        SET OUT_ErrorCode = '0x00200012'; -- Item not exist
        SET OUT_YearSem = '';
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_IsAddCMPossible` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_IsAddCMPossible`(
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
    ROLLBACK;
    RESIGNAL;
    END;

    IF NOT EXISTS (SELECT 1 FROM `StudentOutcomes`
       WHERE AcademicYear = IN_AcademicYear
            AND AcademicProgram = IN_AcademicProgram) THEN
        SELECT '0x00000100' AS `Possibility`;
    ELSEIF NOT EXISTS (SELECT 1 FROM `GeneralPerformanceIndicators`
       WHERE AcademicYear = IN_AcademicYear
            AND AcademicProgram = IN_AcademicProgram) THEN
        SELECT '0x00000200' AS `Possibility`;
    ELSE
        SELECT '0x11111111' AS `Possibility`;
    END IF;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_LoginAuthorization` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_LoginAuthorization`(IN IN_EmailAddress VARCHAR(50), IN IN_Password VARCHAR(256))
BEGIN
    DECLARE v_UserIdx INT DEFAULT 0;
    DECLARE v_StoredPWD VARCHAR(256);
    DECLARE v_Disabled TINYINT DEFAULT 0;
    DECLARE v_LoginFails INT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SELECT `Idx`, `PWD`, `Disabled`, `LoginFails`
    INTO v_UserIdx, v_StoredPWD, v_Disabled, v_LoginFails
    FROM `UserAccounts`
    WHERE `Email` = IN_EmailAddress
    LIMIT 1;

    IF v_UserIdx = 0 THEN
        COMMIT;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001010|0';
    END IF;

    IF v_Disabled = 1 THEN
        COMMIT;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x60001010';
    END IF;

    IF v_StoredPWD = IN_Password THEN
        UPDATE `UserAccounts`
        SET `LastLogIn` = NOW(),
            `LoginFails` = 0
        WHERE `Idx` = v_UserIdx;

        SELECT
            `UA`.`Idx`,
            `UA`.`Name`,
            `UA`.`Observer`,
            `UA`.`SystemAdmin`,
            `UA`.`ResetPWD`,
            GROUP_CONCAT(DISTINCT CASE
                WHEN `ACS`.`Idx` IS NOT NULL THEN `APS`.`Idx`
            END) AS `AccessGranted`,
            GROUP_CONCAT(DISTINCT CASE
                WHEN `ACS`.`Idx` IS NULL THEN `APS`.`Idx`
            END) AS `AccessNotGranted`,
            `UA`.`Affiliation`
        FROM `UserAccounts` AS `UA`
            CROSS JOIN `AcademicPrograms` AS `APS`
            LEFT JOIN `AccessControls` AS `ACS`
                ON (`UA`.`Idx` = `ACS`.`UserAccount`
                    AND `ACS`.`AcademicProgram` = `APS`.`Idx`)
            LEFT JOIN `Positions` AS `POSTNS`
                ON (`POSTNS`.`Idx` = `UA`.`Position`)
        WHERE `UA`.`Idx` = v_UserIdx
        GROUP BY `UA`.`Idx`;

        COMMIT;

    ELSE
        SET v_LoginFails = v_LoginFails + 1;

        UPDATE `UserAccounts`
        SET `LoginFails` = v_LoginFails
        WHERE `Idx` = v_UserIdx;

        IF v_LoginFails >= 5 THEN
            UPDATE `UserAccounts`
            SET `Disabled` = 1
            WHERE `Idx` = v_UserIdx;

            COMMIT;

            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x60001010';

        ELSE
            COMMIT;

            IF v_LoginFails = 1 THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x80001010|1';
            ELSEIF v_LoginFails = 2 THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x80001010|2';
            ELSEIF v_LoginFails = 3 THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x80001010|3';
            ELSEIF v_LoginFails = 4 THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x80001010|4';
            END IF;

        END IF;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_LoginAuthorization_Bypass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_LoginAuthorization_Bypass`(IN IN_AdminAccount VARCHAR(50), IN IN_UserAccount VARCHAR(50), IN IN_Password VARCHAR(256))
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    IF NOT EXISTS (SELECT 1 FROM `UserAccounts`
                            WHERE `PWD`=IN_Password
                                AND `Email`=IN_AdminAccount
                                AND `SystemAdmin`=1) THEN
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x50001010'; -- Admin account not exists

    ELSEIF NOT EXISTS (SELECT 1 FROM `UserAccounts`
                            WHERE `Email`=IN_UserAccount) THEN
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x80001010'; -- No account exist

    ELSEIF EXISTS (SELECT 1 FROM `UserAccounts`
                        WHERE `Email`=IN_UserAccount
                            AND `Disabled`=1) THEN
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x60001010'; -- Account has been disabled

    ELSE
    BEGIN
        SELECT
            `UA`.`Idx`,
            `UA`.`Name`,
            `UA`.`SystemAdmin`,
            GROUP_CONCAT(DISTINCT CASE
                            WHEN `ACS`.`Idx` IS NOT NULL THEN `APS`.`Idx`
                        END) AS `AccessGranted`,
            GROUP_CONCAT(DISTINCT CASE
                            WHEN `ACS`.`Idx` IS NULL THEN `APS`.`Idx`
                        END) AS `AccessNotGranted`,
            `UA`.`Affiliation`
        FROM `UserAccounts` AS `UA`
                 CROSS JOIN `AcademicPrograms` AS `APS`
                 LEFT JOIN `AccessControls` AS `ACS`
                           ON (`UA`.`Idx` = `ACS`.`UserAccount`
                               AND `ACS`.`AcademicProgram` = `APS`.`Idx`)
                 LEFT JOIN `Positions` AS `POSTNS`
                           ON (`POSTNS`.`Idx` = `UA`.`Position`)
        WHERE  `Email`=IN_UserAccount
        GROUP BY
            `UA`.`Idx`;

    END;
    END IF;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_LoginCheck` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_LoginCheck`(IN IN_EmailAddress VARCHAR(50), IN IN_Password VARCHAR(256))
BEGIN
    DECLARE v_UserIdx INT DEFAULT 0;
    DECLARE v_StoredPWD VARCHAR(256);
    DECLARE v_Disabled TINYINT DEFAULT 0;
    DECLARE v_LoginFails INT DEFAULT 0;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if user exists and get their information
    SELECT `Idx`, `PWD`, `Disabled`, `LoginFails`
    INTO v_UserIdx, v_StoredPWD, v_Disabled, v_LoginFails
    FROM `UserAccounts`
    WHERE `Email` = IN_EmailAddress
    LIMIT 1;

    -- If user doesn't exist
    IF v_UserIdx = 0 THEN
        COMMIT; -- Commit before signaling
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001010|0'; -- No account exists
    END IF;

    -- If account is already disabled
    IF v_Disabled = 1 THEN
        COMMIT; -- Commit before signaling
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x60001010'; -- Account has been disabled
    END IF;

    -- Check if password matches
    IF v_StoredPWD = IN_Password THEN
        -- Successful login: Reset LoginFails and update LastLogIn
        UPDATE `UserAccounts`
        SET `LastLogIn` = NOW(),
            `LoginFails` = 0
        WHERE `Idx` = v_UserIdx;

        -- Return user information
        SELECT
            `UA`.`Idx`,
            `UA`.`Name`,
            `UA`.`SystemAdmin`,
            `UA`.`ResetPWD`,
            GROUP_CONCAT(DISTINCT CASE
                WHEN `ACS`.`Idx` IS NOT NULL THEN `APS`.`Idx`
            END) AS `AccessGranted`,
            GROUP_CONCAT(DISTINCT CASE
                WHEN `ACS`.`Idx` IS NULL THEN `APS`.`Idx`
            END) AS `AccessNotGranted`,
            `UA`.`Affiliation`,
            `POSTNS`.`AccessMyCourseAssessments`,
            `POSTNS`.`AccessTACourseAssessments`,
            `POSTNS`.`AccessCourseEvaluation`,
            `POSTNS`.`AccessAssessmentsSummary`
        FROM `UserAccounts` AS `UA`
            CROSS JOIN `AcademicPrograms` AS `APS`
            LEFT JOIN `AccessControls` AS `ACS`
                ON (`UA`.`Idx` = `ACS`.`UserAccount`
                    AND `ACS`.`AcademicProgram` = `APS`.`Idx`)
            LEFT JOIN `Positions` AS `POSTNS`
                ON (`POSTNS`.`Idx` = `UA`.`Position`)
        WHERE `UA`.`Idx` = v_UserIdx
        GROUP BY
            `UA`.`Idx`,
            `UA`.`Name`,
            `UA`.`SystemAdmin`,
            `UA`.`ResetPWD`,
            `UA`.`Affiliation`,
            `POSTNS`.`AccessMyCourseAssessments`,
            `POSTNS`.`AccessTACourseAssessments`,
            `POSTNS`.`AccessCourseEvaluation`,
            `POSTNS`.`AccessAssessmentsSummary`;

        COMMIT;

    ELSE
        -- Failed login: Increment LoginFails
        SET v_LoginFails = v_LoginFails + 1;

        -- Update the database with new count
        UPDATE `UserAccounts`
        SET `LoginFails` = v_LoginFails
        WHERE `Idx` = v_UserIdx;

        -- Check if this is the 5th failed attempt or more
        IF v_LoginFails >= 5 THEN
            -- Disable the account
            UPDATE `UserAccounts`
            SET `Disabled` = 1
            WHERE `Idx` = v_UserIdx;

            COMMIT; -- Commit BEFORE signaling error

            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x60001010'; -- Account disabled due to failed attempts

        ELSE
            COMMIT; -- Commit BEFORE signaling error

            -- Return error with failure count using CASE
            CASE v_LoginFails
                WHEN 1 THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x80001010|1';
                WHEN 2 THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x80001010|2';
                WHEN 3 THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x80001010|3';
                WHEN 4 THEN
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x80001010|4';
                ELSE
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '0x80001010|0';
            END CASE;

        END IF;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_LoginCheck_Bypass` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_LoginCheck_Bypass`(IN IN_AdminAccount VARCHAR(50), IN IN_UserAccount VARCHAR(50), IN IN_Password VARCHAR(256))
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    IF NOT EXISTS (SELECT 1 FROM `UserAccounts`
                            WHERE `PWD`=IN_Password
                                AND `Email`=IN_AdminAccount
                                AND `SystemAdmin`=1) THEN
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x50001010'; -- Admin account not exists

    ELSEIF NOT EXISTS (SELECT 1 FROM `UserAccounts`
                            WHERE `Email`=IN_UserAccount) THEN
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x80001010'; -- No account exist

    ELSEIF EXISTS (SELECT 1 FROM `UserAccounts`
                        WHERE `Email`=IN_UserAccount
                            AND `Disabled`=1) THEN
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x60001010'; -- Account has been disabled

    ELSE
    BEGIN
        SELECT
            `UA`.`Idx`,
            `UA`.`Name`,
            `UA`.`SystemAdmin`,
            GROUP_CONCAT(DISTINCT CASE
                            WHEN `ACS`.`Idx` IS NOT NULL THEN `APS`.`Idx`
                        END) AS `AccessGranted`,
            GROUP_CONCAT(DISTINCT CASE
                            WHEN `ACS`.`Idx` IS NULL THEN `APS`.`Idx`
                        END) AS `AccessNotGranted`,
            `UA`.`Affiliation`,
            `POSTNS`.`AccessMyCourseAssessments`,
            `POSTNS`.`AccessTACourseAssessments`,
            `POSTNS`.`AccessCourseEvaluation`,
            `POSTNS`.`AccessAssessmentsSummary`
        FROM `UserAccounts` AS `UA`
                 CROSS JOIN `AcademicPrograms` AS `APS`
                 LEFT JOIN `AccessControls` AS `ACS`
                           ON (`UA`.`Idx` = `ACS`.`UserAccount`
                               AND `ACS`.`AcademicProgram` = `APS`.`Idx`)
                 LEFT JOIN `Positions` AS `POSTNS`
                           ON (`POSTNS`.`Idx` = `UA`.`Position`)
        WHERE  `Email`=IN_UserAccount
        GROUP BY
            `UA`.`Idx`,
            `UA`.`Name`,
            `UA`.`SystemAdmin`,
            `UA`.`Affiliation`,
            `POSTNS`.`AccessMyCourseAssessments`,
            `POSTNS`.`AccessTACourseAssessments`,
            `POSTNS`.`AccessCourseEvaluation`,
            `POSTNS`.`AccessAssessmentsSummary`;

    END;
    END IF;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_LoginReset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_LoginReset`(IN IN_EmailAddress VARCHAR(50), IN IN_Name VARCHAR(256), IN IN_Password VARCHAR(256))
BEGIN
    DECLARE v_UserIdx INT;

	START TRANSACTION;

	SELECT `Idx` INTO v_UserIdx
    FROM `UserAccounts`
    WHERE LOWER(`Name`) LIKE CONCAT('%', LOWER(IN_Name), '%')
    AND LOWER(`Email`) = LOWER(IN_EmailAddress);

    IF v_UserIdx IS NOT NULL THEN -- Use IS NOT NULL instead of NOT NULL
        UPDATE `UserAccounts`
        SET `PWD` = IN_Password, `ResetPWD`=1, `LoginFails`=0
        WHERE `Idx` = v_UserIdx;

        SELECT '0x11111111' AS 'MESSAGE'; -- Use single quotes for string literals
    ELSE
        SELECT '0x80001010' AS 'MESSAGE';
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAbetCourse` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAbetCourse`(
    IN IN_Idx INT
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if ABET Course is referenced in TypeOfAssignments
    IF EXISTS (SELECT 1 FROM `TypeOfAssignments` WHERE `AbetCourseIdx` = IN_Idx) THEN
        -- Cannot delete: ABET Course is referenced
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x09000010';
    END IF;

    -- Check if ABET Course is referenced in AssessmentMeasures
    IF EXISTS (SELECT 1 FROM `AssessmentMeasures` WHERE `AbetCourseIdx` = IN_Idx) THEN
        -- Cannot delete: ABET Course is referenced
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x09000010';
    END IF;

    -- Delete related records in ContinuousImprovement (cascade delete)
    DELETE FROM `ContinuousImprovement` WHERE `AbetCourseIdx` = IN_Idx;

    -- If no references found, safe to delete
    DELETE FROM `AbetCourses` WHERE `Idx` = IN_Idx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAbetSyllabus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAbetSyllabus`(
    IN IN_Index INT,
    IN IN_Syllabus VARCHAR(256)
)
BEGIN
    START TRANSACTION;

    UPDATE `AbetCourses` SET `Syllabus` = NULL WHERE `Syllabus` = IN_Syllabus;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAbetSyllabusInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAbetSyllabusInfo`(
    IN IN_CourseIdx INT,
    IN IN_AbetSyllabusIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN
    -- Declare variables to store intermediate results
    DECLARE v_AcademicYearTo BIGINT;
    DECLARE v_PreviousIdx INT;
    DECLARE v_LinkedABETSyllabusIdx INT;
    DECLARE v_LinkedABETSyllabusCourseIndex INT;
    DECLARE v_LinkedABETSyllabusAcademicYearTo INT;
    DECLARE v_LinkedABETSyllabusAcademicProgramIdx INT;
    DECLARE v_done BOOLEAN DEFAULT FALSE;

    -- Declare cursor
    DECLARE cursor_linked_syllabus CURSOR FOR
        SELECT `Idx`, `CourseIndex`, `AcademicYearTo`, `AcademicProgram`
        FROM `AbetSyllabus`
        WHERE `LinkedSyllabus` = IN_AbetSyllabusIdx;

    -- Declare NOT FOUND handler
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

--     IF EXISTS (SELECT 1 FROM `AbetSyllabus` WHERE `major_version` = 1 and `minor_version` = 0 and `Idx` = IN_AbetSyllabusIdx) THEN
--         -- Cannot delete: syllabus of version 1.0 cannot be deleted.
--         SIGNAL SQLSTATE '45000'
--         SET MESSAGE_TEXT = '0x09000010';
--
--     ELSE
    IF EXISTS (SELECT 1 FROM `CourseMapping_Courses` WHERE `AbetSyllabus` = IN_AbetSyllabusIdx) THEN
        -- Cannot delete: the selected course is mapped already
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x09000010';

    ELSEIF EXISTS (
        SELECT 1
        FROM `AbetSyllabus` AS `ABS`
        INNER JOIN `CourseMapping_Courses` AS `CMCS` ON `ABS`.`Idx` = `CMCS`.`AbetSyllabus`
        WHERE `ABS`.`LinkedSyllabus` = IN_AbetSyllabusIdx
    ) THEN
        -- Cannot delete: the selected course's linked courses are mapped already
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x09000010';

    ELSEIF NOT EXISTS (
        SELECT 1
        FROM `AbetSyllabus`
        WHERE `CourseIndex` = IN_CourseIdx
            AND `Idx` = IN_AbetSyllabusIdx
            AND `AcademicProgram` = IN_AcademicProgramIdx
    ) THEN
        -- Cannot delete: the selected syllabus does not exist
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00300011';
    END IF;

    OPEN cursor_linked_syllabus;

    read_loop: LOOP
        FETCH cursor_linked_syllabus INTO
            v_LinkedABETSyllabusIdx,
            v_LinkedABETSyllabusCourseIndex,
            v_LinkedABETSyllabusAcademicYearTo,
            v_LinkedABETSyllabusAcademicProgramIdx;

        IF v_done THEN
            LEAVE read_loop;
        END IF;

        IF v_LinkedABETSyllabusIdx IS NOT NULL AND v_LinkedABETSyllabusAcademicProgramIdx IS NOT NULL THEN
            -- Get the previous version's Idx
            SELECT MAX(`Idx`) INTO v_PreviousIdx
            FROM `AbetSyllabus`
            WHERE `CourseIndex` = v_LinkedABETSyllabusCourseIndex
                AND `AcademicProgram` = v_LinkedABETSyllabusAcademicProgramIdx
                AND `Idx` < v_LinkedABETSyllabusIdx;

            -- Update previous version's AcademicYearTo if it exists
            IF v_PreviousIdx IS NOT NULL THEN
                UPDATE `AbetSyllabus`
                SET `AcademicYearTo` = v_LinkedABETSyllabusAcademicYearTo
                WHERE `Idx` = v_PreviousIdx;
            END IF;

            -- Delete the record
            DELETE FROM `AbetSyllabus`
            WHERE `Idx` = v_LinkedABETSyllabusIdx;
        END IF;
    END LOOP;

    CLOSE cursor_linked_syllabus;

    -- Get the AcademicYearTo of the record to be deleted
    SELECT `AcademicYearTo` INTO v_AcademicYearTo
    FROM `AbetSyllabus`
    WHERE `Idx` = IN_AbetSyllabusIdx;

    -- Get the previous version's Idx
    SELECT MAX(`Idx`) INTO v_PreviousIdx
    FROM `AbetSyllabus`
    WHERE `CourseIndex` = IN_CourseIdx
        AND `AcademicProgram` = IN_AcademicProgramIdx
        AND `Idx` < IN_AbetSyllabusIdx;

    -- Update previous version's AcademicYearTo if it exists
    IF v_PreviousIdx IS NOT NULL THEN
        UPDATE `AbetSyllabus`
        SET `AcademicYearTo` = v_AcademicYearTo
        WHERE `Idx` = v_PreviousIdx;
    END IF;

    -- Delete the record
    DELETE FROM `AbetSyllabus`
    WHERE `Idx` = IN_AbetSyllabusIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAbetSyllabusLink` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAbetSyllabusLink`(
    IN IN_AbetSyllabusIdx INT,
    IN IN_AcademicProgramIdx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `CourseMapping_Courses` WHERE `AbetSyllabus` = IN_AbetSyllabusIdx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSE
        UPDATE `AbetSyllabus` SET `LinkedSyllabus`=NULL WHERE `Idx` = IN_AbetSyllabusIdx;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAcademicYearInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAcademicYearInfo`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `StudentOutcomes` WHERE `AcademicYear` = IN_Idx) THEN
           -- Cannot delete: the item is used already
            SIGNAL SQLSTATE '45000'
            SET  MESSAGE_TEXT = '0x09000010';

    ELSE
    DELETE FROM `AcademicYears` WHERE `Idx` = IN_Idx;
    END IF;

    COMMIT;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAccount`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `AVCoursesInstructors` WHERE `Instructor` = IN_Idx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSEIF EXISTS (SELECT 1 FROM `AccessControls` WHERE `UserAccount` = IN_Idx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSEIF EXISTS (SELECT 1 FROM `AbetCourses_Evaluators` WHERE `Evaluator` = IN_Idx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSE
        DELETE FROM `UserAccounts` WHERE `Idx` = IN_Idx;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAffiliation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAffiliation`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `UserAccounts` WHERE `Affiliation` = IN_Idx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSE
        DELETE FROM `Affiliations` WHERE `Idx` = IN_Idx;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAllCMs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAllCMs`(
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    IF EXISTS (
        SELECT 1
        FROM `CourseMapping_Courses` AS `CMCRSES`
        INNER JOIN `Courses` AS `CRSES`
            ON (`CMCRSES`.`CourseIdx` = `CRSES`.`Idx`
                AND `CMCRSES`.`AcademicYear` = IN_AcademicYear
                AND `CMCRSES`.`AcademicProgram` = IN_AcademicProgram)
        WHERE EXISTS (
            SELECT 1
            FROM `AbetCourses` AS `ABETCRSES`
            INNER JOIN `AVCourses` AS `AVCRSES`
                ON (`ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`
                    AND `ABETCRSES`.`AcademicYear` = IN_AcademicYear
                    AND `ABETCRSES`.`AcademicProgram` = IN_AcademicProgram)
            WHERE `AVCRSES`.`Subject` = `CRSES`.`Subject`
            AND `AVCRSES`.`Num` = `CRSES`.`Num`
        )
    ) THEN
        -- Cannot delete: Student Outcomes are referenced in ABET Courses
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x09000010';
    ELSE
        DELETE FROM `CourseMapping_Courses`
        WHERE `AcademicYear` = IN_AcademicYear
          AND `AcademicProgram` = IN_AcademicProgram;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAllPIs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAllPIs`(
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (
            SELECT 1
            FROM `CourseMapping_GPIs` CMPI
            INNER JOIN `GeneralPerformanceIndicators` PI ON CMPI.GPIIdx = PI.Idx
            WHERE CMPI.AcademicYear = IN_AcademicYear
                AND CMPI.AcademicProgram = IN_AcademicProgram
        ) THEN
            -- Cannot delete: PIs are referenced in ABET Courses
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x09000010';

    ELSE
        DELETE FROM `GeneralPerformanceIndicators`
        WHERE `AcademicYear` = IN_AcademicYear
        AND `AcademicProgram` = IN_AcademicProgram;

    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAllSOs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAllSOs`(
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    IF EXISTS (
            SELECT 1
            FROM `CourseMapping_SOs` CMSO
            INNER JOIN `StudentOutcomes` SO ON CMSO.SOIdx = SO.Idx
            WHERE CMSO.AcademicYear = IN_AcademicYear
            AND CMSO.AcademicProgram = IN_AcademicProgram
        ) THEN
            -- Cannot delete: Student Outcomes are referenced in ABET Courses
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x09000010';

    ELSEIF EXISTS (
            SELECT 1
            FROM `GeneralPerformanceIndicators` PI
            INNER JOIN `StudentOutcomes` SO ON PI.SOIdx = SO.Idx
            WHERE SO.AcademicYear = IN_AcademicYear
            AND SO.AcademicProgram = IN_AcademicProgram
        ) THEN
            -- Cannot delete: Student Outcomes are referenced in Performance Indicators
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x09000011';

    ELSE
        DELETE FROM `StudentOutcomes`
        WHERE `AcademicYear` = IN_AcademicYear
          AND `AcademicProgram` = IN_AcademicProgram;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAllStudentsFromRoster` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAllStudentsFromRoster`(
    IN IN_AvailableCourseIdx INT
)
BEGIN
    -- Start transaction for atomic operation
    START TRANSACTION;

    -- Validate course index parameter
    IF IN_AvailableCourseIdx IS NULL OR IN_AvailableCourseIdx < 1 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50001001'; -- Invalid course index
    END IF;

    -- Verify that the course exists in AVCourses table
    IF NOT EXISTS (SELECT 1 FROM `AVCourses` WHERE `Idx` = IN_AvailableCourseIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50001002'; -- Course does not exist
    END IF;

    -- Remove all students from the class roster for the specified course
    -- This is a permanent deletion operation
    DELETE FROM `ClassRoster`
    WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx;

    -- Commit transaction
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAssessmentMaterialStudentSample` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAssessmentMaterialStudentSample`(
    IN IN_CourseMaterialsIdx INT,
    IN IN_StudentSampleNum INT
)
BEGIN
    DECLARE v_StudentSample VARCHAR(256);

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Validate IN_StudentSampleNum
    IF IN_StudentSampleNum NOT IN (1, 2, 3) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'StudentSampleNum must be 1, 2, or 3';
    END IF;

    START TRANSACTION;

    IF IN_StudentSampleNum = 1 THEN
        SELECT StudentSample1 INTO v_StudentSample
        FROM AVCourses_CrsMaterials
        WHERE Idx = IN_CourseMaterialsIdx;

        UPDATE `AVCourses_CrsMaterials`
            SET `StudentSample1` = NULL
            WHERE `Idx` = IN_CourseMaterialsIdx;
    ELSEIF IN_StudentSampleNum = 2 THEN
        SELECT StudentSample2 INTO v_StudentSample
        FROM AVCourses_CrsMaterials
        WHERE Idx = IN_CourseMaterialsIdx;

        UPDATE `AVCourses_CrsMaterials`
            SET `StudentSample2` = NULL
            WHERE `Idx` = IN_CourseMaterialsIdx;
    ELSE
        SELECT StudentSample3 INTO v_StudentSample
        FROM AVCourses_CrsMaterials
        WHERE Idx = IN_CourseMaterialsIdx;

        UPDATE `AVCourses_CrsMaterials`
            SET `StudentSample3` = NULL
            WHERE `Idx` = IN_CourseMaterialsIdx;
    END IF;

    -- Update the record to indicate the course binder material has been changed.
    UPDATE `AVCourses` AS `AVCRSES`
    SET `crsbinder_updated` = 1
    WHERE `AVCRSES`.`Idx` = (SELECT `AvailableCourseIdx` FROM `AVCourses_CrsMaterials` WHERE Idx = IN_CourseMaterialsIdx);

    -- Return the deleted filename
    SELECT v_StudentSample AS StudentSampleFile;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAssessmentMeasure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAssessmentMeasure`(
    IN IN_Idx INT
)
BEGIN
    -- Declare variables
    DECLARE v_ActualAssmntSample VARCHAR(256);
    DECLARE v_AvailableCourseIdx INT;
    DECLARE v_AbetCourseIdx INT;
    DECLARE v_AssignmentType VARCHAR(256);
    DECLARE v_AssignmentNum INT;
    DECLARE v_AssignmentProblem VARCHAR(1024);
    DECLARE v_Measure INT;
    DECLARE v_IsLinked INT DEFAULT 0;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Find details of the assessment measure being removed
    SELECT
        `ActualAssmntSample`,
        `AvailableCourseIdx`,
        `AbetCourseIdx`,
        `AssignmentType`,
        `AssignmentNum`,
        `AssignmentProblem`,
        `Measure`
    INTO
        v_ActualAssmntSample,
        v_AvailableCourseIdx,
        v_AbetCourseIdx,
        v_AssignmentType,
        v_AssignmentNum,
        v_AssignmentProblem,
        v_Measure
    FROM `AssessmentMeasures`
    WHERE `Idx` = IN_Idx;

    -- Check if this course is part of a linked group
    SELECT IFNULL(`Linked`, 0) INTO v_IsLinked
    FROM `AbetCourses`
    WHERE `Idx` = v_AbetCourseIdx;

    -- Remove the selected assessment measure from primary course
    DELETE FROM `AssessmentMeasures` WHERE `Idx` = IN_Idx;

    -- Remove matching measures from related courses based on course type
    IF v_IsLinked = 1 THEN
        -- This is a linked course with different available courses
        CALL SP_RemoveAssessmentMeasureForLinkedCourses(
            v_Measure, v_AssignmentType, v_AssignmentNum,
            v_AvailableCourseIdx, v_AbetCourseIdx
        );
    ELSE
        -- This is a regular reference course with same available course
        CALL SP_RemoveAssessmentMeasureForReferenceCourses(
            v_AssignmentType, v_AssignmentNum, v_AssignmentProblem,
            v_AvailableCourseIdx, v_AbetCourseIdx
        );
    END IF;

    -- Re-order assessment measures in primary course
    SET @ordering_inc = 1;
    SET @new_ordering = 0;
    UPDATE `AssessmentMeasures`
    SET `Measure` = (@new_ordering := @new_ordering + @ordering_inc)
    WHERE `AvailableCourseIdx` = v_AvailableCourseIdx
    AND `AbetCourseIdx` = v_AbetCourseIdx
    ORDER BY `Measure` ASC;

    -- Re-order measures in related courses based on course type
    IF v_IsLinked = 1 THEN
        CALL SP_ReorderAssessmentMeasuresForLinkedCourses(
            v_AvailableCourseIdx, v_AbetCourseIdx
        );
    ELSE
        CALL SP_ReorderAssessmentMeasuresForReferenceCourses(
            v_AvailableCourseIdx, v_AbetCourseIdx
        );
    END IF;

    -- Fetch total number of measures that have the same actual assessment sample
    -- (This helps UI determine if the sample file should be deleted)
    SELECT
        COUNT(*) AS CNT,
        v_ActualAssmntSample AS `ActualAssmntSampleFile`
    FROM `AssessmentMeasures`
    WHERE `ActualAssmntSample` = v_ActualAssmntSample
    AND `AvailableCourseIdx` = v_AvailableCourseIdx
    AND `AbetCourseIdx` = v_AbetCourseIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAssessmentMeasureForLinkedCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAssessmentMeasureForLinkedCourses`(
    IN IN_Measure INT,
    IN IN_AssignmentType VARCHAR(256),
    IN IN_AssignmentNum INT,
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT
)
BEGIN
    -- Remove matching assessment measures from all linked courses
    DELETE FROM `AssessmentMeasures`
    WHERE `AbetCourseIdx` IN (
        SELECT `Idx`
        FROM `AbetCourses`
        WHERE `Linked` = 1
        AND `Reference` = IN_AbetCourseIdx
    )
    AND `AssignmentType` = IN_AssignmentType
    AND (
        (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
        OR
        (`AssignmentNum` = IN_AssignmentNum)
    )
    AND `Measure` = IN_Measure;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAssessmentMeasureForReferenceCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAssessmentMeasureForReferenceCourses`(
    IN IN_AssignmentType VARCHAR(256),
    IN IN_AssignmentNum INT,
    IN IN_AssignmentProblem VARCHAR(1024),
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT
)
BEGIN
    -- Remove matching assessment measures from all reference courses
    DELETE FROM `AssessmentMeasures`
    WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
    AND `AssignmentType` = IN_AssignmentType
    AND (
        (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
        OR
        (`AssignmentNum` = IN_AssignmentNum)
    )
    AND `AssignmentProblem` = IN_AssignmentProblem
    AND `AbetCourseIdx` IN (
        SELECT `Idx`
        FROM `AbetCourses`
        WHERE `AVCourseIdx` = IN_AvailableCourseIdx
        AND `Reference` = IN_AbetCourseIdx
    );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAssessmentMeasureStudentSample` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAssessmentMeasureStudentSample`(
    IN IN_SampleIdx INT,
    IN IN_SampleFile VARCHAR(255)
)
BEGIN
    DECLARE v_SampleFile VARCHAR(255);
    
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Input validation (BEFORE transaction starts)
    IF IN_SampleIdx IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001030'; -- Sample index required
    END IF;

    IF IN_SampleFile IS NULL OR TRIM(IN_SampleFile) = '' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001033'; -- Sample file name required
    END IF;

    -- Check if sample exists AND the file name matches (security check)
    SELECT `SampleFile` INTO v_SampleFile
    FROM `AssessmentMeasureSamples`
    WHERE `Idx` = IN_SampleIdx
      AND `SampleFile` = IN_SampleFile;

    -- If no record found or file name doesn't match
    IF v_SampleFile IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001031'; -- Sample not found or file mismatch
    END IF;

    -- START TRANSACTION AFTER all validation passes
    START TRANSACTION;

    -- Return the sample file name before deletion (for physical file removal)
    SELECT v_SampleFile AS SampleFile;

    -- Delete the student sample record
    DELETE FROM `AssessmentMeasureSamples`
    WHERE `Idx` = IN_SampleIdx
      AND `SampleFile` = IN_SampleFile;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAssessmentSample` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAssessmentSample`(
    IN IN_Idx INT,
    IN IN_ActualAssmntSample VARCHAR(256)
)
BEGIN
    -- Declare variables
    DECLARE v_ActualAssmntSample VARCHAR(256);
    DECLARE v_AvailableCourseIdx INT;
    DECLARE v_AbetCourseIdx INT;
    DECLARE v_IsLinked INT DEFAULT 0;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Find details of the assessment measure
    SELECT
        `ActualAssmntSample`,
        `AvailableCourseIdx`,
        `AbetCourseIdx`
    INTO
        v_ActualAssmntSample,
        v_AvailableCourseIdx,
        v_AbetCourseIdx
    FROM `AssessmentMeasures`
    WHERE `Idx` = IN_Idx;

    -- Validate that the provided sample file matches
    IF IN_ActualAssmntSample = v_ActualAssmntSample THEN
        -- Check if this course is part of a linked group
        SELECT IFNULL(`Linked`, 0) INTO v_IsLinked
        FROM `AbetCourses`
        WHERE `Idx` = v_AbetCourseIdx;

        -- Remove the assessment sample from primary course
        UPDATE `AssessmentMeasures` 
        SET `ActualAssmntSample` = ''
        WHERE `AvailableCourseIdx` = v_AvailableCourseIdx
        AND `AbetCourseIdx` = v_AbetCourseIdx
        AND `ActualAssmntSample` = v_ActualAssmntSample;

        -- Remove sample from related courses based on course type
        IF v_IsLinked = 1 THEN
            -- This is a linked course with different available courses
            CALL SP_RemoveAssessmentSampleForLinkedCourses(
                v_ActualAssmntSample,
                v_AvailableCourseIdx,
                v_AbetCourseIdx
            );
        ELSE
            -- This is a regular reference course with same available course
            CALL SP_RemoveAssessmentSampleForReferenceCourses(
                v_ActualAssmntSample,
                v_AvailableCourseIdx,
                v_AbetCourseIdx
            );
        END IF;

        -- Return the actual assessment sample file path
        SELECT v_ActualAssmntSample AS `ActualAssmntSampleFile`;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAssessmentSampleForLinkedCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAssessmentSampleForLinkedCourses`(
    IN IN_ActualAssmntSample VARCHAR(256),
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT
)
BEGIN
    -- Remove sample from all linked courses (excluding the primary course itself)
    UPDATE `AssessmentMeasures`
    SET `ActualAssmntSample` = ''
    WHERE `ActualAssmntSample` = IN_ActualAssmntSample
    AND `AbetCourseIdx` IN (
        SELECT `Idx`
        FROM `AbetCourses`
        WHERE `Linked` = 1
        AND `Reference` = IN_AbetCourseIdx
    );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAssessmentSampleForReferenceCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAssessmentSampleForReferenceCourses`(
    IN IN_ActualAssmntSample VARCHAR(256),
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT
)
BEGIN
    -- Remove sample from all reference courses with same AvailableCourseIdx (excluding primary)
    UPDATE `AssessmentMeasures`
    SET `ActualAssmntSample` = ''
    WHERE `ActualAssmntSample` = IN_ActualAssmntSample
    AND `AvailableCourseIdx` = IN_AvailableCourseIdx
    AND `AbetCourseIdx` != IN_AbetCourseIdx;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAvailableCourse` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAvailableCourse`(
    IN p_AvailableCourseIdx INT
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Check if course exists
    IF NOT EXISTS (SELECT 1 FROM AVCourses WHERE Idx = p_AvailableCourseIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012: Course not found';
    END IF;

    -- Check if course is being used (has assessments, etc.)
    IF EXISTS (SELECT 1 FROM AbetCourses WHERE AVCourseIdx = p_AvailableCourseIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x09000010: Cannot delete course - it has associated assessments';
    END IF;

    -- Delete related records first
    DELETE FROM AVCoursesInstructors WHERE AVCourseIdx = p_AvailableCourseIdx;
    DELETE FROM ClassRoster WHERE AvailableCourseIdx = p_AvailableCourseIdx;

    -- Delete the course
    DELETE FROM AVCourses WHERE Idx = p_AvailableCourseIdx;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveAVCourseSyllabus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveAVCourseSyllabus`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT
)
BEGIN
    DECLARE v_AVCourseExists INT DEFAULT 0;
    DECLARE v_AbetCourseExists INT DEFAULT 0;
    DECLARE v_IsLinked INT DEFAULT 0;
    DECLARE v_ReferenceIdx INT DEFAULT NULL;
    DECLARE v_PrimaryAbetCourseIdx INT DEFAULT NULL;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Validate that Available course exists
    SELECT COUNT(*) INTO v_AVCourseExists
    FROM `AVCourses`
    WHERE `Idx` = IN_AvailableCourseIdx;

    IF v_AVCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- Available course does not exist
    END IF;

    -- Validate that ABET course exists and get its Linked and Reference status
    SELECT COUNT(*), MAX(`Linked`), MAX(`Reference`)
    INTO v_AbetCourseExists, v_IsLinked, v_ReferenceIdx
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdx;

    IF v_AbetCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200013'; -- ABET course does not exist
    END IF;

    -- Remove syllabus from the specified Available course
    UPDATE `AVCourses`
    SET `Syllabus` = NULL,
        `crsbinder_updated` = 1
    WHERE `Idx` = IN_AvailableCourseIdx;

    -- Check if this is part of a linked course group
    IF v_IsLinked = 1 THEN
        -- Determine the Primary ABET course index
        IF v_ReferenceIdx IS NULL THEN
            -- This is the Primary course
            SET v_PrimaryAbetCourseIdx = IN_AbetCourseIdx;
        ELSE
            -- This is a Reference course, use its Reference value as Primary
            SET v_PrimaryAbetCourseIdx = v_ReferenceIdx;

            -- Remove syllabus from the Primary course's Available course
            UPDATE `AVCourses` AS AVC
            INNER JOIN `AbetCourses` AS ABC ON AVC.`Idx` = ABC.`AVCourseIdx`
            SET AVC.`Syllabus` = NULL,
                AVC.`crsbinder_updated` = 1
            WHERE ABC.`Idx` = v_PrimaryAbetCourseIdx;
        END IF;

        -- Remove syllabus from all Reference courses' Available courses in the linked group
        UPDATE `AVCourses` AS AVC
        INNER JOIN `AbetCourses` AS ABC ON AVC.`Idx` = ABC.`AVCourseIdx`
        SET AVC.`Syllabus` = NULL,
            AVC.`crsbinder_updated` = 1
        WHERE ABC.`Reference` = v_PrimaryAbetCourseIdx
          AND ABC.`Linked` = 1
          AND AVC.`Idx` != IN_AvailableCourseIdx; -- Avoid updating the same course twice
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveBatchPIs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveBatchPIs`(
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT,
    IN IN_CourseSubject VARCHAR(5),
    IN IN_CourseNum VARCHAR(5)
)
BEGIN
    DECLARE v_CourseIdx INT;
    DECLARE v_AbetCourseIdx INT;

    -- First check if the course exists
    SELECT Idx INTO v_CourseIdx
    FROM Courses c
    WHERE c.Subject = IN_CourseSubject
      AND c.Num = IN_CourseNum
    LIMIT 1;

    IF v_CourseIdx IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Course not found';
    END IF;

    -- Get AbetCourseIdx from CourseMapping_Courses
    SELECT cmc.Idx INTO v_AbetCourseIdx
    FROM CourseMapping_Courses cmc
    WHERE cmc.CourseIdx = v_CourseIdx
      AND cmc.AcademicYear = IN_AcademicYear
      AND cmc.AcademicProgram = IN_AcademicProgram
    LIMIT 1;

    IF v_AbetCourseIdx IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Course mapping not found';
    END IF;

    -- Delete SO and PI
    DELETE FROM CourseMapping_GPIs
    WHERE AbetCourseIdx = v_AbetCourseIdx
      AND AcademicYear = IN_AcademicYear
      AND AcademicProgram = IN_AcademicProgram;

    DELETE FROM CourseMapping_SOs
    WHERE AbetCourseIdx = v_AbetCourseIdx
      AND AcademicYear = IN_AcademicYear
      AND AcademicProgram = IN_AcademicProgram;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveCM` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveCM`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (
        SELECT 1
        FROM `CourseMapping_Courses` AS `CMCRSES1`
        INNER JOIN `Courses` AS `CRSES`
            ON `CMCRSES1`.`CourseIdx` = `CRSES`.`Idx`
        WHERE `CMCRSES1`.`Idx` = IN_Idx
            AND EXISTS (
                SELECT 1
                FROM `AbetCourses` AS `ABETCRSES`
                INNER JOIN `AVCourses` AS `AVCRSES`
                    ON `ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx`
                WHERE `ABETCRSES`.`AcademicYear` = `CMCRSES1`.`AcademicYear`
                    AND `ABETCRSES`.`AcademicProgram` = `CMCRSES1`.`AcademicProgram`
                    AND `AVCRSES`.`Subject` = `CRSES`.`Subject`
                    AND `AVCRSES`.`Num` = `CRSES`.`Num`
            )
    ) THEN
   -- Cannot delete: CM is referenced in ABET Courses
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSE
        DELETE FROM `CourseMapping_Courses` WHERE `Idx` = IN_Idx;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveCourse` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveCourse`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `CourseMapping_Courses` WHERE `CourseIdx` = IN_Idx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSEIF EXISTS (SELECT 1 FROM `AbetSyllabus` WHERE `CourseIndex` = IN_Idx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSE
    DELETE FROM `Courses` WHERE `Idx` = IN_Idx;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveCourseAssessment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveCourseAssessment`(IN IN_Idx INT)
BEGIN
    DECLARE v_AssmntSample VARCHAR(256);
    DECLARE v_StudentSample1 VARCHAR(256);
    DECLARE v_StudentSample2 VARCHAR(256);
    DECLARE v_StudentSample3 VARCHAR(256);
    DECLARE v_RecordExists INT;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if record exists
    SELECT COUNT(*) INTO v_RecordExists
    FROM AVCourses_CrsMaterials
    WHERE Idx = IN_Idx;

    IF v_RecordExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Record not found';
    END IF;

    -- Get file names before deletion
    SELECT AssmntSample, StudentSample1, StudentSample2, StudentSample3
    INTO v_AssmntSample, v_StudentSample1, v_StudentSample2, v_StudentSample3
    FROM AVCourses_CrsMaterials
    WHERE Idx = IN_Idx;

    -- Update the record to indicate the course binder material has been changed.
    UPDATE `AVCourses` AS `AVCRSES`
    SET `crsbinder_updated` = 1
    WHERE `AVCRSES`.`Idx` = (SELECT `AvailableCourseIdx` FROM `AVCourses_CrsMaterials` WHERE Idx = IN_Idx);

    -- Delete the record
    DELETE FROM `AVCourses_CrsMaterials` WHERE Idx = IN_Idx;

    -- Return the deleted filenames
    SELECT v_AssmntSample AS AssmntSample,
           v_StudentSample1 AS StudentSample1,
           v_StudentSample2 AS StudentSample2,
           v_StudentSample3 AS StudentSample3;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveCourseInstructor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveCourseInstructor`(
    IN IN_InstructorIdx INT
)
BEGIN
    DECLARE v_avcIdx INT;
    DECLARE v_removedUserIdx INT;
    DECLARE v_currentPrimaryEmail VARCHAR(255);
    DECLARE v_removedEmail VARCHAR(255);
    DECLARE v_instructorString TEXT;
    DECLARE v_newPrimaryEmail VARCHAR(255);
    DECLARE v_firstEmail VARCHAR(255);

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if the instructor assignment exists and get related information
    SELECT `AVCourseIdx`, `Instructor`
    INTO v_avcIdx, v_removedUserIdx
    FROM `AVCoursesInstructors`
    WHERE `Idx` = IN_InstructorIdx;

    -- If no record found, throw error
    IF v_avcIdx IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00000001'; -- Invalid instructor assignment
    END IF;

    -- Get the current primary instructor email from AVCourses
    SELECT `InstructorEmail`
    INTO v_currentPrimaryEmail
    FROM `AVCourses`
    WHERE `Idx` = v_avcIdx;

    -- Get the email of the instructor being removed
    SELECT `Email`
    INTO v_removedEmail
    FROM `UserAccounts`
    WHERE `Idx` = v_removedUserIdx;

    -- Delete the instructor assignment
    DELETE FROM `AVCoursesInstructors`
    WHERE `Idx` = IN_InstructorIdx;

    -- Get all remaining instructors for this course with their names (concatenated)
    SELECT
        GROUP_CONCAT(ua.`Name` ORDER BY ua.`Name` ASC SEPARATOR ', '),
        MIN(ua.`Email`)
    INTO v_instructorString, v_firstEmail
    FROM `AVCoursesInstructors` aci
    LEFT JOIN `UserAccounts` ua ON aci.`Instructor` = ua.`Idx`
    WHERE aci.`AVCourseIdx` = v_avcIdx AND ua.`Name` IS NOT NULL;

    -- Determine new primary instructor email
    -- If removed email was the primary, assign first remaining instructor as primary
    IF v_removedEmail = v_currentPrimaryEmail THEN
        SET v_newPrimaryEmail = IFNULL(v_firstEmail, '');
    ELSE
        -- Check if current primary email still exists in remaining instructors
        SELECT ua.`Email`
        INTO v_newPrimaryEmail
        FROM `AVCoursesInstructors` aci
        LEFT JOIN `UserAccounts` ua ON aci.`Instructor` = ua.`Idx`
        WHERE aci.`AVCourseIdx` = v_avcIdx
          AND ua.`Email` = v_currentPrimaryEmail
        LIMIT 1;

        -- If primary email not found in remaining instructors, use first email
        IF v_newPrimaryEmail IS NULL THEN
            SET v_newPrimaryEmail = IFNULL(v_firstEmail, '');
        END IF;
    END IF;

    -- Update AVCourses table
    UPDATE `AVCourses`
    SET `Instructor` = IFNULL(v_instructorString, ''),
        `InstructorEmail` = IFNULL(v_newPrimaryEmail, ''),
        `IsManuallyEdited` = 1
    WHERE `Idx` = v_avcIdx;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveCrsMaterialsCourseSyllabus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveCrsMaterialsCourseSyllabus`(
    IN IN_AvailableCourseIdx INT
)
BEGIN
    DECLARE v_AVCourseExists INT DEFAULT 0;
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    -- Validate that Available course exists
    SELECT COUNT(*) INTO v_AVCourseExists
    FROM `AVCourses`
    WHERE `Idx` = IN_AvailableCourseIdx;
    IF v_AVCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- Available course does not exist
    END IF;
    -- Remove syllabus from the specified Available course
    UPDATE `AVCourses`
    SET `Syllabus` = NULL,
        `crsbinder_updated` = 1
    WHERE `Idx` = IN_AvailableCourseIdx;
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveInstructionalMaterial` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveInstructionalMaterial`(
    IN IN_Idx INT,
    IN IN_InstructionalMaterialSample VARCHAR(256)
)
BEGIN
 	DECLARE v_InstructionalMaterial VARCHAR (256);

   -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check and get material in one query
    -- Double checking to avoid possible attack
    SELECT MaterialSample INTO v_InstructionalMaterial
    FROM AVCourses_InstMaterials
    WHERE Idx = IN_Idx
        AND MaterialSample = IN_InstructionalMaterialSample;

    IF v_InstructionalMaterial IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x08000010'; -- Material not found
    END IF;

    -- Update the record to indicate the course binder material has been changed.
    UPDATE `AVCourses` AS `AVCRSES`
    SET `crsbinder_updated` = 1
    WHERE `AVCRSES`.`Idx` = (SELECT `AvailableCourseIdx` FROM `AVCourses_InstMaterials` WHERE Idx = IN_Idx);

    -- Delete the record
    DELETE FROM AVCourses_InstMaterials
    WHERE Idx = IN_Idx
    AND MaterialSample = IN_InstructionalMaterialSample;

    -- Return the deleted filename
    SELECT v_InstructionalMaterial AS InstructionalMaterialFile;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveLinksInAllAbetCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveLinksInAllAbetCourses`(
    IN IN_AvcIdx INT,
    IN IN_AbcIdxList VARCHAR(4000)
)
BEGIN
    DECLARE v_UpdatedRows INT DEFAULT 0;
    DECLARE v_CurrentAbcIdx INT;
    DECLARE v_Position INT DEFAULT 1;
    DECLARE v_AbcIdxCount INT DEFAULT 0;
    DECLARE v_CommaPos INT;
    DECLARE v_Remaining VARCHAR(4000);
    DECLARE v_CurrentAbcStr VARCHAR(20);

    -- Start transaction
    START TRANSACTION;

    -- Validate input
    IF IN_AvcIdx IS NULL OR IN_AvcIdx < 1 OR
       IN_AbcIdxList IS NULL OR IN_AbcIdxList = '' THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50006001'; -- Invalid input: AvcIdx is NULL or AbcIdxList is empty
    END IF;

    -- Count elements in the list
    SET v_AbcIdxCount = LENGTH(IN_AbcIdxList) - LENGTH(REPLACE(IN_AbcIdxList, ',', '')) + 1;

    -- Initialize remaining string
    SET v_Remaining = IN_AbcIdxList;

    -- Process each AbcIdx
    WHILE v_Position <= v_AbcIdxCount DO
        -- Extract current AbcIdx
        SET v_CommaPos = LOCATE(',', v_Remaining);
        IF v_CommaPos > 0 THEN
            SET v_CurrentAbcStr = SUBSTRING(v_Remaining, 1, v_CommaPos - 1);
            SET v_Remaining = SUBSTRING(v_Remaining, v_CommaPos + 1);
        ELSE
            SET v_CurrentAbcStr = v_Remaining;
        END IF;

        -- Validate numeric value
        IF v_CurrentAbcStr REGEXP '^[0-9]+$' = 0 THEN
            ROLLBACK;
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x50006002'; -- Invalid course index format
        END IF;

        -- Convert to integer
        SET v_CurrentAbcIdx = CAST(v_CurrentAbcStr AS UNSIGNED);

        -- Update the course: set Reference = NULL and Linked = NULL
        UPDATE `AbetCourses`
        SET `Reference` = NULL,
            `Linked` = NULL
        WHERE `AVCourseIdx` = IN_AvcIdx
            AND `Idx` = v_CurrentAbcIdx;

        -- Track total updated rows
        SET v_UpdatedRows = v_UpdatedRows + ROW_COUNT();

        -- Move to next AbcIdx
        SET v_Position = v_Position + 1;
    END WHILE;

    -- Verify at least one course was updated
    IF v_UpdatedRows = 0 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50006003'; -- No courses were updated
    END IF;

    -- Commit transaction (all or nothing)
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemovePI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemovePI`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;


    IF EXISTS (SELECT 1 FROM `CourseMapping_GPIs` WHERE `GPIIdx` = IN_Idx) THEN
       -- Cannot delete: PI is referenced in ABET Courses
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSE
        DELETE FROM `GeneralPerformanceIndicators` WHERE `Idx` = IN_Idx;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemovePosition` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemovePosition`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `UserAccounts` WHERE `Position` = IN_Idx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSE
        DELETE FROM `Positions` WHERE `Idx` = IN_Idx;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveProgram`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `StudentOutcomes` WHERE `AcademicProgram` = IN_Idx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSEIF EXISTS (SELECT 1 FROM `AccessControls` WHERE `AcademicProgram` = IN_Idx) THEN
       -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSE
        DELETE FROM `AcademicPrograms` WHERE `Idx` = IN_Idx;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveSemesterInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveSemesterInfo`(
    IN p_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if semester exists
    IF NOT EXISTS (SELECT 1 FROM `Semesters` WHERE `Idx` = p_Idx) THEN
        -- Item does not exist
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012';

    -- Check if used in AVCourses table
    ELSEIF EXISTS (SELECT 1 FROM `AVCourses` av
                   INNER JOIN `Semesters` s ON av.`Semester` = s.`SemesterCode`
                   WHERE s.`Idx` = p_Idx) THEN
        -- Cannot delete: the item is used already
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x09000010';

    ELSE
        -- If not in use, delete the semester
        DELETE FROM `Semesters` WHERE `Idx` = p_Idx;
    END IF;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveSO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveSO`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    IF EXISTS (SELECT 1 FROM `CourseMapping_SOs` WHERE `SOIdx` = IN_Idx) THEN
       -- Cannot delete: Student Outcome is referenced in ABET Courses
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000010';

    ELSEIF EXISTS (SELECT 1 FROM `GeneralPerformanceIndicators` WHERE `SOIdx` = IN_Idx) THEN
       -- Cannot delete: Student Outcome is referenced in Performance Indicators
        SIGNAL SQLSTATE '45000'
        SET  MESSAGE_TEXT = '0x09000011';

    ELSE
        DELETE FROM `StudentOutcomes` WHERE `Idx` = IN_Idx;
    END IF;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveStudentFromScoresheet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveStudentFromScoresheet`(
    IN p_AvailableCourseIdx INT,
    IN p_AbetCourseIdx INT,
    IN p_StudentNo INT,
    OUT p_Result VARCHAR(10)
)
BEGIN
    DECLARE v_HasNonNullValues INT DEFAULT 0;
    DECLARE v_UpdateCount INT DEFAULT 0;

    -- Start transaction for atomic operation
    START TRANSACTION;

    -- Check if any record for this student has non-NULL LevelOfAttainment
    -- Student can only be removed if ALL assessment records are NULL
    SELECT COUNT(*) INTO v_HasNonNullValues
    FROM `Scoresheet`
    WHERE `AbetCourseIdx` = p_AbetCourseIdx
      AND `AvailableCourseIdx` = p_AvailableCourseIdx
      AND `StudentNo` = p_StudentNo
      AND `LevelOfAttainment` IS NOT NULL;

    -- If any non-NULL values exist, return error and rollback
    IF v_HasNonNullValues > 0 THEN
        SET p_Result = '0x00000003'; -- Error: Student has assessment data
        ROLLBACK;
    ELSE
        -- Mark student as removed in Scoresheet_Columns
        UPDATE `Scoresheet_Columns`
        SET `IsRemoved` = 1
        WHERE `AbetCourseIdx` = p_AbetCourseIdx
          AND `StudentNo` = p_StudentNo;

        -- Check how many records were updated
        SET v_UpdateCount = ROW_COUNT();

        IF v_UpdateCount > 0 THEN
            SET p_Result = '0x11111111'; -- Success
            COMMIT;
        ELSE
            SET p_Result = '0x00000004'; -- Error: No records found
            ROLLBACK;
        END IF;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveSubject` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveSubject`(
    IN IN_Idx INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    DELETE FROM `Subjects` WHERE `Idx` = IN_Idx;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_RemoveSurveyReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_RemoveSurveyReport`(
    IN IN_AvailableCourseIdx INT
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if the record exists
    IF NOT EXISTS (SELECT 1 FROM `AbetCourses` WHERE `Idx` = IN_AvailableCourseIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- The data not exists
    END IF;

    UPDATE `AVCourses`
    SET `SurveyReport` = NULL
    WHERE `Idx` = IN_AvailableCourseIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ReorderAssessmentMeasuresForLinkedCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ReorderAssessmentMeasuresForLinkedCourses`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT
)
BEGIN
    DECLARE v_Done INT DEFAULT FALSE;
    DECLARE v_LinkedAbetCourseIdx INT;
    DECLARE v_LinkedAvailCourseIdx INT;

    -- Cursor for linked courses
    DECLARE linked_cursor CURSOR FOR
        SELECT DISTINCT
            ac.`Idx` AS AbetCourseIdx,
            ac.`AVCourseIdx`
        FROM `AbetCourses` ac
        WHERE ac.`Linked` = 1
        AND ac.`Reference` = IN_AbetCourseIdx
        AND ac.`AVCourseIdx` != IN_AvailableCourseIdx;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_Done = TRUE;

    -- Open cursor and loop through linked courses
    OPEN linked_cursor;

    read_loop: LOOP
        SET v_Done = FALSE;

        FETCH linked_cursor INTO v_LinkedAbetCourseIdx, v_LinkedAvailCourseIdx;

        IF v_Done THEN
            LEAVE read_loop;
        END IF;

        -- Re-order measures for this linked course
        SET @ordering_inc = 1;
        SET @new_ordering = 0;
        UPDATE `AssessmentMeasures`
        SET `Measure` = (@new_ordering := @new_ordering + @ordering_inc)
        WHERE `AvailableCourseIdx` = v_LinkedAvailCourseIdx
        AND `AbetCourseIdx` = v_LinkedAbetCourseIdx
        ORDER BY `Measure` ASC;

    END LOOP;

    CLOSE linked_cursor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ReorderAssessmentMeasuresForReferenceCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ReorderAssessmentMeasuresForReferenceCourses`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT
)
BEGIN
    -- Update all reference courses to use the same measure numbering by joining to primary course
    UPDATE `AssessmentMeasures` am_ref
    INNER JOIN `AssessmentMeasures` am_primary
        ON am_ref.`AvailableCourseIdx` = am_primary.`AvailableCourseIdx`
        AND am_ref.`AssignmentType` = am_primary.`AssignmentType`
        AND (
            (am_ref.`AssignmentNum` IS NULL AND am_primary.`AssignmentNum` IS NULL)
            OR
            (am_ref.`AssignmentNum` = am_primary.`AssignmentNum`)
        )
        AND am_ref.`AssignmentProblem` = am_primary.`AssignmentProblem`
        AND am_primary.`AbetCourseIdx` = IN_AbetCourseIdx
    SET am_ref.`Measure` = am_primary.`Measure`
    WHERE am_ref.`AvailableCourseIdx` = IN_AvailableCourseIdx
    AND am_ref.`AbetCourseIdx` IN (
        SELECT `Idx`
        FROM `AbetCourses`
        WHERE `AVCourseIdx` = IN_AvailableCourseIdx
        AND `Reference` = IN_AbetCourseIdx
    );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_ReplaceCourseAssessmentMaterials_SSample` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_ReplaceCourseAssessmentMaterials_SSample`(
    IN IN_CourseMaterialsIdx INT
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Update the record to indicate the course binder material has been changed.
    UPDATE `AVCourses` AS `AVCRSES`
    SET `crsbinder_updated` = 1
    WHERE `AVCRSES`.`Idx` = (SELECT `AvailableCourseIdx` FROM `AVCourses_CrsMaterials` WHERE Idx = IN_CourseMaterialsIdx);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_SaveAnalyzedPerformanceIndicators` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_SaveAnalyzedPerformanceIndicators`(
    IN p_AvailableCourseIdx INT,
    IN p_AbetCourseIdx INT,
    IN p_AcademicProgramIdx INT,
    IN p_GPIIdx INT,
    IN p_GPI VARCHAR(20),
    IN p_AVG DECIMAL(5,2),
    IN p_TOTAL INT,
    IN p_TOPFIFTY INT,
    IN p_TOPTWENTYFIVE INT
)
BEGIN
    -- =============================================
    -- Step 1: Delete existing record if it exists
    -- =============================================
    -- This ensures we don't have duplicate records and allows for
    -- fresh analysis data to replace outdated calculations
    DELETE FROM Analyzed_PerformanceIndicators
    WHERE AvailableCourseIdx = p_AvailableCourseIdx
      AND AbetCourseIdx = p_AbetCourseIdx
      AND AcademicProgramIdx = p_AcademicProgramIdx
      AND GPIIdx = p_GPIIdx;

    -- =============================================
    -- Step 2: Insert new analysis record
    -- =============================================
    -- Insert the fresh calculated data for this Performance Indicator
    INSERT INTO Analyzed_PerformanceIndicators
    (AvailableCourseIdx, AbetCourseIdx, AcademicProgramIdx, GPIIdx, GPI,
     AVG, TOTAL, TOPFIFTY, TOPTWENTYFIVE)
    VALUES
    (p_AvailableCourseIdx, p_AbetCourseIdx, p_AcademicProgramIdx, p_GPIIdx, p_GPI,
     p_AVG, p_TOTAL, p_TOPFIFTY, p_TOPTWENTYFIVE);

    -- =============================================
    -- Step 3: Return the number of affected rows
    -- =============================================
    -- Returns 1 if insert was successful, 0 if failed
    SELECT ROW_COUNT() as affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_SaveAnalyzedStudentOutcomes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_SaveAnalyzedStudentOutcomes`(
    IN p_AvailableCourseIdx INT,
    IN p_AbetCourseIdx INT,
    IN p_AcademicProgramIdx INT,
    IN p_SOIdx INT,
    IN p_SO VARCHAR(20),
    IN p_AVG DECIMAL(5,2),
    IN p_TOTAL INT,
    IN p_TOPFIFTY INT,
    IN p_TOPTWENTYFIVE INT
)
BEGIN
    -- =============================================
    -- Step 1: Delete existing record if it exists
    -- =============================================
    -- This ensures we don't have duplicate records and allows for
    -- fresh analysis data to replace outdated calculations
    DELETE FROM Analyzed_StudentOutcomes
    WHERE AvailableCourseIdx = p_AvailableCourseIdx
      AND AbetCourseIdx = p_AbetCourseIdx
      AND AcademicProgramIdx = p_AcademicProgramIdx
      AND SOIdx = p_SOIdx;

    -- =============================================
    -- Step 2: Insert new analysis record
    -- =============================================
    -- Insert the fresh calculated data for this Student Outcome
    INSERT INTO Analyzed_StudentOutcomes
    (AvailableCourseIdx, AbetCourseIdx, AcademicProgramIdx, SOIdx, SO,
     AVG, TOTAL, TOPFIFTY, TOPTWENTYFIVE)
    VALUES
    (p_AvailableCourseIdx, p_AbetCourseIdx, p_AcademicProgramIdx, p_SOIdx, p_SO,
     p_AVG, p_TOTAL, p_TOPFIFTY, p_TOPTWENTYFIVE);

    -- =============================================
    -- Step 3: Return the number of affected rows
    -- =============================================
    -- Returns 1 if insert was successful, 0 if failed
    SELECT ROW_COUNT() as affected_rows;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAbetCourseLevel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAbetCourseLevel`(IN IN_AbetCourseIdx INT, IN IN_Level INT,
    IN IN_AcademicYear INT, IN IN_AcademicProgram INT )
BEGIN
	START TRANSACTION;

    UPDATE `AbetCourses` SET `Level`=IN_Level WHERE `Idx`=IN_AbetCourseIdx AND `AcademicYear`=IN_AcademicYear AND `AcademicProgram`=IN_AcademicProgram;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAbetCourse_Requirement` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAbetCourse_Requirement`(
    IN IN_AbetCourseIdx INT,
    IN IN_Requirement VARCHAR(255),
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN
	START TRANSACTION;

    UPDATE `AbetCourses` SET `Requirement`=IN_Requirement
                                   WHERE `Idx`=IN_AbetCourseIdx
                                     AND `AcademicYear`=IN_AcademicYear
                                     AND `AcademicProgram`=IN_AcademicProgram;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAbetCourse_Syllabus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAbetCourse_Syllabus`(
    IN IN_AcademicYear INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgram INT,
    IN IN_CourseNum VARCHAR(10)
)
BEGIN
    DECLARE v_Degree VARCHAR(255);
    DECLARE v_AcademicYear VARCHAR(255);
    DECLARE v_AbetSyllabus VARCHAR(255);

    START TRANSACTION;

    IF EXISTS (
        SELECT 1 FROM `AbetCourses`
        WHERE `AcademicYear` = IN_AcademicYear
        AND `Idx` = IN_AbetCourseIdx
        AND `AcademicProgram` = IN_AcademicProgram
    ) THEN
    BEGIN

        -- Fetch required information
        SELECT LOWER(`Degree`) INTO v_Degree
        FROM `AcademicPrograms`
        WHERE `Idx` = IN_AcademicProgram;

        SELECT `AcademicYear` INTO v_AcademicYear
        FROM `AcademicYears`
        WHERE `Idx` = IN_AcademicYear;

        -- Create abet syllabus file name
        SET v_AbetSyllabus = CONCAT('abet_syllabus_', v_AcademicYear, '_', v_Degree, '_', IN_CourseNum, '.pdf');

        -- Update Syllabus PDF information
        UPDATE `AbetCourses`
        SET `Syllabus` = v_AbetSyllabus, `SyllabusLastUpdated`=CURDATE()
        WHERE `Idx` = IN_AbetCourseIdx;

        -- Return necessary information for creating ABET file
        SELECT v_AcademicYear AS `AcademicYear`, v_AbetSyllabus AS `AbetSyllabus`;

    END;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAbetSurvey` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAbetSurvey`(
    IN IN_Idx INT,
    IN IN_Subject VARCHAR(5),
    IN IN_Num INT,
    IN IN_CRN INT,
    IN IN_Survey TEXT
)
BEGIN
    DECLARE v_affected_rows INT DEFAULT 0;

    START TRANSACTION;

    -- Update the Survey field for the specified ABET course
    -- Set Survey to NULL if IN_Survey is empty or NULL
    UPDATE `AVCourses`
    SET `Survey` = IF(IN_Survey = '' OR IN_Survey IS NULL, NULL, IN_Survey)
    WHERE `Idx` = IN_Idx
      AND `Subject` = IN_Subject
      AND `Num` = IN_Num
      AND `CRN` = IN_CRN;

    -- Get the number of affected rows
    SET v_affected_rows = ROW_COUNT();

    -- Return success indicator
    SELECT v_affected_rows AS `affected_rows`;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAbetSyllabusApproval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAbetSyllabusApproval`(
    IN IN_ABSIdx    INT,
    IN IN_Field     VARCHAR(50),
    IN IN_Value     VARCHAR(500)
)
BEGIN
    DECLARE v_affected_rows INT DEFAULT 0;

    START TRANSACTION;

    -- Update ApprovalDesc
    IF IN_Field = 'ApprovalDesc' THEN
        UPDATE `AbetSyllabus`
        SET `ApprovalDesc` = IF(IN_Value = '' OR IN_Value IS NULL, NULL, IN_Value)
        WHERE `Idx` = IN_ABSIdx;

    -- Update ApprovalDate
    ELSEIF IN_Field = 'ApprovalDate' THEN
        UPDATE `AbetSyllabus`
        SET `ApprovalDate` = IF(IN_Value = '' OR IN_Value IS NULL, NULL, STR_TO_DATE(IN_Value, '%Y-%m-%d'))
        WHERE `Idx` = IN_ABSIdx;

    -- Update Coordinator
    ELSEIF IN_Field = 'Coordinator' THEN
        UPDATE `AbetSyllabus`
        SET `Coordinator` = IF(IN_Value = '' OR IN_Value IS NULL, NULL, IN_Value)
        WHERE `Idx` = IN_ABSIdx;

    END IF;

    -- Get the number of affected rows
    SET v_affected_rows = ROW_COUNT();

    -- Return success indicator
    SELECT v_affected_rows AS `affected_rows`;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAbetSyllabusVersion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAbetSyllabusVersion`(
    IN p_SyllabusIndex INT,
    IN p_MajorVersion INT,
    IN p_MinorVersion INT
)
BEGIN
    DECLARE v_error_count INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        -- Rollback the transaction on error
        ROLLBACK;
        -- Return error indicator
        SELECT '0x00000000' AS result;
    END;

    -- Start transaction
    START TRANSACTION;

    -- Update the main syllabus record
    UPDATE `AbetSyllabus`
    SET `major_version` = p_MajorVersion,
        `minor_version` = p_MinorVersion
    WHERE `Idx` = p_SyllabusIndex;

    -- Check if the update was successful
    IF ROW_COUNT() = 0 THEN
        -- No rows updated, syllabus not found
        ROLLBACK;
        SELECT '0x99999995' AS result; -- Syllabus not found
    ELSE
        -- Update all syllabi that reference this one (LinkedSyllabus points to this syllabus)
        UPDATE `AbetSyllabus`
        SET `major_version` = p_MajorVersion,
            `minor_version` = p_MinorVersion
        WHERE `LinkedSyllabus` = p_SyllabusIndex;

        -- Commit the transaction
        COMMIT;
        
        -- Return success with count of updated records
        SELECT '0x11111111' AS result, 
               (1 + ROW_COUNT()) AS updated_count; -- Main record + linked records
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAbetSyllabus_ApprovalInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAbetSyllabus_ApprovalInfo`(
    IN courses VARCHAR(1000),
    IN approvalInfo VARCHAR(500),
    IN approvalDate DATE
)
BEGIN
    DECLARE course_id INT;
    DECLARE pos INT DEFAULT 1;
    DECLARE course_str VARCHAR(1000);

    SET course_str = CONCAT(courses, '|');

    START TRANSACTION;

    WHILE pos > 0 DO
        SET course_id = CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(course_str, '|', 1), '|', -1) AS UNSIGNED);

        IF course_id > 0 THEN
            UPDATE AbetSyllabus
            SET ApprovalDesc = approvalInfo,
                ApprovalDate = approvalDate
            WHERE Idx = course_id
            AND (ApprovalDesc IS NULL OR ApprovalDesc = '');
        END IF;

        SET course_str = SUBSTRING(course_str, LOCATE('|', course_str) + 1);
        SET pos = LOCATE('|', course_str);
    END WHILE;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAffiliation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAffiliation`(
    IN IN_Idx INT,
    IN IN_Name VARCHAR(200)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `Affiliations` WHERE `Name` = IN_Name AND `Idx`!=IN_Idx) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already
    END IF;

    UPDATE `Affiliations` SET `Name`=IN_Name WHERE `Idx`=IN_Idx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAssessmentMeasure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAssessmentMeasure`(
    IN IN_AssessmentMeasureIdx INT,
    IN IN_PI INT,
    IN IN_AssignmentType VARCHAR(256),
    IN IN_AssignmentNum INT,
    IN IN_AssignmentProblem VARCHAR(1024),
    IN IN_AssignmentDescription TEXT,
    IN IN_ActualAssmntSample VARCHAR(256)
)
BEGIN
    -- Declare variables
    DECLARE IN_AvailableCourseIdx INT;
    DECLARE IN_AbetCourseIdx INT;
    DECLARE IN_Measure INT;
    DECLARE v_IsLinked INT DEFAULT 0;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Validate input
    IF NOT EXISTS (SELECT 1 FROM `AssessmentMeasures` WHERE `Idx` = IN_AssessmentMeasureIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x80001020'; -- Assessment measure not found
    END IF;

    -- Fetch available course index, abet course index, and measure number
    SELECT `AvailableCourseIdx`, `AbetCourseIdx`, `Measure`
    INTO IN_AvailableCourseIdx, IN_AbetCourseIdx, IN_Measure
    FROM `AssessmentMeasures`
    WHERE `Idx` = IN_AssessmentMeasureIdx;

    -- Check if this course is part of a linked group
    SELECT IFNULL(`Linked`, 0) INTO v_IsLinked
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdx;

    -- Update assessment measure in primary course
    UPDATE `AssessmentMeasures`
    SET
        `GPI` = IN_PI,
        `AssignmentProblem` = IN_AssignmentProblem,
        `AssignmentDescription` = IN_AssignmentDescription,
        `ActualAssmntSample` = IN_ActualAssmntSample
    WHERE `Idx` = IN_AssessmentMeasureIdx;

    -- Update actual assessment sample to other measures in primary course with same assignment type/num
    UPDATE `AssessmentMeasures`
    SET `ActualAssmntSample` = IN_ActualAssmntSample
    WHERE `AssignmentType` = IN_AssignmentType
    AND `AvailableCourseIdx` = IN_AvailableCourseIdx
    AND `AbetCourseIdx` = IN_AbetCourseIdx
    AND (
        (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
        OR
        (`AssignmentNum` = IN_AssignmentNum)
    );

    -- Replicate updates to related courses based on course type
    IF v_IsLinked = 1 THEN
        -- This is a linked course with different available courses
        CALL SP_UpdateAssessmentMeasureForLinkedCourses(
            IN_PI, IN_Measure, IN_AssignmentType, IN_AssignmentNum,
            IN_AssignmentProblem, IN_AssignmentDescription,
            IN_AvailableCourseIdx, IN_AbetCourseIdx, IN_ActualAssmntSample
        );
    ELSE
        -- This is a regular reference course with same available course
        CALL SP_UpdateAssessmentMeasureForReferenceCourses(
            IN_PI, IN_Measure, IN_AssignmentType, IN_AssignmentNum,
            IN_AssignmentProblem, IN_AssignmentDescription,
            IN_AvailableCourseIdx, IN_AbetCourseIdx, IN_ActualAssmntSample
        );
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAssessmentMeasureForLinkedCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAssessmentMeasureForLinkedCourses`(
    IN IN_PI INT,
    IN IN_Measure INT,
    IN IN_AssignmentType VARCHAR(256),
    IN IN_AssignmentNum INT,
    IN IN_AssignmentProblem VARCHAR(1024),
    IN IN_AssignmentDescription TEXT,
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_ActualAssmntSample VARCHAR(256)
)
BEGIN
    DECLARE v_Done INT DEFAULT FALSE;
    DECLARE v_LinkedAbetCourseIdx INT;
    DECLARE v_LinkedAvailCourseIdx INT;
    DECLARE v_LinkedAcademicProgramIdx INT;
    DECLARE v_LinkedGPIIdx INT;
    DECLARE v_BaseSO VARCHAR(50);
    DECLARE v_BaseGPI VARCHAR(50);
    DECLARE v_PrimaryAcademicProgramIdx INT;
    DECLARE v_ErrorMessage VARCHAR(512);

    -- Cursor for linked courses
    DECLARE linked_cursor CURSOR FOR
        SELECT DISTINCT
            ac.`Idx` AS AbetCourseIdx,
            ac.`AVCourseIdx`,
            ac.`AcademicProgram`
        FROM `AbetCourses` ac
        WHERE ac.`Linked` = 1
        AND ac.`Reference` = IN_AbetCourseIdx;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_Done = TRUE;

    -- Get the primary course's academic program
    SELECT `AcademicProgram` INTO v_PrimaryAcademicProgramIdx
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdx;

    -- Get the SO and GPI from the primary course
    SELECT so.SO, gpi.GPI
    INTO v_BaseSO, v_BaseGPI
    FROM `GeneralPerformanceIndicators` gpi
    INNER JOIN `StudentOutcomes` so ON gpi.SOIdx = so.Idx
    WHERE gpi.Idx = IN_PI
    AND gpi.AcademicProgram = v_PrimaryAcademicProgramIdx;

    -- Open cursor and loop through linked courses
    OPEN linked_cursor;

    read_loop: LOOP
        SET v_Done = FALSE;

        FETCH linked_cursor INTO v_LinkedAbetCourseIdx, v_LinkedAvailCourseIdx, v_LinkedAcademicProgramIdx;

        IF v_Done THEN
            LEAVE read_loop;
        END IF;

        -- Find the matched GPI for the linked course
        SET v_LinkedGPIIdx = NULL;

        SELECT gpi_linked.Idx INTO v_LinkedGPIIdx
        FROM `AbetCourses_GPIs` ac_gpi_linked
        INNER JOIN `GeneralPerformanceIndicators` gpi_linked ON ac_gpi_linked.GPIIdx = gpi_linked.Idx
        INNER JOIN `StudentOutcomes` so_linked ON gpi_linked.SOIdx = so_linked.Idx
        WHERE ac_gpi_linked.AbetCourseIdx = v_LinkedAbetCourseIdx
        AND ac_gpi_linked.AcademicProgram = v_LinkedAcademicProgramIdx
        AND so_linked.SO = v_BaseSO
        AND gpi_linked.GPI = v_BaseGPI
        AND so_linked.AcademicProgram = v_LinkedAcademicProgramIdx
        AND gpi_linked.AcademicProgram = v_LinkedAcademicProgramIdx
        LIMIT 1;

        -- Error if no matching GPI found
        IF v_LinkedGPIIdx IS NULL THEN
            SET v_ErrorMessage = CONCAT(
                'No matching GPI for linked course update: LinkedCourse=', v_LinkedAbetCourseIdx,
                ', SO=', v_BaseSO,
                ', GPI=', v_BaseGPI,
                ', Program=', v_LinkedAcademicProgramIdx
            );

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = v_ErrorMessage;
        END IF;

        -- Update assessment measure for this linked course
        UPDATE `AssessmentMeasures`
        SET
            `GPI` = v_LinkedGPIIdx,
            `AssignmentProblem` = IN_AssignmentProblem,
            `AssignmentDescription` = IN_AssignmentDescription,
            `ActualAssmntSample` = IN_ActualAssmntSample
        WHERE `AvailableCourseIdx` = v_LinkedAvailCourseIdx
        AND `AbetCourseIdx` = v_LinkedAbetCourseIdx
        AND `AssignmentType` = IN_AssignmentType
        AND (
            (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
            OR
            (`AssignmentNum` = IN_AssignmentNum)
        )
        AND `Measure` = IN_Measure;

        -- Update actual assessment sample to other measures in this linked course
        UPDATE `AssessmentMeasures`
        SET `ActualAssmntSample` = IN_ActualAssmntSample
        WHERE `AssignmentType` = IN_AssignmentType
        AND `AvailableCourseIdx` = v_LinkedAvailCourseIdx
        AND `AbetCourseIdx` = v_LinkedAbetCourseIdx
        AND (
            (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
            OR
            (`AssignmentNum` = IN_AssignmentNum)
        );

    END LOOP;

    CLOSE linked_cursor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAssessmentMeasureForReferenceCourses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAssessmentMeasureForReferenceCourses`(
    IN IN_PI INT,
    IN IN_Measure INT,
    IN IN_AssignmentType VARCHAR(256),
    IN IN_AssignmentNum INT,
    IN IN_AssignmentProblem VARCHAR(1024),
    IN IN_AssignmentDescription TEXT,
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_ActualAssmntSample VARCHAR(256)
)
BEGIN
    DECLARE v_Done INT DEFAULT FALSE;
    DECLARE v_RefAbetCourseIdx INT;
    DECLARE v_RefAvailCourseIdx INT;
    DECLARE v_RefAcademicProgramIdx INT;
    DECLARE v_RefGPIIdx INT;
    DECLARE v_BaseSO VARCHAR(50);
    DECLARE v_BaseGPI VARCHAR(50);
    DECLARE v_ErrorMessage VARCHAR(512);

    -- Cursor for reference courses (no filtering by AVCourseIdx)
    DECLARE ref_cursor CURSOR FOR
        SELECT DISTINCT
            ac.`Idx` AS AbetCourseIdx,
            ac.`AVCourseIdx`,
            ac.`AcademicProgram`
        FROM `AbetCourses` ac
        WHERE ac.`Reference` = IN_AbetCourseIdx
        AND ac.`Idx` != IN_AbetCourseIdx;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_Done = TRUE;

    -- Get the SO and GPI text from the input GPI (no filtering by AcademicProgram)
    SELECT so.SO, gpi.GPI
    INTO v_BaseSO, v_BaseGPI
    FROM `GeneralPerformanceIndicators` gpi
    INNER JOIN `StudentOutcomes` so ON gpi.SOIdx = so.Idx
    WHERE gpi.Idx = IN_PI;

    -- Open cursor and loop through reference courses
    OPEN ref_cursor;

    read_loop: LOOP
        SET v_Done = FALSE;

        FETCH ref_cursor INTO v_RefAbetCourseIdx, v_RefAvailCourseIdx, v_RefAcademicProgramIdx;

        IF v_Done THEN
            LEAVE read_loop;
        END IF;

        -- Find the matched GPI for the reference course in its own academic program
        SET v_RefGPIIdx = NULL;

        SELECT gpi_ref.Idx INTO v_RefGPIIdx
        FROM `AbetCourses_GPIs` ac_gpi_ref
        INNER JOIN `GeneralPerformanceIndicators` gpi_ref ON ac_gpi_ref.GPIIdx = gpi_ref.Idx
        INNER JOIN `StudentOutcomes` so_ref ON gpi_ref.SOIdx = so_ref.Idx
        WHERE ac_gpi_ref.AbetCourseIdx = v_RefAbetCourseIdx
        AND ac_gpi_ref.AcademicProgram = v_RefAcademicProgramIdx
        AND so_ref.SO = v_BaseSO
        AND gpi_ref.GPI = v_BaseGPI
        AND so_ref.AcademicProgram = v_RefAcademicProgramIdx
        AND gpi_ref.AcademicProgram = v_RefAcademicProgramIdx
        LIMIT 1;

        -- Error if no matching GPI found
        IF v_RefGPIIdx IS NULL THEN
            SET v_ErrorMessage = CONCAT(
                'No matching GPI for reference course update: RefCourse=', v_RefAbetCourseIdx,
                ', SO=', v_BaseSO,
                ', GPI=', v_BaseGPI,
                ', Program=', v_RefAcademicProgramIdx
            );

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = v_ErrorMessage;
        END IF;

        -- Update assessment measure for this reference course
        UPDATE `AssessmentMeasures`
        SET
            `GPI` = v_RefGPIIdx,
            `AssignmentProblem` = IN_AssignmentProblem,
            `AssignmentDescription` = IN_AssignmentDescription,
            `ActualAssmntSample` = IN_ActualAssmntSample
        WHERE `AvailableCourseIdx` = v_RefAvailCourseIdx
        AND `AbetCourseIdx` = v_RefAbetCourseIdx
        AND `AssignmentType` = IN_AssignmentType
        AND (
            (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
            OR
            (`AssignmentNum` = IN_AssignmentNum)
        )
        AND `Measure` = IN_Measure;

        -- Update actual assessment sample to other measures in this reference course
        UPDATE `AssessmentMeasures`
        SET `ActualAssmntSample` = IN_ActualAssmntSample
        WHERE `AssignmentType` = IN_AssignmentType
        AND `AvailableCourseIdx` = v_RefAvailCourseIdx
        AND `AbetCourseIdx` = v_RefAbetCourseIdx
        AND (
            (IN_AssignmentNum IS NULL AND `AssignmentNum` IS NULL)
            OR
            (`AssignmentNum` = IN_AssignmentNum)
        );

    END LOOP;

    CLOSE ref_cursor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAvailableCourse_CollectMaterials` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAvailableCourse_CollectMaterials`(
    IN IN_AvailableCourseIdx INT,
    IN IN_Indicator INT
)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if data exists
    IF NOT EXISTS (
        SELECT 1 FROM `AVCourses`
        WHERE `Idx` = IN_AvailableCourseIdx
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00300011'; -- Abet course info not found
    END IF;

    -- Check if Course Materials exists
    IF IN_Indicator = 0 THEN
       IF EXISTS (SELECT 1 FROM `AVCourses_CrsMaterials`
                        WHERE `AvailableCourseIdx`=IN_AvailableCourseIdx) THEN
            SIGNAL SQLSTATE '45000'
            SET  MESSAGE_TEXT = '0x09500012'; -- data exists
       END IF;
       IF EXISTS (SELECT 1 FROM `AVCourses_InstMaterials`
                        WHERE `AvailableCourseIdx`=IN_AvailableCourseIdx) THEN
            SIGNAL SQLSTATE '45000'
            SET  MESSAGE_TEXT = '0x09500012'; -- data exists
        END IF;
    END IF;

    UPDATE `AVCourses`
    SET `CollectMaterials` = IN_Indicator
    WHERE `Idx` = IN_AvailableCourseIdx;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAVCourseManual` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAVCourseManual`(
    IN IN_AVCourseIdx INT
)
BEGIN
    UPDATE `AVCourses`
    SET 
        `IsManuallyEdited` = 1  -- Mark as manually edited to protect from automated updates
    WHERE `Idx` = IN_AVCourseIdx;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAVCourseSyllabus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAVCourseSyllabus`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_SyllabusFileName VARCHAR(256)
)
BEGIN
    DECLARE v_AVCourseExists INT DEFAULT 0;
    DECLARE v_AbetCourseExists INT DEFAULT 0;
    DECLARE v_IsLinked INT DEFAULT 0;
    DECLARE v_ReferenceIdx INT DEFAULT NULL;
    DECLARE v_PrimaryAbetCourseIdx INT DEFAULT NULL;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Validate that Available course exists
    SELECT COUNT(*) INTO v_AVCourseExists
    FROM `AVCourses`
    WHERE `Idx` = IN_AvailableCourseIdx;

    IF v_AVCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- Available course does not exist
    END IF;

    -- Validate that ABET course exists and get its Linked and Reference status
    SELECT COUNT(*), MAX(`Linked`), MAX(`Reference`)
    INTO v_AbetCourseExists, v_IsLinked, v_ReferenceIdx
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdx;

    IF v_AbetCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200013'; -- ABET course does not exist
    END IF;

    -- Update the specified Available course
    UPDATE `AVCourses`
    SET `Syllabus` = IN_SyllabusFileName,
        `crsbinder_updated` = 1
    WHERE `Idx` = IN_AvailableCourseIdx;

    -- Check if this is part of a linked course group
    IF v_IsLinked = 1 THEN
        -- Determine the Primary ABET course index
        IF v_ReferenceIdx IS NULL THEN
            -- This is the Primary course
            SET v_PrimaryAbetCourseIdx = IN_AbetCourseIdx;
        ELSE
            -- This is a Reference course, use its Reference value as Primary
            SET v_PrimaryAbetCourseIdx = v_ReferenceIdx;

            -- Update the Primary course's Available course
            UPDATE `AVCourses` AS AVC
            INNER JOIN `AbetCourses` AS ABC ON AVC.`Idx` = ABC.`AVCourseIdx`
            SET AVC.`Syllabus` = IN_SyllabusFileName,
                AVC.`crsbinder_updated` = 1
            WHERE ABC.`Idx` = v_PrimaryAbetCourseIdx;
        END IF;

        -- Update all Reference courses' Available courses in the linked group
        UPDATE `AVCourses` AS AVC
        INNER JOIN `AbetCourses` AS ABC ON AVC.`Idx` = ABC.`AVCourseIdx`
        SET AVC.`Syllabus` = IN_SyllabusFileName,
            AVC.`crsbinder_updated` = 1
        WHERE ABC.`Reference` = v_PrimaryAbetCourseIdx
          AND ABC.`Linked` = 1
          AND AVC.`Idx` != IN_AvailableCourseIdx; -- Avoid updating the same course twice
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateAVCourseSyllabusInfo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateAVCourseSyllabusInfo`(
    IN IN_AvailableCourseIdx INT,
    IN IN_SyllabusFileName VARCHAR(256)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if the record exists
    IF NOT EXISTS (SELECT 1 FROM `AVCourses` WHERE `Idx` = IN_AvailableCourseIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- The data not exists
    END IF;

    UPDATE `AVCourses`
    SET `Syllabus` = IN_SyllabusFileName,
        `crsbinder_updated` = 1
    WHERE `Idx` = IN_AvailableCourseIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateColumnInScoresheet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateColumnInScoresheet`(
    IN IN_StudentNo INT,
    IN IN_CustomColumnInfo VARCHAR(256),
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AcademicProgramIdx INT)
BEGIN

    -- Error handling: rollback transaction on any SQL exception
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if record exists for this student and course combination
    IF EXISTS (SELECT 1 FROM `Scoresheet_Columns`
       WHERE `StudentNo` = IN_StudentNo
       AND `AcademicProgramIdx` = IN_AcademicProgramIdx
       AND `AvailableCourseIdx` = IN_AvailableCourseIdx
       AND `AbetCourseIdx` = IN_AbetCourseIdx) THEN

        -- Update existing record with encrypted column info
        UPDATE `Scoresheet_Columns`
        SET `CustomColumnInfo` = AES_ENCRYPT(IN_CustomColumnInfo, 'ABET Course Assessment System')
        WHERE `StudentNo` = IN_StudentNo
          AND `AcademicProgramIdx` = IN_AcademicProgramIdx
          AND `AvailableCourseIdx` = IN_AvailableCourseIdx
          AND `AbetCourseIdx` = IN_AbetCourseIdx;

    ELSE
        -- Insert new record with encrypted column info
        INSERT INTO `Scoresheet_Columns`(
            `AvailableCourseIdx`,
            `AbetCourseIdx`,
            `StudentNo`,
            `CustomColumnInfo`,
            `AcademicProgramIdx`
        )
        VALUES (
            IN_AvailableCourseIdx,
            IN_AbetCourseIdx,
            IN_StudentNo,
            AES_ENCRYPT(IN_CustomColumnInfo, 'ABET Course Assessment System'),
            IN_AcademicProgramIdx
        );
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateCourse` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateCourse`(
    IN IN_Idx INT,
    IN IN_Subject VARCHAR(5),
    IN IN_Num VARCHAR(5),
    IN IN_Title VARCHAR(200),
    IN IN_TitleUniv VARCHAR(200),
    IN IN_Credits VARCHAR(20)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `Courses` WHERE `Subject`=IN_Subject AND `Num`=IN_Num AND `Title`=IN_Title AND `TitleUniv`=IN_TitleUniv AND `Idx`!=IN_Idx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already

    END IF;

    UPDATE `Courses`
        SET `Subject`=IN_Subject, `Num`=IN_Num, `Title`=IN_Title, `TitleUniv`=IN_TitleUniv, `Credits`=IN_Credits
        WHERE `Idx`=IN_Idx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateCourseAssessmentMaterials_SSample` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateCourseAssessmentMaterials_SSample`(
    IN IN_CourseMaterialsIdx INT,
    IN IN_StudentSampleNum INT,
    IN IN_StudentSample VARCHAR(256)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Validate IN_StudentSampleNum
    IF IN_StudentSampleNum NOT IN (1, 2, 3) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'StudentSampleNum must be 1, 2, or 3';
    END IF;

    START TRANSACTION;

    IF IN_StudentSampleNum = 1 THEN
        UPDATE `AVCourses_CrsMaterials`
            SET `StudentSample1`=IN_StudentSample
            WHERE `Idx`= IN_CourseMaterialsIdx;
    ELSEIF IN_StudentSampleNum = 2 THEN
        UPDATE `AVCourses_CrsMaterials`
            SET `StudentSample2`=IN_StudentSample
            WHERE `Idx`= IN_CourseMaterialsIdx;
    ELSE
        UPDATE `AVCourses_CrsMaterials`
            SET `StudentSample3`=IN_StudentSample
            WHERE `Idx`= IN_CourseMaterialsIdx;
    END IF;

    -- Update the record to indicate the course binder material has been changed.
    UPDATE `AVCourses` AS `AVCRSES`
    SET `crsbinder_updated` = 1
    WHERE `AVCRSES`.`Idx` = (SELECT `AvailableCourseIdx` FROM `AVCourses_CrsMaterials` WHERE Idx = IN_CourseMaterialsIdx);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateCourseBinderCreation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateCourseBinderCreation`(
    IN IN_AvailableCourseIdx INT
)
BEGIN
    DECLARE record_exists INT;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    -- Check if record exists
    SELECT COUNT(*) INTO record_exists
    FROM `AVCourses`
    WHERE `Idx` = IN_AvailableCourseIdx;

    IF record_exists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Course record not found';
    END IF;

    START TRANSACTION;

    -- Update the record to indicate the course binder has been created
    UPDATE `AVCourses`
    SET `crsbinder_updated` = 0
    WHERE `Idx` = IN_AvailableCourseIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateCourseMapping_Levels` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateCourseMapping_Levels`(IN IN_AbetCourseIdx INT, IN IN_Level INT,
    IN IN_AcademicYear INT, IN IN_AcademicProgram INT )
BEGIN
	START TRANSACTION;

    UPDATE `CourseMapping_Courses` SET `Level`=IN_Level
                                   WHERE `Idx`=IN_AbetCourseIdx
                                     AND `AcademicYear`=IN_AcademicYear
                                     AND `AcademicProgram`=IN_AcademicProgram;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateCourseMapping_MasterSyllabus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateCourseMapping_MasterSyllabus`(
    IN IN_CourseMappingCourseIdx INT,
    IN IN_AbetSyllabusIdx INT
)
BEGIN
    START TRANSACTION;

    IF EXISTS (
        SELECT 1 FROM `AbetSyllabus`
        WHERE `Idx` = IN_AbetSyllabusIdx
    ) THEN
    BEGIN
        -- Update Syllabus information
        UPDATE `CourseMapping_Courses`
        SET `AbetSyllabus` = IN_AbetSyllabusIdx
        WHERE `Idx` = IN_CourseMappingCourseIdx;

    END;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateCourseMapping_Requirement` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateCourseMapping_Requirement`(
    IN IN_AbetCourseIdx INT,
    IN IN_Requirement VARCHAR(255),
    IN IN_AcademicYear INT,
    IN IN_AcademicProgram INT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    UPDATE `CourseMapping_Courses`
    SET `Requirement` = IN_Requirement
    WHERE `Idx` = IN_AbetCourseIdx
      AND `AcademicYear` = IN_AcademicYear
      AND `AcademicProgram` = IN_AcademicProgram;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateCourseReference` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateCourseReference`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AbetCourseIdxPrimary INT,
    IN IN_ReferenceValue TINYINT
)
BEGIN
    DECLARE v_CourseExists INT;
    DECLARE v_PrimaryCourseExists INT;

    -- Start transaction for atomic operation
    START TRANSACTION;

    -- Validate available course index parameter
    IF IN_AvailableCourseIdx IS NULL OR IN_AvailableCourseIdx < 1 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50002001'; -- Invalid available course index
    END IF;

    -- Validate ABET course index parameter
    IF IN_AbetCourseIdx IS NULL OR IN_AbetCourseIdx < 1 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50002002'; -- Invalid ABET course index
    END IF;

    -- Validate reference value parameter (must be 0 or 1)
    IF IN_ReferenceValue IS NULL OR (IN_ReferenceValue != 0 AND IN_ReferenceValue != 1) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50002003'; -- Invalid reference value
    END IF;

    -- Verify that the ABET course exists
    SELECT COUNT(*)
    INTO v_CourseExists
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdx;

    IF v_CourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50002004'; -- ABET course does not exist
    END IF;

    -- If setting to Reference (1), perform additional validations
    IF IN_ReferenceValue = 1 THEN
        -- Validate that IN_AbetCourseIdxPrimary is provided
        IF IN_AbetCourseIdxPrimary IS NULL OR IN_AbetCourseIdxPrimary < 1 THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x50002006'; -- Invalid primary course index
        END IF;

        -- Prevent a course from referencing itself
        IF IN_AbetCourseIdx = IN_AbetCourseIdxPrimary THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x50002009'; -- Cannot reference itself
        END IF;

        -- Verify that the primary course exists and is for the same available course
        SELECT COUNT(*)
        INTO v_PrimaryCourseExists
        FROM `AbetCourses`
        WHERE `Idx` = IN_AbetCourseIdxPrimary
          AND `AVCourseIdx` = IN_AvailableCourseIdx;

        IF v_PrimaryCourseExists = 0 THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x50002007'; -- Primary course does not exist or is for different available course
        END IF;

        -- Update the reference status to Reference
        UPDATE `AbetCourses`
        SET `Reference` = IN_AbetCourseIdxPrimary
        WHERE `Idx` = IN_AbetCourseIdx;

        -- AUTO-UPDATE: Update any courses that were referencing this course to point to the new primary
        -- This prevents reference chains (A→B→C becomes A→C, B→C)
        UPDATE `AbetCourses`
        SET `Reference` = IN_AbetCourseIdxPrimary
        WHERE `Reference` = IN_AbetCourseIdx
          AND `Idx` != IN_AbetCourseIdx; -- Extra safety check

    ELSE
        -- Update the reference status to Primary (NULL represents Primary)
        UPDATE `AbetCourses`
        SET `Reference` = NULL
        WHERE `Idx` = IN_AbetCourseIdx;
    END IF;

    -- Commit transaction
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateCourseReference_DuplicateAssessmentMeasures` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateCourseReference_DuplicateAssessmentMeasures`(
    IN IN_AvailableCourseIdx INT,
    IN IN_AbetCourseIdxReference INT,
    IN IN_AbetCourseIdxPrimary INT
)
BEGIN
    DECLARE v_ReferenceCourseExists INT;
    DECLARE v_PrimaryCourseExists INT;
    DECLARE v_ExistingMeasures INT;
    DECLARE v_PrimaryMeasures INT;
    DECLARE v_ReferenceAcademicYear INT;
    DECLARE v_ReferenceAcademicProgram INT;
    DECLARE v_NumStudents INT;

    -- Start transaction for atomic operation
    START TRANSACTION;

    -- Validate available course index parameter
    IF IN_AvailableCourseIdx IS NULL OR IN_AvailableCourseIdx < 1 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50003001'; -- Invalid available course index
    END IF;

    -- Validate Reference ABET course index parameter
    IF IN_AbetCourseIdxReference IS NULL OR IN_AbetCourseIdxReference < 1 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50003002'; -- Invalid Reference ABET course index
    END IF;

    -- Validate Primary ABET course index parameter
    IF IN_AbetCourseIdxPrimary IS NULL OR IN_AbetCourseIdxPrimary < 1 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50003003'; -- Invalid Primary ABET course index
    END IF;

    -- Verify that the Reference ABET course exists and get its academic context
    SELECT COUNT(*), MAX(`AcademicYear`), MAX(`AcademicProgram`)
    INTO v_ReferenceCourseExists, v_ReferenceAcademicYear, v_ReferenceAcademicProgram
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdxReference;

    IF v_ReferenceCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50003004'; -- Reference ABET course does not exist
    END IF;

    -- Verify that the Primary ABET course exists
    SELECT COUNT(*)
    INTO v_PrimaryCourseExists
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdxPrimary;

    IF v_PrimaryCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50003005'; -- Primary ABET course does not exist
    END IF;

    -- Check if Reference course already has assessment measures
    SELECT COUNT(*)
    INTO v_ExistingMeasures
    FROM `AssessmentMeasures`
    WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
      AND `AbetCourseIdx` = IN_AbetCourseIdxReference;

    IF v_ExistingMeasures > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50003006'; -- Assessment measures already exist for Reference course
    END IF;

    -- Check if Primary course has assessment measures to duplicate
    SELECT COUNT(*)
    INTO v_PrimaryMeasures
    FROM `AssessmentMeasures`
    WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
      AND `AbetCourseIdx` = IN_AbetCourseIdxPrimary;

    -- If no assessment measures exist in Primary course, complete successfully without duplication
    IF v_PrimaryMeasures = 0 THEN
        COMMIT;
        -- Exit procedure - no duplication needed
    ELSE
        -- Primary course has assessment measures, proceed with duplication

        -- Get NumStudents from Primary course's ContinuousImprovement record
        SELECT COALESCE(`NumStudents`, 0)
        INTO v_NumStudents
        FROM `ContinuousImprovement`
        WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
          AND `AbetCourseIdx` = IN_AbetCourseIdxPrimary
        LIMIT 1;

        -- Duplicate assessment measures from Primary to Reference course
        -- Map GPIs from Primary course to corresponding GPIs in Reference course
        INSERT INTO `AssessmentMeasures` (
            `GPI`,
            `Measure`,
            `AssignmentType`,
            `AssignmentNum`,
            `AssignmentProblem`,
            `AssignmentDescription`,
            `AvailableCourseIdx`,
            `AbetCourseIdx`,
            `ActualAssmntSample`
        )
        SELECT
            `RefGPI`.`Idx` AS `GPI`,  -- Use mapped GPI from Reference course
            `AM`.`Measure`,
            `AM`.`AssignmentType`,
            `AM`.`AssignmentNum`,
            `AM`.`AssignmentProblem`,
            `AM`.`AssignmentDescription`,
            `AM`.`AvailableCourseIdx`,
            IN_AbetCourseIdxReference AS `AbetCourseIdx`,  -- Replace with Reference index
            `AM`.`ActualAssmntSample`
        FROM `AssessmentMeasures` AS `AM`
        -- Join to get Primary GPI details
        INNER JOIN `GeneralPerformanceIndicators` AS `PrimGPI`
            ON (`AM`.`GPI` = `PrimGPI`.`Idx`)
        -- Join to get Primary SO details
        INNER JOIN `StudentOutcomes` AS `PrimSO`
            ON (`PrimGPI`.`SOIdx` = `PrimSO`.`Idx`)
        -- Join to get Reference SO with matching SO text in Reference academic context
        INNER JOIN `StudentOutcomes` AS `RefSO`
            ON (`PrimSO`.`SO` = `RefSO`.`SO`
                AND `RefSO`.`AcademicYear` = v_ReferenceAcademicYear
                AND `RefSO`.`AcademicProgram` = v_ReferenceAcademicProgram)
        -- Join to get Reference GPI with matching GPI text
        INNER JOIN `GeneralPerformanceIndicators` AS `RefGPI`
            ON (`PrimGPI`.`GPI` = `RefGPI`.`GPI`
                AND `RefSO`.`Idx` = `RefGPI`.`SOIdx`)
        WHERE `AM`.`AvailableCourseIdx` = IN_AvailableCourseIdx
          AND `AM`.`AbetCourseIdx` = IN_AbetCourseIdxPrimary;

        -- Duplicate scoresheet records from Primary to Reference course
        -- Use same AvailableCourseIdx, StudentNo, and LevelOfAttainment
        -- Map AssessmentMeasureIdx to the newly created Reference course measures
        -- Use Reference course's AcademicProgramIdx instead of Primary's
        INSERT INTO `Scoresheet` (
            `AvailableCourseIdx`,
            `AbetCourseIdx`,
            `AssessmentMeasureIdx`,
            `StudentNo`,
            `LevelOfAttainment`,
            `AcademicProgramIdx`
        )
        SELECT
            `S`.`AvailableCourseIdx`,
            IN_AbetCourseIdxReference AS `AbetCourseIdx`,
            `RefAM`.`Idx` AS `AssessmentMeasureIdx`,
            `S`.`StudentNo`,
            `S`.`LevelOfAttainment`,
            `RefAC`.`AcademicProgram` AS `AcademicProgramIdx`  -- Get from Reference course instead
        FROM `Scoresheet` AS `S`
            -- Join to get Primary assessment measure details
            INNER JOIN `AssessmentMeasures` AS `PrimAM`
                ON (`S`.`AssessmentMeasureIdx` = `PrimAM`.`Idx`
                    AND `S`.`AvailableCourseIdx` = IN_AvailableCourseIdx
                    AND `PrimAM`.`AbetCourseIdx` = IN_AbetCourseIdxPrimary)
            -- Join to get the corresponding Reference assessment measure
            -- Match based on Measure number and assignment details (not GPI mapping)
            INNER JOIN `AssessmentMeasures` AS `RefAM`
                ON (`RefAM`.`Measure` = `PrimAM`.`Measure`
                    AND `RefAM`.`AssignmentType` = `PrimAM`.`AssignmentType`
                    AND COALESCE(`RefAM`.`AssignmentNum`, 0) = COALESCE(`PrimAM`.`AssignmentNum`, 0)
                    AND COALESCE(`RefAM`.`AssignmentProblem`, '') = COALESCE(`PrimAM`.`AssignmentProblem`, '')
                    AND `RefAM`.`AvailableCourseIdx` = IN_AvailableCourseIdx
                    AND `RefAM`.`AbetCourseIdx` = IN_AbetCourseIdxReference)
            -- Join to get Reference course's AcademicProgram
            INNER JOIN `AbetCourses` AS `RefAC`
                ON (`RefAC`.`Idx` = IN_AbetCourseIdxReference)
            WHERE `S`.`AvailableCourseIdx` = IN_AvailableCourseIdx
              AND `S`.`AbetCourseIdx` = IN_AbetCourseIdxPrimary;

        -- Add ContinuousImprovement record for Reference course if not exists
        INSERT INTO `ContinuousImprovement` (
            `NumStudents`,
            `FacultyReflection`,
            `EvaluatorsReflection`,
            `AvailableCourseIdx`,
            `AbetCourseIdx`
        )
        SELECT
            `CI`.`NumStudents`,
            `CI`.`FacultyReflection`,
            `CI`.`EvaluatorsReflection`,
            IN_AvailableCourseIdx,
            IN_AbetCourseIdxReference
        FROM `ContinuousImprovement` AS `CI`
        WHERE `CI`.`AvailableCourseIdx` = IN_AvailableCourseIdx
          AND `CI`.`AbetCourseIdx` = IN_AbetCourseIdxPrimary
          AND NOT EXISTS (
            SELECT 1
            FROM `ContinuousImprovement`
            WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
              AND `AbetCourseIdx` = IN_AbetCourseIdxReference
        )
        LIMIT 1;

        -- Commit transaction
        COMMIT;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateCrsMaterialsCourseSyllabus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateCrsMaterialsCourseSyllabus`(
    IN IN_AvailableCourseIdx INT,
    IN IN_SyllabusFileName VARCHAR(256)
)
BEGIN
    DECLARE v_AVCourseExists INT DEFAULT 0;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Validate that Available course exists
    SELECT COUNT(*) INTO v_AVCourseExists
    FROM `AVCourses`
    WHERE `Idx` = IN_AvailableCourseIdx;

    IF v_AVCourseExists = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- Available course does not exist
    END IF;

    -- Update the specified Available course
    UPDATE `AVCourses`
    SET `Syllabus` = IN_SyllabusFileName,
        `crsbinder_updated` = 1
    WHERE `Idx` = IN_AvailableCourseIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateEvaluatorReflection` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateEvaluatorReflection`(
    IN IN_ContImprvmntIdx INT,
    IN IN_EvaluatorIdx INT,
    IN IN_EvaluatorsReflection MEDIUMTEXT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error updating evaluator reflection';
    END;

    START TRANSACTION;

    UPDATE `ContinuousImprovement`
    SET `EvaluatorsReflection` = IN_EvaluatorsReflection
    WHERE `Idx` = IN_ContImprvmntIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateMultipleStudentsDropStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateMultipleStudentsDropStatus`(
    IN IN_AvailableCourseIdx INT,
    IN IN_StudentNos VARCHAR(1000),
    IN IN_IsDropped TINYINT
)
BEGIN
    -- Update using FIND_IN_SET to match student numbers
    UPDATE `ClassRoster`
    SET `IsDropped` = IN_IsDropped
    WHERE `AvailableCourseIdx` = IN_AvailableCourseIdx
      AND FIND_IN_SET(`StudentNo`, IN_StudentNos) > 0
      AND `IsDropped` != IN_IsDropped;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdatePI` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdatePI`(
    IN p_Description TEXT,
    IN p_Comments TEXT,
    IN p_Approval TEXT,
    IN p_TobeRemoved INT,
    IN p_Idx INT
)
BEGIN

    SELECT `TobeRemoved` INTO @Old_TobeRemoved
        FROM `GeneralPerformanceIndicators` WHERE `Idx`=p_Idx;

    UPDATE `GeneralPerformanceIndicators`
        SET `Description`=p_Description, `Comments`=p_Comments, `Approval`=p_Approval, `TobeRemoved`=p_TobeRemoved
        WHERE `Idx`=p_Idx;

-- Find academic year and program information
    SELECT `AcademicYear`, `AcademicProgram`
        INTO @sel_AcademicYear, @sel_AcademicProgram
            FROM `GeneralPerformanceIndicators`
        WHERE `Idx`=p_Idx;

-- Update the field "Removal" indicator.
    IF p_TobeRemoved = 1 THEN
        UPDATE `AssessmentMasterRubrics`
        SET `Comments`=p_Comments, `Approval`=p_Approval, `TobeRemoved`=p_TobeRemoved
          WHERE `AcademicYear`=@sel_AcademicYear AND `GPIIdx`=p_Idx
                AND `AcademicProgram`=@sel_AcademicProgram;
    END IF;

--     reset approved messages
    IF p_TobeRemoved = 0 AND @Old_TobeRemoved = 1 THEN
        UPDATE `AssessmentMasterRubrics`
        SET `Comments`='', `Approval`='', `TobeRemoved`=p_TobeRemoved
        WHERE `AcademicYear`=@sel_AcademicYear AND `GPIIdx`=p_Idx
          AND `AcademicProgram`=@sel_AcademicProgram;
    END IF;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdatePosition` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdatePosition`(
    IN IN_Idx INT,
    IN IN_Name VARCHAR(200)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `Positions` WHERE `Name`=IN_Name AND `Idx`!=IN_Idx) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already

    END IF;

    UPDATE `Positions`
        SET `Name`=IN_Name
        WHERE `Idx`=IN_Idx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdatePositionPermission` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdatePositionPermission`(
    IN IN_UserIdx INT,
    IN IN_Option VARCHAR(50),
    IN IN_Checked BOOLEAN
)
BEGIN
    -- Declare a variable to hold the dynamic SET clause
    DECLARE SetField VARCHAR(100);

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF NOT EXISTS (SELECT 1 FROM `Positions` WHERE `Idx` = IN_UserIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- The same name not exists
    END IF;

    -- Determine the correct field based on the option
    CASE IN_Option
        WHEN 'AccessMyCourseAssessments' THEN
            SET SetField = '`AccessMyCourseAssessments`';
        WHEN 'AccessTACourseAssessments' THEN
            SET SetField = '`AccessTACourseAssessments`';
        WHEN 'AccessCourseEvaluation' THEN
            SET SetField = '`AccessCourseEvaluation`';
        WHEN 'AccessAssessmentsSummary' THEN
            SET SetField = '`AccessAssessmentsSummary`';
        ELSE
            -- Raise an error for invalid options
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Invalid permission option';
    END CASE;

    -- Construct the update query
    SET @UpdateQuery = CONCAT(
        'UPDATE `Positions` SET ',
        SetField,
        ' = ',
        IN_Checked,
        ' WHERE `Idx` = ',
        IN_UserIdx
    );

        -- Prepare and execute the dynamic SQL
    PREPARE stmt FROM @UpdateQuery;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateProgram` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateProgram`(
    IN IN_ProgramIdx INT,
    IN IN_ProgramName VARCHAR(200),
    IN IN_DegreeName VARCHAR(20),
    IN IN_DepartmentNameCode INT
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `AcademicPrograms` WHERE `Name` = IN_ProgramName AND `Idx`!=IN_ProgramIdx) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already
    END IF;

    UPDATE `AcademicPrograms`
    SET `Name`=IN_ProgramName, `Degree`=IN_DegreeName, `Department`=IN_DepartmentNameCode
    WHERE `Idx`=IN_ProgramIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateResetScoresInScoresheet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateResetScoresInScoresheet`(
    IN IN_StudentNo INT, IN IN_AvailableCourseIdx INT, IN IN_AbetCourseIdx INT, IN IN_AcademicProgramIdx INT)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    UPDATE `Scoresheet`
        SET `LevelOfAttainment`=NULL
    WHERE `AvailableCourseIdx`=IN_AvailableCourseIdx
        AND `AbetCourseIdx`=IN_AbetCourseIdx
        AND `StudentNo`=IN_StudentNo
        AND `AcademicProgramIdx`=IN_AcademicProgramIdx;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateScoreInScoresheet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateScoreInScoresheet`(IN IN_StudentNo INT, IN IN_LevelOfAttainment INT,
    IN IN_AssessmentMeasureIdx INT, IN IN_AvailableCourseIdx INT, IN IN_AbetCourseIdx INT, IN IN_AcademicProgramIdx INT)
BEGIN

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

	START TRANSACTION;

    UPDATE `Scoresheet`
        SET `LevelOfAttainment`=IN_LevelOfAttainment
    WHERE `AvailableCourseIdx`=IN_AvailableCourseIdx
        AND `AbetCourseIdx`=IN_AbetCourseIdx
        AND`AssessmentMeasureIdx`=IN_AssessmentMeasureIdx
        AND `StudentNo`=IN_StudentNo
        AND `AcademicProgramIdx`=IN_AcademicProgramIdx;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateScoresheet` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateScoresheet`(IN IN_NumStudents INT, IN IN_AvailableCourseIdx INT, IN IN_AbetCourseIdx INT, IN IN_AcademicProgramIdx INT)
BEGIN
	DECLARE done TINYINT DEFAULT FALSE; -- A boolean variable to tell us when the cursor is out of data
	DECLARE _AssessmentMeasureIdx INT;

	-- cursor1 is an arbitrary label, an identifier for the cursor
	DECLARE cursor1 CURSOR FOR  ###################################### fetching Assessment measures #########################
        SELECT DISTINCT `AssessmentMeasureIdx`
            FROM `Scoresheet`
        WHERE `AvailableCourseIdx`=IN_AvailableCourseIdx
                AND `AbetCourseIdx`=IN_AbetCourseIdx
                AND `AcademicProgramIdx`=IN_AcademicProgramIdx;

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

	START TRANSACTION;
	    #----------------------------------------------------------------------------------
        # Update # of students to be assessed
        UPDATE `ContinuousImprovement` SET `NumStudents`=IN_NumStudents
        WHERE `AvailableCourseIdx`=IN_AvailableCourseIdx AND `AbetCourseIdx`=IN_AbetCourseIdx;

	    #----------------------------------------------------------------------------------
        # Fetch total number of students registered for the selected course
        SELECT `Actual` INTO @IN_StudentEnrollment FROM `AVCourses` WHERE `Idx`=IN_AvailableCourseIdx;
        IF @IN_StudentEnrollment <= IN_NumStudents THEN
        BEGIN
            # Find Max value
            SET @IN_StudentEnrollment = IN_NumStudents;
        END;
        END IF;

	    #----------------------------------------------------------------------------------
        -- open the cursor
        OPEN cursor1;

        dataLoop: LOOP
            FETCH NEXT FROM cursor1 INTO _AssessmentMeasureIdx;
            IF done THEN
                LEAVE dataLoop;
            ELSEIF _AssessmentMeasureIdx IS NOT NULL THEN
                BEGIN
                    # Update scoresheet for each student
                    SET @StudentCnt = 1;
                    WHILE @StudentCnt <= @IN_StudentEnrollment DO
                        IF @StudentCnt <= IN_NumStudents THEN
                        BEGIN
                            #-- insert scoresheet
                            INSERT INTO `Scoresheet`
                                (`AvailableCourseIdx`, `AbetCourseIdx`, `AssessmentMeasureIdx`, `StudentNo`, `AcademicProgramIdx`)
                                SELECT * FROM (
                                    SELECT IN_AvailableCourseIdx, IN_AbetCourseIdx, _AssessmentMeasureIdx, @StudentCnt, IN_AcademicProgramIdx) AS tmp
                                    WHERE NOT EXISTS (
                                        SELECT `AvailableCourseIdx`
                                            FROM `Scoresheet`
                                        WHERE `AvailableCourseIdx`=IN_AvailableCourseIdx
                                            AND `AbetCourseIdx`=IN_AbetCourseIdx
                                            AND `AssessmentMeasureIdx`=_AssessmentMeasureIdx
                                            AND `StudentNo`=@StudentCnt
                                            AND `AcademicProgramIdx`=IN_AcademicProgramIdx
                                    ) LIMIT 1;
                        END;
                        ELSE
                        BEGIN
                            #-- remove unused scoresheet
                            DELETE FROM `Scoresheet`
                                WHERE `AvailableCourseIdx`=IN_AvailableCourseIdx
                                    AND `AbetCourseIdx`=IN_AbetCourseIdx
                                    AND `AssessmentMeasureIdx`=_AssessmentMeasureIdx
                                    AND `StudentNo`=@StudentCnt
                                    AND `AcademicProgramIdx`=IN_AcademicProgramIdx;
                        END;
                        END IF;

                        SET @StudentCnt = @StudentCnt + 1;
                    END WHILE;
                END;
            END IF;
        END LOOP dataLoop;

        CLOSE cursor1;

	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateSharedAbetCoursesLink` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateSharedAbetCoursesLink`(
    IN IN_LinkedAbetCourseIdxList TEXT,
    IN IN_PrimaryAbetCourseIdx INT
)
BEGIN
    DECLARE v_PrimaryExists INT DEFAULT 0;
    DECLARE v_LinkedCount INT DEFAULT 0;
    DECLARE v_ExpectedCount INT DEFAULT 0;
    DECLARE v_AlreadyLinkedCount INT DEFAULT 0;
    DECLARE v_PrimaryReferenceValue INT DEFAULT NULL;
    DECLARE v_PrimaryReferencedCount INT DEFAULT 0;

    -- Start transaction
    START TRANSACTION;

    -- Validate Reference ABET course index list
    IF IN_LinkedAbetCourseIdxList IS NULL OR TRIM(IN_LinkedAbetCourseIdxList) = '' THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50004001'; -- Invalid Reference ABET course index list
    END IF;

    -- Validate Primary ABET course index
    IF IN_PrimaryAbetCourseIdx IS NULL OR IN_PrimaryAbetCourseIdx < 1 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50004002'; -- Invalid Primary ABET course index
    END IF;

    -- Check if Primary course index is in the Reference list (cannot reference itself)
    IF FIND_IN_SET(IN_PrimaryAbetCourseIdx, IN_LinkedAbetCourseIdxList) > 0 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50004005'; -- Cannot reference itself
    END IF;

    -- Verify Primary ABET course exists and get its Reference value
    SELECT COUNT(*), MAX(`Reference`) INTO v_PrimaryExists, v_PrimaryReferenceValue
    FROM `AbetCourses`
    WHERE `Idx` = IN_PrimaryAbetCourseIdx;

    IF v_PrimaryExists = 0 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50004004'; -- Primary ABET course does not exist
    END IF;

    -- Check if Primary course already has a Reference value (already a reference course)
    IF v_PrimaryReferenceValue IS NOT NULL THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50004007'; -- Primary course already has a Reference value
    END IF;

    -- Check if Primary course is already referenced by other courses
    SELECT COUNT(*) INTO v_PrimaryReferencedCount
    FROM `AbetCourses`
    WHERE `Reference` = IN_PrimaryAbetCourseIdx;

    IF v_PrimaryReferencedCount > 0 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50004008'; -- Primary course is already referenced by other courses
    END IF;

    -- Count how many Reference indices were provided
    SET v_ExpectedCount = (LENGTH(IN_LinkedAbetCourseIdxList) -
                          LENGTH(REPLACE(IN_LinkedAbetCourseIdxList, ',', '')) + 1);

    -- Verify all Reference ABET courses exist
    SELECT COUNT(*) INTO v_LinkedCount
    FROM `AbetCourses`
    WHERE FIND_IN_SET(`Idx`, IN_LinkedAbetCourseIdxList) > 0;

    IF v_LinkedCount != v_ExpectedCount THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50004003'; -- One or more Reference ABET courses do not exist
    END IF;

    -- Check if any Reference courses already have Linked = 1
    SELECT COUNT(*) INTO v_AlreadyLinkedCount
    FROM `AbetCourses`
    WHERE FIND_IN_SET(`Idx`, IN_LinkedAbetCourseIdxList) > 0
      AND `Linked` = 1;

    IF v_AlreadyLinkedCount > 0 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50004006'; -- One or more Reference courses are already linked
    END IF;

    -- Update Primary course: Set Linked = 1, Reference = NULL (marks it as Primary)
    UPDATE `AbetCourses`
    SET `Linked` = 1,
        `Reference` = NULL
    WHERE `Idx` = IN_PrimaryAbetCourseIdx;

    -- Update all Reference courses: Set Linked = 1, Reference = Primary Idx
    UPDATE `AbetCourses`
    SET `Reference` = IN_PrimaryAbetCourseIdx,
        `Linked` = 1
    WHERE FIND_IN_SET(`Idx`, IN_LinkedAbetCourseIdxList) > 0;

    -- Commit transaction (all or nothing)
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateSharedAbetCoursesUnlink` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateSharedAbetCoursesUnlink`(
    IN IN_AbetCourseAcademicYear INT,
    IN IN_AbetCourseIdx INT,
    IN IN_AvailableCourseIdx INT
)
BEGIN
    DECLARE v_CourseExists INT DEFAULT 0;
    DECLARE v_LinkedValue INT DEFAULT NULL;
    DECLARE v_ReferenceValue INT DEFAULT NULL;
    DECLARE v_PrimaryAbetCourseIdx INT DEFAULT NULL;
    DECLARE v_ReferenceCount INT DEFAULT 0;

    -- Start transaction
    START TRANSACTION;

    -- Validate ABET course index
    IF IN_AbetCourseIdx IS NULL OR IN_AbetCourseIdx < 1 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50005001'; -- Invalid ABET course index
    END IF;

    -- Check if ABET course exists and get its Linked and Reference values
    SELECT COUNT(*), `Linked`, `Reference`
    INTO v_CourseExists, v_LinkedValue, v_ReferenceValue
    FROM `AbetCourses`
    WHERE `Idx` = IN_AbetCourseIdx
        AND `AcademicYear` = IN_AbetCourseAcademicYear
        AND `AVCourseIdx` = IN_AvailableCourseIdx;

    IF v_CourseExists = 0 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50005002'; -- ABET course does not exist
    END IF;

    -- Check if course is part of a linked group
    IF v_LinkedValue IS NULL OR v_LinkedValue = 0 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50005003'; -- Course is not part of any linked group
    END IF;

    -- Determine the Primary course Idx
    IF v_ReferenceValue IS NULL THEN
        -- This is a Primary course (Reference = NULL), use its own Idx
        SET v_PrimaryAbetCourseIdx = IN_AbetCourseIdx;
    ELSE
        -- This is a Reference course (Reference = Primary Idx), use the Reference value
        SET v_PrimaryAbetCourseIdx = v_ReferenceValue;
    END IF;

    -- Count how many Reference courses exist for this Primary
    SELECT COUNT(*) INTO v_ReferenceCount
    FROM `AbetCourses`
    WHERE `Reference` = v_PrimaryAbetCourseIdx
        AND `Reference` IS NOT NULL;

    -- Note: It's okay if v_ReferenceCount = 0 (Primary with no references)
    -- We still want to unlink the Primary course

    -- Unlink all Reference courses by setting Linked = NULL and Reference = NULL
    UPDATE `AbetCourses`
    SET `Linked` = NULL,
        `Reference` = NULL
    WHERE `Reference` = v_PrimaryAbetCourseIdx
        AND `Reference` IS NOT NULL;

    -- Unlink the Primary course by setting Linked = NULL (Reference already NULL)
    UPDATE `AbetCourses`
    SET `Linked` = NULL
    WHERE `Idx` = v_PrimaryAbetCourseIdx;

    -- Verify at least the primary course was updated
    IF ROW_COUNT() = 0 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x50005004'; -- No courses found to unlink
    END IF;

    -- Commit transaction (all or nothing)
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateSO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateSO`(
    IN IN_Idx INT,
    IN IN_Description VARCHAR(2048),
    IN IN_Comments TEXT,
    IN IN_Approval VARCHAR(2048),
    IN IN_TobeRemoved INT
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
    ROLLBACK;
    RESIGNAL;
    END;

    START TRANSACTION;

    -- Add validation check
    IF NOT EXISTS (SELECT 1 FROM StudentOutcomes WHERE Idx = IN_Idx) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x09000012';
    END IF;

    UPDATE StudentOutcomes
    SET Description = IN_Description,
        Comments = IN_Comments,
        Approval = IN_Approval,
        TobeRemoved = IN_TobeRemoved
    WHERE Idx = IN_Idx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateSubject` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateSubject`(
    IN IN_Idx INT,
    IN IN_Name VARCHAR(50),
    IN IN_DeptIdx INT
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing position name
    IF EXISTS (SELECT 1 FROM `Subjects` WHERE `Name`=IN_Name AND `Idx`!=IN_Idx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200011'; -- The same name exists already

    END IF;

    UPDATE `Subjects`
        SET `Name`=IN_Name, `Department`=IN_DeptIdx
        WHERE `Idx`=IN_Idx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateSurveyReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateSurveyReport`(
    IN IN_AvailableCourseIdx INT,
    IN IN_SurveyReportFileName VARCHAR(256)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if the record exists
    IF NOT EXISTS (SELECT 1 FROM `AVCourses` WHERE `Idx` = IN_AvailableCourseIdx) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '0x00200012'; -- The data not exists
    END IF;

    UPDATE `AVCourses`
    SET `SurveyReport` = IN_SurveyReportFileName
    WHERE `Idx` = IN_AvailableCourseIdx;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateUserAccessControl` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateUserAccessControl`(
    IN IN_Idx INT,
    IN IN_AccessControl VARCHAR(200)
)
BEGIN
    -- Declare local variables
    DECLARE str VARCHAR(1024);
    DECLARE program_id VARCHAR(255);
    DECLARE pos INT;

    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Delete existing access controls for this user
    DELETE FROM `AccessControls` WHERE `UserAccount` = IN_Idx;

    -- Process AccessControl string if not empty
    -- Process AccessControl string if not empty
    IF IN_AccessControl IS NOT NULL AND IN_AccessControl != '' THEN
        SET str = IN_AccessControl;

        -- Loop to process each comma-separated value
        simple_loop: LOOP
        -- Find the position of the next comma
        SET pos = LOCATE(',', str);

        IF pos = 0 THEN
        -- Handle the last value in the string
            SET program_id = TRIM(str);
            IF program_id != '' THEN
                INSERT INTO `AccessControls` (`AcademicProgram`, `UserAccount`)
                VALUES (program_id, IN_Idx);
            END IF;
            LEAVE simple_loop;
        END IF;

        -- Extract the value before the comma
        SET program_id = TRIM(SUBSTRING(str, 1, pos - 1));
        IF program_id != '' THEN
            INSERT INTO `AccessControls` (`AcademicProgram`, `UserAccount`)
            VALUES (program_id, IN_Idx);
        END IF;

        -- Remove the processed value and continue
        SET str = SUBSTRING(str, pos + 1);
        END LOOP simple_loop;
    END IF;

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SP_UpdateUserAccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `SP_UpdateUserAccount`(
    IN IN_Idx INT,
    IN IN_Email VARCHAR(50),
    IN IN_UserName VARCHAR(50),
    IN IN_Position INT,
    IN IN_Affiliation INT,
    IN IN_AccessControl VARCHAR(200)
)
BEGIN
    -- Add error handling
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check for existing account
    IF NOT EXISTS (SELECT 1 FROM `UserAccounts` WHERE `Idx`=IN_Idx) THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '0x00200012'; -- info not exits
    END IF;

    UPDATE `UserAccounts`
        SET `Email`=IN_Email,`Name`=IN_UserName,`Position`=IN_Position,`Affiliation`=IN_Affiliation
        WHERE `Idx`=IN_Idx;

    CALL SP_UpdateUserAccessControl(IN_Idx, IN_AccessControl);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-11 17:49:00
