window.onload = init;
let interval;

function init() {
	interval = setInterval(trackLogin, 60000); // Check every 60 seconds
}

async function trackLogin() {
	try {
		const response = await fetch('sessioncheck.php');
		if (response.ok) {
			const result = await response.text();

			if (result === '1') {
				clearInterval(interval);
				showSessionExpiredMessage();
			}
		}
	} catch (error) {
		console.error('Error checking session:', error);
	}
}

function showSessionExpiredMessage() {
	document.body.innerHTML = `
		<!DOCTYPE html>
		<html>
		<head>
			<style>
				.alert {
					background-color: white;
					font-family: 'Open Sans', sans-serif;
					width: 90%;
					max-width: 478px;
					padding: 17px;
					border-radius: 5px;
					text-align: center;
					position: fixed;
					left: 50%;
					top: 50%;
					transform: translate(-50%, -50%);
					overflow: hidden;
					box-shadow: 0 0 10px rgba(0,0,0,0.1);
				}
				h2 {
					color: #575757;
					font-size: 30px;
					text-align: center;
					font-weight: 600;
					margin: 25px 0;
					padding: 0;
					line-height: 25px;
				}
				p {
					color: #797979;
					font-size: 16px;
					text-align: center;
					font-weight: 300;
					margin: 0;
					padding: 0;
					line-height: normal;
				}
				#countdown {
					color: #575757;
					font-size: 20px;
					margin: 15px 0;
				}
				button {
					background-color: #AEDEF4;
					color: white;
					border: none;
					box-shadow: none;
					font-size: 17px;
					font-weight: 500;
					border-radius: 5px;
					padding: 10px 32px;
					margin: 26px 5px 0 5px;
					cursor: pointer;
					transition: background-color 0.3s ease;
				}
				button:focus {
					outline: none;
					box-shadow: 0 0 2px rgba(128, 179, 235, 0.5), inset 0 0 0 1px rgba(0, 0, 0, 0.05);
				}
				button:hover {
					background-color: #a1d9f2;
				}
				button:active {
					background-color: #81ccee;
				}
			</style>
		</head>
		<body style="background-color:gray">
			<div class="alert">
				<br/><br/>
				<img src="./images/msg_error.jpg" width="100" alt="Error"><br/>
				<h2>Warning!</h2>
				<p>Session finished, please log in again</p>
				<div id="countdown">Redirecting in 5 seconds...</div>
				<button class="cancel" id="okButton">OK</button>
			</div>
		</body>
		</html>
	`;

	let timeLeft = 5;
	let countdownInterval = setInterval(() => {
		timeLeft--;
		const countdownElement = document.getElementById('countdown');
		if (countdownElement) {
			countdownElement.textContent = `Redirecting in ${timeLeft} seconds...`;
		}

		if (timeLeft === 0) {
			clearInterval(countdownInterval);
			window.location.assign('./index.php');
		}
	}, 1000);

	// Allow manual redirect with OK button
	document.getElementById('okButton').onclick = function() {
		clearInterval(countdownInterval);
		window.location.assign('./index.php');
		return false;
	};
}