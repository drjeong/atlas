<?php
/**
 * Check Master Syllabus
 * Description: checking if master syllabus exists in the server.
 * Author: Dong Hyun Jeong
 *
 * 05/16/2026 - initial version created
 *
 */

include_once 'session_handler.php';

$CourseMappingCourseIdx = '';
if (array_key_exists('idx', $_POST))
{
    $CourseMappingCourseIdx = trim($_POST['idx']);
}
else
{
    // unwanted illegal entry
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'ERROR',
        'errorCode' => '0x00000000',
        'message' => 'Missing required parameter'
    ]);
    exit;
}

if ($CourseMappingCourseIdx === ''){
    // no required information
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'ERROR',
        'errorCode' => '0x00000101',
        'message' => 'Empty parameter value'
    ]);
    exit;
}

try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $CourseMappingCourseIdx = filter_var($CourseMappingCourseIdx, FILTER_VALIDATE_INT);
    if ($CourseMappingCourseIdx === false) {
        throw new Exception('Invalid Index format');
    }

    $query = "CALL SP_ChkIfAbetSyllabusExist(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$CourseMappingCourseIdx]);
//    error_log($DBCONNECTION->formatQuery($query, [$CourseMappingCourseIdx]));

    if ($result && $DBCONNECTION->num_rows() > 0) {
        $row = $DBCONNECTION->fetch_assoc();
        $data = $row["AbetSyllabus"];

        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'SUCCESS',
            'data' => $data
        ]);
        exit;  // Added exit here
    } else {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'NOT_FOUND',
            'data' => null,
            'message' => 'No matching syllabus found'
        ]);
        exit;  // Added exit here
    }

} catch (mysqli_sql_exception $e) {
    // Database error
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'ERROR',
        'errorCode' => '0x00000500',
        'message' => 'Database error occurred'
    ]);

    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500',
        'file' => __FILE__,
        'line' => $e->getLine()
    ]));
    exit;

} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'ERROR',
        'errorCode' => '0x00000000',
        'message' => 'General error occurred'
    ]);

    error_log($e->getMessage());
    exit;
}