<?php
/**
 * Add Abet Course
 * Description: Adding abet course
 * Author: Dong Hyun Jeong
 *
 * 05/16/2026 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$AbetCourseIdx='';
$ABETSyllabusIdx='';

if (array_key_exists('idx', $_POST) && array_key_exists('syllabus', $_POST) )
{
    $AbetCourseIdx = trim($_POST['idx']);
    $ABETSyllabusIdx = trim($_POST['syllabus']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

if ($AbetCourseIdx==='' || $ABETSyllabusIdx===''){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    $query = "CALL SP_UpdateCourseMapping_MasterSyllabus(?, ?);";
    $params = [$AbetCourseIdx, $ABETSyllabusIdx];
    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    echo "0x11111111";
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    error_log($DBCONNECTION->FormatQuery($query, $params));

    echo "0x00000000";
}
