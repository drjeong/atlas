<?php
/**
 * Fetching course assessment data
 * Description: It fetches all course assessment data.
 * Author: Dong Hyun Jeong
 *
 * 03/26/2025 - initial version created (fetched from create_pdf.php)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Fetches and processes all data needed for course assessment PDF generation
 *
 * @param int $AvailableCourseIdx The available course index
 * @param int $AbetCourseIdx The ABET course index
 * @param int $AcademicProgramIdx The academic program index
 * @param string $AcademicYear The academic year
 * @return array|string Returns an array with all data on success, or an error code string on failure
 */
function fetchCourseAssessmentData($AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, $AcademicYear) {
    // Include required files
    require_once(__DIR__ . '/php_include/listfunc.php');
    require_once(__DIR__ . '/php_include/LatexTemplate.php');
    require_once(__DIR__ . '/php_include/dbconnection_class.php');

    // Initialize database connection and data array
    $DBCONNECTION = new Dbconnection();

    try {

        // Fetch Course Info
        $data = fetchCourseInfo($DBCONNECTION, $AvailableCourseIdx, $AcademicYear);

        // Fetch ABET Course Assessment Measures ($data is referenced and updated)
        fetchAssessmentMeasures($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, $data);

        // Fetch Course Master Rubrics ($data is referenced and updated)
        fetchMasterRubrics($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, $data);

        // Fetch Scoresheet ($data is referenced and updated)
        fetchScoresheet($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $data);

        // Fetch Continuous Improvement ($data is referenced and updated)
        fetchContinuousImprovement($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $data);

        // Fetch Average Assessment Scores ($data is referenced and updated)
        fetchAverageAssessmentScores($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, $data);

        // Fetch Average Performance Indicator Scores ($data is referenced and updated)
        fetchPerStudentAveragePIScores($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, $data);

        // Fetch Average Student Outcome Scores ($data is referenced and updated)
        fetchPerStudentAverageSOScores($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, $data);

        return $data;

    } catch (Exception $e) {
        // Log error and return error code
        error_log($e->getMessage() . ' [Code: ' . $e->getCode() . ']');

        if ($e instanceof mysqli_sql_exception) {
            error_log(json_encode([
                'success' => false,
                'error' => $e->getMessage(),
                'errorCode' => '0x00000500'
            ]));
            return "0x00000500";  // DB error
        }

        if ($e->getCode() !== 0) {
            return sprintf('0x%X', $e->getCode());
        }

        return "0x00000000";  // Generic error
    }
}

/**
 * Fetches basic course information
 */
function fetchCourseInfo($DBCONNECTION, $AvailableCourseIdx, $AcademicYear) {
    // Initialize paths and filenames
    require_once(__DIR__ . '/../config.php');
    $ASSESSMENT_PDF_PATH = __DIRECTORY_ABETASSESSMENTS__ . "$AcademicYear/";
    $ABETSYLLABUS_PDF_PATH = __DIRECTORY_ABETSYLLABI__ . "$AcademicYear/";
    $COURSESYLLABUS_PDF_PATH = __DIRECTORY_COURSEBI__ . "$AcademicYear/";
    $SURVEY_PDF_PATH = __DIRECTORY_ABETASSESSMENTSURVEY__ . "$AcademicYear/";
    $UNIV_LOGO_PATH = __UNIV_LOGO_PATH__;

    $Query = "CALL SP_CreatePDF_FetchAvailableCourseInfo(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx]);

    if (!$result || $DBCONNECTION->num_rows() === 0) {
        throw new Exception('No course data found');
    }

    $row = $DBCONNECTION->fetch_assoc();

    // Safely get values with null coalescing
    $Semester = $row['Semester'] ?? '';
    $CourseCRN = $row['CRN'] ?? '';
    $CourseSubject = $row['Subject'] ?? '';
    $CourseNum = $row['Num'] ?? '';
    $CourseTitle = $row['Title'] ?? '';
    $CourseCredits = $row['Credits'] ?? '';
    $InstructorName = $row['Instructor'] ?? '';
    $Degree = $row['Degree'] ?? '';
    $CourseSyllabusPDF_FileName = !empty($row['Syllabus'])
        ? $COURSESYLLABUS_PDF_PATH . $row['Syllabus']
        : '';
    $AbetSyllabusPDF_FileName = !empty($row['ABETSyllabus'])
        ? $ABETSYLLABUS_PDF_PATH . $row['ABETSyllabus']
        : '';
    $SurveyReportPDF_FileName = !empty($row['SurveyReport'])
        ? $SURVEY_PDF_PATH . $row['SurveyReport']
        : '';

    // Convert to lowercase once
    $lowercase_values = [
        'degree' => strtolower($Degree),
        'subject' => strtolower($CourseSubject),
        'num' => strtolower($CourseNum),
        'semester' => strtolower($Semester)
    ];

    // Build filenames using consistent pattern
    $filename_parts = [
        'semester' => str_replace(' ', '_', $lowercase_values['semester']),
        'subject' => str_replace(' ', '_', $lowercase_values['subject']),
        'num' => str_replace(' ', '_', $lowercase_values['num']),
        'crn' => 'crn' . str_replace(' ', '_', $CourseCRN)
    ];

//    $CourseSyllabusPDF_FileName = 'syllabus_' . implode('_', $filename_parts) . '.pdf';

    // ABET filename uses different pattern
//    $AbetSyllabusPDF_FileName = 'abet_syllabus_' . sprintf('%s_%s_%s_%s.pdf',
//            str_replace(' ', '-', $AcademicYear),
//            str_replace(' ', '_', $lowercase_values['degree']),
//            str_replace(' ', '_', $lowercase_values['subject']),
//            str_replace(' ', '_', $lowercase_values['num'])
//        );

    $course_title = trim(sprintf('%s %s %s', $CourseSubject, $CourseNum, $CourseTitle));

    return [
        'logo' => $UNIV_LOGO_PATH,
        'assessmentpath' => $ASSESSMENT_PDF_PATH,
        'courseinfo' => $CourseCRN,
        'coursetitle' => LatexTemplate::plainTextToLatex($course_title),
        'coursesemester' => LatexTemplate::plainTextToLatex($Semester),
        'courseCRN' => LatexTemplate::plainTextToLatex($CourseCRN),
        'courseinstructor' => LatexTemplate::plainTextToLatex(LatexTemplate::replaceSpecialCharacters($InstructorName)),
        'coursesyllabus' => $CourseSyllabusPDF_FileName,
        'abetcoursesyllabus' => $AbetSyllabusPDF_FileName,
        'coursesurvey' => $SurveyReportPDF_FileName,
        'pdf_filename' => 'assessment_' . implode('_', $filename_parts) . '.pdf'
    ];
}

/**
 * Fetches assessment measures data
 */
function fetchAssessmentMeasures($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, &$data) {
    $Query = "CALL SP_CreatePDF_FetchABETCourseAssessmentMeasuresNSamples(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AvailableCourseIdx,
        $AbetCourseIdx,
        $AcademicProgramIdx
    ]);

    $data['assessmentmeasures_exist'] = false;
    $data['studentsamples_exist'] = false;
    $AssmntMeasures = [];
    if ($result && $DBCONNECTION->num_rows() > 0) {
        while ($row = $DBCONNECTION->fetch_assoc()) {
            // Parse student samples (pipe-separated string)
            $studentSamplesRaw = $row['StudentSamples'] ?? '';
            $studentSamples = [];

            if (!empty($studentSamplesRaw)) {
                $sampleFiles = explode('|', $studentSamplesRaw);
                foreach ($sampleFiles as $sampleFile) {
                    if (!empty(trim($sampleFile))) {
                        $studentSamples[] = trim($sampleFile);
                        $data['studentsamples_exist'] = true;
                    }
                }
            }

            $AssmntMeasures[] = [
                'measure' => LatexTemplate::plainTextToLatex($row['Measure'] ?? ''),
                'pi' => LatexTemplate::plainTextToLatex(($row['SO'] ?? '') . "-" . ($row['GPI'] ?? '')),
                'assmntmeasure' => $row['MSRIdx'] ?? '',
                'type' => LatexTemplate::plainTextToLatex(($row['AssignmentType'] ?? '') . ' ' . ($row['AssignmentNum'] ?? '')),
                'problem' => LatexTemplate::plainTextToLatex($row['AssignmentProblem'] ?? ''),
                'desc' => LatexTemplate::plainTextToLatex($row['AssignmentDescription'] ?? ''),
                'assmntsample' => $row['ActualAssmntSample'] ?? '',
                'studentsamples' => $studentSamples  // Array of student sample filenames
            ];

            if (!empty($row['ActualAssmntSample']))
                $data['assessmentmeasures_exist'] = true;
        }
        $data['assessmentmeasures'] = $AssmntMeasures;
    }
}

/**
 * Fetches master rubrics data
 */
function fetchMasterRubrics($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, &$data) {
    $Query = "CALL SP_CreatePDF_FetchABETCourseMaterRubrics(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AvailableCourseIdx,
        $AbetCourseIdx,
        $AcademicProgramIdx
    ]);

    $MasterRubrics = [];
    if (!$result || $DBCONNECTION->num_rows() === 0) {
        throw new Exception('No rubrics data found', 0x3234234);
    }

    while ($row = $DBCONNECTION->fetch_assoc()) {
        $tmp = [
            'pi' => LatexTemplate::plainTextToLatex(
                ($row['SO'] ?? '') . "-" . ($row['GPI'] ?? '')
            )
        ];

        // Add first level of attainment
        $levelOfAttainment = $row['LevelofAttainment'] ?? '';
        if ($levelOfAttainment) {
            $tmp['loa' . $levelOfAttainment] = LatexTemplate::plainTextToLatex($row['Description'] ?? '');
        }

        // Fetch and add next 3 levels of attainment
        for ($i = 0; $i < 3; $i++) {
            $row = $DBCONNECTION->fetch_assoc();
            if (!$row) {
                throw new Exception('Incomplete rubrics data');
            }

            $levelOfAttainment = $row['LevelofAttainment'] ?? '';
            if ($levelOfAttainment) {
                $tmp['loa' . $levelOfAttainment] = LatexTemplate::plainTextToLatex($row['Description'] ?? '');
            }
        }

        $MasterRubrics[] = $tmp;
    }

    $data['masterrubrics'] = $MasterRubrics;
}

/**
 * Fetches scoresheet data
 */
function fetchScoresheet($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, &$data) {
    $Query = "SELECT `NumStudents` FROM `ContinuousImprovement` WHERE `AbetCourseIdx` = ? AND `AvailableCourseIdx` = ?;";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AbetCourseIdx,
        $AvailableCourseIdx
    ]);

    $NumOfStudents = 0;  // # of students to be assessed
    if ($row = $DBCONNECTION->fetch_assoc()) {
        $NumOfStudents = (int)($row['NumStudents'] ?? 0);
    }

    if ($NumOfStudents <= 0) {
        throw new Exception('Invalid number of students');
    }

    // Fetch assessment measures
    $Query = "CALL SP_FetchScoreSheetAssessmentMeasures(?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AbetCourseIdx,
        $AvailableCourseIdx
    ]);

    $AssessmentMeasures_Array = [];
    while ($row = $DBCONNECTION->fetch_assoc()) {
        $AssessmentMeasures_Array[$row['Idx'] ?? 0] = $row['GPIIdx'] ?? 0;
    }

    if (empty($AssessmentMeasures_Array)) {
        throw new Exception('No assessment measures found');
    }

// Fetch scoresheet information
    $Scoresheet_Array = [];
    $AllStudents = []; // Track all unique students across all assessment measures

    foreach ($AssessmentMeasures_Array as $AssessmentMeasureIdx => $GPIIdx) {
        $Query = "CALL SP_FetchScoreSheetAssessmentMeasurestInfoPrint(?);";
        $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AssessmentMeasureIdx]);

        while ($row = $DBCONNECTION->fetch_assoc()) {
            $StudentNo = (int)($row['StudentNo'] ?? 0);
            $LevelOfAttainment = $row['LevelOfAttainment'] ?? '';

            if ($StudentNo > 0) {
                $Scoresheet_Array[$AssessmentMeasureIdx][$StudentNo] = [
                    'LevelOfAttainment' => $LevelOfAttainment
                ];

                // Track this student
                $AllStudents[$StudentNo] = true;
            }
        }
    }

// Build final scoresheet data - iterate only over students that exist
    $DataScoresheet = [];
    ksort($AllStudents); // Sort students by StudentNo

    foreach (array_keys($AllStudents) as $StudentNo) {
        $row_array = [
            'Student' => LatexTemplate::plainTextToLatex((string)$StudentNo)
        ];

        foreach ($AssessmentMeasures_Array as $AssessmentMeasureIdx => $GPIIdx) {
            $row_array['Measure' . $AssessmentMeasureIdx] =
                $Scoresheet_Array[$AssessmentMeasureIdx][$StudentNo]['LevelOfAttainment'] ?? '';
        }

        $DataScoresheet[] = $row_array;
    }

    $data['scoresheet'] = $DataScoresheet;
}


/**
 * Fetches continuous improvement data
 */
function fetchContinuousImprovement($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, &$data) {
    $Query = "CALL SP_CreatePDF_FetchABETCourseContinuousImprovement(?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AvailableCourseIdx,
        $AbetCourseIdx
    ]);

    if (!$result) {
        throw new Exception('Failed to fetch reflection data');
    }

    $data['FacultyReflection'] = '';
    $data['EvaluatorsReflection'] = '';
    if ($row = $DBCONNECTION->fetch_assoc()) {
        $data['FacultyReflection'] = LatexTemplate::htmlToLatexInsidetcolorbox(
            convert_encoded_html_to_display($row['FacultyReflection']) ?? ''
        );
        $data['EvaluatorsReflection'] = LatexTemplate::htmlToLatexInsidetcolorbox(
            convert_encoded_html_to_display($row['EvaluatorsReflection']) ?? ''
        );

//        error_log($row['FacultyReflection']);
//        error_log(convert_encoded_html_to_display($row['FacultyReflection']));
//        error_log(LatexTemplate::htmlToLatexInsidetcolorbox(convert_encoded_html_to_display($row['FacultyReflection'])));
    }
}

/**
 * Fetches average assessment scores data
 */
function fetchAverageAssessmentScores($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, &$data) {
    $Query = "CALL SP_CreatePDF_FetchABETCourseAverageAssessmentScores(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AvailableCourseIdx,
        $AbetCourseIdx,
        $AcademicProgramIdx
    ]);

    $AvgScores = [];
    while ($row = $DBCONNECTION->fetch_assoc()) {
        $total = (float)($row['TOTAL'] ?? 0);

        // Calculate percentages
        $topFifty = $total > 0
            ? round(((float)($row['TOPFIFTY'] ?? 0) / $total) * 100.0, 2)
            : 0;

        $topTwentyFive = $total > 0
            ? round(((float)($row['TOPTWENTYFIVE'] ?? 0) / $total) * 100.0, 2)
            : 0;

        // Build score record
        $scoreRecord = [
            'measure' => LatexTemplate::plainTextToLatex($row['Measure'] ?? ''),
            'assgnmenttype' => LatexTemplate::plainTextToLatex($row['AssignmentType']) ?? '',
            'assignmentnum' => $row['AssignmentNum'] ?? '',
            'assgnmentdesc' => LatexTemplate::plainTextToLatex(html_entity_decode($row['AssignmentDesc']) ?? ''),
            'AVG' => LatexTemplate::plainTextToLatex(
                (string)round((float)($row['AVG'] ?? 0), 2)
            ),
            'TOPFIFTY' => LatexTemplate::plainTextToLatex((string)$topFifty),
            'TOPTWENTYFIVE' => LatexTemplate::plainTextToLatex((string)$topTwentyFive)
        ];

        $AvgScores[] = $scoreRecord;
    }

    $data['courseavgscores'] = $AvgScores;
}

///**
// * Fetches average performance indicator scores data
// */
//function fetchAveragePIScores($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, &$data) {
//    $Query = "CALL SP_CreatePDF_FetchABETCourseAveragePIScores(?, ?, ?);";
//    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
//        $AvailableCourseIdx,
//        $AbetCourseIdx,
//        $AcademicProgramIdx
//    ]);
//
//    if (!$result) {
//        throw new Exception('Failed to fetch PI scores');
//    }
//
//    $AvgScores = [];
//    while ($row = $DBCONNECTION->fetch_assoc()) {
//        $total = (float)($row['TOTAL'] ?? 0);
//
//        // Calculate percentage scores
//        $topFifty = $total > 0
//            ? round(((float)($row['TOPFIFTY'] ?? 0) / $total) * 100.0, 2)
//            : 0;
//
//        $topTwentyFive = $total > 0
//            ? round(((float)($row['TOPTWENTYFIVE'] ?? 0) / $total) * 100.0, 2)
//            : 0;
//
//        $average = round((float)($row['AVG'] ?? 0), 2);
//
//        // Build score record with sanitized values
//        $scoreRecord = [
//            'GPI' => LatexTemplate::plainTextToLatex(
//                $row['GPI'] ?? ''
//            ),
//            'GPIDescription' => LatexTemplate::plainTextToLatex(
//                html_entity_decode($row['Description'] ?? '')
//            ),
//            'AVG' => LatexTemplate::plainTextToLatex((string)$average),
//            'TOPFIFTY' => LatexTemplate::plainTextToLatex((string)$topFifty),
//            'TOPTWENTYFIVE' => LatexTemplate::plainTextToLatex((string)$topTwentyFive)
//        ];
//
//        $AvgScores[] = $scoreRecord;
//    }
//
//    $data['gpiavgscores'] = $AvgScores;
//}

/**
 * Fetches average performance indicator scores data
 */
function fetchPerStudentAveragePIScores($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, &$data) {
    $Query = "CALL SP_CreatePDF_FetchABETCoursePerStudentAveragePIScores(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AvailableCourseIdx,
        $AbetCourseIdx,
        $AcademicProgramIdx
    ]);

    if (!$result) {
        throw new Exception('Failed to fetch per-student PI scores');
    }

    $AvgScores = [];

    while ($row = $DBCONNECTION->fetch_assoc()) {
        // Extract percentage scores (already calculated in stored procedure)
        $topFifty = round((float)($row['PercentDeveloping'] ?? 0), 2);
        $topTwentyFive = round((float)($row['PercentSatisfactory'] ?? 0), 2);
        $average = round((float)($row['AverageScore'] ?? 0), 2);

        // Build score record with sanitized values
        $scoreRecord = [
            'GPI' => LatexTemplate::plainTextToLatex(
                $row['GPI'] ?? ''
            ),
            'GPIDescription' => LatexTemplate::plainTextToLatex(
                html_entity_decode($row['GPIDescription'] ?? '')
            ),
            'AVG' => LatexTemplate::plainTextToLatex((string)$average),
            'TOPFIFTY' => LatexTemplate::plainTextToLatex((string)$topFifty),
            'TOPTWENTYFIVE' => LatexTemplate::plainTextToLatex((string)$topTwentyFive)
        ];

        $AvgScores[] = $scoreRecord;
    }

    $data['gpiavgscores'] = $AvgScores;
}

///**
// * Fetches average student outcome scores data
// */
//function fetchAverageSOScores($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, &$data) {
//    $Query = "CALL SP_CreatePDF_FetchABETCourseAverageSOScores(?, ?, ?);";
//    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
//        $AvailableCourseIdx,
//        $AbetCourseIdx,
//        $AcademicProgramIdx
//    ]);
//
//    if (!$result) {
//        throw new Exception('Failed to fetch SO scores');
//    }
//
//    $AvgScores = [];
//    while ($row = $DBCONNECTION->fetch_assoc()) {
//        $total = (float)($row['TOTAL'] ?? 0);
//
//        // Calculate percentage scores
//        $topFifty = $total > 0
//            ? round(((float)($row['TOPFIFTY'] ?? 0) / $total) * 100.0, 2)
//            : 0;
//
//        $topTwentyFive = $total > 0
//            ? round(((float)($row['TOPTWENTYFIVE'] ?? 0) / $total) * 100.0, 2)
//            : 0;
//
//        $average = round((float)($row['AVG'] ?? 0), 2);
//
//        // Build score record with sanitized values
//        $scoreRecord = [
//            'SO' => LatexTemplate::plainTextToLatex(
//                $row['SO'] ?? ''
//            ),
//            'SODescription' => LatexTemplate::plainTextToLatex(
//                html_entity_decode($row['Description'] ?? '')
//            ),
//            'AVG' => LatexTemplate::plainTextToLatex((string)$average),
//            'TOPFIFTY' => LatexTemplate::plainTextToLatex((string)$topFifty),
//            'TOPTWENTYFIVE' => LatexTemplate::plainTextToLatex((string)$topTwentyFive)
//        ];
//
//        $AvgScores[] = $scoreRecord;
//    }
//
//    $data['soavgscores'] = $AvgScores;
//}

/**
 * Fetches per-student average student outcome scores data
 */
function fetchPerStudentAverageSOScores($DBCONNECTION, $AvailableCourseIdx, $AbetCourseIdx, $AcademicProgramIdx, &$data) {
    $Query = "CALL SP_CreatePDF_FetchABETCoursePerStudentAverageSOScores(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AvailableCourseIdx,
        $AbetCourseIdx,
        $AcademicProgramIdx
    ]);

    if (!$result) {
        throw new Exception('Failed to fetch per-student SO scores');
    }

    $AvgScores = [];

    while ($row = $DBCONNECTION->fetch_assoc()) {
        // Extract percentage scores (already calculated in stored procedure)
        $topFifty = round((float)($row['PercentDeveloping'] ?? 0), 2);
        $topTwentyFive = round((float)($row['PercentSatisfactory'] ?? 0), 2);
        $average = round((float)($row['AverageScore'] ?? 0), 2);

        // Build score record with sanitized values
        $scoreRecord = [
            'SO' => LatexTemplate::plainTextToLatex(
                $row['SO'] ?? ''
            ),
            'SODescription' => LatexTemplate::plainTextToLatex(
                html_entity_decode($row['Description'] ?? '')
            ),
            'AVG' => LatexTemplate::plainTextToLatex((string)$average),
            'TOPFIFTY' => LatexTemplate::plainTextToLatex((string)$topFifty),
            'TOPTWENTYFIVE' => LatexTemplate::plainTextToLatex((string)$topTwentyFive)
        ];

        $AvgScores[] = $scoreRecord;
    }

    $data['soavgscores'] = $AvgScores;
}
