<?php
/**
 * Listing Courses
 * Description: listing courses assigned to each instructor
 *
 * 09/22/2024 - initial version created
 * 03/29/2026 - add to return LinkedGroupId, IsReference, CourseSection
 * 03/29/2026 - fixed to only return courses with assigned assistants
 * 03/29/2026 - fixed instructor name by joining AVCoursesInstructors and UserAccounts tables
 * 08/09/2026 - Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */

include_once 'session_handler.php';

$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// the following is used for administrator
if (array_key_exists('_TA', $_GET)) {
    $TAEmail = trim($_GET['_TA']);
}

// First create a subquery for the grouped data (SOs and GPIs)
$groupedDataQuery = "SELECT 
    `ABETCRSES`.`Idx` AS CourseIdx,
    GROUP_CONCAT(DISTINCT(`ABETCRSES_SOS`.`SOIdx`) ORDER BY `STNTOUTCMS`.`SO` SEPARATOR ', ') AS SOIdxes,
    GROUP_CONCAT(DISTINCT(`STNTOUTCMS`.`SO`) ORDER BY `STNTOUTCMS`.`SO` SEPARATOR ', ') AS StudentOutcomes,
    GROUP_CONCAT(`ABETCRSES_GPIS`.`GPIIdx` ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI` SEPARATOR ', ') AS GPIIdxes,
    GROUP_CONCAT(CONCAT_WS('-',`STNTOUTCMS`.`SO`, `GPIS`.`GPI`) ORDER BY `STNTOUTCMS`.`SO`, `GPIS`.`GPI` SEPARATOR ', ') AS GPIs
    FROM `AbetCourses` AS `ABETCRSES`
    LEFT JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` ON (`ABETCRSES`.`Idx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
    LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` ON (`ABETCRSES_GPIS`.`SOIdx`=`ABETCRSES_SOS`.`SOIdx` AND `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
    LEFT JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`ABETCRSES_SOS`.`SOIdx`=`STNTOUTCMS`.`Idx`) 
    LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ABETCRSES_GPIS`.`GPIIdx`)
    GROUP BY `ABETCRSES`.`Idx`";

// Create a subquery for assistants (to handle multiple assistants per course)
$assistantsQuery = "SELECT 
    `ASSNTS`.`AbetCourseIdx`,
    GROUP_CONCAT(`UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR ', ') AS AssistantNames,
    GROUP_CONCAT(`UA`.`Email` ORDER BY `UA`.`Name` SEPARATOR ', ') AS AssistantEmails
    FROM `AbetCourses_Assistants` AS `ASSNTS`
    INNER JOIN `UserAccounts` AS `UA` ON (`ASSNTS`.`Assistant`=`UA`.`Idx`)
    GROUP BY `ASSNTS`.`AbetCourseIdx`";

// Create a subquery for instructors (to handle multiple instructors per course)
$instructorsQuery = "SELECT 
    `AVCI`.`AVCourseIdx`,
    GROUP_CONCAT(`UA`.`Name` ORDER BY `UA`.`Name` SEPARATOR ', ') AS InstructorNames
    FROM `AVCoursesInstructors` AS `AVCI`
    INNER JOIN `UserAccounts` AS `UA` ON (`AVCI`.`Instructor`=`UA`.`Idx`)
    GROUP BY `AVCI`.`AVCourseIdx`";

// Main query - INNER JOIN for assistants to only show courses with assigned assistants
$table = 'AbetCourses';
$joinQuery = " FROM `AbetCourses` AS `ABETCRSES` 
    INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear`=`AYS`.`Idx`) 
    INNER JOIN `AcademicPrograms` AS `APS` ON (`ABETCRSES`.`AcademicProgram`=`APS`.`Idx`) 
    INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx`= `AVCRSES`.`Idx`) 
    LEFT JOIN `Semesters` AS `SMSTRS` ON (`AVCRSES`.`Semester`=`SMSTRS`.`SemesterCode`)
    INNER JOIN ($assistantsQuery) AS `ASSNTS_DATA` ON (`ABETCRSES`.`Idx`=`ASSNTS_DATA`.`AbetCourseIdx`)
    LEFT JOIN ($instructorsQuery) AS `INSTRS_DATA` ON (`AVCRSES`.`Idx`=`INSTRS_DATA`.`AVCourseIdx`)
    LEFT JOIN ($groupedDataQuery) AS `GROUPED_DATA` ON (`ABETCRSES`.`Idx` = `GROUPED_DATA`.`CourseIdx`)";

// Table's primary key
$primaryKey = '`ABETCRSES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
$columns = array(
    array('db' => '`ABETCRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_'.$row[0];
    }),
    array( 'db' => '`ABETCRSES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`ABETCRSES`.`Reference`', 'dt' => 'ReferenceCrsAssessment', 'field' => 'ReferenceCrsAssessment', 'as' => 'ReferenceCrsAssessment'),
    array( 'db' => '`ABETCRSES`.`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => '`ABETCRSES`.`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram'),
    array( 'db' => '`APS`.`Name`', 'dt' => 'AcademicProgramName', 'field' => 'AcademicProgramName', 'as' => 'AcademicProgramName'),
    array( 'db' => '`AYS`.`AcademicYear`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array(
        'db' => "CONCAT(`AYS`.`AcademicYear`, ' (', `SMSTRS`.`Explanation`, ')')",
        'dt' => 'AcademicYearCustomInfo',
        'field' => 'AcademicYearCustomInfo',
        'as' => 'AcademicYearCustomInfo'
    ),
    array(
        'db' => "CONCAT(`AVCRSES`.`Subject`, ' ', `AVCRSES`.`Num`, ' ', `AVCRSES`.`Title`, ' (CRN: ', `AVCRSES`.`CRN`, ')')",
        'dt' => 'CourseCustomInfo',
        'field' => 'CourseCustomInfo',
        'as' => 'CourseCustomInfo'
    ),
    array( 'db' => '`AVCRSES`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`AVCRSES`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`AVCRSES`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    // Use the instructor names from the joined subquery
    array(
        'db' => 'IFNULL(`INSTRS_DATA`.`InstructorNames`, \'\')',
        'dt' => 'Instructor',
        'field' => 'Instructor',
        'as' => 'Instructor'
    ),
    array( 'db' => '`AVCRSES`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`AVCRSES`.`Idx`', 'dt' => 'AVCourseIdx', 'field' => 'AVCourseIdx', 'as' => 'AVCourseIdx'),
    array( 'db' => '`AVCRSES`.`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => '`AVCRSES`.`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => '`AVCRSES`.`Actual`', 'dt' => 'Enrollment', 'field' => 'Enrollment', 'as' => 'Enrollment'),
    array( 'db' => '`AVCRSES`.`Syllabus`', 'dt' => 'CourseSyllabus', 'field' => 'CourseSyllabus', 'as' => 'CourseSyllabus'),
    array( 'db' => '`SMSTRS`.`Explanation`', 'dt' => 'SemesterTxt', 'field' => 'SemesterTxt', 'as' => 'SemesterTxt'),
    array( 'db' => '`ASSNTS_DATA`.`AssistantNames`', 'dt' => 'ASST', 'field' => 'ASST', 'as' => 'ASST'),
    array( 'db' => '`ABETCRSES`.`Syllabus`', 'dt' => 'AbetSyllabus', 'field' => 'AbetSyllabus', 'as' => 'AbetSyllabus'),
    array( 'db' => '`GROUPED_DATA`.`SOIdxes`', 'dt' => 'SOIdxes', 'field' => 'SOIdxes', 'as' => 'SOIdxes'),
    array( 'db' => '`GROUPED_DATA`.`StudentOutcomes`', 'dt' => 'StudentOutcomes', 'field' => 'StudentOutcomes', 'as' => 'StudentOutcomes'),
    array( 'db' => '`GROUPED_DATA`.`GPIIdxes`', 'dt' => 'GPIIdxes', 'field' => 'GPIIdxes', 'as' => 'GPIIdxes'),
    array( 'db' => '`GROUPED_DATA`.`GPIs`', 'dt' => 'GPIs', 'field' => 'GPIs', 'as' => 'GPIs'),
    array( 'db' => '(SELECT GROUP_CONCAT(CONCAT(gpi_idx, \':\', measure_count) ORDER BY gpi_idx SEPARATOR \', \') FROM (SELECT `ABETCRSES_GPIS`.`GPIIdx` as gpi_idx, COUNT(DISTINCT `ASSSMNT`.`Idx`) as measure_count FROM `AbetCourses_GPIs` AS `ABETCRSES_GPIS` LEFT JOIN `AssessmentMeasures` AS `ASSSMNT` ON (`ASSSMNT`.`AbetCourseIdx`=`ABETCRSES`.`Idx` AND `ASSSMNT`.`GPI`=`ABETCRSES_GPIS`.`GPIIdx`) WHERE `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES`.`Idx` GROUP BY `ABETCRSES_GPIS`.`GPIIdx`) as gpi_counts)', 'dt' => 'AssessmentMeasuresCount', 'field' => 'AssessmentMeasuresCount', 'as' => 'AssessmentMeasuresCount'),
    array(
        'db' => '(SELECT COUNT(DISTINCT `SAMPLES`.`Idx`) 
              FROM `AssessmentMeasures` AS `MEASURES` 
              LEFT JOIN `AssessmentMeasureSamples` AS `SAMPLES` 
                ON (`SAMPLES`.`AssessmentMeasureIdx` = `MEASURES`.`Idx`) 
              WHERE `MEASURES`.`AbetCourseIdx` = `ABETCRSES`.`Idx`)',
        'dt' => 'StudentSamplesCount',
        'field' => 'StudentSamplesCount',
        'as' => 'StudentSamplesCount'
    ),
    array(
        'db' => 'COALESCE(`ABETCRSES`.`Reference`, `ABETCRSES`.`Idx`)',
        'dt' => 'LinkedGroupId',
        'field' => 'LinkedGroupId',
        'as' => 'LinkedGroupId'
    ),
    array(
        'db' => 'CONCAT(`AVCRSES`.`Semester`, \'_\', `AVCRSES`.`CRN`)',
        'dt' => 'CourseSection',
        'field' => 'CourseSection',
        'as' => 'CourseSection'
    ),
    array(
        'db' => 'IF(`ABETCRSES`.`Reference` IS NULL OR `ABETCRSES`.`Reference` = 0, 0, 1)',
        'dt' => 'IsReference',
        'field' => 'IsReference',
        'as' => 'IsReference'
    ),
    array( 'db' => '`ASSNTS_DATA`.`AssistantEmails`', 'dt' => 'AssistantEmails', 'field' => 'AssistantEmails', 'as' => 'AssistantEmails'),
);

$extraWhere = "";

// Filter by academic year if specified
if ($AcademicYear != "" && $AcademicYear != "all") {
    if ($extraWhere !="") $extraWhere .= " AND ";
    $extraWhere .= "`ABETCRSES`.`AcademicYear`='".$AcademicYear."'";
}

// Apply access control filters based on user role
if (isset($TAEmail)) {
    // Used for administrator to view specific assistant's courses
    if ($extraWhere !="") $extraWhere .= " AND ";
    $extraWhere .= "FIND_IN_SET('" . $TAEmail . "', REPLACE(`ASSNTS_DATA`.`AssistantEmails`, ', ', ',')) > 0";
} else if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true) {
    // For program directors or chairs - filter by granted programs
    $proramCondition = '';
    foreach($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'] as $program => $bool) {
        if ($bool == true) {
            if ($proramCondition != '') $proramCondition .= " OR ";
            $proramCondition .= " `APS`.`Idx` = $program";
        }
    }
    if ($extraWhere !="") $extraWhere .= " AND ";
    $extraWhere .= " ($proramCondition)";
} else {
    // For regular assistants - show only their assigned courses
    if ($extraWhere !="") $extraWhere .= " AND ";
    $extraWhere .= "FIND_IN_SET('" . $_SESSION['ATLAS_LOGIN_USEREMAIL'] . "', REPLACE(`ASSNTS_DATA`.`AssistantEmails`, ', ', ',')) > 0";
}

// No GROUP BY needed since we're using subqueries
$groupBy = "";

// Define custom ORDER BY for proper linked course grouping
$customOrderBy = "`AYS`.`AcademicYear` DESC, 
                  `AVCRSES`.`Semester` DESC,
                  COALESCE(`ABETCRSES`.`Reference`, `ABETCRSES`.`Idx`) ASC,
                  IF(`ABETCRSES`.`Reference` IS NULL, 0, 1) ASC,
                  `AVCRSES`.`CRN` ASC,
                  `ABETCRSES`.`Idx` ASC";

require( 'ssp.join.class.php' );
require_once(__DIR__ . '/../php_include/dbconnection.php');

echo json_encode(
    SSP::joinquery_ordered( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, $customOrderBy, false)
);
