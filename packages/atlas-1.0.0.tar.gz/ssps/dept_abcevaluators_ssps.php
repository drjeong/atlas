<?php
/**
 * Listing abet courses and evalutors
 * File: dept_abcevaluators_ssps.php
 * Description: listing abet courses and their evaluators
 *
 * 03/04/2024 - initial version created
 * 08/09/2026 - Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */
include_once 'session_handler.php';

$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = '';
$joinQuery = " FROM
(
    SELECT `ABETCRSES`.`Idx`, `ABETCRSES`.`AcademicYear`, `ABETCRSES`.`Level`, `AYS`.`AcademicYear` AS `AcademicYearInfo`, 
        `ABETCRSES`.`AcademicProgram`, 
        FUNC_GetCourseLevel(`ABETCRSES`.`Level`) AS `CourseLevel`,
        `SMSTRS`.`Explanation` AS `Semester`, 
        `AVCRSES`.`CRN`, `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Title`, `AVCRSES`.`Credits`, 
        `ABETCRSES`.`Syllabus`, `ACDEMICPRMS`.`Degree`,
        GROUP_CONCAT(`UA`.`Name`) AS `Instructor`, 
        MAX(`CNTIMPRVMNT`.`EvaluatorsReflection`) AS `EvaluatorsReflection`
    FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AVCourses` AS `AVCRSES` ON (`ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx` 
            AND `ABETCRSES`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."')
        LEFT JOIN `Semesters` AS `SMSTRS` ON (`AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`)
        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` ON (`AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`) 
        INNER JOIN `UserAccounts` AS `UA` ON (`AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`)
        INNER JOIN `AcademicYears` AS `AYS` ON (`ABETCRSES`.`AcademicYear` = `AYS`.`Idx`) 
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
        LEFT JOIN `ContinuousImprovement` AS `CNTIMPRVMNT` ON (`CNTIMPRVMNT`.`AbetCourseIdx` = `ABETCRSES`.`Idx`) 
    GROUP BY `ABETCRSES`.`Idx`, `ABETCRSES`.`AcademicYear`, `ABETCRSES`.`Level`, `AYS`.`AcademicYear`, 
        `ABETCRSES`.`AcademicProgram`, `SMSTRS`.`Explanation`, `AVCRSES`.`CRN`, `AVCRSES`.`Subject`, 
        `AVCRSES`.`Num`, `AVCRSES`.`Title`, `AVCRSES`.`Credits`, `ABETCRSES`.`Syllabus`, `ACDEMICPRMS`.`Degree`
) AS A
LEFT JOIN
(
    SELECT `ABETCRSES`.`Idx` AS `AbetCourseIdx`, `ABETCRSES`.`AcademicYear`, 
        `ABETCRSES`.`AcademicProgram`,  
        GROUP_CONCAT(`EVALUATORS`.`Evaluator`) AS `Evaluators`,
        GROUP_CONCAT(`UA`.`Name`) AS `Evaluator_Names`
    FROM `AbetCourses` AS `ABETCRSES` 
    	INNER JOIN `AbetCourses_Evaluators` AS `EVALUATORS` ON (`ABETCRSES`.`Idx` = `EVALUATORS`.`AbetCourseIdx`
    	    AND `ABETCRSES`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."')
        INNER JOIN `UserAccounts` AS `UA` ON (`EVALUATORS`.`Evaluator` = `UA`.`Idx`) 
    GROUP BY `ABETCRSES`.`Idx`, `ABETCRSES`.`AcademicYear`, `ABETCRSES`.`AcademicProgram`
) AS B
ON (A.`Idx` = B.`AbetCourseIdx` AND A.`AcademicYear` = B.`AcademicYear` AND A.`AcademicProgram` = B.`AcademicProgram` )";

// Table's primary key
$primaryKey = 'A.`Idx`';

// Array of database columns
$columns = array(
    array('db' => 'A.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_'.$row[0];
    }),
    array( 'db' => 'A.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => 'A.`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => 'A.`AcademicYearInfo`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => 'A.`CourseLevel`', 'dt' => 'Level', 'field' => 'Level', 'as' => 'Level'),
    array( 'db' => 'A.`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => 'A.`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => 'A.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => 'A.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => 'A.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => 'A.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => 'A.`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram'),
    array( 'db' => 'A.`Degree`', 'dt' => 'Degree', 'field' => 'Degree', 'as' => 'Degree'),
    array( 'db' => 'B.`Evaluators`', 'dt' => 'Evaluators', 'field' => 'Evaluators', 'as' => 'Evaluators'),
    array( 'db' => 'B.`Evaluator_Names`', 'dt' => 'Evaluator_Names', 'field' => 'Evaluator_Names', 'as' => 'Evaluator_Names'),
    array( 'db' => 'A.`Instructor`', 'dt' => 'Instructor', 'field' => 'Instructor', 'as' => 'Instructor')
);

require( 'ssp.join.class.php' );

if (empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']])) {
    // current selected program not allowed to access
    $extraWhere = "A.`AcademicProgram` = ''";
} else {
    $extraWhere = "A.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";
}

if ($AcademicYear != "" && $AcademicYear != "all")
    $extraWhere .= " AND A.`AcademicYear`='".$AcademicYear."'";
$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);


