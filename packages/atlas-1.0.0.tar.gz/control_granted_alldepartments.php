<!--                    Displaying extra menu-->
<?php
/**
 *
 * Listing Department Courses
 * Description: Listing Department Courses
 * Author: Dong Hyun Jeong
 *
 * 04/07/2025 - initial version created
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// First handle the form submission
if (array_key_exists('CH_DEPARTMENT', $_POST)) {
    $_SESSION['ATLAS_SELECTED_DEPARTMENT'] = trim($_POST['CH_DEPARTMENT']); // user changed
}
// Set default if not set
elseif (!isset($_SESSION['ATLAS_SELECTED_DEPARTMENT'])) {
    $_SESSION['ATLAS_SELECTED_DEPARTMENT'] = $_SESSION['ATLAS_LOGIN_AFFILATION'];
}

$url = "//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
$escaped_url = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
?>

<form name='change_deprt_frm' id='change_deprt_frm' action='<?php echo($escaped_url);?>' method='post'>
    <div class="input-group label-primary" style="background-color:white;">
        <span class="label-default input-group-addon" style="color:white; font-weight: bold;">SELECTED DEPARTMENT:</span>
        <select name="CH_DEPARTMENT" id="departmentSelect" class="input-sm form-control" style="width:400px;" onchange="this.form.submit();">
            <?php
            require_once(__DIR__ . '/php_include/dbconnection_class.php');
            $DBCONNECTION = new Dbconnection();

            // First get the Level 0 affiliation
            $LevelZeroQuery = "SELECT `Idx`, `Name` FROM `Affiliations` WHERE `Level`='0' LIMIT 1;";
            $DBCONNECTION->sendquery($LevelZeroQuery);
            $levelZeroRow = $DBCONNECTION->fetch_assoc();

            // Now get user-specific affiliations
            $Query = "SELECT `AFFILATN`.`Idx`, `AFFILATN`.`Name`
            FROM `UserAccounts` AS `UA`
                     INNER JOIN `AccessControls` AS `ACS` ON (`UA`.`Idx` = `ACS`.`UserAccount`)
                     LEFT JOIN `AcademicPrograms` AS `APS` ON (`ACS`.`AcademicProgram` = `APS`.`Idx`)
                     LEFT JOIN `Affiliations` AS `AFFILATN` ON (`AFFILATN`.`Idx`=`APS`.`Department`)
            WHERE  `UA`.`Idx`=".$_SESSION['ATLAS_LOGIN_USERIDX']."
            GROUP BY `AFFILATN`.`Idx`
            ORDER BY `AFFILATN`.`Name`;";

            $DBCONNECTION->sendquery($Query);

            $results = [];

            // Add level 0 affiliation first if it exists
            if ($levelZeroRow) {
                $results[] = $levelZeroRow;
            }

            // Add other affiliations
            while ($row = $DBCONNECTION->fetch_assoc()) {
                $results[] = $row;
            }

            $firstItem = null;
            $hasMatch = false;

            // Process results to find first item and match
            foreach ($results as $row) {
                if ($firstItem === null) {
                    $firstItem = $row['Idx'];
                }

                // Check if we have a match for the selected department
                if ($_SESSION['ATLAS_SELECTED_DEPARTMENT'] == $row['Idx']) {
                    $hasMatch = true;
                }
            }

            // If no match found, use the first item
            if (!$hasMatch && $firstItem !== null) {
                $_SESSION['ATLAS_SELECTED_DEPARTMENT'] = $firstItem;
            }

            // Now output the options
            foreach ($results as $row) {
                $selected = ($_SESSION['ATLAS_SELECTED_DEPARTMENT'] == $row['Idx']) ? ' selected="selected"' : '';
                echo '<option value="'.htmlspecialchars($row['Idx'], ENT_QUOTES, 'UTF-8').'"'.$selected.' style="font-size:10pt;">'.htmlspecialchars($row['Name'], ENT_QUOTES, 'UTF-8').'</option>';
            }

            unset($DBCONNECTION);
            ?>
        </select>
    </div><!-- /input-group -->
</form>

<script>
// Alternative: Using event listener (more modern approach)
document.addEventListener('DOMContentLoaded', function() {
    var departmentSelect = document.getElementById('departmentSelect');
    if (departmentSelect) {
        departmentSelect.addEventListener('change', function() {
            this.form.submit();
        });
    }
});
</script>