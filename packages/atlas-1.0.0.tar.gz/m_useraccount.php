<?php
/**
 * Management of User Accounts
 * Description: managing user accounts
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 03/01/2022 - modify row selection with using the multi-row selection feature in DataTables.
 * 03/04/2022 - add column-based search option in DataTables.
 */


include('checker_systemadmin.php');
include('header.php');

?>

<script src="js/datatable-utils-search.min.js"></script>
<script src="js/datatable-utils-rowselector.min.js?v=0.0.1"></script>

<script type="text/javascript">

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        SAME_ITEM_EXIST: '0x00200011',
        SAME_ITEM_EXIST2: '0x00200012',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
    };

    function CheckedItemUpdate(UserIdx, Option, Checked)
    {
        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case "0x11111111":
                        Swal.fire({title: "Updated!", text: "Access privilege has been changed!", timer:2000, icon: "success"});
                        break;
                    default:
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                }
                DataTable_UserAccounts.ajax.reload(null, false);
            }
        }
        xmlhttp.open("GET","m_useraccount_updatechecked_ajax.php?id="+encodeURIComponent(UserIdx)
            +"&option="+encodeURIComponent(Option)
            +"&checked="+encodeURIComponent(Checked)
            ,true);
        xmlhttp.send();
    }

    async function UpdateUserAccount(_ID, _Name, _Email, _Position, _Affiliation, _AccessControl){
        try {
            const willUpdate = await async_commons.showConfirmDialog(
                `Are you sure you want to update the user(${_Name})'s information?`,
                { title: 'UPDATE', confirmButtonText: 'Yes, update it!' }
            );

            if (!willUpdate.value) return;
            const result = await async_commons.makeApiCall('m_useraccount_update_ajax.php', {
                id: _ID,
                name: _Name,
                email: _Email,
                pos: _Position,
                aff: _Affiliation,
                acc: _AccessControl
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'The information has been updated!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function RemoveUserAccount(id, name){
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted user account (<span style="color:red">${name}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('m_useraccount_remove_ajax.php', {
                id: id
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected user account has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected user account cannot be deleted!! It has been used already!!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function ModifyUserAccount(data)
    {
        const _ID=data.Idx;
        const _Email=data.Email;
        const _Name=data.Name;
        const _Position=data.Position;
        const _Affiliation=data.Affiliation;
        const _AccessControl=data.Cntl;

        const content =
            `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
             <input type="hidden" name="_ID" value="${_ID}">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
             <div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Email Address<span style="color:red">*</span></span>
                  <input type="text" name="_Email" id="_Email" class="input-sm form-control" value="${_Email}" placeholder="account@udc.edu" required>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Name<span style="color:red">*</span></span>
                  <input type="text" name="_Name" id="_Name" class="input-sm form-control" value="${_Name}" placeholder="" required>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Position<span style="color:red">*</span></span>
                  <select name="_Position" class="input-sm form-control"><?php include('inc_positioninfo.php'); ?></select>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Affiliations&nbsp;Name<span style="color:red">*</span></span>
                  <select name="_Affiliation" class="input-sm form-control"><?php include('inc_affiliationinfo.php'); ?></select>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Access&nbsp;Control<span style="color:red">*</span></span>
                <div style="margin:5px; height: 200px; overflow-y: auto;">
                  <?php include('inc_academicprograminfo.php'); ?>
                </div>
              </div>
             </div>
             </td></tr>
             </table></form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">EDIT USER ACCOUNT</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;SAVE",
                    className: 'btn-success',
                    callback: function(){
                        if (ValidateItems()===false) return false;

                        const _AccessControl = Array.from(document.querySelectorAll('input[name="_AccessControl"]:checked'))
                            .map(cb => cb.value).join(',');

                        bootbox.hideAll();

                        UpdateUserAccount(
                            popupfrm._ID.value,
                            popupfrm._Name.value,
                            popupfrm._Email.value,
                            popupfrm._Position.value,
                            popupfrm._Affiliation.value,
                            _AccessControl);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_UserID").focus();
        });

        popupfrm._Position.value = _Position;
        popupfrm._Affiliation.value = _Affiliation;

        if (_AccessControl !== "" && _AccessControl != null){
            try {
                const aps = _AccessControl.split(",").map(val => val.trim());
                const checkboxes = document.querySelectorAll('input[name="_AccessControl"]');
                checkboxes.forEach(checkbox => {
                    if (aps.includes(checkbox.value)) {
                        checkbox.checked = true;
                    }
                });
            } catch (e) {
                console.error('Error setting checkboxes:', e);
            }
        }
    }

    function AddUserAccount(_Name='', _Email='', _Position='', _Affiliation='', _AccessControl='')
    {
        const content =
            `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
             <div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Email Address<span style="color:red">*</span></span>
                  <input type="text" name="_Email" id="_Email" class="input-sm form-control" value="${_Email}" placeholder="account@udc.edu" required>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Name<span style="color:red">*</span></span>
                  <input type="text" name="_Name" id="_Name" class="input-sm form-control" value="${_Name}" placeholder="" required>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Position<span style="color:red">*</span></span>
                  <select name="_Position" class="input-sm form-control"><option value=""></option><?php include('inc_positioninfo.php'); ?></select>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Affiliations&nbsp;Name<span style="color:red">*</span></span>
                  <select name="_Affiliation" class="input-sm form-control"><option value=""></option><?php include('inc_affiliationinfo.php'); ?></select>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Access&nbsp;Control<span style="color:red">*</span></span>
                <div style="margin:5px; height: 200px; overflow-y: auto;">
                  <?php include('inc_academicprograminfo.php'); ?>
                </div>
              </div>
             </div>
             </td></tr>
             </table></form>`;

        createModalDialog({
            title: `
                    <span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;
                    <span style="font-size:16pt;font-weight: bold;">ADD USER ACCOUNT</span>`,
            message: content,
            buttons: {
                ok: {
                    label: '<span class="glyphicon glyphicon-ok"></span>&nbsp;ADD',
                    className: 'btn-success',
                    callback: function(){
                        if (ValidateItems()===false) return false;

                        const tmpAccessControl = Array.from(document.querySelectorAll('input[name="_AccessControl"]:checked'))
                            .map(cb => cb.value).join(',');

                        AddUserAccount_Perform(
                            popupfrm._Name.value,
                            popupfrm._Email.value,
                            popupfrm._Position.value,
                            popupfrm._Affiliation.value,
                            tmpAccessControl);
                    }
                },
                cancel: {
                    label: '<span class="glyphicon glyphicon-remove"></span>&nbsp;CANCEL',
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_UserID").focus();
        });

        if (_Position!=='') popupfrm._Position.value = _Position;
        if (_Affiliation!=='') popupfrm._Affiliation.value = _Affiliation;
        if (_AccessControl!=='') {
            const accessControls = _AccessControl.split(',');
            accessControls.forEach(value => {
                const checkbox = document.querySelector(`input[name="_AccessControl"][value="${value}"]`);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });
        }
    }

    async function AddUserAccount_Perform(_Name, _Email, _Position, _Affiliation, _AccessControl){
        try {

            const result = await async_commons.makeApiCall('m_useraccount_add_ajax.php', {
                name: _Name,
                email: _Email,
                pos: _Position,
                aff: _Affiliation,
                acc: _AccessControl
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'The user account has been added!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage('ERROR', 'The same user account (email address) exists!');
                    // Re-open the add dialog
                    AddUserAccount(_Name, _Email, _Position, _Affiliation, _AccessControl);
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST2: {
                    await async_commons.showErrorMessage('ERROR', 'The same user account (name) exists!');
                    // Re-open the add dialog
                    AddUserAccount(_Name, _Email, _Position, _Affiliation, _AccessControl);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function ValidateItems()
    {
        var exp = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
        if (popupfrm._Email.value.isEmpty())
        {
            popupfrm._Email.focus();
            Swal.fire({title:"ERROR", text: "Email address is not entered!!", icon:"error"});
            return false;
        }
        else if (exp.test(popupfrm._Email.value) === false)
        {
            popupfrm._Email.focus();
            Swal.fire({title:"ERROR", text: "Email address is not correctly entered!!", icon:"error"});
            return false;
        }
        else if (popupfrm._Name.value.isEmpty())
        {
            popupfrm._Name.focus();
            Swal.fire({title:"ERROR", text: "Name is not entered!!", icon:"error"});
            return false;
        }
        else if (popupfrm._Position.value.isEmpty() || popupfrm._Position.value == "NULL")
        {
            popupfrm._Position.focus();
            Swal.fire({title:"ERROR", text: "Position is not selected!!", icon:"error"});
            return false;
        }
        else if (popupfrm._Affiliation.value.isEmpty() || popupfrm._Affiliation.value == "NULL")
        {
            popupfrm._Affiliation.focus();
            Swal.fire({title:"ERROR", text: "Affiliation is not selected!!", icon:"error"});
            return false;
        }
        return true;
    }

    function SetPassword(id, name, email)
    {
        //
        // const content = ''
        //     + '<form name="popupfrm" id="popupfrm" autocomplete="off">'
        //     + '<table style="border-spacing:0; padding:0; width:100%;">'
        //     + '<caption><span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:bottom;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">SET USER PASSWORD</br></br></span></caption>'
        //     + '<input type="hidden" name="id" value="'+id+'">'
        //     + '<div class="hidden"><input type="password"/></div>'
        //     + '<tr><td width="150" align="right"><span style="font-size:10pt;"><span style="color:red">*</span>Choose Password:&nbsp;</span></td><td align="left"><input type="password" name="passwd1" style="width:350px;font-size:10pt;" value=""></td></tr>'
        //     + '<tr><td width="150" align="right"><span style="font-size:10pt;"><span style="color:red">*</span>Re-Enter Password:&nbsp;</span></td><td align="left"><input type="password" name="passwd2" style="width:350px;font-size:10pt;" value=""></td></tr>'
        //     + '<tr><td style="height:5px"></td></tr></table>'
        //     + '<div align="right"><button onclick="SetUserPassword();return false;">UPDATE NOW</button><button class="cancel" onclick="popupWin();return false;">CANCEL</button></div>';
        // popupWin(content, 500);
        // popupfrm.passwd1.focus();
    }

    function SetUserPassword()
    {
        if (popupfrm.passwd1.value != popupfrm.passwd2.value)
        {
            Swal.fire({
                  title: "Password Mismatch!",
                  text: "Password does not match!!",
                  icon: "error"
            });
            return;
        }

        let id = popupfrm.id.value;
        let pass = popupfrm.passwd1.value;

        let xmlhttp;
        if (window.XMLHttpRequest) {
        // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case "0x11111111": {
                        Swal.fire({
                            title: "Completed!",
                            text: "Password updated successfully!!",
                            icon: "success",
                            timer: 2000
                        });
                    }
                    break;
                    default:
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                }
            }
        };
        xmlhttp.open("POST", "m_useraccount_updatepasswd_ajax.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send("id="+id+"&pass="+pass);
    }

    function ResetPassword(id, name, email)
    {
        Swal.fire({
            title: "Are you sure?",
            html: "Reset password for (<span style=\"color:red\">"+name+"</span>)",
            icon: "question",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, reset password!"
        }).then(function(result){
            if (result.value)
            {
                let xmlhttp;
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp=new XMLHttpRequest();
                } else { // code for IE6, IE5
                    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange=function() {
                    if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                        var res = xmlhttp.responseText.split("]]");

                        switch (res[0])
                        {
                            case "0x11111111": {
                                Swal.fire({
                                    title: "Completed!",
                                    html: "Password reset has been performed! <br/>Temporarily assigned password is <span style='color:red;font-weight:bold;'>"+res[1]+"</span>.<br/><br/> Do you want to email the temporarily assigned password to <br/><span style='color:blue'>"+name+" ("+email+")</span>?",
                                    icon: "success",
                                    showCancelButton: true,
                                    confirmButtonColor: "#DD6B55",
                                    confirmButtonText: "Yes, Please email it!!"
                                }).then(function(result){
                                    if (result.value) { // send "yes"
                                        Email_ResetPassword(name, email, res[1]);
                                    }
                                });
                            }
                                break;
                            default:
                                Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        }
                    }
                }
                xmlhttp.open("GET","m_useraccount_resetpasswd_ajax.php?id="+id,true);
                xmlhttp.send();
            }
        });
    }

    function Email_ResetPassword(name, email, password)
    {
        let xmlhttp;
        if (window.XMLHttpRequest) {
        // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        const postdata = "name="+encodeURIComponent(name)
            +"&email="+encodeURIComponent(email)
            +"&password="+encodeURIComponent(password);

        xmlhttp.open("POST","m_useraccount_email_ajax.php",true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case "0x11111111":
                        Swal.fire({title: "Sent!",text: "The temporarily assigned password has been sent!!",timer:2000, icon: "success" });
                    break;
                    default:
                        Swal.fire({title:"ERROR", text: "The temporarily assigned password has not been sent!", icon:"error"});
                }
            }
        }
        xmlhttp.send(postdata);
    }

    function GetSelectedUsers()
    {
        let selected = DataTable_UserAccounts.rows({selected: true}).data();
        let courses_array = [];
        for(let i = 0; i < selected.length; ++i) {
            courses_array.push(selected[i].Idx);
        }
        let parameter = courses_array.join([separator = '|']);
        return [selected.length, parameter];
    }

    function AssignDefaultPassword()
    {
        let parameter = GetSelectedUsers();
        if (parameter[0] === 0) {
            Swal.fire({title: "ERROR", text: "Please select user account first!", icon: "error"});
            return;
        }

        Swal.fire({
            title: "Are you sure?",
            html: "Default Password will be set with name (appeared in the university system) - case sensitive!",
            icon: "question",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes, Assign it!"
        }).then(function (result) {
            if (result.value) {
                let xmlhttp;
                if (window.XMLHttpRequest) {
                    // code for IE7+, Firefox, Chrome, Opera, Safari
                    xmlhttp = new XMLHttpRequest();
                } else { // code for IE6, IE5
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function () {
                    if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
                        switch (xmlhttp.responseText.trim()) {
                            case"0x11111111": {
                                DataTable_UserAccounts.rows().deselect();
                                DataTable_UserAccounts.ajax.reload(null, false);
                                Swal.fire({
                                    title: "UPDATED",
                                    text: "The information has been updated!",
                                    icon: "success",
                                    timer: 2000
                                });
                                break;
                            }
                            default: {
                                Swal.fire({
                                    title: "ERROR",
                                    text: "Unexpected error found. Please contact the system administrator!",
                                    icon: "error"
                                });
                                break;
                            }
                        }
                    }
                }
                const param = "_UList=" + parameter[1];
                xmlhttp.open("POST", "m_useraccount_assigndefaultpassword_ajax.php", true);
                xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlhttp.send(param);
            }
        });
    }

    function AssignPosition()
    {
        const parameter = GetSelectedUsers();
        if (parameter[0]===0)
        {
            Swal.fire({title:"ERROR", text: "You need to check at least one user!!", icon:"error"});
            return;
        }

        const content = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<table style="border-spacing:0; padding:0; width:100%;">'
            + '<tr><td colspan="2">'
            + '<div class="input-group" style="width:100%">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Position<span style="color:red">*</span></span>'
            + '     <select name="_Position" class="input-sm form-control"><option value=""></option><?php include('inc_positioninfo.php'); ?></select>'
            + ' </div>'
            + '</div>'
            + '</td></tr>'
            + '</table></form>';

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN POSITION</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;ASSIGN",
                    className: 'btn-success',
                    callback: function(){
                        if (popupfrm._Position.value.isEmpty() || popupfrm._Position.value == "NULL")
                        {
                            popupfrm._Position.focus();
                            Swal.fire({title:"ERROR", text: "Position is not selected!!", icon:"error"});
                            return false;
                        }
                        AssignPosition_Perform(
                            popupfrm._Position.value,
                            parameter[1]);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_Position").focus();
        });
    }

    function AssignPosition_Perform(_Position, _UserList)
    {
        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case"0x11111111": {
                        DataTable_UserAccounts.rows().deselect();
                        DataTable_UserAccounts.ajax.reload(null, false);

                        Swal.fire({
                            title: "UPDATED",
                            text: "The information has been updated!",
                            icon: "success",
                            timer: 2000});
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }
        const param = "_Position="+_Position+"&_UList="+_UserList;
        xmlhttp.open("POST", "m_useraccount_assignposition_ajax.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send(param);
    }

    function AssignAffiliation()
    {
        const parameter = GetSelectedUsers();
        if (parameter[0]===0)
        {
            Swal.fire({title:"ERROR", text: "You need to check at least one user!!", icon:"error"});

            return;
        }

        const content = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<table style="border-spacing:0; padding:0; width:100%;">'
            + '<tr><td colspan="2">'
            + '<div class="input-group" style="width:100%">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Affiliations&nbsp;Name<span style="color:red">*</span></span>'
            + '     <select name="_Affiliation" class="input-sm form-control"><?php include('inc_affiliationinfo.php'); ?></select>'
            + ' </div>'
            + '</div>'
            + '</td></tr>'
            + '</table></form>';

        createModalDialog({
            width: '700px',
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN AFFILIATION</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;ASSIGN",
                    className: 'btn-success',
                    callback: function(){
                        if (popupfrm._Affiliation.value.isEmpty() || popupfrm._Affiliation.value == "NULL")
                        {
                            popupfrm._Affiliation.focus();
                            Swal.fire({title:"ERROR", text: "Position is not selected!!", icon:"error"});
                            return false;
                        }
                        AssignAffiliation_Perform(
                            popupfrm._Affiliation.value,
                            parameter[1]);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_Affiliation").focus();
        });
    }

    function AssignAffiliation_Perform(_Affiliation, _UserList)
    {
        let xmlhttp;
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp=new XMLHttpRequest();
        } else { // code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function() {
            if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                switch(xmlhttp.responseText.trim())
                {
                    case"0x11111111": {
                        DataTable_UserAccounts.rows().deselect();
                        DataTable_UserAccounts.ajax.reload(null, false);

                        Swal.fire({
                            title: "UPDATED",
                            text: "The information has been updated!",
                            icon: "success",
                            timer: 2000});
                        break;
                    }
                    default:{
                        Swal.fire({title:"ERROR", text: "Unexpected error found. Please contact the system administrator!", icon:"error"});
                        break;
                    }
                }
            }
        }
        const param = "_Affiliation="+_Affiliation+"&_UList="+_UserList;
        xmlhttp.open("POST", "m_useraccount_assignaffiliation_ajax.php", true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send(param);
    }


    /// Updated function - only manages UI state, doesn't change database values
    function handleCheckboxLogic(checkbox, data) {
        const isChecked = checkbox.checked;
        const checkboxType = checkbox.value;
        const rowElement = $(checkbox).closest('tr');

        // Get references to all three checkboxes in the same row
        const observerCheckbox = rowElement.find('.Observer')[0];
        const sysAdminCheckbox = rowElement.find('.SysAdmin')[0];
        const accessDisabledCheckbox = rowElement.find('.AccessDisabled')[0];

        if (checkboxType === 'AccessDisabled' && isChecked) {
            // If AccessDisabled is checked, just disable Observer and SysAdmin (don't uncheck them)
            observerCheckbox.disabled = true;
            sysAdminCheckbox.disabled = true;

        } else if (checkboxType === 'AccessDisabled' && !isChecked) {
            // If AccessDisabled is unchecked, re-enable Observer and SysAdmin
            observerCheckbox.disabled = false;
            sysAdminCheckbox.disabled = false;

        } else if (checkboxType === 'Observer' && isChecked) {
            // If Observer is checked, uncheck SysAdmin
            if (sysAdminCheckbox.checked) {
                sysAdminCheckbox.checked = false;
                CheckedItemUpdate(data.Idx, 'SysAdmin', false);
            }

        } else if (checkboxType === 'SysAdmin' && isChecked) {
            // If SysAdmin is checked, uncheck Observer
            if (observerCheckbox.checked) {
                observerCheckbox.checked = false;
                CheckedItemUpdate(data.Idx, 'Observer', false);
            }
        }
    }
</script>

<script class="init">
$(document).ready(function() {
	DataTable_UserAccounts = $("#useraccountinfo").DataTable({
		"processing": true,
		"serverSide": false,
		"lengthMenu": [ 30, 50, 80, 100, 150, 200 ],
		"ajax": "ssps/m_useraccount_ssps.php",
        "oLanguage": {"sInfoFiltered": ""},
		"columns": [
            {
                "data": null,
                "className": "select-checkbox",
                "defaultContent": "",
                "orderable": false
            },
			{ "data": 'Email' },
			{ "data": 'Name' },
            { "data": 'PositionName' },
            { "data": 'AffiliationName' },
            { "data": 'CntlNames' },
            { "data": 'Observer' },
            { "data": 'SystemAdmin' },
            { "data": 'Disabled' },
            {
                "data": 'LastLogin',
                "render": function(data, type, row) {
                    if (type === 'display') {
                        return formatLocalDateTime(data);
                    }
                    return data;
                }
            },
            { "data": "" } // used for representing menu options
		],
        "fnInitComplete": function(oSettings, json) {
            // Add "Clear Filter" button to Filter
            let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
            btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
            $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                $('#' + oSettings.sTableId).dataTable().fnFilter('');
            });
        },
        "fnDrawCallback": function() {
            $('#useraccountinfo tr td:nth-child(4)').css('text-align', 'center');
            $('#useraccountinfo tr td:nth-child(5)').css('text-align', 'center');
            $('#useraccountinfo tr td:nth-child(6)').css('text-align', 'center');
            $('#useraccountinfo tr td:nth-child(7)').css('text-align', 'center');
            $('#useraccountinfo tr td:nth-child(8)').css('text-align', 'center');
        },
		"columnDefs": [
            {
                "targets"  : 'no-sort',
                "orderable": false,
            },
            {
                "targets": '_all',
                "className": 'dt-center'
            },
            {
                "render": function(data, type, row) {
                    const uniqueId = `Observer_${row.Idx}`;
                    const checked = (data === "1" || data === 1) ? "checked" : "";
                    const disabled = (row.Disabled === "1" || row.Disabled === 1) ? "disabled" : "";

                    return `
            <input value="Observer"
                   id="${uniqueId}"
                   name="Observer"
                   class="Observer"
                   type="checkbox"
                   ${checked}
                   ${disabled} />
            <label for="${uniqueId}" class="sr-only">Observer</label>
        `;
                },
                "targets": 6
            },
            {
                "render": function(data, type, row) {
                    const uniqueId = `SysAdmin_${row.Idx}`;
                    const checked = (data === "1" || data === 1) ? "checked" : "";
                    const disabled = (row.Disabled === "1" || row.Disabled === 1) ? "disabled" : "";

                    return `
            <input value="SysAdmin"
                   id="${uniqueId}"
                   name="SysAdmin"
                   class="SysAdmin"
                   type="checkbox"
                   ${checked}
                   ${disabled} />
            <label for="${uniqueId}" class="sr-only">Admin</label>
        `;
                },
                "targets": 7
            },
            {
                "render": function ( data, type, row ) {
                    const uniqueId = `AccessDisabled_${row.Idx}`;
                    const checked = (data === "1" || data === 1) ? "checked" : "";

                    return `
                        <input value="AccessDisabled"
                               id="${uniqueId}"
                               name="AccessDisabled"
                               class="AccessDisabled"
                               type="checkbox"
                               ${checked} />
                        <label for="${uniqueId}" class="sr-only">Access Disabled</label>
                    `;
                },
                "targets": 8
            },
            {
            "targets": -1,
            "data": null,
            "orderable": false,
            "defaultContent": `<div style="width:100%;text-align:center;">
                    <button id="reset" class="btn btn-danger btn-xs glyphicon glyphicon-lock" style="min-height: 20px;"></button>&nbsp;
                    <button id="password" class="btn btn-danger btn-xs glyphicon glyphicon-lock" style="color:red;min-height: 20px;" disabled="true"></button>&nbsp;
                    <button id="modify" class="btn btn-danger btn-xs glyphicon glyphicon-wrench" style="min-height: 20px;"></button>&nbsp;
                    <button id="remove" class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="min-height: 20px;"></button></div>`
            }
        ],
        'select': {
            'style': 'multi'
        }
	});

    async_commons.setDataTable(DataTable_UserAccounts);

    // Initialize the column search functionality
    new DataTableSearch('#useraccountinfo', DataTable_UserAccounts);

    // $('#useraccountinfo').on('click', '.toggle-all', function() {
    //     $(this).closest("tr").toggleClass("selected");
    //     if($(this).closest("tr").hasClass("selected")){
    //         DataTable_UserAccounts.rows({ page: 'current' }).select();
    //     }
    //     else {
    //         DataTable_UserAccounts.rows({ page: 'current' }).deselect();
    //     }
    // });


    // Update the checkbox click handlers - keep existing handlers but remove the duplicate CheckedItemUpdate call
    $('#useraccountinfo').on('click', '.Observer', function() {
        const data = DataTable_UserAccounts.row($(this).parents('tr')).data();
        handleCheckboxLogic(this, data);
        CheckedItemUpdate(data.Idx, this.value, this.checked);
        return false;
    });

    $('#useraccountinfo').on('click', '.SysAdmin', function() {
        const data = DataTable_UserAccounts.row($(this).parents('tr')).data();
        handleCheckboxLogic(this, data);
        CheckedItemUpdate(data.Idx, this.value, this.checked);
        return false;
    });

    $('#useraccountinfo').on('click', '.AccessDisabled', function() {
        const data = DataTable_UserAccounts.row($(this).parents('tr')).data();
        handleCheckboxLogic(this, data);
        CheckedItemUpdate(data.Idx, this.value, this.checked);
        return false;
    });

    $('#useraccountinfo tbody').on( 'click', '#reset', function () {
        const data = DataTable_UserAccounts.row( $(this).parents('tr') ).data();
		ResetPassword(data.Idx, data.Name, data.Email);
		return false;
	} );

	$('#useraccountinfo tbody').on( 'click', '#password', function () {
        const data = DataTable_UserAccounts.row( $(this).parents('tr') ).data();
		SetPassword(data.Idx, data.Name, data.Email);
		return false;
	} );

	$('#useraccountinfo tbody').on( 'click', '#remove', function () {
        const data = DataTable_UserAccounts.row( $(this).parents('tr') ).data();
		RemoveUserAccount(data.Idx, data.Name);
		return false;
	} );

	$('#useraccountinfo tbody').on( 'click', '#modify', function () {
        const data = DataTable_UserAccounts.row( $(this).parents('tr') ).data();
		ModifyUserAccount(data);
		return false;
	} );

} );
</script>

<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">&nbsp;USER ACCOUNT MANAGEMENT</span>&nbsp;</p>
	</div>

	<div class="pagebacklayout_inner_noborder" style="min-height:400px">
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style="margin-bottom:0.1in;">
		<tr>
			<td style="width:20%">
			</td>
			<td style="width:80%; text-align:right">
                <button class="btn btn-danger btn-sm" onclick="AssignDefaultPassword();return false;">ASSIGN DEFAULT PASSWORD</button>
                <button class="btn btn-danger btn-sm" onclick="AssignPosition();return false;">ASSIGN POSITION</button>
                <button class="btn btn-danger btn-sm" onclick="AssignAffiliation();return false;">ASSIGN AFFILIATION</button>
                <button class="btn btn-danger btn-sm" onclick="AddUserAccount();return false;">ADD USER ACCOUNT</button>
            </td>
		</tr>
		</table>
		<div class="CSSTable_SSPSLIST">
			<table id="useraccountinfo" class="display" style="border-spacing:0; padding:0; width:100%;">
			<thead>
				<tr>
                    <th class="no-sort" style="width:3px"></th>
					<th style="width:80px">EMAIL ADDRESS</th>
					<th style="width:80px">NAME</th>
                    <th>PositionName</th>
                    <th>Affiliations Name</th>
                    <th>Programs to Control</th>
                    <th class="no-sort" >Observer (No control)</th>
                    <th class="no-sort" >System Administration</th>
                    <th class="no-sort" >Access Disabled</th>
                    <th>Last LogIn</th>
                    <th class="no-sort" style="width:100px">OPERATION</th>
				</tr>
			</thead>
            <tfoot>
            <tr>
                <th></th>
                <th>EMAIL ADDRESS</th>
                <th>NAME</th>
                <th>PositionName</th>
                <th>Affiliations Name</th>
                <th>Programs to Control</th>
                <th></th>
                <th></th>
                <th></th>
                <th>Last LogIn</th>
                <th></th>
            </tr>
            </tfoot>
			</table>
		</div>
		<table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
		<tr><td><span style='font-size:10pt;color:red;font-weight:bold;font-family: "Times New Roman", Georgia, Serif;'></span></td>
		<td style="text-align:right;"><span style="font-size:9pt;">
		<span class="btn btn-primary btn-xs glyphicon glyphicon-lock" style="pointer-events: none;"></span>: Auto Reset Password /
		<span class="btn btn-primary btn-xs glyphicon glyphicon-lock" style="color:red; pointer-events: none;"></span>: Manual Update Password /
		<span class="btn btn-primary btn-xs glyphicon glyphicon-wrench" style="pointer-events: none;"></span>: Modify Info. /
		<span class="btn btn-primary btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Remove Account
		</span></span></td></tr></table>
	</div>
</div>

<?php include('footer.php');?>

