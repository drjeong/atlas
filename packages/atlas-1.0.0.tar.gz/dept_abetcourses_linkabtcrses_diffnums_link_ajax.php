<?php
/**
 * Add Selected Abet Courses
 * Description: Adding abet course as cross-program courses (different course numbers)
 * Author: Dong Hyun Jeong
 *
 * 03/26/2026 - initial version created
 *
 *
 */

include_once 'session_handler.php';

$AcademicYearIdx = '';
$PrimaryCourse = '';
$ReferenceCourses = '';

if (array_key_exists('ay', $_POST) &&
    array_key_exists('primarycrse', $_POST) &&
    array_key_exists('refcrses', $_POST))
{
    $AcademicYearIdx = trim($_POST['ay']);
    $PrimaryCourse = trim($_POST['primarycrse']);
    $ReferenceCourses = trim($_POST['refcrses']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

if ($AcademicYearIdx == "" || $PrimaryCourse == "" || $ReferenceCourses == "") {
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/../config.php');
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    // Parse primary course to get its AbetCourseIdx
    $PrimaryCourse_Tmp = explode('_', $PrimaryCourse);
    if (count($PrimaryCourse_Tmp) != 2) {
        throw new Exception('Invalid Primary Course format');
    }
    $PrimaryAbetCourseIdx = (int)$PrimaryCourse_Tmp[1];  // AbetCourseIdx

    // Parse reference courses to build comma-separated list of AbetCourseIdx values
    $ReferenceCourse_Array = explode('|', $ReferenceCourses);
    $ReferenceIdxList = array();

    foreach ($ReferenceCourse_Array as $refCourse) {
        $RefCourse_Tmp = explode('_', $refCourse);
        if (count($RefCourse_Tmp) != 2) {
            throw new Exception('Invalid Reference Course format');
        }

        $RefAbetCourseIdx = (int)$RefCourse_Tmp[1];  // AbetCourseIdx
        $ReferenceIdxList[] = $RefAbetCourseIdx;
    }

    if (empty($ReferenceIdxList)) {
        throw new Exception('No valid reference courses provided');
    }

    // Convert array to comma-separated string
    $ReferenceIdxString = implode(',', $ReferenceIdxList);

    // Call stored procedure once with all reference courses
    $query = "CALL SP_UpdateSharedAbetCoursesLink(?, ?);";
    $params = [$ReferenceIdxString, $PrimaryAbetCourseIdx];
//    error_log($DBCONNECTION->formatQuery($query, $params));
    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();

    // Check if it's a SIGNAL error with our custom error code
    if (strpos($errorMessage, '0x5000') !== false) {
        // Extract error code from message
        preg_match('/0x[0-9A-Fa-f]+/', $errorMessage, $matches);
        if (!empty($matches)) {
            echo $matches[0];
        } else {
            echo "0x00000500";
        }
    } else {
        echo "0x00000500";  // other DB error
    }

    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'query' => isset($query) ? $query : 'N/A'
    ]));

    if (isset($query) && isset($params)) {
        error_log($DBCONNECTION->FormatQuery($query, $params));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}
