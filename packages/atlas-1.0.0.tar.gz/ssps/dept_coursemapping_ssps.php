<?php
/**
 * Listing abet courses
 * Description: listing all abet courses
 *
 * 11/19/2024 - initial version created
 *
 */
include_once 'session_handler.php';


$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = '';
$joinQuery = " FROM (
    SELECT 
        A.`Idx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`AbetSyllabus`, A.`Degree`,
        A.`Requirement`,
        GROUP_CONCAT(DISTINCT B.`SO` ORDER BY B.`SO` SEPARATOR ', ') as `StudentOutcomes`,
        GROUP_CONCAT(DISTINCT B.`SOIdx` ORDER BY B.`SO` SEPARATOR ', ') as `SOIdxes`,
        GROUP_CONCAT(DISTINCT B.`GPIIdx` ORDER BY B.`SO`, B.`GPI` SEPARATOR ', ') as `PIIdxes`,
        GROUP_CONCAT(DISTINCT CONCAT_WS('-',B.`SO`, B.`GPI`) ORDER BY B.`SO`, B.`GPI` SEPARATOR ', ') as `PIs`
    FROM (
        SELECT `CMCRSES`.`Idx`, `CMCRSES`.`AcademicYear`, `CMCRSES`.`Level`, 
            `AYS`.`AcademicYear` AS `AcademicYearInfo`, 
            `CMCRSES`.`AcademicProgram`, 
            `CMCRSES`.`AbetSyllabus`,
            `CRSES`.`Subject`, `CRSES`.`Num`, `CRSES`.`Title`, 
            `CRSES`.`Credits`, `ACDEMICPRMS`.`Degree`,
            `CMCRSES`.`Requirement`
        FROM `CourseMapping_Courses` AS `CMCRSES`
        INNER JOIN `Courses` AS `CRSES` 
            ON (`CMCRSES`.`CourseIdx` = `CRSES`.`Idx` 
                AND `CMCRSES`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."') 
        INNER JOIN `AcademicYears` AS `AYS` 
            ON (`CMCRSES`.`AcademicYear` = `AYS`.`Idx`) 
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` 
            ON (`CMCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
    ) AS A
    LEFT JOIN (
        SELECT `CMCRSES`.`Idx` AS `AbetCourseIdx`, `CMCRSES`.`AcademicYear`, 
            `CMCRSES`.`AcademicProgram`, `STNTOUTCMS`.`Idx` AS `SOIdx`, 
            `STNTOUTCMS`.`SO`, `GPIS`.`Idx` AS `GPIIdx`, `GPIS`.`GPI` 
        FROM `CourseMapping_Courses` AS `CMCRSES` 
        INNER JOIN `CourseMapping_SOs` AS `ABETCRSES_SOS` 
            ON (`CMCRSES`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx` 
                AND `CMCRSES`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."') 
        LEFT JOIN `CourseMapping_GPIs` AS `ABETCRSES_GPIS` 
            ON (`ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx` 
                AND `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` 
            ON (`ABETCRSES_SOS`.`SOIdx` = `STNTOUTCMS`.`Idx`) 
        LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON (`GPIS`.`Idx` = `ABETCRSES_GPIS`.`GPIIdx`)
    ) AS B ON (A.`Idx` = B.`AbetCourseIdx` 
        AND A.`AcademicYear` = B.`AcademicYear` 
        AND A.`AcademicProgram` = B.`AcademicProgram`)
    GROUP BY A.`Idx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`Degree`
) AS combined";

// Table's primary key
$primaryKey = '`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => '`AcademicyearInfo`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => 'FUNC_GetCourseLevel(`Level`)', 'dt' => 'Level', 'field' => 'Level', 'as' => 'Level'),
    array( 'db' => '`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`AbetSyllabus`', 'dt' => 'AbetSyllabus', 'field' => 'AbetSyllabus', 'as' => 'AbetSyllabus'),
    array( 'db' => '`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram'),
    array( 'db' => '`Requirement`', 'dt' => 'Requirement', 'field' => 'Requirement', 'as' => 'Requirement'),
    array( 'db' => '`Degree`', 'dt' => 'Degree', 'field' => 'Degree', 'as' => 'Degree'),
    array(
        'db' => '`SOIdxes`', // Base column for filtering
        'dt' => 'SOIdxes',
        'field' => 'SOIdxes',
        'as' => 'SOIdxes',
        'formatter' => function($d, $row) {
            return $d; // The GROUP_CONCAT will be handled in the query
        }
    ),
    array(
        'db' => '`StudentOutcomes`', // Base column for filtering
        'dt' => 'StudentOutcomes',
        'field' => 'StudentOutcomes',
        'as' => 'StudentOutcomes',
        'formatter' => function($d, $row) {
            return $d; // The GROUP_CONCAT will be handled in the query
        }
    ),
    array(
        'db' => '`PIIdxes`',
        'dt' => 'PIIdxes',
        'field' => 'PIIdxes',
        'as' => 'PIIdxes',
        'formatter' => function($d, $row) {
            return $d;
        }
    ),
    array(
        'db' => "PIs",
        'dt' => 'PIs',
        'field' => 'PIs',
        'as' => 'PIs',
        'formatter' => function($d, $row) {
            return $d;
        }
    )
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );

$extraWhere = "combined.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";

if ($AcademicYear != "" && $AcademicYear != "all") {
    $extraWhere .= " AND combined.`AcademicYear`='".$AcademicYear."'";
}

// Remove the GROUP BY since it's now handled in the subquery
$groupBy = "Idx";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);



