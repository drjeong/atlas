<?php
/**
 * Listing PIs
 * Description: listing performance indicators
 *
 *
 * 10/08/2024 -- Adding revision comments and approval info
 */

include_once 'session_handler.php';


$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = 'GeneralPerformanceIndicators';
$joinQuery = "FROM `{$table}` AS `PI` INNER JOIN `AcademicYears` AS `AYS` ON (`PI`.`AcademicYear`=`AYS`.`Idx` AND `PI`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."') INNER JOIN `AcademicPrograms` AS `AP` ON (`PI`.`AcademicProgram` = `AP`.`Idx`) LEFT JOIN `StudentOutcomes` AS `SO` ON (`SO`.`Idx` = `PI`.`SOIdx`) ";


// Table's primary key
$primaryKey = '`PI`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`PI`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`PI`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`PI`.`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => '`AYS`.`AcademicYear`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => '`PI`.`SOIdx`', 'dt' => 'SOIdx', 'field' => 'SOIdx', 'as' => 'SOIdx'),
    array( 'db' => 'CONCAT_WS(\'-\',`SO`.`SO`, `PI`.`GPI`)', 'dt' => 'PITXT', 'field' => 'PITXT', 'as' => 'PITXT'),
    array( 'db' => '`PI`.`Description`', 'dt' => 'Description', 'field' => 'Description', 'as' => 'Description', 'formatter'),
    array( 'db' => '`PI`.`Comments`', 'dt' => 'Comments', 'field' => 'Comments', 'as' => 'Comments'),
    array( 'db' => '`PI`.`Approval`', 'dt' => 'Approval', 'field' => 'Approval', 'as' => 'Approval'),
    array( 'db' => '`PI`.`TobeRemoved`', 'dt' => 'TobeRemoved', 'field' => 'TobeRemoved', 'as' => 'TobeRemoved'),
    array( 'db' => '`PI`.`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );

$extraWhere = "`PI`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";

if ($AcademicYear != "" && $AcademicYear != "all") $extraWhere .= " AND `PI`.`AcademicYear`='".$AcademicYear."'";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere)
);

