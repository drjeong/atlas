<?php
/**
 * Listing Assessment Measures
 * File: u_course_assessmentmeasures_ssps.php
 * Description: listing assessment measures of the selected course
 *
 *
 *
 */

include_once 'session_handler.php';


$AbetCourseIdx='';
$AvailableCourseIdx='';
$AcademicProgramIdx='';
if (array_key_exists('_ABTC', $_GET) && array_key_exists('_AVC', $_GET) && array_key_exists('_AP', $_GET)) {
    $AbetCourseIdx = trim($_GET['_ABTC']);
    $AvailableCourseIdx = trim($_GET['_AVC']);
    $AcademicProgramIdx = trim($_GET['_AP']);
}
else {
    // illegal entry
    exit;
}

// DB table to use
$table = 'AssessmentMeasures';
$joinQuery = "FROM `$table` AS `ASSMNTMEASURES` 
    INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` 
        ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram`='$AcademicProgramIdx') 
    INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` 
        ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`='$AcademicProgramIdx')
    LEFT JOIN `AssessmentMeasureSamples` AS `SAMPLES`
        ON (`SAMPLES`.`AssessmentMeasureIdx`=`ASSMNTMEASURES`.`Idx`)";

// Table's primary key
$primaryKey = '`ASSMNTMEASURES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
$columns = array(
    array('db' => '`ASSMNTMEASURES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_'.$row[0];
        }
    ),
    array( 'db' => '`ASSMNTMEASURES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`ASSMNTMEASURES`.`GPI`', 'dt' => 'GPIIdx', 'field' => 'GPIIdx', 'as' => 'GPIIdx'),
    array( 'db' => '`GPIS`.`Description`', 'dt' => 'GPIDescription', 'field' => 'GPIDescription', 'as' => 'GPIDescription'),
    array( 'db' => '`ASSMNTMEASURES`.`Measure`', 'dt' => 'Measure', 'field' => 'Measure', 'as' => 'Measure'),
    array( 'db' => 'CONCAT_WS(\'-\',`STNTOUTCMS`.`SO`, `GPIS`.`GPI`)', 'dt' => 'GPI', 'field' => 'GPI', 'as' => 'GPI'),
    array( 'db' => '`ASSMNTMEASURES`.`AssignmentType`', 'dt' => 'AssignmentType', 'field' => 'AssignmentType', 'as' => 'AssignmentType'),
    array( 'db' => '`ASSMNTMEASURES`.`AssignmentNum`', 'dt' => 'AssignmentNum', 'field' => 'AssignmentNum', 'as' => 'AssignmentNum'),
    array( 'db' => '`ASSMNTMEASURES`.`AssignmentProblem`', 'dt' => 'AssignmentProb', 'field' => 'AssignmentProb', 'as' => 'AssignmentProb'),
    array( 'db' => '`ASSMNTMEASURES`.`AssignmentDescription`', 'dt' => 'AssignmentDesc', 'field' => 'AssignmentDesc', 'as' => 'AssignmentDesc'),
    array( 'db' => '`ASSMNTMEASURES`.`ActualAssmntSample`', 'dt' => 'ActualAssmntSample', 'field' => 'ActualAssmntSample', 'as' => 'ActualAssmntSample'),
    array(
        'db' => 'COUNT(`SAMPLES`.`Idx`)',
        'dt' => 'StudentSamples',
        'field' => 'StudentSamples',
        'as' => 'StudentSamples'
    ),
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "`ASSMNTMEASURES`.`AvailableCourseIdx` = '$AvailableCourseIdx'";
$extraWhere .= " AND `ASSMNTMEASURES`.`AbetCourseIdx`= '$AbetCourseIdx'";

$groupBy = "`ASSMNTMEASURES`.`Idx`";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
