<?php
/**
 * Main index page
 * Description: main index page with login box
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 *
 */

require_once "./php_include/rsa.php";
?>
<!doctype html>
<html lang="en">
<head>
    <title>ATLAS: Academic Tracking & Learning Assessment System</title>
    <meta charset="utf-8">
    <meta name="author" content="">
    <meta name="description" content="">

    <link rel="apple-touch-icon" sizes="180x180" href="./favicon_io/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./favicon_io/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./favicon_io/favicon-16x16.png">
    <link rel="manifest" href="./favicon_io/site.webmanifest">

    <link rel="stylesheet" type="text/css" href="css/style-home.css" />
    <link rel="stylesheet" type="text/css" href="/toolbox/sweetalert2-10.12.6/package/dist/sweetalert2.css" />
    <link rel="stylesheet" type="text/css" href="/toolbox/bootstrap-3.3.5-dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/toolbox/jquery-ui-1.11.4.custom/jquery-ui.min.css" />
    <link rel="stylesheet" type="text/css" href="css/bootbox.css?v=0.0.1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!--    <script src="js/jquery-1.11.3.min.js"></script>-->
    <script src="/toolbox/sweetalert2-10.12.6/package/dist/sweetalert2.min.js"></script>
    <script src="/toolbox/bootstrap-3.3.5-dist/js/bootstrap.min.js"></script>
    <script src="/toolbox/bootbox_6.0.0/bootbox.all.min.js"></script>
    <script src="js/jsencrypt.min.js"></script>
    <script src="js/api_commons.min.js?v=0.0.102"></script>
    <script src="js/api_spinner.min.js?v=0.0.1"></script>
    <script src="js/disable-navigation.min.js?v=0.0.1"></script>

    <script>
        String.prototype.isEmpty = String.prototype.isEmpty || function() {
            return !(!!this.trim().length);
        }

        function chk()
        {
            if (form.email.value.isEmpty())
            {
                form.email.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Enter your email address!!",
                    icon: "error"
                });
                return false;
            }
            if (form.pwd.value.isEmpty())
            {
                form.pwd.focus();
                Swal.fire({
                    title: "ERROR",
                    text: "Enter your Password!!",
                    icon: "error"
                });
                return false;
            }
            return true;
        }

        function getEncryptedData(textvalue)
        {
            // Create the encryption object and set the key.
            const crypt = new JSEncrypt();
            crypt.setKey(form.pub_key.value);

            //Even though the methods are called setPublicKey and setPrivateKey, remember
            //that they are only alias to setKey, so you can pass them both a private or
            //a public openssl key, just remember that setting a public key allows you to only encrypt.
            return crypt.encrypt(textvalue);
        }

        function ChangetoLowercase(input)
        {
            input.value = input.value.toLowerCase();
        }

        function CheckCredential()
        {
            if (chk() === false) return false;

            const email = getEncryptedData(form.email.value);
            const pwd = getEncryptedData(form.pwd.value);

            let xmlhttp;
            if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp=new XMLHttpRequest();
            } else { // code for IE6, IE5
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function() {
                if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                    const response = xmlhttp.responseText.trim();

                    // Check if response contains failure count
                    if (response.startsWith("0x80001010|")) {
                        const parts = response.split("|");
                        const failCount = parseInt(parts[1]) || 0;
                        const remainingAttempts = 5 - failCount;

                        let errorText = "Invalid login credentials.";

                        if (failCount >= 5) {
                            errorText = "Your account has been locked due to too many failed login attempts. Please contact the system administrator (Dr. Jeong).";
                        } else if (failCount > 0) {
                            errorText = `Invalid login credentials. Please note that this system is not connected to UDC SSO (Single Sign-On). You have ${remainingAttempts} attempt${remainingAttempts !== 1 ? 's' : ''} remaining before your account will be locked.`;
                        }

                        Swal.fire({
                            title: "Login Failed",
                            text: errorText,
                            icon: "error"
                        });
                        return;
                    }

                    switch(response)
                    {
                        case "0x11111111":
                            location.href = "main.php";
                            break;
                        case "0x60001010":
                            Swal.fire({
                                title: "Account Disabled",
                                text: "Your account has been disabled. Please contact the system administrator (Dr. Jeong).",
                                icon: "error"
                            });
                            break;
                        default:
                            Swal.fire({
                                title: "ERROR",
                                text: "Unknown error is occurred. Please contact the system administrator!!",
                                // text: "Unable to process your login credentials. Please note that this system is not connected to UDC SSO (Single Sign-On). If you have not created a password before, click the button on the login-page to request a temporary password.",
                                icon: "error"
                            });
                            break;
                    }
                }
            }
            xmlhttp.open("POST", "login_chk.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send("email="+encodeURIComponent(email)+"&pwd="+encodeURIComponent(pwd));

            return false;
        }

        function RequestTempPassword_Perform(email, lname)
        {
            // Show the full page spinner
            showFullPageSpinner();

            email = email.toLowerCase();

            email = getEncryptedData(email);
            lname = getEncryptedData(lname);

            let xmlhttp;
            if (window.XMLHttpRequest) {
                // code for IE7+, Firefox, Chrome, Opera, Safari
                xmlhttp=new XMLHttpRequest();
            } else { // code for IE6, IE5
                xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
            xmlhttp.onreadystatechange=function() {
                if (xmlhttp.readyState===4 && xmlhttp.status===200) {
                    // Hide spinner and show notification
                    hideFullPageSpinner();

                    switch(xmlhttp.responseText.trim())
                    {
                        case "0x11111111":
                            Swal.fire({
                                title: "SUCCESS",
                                html: "Your login credential reset request has been submitted. A confirmation email will be delivered to your email soon!! <br/><span style='color: red;'>Please contact the system administrator if you do not receive any email in next 10 minutes.</span>",
                                icon: "success"
                            });
                            break;
                        default:
                            Swal.fire({
                                title: "ERROR",
                                text: "Unknown error is occurred. Please contact the system administrator!!",
                                icon: "error"
                            });
                            break;
                    }
                }
            }
            xmlhttp.open("POST", "login_reset.php", true);
            xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlhttp.send("email="+encodeURIComponent(email)+"&lname="+encodeURIComponent(lname));

            return false;
        }

        function RequestTempPassword()
        {
            const content = ''
                + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
                + '<table style="border-spacing:0; padding:0; width:100%;">'
                + '<tr><td colspan="2"><div class="input-group" style="width:100%">'
                + '			<div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Email Address<span style="color:red">*</span></span>'
                + '				<input type="text" name="email" id="email" class="input-sm form-control" value="" placeholder="Registered Email Address" required>'
                + '			</div>'
                + '			<div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Your Last Name<span style="color:red">*</span></span>'
                + '				<input type="text" name="lname" id="lname" class="input-sm form-control" value="" placeholder="Your Last Name" required>'
                + '			</div>'
                + '</div></td></tr>'
                + '</table></form>';

            bootbox.dialog({
                title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">REQUEST TEMPORARY PASSWORD</span>',
                message: content,
                onEscape: true,
                backdrop: true,
                buttons: {
                    ok: {
                        label: "<span class='glyphicon glyphicon-ok'></span> RESET",
                        className: 'btn-success',
                        callback: function(){
                            if (popupfrm.email.value.isEmpty())
                            {
                                popupfrm.email.focus();
                                Swal.fire({title:"ERROR", text: "Email address is not entered!!", icon:"error"});
                                return false;
                            }
                            if (popupfrm.lname.value.isEmpty())
                            {
                                popupfrm.lname.focus();
                                Swal.fire({title:"ERROR", text: "Your last name is not entered!!", icon:"error"});
                                return false;
                            }

                            RequestTempPassword_Perform(popupfrm.email.value, popupfrm.lname.value);
                        }
                    },
                    cancel: {
                        label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                        className: 'btn-default',
                        callback: function(){
                        }
                    }
                }
            }).on('shown.bs.modal',function(){
                $("#email").focus();
                $(this).removeAttr('aria-hidden');
            }).find('.modal-dialog').css({
                'margin-top': function (){
                    let w = $( window ).height();
                    let b = $(this).height();
                    let h = (w-b)*0.2
                    return h+"px";
                }
            }).find('.modal-header').css({
                'cursor': 'move'            // change mouse cursor for dragging on modal header
            });
        }

    </script>
</head>
<body>

<table class="pagebacklayout_top" style="height:60px; text-align: center; border-spacing: 0; padding: 0;">
    <tr style="background-image: url('./images/banner_bg_repeat.jpg'); background-repeat: repeat;">
        <td style="height: 5px;"></td>
    </tr>
    <tr style="background-image: url('./images/banner_bg_repeat.jpg'); background-repeat: repeat;">
        <td style="width:5px;"><img src="./images/universitylogo.svg" alt="University Logo" class="svgshadow" style="height:30px; text-align: left"></td>
    </tr>
    <tr style="background-image: url('./images/banner_bg_repeat.jpg'); background-repeat: repeat;">
        <td style="height:90px; width:100%; text-align: center; vertical-align: top">
            <div style="width:100%; padding:20px;"><span style="color:white; font-size: 30px;text-shadow: 2px 2px #000000;">ATLAS: Academic Tracking & Learning Assessment System</span></div>
        </td>
        <td></td>
    </tr>
    <tr style="background-image: url('./images/banner_bg_repeat.jpg'); background-repeat: repeat;"><td style="height: 5px;"></td></tr>
    <tr>
        <td style="height: 5px;"><hr id="dottedline" /></td>
    </tr>
    <tr style="background-color: white;">
        <td style="height: 80%; vertical-align: top; text-align: center;">
            <!-- Information Should be here BEGIN-->
            <table style="border: 1px solid black; width:100%; border-spacing: 0; padding: 0; text-align: center;">
                <tr>
                    <td colspan=3 style="vertical-align: top; text-align:center;">
                        <table style="margin:auto; border: 0px solid red;  height: 500px; border-spacing: 0; padding: 0; vertical-align: top">
                            <tr>
                                <td style="vertical-align: top; text-align:center;"><br><br>
                                    <h4>Please enter your credentials to access the system</h4>
                                    <br/><br/>

                                    <div style="margin:auto; text-align: center;">
                                        <form name='form' action='' onsubmit="CheckCredential();return false;" style="margin: 0 auto; text-align: center">
                                            <input type="hidden" name="pub_key" value="<?php echo GetPublicKey();?>">

                                            <div class="form-group row">
                                                <label for="email" class="col-sm-3 col-form-label col-form-label-lg">Email&nbsp;Address</label>
                                                <div class="col-sm-9">
                                                    <input type="email" id="email" name="email" class="form-control form-control-lg" placeholder="Enter Your Email Address" pattern=".+@.+\..+" onchange="ChangetoLowercase(this);" required autofocus>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="pwd" class="col-sm-3 col-form-label col-form-label-lg">Password</label>
                                                <div class="col-sm-9">
                                                    <input type="password" id="pwd" name="pwd" class="form-control" placeholder="Enter Your Password" required>
                                                </div>
                                            </div>

                                            <div class="form-group row" style="padding: 0px 15px;">
                                                <button class="btn btn-lg btn-primary" type="submit" style="width:100%;">Sign in</button>
                                            </div>

                                            <div class="btn-group btn-block">
                                                Need help?&nbsp;&nbsp;&nbsp;<a href="#" onclick="RequestTempPassword();return false;">CLICK HERE TO REQUEST A TEMPORARY PASSWORD</a>
                                            </div>

                                        </form>
                                    </div>

                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<?php include('footer.php');?>
