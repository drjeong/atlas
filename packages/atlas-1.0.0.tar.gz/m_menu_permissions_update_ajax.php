<?php
include('checker_systemadmin.php');
include_once 'session_handler.php';

// Check if user is system admin
if (!isset($_SESSION['ATLAS_LOGIN_SYSADMIN']) || $_SESSION['ATLAS_LOGIN_SYSADMIN'] !== true) {
    echo 'ERROR: Unauthorized';
    exit;
}

require_once(__DIR__ . '/php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

// Convert character encodings
require_once(__DIR__ . '/php_include/listfunc.php');

$userIdx = isset($_POST['userIdx']) ? intval($_POST['userIdx']) : 0;
$groupCode = isset($_POST['groupcode']) ? $_POST['groupcode'] : '';
$parentMenu = isset($_POST['parentmenu']) ? $_POST['parentmenu'] : '';
$checked = isset($_POST['checked']) ? $_POST['checked'] : 'false';

if ($userIdx <= 0 || empty($groupCode) || empty($parentMenu)) {
    echo 'ERROR: Invalid parameters - UserIdx, GroupCode, or ParentMenu missing';
    exit;
}

// Check if user is system admin (cannot modify their permissions)
$checkUserQuery = "SELECT SystemAdmin FROM UserAccounts WHERE Idx = ?";
$checkUserResult = $DBCONNECTION->prepare_execute_catch_error($checkUserQuery, [$userIdx]);
if ($checkUserResult) {
    $user = $checkUserResult->fetch_assoc();
    if ($user && $user['SystemAdmin'] == '1') {
        echo '0x11111111'; // Success but no change needed for system admin
        exit;
    }
}

// Convert and escape
$groupCode = convertSpecialCharacters($groupCode);
$groupCode = $DBCONNECTION->real_escape_string($groupCode);
$parentMenu = convertSpecialCharacters($parentMenu);
$parentMenu = $DBCONNECTION->real_escape_string($parentMenu);

$grantedBy = $_SESSION['ATLAS_LOGIN_USERIDX'];

if ($checked === 'true') {
    // Add submenu group permission
    $checkQuery = "SELECT Idx FROM UserMenuPermissions 
                  WHERE UserIdx = ? AND MenuGroupCode = ? AND MenuCode = ?";
    $checkResult = $DBCONNECTION->prepare_execute_catch_error($checkQuery,
        [$userIdx, $groupCode, $parentMenu]);

    if ($checkResult && $checkResult->num_rows == 0) {
        $insertQuery = "INSERT INTO UserMenuPermissions 
                       (UserIdx, MenuCode, MenuGroupCode, GrantedBy, GrantedDate) 
                       VALUES (?, ?, ?, ?, NOW())";
        $insertResult = $DBCONNECTION->prepare_execute_catch_error($insertQuery,
            [$userIdx, $parentMenu, $groupCode, $grantedBy]);

//        if (!$insertResult) {
//            echo 'ERROR: Failed to grant permission';
//            exit;
//        }
    }
} else {
    // Remove submenu group permission
    $deleteQuery = "DELETE FROM UserMenuPermissions 
                   WHERE UserIdx = ? 
                   AND MenuGroupCode = ? 
                   AND MenuCode = ?";
    $deleteResult = $DBCONNECTION->prepare_execute_catch_error($deleteQuery,
        [$userIdx, $groupCode, $parentMenu]);

//    if (!$deleteResult) {
//        echo 'ERROR: Failed to revoke permission';
//        exit;
//    }
}

// After successful permission change, refresh the session menu cache
if (isset($_SESSION['ATLAS_ACCESSIBLE_MENUS'])) {
    require_once(__DIR__ . '/php_include/menu_access_control.php');

    // If we just modified the current user's permissions, reload them
    if ($userIdx == $_SESSION['ATLAS_LOGIN_USERIDX']) {
        $menuAccess = new MenuAccessControl(
            $DBCONNECTION,
            $_SESSION['ATLAS_LOGIN_USERIDX']
        );
        $_SESSION['ATLAS_ACCESSIBLE_MENUS'] = $menuAccess->getAccessibleMenus();
    }
}

echo '0x11111111'; // Success
