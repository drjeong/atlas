<?php
/**
 * Session Time Out
 * This is called from Javascript to check if session is expired or not.
 *
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
echo(sessionCheck());
function sessionCheck()
{
	if(!isset($_SESSION['ATLAS_LOGIN_USERIDX']) || SessionTimeOut())
	{
        // destroy the session.
        session_unset();
        session_destroy();
        session_write_close();
        session_start();
        session_regenerate_id(true);
		return true;
	}
	return false;
}

function SessionTimeOut()
{
	if(!isset($_SESSION['ATLAS_LASTCONNECTEDTIME'])) return false; // session not defined

	$current = time();// take the current time
	$diff = $current - $_SESSION['ATLAS_LASTCONNECTEDTIME'];
	if($diff > $_SESSION['ATLAS_TIMEOUT'])
	{
		return true;
	}
    return false;
}