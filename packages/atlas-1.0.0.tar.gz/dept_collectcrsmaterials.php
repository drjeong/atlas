<?php
/**
 * Abet courses
 * Description: Listing abet courses to collect course materials
 * Author: Dong Hyun Jeong
 *
 * 04/07/2025 - initial version created
 */

include('checker_programdirector.php');
include('header.php');
?>

<?php

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection();

?>

<script src="js/datatable-utils-search.min.js"></script>
<script src="js/datatable-utils-rowselector.min.js?v=0.0.001"></script>

<script src="js/api_pdfviewer.min.js?v=0.0.1"></script>

<script>

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        CANNOT_REMOVE_DATA_EXIST: '0x09500012',
    };

    var DataTable_CollectMaterials_CourseList = null;
    var DataTable_CoursesList = null;

// ----------------------------------------------------------------------------------------------
    function assignAssistants(CourseIdx, Assistants=null) {
        let DataTable_Assistants_List = null;
        let initiallySelectedRows = []; // Store initially selected assistants
        let currentlySelectedRows = []; // Store currently selected assistants

        const content = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<div class="CSSTable_SSPSLIST" style="min-height:370px;">'
            + '<table id="assistants_list" class="display" style="border-spacing:0; padding:0; width:100%;">'
            + '<thead>'
            + '<tr>'
            + ' <th class="no-sort" style="width:3px"></th>'
            + ' <th>NAME</th>'
            + ' <th>POSITION</th>'
            + ' <th>AFFILIATION</th>'
            + '</tr>'
            + '</thead>'
            + '<thead id="serachbox" class="filters">'
            + '<tr>'
            + ' <th></th>'
            + ' <th>NAME</th>'
            + ' <th>POSITION</th>'
            + ' <th>AFFILIATION</th>'
            + '</tr>'
            + '</thead>'
            + '<tfoot>'
            + '<tr>'
            + ' <th></th>'
            + ' <th>NAME</th>'
            + ' <th>POSITION</th>'
            + ' <th>AFFILIATION</th>'
            + '</tr>'
            + '</tfoot>'
            + '</table>'
            + '</div></form>';

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN / UNASSIGN ASSISTANTS</span>',
            message: content,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){
                        const selected_assistants = DataTable_Assistants_List.rows({ selected: true }).data();
                        let selected_assistants_list = '';
                        for(let i = 0; i < selected_assistants.length; ++i) {
                            if (selected_assistants_list !== '') selected_assistants_list += "|";
                            selected_assistants_list += encodeURIComponent(selected_assistants[i].Idx);
                        }

                        // Get newly checked and unchecked items
                        const newlyChecked = currentlySelectedRows.filter(id => !initiallySelectedRows.includes(id));
                        const newlyUnchecked = initiallySelectedRows.filter(id => !currentlySelectedRows.includes(id));

                        // console.log("Newly checked assistants:", newlyChecked);
                        // console.log("Newly unchecked assistants:", newlyUnchecked);

                        // You can pass this information to your server if needed
                        AssignAssistants_Perform(CourseIdx, selected_assistants_list, newlyChecked, newlyUnchecked);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        });

        // Define a custom sorting function to the selected rows
        $.fn.dataTable.ext.order['dom-checkbox'] = function  ( settings, col ) {
            return this.api().column( col, {order:'index'} ).nodes().map( function ( td, i ) {
                return $(td).closest('tr').hasClass('selected') ? '1' : '0';
            } );
        }

        DataTable_Assistants_List = $("#assistants_list").DataTable({
            "processing": true,
            "serverSide": false,
            "iDisplayLength": 7,
            "lengthChange": false,
            "sDom": 'tip', // invisible search box & show pagination tabs & show selected entries
            "language": {
                "info": "", // Hide default info
                "infoEmpty": "",
                "infoFiltered": "",
                "select": {
                    "rows": {
                        _: "%d rows selected",  // Multiple rows selected
                        0: "",                   // No rows selected (show nothing)
                        1: "1 row selected"     // One row selected
                    }
                }
            },
            "ajax": {
                "url": "ssps/dept_abcassistants_list_ssps.php",
                "dataSrc": function(json) {
                    // Process the data once it's loaded
                    if (Assistants !== null) {
                        const AssistantsIdxes = Assistants.split(",").map(str => parseInt(str.trim(), 10));
                        initiallySelectedRows = [...AssistantsIdxes]; // Store initial selection
                        currentlySelectedRows = [...AssistantsIdxes]; // Initialize current selection
                    }
                    return json.data;
                }
            },
            "order": [[ 1, 'asc' ]],
            "fnDrawCallback": function() {
                $('#assistants_list tr td:nth-child(1)').css('text-align', 'center');
                $('#assistants_list tr td:nth-child(2)').css('text-align', 'center');
                $('#assistants_list tr td:nth-child(3)').css('text-align', 'center');
            },
            "columns": [
                {
                    "data": 'DT_RowId',
                    "render": function ( data, type, full, meta ) {
                        let rowId = full.Idx; // Get Idx
                        if (Assistants !== null) {
                            const AssistantsIdxes = Assistants.split(",").map(str => parseInt(str.trim(), 10));
                            if (AssistantsIdxes.includes(rowId)) {
                                // Select this row after a slight delay to ensure DataTable is ready
                                setTimeout(() => {
                                    DataTable_Assistants_List.row('#'+data).select();
                                }, 100);
                            }
                        }
                        return '';
                    }
                },
                { "data": 'Name' },
                { "data": 'Position' },
                { "data": 'Affiliation' }
            ],
            "columnDefs": [
                {
                    'orderable': false,
                    'className': 'select-checkbox',
                    'targets': 0,
                    'orderDataType': 'dom-checkbox'
                },
                {
                    "targets"  : 'no-sort',
                    "orderable": false,
                }
            ],
            'select': {
                'style': 'multi',
                'info': true  // Keep the select info enabled
            }
        });

        // Listen for select/deselect events
        DataTable_Assistants_List.on('select', function(e, dt, type, indexes) {
            if (type === 'row') {
                indexes.forEach(index => {
                    const rowData = DataTable_Assistants_List.row(index).data();
                    const rowId = parseInt(rowData.Idx, 10);
                    if (!currentlySelectedRows.includes(rowId)) {
                        currentlySelectedRows.push(rowId);
                    }
                });
            }
        });

        DataTable_Assistants_List.on('deselect', function(e, dt, type, indexes) {
            if (type === 'row') {
                indexes.forEach(index => {
                    const rowData = DataTable_Assistants_List.row(index).data();
                    const rowId = parseInt(rowData.Idx, 10);
                    const idx = currentlySelectedRows.indexOf(rowId);
                    if (idx !== -1) {
                        currentlySelectedRows.splice(idx, 1);
                    }
                });
            }
        });

        // Apply custom sorting to the selected rows
        DataTable_Assistants_List.order([0,'desc']).draw();

        // Setup - add a text input to each footer cell
        $('#assistants_list #serachbox th').each( function () {
            const title = $(this).text();
            if (title != "") $(this).html( '<input type="text" name="searchbox" placeholder="Search '+title+'" style="color:black; width: 100%;padding:1px;box-sizing: border-box;"/>' );
        } );

        $('#assistants_list tfoot th').each( function () {
            const title = $(this).text();
            if (title != "") $(this).html( '<input type="text" placeholder="Search '+title+'" style="color:black; width: 100%;padding:1px;box-sizing: border-box;"/>' );
        } );

        // Apply the search
        DataTable_Assistants_List.columns().every( function (colIdx) {
            const that = this;
            $(
                'input',
                $('.filters th').eq($(DataTable_Assistants_List.column(colIdx).header()).index())
            ).on( 'keyup change', function () {
                if ( that.search() !== this.value ) {
                    that.search( this.value )
                        .draw();
                }
            });

            $( 'input', this.footer() ).on( 'keyup change', function () {
                if ( that.search() !== this.value ) {
                    that.search( this.value )
                        .draw();
                }
            });
        } );
    }

    async function AssignAssistants_Perform(CourseIdx, selectedAssistants, newlyChecked = [], newlyUnchecked = []) {
        try {
            const result = await async_commons.makeApiCall('dept_collectcrsmaterials_assistants_assign_ajax.php', {
                crsidx: CourseIdx,
                astntsidxes: selectedAssistants,
                newlyChecked: JSON.stringify(newlyChecked),
                newlyUnchecked: JSON.stringify(newlyUnchecked)
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Assistant information has been updated');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
            // Hide spinner and show notification
            hideFullPageSpinner();
        }
    }

    async function removeCourse(Idx, AcademicYearInfo, Subject, Num, Title) {
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted content (<span style="color:red">${AcademicYearInfo} ${Subject} ${Num} ${Title}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('dept_collectcrsmaterials_remove_ajax.php', {
                id: Idx,
                ay: 0
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('REMOVED', 'The selected course has been removed!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_DATA_EXIST: {
                    await async_commons.showErrorMessage('ERROR', 'Cannot remove because data collection has been started already.');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function addCourses_perform(_AY, _SELECTEDCOURSES) {
        try {
            const result = await async_commons.makeApiCall('dept_collectcrsmaterials_add_ajax.php', {
                ay: _AY,
                crses: _SELECTEDCOURSES
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'Courses are added');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
            // Hide spinner and show notification
            hideFullPageSpinner();
        }
    }

    function addCourses()
    {
        const [selectedAcademicYearValue, selectedAcademicYearText] = async_commons.getSelectedAcademicYear();
        if (selectedAcademicYearValue === '') {
            return;
        }
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
                <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;" >
                    <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>
                        <input type="hidden" name="_AY" id="_AY" class="input-sm form-control" value="${selectedAcademicYearValue}" readonly>
                        <input type="text" name="_AYTXT" id="_AYTXT" class="input-sm form-control" value="${selectedAcademicYearText}" readonly>
                    </div>
                    <table id="selectedcouselist" class="display" style="border-spacing:0; padding:0; width:100%;">
                        <thead>
                        <tr>
                            <th class="toggle-all" style="width:3px"></th>
                            <th>SEMESTER</th>
                            <th>CRN</th>
                            <th>SUBJECT</th>
                            <th>NUMBER</th>
                            <th>SECTION</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                            <th>DAYS</th>
                            <th>TIMES</th>
                            <th>INSTRUCTOR</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th></th>
                            <th>SEMESTER</th>
                            <th>CRN</th>
                            <th>SUBJECT</th>
                            <th>NUMBER</th>
                            <th>SECTION</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                            <th>DAYS</th>
                            <th>TIMES</th>
                            <th>INSTRUCTOR</th>
                        </tr>
                        </tfoot>
                    </table>
                </div></form>`;

        const rowSelector = new DataTableRowSelector('selectedcouselist', {
            counterId: 'selectedCount',
            toggleButtonId: 'toggleSelected',
            itemName: 'course'
        });

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD COURSES</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ADD",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');

                        let selected = rowSelector.getSelectedData();
                        if (!selected.length) {
                            Swal.fire({title: "ERROR", text: "You need to check at least one course!!", icon: "error"});
                            return false;
                        }
                        const selectedCourses = selected.map(course => course.Idx).join('|'); // separated by '|'
                        addCourses_perform(popupForm._AY.value, selectedCourses);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        });

        DataTable_CoursesList = $("#selectedcouselist").DataTable({
            processing: true,
            serverSide: false,
            iDisplayLength: 8,
            lengthChange: false,
            select: {
                style: 'multi',
                selector: 'td'
            },
            dom: `t<"row"<"col-sm-6"<"filterControls">><"col-sm-6"p>>`, // add row selector filter controls at the bottom
            initComplete: function() {
                // Initialize the row selector
                rowSelector.init(DataTable_CoursesList);
            },
            ajax: `ssps/dept_collectcrsmaterials_courselist_ssps.php?_AY=${selectedAcademicYearValue}`,
            order: [[ 1, 'asc' ], [ 2, 'asc' ]],
            fnDrawCallback: function() {
                $('#selectedcouselist tr td:nth-child(1)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(2)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(3)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(4)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(5)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(7)').css('text-align', 'center');

                $('#selectedcouselist tr td:nth-child(6)').css('width', '150px');
                $('#selectedcouselist tr td:nth-child(8)').css('width', '100px');

                rowSelector.updateSelectedCount();
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function ( data, type, full, meta ) {
                        return '';
                    }
                },
                { data: 'SemesterTxt', className: 'text-center' },
                { data: 'CRN', className: 'text-center' },
                { data: 'Subject', className: 'text-center' },
                { data: 'Num', className: 'text-center' },
                { data: 'Section', className: 'text-center' },
                { data: 'Title', className: 'text-center' },
                { data: 'Credits', className: 'text-center' },
                { data: 'Days', className: 'text-center' },
                { data: 'Times', className: 'text-center' },
                { data: 'Instructor', className: 'text-center' }
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets  : 'no-sort',
                    orderable: false,
                }
            ]
        });

        // Initialize the column search functionality
        new DataTableSearch('#selectedcouselist', DataTable_CoursesList, ShowResetBtn=false);
    }

</script>

<script class="init">
    const szURL = `ssps/dept_collectcrsmaterials_ssps.php?_AY=`;

    $(document).ready(function() {
        const SelectedAcademicYear = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].value;

        DataTable_CollectMaterials_CourseList = $("#AVCourses").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            stateSave: false,
            processing: true,
            serverSide: false,
            select: false,
            lengthMenu: [30, 50, 100, 150, 200, 300, 400],
            ajax: `${szURL}${SelectedAcademicYear}`,
            oLanguage: {
                sInfoFiltered: ""
            },
            order: [[2, "asc"], [3, "asc"], [4, "asc"]],

            // Column definitions
            columns: [
                { data: 'SemesterTxt', className: 'text-center' },
                { data: 'CRN', className: 'text-center' },
                { data: 'Subject', className: 'text-center' },
                { data: 'Num', className: 'text-center' },
                { data: 'Title', className: 'text-center' },
                { data: 'Credits', className: 'text-center' },
                { data: 'Days', className: 'text-center' },
                { data: 'Times', className: 'text-center' },
                { data: 'Instructor', className: 'text-center' },
                {
                    data: 'AssistantNames',
                    className: 'text-center'
                },
                {
                    data: null,
                    className: 'text-center',
                    render: function(data, type, row)
                    {
                        return `<div>
                                    <button id="assign_unassign_assistants" alt="Assign/Unassign Assistants" title="Assign/Unassign Assistants" class="btn btn-danger btn-xs glyphicon glyphicon-user" style="min-height: 20px;"></button>
                                    <button id="remove" alt="Remove course" title="Remove course" class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="min-height: 20px;"></button>
                                </div>`;
                    }
                } // used for representing menu options
            ],
            // Styling callbacks
            fnInitComplete: function(settings) {
                const btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + settings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                btnClear.click(() => $('#' + settings.sTableId).dataTable().fnFilter(''));
            },
            fnDrawCallback: function() {
                this.api().state.clear(); // cancel "stateSave" after reload the page

                // Cell widths
                const cellWidths = {
                    2: '80px',
                    3: '80px', 4: '80px'
                };
                const minWidths = {
                    5: '150px', 6: '80px',
                    7: '80px', 8: '80px', 9: '80px', 10: '80px',
                    11: '80px', 12: '150px'
                };
                Object.entries(cellWidths).forEach(([col, width]) => {
                    $(`#AVCourses tr td:nth-child(${col})`).css('width', width);
                });
                Object.entries(minWidths).forEach(([col, width]) => {
                    $(`#AVCourses tr td:nth-child(${col})`).css('min-width', width);
                });
                $('#AVCourses tr td:nth-child(1)').css('vertical-align', 'bottom');
            },
            columnDefs: [
                {
                    targets: 'no-sort',
                    orderable: false
                },
                {
                    targets: -1,
                    data: null,
                    orderable: false,
                    defaultContent: ''
                }
            ],
            buttons: [
                {
                    extend: 'excelHtml5',
                    title: `Collect Course Materials (${document.forms["change_deprt_frm"]["CH_DEPARTMENT"].options[document.forms["change_deprt_frm"]["CH_DEPARTMENT"].selectedIndex].text})`,
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                    },
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
                    }
                }
            ]
        });

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_CollectMaterials_CourseList.ajax.url(tmpURL).load();
        });

        // Initialize the column search functionality
        new DataTableSearch('#AVCourses', DataTable_CollectMaterials_CourseList);

        // Set the DataTable in AsyncCommons
        async_commons.setDataTable(DataTable_CollectMaterials_CourseList);

        $('#AVCourses tbody').on( 'click', '#remove', function () {
            const data = DataTable_CollectMaterials_CourseList.row( $(this).parents('tr') ).data();
            removeCourse(data.Idx, data.SemesterTxt, data.Subject, data.Num, data.Title);
            return false;  // disable row selection action
        } );

        $('#AVCourses tbody').on( 'click', '#assign_unassign_assistants', function () {
            const data = DataTable_CollectMaterials_CourseList.row( $(this).parents('tr') ).data();
            assignAssistants(data.Idx, data.Assistants);
            return false; // disable row selection action
        } );
    } );

</script>

<div class="pagebacklayout">
    <div style="width:100%;  margin-bottom:0.1in;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSE MATERIALS TO BE COLLECTED</p>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:80%; min-width:350px;">
                    <?php include('control_granted_alldepartments.php'); ?>
                    <script>
                        $(document).ready(function() {
                            // Add the change event handler using jQuery
                            $("#departmentSelect").on("change", function() {
                                const _AY = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].value;
                                url = szURL + _AY+"&_DEPT="+this.value;
                                DataTable_CollectMaterials_CourseList.ajax.url( url.toString() ).load();
                            });
                        });
                    </script>
                </td>
                <td style="width:20%; text-align: right">
                </td>
            </tr>
        </table>

        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:20%; min-width:350px;">
                    <?php echo($AcademicYearSelection);?>
                </td>
                <td style="width:5%"></td>
                <td style="width:75%; text-align: right">
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-list-alt" onclick="addCourses();return false;">&nbsp;ADD COURSES TO COLLECT COURSE MATERIALS</button>
                </td>
            </tr>
        </table>


        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="AVCourses" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th style="width:50px">SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>DAYS</th>
                    <th>TIMES</th>
                    <th>INSTRUCTOR</th>
                    <th>ASSISTANT</th>
                    <th class="no-sort">OPERATION</th>
                </tr>
                </thead>
                <thead id="serachbox" class="filters">
                <tr>
                    <th>SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>DAYS</th>
                    <th>TIMES</th>
                    <th>INSTRUCTOR</th>
                    <th>ASSISTANT</th>
                    <th></th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th>SEMESTER</th>
                    <th>CRN</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>DAYS</th>
                    <th>TIMES</th>
                    <th>ASSISTANT</th>
                    <th>INSTRUCTOR</th>
                    <th></th>
                </tr>
                </tfoot>
            </table>
        </div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Remove Course
                </td>
            </tr>
        </table>
    </div>
</div>


<?php include('footer.php');?>



