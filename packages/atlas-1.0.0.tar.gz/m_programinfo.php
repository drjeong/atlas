<?php
/**
 * Management of Academic Degree Programs
 * Description: managing academic degree programs.
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 09/29/2023 -- Add validation check if degree program name exists.
 *
 */

include('checker_programdirector.php');
include('header.php');

?>

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>

<script type="text/javascript">

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        SAME_ITEM_EXIST: '0x00200011',
        ITEM_NOT_EXIST: '0x00200012',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
    };

    async function ModifyAcademicProgram_Perform(_ID, _AP, _DN, _DEPTNAME) {
        try {
            const result = await async_commons.makeApiCall('m_programinfo_update_ajax.php', {
                id: _ID,
                ap: _AP,
                dn: _DN,
                dept: _DEPTNAME
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Information has been updated!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `The entered academic program exists already!`
                    );
                    // Re-open the add dialog
                    ModifyAcademicProgram(_ID, _AP, _DN, _DEPTNAME);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function RemoveAcademicProgram(id, dp){
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted content (<span style="color:red">${dp}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('m_programinfo_remove_ajax.php', {
                id: id
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected program has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected program cannot be removed!! It has been used already!!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }
    
    function ModifyAcademicProgram(_ID, _AP, _DN, _DEPTIDX, _DEPTNAME)
    {
        const formContent = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<input type="hidden" name="_ID" value="'+_ID+'">'
            + '<table style="border-spacing:0; padding:0; width:100%;">'
            + '<tr><td colspan="2">'
            + '<div class="input-group" style="width:100%">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Program&nbsp;Name (Major)<span style="color:red">*</span></span>'
            + '     <input type="text" name="_AP" id="_AP" class="input-sm form-control" value="'+_AP+'" placeholder="ex) Computer Science" required>'
            + ' </div>'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Degree&nbsp;Name<span style="color:red">*</span></span>'
            + '     <input type="text" name="_DN" id="_DN" class="input-sm form-control" value="'+_DN+'" placeholder="ex) BSCS, BSEE, BSME, BSCE" required>'
            + ' </div>'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Department&nbsp;Name<span style="color:red">*</span></span>'
            + '     <select name="_DEPTNAME" class="input-sm form-control"><?php include('inc_departmentinfo.php'); ?></select>'
            + ' </div>'
            + '</div>'
            + '</td></tr>'
            + '</table></form>';


        createModalDialog({
            title: `<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">EDIT ACADEMIC PROGRAM (MAJOR)</span>`,
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;UPDATE",
                    className: 'btn-success',
                    callback: function(){
                        if (ValidateItems()===false) return false;
                        ModifyAcademicProgram_Perform(popupfrm._ID.value, popupfrm._AP.value, popupfrm._DN.value, popupfrm._DEPTNAME.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_AP").focus();
        });
        if (_DEPTIDX!=='') popupfrm._DEPTNAME.value = _DEPTIDX;
    }

    async function AddAcademicProgram_Perform(_Name, _DN, _DEPTIDX) {
        try {
            const result = await async_commons.makeApiCall('m_programinfo_add_ajax.php', {
                ap: _Name,
                dn: _DN,
                dept: _DEPTIDX
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'Academic program is added successfully!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `The entered academic program exists already!`
                    );
                    // Re-open the add dialog
                    AddAcademicProgram(_Name, _DN, _DEPTIDX);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function AddAcademicProgram(_Program='', _Degree='', _DEPTIDX='')
    {
        const formContent =
            `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
             <div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%">
                <span class="input-group-addon" style="width:200px;">Program&nbsp;Name (Major)<span style="color:red">*</span></span>
                <input type="text" name="_AP" id="_AP" class="input-sm form-control" value="${_Program}" placeholder="ex) Computer Science" required>
              </div>
              <div class="input-group" style="width:100%">
                <span class="input-group-addon" style="width:200px;">Degree&nbsp;Name<span style="color:red">*</span></span>
                <input type="text" name="_DN" id="_DN" class="input-sm form-control" value="${_Degree}" placeholder="ex) BSCS, BSEE, BSME, BSCE" required>
              </div>
              <div class="input-group" style="width:100%">
                <span class="input-group-addon" style="width:200px;">Department&nbsp;Name<span style="color:red">*</span></span>
                <select name="_DEPTNAME" class="input-sm form-control"><?php include('inc_departmentinfo.php'); ?></select>
              </div>
             </div>
             </td></tr>
             </table></form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD ACADEMIC PROGRAM (MAJOR)</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;FETCH",
                    className: 'btn-success',
                    callback: function(){
                        if (ValidateItems()===false) return false;
                        AddAcademicProgram_Perform(popupfrm._AP.value, popupfrm._DN.value, popupfrm._DEPTNAME.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_AP").focus();
        });
        if (_DEPTIDX!=='') popupfrm._DEPTNAME.value = _DEPTIDX;
    }

    function ValidateItems()
    {
        if (popupfrm._AP.value.isEmpty())
        {
            popupfrm._AP.focus();
            Swal.fire({title:"ERROR", text: "Academic program name is not entered!!", icon:"error"});

            return false;
        }
        else if (popupfrm._DN.value.isEmpty())
        {
            popupfrm._DN.focus();
            Swal.fire({title:"ERROR", text: "Degree name is not entered!!", icon:"error"});

            return false;
        }
        else if (popupfrm._DEPTNAME.value.isEmpty())
        {
            popupfrm._DEPTNAME.focus();
            Swal.fire({title:"ERROR", text: "Department Name is not selected!!", icon:"error"});

            return false;
        }
        return true;
    }
</script>
<?php
}
?>


<script class="init">
$(document).ready(function() {
	DataTable_AcademicPrograms = $("#programinfo").DataTable({
		"processing": true,
		"serverSide": true,
        "lengthMenu": [ 30, 50, 75, 100, 150, 300, 500 ],
		"ajax": "ssps/m_programinfo_ssps.php",
		"fnDrawCallback": function() {
			$('#programinfo tr td:nth-child(1)').css('text-align', 'center');
		},		
		"fnInitComplete": function(oSettings, json) {
		  // Add "Clear Filter" button to Filter
		  let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
		  btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
		  $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
		   $('#' + oSettings.sTableId).dataTable().fnFilter('');
		  });
		},
        "fnDrawCallback": function() {
            $('#programinfo tr td:nth-child(1)').css('text-align', 'center');
            $('#programinfo tr td:nth-child(2)').css('text-align', 'center');
        },
		"columns": [
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
			{ "data": 'Idx' },
<?php
}
?>
			{ "data": 'APName' },
            { "data": 'Degree' },
			{ "data": 'DeptName' },
			{ "data": 'Date' },
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
			{ "data": "" } // used for representing menu options
<?php
}
?>
		],
		"columnDefs": [ {
			"targets"  : 'no-sort',
			"orderable": false,
		}
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
		,{
		"targets": -1,
		"data": null,
		"orderable": false,
		"defaultContent": "<div style=\"width:100%;text-align:center;\"><button id=\"modify\" class=\"btn btn-danger btn-xs glyphicon glyphicon-wrench\" style=\"min-height: 20px;\"></button>&nbsp;<button id=\"remove\" class=\"btn btn-danger btn-xs glyphicon glyphicon-remove\" style=\"min-height: 20px;\"></button></div>"
		}
<?php
}
?>
        ]
	});

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
    async_commons.setDataTable(DataTable_AcademicPrograms);

	$('#programinfo tbody').on( 'click', '#remove', function () {
		const data = DataTable_AcademicPrograms.row( $(this).parents('tr') ).data();
		RemoveAcademicProgram(data.Idx, data.APName);
	} );

	$('#programinfo tbody').on( 'click', '#modify', function () {
		const data = DataTable_AcademicPrograms.row( $(this).parents('tr') ).data();
		ModifyAcademicProgram(data.Idx, data.APName, data.Degree, data.DeptIdx, data.DeptName);
	} );
<?php
}
?>
} );

</script>


<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">ACADEMIC PROGRAMS</span>&nbsp;</p>
	</div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
			<td width="80%"></td>
			<td width="20%" align="right">
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
                <button class="btn btn-danger btn-sm" onclick="AddAcademicProgram();return false;">ADD ACADEMIC PROGRAM (MAJOR)</button>
<?php
}
?>
            </td>
		</tr>
		</table>

		<div class="CSSTable_SSPSLIST">
		<table id="programinfo" class="display" style="border-spacing:0; padding:0; width:100%;">
		<thead>
			<tr>
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
				<th>IDX</th>
<?php
}
?>
				<th>ACADEMIC PROGRAM</th>
                <th>DEGREE NAME</th>
				<th>DEPARTMENT NAME</th>
				<th>ADDED DATE</th>
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
				<th class="no-sort">OPERATION</th>
<?php
}
?>
			</tr>
		</thead>
		</table>
		</div>
	</div>
</div>


<?php include('footer.php');?>

