<?php
/**
 * Abet courses
 * Description: Update the survey information for the selected abet courses
 * Author: Dong Hyun Jeong
 *
 * 11/19/2025 - initial version created
 */

include_once 'session_handler.php';

$AvailableCourseIdx = '';
$Subject = '';
$Num = '';
$CRN = '';
$Survey = '';

if (array_key_exists('Idx', $_POST)
    && array_key_exists('Subject', $_POST)
    && array_key_exists('Survey', $_POST)
    && array_key_exists('Num', $_POST)
    && array_key_exists('CRN', $_POST))
{
    $AvailableCourseIdx = trim($_POST['Idx']);
    $Subject = trim($_POST['Subject']);
    $Survey = trim($_POST['Survey']);
    $Num = trim($_POST['Num']);
    $CRN = trim($_POST['CRN']);
}
else
{
    // unwanted illegal entry
    echo json_encode(['success' => false, 'error' => 'Missing required fields', 'code' => '0x00000000']);
    exit;
}

if ($AvailableCourseIdx == "" || $Subject == "" || $Num == "" || $CRN == "") {
    // no required information
    echo json_encode(['success' => false, 'error' => 'Missing required information', 'code' => '0x00000101']);
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/../config.php');
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AvailableCourseIdx = filter_var($AvailableCourseIdx, FILTER_VALIDATE_INT);
    $Num = filter_var($Num, FILTER_VALIDATE_INT);
    $CRN = filter_var($CRN, FILTER_VALIDATE_INT);

    if ($AvailableCourseIdx === false || $Num === false || $CRN === false) {
        throw new Exception('Invalid input format');
    }

    // Use htmlspecialchars instead of FILTER_SANITIZE_STRING
    $Subject = htmlspecialchars(strip_tags($Subject), ENT_QUOTES, 'UTF-8');
    $Survey = htmlspecialchars(strip_tags($Survey), ENT_QUOTES, 'UTF-8');

    // Update the Survey field
    // Adjust the stored procedure name and parameters according to your database schema
    $query = "CALL SP_UpdateAbetSurvey(?, ?, ?, ?, ?);";
    $params = [$AvailableCourseIdx, $Subject, $Num, $CRN, $Survey];
    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    if ($result) {
        echo json_encode(['success' => true, 'code' => '0x11111111']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Update failed', 'code' => '0x00000102']);
    }

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    echo json_encode(['success' => false, 'error' => 'Database error', 'code' => '0x00000500']);

    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'query' => '0x00000500'
    ]));

    error_log($DBCONNECTION->FormatQuery($query, $params));

} catch (Exception $e) {
    error_log($e->getMessage()); // Boring error messages from anything else!
    echo json_encode(['success' => false, 'error' => $e->getMessage(), 'code' => '0x00000000']);
}

