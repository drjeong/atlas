<?php
session_start();
header('Content-Type: application/json');

require_once(__DIR__ . '/php_include/dbconnection_class.php');

try {
    $DBCONNECTION = new Dbconnection();

    $gpi = $_POST['gpi'] ?? '';  // This will be like "SO 2-B"
    $program = $_POST['program'] ?? '';
    $academicYear = $_POST['academicYear'] ?? '';

    if (empty($gpi) || empty($program)) {
        throw new Exception('Missing required parameters');
    }

//    error_log("=== PI Details Request ===");
//    error_log("GPI (concatenated): $gpi");
//    error_log("Program: $program");
//    error_log("Academic Year: $academicYear");

    // Split the concatenated GPI (e.g., "SO 2-B" -> SO="SO 2", GPI="B")
    // The format is: CONCAT_WS('-', SO, GPI) = "SO X-Y"
    // We need to extract SO and GPI parts
    $gpiParts = explode('-', $gpi);
    if (count($gpiParts) >= 2) {
        // For "SO 2-B", we get ["SO 2", "B"]
        $soWithSpace = $gpiParts[0];  // "SO 2"
        $gpiCode = implode('-', array_slice($gpiParts, 1));  // "B" or could be "B-C" etc

//        error_log("Parsed - SO with space: '$soWithSpace', GPI code: '$gpiCode'");
    } else {
        throw new Exception('Invalid GPI format: ' . $gpi);
    }

    $courses = [];
    $totalScore = 0;
    $totalScores = 0;

    // Determine academic year to query
    if ($academicYear === 'Overall') {
        // Get all academic years from session
        if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS']) && is_array($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
            $academicYearIndices = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
        } else {
            $academicYearIndices = [intval($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'])];
        }
        $academicYearsStr = implode(',', array_map('intval', $academicYearIndices));
    } else {
        // Specific year - lookup the year index
        $yearQuery = "SELECT Idx FROM AcademicYears WHERE AcademicYear = ?";
        $yearResult = $DBCONNECTION->prepare_execute_catch_error($yearQuery, [$academicYear]);

        if ($yearResult && $DBCONNECTION->num_rows() > 0) {
            $yearRow = $DBCONNECTION->fetch_assoc();
            $academicYearsStr = intval($yearRow['Idx']);
//            error_log("Found year index: $academicYearsStr for year: $academicYear");
        } else {
            throw new Exception('Academic year not found: ' . $academicYear);
        }
    }

//    error_log("Academic Years String: $academicYearsStr");

    // Query using Scoresheet data - matching the SSPS query structure
    $query = "
        SELECT
            `GPIS`.`AcademicYear` AS AcademicYearIdx,
            `AYS`.`AcademicYear` AS AcademicYear,
            `AVCRSES`.`CourseNo`,
            `AVCRSES`.`Crn`,
            `AVCRSES`.`Title` AS CourseName,
            AVG(`SCSHEET`.`LevelOfAttainment`) AS AVG,
            COUNT(`SCSHEET`.`LevelOfAttainment`) AS TOTAL,
            SUM(`SCSHEET`.`LevelOfAttainment`) AS SUM_SCORES,
            CONCAT_WS('-', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`) AS FullGPI
        FROM `StudentOutcomes` AS `STNTOUTCMS`
        INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
        LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
        LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
        LEFT JOIN `AcademicYears` AS `AYS` ON (`GPIS`.`AcademicYear` = `AYS`.`Idx`)
        LEFT JOIN `AVCourses` AS `AVCRSES` ON (`ASSMNTMEASURES`.`AvailableCourseIdx` = `AVCRSES`.`Idx`)
        WHERE `GPIS`.`AcademicProgram` = ?
        AND `GPIS`.`AcademicYear` IN ($academicYearsStr)
        AND CONCAT_WS('-', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`) = ?
        AND `GPIS`.`TobeRemoved` = 0
        AND `SCSHEET`.`LevelOfAttainment` IS NOT NULL
        GROUP BY `GPIS`.`AcademicYear`, `AYS`.`AcademicYear`, `AVCRSES`.`Idx`, `AVCRSES`.`CourseNo`, `AVCRSES`.`Crn`, `AVCRSES`.`Title`, `STNTOUTCMS`.`SO`, `GPIS`.`GPI`
        HAVING COUNT(`SCSHEET`.`LevelOfAttainment`) > 0
        ORDER BY `AYS`.`AcademicYear` DESC, `AVCRSES`.`CourseNo`, `AVCRSES`.`Crn`
    ";

//    error_log("Executing main query with concatenated GPI match...");
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$program, $gpi]);

    $rowCount = 0;
    if ($result && $DBCONNECTION->num_rows() > 0) {
//        error_log("Found " . $DBCONNECTION->num_rows() . " rows");
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $rowCount++;
            $scoreCount = intval($row['TOTAL']);
            $sumScores = floatval($row['SUM_SCORES']);
            $avgScore = floatval($row['AVG']);

            $totalScore += $sumScores;
            $totalScores += $scoreCount;

//            error_log("Row $rowCount: Course={$row['CourseNo']}, CRN={$row['Crn']}, Scores=$scoreCount, Sum=$sumScores, Avg=$avgScore");

            $courses[] = [
                'courseNo' => $row['CourseNo'] ?? 'N/A',
                'crn' => $row['Crn'] ?? 'N/A',
                'courseName' => $row['CourseName'] ?? 'Unknown Course',
                'academicYear' => $row['AcademicYear'] ?? 'N/A',
                'scores' => $scoreCount,
                'avgScore' => number_format($avgScore, 2),
                'totalScore' => number_format($sumScores, 2)
            ];
        }
//        error_log("Total: $rowCount courses, $totalScores scores, sum=$totalScore");
    } else {
//        error_log("No rows found! Checking if data exists...");

        // Debug query: Check with concatenated GPI
        $checkQuery = "
            SELECT 
                COUNT(`SCSHEET`.`LevelOfAttainment`) AS score_count,
                SUM(`SCSHEET`.`LevelOfAttainment`) AS sum_scores,
                AVG(`SCSHEET`.`LevelOfAttainment`) AS avg_score,
                CONCAT_WS('-', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`) AS FullGPI
            FROM `StudentOutcomes` AS `STNTOUTCMS`
            INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`STNTOUTCMS`.`Idx` = `GPIS`.`SOIdx`)
            LEFT JOIN `AssessmentMeasures` AS `ASSMNTMEASURES` ON (`ASSMNTMEASURES`.`GPI` = `GPIS`.`Idx`)
            LEFT JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx` = `SCSHEET`.`AssessmentMeasureIdx`)
            WHERE `GPIS`.`AcademicProgram` = ?
            AND `GPIS`.`AcademicYear` IN ($academicYearsStr)
            AND CONCAT_WS('-', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`) = ?
            AND `GPIS`.`TobeRemoved` = 0
            AND `SCSHEET`.`LevelOfAttainment` IS NOT NULL
            GROUP BY CONCAT_WS('-', `STNTOUTCMS`.`SO`, `GPIS`.`GPI`)
        ";

        $checkResult = $DBCONNECTION->prepare_execute_catch_error($checkQuery, [$program, $gpi]);
        if ($checkResult && $DBCONNECTION->num_rows() > 0) {
            $checkRow = $DBCONNECTION->fetch_assoc();
            $totalScores = intval($checkRow['score_count']);
            $totalScore = floatval($checkRow['sum_scores']);

//            error_log("Found aggregated data: count=$totalScores, sum=$totalScore, avg=" . $checkRow['avg_score']);
//            error_log("Matched GPI: " . $checkRow['FullGPI']);
        } else {
//            error_log("No data found even with aggregated query!");
        }
    }

    $avgScore = $totalScores > 0 ? number_format($totalScore / $totalScores, 2) : '0.00';

//    error_log("Final response: courses=" . count($courses) . ", totalScores=$totalScores, avgScore=$avgScore");

    echo json_encode([
        'success' => true,
        'courses' => $courses,
        'totalScore' => number_format($totalScore, 2),
        'totalScores' => $totalScores,
        'avgScore' => $avgScore
    ]);

} catch (Exception $e) {
    error_log("ERROR in p_evluationpis_details.php: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());

    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}