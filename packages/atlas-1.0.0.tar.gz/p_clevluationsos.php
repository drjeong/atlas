<?php
/**
 * Evaluation of Student Outcomes
 * File: p_evluationsos.php
 * Description: Listing evaluation of student outcomes.
 */
?>

<?php
include('header.php');

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection(false);

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}
?>

    <script type="text/javascript">
        $(document).ready(function() {
            // Add event listener to the select element
            $("#_AY").on('change', function() {
                document.academicyear.submit();
            });
        });
    </script>

    <div class="pagebacklayout">
        <div class="row">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSE-LEVEL EVALUATION OF STUDENT OUTCOMES</span></p>

            <p style="text-align:center;font-size:13px;color:#333;margin-top:5px;padding:10px;background-color:#fff3cd;border-left:4px solid #ffc107;font-style:italic;">
                <strong>Note:</strong> Average score is calculated as the sum of all level of attainment scores divided by the <span style="color:#d9534f;font-weight:bold;">total number of scores</span> (not the number of students).
            </p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <?php include('control_allprograms.php'); ?>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:30%;">
                        <?php echo($AcademicYearSelection);?>
                    </td>
                    <td style="width:10%"></td>
                    <td style="width:60%; text-align: right">
                    </td>
                </tr>
            </table>

            <?php
            require_once(__DIR__ . '/php_include/dbconnection_class.php');
            $DBCONNECTION = new Dbconnection();

            $AbetCourseAvailable = false;
            $Query = "CALL SP_ChkAbetCourses( '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."', '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' )";
            if ($DBCONNECTION->gettotalcount($Query) > 0)
                $AbetCourseAvailable = true;

            if ($AbetCourseAvailable === false){
                echo <<<HTML
        <div class='col-md-12'>
            <div class="alert alert-info text-center" role="alert" style="padding: 40px; margin: 20px 0;">
                <h4 class="alert-heading">No ABET Courses Available</h4>
                <p class="mb-0">There are currently no ABET courses available for the selected academic year and program.</p>
                <hr>
                <p class="mb-0">Please select a different academic year or contact your administrator if you believe this is an error.</p>
            </div>
        </div>
HTML;
            } else {
                /////////////////////////////////////////////////////////////////////////////////
                // fetch abet courses' course-level evaluation results
                $Query = "CALL SP_FetchCourseLevelEvaluationResults('".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."', '" . $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] . "');";
//                error_log($Query);
                $DBCONNECTION->sendquery($Query);

                $data_array = array();
                $hasData = false;

                // Restructure data: group by AVCIdx, then collect all SOs for each course
                while ($row = $DBCONNECTION->fetch_assoc()) {
                    $hasData = true;
                    $AVCIdx = $row['AVCIdx'];

                    // Initialize course data if not exists
                    if (!isset($data_array[$AVCIdx])) {
                        $data_array[$AVCIdx] = array(
                                "ABCIdx" => $row['ABCIdx'],
                                "CourseNo" => isset($row['CourseNo']) ? $row['CourseNo'] : 'N/A',
                                "Credits" => isset($row['Credits']) ? $row['Credits'] : 'N/A',
                                "Title" => isset($row['Title']) ? $row['Title'] : 'N/A',
                                "Instructor" => isset($row['Instructor']) ? $row['Instructor'] : 'N/A',
                                "Semester" => isset($row['Semester']) ? $row['Semester'] : 'N/A',
                                "StudentOutcomes" => array()
                        );
                    }

                    // Add student outcome data
                    $SO = $row['SO'];
                    $AVG = $row['AVG'];
                    $TOTAL = ($row['TOTAL'] == 0) ? 1 : $row['TOTAL'];
                    $TOPFIFTY = $row['TOPFIFTY']; // >= 2
                    $TOPTWENTYFIVE = $row['TOPTWENTYFIVE']; // >= 3

                    // Handle null or empty AVG values
                    if ($AVG === null || $AVG === '' || $AVG == 0) {
                        $avgFormatted = '0.00';
                        $topFiftyPercent = '0.00';
                        $topTwentyFivePercent = '0.00';
                    } else {
                        $avgFormatted = sprintf('%.2f', $AVG);
                        $topFiftyPercent = sprintf('%.2f', ($TOPFIFTY / $TOTAL) * 100);
                        $topTwentyFivePercent = sprintf('%.2f', ($TOPTWENTYFIVE / $TOTAL) * 100);
                    }

                    $data_array[$AVCIdx]["StudentOutcomes"][] = array(
                            "SO" => $SO,
                            "AVG" => $avgFormatted,
                            "TOPFIFTY" => $topFiftyPercent,
                            "TOPTWENTYFIVE" => $topTwentyFivePercent
                    );
                }

                if (!$hasData || empty($data_array)) {
                    echo <<<HTML
        <div class='col-md-12'>
            <div class="alert alert-warning text-center" role="alert" style="padding: 30px; margin: 20px 0;">
                <h4 class="alert-heading">No Course-Level Evaluation Data Available</h4>
                <p class="mb-0">There are currently no course-level evaluation results for the selected academic year and program.</p>
            </div>
        </div>
HTML;
                } else {
                    echo <<<HTML
        <div class='col-md-12'>
            <!-- Page Content -->
            <div id="pagebacklayout_inner_noborder">
                <div class="CSSTable_ROUNDEDCORDER">
                    <table class="display">
                    <thead>
                        <tr>
                            <th style="height:50px;">COURSE INFO</th>
                            <th style="height:50px;">STUDENT OUTCOME</th>
                            <th>AVERAGE SCORE</th>
                            <th>% >= 2 (Developing)</th>
                            <th>% >= 3 (Satisfactory)</th>
                        </tr>                    
                    </thead>
                    <tbody>
HTML;
                    $background_color = '#efefef';
                    foreach ($data_array as $AVCIdx => $Data) {
                        $CourseNo = $Data['CourseNo'];
                        $Credits = $Data['Credits'];
                        $Title = $Data['Title'];
                        $Instructor = $Data['Instructor'];
                        $Semester = $Data['Semester'];
                        $StudentOutcomes = $Data['StudentOutcomes'];
                        $SOCnt = count($StudentOutcomes);

                        if ($SOCnt == 0) continue; // no data to show

                        $firstRow = true;
                        foreach ($StudentOutcomes as $outcome) {
                            if ($firstRow) {
                                echo <<<HTML
                        <tr style="border-spacing: 3px; background-color:$background_color">
                            <td rowspan="$SOCnt" style="width:40%;">
                                $CourseNo $Title ($Semester), Instructor: $Instructor
                            </td>
                            <td style="width:15%; text-align: center">{$outcome['SO']}</td>
                            <td style="width:15%; text-align: center">{$outcome['AVG']}</td>
                            <td style="width:15%; text-align: center">{$outcome['TOPFIFTY']}</td>
                            <td style="width:15%; text-align: center">{$outcome['TOPTWENTYFIVE']}</td>
                        </tr>
HTML;
                                $firstRow = false;
                            } else {
                                echo <<<HTML
                        <tr style="background-color:$background_color">
                            <td style="width:15%; text-align: center">{$outcome['SO']}</td>
                            <td style="width:15%; text-align: center">{$outcome['AVG']}</td>
                            <td style="width:15%; text-align: center">{$outcome['TOPFIFTY']}</td>
                            <td style="width:15%; text-align: center">{$outcome['TOPTWENTYFIVE']}</td>
                        </tr>
HTML;
                            }
                        }

                        $background_color = ($background_color == '#efefef') ? '#ffffff' : '#efefef';
                    }
                    echo <<<HTML
                    </tbody>
                    </table>
                </div>
                <!-- /#page-content-wrapper -->
            </div>
        </div>
HTML;
                }
            }
            ?>

        </div>
    </div>

<?php include('footer.php');?>