<?php
/**
 * Removing Abet Syllabus
 * Description: removing the selected abet syllabus
 * Author: Dong Hyun Jeong
 *
 * 11/10/2024 -- initial version created
 */


include_once 'session_handler.php';

$SyllabusIdx = (isset($_POST['sid'])) ? trim($_POST['sid']) : '';
$CourseIdx = (isset($_POST['cid'])) ? trim($_POST['cid']) : '';
$AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';

if ($SyllabusIdx=="" || $CourseIdx=="" || $AcademicProgramIdx=="") {
    echo "0x00000011";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once ('./php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $SyllabusIdx = filter_var($SyllabusIdx, FILTER_VALIDATE_INT);
    if ($SyllabusIdx === false) {
        throw new Exception('Invalid Index format');
    }
    $CourseIdx = filter_var($CourseIdx, FILTER_VALIDATE_INT);
    if ($CourseIdx === false) {
        throw new Exception('Invalid Index format');
    }

    $query = "CALL SP_RemoveAbetSyllabusInfo(?, ?, ?);";
    $params = [$CourseIdx, $SyllabusIdx, $AcademicProgramIdx];
    $result = $DBCONNECTION->prepare_execute_catch_error($query, $params);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x09000010') !== false) {
        echo '0x09000010';  // Cannot delete: course is referenced already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500',
            'query' => $DBCONNECTION->FormatQuery($query, $params)
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}