<?php
/**
 * Listing Scores
 * File: u_course_scoresheets_ssps.php
 * Description: listing scores of the selected course
 *
 *
 *
 */


include_once 'session_handler.php';


$AbetCourseIdx='';
$AvailableCourseIdx='';
$AcademicProgramIdx='';
if (array_key_exists('_ABTC', $_GET) && array_key_exists('_AVC', $_GET) && array_key_exists('_AP', $_GET)) {
    $AbetCourseIdx = trim($_GET['_ABTC']);
    $AvailableCourseIdx = trim($_GET['_AVC']);
    $AcademicProgramIdx = trim($_GET['_AP']);
}
else {
    // illegal entry
    exit;
}

require_once ('../php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();

// Fetching # of students
$Query = "SELECT `NumStudents` FROM `ContinuousImprovement` WHERE `AbetCourseIdx` = ? AND `AvailableCourseIdx` = ?;";
$result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AbetCourseIdx, $AvailableCourseIdx]);
$NumOfStudents=0;  // # of students to be assessed
if ($row = $DBCONNECTION->fetch_assoc())
{
    $NumOfStudents = $row['NumStudents'];
}

// Fetching assessment measures
$Query = "CALL SP_FetchScoreSheetAssessmentMeasures( ?, ? );";
$result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AbetCourseIdx, $AvailableCourseIdx]);

$AssessmentMeasures_Array = array();
while ($row = $DBCONNECTION->fetch_assoc())
{
    $GPIIdx = $row["GPIIdx"];
    $AssessmentMeasures_Array[$row["Idx"]] = $GPIIdx;
}

if (count($AssessmentMeasures_Array) == 0)
{   // no records found
    echo('{"draw":0,"recordsTotal":0,"recordsFiltered":0,"data":[]}');
    exit;
}

// Fetching Classroster Information if exists
require_once(__DIR__ . '/../../config.php');
$Classroster_Array = array();
$Query = "CALL SP_FetchClassRoster(?, ?);";
$result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx, __DB_ENCRYPTION_KEY]);
//echo "CALL SP_FetchClassRoster($AvailableCourseIdx, ".__DB_ENCRYPTION_KEY.");";

while ($row = $DBCONNECTION->fetch_assoc())
{
    $Classroster_Array[] = array(
        'StudentNo' => (int)($row['StudentNo'] ?? 0),
        'StudentName' => $row['StudentName'] ?? '',
        'StudentMajor' => $row['StudentMajor'] ?? '',
        'AcademicProgramIdx' => $row['AcademicProgramIdx'],
        'Degree' => $row['Degree'] ?? '',
        'IsDropped' => (bool)($row['IsDropped'] ?? false)
    );
}

// Fetching Scoresheet Information
$Scoresheet_Array = array();
foreach ($AssessmentMeasures_Array AS $AssessmentMeasureIdx => $GPIIdx)
{
    $Query = "CALL SP_FetchScoreSheetAssessmentMeasurestInfoDisplay(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AssessmentMeasureIdx]);

    while ($row = $DBCONNECTION->fetch_assoc()) {
        $StudentNo = (int)($row['StudentNo'] ?? 0);
        $CustomColumnInfo = $row['CustomColumnInfo'];
        $LevelOfAttainment = $row['LevelOfAttainment'] ?? '';

        if ($StudentNo > 0) {
            $Scoresheet_Array[$AssessmentMeasureIdx][$StudentNo] = [
                'LevelOfAttainment' => $LevelOfAttainment,
                'CustomColumnInfo' => $CustomColumnInfo
            ];
        }
    }
}

// Build data array
$data_array = array();

// Method 1: Use Class roster if it exists
if (!empty($Classroster_Array)) {
    if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {

        foreach ($Classroster_Array as $student)
        {
            $StudentNo = $student['StudentNo'];
            $row_array = array();

            $row_array['StudentNo'] = $StudentNo;
            $row_array['StudentName'] = $student['StudentName'];
            $row_array['StudentMajor'] = $student['StudentMajor'];
            $row_array['Degree'] = $student['Degree'];
            $row_array['IsDropped'] = $student['IsDropped'];

            foreach ($AssessmentMeasures_Array AS $AssessmentMeasureIdx => $GPIIdx)
            {
                $row_array['CustomColumnInfo'] = $row_array['StudentName'] . ' (' . $row_array['Degree'] . ')';
                if ($student['AcademicProgramIdx'] != $AcademicProgramIdx) {
                    $row_array['IsDropped'] = 1;
//                $row_array['Measure' . $AssessmentMeasureIdx] = ''; // not allowed to enter levelofattainment if the student's program is not matched.
                }

                $row_array['Measure' . $AssessmentMeasureIdx] = $Scoresheet_Array[$AssessmentMeasureIdx][$StudentNo]['LevelOfAttainment'] ?? '';
            }

            $data_array[] = $row_array;
        }

    } else {

        foreach ($Classroster_Array as $student)
        {
            if ($student['AcademicProgramIdx'] != $AcademicProgramIdx) {
                continue;
            }

            $StudentNo = $student['StudentNo'];
            $row_array = array();

            $row_array['StudentNo'] = $StudentNo;
            $row_array['StudentName'] = '';//$student['StudentName'];
            $row_array['StudentMajor'] = $student['StudentMajor'];
            $row_array['AP'] = $student['AcademicProgramIdx'];
            $row_array['Degree'] = $student['Degree'];
            $row_array['IsDropped'] = $student['IsDropped'];

            foreach ($AssessmentMeasures_Array AS $AssessmentMeasureIdx => $GPIIdx)
            {
                $row_array['CustomColumnInfo'] = $row_array['StudentName'] . ' (' . $row_array['Degree'] . ')';
                $row_array['Measure' . $AssessmentMeasureIdx] = $Scoresheet_Array[$AssessmentMeasureIdx][$StudentNo]['LevelOfAttainment'] ?? '';
            }

            $data_array[] = $row_array;
        }

    }
}
// Method 2: Fallback to sequential numbering if Classroster doesn't exist
else {
    for ($Student = 1; $Student <= $NumOfStudents; $Student++)
    {
        $row_array = array();

        $row_array['StudentNo'] = $Student;
        $row_array['StudentName'] = '';
        $row_array['StudentMajor'] = '';
        $row_array['Degree'] = '';
        $row_array['IsDropped'] = false;

        foreach ($AssessmentMeasures_Array AS $AssessmentMeasureIdx => $GPIIdx)
        {
            $row_array['CustomColumnInfo'] = $Scoresheet_Array[$AssessmentMeasureIdx][$Student]['CustomColumnInfo'] ?? $Student;
            $row_array['Measure'.$AssessmentMeasureIdx] = $Scoresheet_Array[$AssessmentMeasureIdx][$Student]['LevelOfAttainment'] ?? '';
        }

        $data_array[] = $row_array;
    }
}

//print_r($data_array);

$json_data = array("data" => $data_array);
echo json_encode($json_data);

