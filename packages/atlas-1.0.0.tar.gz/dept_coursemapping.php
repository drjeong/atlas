<?php
/**
 * Abet courses
 * Description: Listing courses' SO / PI mapping
 * Author: Dong Hyun Jeong
 *
 * 11/19/2024 - initial version created
 * 12/14/2025 - revise to handle course and year indexes for updating level and requirement
 *
 */

//include('checker_programdirector.php');
include('header.php');
?>

<?php

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection();

?>

<script src="js/datatable-utils-search.min.js"></script>
<script src="js/datatable-utils-rowselector.min.js?v=0.0.001"></script>
<script src="js/soConverter.min.js"></script>

<script src="js/dlg_commons.js"></script>

<script>
    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        NO_SO_DATA: '0x00000100',
        NO_PI_DATA: '0x00000200',
        SAME_ITEM_EXIST: '0x00200011',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
        NOT_DATA_IN_SOURCE_YEAR: '0x09500011',
        DATA_EXIST_ALREADY_IN_TARGET_YEAR: '0x09500012',
    };

    async function AsyncGetOptions(option = 1) {
        try {
            const rawResult = await async_commons.makeApiCall(`api_getoptions.php?sel=cm&op=${option}`, {});
            const result = JSON.parse(rawResult);

            if (result.status === 'ERROR') {
                throw new Error(result.message);
            }

            return result.data;
        } catch (error) {
            await async_commons.handleError(error);
            throw error;
        }
    }


    async function downloadSyllabus(SyllabusIndex, AcademicYearValue, AcademicProgramIdx, Subject, Num) {
        try {
            const blob = await async_commons.makeApiCall('create_abetsyllabus_pdf.php', {
                _idx: SyllabusIndex,
                _ay: AcademicYearValue,
                _ap: AcademicProgramIdx
            }, true, 'blob');

            if (blob.type === "application/pdf") {
                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);

                let AssessmentPDF_FileName = 'abet_syllabus';
                AssessmentPDF_FileName += '_' + String(Subject).toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '_' + String(Num).toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '.pdf';

                link.download = AssessmentPDF_FileName;
                link.click();

                // Clean up
                setTimeout(() => {
                    window.URL.revokeObjectURL(link.href);
                }, 100);

                await async_commons.showSuccessMessage('SUCCESS', 'PDF downloaded successfully!');
            } else {
                throw new Error('Invalid file type received');
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
        }
    }
</script>

<?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
<script>
    function DuplicateAbetSOsPIs(_AYF = '', _AYT = '') {
        showDuplicateDialog({
            title: 'DUPLICATE SOs, PIs, and SYLLABUS INFO',
            yearFrom: _AYF,
            yearTo: _AYT,
            performDuplication: DuplicateAbetSOsPIs_Perform
        });
    }

    async function DuplicateAbetSOsPIs_Perform(_AYF, _AYT) {
        try {
            const result = await async_commons.makeApiCall('dept_coursemapping_duplicate_ajax.php', {
                ayf: _AYF,
                ayt: _AYT
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage(
                        'DUPLICATED',
                        'PI are duplicated successfully!'
                    );
                    // location.reload();
                    break;
                }
                case ErrorCodes.NOT_DATA_IN_SOURCE_YEAR: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        'The selected "DUPLICATE FROM YEAR" does not have Course Mappings.'
                    );
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    let DataTable_AbetCourseList = null;
    let DataTable_CoursesList = null;
    function AssignPIs(CourseIdx, AcademicYear, AcademicYearInfo, SOIdxes, PIIdxes=null, CourseInfo=null)
    {
        let DataTable_GPIList = null;
        const formContent = `
        <form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>
                    <input type="text" name="_AY" id="_AY" class="input-sm form-control" value="${AcademicYearInfo}" disabled>
                </div>
                <div class="input-group" style="width:100%; margin-top:10px;">
                    <span class="input-group-addon" style="width:230px;">Auto Select PIs</span>
                    <input type="text" name="_AutoSelect" id="_AutoSelect" class="input-sm form-control" placeholder="e.g., SO 1-A, SO 2-A, SO 3-B">
                    <span class="input-group-btn">
                        <button type="button" class="btn btn-primary btn-sm" id="btnAutoSelect">
                            <span class="glyphicon glyphicon-check"></span> Select
                        </button>
                    </span>
                </div>
                <table id="gpilist" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th class="no-sort" style="width:3px"></th>
                        <th>SO</th>
                        <th>PI</th>
                        <th>DESC</th>
                    </tr>
                    </thead>
                </table>
            </div></form>`;

        let title = '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN PERFORMANCE INDICATORS';
        if (CourseInfo != null) {
            title += ': ' + CourseInfo;
        }
        title += '</span>';

        createModalDialog({
            className: "dialogWidth60p",
            title: title,
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){

                        const selected = DataTable_GPIList.rows({ selected: true }).data();
                        const unselected  = DataTable_GPIList.rows({ selected: false }).data();

                        let checked_unchecked_list = '';
                        for(let i = 0; i < selected.length; ++i) {
                            if (checked_unchecked_list !=='') checked_unchecked_list += "|";
                            checked_unchecked_list += selected[i].SOIdx + "_" + selected[i].GPIIdx+"_true";
                        }
                        for(let i = 0; i < unselected.length; ++i) {
                            if (checked_unchecked_list !=='') checked_unchecked_list += "|";
                            checked_unchecked_list += unselected[i].SOIdx + "_" + unselected[i].GPIIdx+"_false";
                        }
                        AssignPIs_Perform(CourseIdx, AcademicYear, checked_unchecked_list);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            // Auto-select button click handler
            $('#btnAutoSelect').on('click', function() {
                const input = $('#_AutoSelect').val().trim();
                if (!input) return;

                // Deselect all rows first
                DataTable_GPIList.rows().deselect();

                // Parse the input string
                // Example: "SO 1-A, SO 2-A, SO 3-B"
                const items = input.split(',').map(s => s.trim());
                const notFoundItems = [];

                items.forEach(item => {
                    // Match pattern like "SO 1-A" or "SO 1 - A"
                    const match = item.match(/SO\s*(\d+)\s*-\s*([A-Z])/i);
                    if (match) {
                        const soNumber = match[1];
                        const piLetter = match[2].toUpperCase();
                        let found = false;

                        // Find and select matching rows in the DataTable
                        DataTable_GPIList.rows().every(function() {
                            const data = this.data();
                            // Assuming SO column contains "SO 1" format and GPI contains "A", "B", etc.
                            const soMatch = data.SO.match(/\d+/);
                            const piMatch = data.GPI.match(/[A-Z]/i);

                            if (soMatch && piMatch &&
                                soMatch[0] === soNumber &&
                                piMatch[0].toUpperCase() === piLetter) {
                                this.select();
                                found = true;
                            }
                        });

                        // Track items that were not found
                        if (!found) {
                            notFoundItems.push(item);
                        }
                    }
                });

                // Show warning if any items were not found
                if (notFoundItems.length > 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Items Not Found',
                        html: 'The following items were not found:<br><strong>' + notFoundItems.join(', ') + '</strong>',
                        confirmButtonText: 'OK'
                    });
                }
            });
        }).find('.modal-dialog').css({
            'margin-top': function (){
                let w = $( window ).height();
                let b = $(this).height();
                let h = (w-b)*0.1;
                return h+"px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"   // enable draggable dialog
        }).find('.modal-header').css({
            'cursor': 'move'            // change mouse cursor for dragging on modal header
        });

        const urlGPIList = `ssps/dept_coursemapping_gpilist_ssps.php?_IDX=${CourseIdx}&_AY=${AcademicYear}&_SO=${encodeURIComponent(SOIdxes)}`;
        DataTable_GPIList = $("#gpilist").DataTable({
            "processing": true,
            "serverSide": false,
            "iDisplayLength": 8,
            "select": {
                'style': 'multi'
            },
            "lengthChange": false,
            "sDom": 'tp', // invisible search box & show pagination tabs
            "ajax": urlGPIList,
            "order": [[ 1, 'asc' ], [ 2, 'asc' ]],
            "fnDrawCallback": function() {
                $('#gpilist tr td:nth-child(1)').css('text-align', 'center');
                $('#gpilist tr td:nth-child(2)').css('text-align', 'center');
                $('#gpilist tr td:nth-child(3)').css('text-align', 'center');

                $('#gpilist tr td:nth-child(4)').css('width', '80%');
            },
            "columns": [
                {
                    "data": 'DT_RowId',
                    "render": function ( data, type, full, meta ) {
                        if (PIIdxes !== '' && PIIdxes != null){
                            let res = PIIdxes.split(",");
                            for(let i = 0; i < res.length; i++) {
                                if (Number(res[i].trim()) === full.GPIIdx) {
                                    DataTable_GPIList.row('#'+data).select();
                                }
                            }
                        }
                        return '';
                    }
                },
                { "data": 'SO' },
                { "data": 'GPI' },
                { "data": 'Desc' },
            ],
            "columnDefs": [
                {
                    'orderable': false,
                    'className': 'select-checkbox',
                    'targets': 0
                },
                {
                    "targets"  : 'no-sort',
                    "orderable": false,
                }
            ]
        });
    }

    async function AssignPIs_Perform(CourseIdx, _AY, CheckedUncheckedPIs) {
        try {
            const result = await async_commons.makeApiCall('dept_coursemapping_assign_gpi_ajax.php', {
                abetcrs: CourseIdx,
                ay: _AY,
                gpi: CheckedUncheckedPIs
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ASSIGNED', 'GPIS are assigned!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    // ----------------------------------------------------------------------------------------------
    function toggleOtherInput(selectElement) {
        const otherInputDiv = document.getElementById('otherInputDiv');
        const otherInput = document.getElementById('_ReqOther');

        if (selectElement.value === 'Other') {
            otherInputDiv.style.display = 'flex';
            otherInput.required = true;
            otherInput.focus();
        } else {
            otherInputDiv.style.display = 'none';
            otherInput.required = false;
            otherInput.value = '';
        }
    }

    function ValidateItems(popupForm)
    {
        if (popupForm._Req.value.isEmpty())
        {
            popupForm._Req.focus();
            Swal.fire({title:"ERROR", text: "Requirement is not selected!!", icon:"error"});

            return false;
        }
        else if (popupForm._Req.value === 'Other')
        {
            if (popupForm._ReqOther.value.isEmpty()) {
                popupForm._ReqOther.focus();
                Swal.fire({title:"ERROR", text: "Requirement is not entered!!", icon:"error"});
                return false;
            }
        }
        return true;
    }

    function AssignReqToSelectedCourses() {
        // Check if DataTable is empty
        if (DataTable_AbetCourseList.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses
        const selected = DataTable_AbetCourseList.rows({ selected: true }).data();
        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        // Create pipe-separated string of paired course data (Idx:AcademicYear)
        const coursePairs = selected
            .toArray()
            .map(course => `${encodeURIComponent(course.Idx)}:${encodeURIComponent(course.AcademicYear)}`)
            .join('|');

        // Assign requirement
        AssignRequirement(coursePairs);
    }

    function AssignRequirement(coursePairs) {
        let DataTable_SOList = null;
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST">
                <div class="input-group" style="width:100%">
                    <span class="input-group-addon" style="width:230px;">Course Requirement<span style="color:red">*</span></span>
                    <select name="_Req" id="_Req" class="input-sm form-control" onchange="toggleOtherInput(this)">
                        <option value=""></option>
                        <option value="Core">Core</option>
                        <option value="Elective">Elective</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div id="otherInputDiv" class="input-group" style="width:100%; display:none; margin-top:10px;">
                    <span class="input-group-addon" style="width:230px;">Enter the Other Requirement:</span>
                    <input type="text" name="_ReqOther" id="_ReqOther" class="input-sm form-control">
                </div>
            </div>
        </form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN COURSE REQUIREMENT</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');
                        if (!ValidateItems(popupForm)) return false;

                        const requirement = (popupForm._Req.value !== 'Other') ? popupForm._Req.value : popupForm._ReqOther.value;

                        AssignRequirement_Perform(coursePairs, requirement);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        }).find('.modal-dialog').css({
            'margin-top': function (){
                let w = $( window ).height();
                let b = $(this).height();
                let h = (w-b)*0.1;
                return h+"px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"
        }).find('.modal-header').css({
            'cursor': 'move'
        });
    }

    async function AssignRequirement_Perform(coursePairs, _Req) {
        try {
            const result = await async_commons.makeApiCall('dept_coursemapping_assign_requirement_ajax.php', {
                coursePairs: coursePairs,
                req: _Req
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Requirement information is assigned!');
                    await async_commons.unselectRowsInDataTable();
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }


    function AssignLevelToSelectedCourses() {
        // Check if DataTable is empty
        if (DataTable_AbetCourseList.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses
        const selected = DataTable_AbetCourseList.rows({ selected: true }).data();
        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        // Create pipe-separated string of paired course data (Idx:AcademicYear)
        const coursePairs = selected
            .toArray()
            .map(course => `${encodeURIComponent(course.Idx)}:${encodeURIComponent(course.AcademicYear)}`)
            .join('|');

        // Assign level
        AssignLevel(coursePairs);
    }

    function AssignLevel(coursePairs) {
        let DataTable_SOList = null;
        const formContent =
            `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST">
                <div class="input-group" style="width:100%">
                    <span class="input-group-addon" style="width:230px;">Course Level<span style="color:red">*</span></span>
                    <select name="_Level" id="_Level" class="input-sm form-control">
                        <option value=""></option>
                        <option value="1">Introductory</option>
                        <option value="2">Practice</option>
                        <option value="3">Mastery</option>
                    </select>
                </div>
            </div>
        </form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN COURSE LEVEL</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');

                        if (!popupForm._Level.value) {
                            Swal.fire({
                                title: "ERROR",
                                text: "Please select a course level!",
                                icon: "error"
                            });
                            return false;
                        }

                        AssignLevel_Perform(coursePairs, popupForm._Level.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
        }).find('.modal-dialog').css({
            'margin-top': function (){
                let w = $( window ).height();
                let b = $(this).height();
                let h = (w-b)*0.1;
                return h+"px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"
        }).find('.modal-header').css({
            'cursor': 'move'
        });
    }

    async function AssignLevel_Perform(coursePairs, _Level) {
        try {
            const result = await async_commons.makeApiCall('dept_coursemapping_assign_level_ajax.php', {
                coursePairs: coursePairs,
                level: _Level
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Level information is assigned!');
                    await async_commons.unselectRowsInDataTable();
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }


    //---------------------------------------------------------------------------------------
    function AssignSOs(CourseIdx, AcademicYear, AcademicYearInfo, SOIdxes=null, CourseInfo=null)
    {
        let DataTable_SOList = null;
        const formContent =
            `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
                <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                    <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>
                        <input type="text" name="_AY" id="_AY" class="input-sm form-control" value="${AcademicYearInfo}" disabled>
                    </div>
                    <div class="input-group" style="width:100%; margin-top:10px;">
                        <span class="input-group-addon" style="width:230px;">Auto Select SOs</span>
                        <input type="text" name="_AutoSelectSOs" id="_AutoSelectSOs" class="input-sm form-control" placeholder="e.g., SO 1-A, SO 2-A, SO 3-B or SO 1, SO 2, SO 3">
                        <span class="input-group-btn">
                            <button type="button" class="btn btn-primary btn-sm" id="btnAutoSelectSOs">
                                <span class="glyphicon glyphicon-check"></span> Select
                            </button>
                        </span>
                    </div>
                    <table id="solist" class="display" style="border-spacing:0; padding:0; width:100%;">
                        <thead>
                        <tr>
                            <th class="no-sort" style="width:3px"></th>
                            <th>SO</th>
                            <th>DESC</th>
                        </tr>
                        </thead>
                    </table>
                </div></form>`;

        const  title = `<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ASSIGN STUDENT OUTCOMES${CourseInfo != null ? ': ' + CourseInfo : ''}</span>`;

        createModalDialog({
            className: 'dialogWidth60p',
            title: title,
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ASSIGN",
                    className: 'btn-success',
                    callback: function(){

                        let selected = DataTable_SOList.rows({ selected: true }).data();
                        let unselected  = DataTable_SOList.rows({ selected: false }).data();

                        let checked_unchecked_list = '';
                        for(let i = 0; i < selected.length; ++i) {
                            if (checked_unchecked_list !== '') checked_unchecked_list += "|";
                            checked_unchecked_list += encodeURIComponent(selected[i].Idx + "_true");
                        }
                        for(let i = 0; i < unselected.length; ++i) {
                            if (checked_unchecked_list !== '') checked_unchecked_list += "|";
                            checked_unchecked_list += encodeURIComponent(unselected[i].Idx + "_false");
                        }
                        AssignSOs_Perform(CourseIdx, AcademicYear, checked_unchecked_list);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            // Auto-select button click handler
            $('#btnAutoSelectSOs').on('click', function() {
                const input = $('#_AutoSelectSOs').val().trim();
                if (!input) return;

                // Deselect all rows first
                DataTable_SOList.rows().deselect();

                // Parse the input string
                // Example: "SO 1, SO 2, SO 3"
                const items = input.split(',').map(s => s.trim());

                items.forEach(item => {
                    // Match pattern like "SO 1"
                    const match = item.match(/SO\s*(\d+)/i);
                    if (match) {
                        const soNumber = match[1];

                        // Find and select matching rows in the DataTable
                        DataTable_SOList.rows().every(function() {
                            const data = this.data();
                            // Assuming SO column contains "SO 1" format
                            const soMatch = data.SO.match(/\d+/);

                            if (soMatch && soMatch[0] === soNumber) {
                                this.select();
                            }
                        });
                    }
                });
            });

        }).find('.modal-dialog').css({
            'margin-top': function (){
                let w = $( window ).height();
                let b = $(this).height();
                let h = (w-b)*0.1;
                return h+"px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"   // enable draggable dialog
        }).find('.modal-header').css({
            'cursor': 'move'            // change mouse cursor for dragging on modal header
        });

        DataTable_SOList = $("#solist").DataTable({
            processing: true,
            serverSide: false,
            iDisplayLength: 8,
            lengthChange: false,
            select: {
                style: 'multi'
            },
            sDom: 'tp', // invisible search box & show pagination tabs
            ajax: 'ssps/dept_coursemapping_solist_ssps.php?_AY='+AcademicYear,
            order: [[ 1, 'asc' ]],
            fnDrawCallback: function() {
                $('#solist tr td:nth-child(1)').css('text-align', 'center');
                $('#solist tr td:nth-child(2)').css('text-align', 'center');
                $('#solist tr td:nth-child(3)').css('width', '80%');
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function ( data, type, full, meta ) {
                        let rowId = full.Idx; // // Get Idx
                        if (SOIdxes!=null)
                        {
                            if (SOIdxes.search(rowId) >=0)
                                DataTable_SOList.row('#'+data).select();
                        }
                        return '';
                    }
                },
                { data: 'SO' },
                { data: 'Desc' },
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets  : 'no-sort',
                    orderable: false,
                }
            ],

        });
    }

    async function AssignSOs_Perform(CourseIdx, _AY, CheckedUncheckedSOs) {
        try {
            const result = await async_commons.makeApiCall('dept_coursemapping_assign_so_ajax.php', {
                ay: _AY,
                sos: CheckedUncheckedSOs,
                abetcrs: CourseIdx
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ASSIGNED', 'Student outcomes are assigned!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }


    async function RemoveCourseMapping(Idx, AcademicYearInfo, Subject, Num, Title, Syllabus) {
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted content (<span style="color:red">${AcademicYearInfo} ${Subject} ${Num} ${Title}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('dept_coursemapping_remove_ajax.php', {
                id: Idx
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected course mapping has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected course mapping cannot be deleted because it is used already.');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function AddCourses_Perform(_AY, _SELECTEDCOURSES, _SELECTEDCOURSESABETSYLLABI) {
        try {
            const result = await async_commons.makeApiCall('dept_coursemapping_add_ajax.php', {
                ay: _AY,
                crses: _SELECTEDCOURSES,
                abetbi: _SELECTEDCOURSESABETSYLLABI
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'Course is added!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function AddCourses() {
        const [selectedAcademicYearValue, selectedAcademicYearText] = async_commons.getSelectedAcademicYear();
        if (selectedAcademicYearValue === '') {
            return;
        }

        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div class="CSSTable_SSPSLIST" style="min-height:370px;">
                <div class="input-group" style="width:100%">
                    <span class="input-group-addon" style="width:230px;">Target Academic Year<span style="color:red">*</span></span>
                    <input type="hidden" name="_AY" id="_AY" class="input-sm form-control" value="${selectedAcademicYearValue}" readonly>
                    <input type="text" name="_AYTXT" id="_AYTXT" class="input-sm form-control" value="${selectedAcademicYearText}" readonly>
                </div>
                <div class="input-group" style="width:100%; margin-top:10px;">
                    <span class="input-group-addon" style="width:230px;">Bulk Select Courses</span>
                    <input type="text" name="bulkCourseInput" id="bulkCourseInput" class="input-sm form-control"
                        placeholder="Enter courses (e.g., CCEN 101, ELEC 225, ELEC 226, APCT 231)">
                    <span class="input-group-btn">
                        <button type="button" class="btn btn-primary btn-sm" id="bulkSelectBtn">
                            <span class="glyphicon glyphicon-check"></span> Select
                        </button>
                    </span>
                </div>
                <table id="selectedcouselist" class="display" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                        <tr>
                            <th class="toggle-all" style="width:3px"></th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                            <th>ACADEMIC PROGRAM</th>
                            <th>MASTER SYLLABUS</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th>SUBJECT</th>
                            <th>NUM</th>
                            <th>TITLE</th>
                            <th>CREDITS</th>
                            <th>ACADEMIC PROGRAM</th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </form>`;

        const rowSelector = new DataTableRowSelector('selectedcouselist', {
            counterId: 'selectedCount',
            toggleButtonId: 'toggleSelected',
            itemName: 'course'
        });

        createModalDialog({
            className: "dialogWidth60p",
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD COURSES</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ADD",
                    className: 'btn-success',
                    callback: function() {
                        const popupForm = document.getElementById('popupfrm');
                        let selected = rowSelector.getSelectedData();

                        if (!selected.length) {
                            Swal.fire({
                                title: "ERROR",
                                text: "You need to select at least one course!!",
                                icon: "error"
                            });
                            return false;
                        }

                        const selectedCourses = selected.map(course => course.Idx).join('|');
                        const selectedCoursesAbetSyllabi = selected.map(course => course.ASIdx).join('|');
                        AddCourses_Perform(popupForm._AY.value, selectedCourses, selectedCoursesAbetSyllabi);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function() {}
                }
            }
        }).on('shown.bs.modal', function() {
            AsyncGetOptions(4)
                .then(data => {
                    if (data === ErrorCodes.NO_SO_DATA) {
                        bootbox.hideAll();
                        Swal.fire({
                            title: "ERROR",
                            text: "No Student Outcomes exists in the Selected Academic Year!",
                            icon: "error"
                        });
                    } else if (data === ErrorCodes.NO_PI_DATA) {
                        bootbox.hideAll();
                        Swal.fire({
                            title: "ERROR",
                            text: "No Performance Indicators exists in the Selected Academic Year!",
                            icon: "error"
                        });
                    }
                })
                .catch(error => {
                    console.error('Error checking data:', error);
                    Swal.fire({
                        title: "ERROR",
                        text: "Failed to check data",
                        icon: "error"
                    });
                });
        }).find('.modal-dialog').css({
            'margin-top': function() {
                let w = $(window).height();
                let b = $(this).height();
                let h = (w - b) * 0.1;
                return h + "px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"
        }).find('.modal-header').css({
            'cursor': 'move'
        });

        DataTable_CoursesList = $("#selectedcouselist").DataTable({
            processing: true,
            serverSide: true,
            iDisplayLength: 8,
            lengthChange: false,
            select: {
                style: 'multi',
                selector: 'td'
            },
            dom: `t<"row"<"col-sm-6"<"filterControls">><"col-sm-6"p>>`,
            initComplete: function() {
                rowSelector.init(DataTable_CoursesList);

                // Setup bulk select functionality
                $('#bulkSelectBtn').on('click', function() {
                    const input = $('#bulkCourseInput').val().trim();
                    if (!input) {
                        Swal.fire({
                            title: "Warning",
                            text: "Please enter course codes to select",
                            icon: "warning"
                        });
                        return;
                    }

                    // Parse the input - supports formats like "CCEN 101, ELEC 225" or "CCEN101,ELEC225"
                    const courseEntries = input.split(',').map(entry => entry.trim());
                    const coursesToSelect = [];

                    courseEntries.forEach(entry => {
                        // Match patterns like "CCEN 101" or "CCEN101"
                        const match = entry.match(/^([A-Z]+)\s*(\d+)$/i);
                        if (match) {
                            coursesToSelect.push({
                                subject: match[1].toUpperCase(),
                                num: match[2]
                            });
                        }
                    });

                    if (coursesToSelect.length === 0) {
                        Swal.fire({
                            title: "Error",
                            text: "No valid course codes found. Use format: SUBJ NUM (e.g., CCEN 101, ELEC 225)",
                            icon: "error"
                        });
                        return;
                    }

                    // Select matching rows
                    let selectedCount = 0;
                    DataTable_CoursesList.rows().every(function() {
                        const rowData = this.data();
                        const match = coursesToSelect.some(course =>
                            course.subject === rowData.Subject && course.num === rowData.Num
                        );

                        if (match) {
                            this.select();
                            selectedCount++;
                        }
                    });

                    rowSelector.updateSelectedCount();

                    if (selectedCount > 0) {
                        Swal.fire({
                            title: "Success",
                            text: `Selected ${selectedCount} course(s)`,
                            icon: "success",
                            timer: 1500,
                            showConfirmButton: false
                        });
                    } else {
                        Swal.fire({
                            title: "Warning",
                            text: "No matching courses found in the table",
                            icon: "warning"
                        });
                    }
                });
            },
            ajax: `ssps/dept_coursemapping_courselist_ssps.php?_AY=${selectedAcademicYearValue}`,
            order: [[1, 'asc'], [2, 'asc']],
            fnDrawCallback: function() {
                $('#selectedcouselist tr td:nth-child(1)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(2)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(3)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(4)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(5)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(6)').css('text-align', 'center');
                $('#selectedcouselist tr td:nth-child(7)').css('text-align', 'center');

                $('#selectedcouselist tr td:nth-child(2)').css('width', '40px');
                $('#selectedcouselist tr td:nth-child(3)').css('width', '30px');
                $('#selectedcouselist tr td:nth-child(4)').css('min-width', '150px');
                $('#selectedcouselist tr td:nth-child(5)').css('width', '30px');
                $('#selectedcouselist tr td:nth-child(6)').css('width', '30px');

                rowSelector.updateSelectedCount();

                // Add click event listener to PDF buttons
                $('#selectedcouselist button.download-syllabus').off('click').on('click', function() {
                    const syllabus = $(this).data('syllabus');
                    const subject = $(this).data('subject');
                    const num = $(this).data('num');
                    const apidx = $(this).data('apidx');
                    downloadSyllabus(syllabus, selectedAcademicYearValue, apidx, subject, num);
                    return false;
                });
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function(data, type, full, meta) {
                        return '';
                    }
                },
                { data: 'Subject' },
                { data: 'Num' },
                { data: 'Title' },
                { data: 'Credits' },
                { data: 'APName' },
                {
                    data: 'ASIdx',
                    render: function(data, type, row) {
                        return data ? `
                            <button class="btn btn-warning btn-xs download-syllabus"
                                data-syllabus="${data}"
                                data-subject="${row.Subject}"
                                data-num="${row.Num}"
                                data-apidx="${row.APIdx}"
                                title="Download Syllabus">
                                <i class="glyphicon glyphicon-floppy-save"></i> PDF
                            </button>` : '';
                    }
                }
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets: 'no-sort',
                    orderable: false,
                },
                {
                    targets: 5,
                    className: 'no-select'
                }
            ]
        });

        // Initialize the column search functionality
        new DataTableSearch('#selectedcouselist', DataTable_CoursesList, ShowResetBtn=false);
    }
</script>
<?php } ?>

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN']) { // available only to the people who have access controls to programs
?>
<script>
    async function RemoveAllCourses()
    {
        try {
            const [selectedAcademicYearValue, selectedAcademicYearText] = async_commons.getSelectedAcademicYear();
            if (selectedAcademicYearValue === '') {
                return;
            }

            const willDelete = await async_commons.showConfirmDialog(
                `Deleted Information in (<span style="color:red">${selectedAcademicYearText}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('dept_coursemapping_removeall_ajax.php', {
                ay: selectedAcademicYearValue
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'All courses has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'All courses cannot be deleted because they are used in ABET assessment already.');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function UploadPIs()
    {
        // Check if DataTable has any data
        if (DataTable_AbetCourseList.rows().count() > 0) {
            // Show error message if data exists
            Swal.fire({
                title: "Upload Not Allowed",
                text: "Cannot upload PIs because data already exists in the table. Please clear existing data before uploading new PIs.",
                icon: "error"
            });
            return false; // Exit the function
        }

        const formContent = `
            <form name="popupfrm" id="popupfrm" onsubmit="return false;">
            <div style="color:blue; font-weight:bold;">Support only CSV (Comma delimited) and TSV (Tab delimited) formats. Not sure please, use this sample (<a href="./assets/soinputformat.csv">soinputformat.csv</a>).</div>
            <table style="border-spacing:0; padding:0; width:100%;">
            <tr><td colspan="2"><div class="input-group" style="width:100%">
            <tr><td>ENTER DATA BELOW </td></tr>
            <tr><td><textarea id="pisdata" name="pisdata" style="width:100%;height:200px;"></textarea></td></tr>
            </div></td></tr>
            </table>
            <div style="color:blue; font-weight:bold;">Please use with caution when uploading data. If not sure, please contact the system administrator.</div>
            </form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">AUTO PROCESS PI LIST</span>',
            className: "dialogWidth60p",
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> CONVERT",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');

                        if (popupForm.pisdata.value.isEmpty())
                        {
                            popupForm.pisdata.focus();
                            Swal.fire({title:"ERROR", text: "Data is not selected!!", icon:"error"});
                            return false;
                        }
                        processData(popupForm.pisdata.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#pisdata").focus();
        }).find('.modal-dialog').css({
            'margin-top': function (){
                let w = $( window ).height();
                let b = $(this).height();
                let h = (w-b)*0.2
                return h+"px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"   // enable draggable dialog
        }).find('.modal-header').css({
            'cursor': 'move'            // change mouse cursor for dragging on modal header
        });
    }

    function processData(input_data) {
        const result = SOConverter.convertData(input_data);

        let output = '';
        let covertedData = '';
        if (result.success) {
            covertedData = result.convertedData.join('\n');

            output = "Column Names:\n";
            output += result.columnNames.join(', ') + "\n\n";
            output += "Converted Data:\n";
            output += covertedData;
        } else {
            Swal.fire({title:"ERROR", text: result.error, icon:"error"
            }).then(function(result){
                UploadPIs();
            });
            return;
        }

        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
                <table style="border-spacing:0; padding:0; width:100%;">
                    <tr><td colspan="2"><div class="input-group" style="width:100%">
                        <tr><td>HERE IS THE CONVERTED DATA</td></tr>
                        <tr><td><textarea name="pisdata" style="width:100%;height:200px;" readonly></textarea></td></tr>
                    </div></td></tr>
                </table>
                <div style="color:blue; font-weight:bold;">Please click the PROCEED button if the converted data is correct.</div>
            </form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">AUTO PROCESS PI LIST</span>',
            className: "dialogWidth60p",
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> PROCEED",
                    className: 'btn-success',
                    callback: function(){
                        if (popupfrm.pisdata.value.isEmpty())
                        {
                            popupfrm._AYF.focus();
                            Swal.fire({title:"ERROR", text: "Data is not selected!!", icon:"error"});
                            return false;
                        }
                        UploadPIs_Perform(covertedData);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            popupfrm.pisdata.value = output;

        }).find('.modal-dialog').css({
            'margin-top': function (){
                let w = $( window ).height();
                let b = $(this).height();
                let h = (w-b)*0.2
                return h+"px";
            }
        }).find('.modal-content').draggable({
            'handle': ".modal-header"   // enable draggable dialog
        }).find('.modal-header').css({
            'cursor': 'move'            // change mouse cursor for dragging on modal header
        });
    }

    function convertToJson(data) {
        // Split the data into lines
        const lines = data.trim().split('\n');

        // Convert each line into an object
        const jsonData = lines.map(line => {
            const [course, outcomes] = line.split('|');
            return {
                course: course.trim(),
                outcomes: outcomes.split(', ').map(outcome => outcome.trim())
            };
        });

        // Convert to formatted JSON string
        return JSON.stringify(jsonData, null, 2);
    }

    async function UploadPIs_Perform(data) {
        try {
            const SelectedAcademicYear = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].value;
            const json_data = convertToJson(data);

            const result = await async_commons.makeApiCall('dept_coursemapping_processpis_ajax.php', {
                ay: SelectedAcademicYear,
                data: json_data
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('PROCESSED', 'Data has been processed!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function UpdateMasterSyllabus() {

        // Check if DataTable is empty
        if (DataTable_AbetCourseList.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses and convert to array
        const selected = DataTable_AbetCourseList.rows({ selected: true }).data().toArray();

        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        // Show confirmation dialog
        const confirmation = await Swal.fire({
            title: 'Confirm Update',
            html: `
            <p>You have selected <strong>${selected.length}</strong> course(s).</p>
            <p style="margin-top: 10px;">Do you want to update syllabus information for the selected courses (that don't have a syllabus) by checking the existing master course syllabi?</p>
        `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, Update All',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            reverseButtons: true
        });

        // If user cancels, exit
        if (!confirmation.isConfirmed) {
            return;
        }

        const totalCourses = selected.length;
        let processedCourses = 0;
        let successCount = 0;
        let errorCount = 0;
        const errorDetails = [];

        // Show progress dialog
        Swal.fire({
            title: 'Updating Master Syllabus',
            html: `
            <div>
                <p>Processing course <span id="current-course">0</span> of ${totalCourses}</p>
                <div style="width: 100%; background-color: #e0e0e0; border-radius: 10px; margin-top: 10px;">
                    <div id="progress-bar" style="width: 0%; height: 30px; background-color: #4caf50; border-radius: 10px; transition: width 0.3s;"></div>
                </div>
                <p id="progress-percent" style="margin-top: 10px; font-weight: bold;">0%</p>
                <p id="current-status" style="margin-top: 5px; font-size: 0.9em; color: #666;"></p>
            </div>
        `,
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        // Helper function to safely update DOM elements
        function updateProgress(processed, total, status = '') {
            const progressPercent = Math.round((processed / total) * 100);

            const currentCourseEl = document.getElementById('current-course');
            const progressBarEl = document.getElementById('progress-bar');
            const progressPercentEl = document.getElementById('progress-percent');
            const statusEl = document.getElementById('current-status');

            if (currentCourseEl) currentCourseEl.textContent = processed;
            if (progressBarEl) progressBarEl.style.width = progressPercent + '%';
            if (progressPercentEl) progressPercentEl.textContent = progressPercent + '%';
            if (statusEl && status) statusEl.textContent = status;
        }

        // Update Syllabus for each selected course sequentially
        for (let i = 0; i < selected.length; i++) {
            const item = selected[i];

            if (item.Idx) {
                const _IDX = item.Idx;
                const _AYINFO = item.AcademicYearInfo;
                const _AY = item.AcademicYear;
                const _SUBJECT = item.Subject;
                const _NUM = item.Num;
                const _TITLE = item.Title;
                const _DEGREE = item.Degree;
                const _AP = item.AcademicProgram;

                // Update status
                updateProgress(processedCourses, totalCourses, `Processing: ${_SUBJECT} ${_NUM}`);

                try {
                    const checkResult = await CheckIfMasterSyllabusExist(_IDX);

                    if (checkResult && checkResult.data !== null && checkResult.success) {
                        // Call with silent mode = true
                        const uploadResult = await UpdateAutoMasterSyllabusProcess(
                            _IDX,
                            checkResult.data,
                            true  // Silent mode
                        );

                        if (uploadResult && uploadResult.success) {
                            successCount++;
                        } else {
                            errorCount++;
                            errorDetails.push(`${_SUBJECT} ${_NUM}: ${uploadResult?.error || 'Upload failed'}`);
                        }
                    } else {
                        errorCount++;
                        errorDetails.push(`${_SUBJECT} ${_NUM}: Syllabus not found`);
                    }
                } catch (error) {
                    console.error(`Error processing course ${_SUBJECT} ${_NUM}:`, error);
                    errorCount++;
                    errorDetails.push(`${_SUBJECT} ${_NUM}: ${error.message || 'Unknown error'}`);
                }

                // Update progress
                processedCourses++;
                updateProgress(processedCourses, totalCourses, `Completed: ${_SUBJECT} ${_NUM}`);

                // Small delay to ensure DOM updates
                await new Promise(resolve => setTimeout(resolve, 100));
            }
        }

        // Reload DataTable once after all updates
        await async_commons.reloadDataTable();

        // Show completion message with details
        let errorDetailsHtml = '';
        if (errorCount > 0 && errorDetails.length > 0) {
            errorDetailsHtml = `
                <div style="margin-top: 15px; text-align: left; max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                    <strong>Error Details:</strong>
                    <ul style="margin: 5px 0; padding-left: 20px;">
                        ${errorDetails.map(detail => `<li>${detail}</li>`).join('')}
                    </ul>
                </div>
            `;
        }

        await Swal.fire({
            title: 'Complete!',
            html: `
                <p><strong>Total Processed:</strong> ${processedCourses}</p>
                <p style="color: #4caf50;"><strong>Success:</strong> ${successCount}</p>
                ${errorCount > 0 ? `<p style="color: #f44336;"><strong>Errors:</strong> ${errorCount}</p>` : ''}
                ${errorDetailsHtml}
            `,
            icon: errorCount > 0 ? 'warning' : 'success',
            confirmButtonText: 'OK',
            width: errorCount > 0 ? '600px' : '400px'
        });
    }

    async function CheckIfMasterSyllabusExist(_IDX) {
        if (_IDX === '') {
            return {
                success: false,
                data: null
            };
        }

        try {
            const rawResult = await async_commons.makeApiCall('dept_coursemapping_checkabetsyllabus_ajax.php', {
                idx: _IDX
            });

            const result = JSON.parse(rawResult);
            if (result.status === 'ERROR') {
                throw new Error(result.message);
            }

            return {
                success: true,
                data: result.data
            };

        } catch (error) {
            return {
                success: false,
                data: null
            };
        }
    }

    async function UpdateAutoMasterSyllabusProcess(_IDX="", _SYLLABUS="", _SILENT=false) {
        try {
            const result = await async_commons.makeApiCall('dept_coursemapping_syllabusupdate_ajax.php', {
                idx: _IDX,
                syllabus: _SYLLABUS
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    if (!_SILENT) {
                        await async_commons.reloadDataTable();
                        await async_commons.showSuccessMessage('ADDED', 'Syllabus information has bee updated successfully!');
                    }
                    return { success: true, code: code };
                }
                default: {
                    if (!_SILENT) {
                        throw new Error('Unexpected server response');
                    }
                    return { success: false, code: code, error: 'Unexpected server response' };
                }
            }
        } catch (error) {
            if (!_SILENT) {
                await async_commons.handleError(error);
            }
            return { success: false, error: error.message || error };
        }
    }

</script>
<?php
}
?>

<script class="init">
    $(document).ready(function() {
        const szURL = 'ssps/dept_coursemapping_ssps.php?_AY=';

        DataTable_AbetCourseList = $("#AbetCourses").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            processing: true,
            serverSide: false,
            select: {
                style: 'multi'
            },
            lengthMenu: [50, 100, 150, 200, 300, 400],
            ajax: `${szURL}<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>`,
            language: {
                infoFiltered: "",
                processing: "Loading...",
                loadingRecords: "Please wait - loading..."
            },
            order: [
                [2, "asc"],
                [3, "asc"],
                [4, "asc"]
            ],
            pageLength: 50,
            columns: [
                {
                    data: null,
                    className: "select-checkbox text-center",
                    defaultContent: "",
                    orderable: false,
                    width: "30px"
                },
                { data: 'AcademicYearInfo', className: 'text-center' },
                { data: 'Subject', className: 'text-center', width: "40px" },
                { data: 'Num', className: 'text-center', width: "20px" },
                { data: 'Title', width: "200px" },
                { data: 'Credits', className: 'text-center', width: "25px" },
                { data: 'Requirement', className: 'text-center' },
                { data: 'Level', className: 'text-center' },
                { data: 'StudentOutcomes', className: 'text-center' },
                {
                    data: 'PIs',
                    className: 'text-center',
                    render: function(data, type, full) {
                        if (type === 'display') {
                            return full.PIs.split(",")
                                .filter(item => item.includes("-"))
                                .map(item => item.trim())
                                .join(", ");
                        }
                        return data;
                    }
                },
                {
                    data: 'AbetSyllabus',
                    className: 'text-center',
                    width: "25px",
                    render: function(data) {
                        return data ? `<button class="btn btn-warning btn-xs" id="downloadpdf"
                    title="Download Syllabus"><i class="glyphicon glyphicon-floppy-save"></i> PDF</button>` : '';
                    }
                },
                <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                {
                    data: null
                }
                <?php } ?>
            ],
            fnInitComplete: function(oSettings, json) {
                // Add "Clear Filter" button to Filter
                let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                    $('#' + oSettings.sTableId).dataTable().fnFilter('');
                });
            },
            columnDefs: [
                {
                    "targets"  : 'no-sort',
                    "orderable": false,
                }
                <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                ,{
                    "targets": -1,
                    "data": null,
                    "orderable": false,
                    "defaultContent":
                        `<div>
                            <button id="assignso" title="Assign Student Outcome" class="btn btn-danger btn-xs glyphicon glyphicon-th-list" style="min-height: 20px;"></button>&nbsp;
                            <button id="assigngpi" title="Assign Performance Indicators" class="btn btn-danger btn-xs glyphicon glyphicon-list" style="min-height: 20px;"></button>&nbsp;
                            <button id="remove" title="Remove ABET course" class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="min-height: 20px;"></button>
                        </div>`
                }
                <?php } ?>
            ],
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'landscape',
                    title: getTitleText,
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> PDF',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff; margin-left:8px;'
                    },
                    exportOptions: {
                        columns: [1, 2, 3, 4, 5, 6, 7, 8, 9]
                    },
                    customize: function(doc) {
                        // Font size adjustments
                        doc.styles.tableHeader.fontSize = 9;
                        doc.defaultStyle.fontSize = 8;

                        // Set page size to US Letter
                        doc.pageSize = 'LETTER';

                        // Reduce margins to maximize space (in points, 72 points = 1 inch)
                        doc.pageMargins = [20, 20, 20, 20]; // [left, top, right, bottom]

                        // Ensure table fits page width
                        doc.content[1].table.widths = Array(doc.content[1].table.body[0].length).fill('*');

                        // Set specific widths if needed for certain columns
                        doc.content[1].table.widths = ['8%', '8%', '8%', '21%', '8%', '9%', '10%', '10%', '12%', '12%'];

                        // Add some styling to make it more readable
                        doc.styles.tableHeader.alignment = 'left';
                        doc.styles.tableBodyEven = doc.styles.tableBodyOdd;
                    },
                    pageSize: 'LETTER'
                },
                {
                    extend: 'excelHtml5',
                    title: getTitleText,
                    text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff;'
                    },
                    exportOptions: {
                        columns: [1, 2, 3, 4, 5, 6, 7, 8, 9]
                    }
                }
            ]
        });

        // Helper function for title
        function getTitleText() {
            const program = document.forms["changefrm"]["CH_APR"].options[
                document.forms["changefrm"]["CH_APR"].selectedIndex
                ].text;
            const academicYear = document.academicyear._AY.options[
                document.academicyear._AY.selectedIndex
                ].text;
            return `Overall SO/PI Course Mapping Information (${program} ${academicYear})`;
        }

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_AbetCourseList.ajax.url(tmpURL).load();
        });

        // Initialize the column search functionality
        new DataTableSearch('#AbetCourses', DataTable_AbetCourseList);

        $('#AbetCourses').on('click', '.toggle-all', function() {
            $(this).closest("tr").toggleClass("selected");
            if ($(this).closest("tr").hasClass("selected")) {
                DataTable_AbetCourseList.rows({ page: 'current' }).select();
            }
            else {
                DataTable_AbetCourseList.rows({ page: 'current' }).deselect();
            }
        });

        $('#AbetCourses tbody').on( 'click', '#downloadpdf', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            downloadSyllabus(data.AbetSyllabus, data.AcademicYear, data.AcademicProgram, data.Subject, data.Num);
            return false; // disable row selection action
        } );

        <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
        $('#AbetCourses tbody').on( 'click', '#assignso', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            const courseInfo = data.Subject + data.Num + ' ' + data.Title;
            AssignSOs(data.Idx, data.AcademicYear, data.AcademicYearInfo, data.SOIdxes, courseInfo);
            return false; // disable row selection action
        } );

        $('#AbetCourses tbody').on( 'click', '#assigngpi', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            const courseInfo = data.Subject + ' ' + data.Num + ' ' + data.Title;
            if (data.SOIdxes === null)
            {
                Swal.fire({
                    title: "ERROR",
                    text: "Please add Student Outcomes first.",
                    icon: "error",
                    timer: 5000,
                    heightAuto: false,
                    scrollbarPadding: false
                });
                return false;
            }
            AssignPIs(data.Idx, data.AcademicYear, data.AcademicYearInfo, data.SOIdxes, data.PIIdxes, courseInfo);
            return false;  // disable row selection action
        } );

        $('#AbetCourses tbody').on( 'click', '#remove', function () {
            const data = DataTable_AbetCourseList.row( $(this).parents('tr') ).data();
            RemoveCourseMapping(data.Idx, data.AcademicYearInfo, data.Subject, data.Num, data.Title, data.Syllabus);
            return false;  // disable row selection action
        } );
        <?php } ?>

        async_commons.setDataTable(DataTable_AbetCourseList);

    } );

</script>

<div class="pagebacklayout">
    <div style="width:100%;">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">OVERALL SO/PI COURSE MAPPING INFORMATION</span></p>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <?php
        if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
            include('control_selprogram.php');
        } else {
            include('control_allprograms.php');
        }
        ?>
    </div>

    <div class="pagebacklayout_inner_noborder">
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { // available only to the system administrator
?>
        <div style="display: flex; align-items: center; gap: 10px; border: 2px solid red; padding: 10px; border-radius: 5px; background-color: #e0e0e0;">
            <h5 style="margin: 0;">SYSTEM ADMIN MENUS:</h5>
            <button class="btn btn-default btn-sm" onclick="UploadPIs();return false;" style="color:red;">UPLOAD SOs/PIs TO THIS ACADEMIC YEAR</button>
            <button class="btn btn-default btn-sm" onclick="RemoveAllCourses();return false;" style="color:red;">REMOVE ALL COURSES IN THIS ACADEMIC YEAR</button>
        </div>
<?php
}
?>
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr><td colspan="3" style="width:100%; text-align: right">
            </td></tr>
            <tr>
                <td style="width:20%; min-width:350px;">
                    <?php echo($AcademicYearSelection);?>
                </td>
                <td style="width:5%"></td>
                <td style="width:75%; text-align: right">
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <button class="btn btn-default btn-sm" onclick="DuplicateAbetSOsPIs();return false;" style="color:red;">DUPLICATE (DIRECTOR ONLY)</button>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-refresh" onclick="UpdateMasterSyllabus();return false;">&nbsp;UPDATE SYLLABUS</button>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-tasks" onclick="AssignReqToSelectedCourses();return false;">&nbsp;ASSIGN REQUIREMENT</button>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-th-large" onclick="AssignLevelToSelectedCourses();return false;">&nbsp;ASSIGN LEVEL</button>
                    <button class="btn btn-danger btn-sm glyphicon glyphicon-list-alt" onclick="AddCourses();return false;">&nbsp;ADD COURSES FROM COURSE INVENTORY</button>
                    <?php } ?>
                </td>
            </tr>
        </table>


        <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
            <table id="AbetCourses" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th class="toggle-all" style="width:3px; "></th>
                    <th style="width:50px">ACADEMIC YEAR</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>REQUIREMENT</th>
                    <th>LEVEL</th>
                    <th>STUDENT OUTCOMES</th>
                    <th>PERFORMANCE INDICATORS</th>
                    <th>MASTER SYLLABUS</th>
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <th class="no-sort">OPERATION</th>
                    <?php } ?>
                </tr>
                </thead>
                <thead id="serachbox" class="filters">
                <tr>
                    <th></th>
                    <th>ACADEMIC YEAR</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>REQUIREMENT</th>
                    <th>LEVEL</th>
                    <th>STUDENT OUTCOMES</th>
                    <th>PERFORMANCE INDICATORS</th>
                    <th></th>
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <th></th>
                    <?php } ?>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th></th>
                    <th>ACADEMIC YEAR</th>
                    <th>SUBJECT</th>
                    <th>NUMBER</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>REQUIREMENT</th>
                    <th>LEVEL</th>
                    <th>STUDENT OUTCOMES</th>
                    <th>PERFORMANCE INDICATORS</th>
                    <th></th>
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <th></th>
                    <?php } ?>
                </tr>
                </tfoot>
            </table>
        </div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <?php if ($_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS'] === true || $_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {?>
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-tasks" style="pointer-events: none;"></span>: Assign Requirement
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-th-large" style="pointer-events: none;"></span>: Assign Course Level
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-th-list" style="pointer-events: none;"></span>: Assign Student Outcome
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-list" style="pointer-events: none;"></span>: Assign Performance Indicator
                    <span class="btn btn-danger btn-xs glyphicon glyphicon-remove" style="pointer-events: none;"></span>: Remove ABET Course
                    <?php } ?>
                </td>
            </tr>
        </table>
    </div>
</div>


<?php include('footer.php');?>



