// disable-navigation.js
(function() {
    'use strict';

    // Wait for DOM to be ready
    document.addEventListener('DOMContentLoaded', function() {
        // Disable back button
        history.pushState(null, null, location.href);

        window.onpopstate = function() {
            history.go(1);
        };

        // Disable right-click context menu
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });

        // Disable common keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Disable F5, Ctrl+R (refresh)
            if (e.key === 'F5' || (e.ctrlKey && e.key === 'r')) {
                e.preventDefault();
            }
            // Disable Alt+Left (back)
            if (e.altKey && e.key === 'ArrowLeft') {
                e.preventDefault();
            }
            // Disable Backspace (if not in input field)
            if (e.key === 'Backspace' &&
                !['INPUT', 'TEXTAREA'].includes(e.target.tagName) &&
                !e.target.isContentEditable) {
                e.preventDefault();
            }
        });
    });
})();