<?php
/**
 * Listing courses
 * File: dept_abetcourses_courselist_ssps.php
 * Description: listing courses in a dialog window
 *
 * 08/09/2026 Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */

include_once 'session_handler.php';

// DB table to use
$table = 'AVCourses';
$joinQuery = "FROM `$table` AS `AVCRSES` 
INNER JOIN `Subjects` AS `SBJTS` ON (`SBJTS`.`Name`=`AVCRSES`.`Subject` AND `SBJTS`.`Department` = '".$_SESSION['ATLAS_SELECTED_DEPARTMENT']."')
INNER JOIN `AcademicYears` AS `AYS` ON (`AVCRSES`.`Semester` BETWEEN `AYS`.`From` AND `AYS`.`To`)
LEFT JOIN `Semesters` AS `SMSTRS` ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
";

// Table's primary key
$primaryKey = '`AVCRSES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`AVCRSES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`AVCRSES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => '`SMSTRS`.`Explanation`', 'dt' => 'SemesterTxt', 'field' => 'SemesterTxt', 'as' => 'SemesterTxt'),
    array( 'db' => '`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => '`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`Section`', 'dt' => 'Section', 'field' => 'Section', 'as' => 'Section'),
    array( 'db' => '`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`Days`', 'dt' => 'Days', 'field' => 'Days', 'as' => 'Days'),
    array( 'db' => '`Times`', 'dt' => 'Times', 'field' => 'Times', 'as' => 'Times'),
    array(
        'db' => '`Instructor`', // Base column for filtering
        'dt' => 'Instructor',
        'field' => 'Instructor',
        'as' => 'Instructor',
        'formatter' => function($d, $row) {
            return $d; // The GROUP_CONCAT will be handled in the query
        }
    )
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );


// Base WHERE condition without the department filter (now in JOIN)
$extraWhere = "(`AVCRSES`.`CollectMaterials` != 1 OR `AVCRSES`.`CollectMaterials` IS NULL)";

// Add academic year filter if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']) && $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] != "" && $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] != "all") {
    $extraWhere .= " AND `AYS`.`Idx` = '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."'";
}

// Remove the GROUP BY since it's now handled in the subquery
$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);

