<?php
/**
 * Listing All Courses
 * File: m_courses_ssps.php
 * Description: listing all courses in the system
 *
 *
 *
 */
include_once 'session_handler.php';

require_once(__DIR__ . '/../../config.php');

// DB table to use
$table = 'AbetSyllabus';

// Base join query without WHERE clause
$joinQuery = "FROM `{$table}` AS `ABS` 
LEFT JOIN `Courses` AS `CS` ON (`CS`.`Idx`=`ABS`.`CourseIndex`)";

// Table's primary key
$primaryKey = '`CS`.`Idx`';

// Array of database columns
$columns = array(
    array('db' => '`CS`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId',
        'formatter' => function( $d, $row ) {
            return 'row_'.$d;
        }
    ),
    array( 'db' => '`CS`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => 'CONCAT(`ABS`.`major_version`, \'.\', `ABS`.`minor_version`)',
        'dt' => 'Version', 'field' => 'Version', 'as' => 'Version'),
    array( 'db' => '`CS`.`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`CS`.`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`CS`.`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`CS`.`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`ABS`.`Description`', 'dt' => 'Description', 'field' => 'Description', 'as' => 'Description'),
    array( 'db' => '`ABS`.`Pre_requisites`', 'dt' => 'Pre_requisites', 'field' => 'Pre_requisites', 'as' => 'Pre_requisites'),
    array( 'db' => '`ABS`.`Co_requisites`', 'dt' => 'Co_requisites', 'field' => 'Co_requisites', 'as' => 'Co_requisites'),
    array( 'db' => '`ABS`.`Required_Texts`', 'dt' => 'Required_Texts', 'field' => 'Required_Texts', 'as' => 'Required_Texts'),
    array( 'db' => '`ABS`.`Idx`', 'dt' => 'ABSIdx', 'field' => 'ABSIdx', 'as' => 'ABSIdx'),
    array( 'db' => '`ABS`.`Coordinator`', 'dt' => 'Coordinator', 'field' => 'Coordinator', 'as' => 'Coordinator'),
    array( 'db' => 'CASE WHEN (`ABS`.`Description` IS NOT NULL AND `ABS`.`ApprovalDate` IS NULL) THEN \'Need Approval\' ELSE \'\' END',
        'dt' => 'NeedApproval', 'field' => 'NeedApproval', 'as' => 'NeedApproval'),
    array( 'db' => '`ABS`.`Requirement`', 'dt' => 'Requirement', 'field' => 'Requirement', 'as' => 'Requirement'),
    array( 'db' => '`ABS`.`RevisionDate`', 'dt' => 'RevisionDate', 'field' => 'RevisionDate', 'as' => 'RevisionDate'),
    array( 'db' => '`ABS`.`RevisionDesc`', 'dt' => 'RevisionDesc', 'field' => 'RevisionDesc', 'as' => 'RevisionDesc'),
    array( 'db' => '`ABS`.`ApprovalDesc`', 'dt' => 'ApprovalDesc', 'field' => 'ApprovalDesc', 'as' => 'ApprovalDesc'),
    array( 'db' => '`ABS`.`ApprovalDate`', 'dt' => 'ApprovalDate', 'field' => 'ApprovalDate', 'as' => 'ApprovalDate')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );

$extraWhere = "`ABS`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";

$extraWhere .= "AND NOT EXISTS (
    SELECT 1
    FROM AbetSyllabus AS sub
    WHERE sub.CourseIndex = ABS.CourseIndex
    AND sub.AcademicProgram = ABS.AcademicProgram
    AND (
        sub.major_version > ABS.major_version
        OR (
            sub.major_version = ABS.major_version
            AND sub.minor_version > ABS.minor_version
        )
    )
)";

$groupBy = '';

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);