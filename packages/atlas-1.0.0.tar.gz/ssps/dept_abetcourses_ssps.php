<?php
/**
 * Listing abet courses
 * File: dept_abetcourses_ssps.php
 * Description: listing abet courses
 *
 * 03/09/2023 Updated to fetch ABET course level information.
 * 08/09/2026 Modified to use Semesters table join instead of FUNC_GetYearSem
 *
 */
require_once 'json_response_handler.php';

$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = '';
$joinQuery = " FROM (
    SELECT 
        A.`Idx`, A.`AVCIdx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Requirement`, A.`Semester`, A.`CRN`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`Syllabus`, A.`SyllabusLastUpdated`, A.`Degree`, A.`Survey`,
        A.`Enrollment`,
        GROUP_CONCAT(DISTINCT A.`Instructor` ORDER BY A.`Instructor` SEPARATOR ', ') as `Instructor`,
        GROUP_CONCAT(DISTINCT A.`Email` ORDER BY A.`Instructor` SEPARATOR ', ') as `Email`,
        GROUP_CONCAT(DISTINCT B.`SO` ORDER BY B.`SO` SEPARATOR ', ') as `StudentOutcomes`,
        GROUP_CONCAT(DISTINCT B.`SOIdx` ORDER BY B.`SO` SEPARATOR ', ') as `SOIdxes`,
        GROUP_CONCAT(DISTINCT B.`PIIdx` ORDER BY B.`SO`, B.`PI` SEPARATOR ', ') as `PIIdxes`,
        GROUP_CONCAT(DISTINCT CONCAT_WS('-',B.`SO`, B.`PI`) ORDER BY B.`SO`, B.`PI` SEPARATOR ', ') as `PIs`,
        IFNULL(C.`HasClassRoster`, 0) as `HasClassRoster`
    FROM (
        SELECT `ABETCRSES`.`Idx`, `ABETCRSES`.`AcademicYear`, `ABETCRSES`.`Level`, 
            `AYS`.`AcademicYear` AS `AcademicYearInfo`, 
            `ABETCRSES`.`AcademicProgram`, `ABETCRSES`.`Requirement`, 
            `SMSTRS`.`Explanation` AS `Semester`,
            `AVCRSES`.`Idx` AS `AVCIdx`,
            `AVCRSES`.`CRN`, `AVCRSES`.`Subject`, `AVCRSES`.`Num`, `AVCRSES`.`Title`, 
            `AVCRSES`.`Credits`, `AVCRSES`.`Survey`, 
            `ABETCRSES`.`Syllabus`, `ABETCRSES`.`SyllabusLastUpdated`,  
            `ACDEMICPRMS`.`Degree`,
            `AVCRSES`.`Actual` AS `Enrollment`,
            `UA`.`Name` AS `Instructor`, `UA`.`Email`
        FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AVCourses` AS `AVCRSES` 
            ON (`ABETCRSES`.`AVCourseIdx` = `AVCRSES`.`Idx` 
                AND `ABETCRSES`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."') 
        LEFT JOIN `Semesters` AS `SMSTRS`
            ON `AVCRSES`.`Semester` = `SMSTRS`.`SemesterCode`
        LEFT JOIN `AVCoursesInstructors` AS `AVINSTRUCTORS` 
            ON (`AVCRSES`.`Idx` = `AVINSTRUCTORS`.`AVCourseIdx`) 
        INNER JOIN `UserAccounts` AS `UA` 
            ON (`AVINSTRUCTORS`.`Instructor` = `UA`.`Idx`)
        INNER JOIN `AcademicYears` AS `AYS` 
            ON (`ABETCRSES`.`AcademicYear` = `AYS`.`Idx`) 
        INNER JOIN `AcademicPrograms` AS `ACDEMICPRMS` 
            ON (`ABETCRSES`.`AcademicProgram` = `ACDEMICPRMS`.`Idx`)
    ) AS A
    LEFT JOIN (
        SELECT `ABETCRSES`.`Idx` AS `AbetCourseIdx`, `ABETCRSES`.`AcademicYear`, 
            `ABETCRSES`.`AcademicProgram`, `STNTOUTCMS`.`Idx` AS `SOIdx`, 
            `STNTOUTCMS`.`SO`, `GPIS`.`Idx` AS `PIIdx`, `GPIS`.`GPI` AS `PI`
        FROM `AbetCourses` AS `ABETCRSES` 
        INNER JOIN `AbetCourses_SOs` AS `ABETCRSES_SOS` 
            ON (`ABETCRSES`.`Idx` = `ABETCRSES_SOS`.`AbetCourseIdx` 
                AND `ABETCRSES`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."') 
        LEFT JOIN `AbetCourses_GPIs` AS `ABETCRSES_GPIS` 
            ON (`ABETCRSES_GPIS`.`SOIdx` = `ABETCRSES_SOS`.`SOIdx` 
                AND `ABETCRSES_GPIS`.`AbetCourseIdx`=`ABETCRSES_SOS`.`AbetCourseIdx`) 
        INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` 
            ON (`ABETCRSES_SOS`.`SOIdx` = `STNTOUTCMS`.`Idx`) 
        LEFT JOIN `GeneralPerformanceIndicators` AS `GPIS` 
            ON (`GPIS`.`Idx` = `ABETCRSES_GPIS`.`GPIIdx`)
    ) AS B ON (A.`Idx` = B.`AbetCourseIdx` 
        AND A.`AcademicYear` = B.`AcademicYear` 
        AND A.`AcademicProgram` = B.`AcademicProgram`)
    LEFT JOIN (
        SELECT `AvailableCourseIdx`, 
            CASE 
                WHEN COUNT(*) > 0 THEN 1 
                ELSE 0 
            END AS `HasClassRoster`
        FROM `ClassRoster`
        GROUP BY `AvailableCourseIdx`
    ) AS C ON (A.`AVCIdx` = C.`AvailableCourseIdx`)
    GROUP BY A.`Idx`, A.`AVCIdx`, A.`AcademicYear`, A.`Level`, A.`AcademicYearInfo`, 
        A.`AcademicProgram`, A.`Requirement`, A.`Semester`, A.`CRN`, A.`Subject`, 
        A.`Num`, A.`Title`, A.`Credits`, A.`Syllabus`, A.`SyllabusLastUpdated`, A.`Degree`, 
        A.`Survey`, A.`Enrollment`, C.`HasClassRoster`
) AS combined";

// Table's primary key
$primaryKey = '`Idx`';

// Array of database columns which should be read and sent back to DataTables.
$columns = array(
    array('db' => '`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        return 'row_'.$d;
    }),
    array( 'db' => '`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`AVCIdx`', 'dt' => 'AVCIdx', 'field' => 'AVCIdx', 'as' => 'AVCIdx'),
    array( 'db' => '`Enrollment`', 'dt' => 'Enrollment', 'field' => 'Enrollment', 'as' => 'Enrollment'),
    array( 'db' => '`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => '`AcademicYearInfo`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => '`Requirement`', 'dt' => 'Requirement', 'field' => 'Requirement', 'as' => 'Requirement'),
    array( 'db' => 'FUNC_GetCourseLevel(`Level`)', 'dt' => 'Level', 'field' => 'Level', 'as' => 'Level'),
    array( 'db' => '`Semester`', 'dt' => 'Semester', 'field' => 'Semester', 'as' => 'Semester'),
    array( 'db' => '`CRN`', 'dt' => 'CRN', 'field' => 'CRN', 'as' => 'CRN'),
    array( 'db' => '`Subject`', 'dt' => 'Subject', 'field' => 'Subject', 'as' => 'Subject'),
    array( 'db' => '`Num`', 'dt' => 'Num', 'field' => 'Num', 'as' => 'Num'),
    array( 'db' => '`Title`', 'dt' => 'Title', 'field' => 'Title', 'as' => 'Title'),
    array( 'db' => '`Credits`', 'dt' => 'Credits', 'field' => 'Credits', 'as' => 'Credits'),
    array( 'db' => '`Syllabus`', 'dt' => 'AbetSyllabus', 'field' => 'AbetSyllabus', 'as' => 'AbetSyllabus'),
    array( 'db' => '`SyllabusLastUpdated`', 'dt' => 'SyllabusLastUpdated', 'field' => 'SyllabusLastUpdated', 'as' => 'SyllabusLastUpdated'),
    array( 'db' => '`Survey`', 'dt' => 'Survey', 'field' => 'Survey', 'as' => 'Survey'),
    array( 'db' => '`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram'),
    array( 'db' => '`Degree`', 'dt' => 'Degree', 'field' => 'Degree', 'as' => 'Degree'),
    array( 'db' => '`Instructor`', 'dt' => 'Instructor', 'field' => 'Instructor', 'as' => 'Instructor'),
    array( 'db' => '`Email`', 'dt' => 'Email', 'field' => 'Email', 'as' => 'Email'),
    array( 'db' => '`SOIdxes`', 'dt' => 'SOIdxes', 'field' => 'SOIdxes', 'as' => 'SOIdxes'),
    array( 'db' => '`StudentOutcomes`', 'dt' => 'StudentOutcomes', 'field' => 'StudentOutcomes', 'as' => 'StudentOutcomes'),
    array( 'db' => '`PIIdxes`', 'dt' => 'PIIdxes', 'field' => 'PIIdxes', 'as' => 'PIIdxes'),
    array( 'db' => '`PIs`', 'dt' => 'PIs', 'field' => 'PIs', 'as' => 'PIs'),
    array( 'db' => '`HasClassRoster`', 'dt' => 'HasClassRoster', 'field' => 'HasClassRoster', 'as' => 'HasClassRoster')
);

require( 'ssp.join.class.php' );

if (empty($_SESSION['ATLAS_ACCESSCNTL_GRANTEDPROGRAMS'][$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']])) {
    $extraWhere = "combined.`AcademicProgram` = ''";
} else {
    $extraWhere = "combined.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";
}

if ($AcademicYear != "" && $AcademicYear != "all") {
    $extraWhere .= " AND combined.`AcademicYear`='".$AcademicYear."'";
}

$groupBy = "";

require_once(__DIR__ . '/../php_include/dbconnection.php');
try {
    $result =  SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false);
    sendJsonResponse($result);
} catch (Exception $e) {
    error_log('DataTables Error: ' . $e->getMessage());
    sendJsonError('Database error occurred', 500);
}

