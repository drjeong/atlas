<?php
/**
 * Management of Academic Year
 * Description: add course info
 * Author: Dong Hyun Jeong
 *
 * 10/18/2024 - initial version created
 *
 */


include('checker_systemadmin.php');


$SUBJ = (isset($_POST['subj'])) ? trim($_POST['subj']) : '';
$NUM = (isset($_POST['num'])) ? trim($_POST['num']) : '';
$TITLE = (isset($_POST['title'])) ? trim($_POST['title']) : '';
$Credits = (isset($_POST['cr'])) ? trim($_POST['cr']) : '';

if ($SUBJ=="" || $NUM=="" || $TITLE=="" || $Credits==""){
    echo "0x00000011";
    exit;
}


//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // convert unwanted escape strings
    $TITLE = $DBCONNECTION->real_escape_string($TITLE);

    /////////////////////////////////////////////////////////////////////////////////
    // insert item
    $query = "CALL SP_AddCourse(?, ?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query,
        [$SUBJ, $NUM, $TITLE, $Credits]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00200011') !== false) {
        echo '0x00200011';  // same item exists already
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}