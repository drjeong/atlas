<?php
/**
 * Management of Department (Affiliation) Information
 * Description: managing department information
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 *
 */

include('checker_systemadmin.php');
include('header.php');

?>


<script type="text/javascript">

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        SAME_ITEM_EXIST: '0x00200011',
        ITEM_NOT_EXIST: '0x00200012',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
    };

    async function updateaffiliationinfo(_IDX, _AFNAME) {
        try {
            const result = await async_commons.makeApiCall('m_affiliation_update_ajax.php', {
                id: _IDX,
                _AFNAME: _AFNAME
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Information has been updated!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `The entered information exists already!`
                    );
                    // Re-open the add dialog
                    ModifyAffiliation(_IDX, _AFNAME);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function RemoveAffiliation(id, dp){
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted information (<span style="color:red">${dp}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('m_affiliation_remove_ajax.php', {
                id: id
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected subject has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected subject cannot be removed!! It has been used already!!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function ModifyAffiliation(_ID, _AFNAME)
    {
        const formContent = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<input type="hidden" name="_ID" value="'+_ID+'">'
            + '<table style="border-spacing:0; padding:0; width:100%;">'
            + '<tr><td colspan="2">'
            + '<div class="input-group" style="width:100%">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Program&nbsp;Name (Major)<span style="color:red">*</span></span>'
            + '     <input type="text" name="_AFNAME" id="_AFNAME" class="input-sm form-control" value="'+_AFNAME+'" placeholder="ex) Computer Science" required>'
            + ' </div>'
            + '</div>'
            + '</td></tr>'
            + '</table></form>';

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">EDIT DEPARTMENT INFORMATION</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;UPDATE",
                    className: 'btn-success',
                    callback: function(){
                        updateaffiliationinfo(popupfrm._ID.value, popupfrm._AFNAME.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_AFNAME").focus();
       });
    }

    async function AddAffiliation_Perform(_AFNAME) {
        try {
            const result = await async_commons.makeApiCall('m_affiliation_add_ajax.php', {
                _AFNAME: _AFNAME
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'Affiliation is added successfully!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `The entered affiliation exists already!`
                    );
                    // Re-open the add dialog
                    AddAffiliation(_AFNAME);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function AddAffiliation(_AFNAME='')
    {
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
             <div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Affiliation&nbsp;Name (Department or College)<span style="color:red">*</span></span>
                  <input type="text" name="_AFNAME" id="_AFNAME" class="input-sm form-control" value="${_AFNAME}" placeholder="ex) Computer Science" required>
              </div>
             </div>
             </td></tr>
             </table></form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD DEPARTMENT INFORMATION</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;ADD",
                    className: 'btn-success',
                    callback: function(){
                        AddAffiliation_Perform(popupfrm._AFNAME.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_AFNAME").focus();
        });
    }

</script>

<script class="init">
$(document).ready(function() {
	DataTable_Department = $("#affiliationinfo").DataTable({
		"processing": true,
		"serverSide": true,
        "lengthMenu": [ 30, 50, 75, 100, 150, 300, 500 ],
		"ajax": "ssps/m_affiliation_ssps.php",
		"fnInitComplete": function(oSettings, json) {
		  // Add "Clear Filter" button to Filter
		  let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
		  btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
		  $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
		   $('#' + oSettings.sTableId).dataTable().fnFilter('');
		  });
		},
		"fnDrawCallback": function() {
			$('#affiliationinfo tr td:nth-child(1)').css('text-align', 'center');
			$('#affiliationinfo tr td:nth-child(2)').css('text-align', 'center');
			$('#affiliationinfo tr td:nth-child(3)').css('text-align', 'center');
		},		
		"columnDefs": [ {
			"targets"  : 'no-sort',
			"orderable": false,
		},
		{
		"targets": -1,
		"data": null,
		"orderable": false,
		"defaultContent": "<div style=\"width:100%;text-align:center;\"><button id=\"modify\" class=\"btn btn-danger btn-xs glyphicon glyphicon-wrench\" style=\"min-height: 20px;\"></button>&nbsp;<button id=\"remove\" class=\"btn btn-danger btn-xs glyphicon glyphicon-remove\" style=\"min-height: 20px;\"></button></div>"
		} ]
	});

    async_commons.setDataTable(DataTable_Department);

	$('#affiliationinfo tbody').on( 'click', '#remove', function () {
		const data = DataTable_Department.row( $(this).parents('tr') ).data();
        RemoveAffiliation(data[0], data[1]);
	} );

	$('#affiliationinfo tbody').on( 'click', '#modify', function () {
		const data = DataTable_Department.row( $(this).parents('tr') ).data();
		ModifyAffiliation(data[0], data[1]);
	} );

} );
</script>


<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">&nbsp;ALL DEPARTMENT INFORMATION</span>&nbsp;</p>
	</div>

	<div class="pagebacklayout_inner_noborder" style="min-height:400px">
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style="margin-bottom:0.1in;">
		<tr>
			<td width="80%">		
			</td>
			<td width="20%" align="right"><button class="btn btn-danger btn-sm" onclick="AddAffiliation();return false;">ADD DEPARTMENT INFO</button></td>
		</tr>
		</table>
		<div class="CSSTable_SSPSLIST">
		<table id="affiliationinfo" class="display" style="border-spacing:0; padding:0; width:100%;">
		<thead>
			<tr>
				<th>IDX</th>
				<th>AFFILIATION NAME</th>
				<th class="no-sort">OPERATION</th>
			</tr>
		</thead>
		</table>
		</div>
    </div>
</div>

<?php include('footer.php');?>

