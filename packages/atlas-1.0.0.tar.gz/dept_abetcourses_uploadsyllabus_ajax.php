<?php
/**
 * Upload Abet Syllabus
 * Description: uploading master syllabus to the server.
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 *
 */

include_once 'session_handler.php';

$Idx='';
$AcademicYear='';       // index
$AcademicYearInfo='';
$Degree='';
$Subject='';
$Num='';

if (array_key_exists('_IDX', $_POST) && array_key_exists('_AY', $_POST) && array_key_exists('_AYINFO', $_POST)
    && array_key_exists('_DEGREE', $_POST) && array_key_exists('_SUBJECT', $_POST) && array_key_exists('_NUM', $_POST))
{
    $Idx = trim($_POST['_IDX']);
    $AcademicYear = trim($_POST['_AY']);
    $AcademicYearInfo = trim($_POST['_AYINFO']);
    $Degree = trim($_POST['_DEGREE']);
    $Subject = trim($_POST['_SUBJECT']);
    $Num = trim($_POST['_NUM']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($Idx=="" || $AcademicYear=="" || $AcademicYearInfo=="" || $AcademicProgram=="" || $Degree=="" || $Subject=="" || $Num==""){
    // no required information
    echo "0x00000101";
    exit;
}

if ($_FILES["_FILE"]["name"]==""){
    echo "0x00020101";  // File is not selected!
    exit;
}

try {
    require_once(__DIR__ . '/../config.php');

    // Construct file paths and names
    $CourseInfo = $AcademicYearInfo . '_' . $Degree . '_' . $Subject . '_' . $Num;
    $target_dir = rtrim(__DIRECTORY_ABETSYLLABI__, '/') . '/' . $AcademicYearInfo . '/';
    $file_name = 'abet_syllabus_' . strtolower($CourseInfo);
    $file_name = preg_replace("/\s+/", "_", $file_name);
    $file_name .= '.pdf';
    $UploadFileName = $target_dir . $file_name;

    // Validate file upload
    if (!isset($_FILES['_FILE']) || !isset($_FILES['_FILE']['tmp_name'])) {
        throw new Exception('No file uploaded: ' . $_FILES["_FILE"]["name"]);
    }

    // Directory checks
    if (!file_exists($target_dir)) {
        if (!mkdir($target_dir, 0755, true)) {
            throw new Exception('Failed to create directory: ' . $target_dir);
        }
    }

    if (!is_writable($target_dir)) {
        throw new Exception('Directory not writable: ' . $target_dir);
    }

    // File upload validation
    if (!is_uploaded_file($_FILES['_FILE']['tmp_name'])) {
        echo "0x00251400"; // file size limit exceeded
        exit;
    }

    // Validate file type
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime_type = $finfo->file($_FILES['_FILE']['tmp_name']);
    if ($mime_type !== 'application/pdf') {
        throw new Exception('Invalid file type. Only PDF files are allowed: '. $mime_type);
    }

    // Move uploaded file
    if (!move_uploaded_file($_FILES["_FILE"]["tmp_name"], $UploadFileName)) {
        throw new Exception('Failed to move uploaded file: ' . $_FILES["_FILE"]["tmp_name"]);
    }

    // Database operations
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate academic year
    $AcademicYear = filter_var($AcademicYear, FILTER_VALIDATE_INT);
    if ($AcademicYear === false) {
        throw new Exception('Invalid Academic Year format: '. $AcademicYear);
    }

    // Validate string lengths
    if (strlen($file_name) > 256) {
        throw new Exception('File name exceeds maximum length: '. strlen($file_name));
    }
    if (strlen($Subject) > 5 || strlen($Num) > 5) {
        throw new Exception('Subject or Course Number exceeds maximum length: Subject:'. strlen($Subject).' Num:'.strlen($Num));
    }

    // Database update
    $query = "CALL SP_AddAbetSyllabus(?, ?, ?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [
        $AcademicYear,
        $file_name,
        $Subject,
        $Num,
        $AcademicProgram
    ]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    error_log("Database error: " . $e->getMessage());
    echo "0x00000500";

    // Clean up uploaded file if database operation fails
    if (isset($UploadFileName) && file_exists($UploadFileName)) {
        unlink($UploadFileName);
    }

} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    echo "0x00000000";

    // Clean up uploaded file if operation fails
    if (isset($UploadFileName) && file_exists($UploadFileName)) {
        unlink($UploadFileName);
    }
}
