<?php
/**
 * Listing Assessment Measure
 * File: u_course_results_assessmentmeasure_ssp.php
 * Description: listing assessment measure of the selected course
 *
 *
 *
 */
include_once 'session_handler.php';


$AbetCourseIdx='';
$AvailableCourseIdx='';
$AcademicProgramIdx='';
if (array_key_exists('_ABTC', $_GET) && array_key_exists('_AVC', $_GET) && array_key_exists('_AP', $_GET)) {
    $AbetCourseIdx = trim($_GET['_ABTC']);
    $AvailableCourseIdx = trim($_GET['_AVC']);
    $AcademicProgramIdx = trim($_GET['_AP']);
}
else {
    // illegal entry
    exit;
}

// DB table to use
$table = 'AssessmentMeasures';
$joinQuery = "FROM `$table` AS `ASSMNTMEASURES` INNER JOIN `GeneralPerformanceIndicators` AS `GPIS` ON (`GPIS`.`Idx`=`ASSMNTMEASURES`.`GPI` AND `GPIS`.`AcademicProgram`='$AcademicProgramIdx') INNER JOIN `StudentOutcomes` AS `STNTOUTCMS` ON (`GPIS`.`SOIdx`=`STNTOUTCMS`.`Idx` AND `STNTOUTCMS`.`AcademicProgram`='$AcademicProgramIdx') INNER JOIN `Scoresheet` AS `SCSHEET` ON (`ASSMNTMEASURES`.`Idx`=`SCSHEET`.`AssessmentMeasureIdx`) ";

// Table's primary key
$primaryKey = '`ASSMNTMEASURES`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`ASSMNTMEASURES`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => 'CONCAT(`STNTOUTCMS`.`SO`, " - ", `GPIS`.`GPI`)', 'dt' => 'SO_PI', 'field' => 'SO_PI', 'as' => 'SO_PI'),
    array( 'db' => '`ASSMNTMEASURES`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`ASSMNTMEASURES`.`Measure`', 'dt' => 'Measure', 'field' => 'Measure', 'as' => 'Measure'),
    array( 'db' => '`ASSMNTMEASURES`.`AssignmentType`', 'dt' => 'AssignmentType', 'field' => 'AssignmentType', 'as' => 'AssignmentType'),
    array( 'db' => '`ASSMNTMEASURES`.`AssignmentNum`', 'dt' => 'AssignmentNum', 'field' => 'AssignmentNum', 'as' => 'AssignmentNum'),
    array( 'db' => '`ASSMNTMEASURES`.`AssignmentProblem`', 'dt' => 'AssignmentProb', 'field' => 'AssignmentProb', 'as' => 'AssignmentProb'),
    array( 'db' => '`ASSMNTMEASURES`.`AssignmentDescription`', 'dt' => 'AssignmentDesc', 'field' => 'AssignmentDesc', 'as' => 'AssignmentDesc'),
    array( 'db' => 'AVG(`SCSHEET`.`LevelOfAttainment`)', 'dt' => 'AVG', 'field' => 'AVG', 'as' => 'AVG'),
    array( 'db' => 'COUNT(`SCSHEET`.`LevelOfAttainment`)', 'dt' => 'TOTAL', 'field' => 'TOTAL', 'as' => 'TOTAL'),
    array( 'db' => 'SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 2 THEN 1 ELSE NULL END)', 'dt' => 'TOPFIFTY', 'field' => 'TOPFIFTY', 'as' => 'TOPFIFTY'),
    array( 'db' => 'SUM(CASE WHEN `SCSHEET`.`LevelOfAttainment` >= 3 THEN 1 ELSE NULL END)', 'dt' => 'TOPTWENTYFIVE', 'field' => 'TOPTWENTYFIVE', 'as' => 'TOPTWENTYFIVE'),

);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );
$extraWhere = "`ASSMNTMEASURES`.`AvailableCourseIdx` = '$AvailableCourseIdx'";
$extraWhere .= " AND `ASSMNTMEASURES`.`AbetCourseIdx`= '$AbetCourseIdx'";
$groupBy = "`ASSMNTMEASURES`.`Idx`";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere, $groupBy, false)
);
