<?php
/**
 * Evaluation of Student Outcoms
 * Description: Creating JSON chart data
 *
 *
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }

function fetchMultiYearsChartData() {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Determine stored procedure and parameters
    $Query = "CALL SP_FetchOverallAbetCourseAssessmentsBySO_MultiYears(?, ?);";
    $academicYears = implode(",", $_SESSION['ATLAS_SELECTED_ACADEMICYEARS']);
    $params = [$academicYears, $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']];
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, $params);

    // Group data by Performance Indicator (GPI)
    $chartData = [];

    while ($row = $DBCONNECTION->fetch_assoc()) {
        $SO = $row['SO'];
        $academicYear = $row['AcademicYear'];

        if (!isset($chartData[$SO])) {
            $chartData[$SO] = [
                'description' => html_entity_decode($row['SODescription']),
                'data' => []
            ];
        }

        $chartData[$SO]['data'][$academicYear] = [
            'AVG' => sprintf('%.2f', $row['AVG']),
            'TOTAL' => $row['TOTAL'],
            'TOPFIFTY' => sprintf('%.2f', ($row['TOPFIFTY'] / max(1, $row['TOTAL'])) * 100),
            'TOPTWENTYFIVE' => sprintf('%.2f', ($row['TOPTWENTYFIVE'] / max(1, $row['TOTAL'])) * 100),
        ];
    }

    // Output JSON
    header('Content-Type: application/json');
    echo json_encode($chartData);
}
fetchMultiYearsChartData();