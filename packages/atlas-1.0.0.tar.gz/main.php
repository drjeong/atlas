<?php include('header.php'); ?>
	<!-- Information Should be here BEGIN-->

<div class="pagebacklayout">
	<div style="width:100%;height:30px">
		<p style="margin-top:0.2in;text-align:center;"><span style="font-size:12pt;font-weight:bold;">&nbsp;ATLAS: Academic Tracking & Learning Assessment System</span>&nbsp;</p>
	</div>

	<div class="pagebacklayout_inner_noborder" style="min-height:400px;">

	<article class="container" style="width:900px;">
        This is a web-based course assessment management system built to simplify and modernize the way faculty approach course evaluation. By providing an intuitive interface and a structured workflow, the system empowers educators to conduct assessments with greater ease, collect and manage course assessment materials more efficiently, and gain meaningful insights that support continuous academic improvement. <br/><br/>

    	The current version of the system is running within a cloud system. If you face a problem of using the system, please contact Dr. Jeong (djeong [at] udc.edu), Dr. Nitsche (ludwig.nitsche [at] udc.edu), or Dr. Wellman (briana.wellman [at] udc.edu).<br/><br/>

        <span style="font-weight: bold;"> Tutorials:</span><br/>
        <ul>
            <li><a href="./materials/tutorial1.pdf" target="_blank">Tutorial1 (PDF)</a></li>
            <li><a href="./materials/tutorial1.mp4" target="_blank">Tutorial1 (Video)</a></li>
        </ul>
        <ul>
            <li><a href="./materials/ABET Course Assessment_Feb2026.pdf" target="_blank">Tutorial2 (PDF)</a></li>
            <li><a href="./materials/ABET Meeting-Training-Meeting Recording.mp4" target="_blank">Tutorial2 (Video)</a></li>
        </ul>
    </article>
	</div>
</div>

<script src="js/datatable-utils-holdsearch.min.js"></script>
<script>
    // Clear all DataTable search holds
    DataTableHoldSearch.clearAllSearchHolds();
</script>

	<!-- Information Should be here END-->
<?php include('footer.php');?>
