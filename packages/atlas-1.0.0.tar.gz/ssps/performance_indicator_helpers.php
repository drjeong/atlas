<?php
/**
 * Performance Indicator Analysis Helper Functions
 *
 * Provides reusable functions for analyzing and saving performance indicators
 * for ABET courses across academic programs and years.
 *
 * Created: 06/06/2026
 * Updated: 06/06/2026 - Removed ABOVE3 column reference (not in Analyzed_PerformanceIndicators table)
 */

require_once('../php_include/dbconnection_class.php');
require_once('PerformanceIndicatorAnalyzer.php');

/**
 * Analyze and save performance indicators for ABET courses
 *
 * @param Dbconnection $dbConnection Database connection object
 * @param int $academicProgram Academic program ID
 * @param array|string $academicYears Array of academic year IDs or comma-separated string
 * @param bool $forceRecalculate If true, recalculates even if data exists (default: false)
 * @param string|null $requirementFilter Optional requirement filter (e.g., 'Core', 'Elective')
 * @return array Results array with 'success', 'processed', 'skipped', 'errors', and 'courses' keys
 */
function analyzeAndSavePerformanceIndicators(
    $dbConnection,
    $academicProgram,
    $academicYears,
    $forceRecalculate = true,
    $requirementFilter = null
) {
    // Initialize results tracking
    $results = array(
        'success' => true,
        'processed' => 0,
        'skipped' => 0,
        'errors' => array(),
        'courses' => array()
    );

    // Normalize academic years to array
    if (is_string($academicYears)) {
        $academicYears = array_map('intval', explode(',', $academicYears));
    } elseif (!is_array($academicYears)) {
        $academicYears = array(intval($academicYears));
    }

    // Build academic years string for query
    $academicYearsStr = implode(',', array_map('intval', $academicYears));

    // Build requirement filter clause
    $requirementClause = '';
    if ($requirementFilter !== null && $requirementFilter !== '' && $requirementFilter !== 'All') {
        $escapedRequirement = $dbConnection->real_escape_string($requirementFilter);
        $requirementClause = "AND ABETCRSES.Requirement = '{$escapedRequirement}'";
    }

    // Step 1: Get all ABET courses for selected academic program and years
    $query = "
        SELECT DISTINCT
            ABETCRSES.Idx AS AbetCourseIdx,
            ABETCRSES.AcademicYear AS AcademicYearIdx,
            AYS.AcademicYear,
            ABETCRSES.AVCourseIdx AS AvailableCourseIdx,
            ABETCRSES.Requirement,
            AVCRSES.CourseNo,
            AVCRSES.Crn,
            AVCRSES.Title,
            AVCRSES.Semester
        FROM `AbetCourses` AS `ABETCRSES`
        INNER JOIN `AcademicYears` AS `AYS` ON (ABETCRSES.AcademicYear = AYS.Idx)
        INNER JOIN `AVCourses` AS `AVCRSES` ON (
            AYS.`From` <= AVCRSES.Semester 
            AND AYS.`To` >= AVCRSES.Semester 
            AND ABETCRSES.AVCourseIdx = AVCRSES.Idx
        )
        WHERE ABETCRSES.AcademicProgram = ?
          AND ABETCRSES.AcademicYear IN ($academicYearsStr)
          $requirementClause
        ORDER BY ABETCRSES.AcademicYear, AVCRSES.CourseNo, AVCRSES.Semester
    ";

    $result = $dbConnection->prepare_execute_catch_error($query, array($academicProgram));

    if (!$result) {
        $results['success'] = false;
        $results['errors'][] = "Failed to fetch ABET courses: " . $dbConnection->error();
        return $results;
    }

    $abetCourses = array();
    if ($dbConnection->num_rows() > 0) {
        while ($row = $dbConnection->fetch_assoc()) {
            $abetCourses[] = array(
                'AbetCourseIdx' => $row['AbetCourseIdx'],
                'AcademicYearIdx' => $row['AcademicYearIdx'],
                'AcademicYear' => $row['AcademicYear'],
                'AvailableCourseIdx' => $row['AvailableCourseIdx'],
                'Requirement' => $row['Requirement'],
                'CourseNo' => $row['CourseNo'],
                'Crn' => $row['Crn'],
                'Title' => $row['Title'],
                'Semester' => $row['Semester']
            );
        }
    }

    if (empty($abetCourses)) {
        $results['errors'][] = "No ABET courses found for the specified criteria";
        return $results;
    }

    // Step 2: Analyze and save performance indicators
    $analyzer = new PerformanceIndicatorAnalyzer($dbConnection);
    $processedCourses = array();

    foreach ($abetCourses as $course) {
        // Create unique key to avoid processing same course multiple times
        $courseKey = $course['AbetCourseIdx'] . '_' . $course['AvailableCourseIdx'];

        if (isset($processedCourses[$courseKey])) {
            $results['skipped']++;
            continue;
        }
        $processedCourses[$courseKey] = true;

        try {
            // Check if analysis already exists (unless force recalculate)
            if (!$forceRecalculate) {
                $existingData = $analyzer->getSavedAnalysis(
                    $course['AbetCourseIdx'],
                    $course['AvailableCourseIdx'],
                    $academicProgram
                );

                if (!empty($existingData)) {
                    $results['skipped']++;
                    $results['courses'][] = array(
                        'courseNo' => $course['CourseNo'],
                        'crn' => $course['Crn'],
                        'title' => $course['Title'],
                        'status' => 'skipped',
                        'message' => 'Analysis already exists'
                    );
                    continue;
                }
            }

            // Calculate and save analysis
            // getAnalysis with autoSave=true will calculate and save to DB
            $analysisData = $analyzer->getAnalysis(
                $course['AbetCourseIdx'],
                $course['AvailableCourseIdx'],
                $academicProgram,
                true  // Auto-save to database
            );

            if ($analysisData !== false && !empty($analysisData)) {
                $results['processed']++;
                $results['courses'][] = array(
                    'courseNo' => $course['CourseNo'],
                    'crn' => $course['Crn'],
                    'title' => $course['Title'],
                    'requirement' => $course['Requirement'],
                    'semester' => $course['Semester'],
                    'status' => 'processed',
                    'indicatorCount' => count($analysisData)
                );
            } else {
                $results['skipped']++;
                $results['courses'][] = array(
                    'courseNo' => $course['CourseNo'],
                    'crn' => $course['Crn'],
                    'title' => $course['Title'],
                    'status' => 'skipped',
                    'message' => 'No analysis data available'
                );
            }

        } catch (Exception $e) {
            $results['success'] = false;
            $results['errors'][] = "Error processing {$course['CourseNo']} (CRN: {$course['Crn']}): " . $e->getMessage();
            $results['courses'][] = array(
                'courseNo' => $course['CourseNo'],
                'crn' => $course['Crn'],
                'title' => $course['Title'],
                'status' => 'error',
                'message' => $e->getMessage()
            );
        }
    }

    return $results;
}

/**
 * Get saved performance indicator analysis from database
 *
 * @param Dbconnection $dbConnection Database connection object
 * @param int $academicProgram Academic program ID
 * @param array|string $academicYears Array of academic year IDs or comma-separated string
 * @param string|null $requirementFilter Optional requirement filter
 * @return array Analysis data grouped by course
 */
function getSavedPerformanceIndicators(
    $dbConnection,
    $academicProgram,
    $academicYears,
    $requirementFilter = null
) {
    // Normalize academic years to array
    if (is_string($academicYears)) {
        $academicYears = array_map('intval', explode(',', $academicYears));
    } elseif (!is_array($academicYears)) {
        $academicYears = array(intval($academicYears));
    }

    $academicYearsStr = implode(',', array_map('intval', $academicYears));

    // Build requirement filter clause
    $requirementClause = '';
    if ($requirementFilter !== null && $requirementFilter !== '' && $requirementFilter !== 'All') {
        $escapedRequirement = $dbConnection->real_escape_string($requirementFilter);
        $requirementClause = "AND ABETCRSES.Requirement = '{$escapedRequirement}'";
    }

    $query = "
        SELECT
            AVCRSES.CourseNo,
            AVCRSES.CRN,
            AVCRSES.Title,
            AVCRSES.Semester,
            AVCRSES.Idx AS AvailableCourseIdx,
            ABETCRSES.Requirement,
            ABETCRSES.Level,
            ABETCRSES.Idx AS AbetCourseIdx,
            AYS.AcademicYear,
            ANLYZD_PI.GPIIdx,
            GPIS.GPI,
            STNTOUTCMS.SO,
            GPIS.Description AS GPIDescription,
            ANLYZD_PI.AVG,
            ANLYZD_PI.TOTAL,
            ANLYZD_PI.TOPFIFTY,
            ANLYZD_PI.TOPTWENTYFIVE
        FROM AbetCourses AS ABETCRSES
        INNER JOIN AcademicYears AS AYS ON (ABETCRSES.AcademicYear = AYS.Idx)
        INNER JOIN AVCourses AS AVCRSES ON (
            AYS.`From` <= AVCRSES.Semester 
            AND AYS.`To` >= AVCRSES.Semester 
            AND ABETCRSES.AVCourseIdx = AVCRSES.Idx
        )
        INNER JOIN Analyzed_PerformanceIndicators AS ANLYZD_PI ON (
            ANLYZD_PI.AbetCourseIdx = ABETCRSES.Idx
            AND ANLYZD_PI.AvailableCourseIdx = AVCRSES.Idx
            AND ANLYZD_PI.AcademicProgramIdx = ABETCRSES.AcademicProgram
        )
        INNER JOIN GeneralPerformanceIndicators AS GPIS ON (
            ANLYZD_PI.GPIIdx = GPIS.Idx
        )
        INNER JOIN StudentOutcomes AS STNTOUTCMS ON (
            GPIS.SOIdx = STNTOUTCMS.Idx
        )
        WHERE ABETCRSES.AcademicProgram = ?
        AND ABETCRSES.AcademicYear IN ($academicYearsStr)
        $requirementClause
        ORDER BY AVCRSES.CourseNo, ABETCRSES.Idx, STNTOUTCMS.SO, GPIS.GPI
    ";

    $result = $dbConnection->prepare_execute_catch_error($query, array($academicProgram));

    $courses = array();
    if ($result && $dbConnection->num_rows() > 0) {
        while ($row = $dbConnection->fetch_assoc()) {
            $courseKey = $row['CourseNo'] . '_' . $row['AbetCourseIdx'];

            if (!isset($courses[$courseKey])) {
                $courses[$courseKey] = array(
                    'courseNo' => $row['CourseNo'],
                    'crn' => $row['CRN'],
                    'title' => $row['Title'],
                    'requirement' => $row['Requirement'],
                    'level' => $row['Level'],
                    'abetCourseIdx' => $row['AbetCourseIdx'],
                    'availableCourseIdx' => $row['AvailableCourseIdx'],
                    'semester' => $row['Semester'],
                    'academicYear' => $row['AcademicYear'],
                    'indicators' => array()
                );
            }

            // Combine SO and GPI to create "SO 1-B" format
            // SO already contains "SO 1", "SO 2", etc., so just append "-" and GPI
            $combinedGPI = $row['SO'] . '-' . $row['GPI'];

            $courses[$courseKey]['indicators'][] = array(
                'gpiIdx' => $row['GPIIdx'],
                'gpi' => $combinedGPI,  // "SO 1-B" format
                'gpiCode' => $row['GPI'],  // Original GPI code (A, B, C, etc.)
                'so' => $row['SO'],  // "SO 1", "SO 2", etc.
                'gpiDescription' => $row['GPIDescription'],
                'avg' => floatval($row['AVG']),
                'total' => intval($row['TOTAL']),
                'topFifty' => intval($row['TOPFIFTY']),
                'topTwentyFive' => intval($row['TOPTWENTYFIVE'])
            );
        }
    }

    return $courses;
}

/**
 * Delete saved performance indicator analysis for specific criteria
 *
 * @param Dbconnection $dbConnection Database connection object
 * @param int $academicProgram Academic program ID
 * @param array|string $academicYears Array of academic year IDs or comma-separated string
 * @param string|null $requirementFilter Optional requirement filter
 * @return array Results with 'success' and 'deleted' count
 */
function deleteSavedPerformanceIndicators(
    $dbConnection,
    $academicProgram,
    $academicYears,
    $requirementFilter = null
) {
    // This would require additional logic to identify which records to delete
    // based on the AbetCourseIdx values that match the criteria
    // For now, returning a placeholder

    return array(
        'success' => false,
        'message' => 'Delete function not yet implemented - use forceRecalculate option instead'
    );
}