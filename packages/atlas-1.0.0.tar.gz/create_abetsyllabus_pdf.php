<?php
/**
 * Create ABET Syllabus PDF file
 * Description: It requires latex to be installed on the server.
 *      Check necessary components in LatexTemplate.php under php_include
 * Author: Dong Hyun Jeong
 *
 * 10/15/2024 - initial version created
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';

$AbetSyllabusIdx='';
$AcademicYearIdx=null;
$AcademicProgramIdx='';
if ( array_key_exists('_idx', $_POST) ) {
    $AbetSyllabusIdx = trim($_POST['_idx']);
}
if ( array_key_exists('_ay', $_POST) ) {
    $AcademicYearIdx = trim($_POST['_ay']);
}
if ( array_key_exists('_ap', $_POST) ) {
    $AcademicProgramIdx = trim($_POST['_ap']);
}
if (empty($AcademicProgramIdx)) {
    $AcademicProgramIdx = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
}

if ($AbetSyllabusIdx=='' || $AcademicProgramIdx=='') {
    // illegal entry
    exit;
}

//$abetSyllabusFile = 'tmp.pdf';
//error_log("$AbetSyllabusIdx, null, $AcademicYearIdx, $AcademicProgramIdx");

require_once __DIR__ . "/php_include/AbetSyllabusPDFCreator.php";
$creator = new AbetSyllabusPDFCreator($AbetSyllabusIdx, null, $AcademicYearIdx, $AcademicProgramIdx);
$creator->createPDF();
