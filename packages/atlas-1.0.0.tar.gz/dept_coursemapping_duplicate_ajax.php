<?php
/**
 * Duplicate Abet Course
 * Description: duplicating courses' student outcomes, performance indicators, and syllabus.
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 * 09/22/2024 - Bug fix - creating duplicated syllabus
 *
 */


include_once 'session_handler.php';


$AcademicYearFrom='';
$AcademicYearTo='';

if (array_key_exists('ayf', $_POST) && array_key_exists('ayt', $_POST) )
{
    $AcademicYearFrom = trim($_POST['ayf']);
    $AcademicYearTo = trim($_POST['ayt']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYearFrom=="" || $AcademicYearTo=="" || $AcademicProgram==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearFrom = filter_var($AcademicYearFrom, FILTER_VALIDATE_INT);
    if ($AcademicYearFrom === false) {
        throw new Exception('Invalid Academic Year format');
    }
    $AcademicYearTo = filter_var($AcademicYearTo, FILTER_VALIDATE_INT);
    if ($AcademicYearTo === false) {
        throw new Exception('Invalid Academic Year format');
    }

    // Duplicate SOs & PIs for all Abet Courses
    $query = "CALL SP_DuplicateCourseMapping_Courses(?, ?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$AcademicYearFrom, $AcademicYearTo, $AcademicProgram]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x09500011') !== false) {
        echo '0x09500011';  // data in the source year does not exist
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

