

/*!
 * soConverter.js
 *
 * Version:  0.0.1
 * Released:
 * Author:   Dong Hyun Jeong
 * License:  MIT
 *
 */
const SOConverter = {
  detectDelimiter: function(text) {
    const lines = text.trim().split('\n');
    const firstLine = lines[0];

    // Check for tabs first
    if (firstLine.includes('\t')) {
      // throw new Error("Tab-delimited data is not supported. Please use comma (,) or pipe (|) delimiters.");
    }

    const delimiters = {
      pipe: '|',
      comma: ','
    };

    const counts = {};
    for (const [key, delimiter] of Object.entries(delimiters)) {
      counts[key] = (firstLine.match(new RegExp(delimiter === '|' ? '\\|' : delimiter, 'g')) || []).length;
    }

    const maxCount = Math.max(...Object.values(counts));
    const delimiterType = Object.keys(counts).find(key => counts[key] === maxCount);

    return delimiters[delimiterType];
  },

  splitLine: function(line, delimiter) {
    if (!delimiter) {
      delimiter = this.detectDelimiter(line);
    }
    return line.split(delimiter);
  },

  generateColumnNames: function(soHeader, letterHeader) {
    const delimiter = this.detectDelimiter(soHeader);
    const columnNames = new Array(soHeader.split(delimiter).length).fill('');
    const sos = this.splitLine(soHeader, delimiter);
    const letters = this.splitLine(letterHeader, delimiter);
    let currentSO = '';

    for (let i = 0; i < sos.length; i++) {
      const soValue = sos[i].trim();
      const letterValue = letters[i].trim();

      if (soValue.startsWith('SO')) {
        currentSO = soValue;
      }

      if (letterValue && currentSO) {
        columnNames[i] = `${currentSO}-${letterValue}`;
      }
    }

    return {
      columnNames: columnNames,
      delimiter: delimiter
    };
  },

  convertRow: function(values, columnNames) {
    const soNotation = [];

    for (let i = 0; i < values.length; i++) {
      const value = values[i].trim();
      if (value !== '' && columnNames[i]) {
        soNotation.push(columnNames[i]);
      }
    }

    return soNotation;
  },

  extractCourseNumber: function(line, delimiter) {
    const values = this.splitLine(line, delimiter);
    return values[0].trim();
  },

  convertData: function(inputText) {
    try {
      inputText = inputText.replace(/\t/g, ",");

      const lines = inputText.trim().split('\n');
      const { columnNames, delimiter } = this.generateColumnNames(lines[0], lines[1]);

      let result = [];
      for (let i = 2; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        const courseNumber = this.extractCourseNumber(line, delimiter);
        const values = this.splitLine(line, delimiter);
        const soNotation = this.convertRow(values, columnNames);

        if (soNotation.length > 0) {
          result.push(`${courseNumber} | ${soNotation.join(', ')}`);
        }
      }

      return {
        columnNames: columnNames.filter(name => name !== ''),
        convertedData: result,
        success: true
      };
    } catch (error) {
      return {
        error: error.message,
        success: false
      };
    }
  }
};

// For CommonJS environments (Node.js)
if (typeof module !== 'undefined' && module.exports) {
  module.exports = SOConverter;
}