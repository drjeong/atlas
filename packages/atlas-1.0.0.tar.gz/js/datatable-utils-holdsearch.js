class DataTableHoldSearch {
  constructor(tableId, dataTable, showResetBtn = true, enableHoldSearch = false) {
    this.tableId = tableId;
    this.dataTable = dataTable;
    this.showResetBtn = showResetBtn;
    this.enableHoldSearch = enableHoldSearch;
    this.storageKey = `dtSearch_${tableId.replace('#', '')}`;
    this.initialize();
  }

  initialize() {
    if (this.showResetBtn) this.addResetButton();
    this.setupHeaderSearch();
    this.setupFooterSearch();
    this.initializeSearchHandlers();
    if (this.enableHoldSearch) {
      this.loadSavedSearches();
    }
  }

  saveSearchState() {
    if (!this.enableHoldSearch) return;

    const searchState = {
      header: {},
      footer: {},
      columns: {}
    };

    // Save header searches
    $(`${this.tableId} #serachbox input`).each((index, element) => {
      searchState.header[index] = $(element).val();
    });

    // Save footer searches
    $(`${this.tableId} tfoot input`).each((index, element) => {
      searchState.footer[index] = $(element).val();
    });

    // Save column searches
    this.dataTable.columns().every(function(index) {
      searchState.columns[index] = this.search();
    });

    localStorage.setItem(this.storageKey, JSON.stringify(searchState));
  }

  loadSavedSearches() {
    if (!this.enableHoldSearch) return;

    const savedState = localStorage.getItem(this.storageKey);
    if (!savedState) return;

    const searchState = JSON.parse(savedState);

    // Apply header searches
    $(`${this.tableId} #serachbox input`).each((index, element) => {
      const value = searchState.header[index] || '';
      $(element).val(value);
      if (value) $(element).siblings('.clearColumn').show();
    });

    // Apply footer searches
    $(`${this.tableId} tfoot input`).each((index, element) => {
      const value = searchState.footer[index] || '';
      $(element).val(value);
      if (value) $(element).siblings('.clearColumn').show();
    });

    // Apply column searches
    this.dataTable.columns().every(function(index) {
      const value = searchState.columns[index] || '';
      if (value) this.search(value);
    });

    this.dataTable.draw();
  }

  // addResetButton() {
  //   $(this.tableId).before('&nbsp;<button id="resetSearch" class="btn btn-danger btn-xs" style="height:25px; margin-bottom:10px;">CLEAR ALL FILTERS</button>&nbsp;');
  //
  //   $('#resetSearch').on('click', () => {
  //     // Clear all input fields
  //     $(`${this.tableId} #serachbox input, ${this.tableId} tfoot input`).each(function() {
  //       $(this).val('');
  //       $(this).siblings('.clearColumn').hide();
  //     });
  //
  //     // Clear all searches
  //     this.dataTable.columns().every(function() {
  //       this.search('');
  //     });
  //     this.dataTable.search('');
  //     this.dataTable.draw();
  //
  //     // Clear saved state if hold search is enabled
  //     if (this.enableHoldSearch) {
  //       localStorage.removeItem(this.storageKey);
  //     }
  //   });
  // }

  addResetButton() {
    this.dataTable.on('init.dt', () => {
      const tableId = this.tableId.replace('#', '');
      const btnResetAll = $('<button id="resetSearch" class="btn btn-danger btn-xs" style="height:25px; margin-right:8px;">CLEAR ALL FILTERS</button>');
      $(`#${tableId}_wrapper .dataTables_length`).prepend(btnResetAll);

      $('#resetSearch').on('click', () => {
        $(`${this.tableId} #serachbox input, ${this.tableId} tfoot input`).each(function() {
          $(this).val('');
          $(this).siblings('.clearColumn').hide();
        });
        this.dataTable.columns().every(function() {
          this.search('');
        });
        this.dataTable.search('');
        this.dataTable.draw();
        if (this.enableHoldSearch) {
          localStorage.removeItem(this.storageKey);
        }
      });
    });
  }

  setupHeaderSearch() {
    $(`${this.tableId} #serachbox th`).each((index, element) => {
      const title = $(element).text().trim();
      if (title !== '' && title !== null) {
        $(element).html(`
          <div style="display: flex; gap: 2px;">
            <input type="text" placeholder="Search ${title}" 
                   value="${this.dataTable.column(index).search()}"
                   style="color:black; width: 100%; padding:1px; box-sizing: border-box;"/>
            <button class="clearColumn" data-column="${index}" 
                    style="padding: 0 4px; display: none;">×</button>
          </div>
        `);
      }
    });
  }

  setupFooterSearch() {
    $(`${this.tableId} tfoot th`).each((index, element) => {
      const title = $(element).text().trim();
      if (title !== '' && title !== null) {
        $(element).html(`
                    <div style="display: flex; gap: 2px;">
                        <input type="text" placeholder="Search ${title}" 
                               value="${this.dataTable.column(index).search()}"
                               style="color:black; width: 100%; padding:1px; box-sizing: border-box;"/>
                        <button class="clearColumn" data-column="${index}" 
                                style="padding: 0 4px; display: none;">×</button>
                    </div>
                `);
      }
    });
  }

  initializeSearchHandlers() {
    // Individual column clear button handler
    $(this.tableId).on('click', '.clearColumn', (event) => {
      const columnIndex = $(event.currentTarget).data('column');
      $(event.currentTarget).siblings('input').val('');
      $(event.currentTarget).hide();
      this.dataTable.column(columnIndex).search('').draw();
      if (this.enableHoldSearch) {
        this.saveSearchState();
      }
    });

    // Input handlers for both header and footer
    const handleInput = (input, clearButton) => {
      if (input.value.length > 0) {
        clearButton.style.display = 'block';
      } else {
        clearButton.style.display = 'none';
      }
    };

    // Header search handler
    this.dataTable.columns().every((colIdx) => {
      const that = this.dataTable.column(colIdx);
      $('input', $('.filters th').eq($(this.dataTable.column(colIdx).header()).index()))
          .on('keyup change', (e) => {
            const clearButton = $(e.target).siblings('.clearColumn')[0];
            handleInput(e.target, clearButton);
            if (that.search() !== e.target.value) {
              that.search(e.target.value).draw();
              if (this.enableHoldSearch) {
                this.saveSearchState();
              }
            }
          });
    });

    // Footer search handler
    this.dataTable.columns().every((colIdx) => {
      const that = this.dataTable.column(colIdx);
      $('input', that.footer()).on('keyup change', (e) => {
        const clearButton = $(e.target).siblings('.clearColumn')[0];
        handleInput(e.target, clearButton);
        if (that.search() !== e.target.value) {
          that.search(e.target.value).draw();
          if (this.enableHoldSearch) {
            this.saveSearchState();
          }
        }
      });
    });

    // Save state before page unload only if hold search is enabled
    if (this.enableHoldSearch) {
      $(window).on('beforeunload', () => {
        this.saveSearchState();
      });
    }
  }

  // Static method to clear all DataTable search holds
  static clearAllSearchHolds() {
    const searchKeys = Object.keys(localStorage).filter(key => key.startsWith('dtSearch_'));
    searchKeys.forEach(key => localStorage.removeItem(key));
  }
}