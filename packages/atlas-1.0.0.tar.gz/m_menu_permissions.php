<?php
include('checker_systemadmin.php');
include('header.php');
?>


    <script type="text/javascript">
        let DataTable_MenuPermissions;
        let subMenuGroups = [];
        let userData = [];
        let menuStructure = {};
        let columnMapping = []; // Store column info for proper indexing

        function updateSelectAllCheckbox() {
            if (!DataTable_MenuPermissions) return;
            const visibleRows = DataTable_MenuPermissions.rows({ page: 'current' }).nodes();
            let totalCheckboxes = 0;
            let checkedCheckboxes = 0;
            $(visibleRows).each(function() {
                const checkbox = $(this).find('.row-select-check:not(:disabled)');
                if (checkbox.length) {
                    totalCheckboxes++;
                    if (checkbox.is(':checked')) checkedCheckboxes++;
                }
            });
            const selectAllCheckbox = $('#selectAllUsers');
            if (totalCheckboxes === 0 || checkedCheckboxes === 0) {
                selectAllCheckbox.prop('checked', false).prop('indeterminate', false);
            } else if (checkedCheckboxes === totalCheckboxes) {
                selectAllCheckbox.prop('checked', true).prop('indeterminate', false);
            } else {
                selectAllCheckbox.prop('checked', false).prop('indeterminate', true);
            }
        }

        function UpdatePermission(userIdx, groupCode, checked, parentMenu) {
            $.ajax({
                url: 'm_menu_permissions_update_ajax.php',
                method: 'POST',
                data: {
                    userIdx: userIdx,
                    checked: checked,
                    groupcode: groupCode,
                    parentmenu: parentMenu
                },
                success: function(response) {
                    if (response.trim() === "0x11111111") {
                        // Swal.fire({ title: 'Done!', text: 'Permissions updated.', icon: 'success', timer: 500 });
                    } else {
                        Swal.fire({ title: 'ERROR', text: "Failed to update permission.", icon: 'error', timer: 2000 });
                    }
                }
            });
        }

        function ShowPermissionSelectionDialog() {
            const selectedRows = DataTable_MenuPermissions.rows('.selected').data();
            if (selectedRows.length === 0) {
                Swal.fire({ title: 'No Users Selected', text: "Please select at least one user.", icon: 'warning' });
                return;
            }

            // Build checkbox list grouped by main menu
            let checkboxesHtml = '';

            // Add "Select All" option at the top
            checkboxesHtml += '<div style="margin-bottom:15px; padding:10px; background:#f0f0f0; border-radius:4px;">';
            checkboxesHtml += '<label style="font-weight:bold; cursor:pointer; display:block;">';
            checkboxesHtml += '<input type="checkbox" id="selectAllPermissions" style="margin-right:8px; width:14px; height:14px; vertical-align:middle;">';
            checkboxesHtml += 'Select All Permissions';
            checkboxesHtml += '</label>';
            checkboxesHtml += '</div>';

            // Group permissions by main menu
            Object.keys(menuStructure).forEach(function(mainMenuCode) {
                const mainMenu = menuStructure[mainMenuCode];
                if (mainMenu.groups.length > 0) {
                    checkboxesHtml += '<div style="margin-bottom:20px; border:1px solid #ddd; border-radius:4px; overflow:hidden;">';
                    checkboxesHtml += '<div style="background:#1976D2; color:#fff; padding:8px; font-weight:bold; font-size:13px;">';
                    checkboxesHtml += mainMenu.main.MenuName;
                    checkboxesHtml += '</div>';
                    checkboxesHtml += '<div style="padding:10px;">';

                    mainMenu.groups.forEach(function(group) {
                        checkboxesHtml += '<div style="margin:8px 0;">';
                        checkboxesHtml += '<label style="cursor:pointer; display:block; padding:4px;">';
                        checkboxesHtml += '<input type="checkbox" class="permission-select" name="_Permissions" ';
                        checkboxesHtml += 'value="' + group.GroupCode + '|' + mainMenuCode + '" ';
                        checkboxesHtml += 'data-groupcode="' + group.GroupCode + '" ';
                        checkboxesHtml += 'data-parentmenu="' + mainMenuCode + '" ';
                        checkboxesHtml += 'style="margin-right:10px; width:18px; height:18px; vertical-align:middle;">';
                        checkboxesHtml += '<span style="font-size:13px;">' + group.GroupName + '</span>';
                        checkboxesHtml += ' <span style="color:#666; font-size:11px;">(' + group.GroupCode + ')</span>';
                        checkboxesHtml += '</label>';
                        checkboxesHtml += '</div>';
                    });

                    checkboxesHtml += '</div>';
                    checkboxesHtml += '</div>';
                }
            });

            const content =
                `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
                 <table style="border-spacing:0; padding:0; width:100%;">
                 <tr><td>
                 <div class="input-group" style="width:100%">
                  <div class="input-group" style="width:100%">
                      <span class="input-group-addon" style="width:200px;">Selected Users</span>
                      <div class="form-control" style="background:#f9f9f9; height:auto; min-height:34px;">
                          <strong>${selectedRows.length}</strong> user(s) selected
                      </div>
                  </div>
                  <div class="input-group" style="width:100%">
                      <span class="input-group-addon" style="width:200px;">Permissions to Enable<span style="color:red">*</span></span>
                      <div style="margin:5px; height:400px; overflow-y:auto; border:1px solid #ddd; border-radius:4px; padding:10px; background:#fff;">
                          ${checkboxesHtml}
                      </div>
                  </div>
                 </div>
                 </td></tr>
                 </table></form>`;

            createModalDialog({
                className: "dialogWidth40p",
                title: `<span class="glyphicon glyphicon-check" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;
                        <span style="font-size:16pt;font-weight:bold;">ENABLE PERMISSIONS FOR SELECTED USERS</span>`,
                message: content,
                buttons: {
                    ok: {
                        label: '<span class="glyphicon glyphicon-ok"></span>&nbsp;APPLY SELECTED',
                        className: 'btn-success',
                        callback: function() {
                            const selectedPermissions = [];
                            document.querySelectorAll('input[name="_Permissions"]:checked').forEach(function(checkbox) {
                                selectedPermissions.push({
                                    groupCode: checkbox.dataset.groupcode,
                                    parentMenu: checkbox.dataset.parentmenu
                                });
                            });

                            if (selectedPermissions.length === 0) {
                                Swal.fire({
                                    title: 'No Permissions Selected',
                                    text: "Please select at least one permission to enable.",
                                    icon: 'warning'
                                });
                                return false;
                            }

                            // Apply selected permissions to selected users
                            let updateCount = 0;
                            DataTable_MenuPermissions.rows('.selected').every(function() {
                                const rowNode = $(this.node());
                                const rowData = this.data();

                                selectedPermissions.forEach(function(perm) {
                                    // Find the checkbox for this permission in this row
                                    const checkbox = rowNode.find('.permission-check[data-groupcode="' + perm.groupCode + '"][data-parentmenu="' + perm.parentMenu + '"]');

                                    if (checkbox.length && !checkbox.is(':disabled') && !checkbox.is(':checked')) {
                                        checkbox.prop('checked', true);
                                        UpdatePermission(rowData.Idx, perm.groupCode, true, perm.parentMenu);
                                        updateCount++;
                                    }
                                });
                            });

                            Swal.fire({
                                title: 'Done!',
                                text: updateCount + ' permission(s) enabled.',
                                icon: 'success',
                                timer: 2000
                            });
                        }
                    },
                    cancel: {
                        label: '<span class="glyphicon glyphicon-remove"></span>&nbsp;CANCEL',
                        className: 'btn-default',
                        callback: function() {
                        }
                    }
                }
            }).on('shown.bs.modal', function() {
                // Handle "Select All" checkbox
                $('#selectAllPermissions').on('change', function() {
                    const isChecked = $(this).is(':checked');
                    $('.permission-select').prop('checked', isChecked);
                });

                // Update "Select All" state when individual checkboxes change
                $('.permission-select').on('change', function() {
                    const total = $('.permission-select').length;
                    const checked = $('.permission-select:checked').length;
                    $('#selectAllPermissions').prop('checked', checked === total);
                    $('#selectAllPermissions').prop('indeterminate', checked > 0 && checked < total);
                });
            });
        }

        function showColumnMenu() {
            const menu = document.getElementById('columnVisibilityMenu');
            menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
        }

        // Close menu when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#columnVisibilityBtn, #columnVisibilityMenu').length) {
                $('#columnVisibilityMenu').hide();
            }
        });

        function buildColumnToggleBar(table) {
            const menu = $('#columnVisibilityMenu');
            // Remove previously injected items
            menu.find('.col-menu-group-header, .col-menu-item').remove();

            let lastMainMenu = null;

            columnMapping.forEach(function(col, index) {
                if (col.type !== 'permission' && col.type !== 'empty') return;

                // Insert group header when main menu changes
                if (col.mainMenuName !== lastMainMenu) {
                    lastMainMenu = col.mainMenuName;
                    menu.append(
                        $('<div>').addClass('col-menu-group-header').text(col.mainMenuName)
                    );
                }

                const dtColumn = table.column(index);
                const isVisible = dtColumn.visible();
                const subLabel = col.type === 'permission'
                    ? 'Measure: ' + col.groupName + ' (' + col.groupCode + ')'
                    : col.mainMenuName + ' — (no submenus)';

                const itemDiv = $('<div>').addClass('col-menu-item');
                const label = $('<label>');
                const checkbox = $('<input type="checkbox">')
                    .prop('checked', isVisible)
                    .attr('data-col-index', index)
                    .css({ marginRight: '8px', verticalAlign: 'top', marginTop: '2px', float: 'left' })
                    .on('change', function() {
                        const colIdx = $(this).data('col-index');
                        table.column(colIdx).visible($(this).is(':checked'));
                        updateToggleAllCheckbox();
                    });

                const span = $('<span>').css({ display: 'block', marginLeft: '25px' }).text(subLabel);

                label.append(checkbox).append(span);
                itemDiv.append(label);
                menu.append(itemDiv);
            });

            updateToggleAllCheckbox();
        }

        function updateToggleAllCheckbox() {
            const all = $('#columnVisibilityMenu input[data-col-index]');
            const checked = $('#columnVisibilityMenu input[data-col-index]:checked');
            const toggleAll = $('#toggleAllColumns')[0];
            if (checked.length === 0) {
                toggleAll.checked = false;
                toggleAll.indeterminate = false;
            } else if (checked.length === all.length) {
                toggleAll.checked = true;
                toggleAll.indeterminate = false;
            } else {
                toggleAll.checked = false;
                toggleAll.indeterminate = true;
            }
        }

        function toggleAllColumnsFunc(masterCheckbox) {
            const isChecked = masterCheckbox.checked;
            $('#columnVisibilityMenu input[data-col-index]').each(function() {
                $(this).prop('checked', isChecked);
                DataTable_MenuPermissions.column($(this).data('col-index')).visible(isChecked);
            });
        }

        function updateAllToggleBtn() {
            const allVisible = $('#columnToggleBar .btn-col-toggle:not(.hidden-col)').length ===
                $('#columnToggleBar .btn-col-toggle').length;
            $('#btnToggleAllCols')
                .toggleClass('active', allVisible)
                .toggleClass('hidden-col', !allVisible);
        }


        $(document).ready(function() {
            $.ajax({
                url: 'ssps/m_menu_permissions_ssps.php',
                method: 'GET',
                dataType: 'json',
                async: false,
                success: function(response) {
                    if (!response.menuItems || response.menuItems.length === 0) {
                        Swal.fire({ title: "Warning", text: "No menu items found.", icon: "warning" });
                        return;
                    }
                    subMenuGroups = response.menuItems; // These are now only submenu groups
                    userData = response.data;

                    // Build menu structure organized by main menu
                    const mainMenus = response.mainMenus || [];
                    mainMenus.forEach(function(mainMenu) {
                        menuStructure[mainMenu.MenuCode] = { main: mainMenu, groups: [] };
                    });

                    // Populate groups under their parent menus
                    subMenuGroups.forEach(function(group) {
                        if (menuStructure[group.ParentMenuCode]) {
                            menuStructure[group.ParentMenuCode].groups.push(group);
                        }
                    });

                    // Build column mapping and header
                    columnMapping = [
                        { type: 'select' },
                        { type: 'username' },
                        { type: 'position' }
                    ];

                    let headerHtml = '<tr>' +
                        '<th class="th-select"><input type="checkbox" id="selectAllUsers" /></th>' +
                        '<th class="th-username">USER NAME</th>' +
                        '<th class="th-position">POSITION NAME</th>';

                    mainMenus.forEach(function(mainMenu) {
                        const groups = menuStructure[mainMenu.MenuCode].groups;
                        if (groups.length > 0) {
                            groups.forEach(function(group) {
                                columnMapping.push({
                                    type: 'permission',
                                    groupCode: group.GroupCode,
                                    parentMenu: mainMenu.MenuCode,
                                    mainMenuName: mainMenu.MenuName,
                                    groupName: group.GroupName
                                });
                                headerHtml += '<th class="th-perm" data-groupcode="' + group.GroupCode + '" data-parentmenu="' + mainMenu.MenuCode + '">' +
                                    '<div class="th-main">' + mainMenu.MenuName + '</div>' +
                                    '<div class="th-sub">' + group.GroupName + '</div>' +
                                    '<div class="th-code">(' + group.GroupCode + ')</div>' +
                                    '</th>';
                            });
                        } else {
                            columnMapping.push({ type: 'empty', mainMenuName: mainMenu.MenuName });
                            headerHtml += '<th class="th-empty">' +
                                '<div class="th-main">' + mainMenu.MenuName + '</div>' +
                                '<div class="th-sub">—</div>' +
                                '</th>';
                        }
                    });

                    headerHtml += '</tr>';
                    $('#menupermissions thead').html(headerHtml);
                }
            });

            if (subMenuGroups.length === 0) return;

            // Build columns based on columnMapping
            let columns = [];
            columnMapping.forEach(function(col, index) {
                if (col.type === 'select') {
                    columns.push({
                        data: null,
                        className: "td-select",
                        orderable: false,
                        render: function(data, type, row) {
                            const disabled = row.SystemAdmin == '1' ? 'disabled' : '';
                            return '<input type="checkbox" class="row-select-check" data-userid="' + row.Idx + '" ' + disabled + '/>';
                        }
                    });
                } else if (col.type === 'username') {
                    columns.push({ data: 'Name', className: "td-username" });
                } else if (col.type === 'position') {
                    columns.push({ data: 'PositionName', className: "td-position" });
                } else if (col.type === 'permission') {
                    columns.push({
                        data: null,
                        className: "td-perm",
                        orderable: false,
                        render: function(data, type, row) {
                            const hasPermission = row.Permissions && row.Permissions[col.groupCode] == '1';
                            const checked = hasPermission ? 'checked' : '';
                            const disabled = row.SystemAdmin == '1' ? 'disabled' : '';
                            return '<input type="checkbox" class="permission-check" data-userid="' + row.Idx + '" ' +
                                'data-groupcode="' + col.groupCode + '" data-parentmenu="' + col.parentMenu + '" ' +
                                checked + ' ' + disabled + '/>';
                        }
                    });
                } else {
                    columns.push({
                        data: null,
                        className: "td-empty",
                        orderable: false,
                        render: function() { return '—'; }
                    });
                }
            });

            // Initialize DataTable WITHOUT scrollX - use wrapper instead
            DataTable_MenuPermissions = $("#menupermissions").DataTable({
                processing: true,
                serverSide: false,
                lengthMenu: [30, 50, 80, 100],
                data: userData,
                columns: columns,
                autoWidth: false,
                scrollX: false,  // Disabled!
                fnInitComplete: function(oSettings) {
                    updateSelectAllCheckbox();
                    buildColumnToggleBar(this.api());
                },
                fnDrawCallback: function() {
                    updateSelectAllCheckbox();
                }
            });

            // Select all handler
            $(document).on('change', '#selectAllUsers', function() {
                const isChecked = $(this).is(':checked');
                DataTable_MenuPermissions.rows({ page: 'current' }).every(function() {
                    const rowData = this.data();
                    const rowNode = $(this.node());
                    if (isChecked && rowData.SystemAdmin != '1') {
                        rowNode.addClass('selected').find('.row-select-check').prop('checked', true);
                    } else if (!isChecked) {
                        rowNode.removeClass('selected').find('.row-select-check').prop('checked', false);
                    }
                });
            });

            // Row checkbox handler
            $('#menupermissions tbody').on('change', '.row-select-check', function() {
                const row = $(this).closest('tr');
                $(this).is(':checked') ? row.addClass('selected') : row.removeClass('selected');
                updateSelectAllCheckbox();
            });

            // Row click handler
            $('#menupermissions tbody').on('click', 'tr', function(e) {
                if ($(e.target).is('input')) return;
                const row = $(this);
                const rowData = DataTable_MenuPermissions.row(row).data();
                if (rowData && rowData.SystemAdmin == '1') return;
                row.toggleClass('selected');
                row.find('.row-select-check').prop('checked', row.hasClass('selected'));
                updateSelectAllCheckbox();
            });

            // Permission checkbox handler
            $('#menupermissions tbody').on('change', '.permission-check:not(:disabled)', function() {
                const $this = $(this);
                $this.closest('td').addClass('updating');
                UpdatePermission($this.data('userid'), $this.data('groupcode'), $this.is(':checked'), $this.data('parentmenu'));
                setTimeout(function() { $this.closest('td').removeClass('updating'); }, 500);
            });

            /// Header click to toggle column
            $(document).on('click', '#menupermissions thead th.th-perm', function() {
                const th = $(this);
                const groupCode = th.data('groupcode');
                const parentMenu = th.data('parentmenu');
                const colIndex = th.index();

                // Count how many users on current page don't have this permission
                let enableCount = 0;
                let disableCount = 0;

                DataTable_MenuPermissions.rows({ page: 'current' }).every(function() {
                    const td = $(this.node()).find('td').eq(colIndex);
                    const checkbox = td.find('.permission-check:not(:disabled)');
                    if (checkbox.length) {
                        if (checkbox.is(':checked')) {
                            disableCount++;
                        } else {
                            enableCount++;
                        }
                    }
                });

                // Determine action based on what would affect more users
                const shouldEnable = enableCount >= disableCount;
                const action = shouldEnable ? 'enable' : 'disable';
                const affectedCount = shouldEnable ? enableCount : disableCount;

                if (affectedCount === 0) {
                    Swal.fire({
                        title: 'No Changes Needed',
                        text: 'All visible users already have the desired state for this permission.',
                        icon: 'info'
                    });
                    return;
                }

                // Show confirmation dialog
                Swal.fire({
                    title: 'Confirm Permission Update',
                    html: `Are you sure you want to <strong>${action}</strong> this permission for <strong>${affectedCount}</strong> visible user(s) on this page?<br><br>` +
                        `<div style="text-align:left; padding:10px; background:#f0f0f0; border-radius:4px; margin-top:10px;">` +
                        `<strong>Permission:</strong> ${th.find('.th-sub').text()}<br>` +
                        `<strong>Group:</strong> ${th.find('.th-main').text()}` +
                        `</div>`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: `Yes, ${action.toUpperCase()}`,
                    confirmButtonColor: shouldEnable ? '#28a745' : '#dc3545',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Add visual feedback
                        th.addClass('toggled-on');

                        let updateCount = 0;

                        // Only process rows on the current page
                        DataTable_MenuPermissions.rows({ page: 'current' }).every(function() {
                            const td = $(this.node()).find('td').eq(colIndex);
                            const checkbox = td.find('.permission-check:not(:disabled)');
                            if (checkbox.length) {
                                const isChecked = checkbox.is(':checked');
                                const shouldUpdate = shouldEnable ? !isChecked : isChecked;

                                if (shouldUpdate) {
                                    checkbox.prop('checked', shouldEnable);
                                    UpdatePermission(checkbox.data('userid'), groupCode, shouldEnable, parentMenu);
                                    updateCount++;
                                }
                            }
                        });

                        // Remove visual feedback after a delay
                        setTimeout(function() {
                            th.removeClass('toggled-on');
                        }, 1000);

                        Swal.fire({
                            title: 'Done!',
                            text: `${updateCount} permission(s) ${shouldEnable ? 'enabled' : 'disabled'}.`,
                            icon: 'success',
                            timer: 2000
                        });
                    }
                });
            });

            $('#btnEnableSelectedPermissions').on('click', ShowPermissionSelectionDialog);
        });
    </script>
    <style>
        /* Wrapper for horizontal scroll */
        .table-wrapper {
            width: 100%;
            overflow-x: auto;
            overflow-y: visible;
        }
        #menupermissions {
            border-collapse: collapse;
            width: max-content !important;
            min-width: 100%;
        }
        #menupermissions th,
        #menupermissions td {
            border: 1px solid #ccc;
            padding: 6px 8px;
            vertical-align: middle;
            text-align: center;
            white-space: nowrap;
        }
        /* Header styles */
        .th-select {
            width: 40px;
            background: #f0f0f0;
        }
        .th-username,
        .th-position {
            background: #fff3cd;
            text-align: left;
            min-width: 150px;
        }
        .th-perm {
            background: linear-gradient(to bottom, #1976D2 0%, #1976D2 35%, #64B5F6 35%, #64B5F6 100%);
            color: #000;
            min-width: 130px;
            max-width: 160px;
            white-space: normal;
            cursor: pointer;
            transition: background 0.2s;
        }
        .th-perm:hover {
            background: linear-gradient(to bottom, #1565C0 0%, #1565C0 35%, #42A5F5 35%, #42A5F5 100%);
        }
        .th-perm.toggled-on {
            background: linear-gradient(to bottom, #2E7D32 0%, #2E7D32 35%, #81C784 35%, #81C784 100%);
        }
        .th-main {
            background: rgba(255,255,255,0.2);
            color: #fff;
            font-size: 9px;
            font-weight: bold;
            text-transform: uppercase;
            padding: 3px;
            margin: -6px -8px 4px -8px;
        }
        .th-sub {
            font-size: 10px;
            font-weight: 600;
            line-height: 1.2;
        }
        .th-code {
            font-size: 8px;
            color: #333;
            font-style: italic;
        }
        .th-empty {
            background: #e0e0e0;
            min-width: 100px;
        }
        .th-empty .th-main {
            background: rgba(0,0,0,0.1);
            color: #333;
        }
        /* Cell styles */
        .td-select {
            background: #f9f9f9;
            width: 40px;
        }
        .td-username,
        .td-position {
            text-align: left;
            background: #fffef5;
        }
        .td-perm {
            background: #f5f9ff;
        }
        .td-perm.updating {
            background: #ffffcc !important;
        }
        .td-empty {
            background: #fafafa;
            color: #999;
        }
        /* Checkboxes */
        .permission-check,
        .row-select-check,
        #selectAllUsers {
            width: 14px;
            height: 14px;
            cursor: pointer;
        }
        .permission-check:checked {
            accent-color: #28a745;
        }
        .permission-check:disabled,
        .row-select-check:disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }
        /* Row selection */
        #menupermissions tbody tr {
            cursor: pointer;
        }
        #menupermissions tbody tr.selected {
            background: #b0d4f1 !important;
        }
        #menupermissions tbody tr.selected td {
            background: #b0d4f1 !important;
        }
        #menupermissions tbody tr:hover td {
            background: #e8f4fc !important;
        }
        /* Legend & buttons */
        .alert-info {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .permission-legend {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 10px 15px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .permission-legend input[type="checkbox"] {
            width: 12px;
            height: 12px;
        }
        .legend-item {
            display: inline-block;
            margin-right: 20px;
        }
        .btn-enable-all {
            background: #28a745;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }
        .btn-enable-all:hover {
            background: #218838;
        }
        .action-buttons {
            margin-bottom: 15px;
            text-align: right;
        }
        /* DataTables overrides */
        .dataTables_wrapper .dataTables_scroll {
            overflow: visible !important;
        }

        #columnVisibilityMenu .col-menu-group-header {
            background: #1976D2;
            color: #fff;
            font-size: 11px;
            font-weight: bold;
            padding: 4px 8px;
            margin: 6px -10px 2px -10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        #columnVisibilityMenu label {
            font-weight: normal;
            cursor: pointer;
            margin: 0;
            display: block;
        }
        #columnVisibilityMenu .col-menu-item {
            padding: 5px 5px;
            border-bottom: 1px solid #eee;
        }
        #columnVisibilityMenu .col-menu-item:hover {
            background: #f0f7ff;
        }
    </style>
    <div class="pagebacklayout">
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;">
                <span class="largeheadline">&nbsp;USER ACCESS PERMISSIONS MANAGEMENT</span>&nbsp;
            </p>
        </div>
        <div class="pagebacklayout_inner_noborder" style="min-height:400px">
            <div style="padding: 20px;">
                <div class="alert alert-info">
                    <strong>Instructions:</strong> Click row to select • Check boxes to grant submenu group access • Click column header to toggle all • System Admins are grayed out
                </div>
                <div class="permission-legend">
                    <span class="legend-item"><input type="checkbox" checked style="width:13px;height:13px;accent-color:#28a745;pointer-events:none;"> Has access</span>
                    <span class="legend-item"><input type="checkbox" style="width:13px;height:13px;accent-color:#5cb85c;pointer-events:none;"> No access</span>
                    <span class="legend-item"><input type="checkbox" checked style="width:13px;height:13px;accent-color:#2196F3;pointer-events:none;"> Row Selected</span>
                </div>
                <div style="position: relative; display: inline-block; margin-bottom: 12px;">
                    <button id="columnVisibilityBtn" class="btn btn-primary btn-sm" onclick="showColumnMenu(); return false;">
                        <span class="glyphicon glyphicon-th-list"></span> Show/Hide Columns
                    </button>
                    <div id="columnVisibilityMenu" style="display: none; position: absolute; left: 0; top: 100%; background: white; border: 1px solid #ccc; padding: 10px; margin-top: 5px; min-width: 300px; max-width: 420px; box-shadow: 0 2px 5px rgba(0,0,0,0.2); z-index: 1000; max-height: 400px; overflow-y: auto; text-align: left;">
                        <div style="padding: 5px 5px 8px 5px; border-bottom: 2px solid #1976D2; margin-bottom: 5px;">
                            <label style="font-weight: bold; cursor: pointer; margin: 0; display: block;">
                                <input type="checkbox" id="toggleAllColumns" checked onchange="toggleAllColumnsFunc(this)" style="margin-right: 8px; vertical-align: middle;">
                                <span>Show All / Hide All</span>
                            </label>
                        </div>
                        <!-- Injected dynamically -->
                    </div>
                </div>
                <div class="table-wrapper">
                    <table id="menupermissions" class="CSSTable_SSPSLIST">
                        <thead></thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php include('footer.php');?>