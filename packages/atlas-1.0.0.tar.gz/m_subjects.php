<?php
/**
 * Management of Academic Degree Programs
 * Description: managing course subjects
 * Author: Dong Hyun Jeong
 *
 * 10/27/2024 - initial version created
 *
 */

include('checker_programdirector.php');
include('header.php');
?>

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>

<script type="text/javascript">

    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        SAME_ITEM_EXIST: '0x00200011',
        ITEM_NOT_EXIST: '0x00200012',
        CANNOT_REMOVE_ITEM_ALREADY_INUSE: '0x09000010',
    };

    async function UpdateSubject(_ID, _SBJT, _DEPTIDX) {
        try {
            const result = await async_commons.makeApiCall('m_subjects_update_ajax.php', {
                id: _ID,
                sbjt: _SBJT,
                dept: _DEPTIDX
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('UPDATED', 'Information has been updated!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `The entered information exists already!`
                    );
                    // Re-open the add dialog
                    ModifySubject(_ID, _SBJT, _DEPTIDX);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function RemoveSubject(id, dp){
        try {
            const willDelete = await async_commons.showConfirmDialog(
                `Deleted information (<span style="color:red">${dp}</span>) cannot be restored!`
            );

            if (!willDelete.value) return;

            const result = await async_commons.makeApiCall('m_subjects_remove_ajax.php', {
                id: id
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('DELETED', 'The selected subject has been deleted!');
                    break;
                }
                case ErrorCodes.CANNOT_REMOVE_ITEM_ALREADY_INUSE: {
                    await async_commons.showErrorMessage('ERROR', 'The selected subject cannot be removed!! It has been used already!!');
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function ModifySubject(_ID, _SBJT, _DEPTIDX)
    {
        const formContent = ''
            + '<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">'
            + '<input type="hidden" name="_ID" value="'+_ID+'">'
            + '<table style="border-spacing:0; padding:0; width:100%;">'
            + '<tr><td colspan="2">'
            + '<div class="input-group" style="width:100%">'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Program&nbsp;Name (Major)<span style="color:red">*</span></span>'
            + '     <input type="text" name="_SBJT" id="_SBJT" class="input-sm form-control" value="'+_SBJT+'" placeholder="ex) Computer Science" required>'
            + ' </div>'
            + ' <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Department&nbsp;Name<span style="color:red">*</span></span>'
            + '     <select name="_DEPTIDX" class="input-sm form-control"><?php include('inc_departmentinfo.php'); ?></select>'
            + ' </div>'
            + '</div>'
            + '</td></tr>'
            + '</table></form>';

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">EDIT SUBJECT</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;UPDATE",
                    className: 'btn-success',
                    callback: function(){
                        if (ValidateItems(popupfrm)===false) return false;
                        UpdateSubject(popupfrm._ID.value, popupfrm._SBJT.value, popupfrm._DEPTIDX.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_SBJT").focus();
        });
        popupfrm._DEPTIDX.value = _DEPTIDX;
    }

    async function AddSubject_Perform(_SBJT, _DEPTIDX) {
        try {
            const result = await async_commons.makeApiCall('m_subjects_add_ajax.php', {
                sbjt: _SBJT,
                dept: _DEPTIDX
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage('ADDED', 'Subject is added successfully!');
                    break;
                }
                case ErrorCodes.SAME_ITEM_EXIST: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `The entered subject exists already!`
                    );
                    // Re-open the add dialog
                    AddSubject(_SBJT, _DEPTIDX);
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function AddSubject(_SBJT='', _DEPTIDX='')
    {
        const formContent =
            `<form name="popupfrm" id="popupfrm" method="" onsubmit="return false;">
             <table style="border-spacing:0; padding:0; width:100%;">
             <tr><td colspan="2">
             <div class="input-group" style="width:100%">
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Course Subject<span style="color:red">*</span></span>
                  <input type="text" name="_SBJT" id="_SBJT" class="input-sm form-control" value="${_SBJT}" placeholder="ex) CSCI" required>
              </div>
              <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:200px;">Department&nbsp;Name<span style="color:red">*</span></span>
                  <select name="_DEPTIDX" class="input-sm form-control"><?php include('inc_departmentinfo.php'); ?></select>
              </div>
             </div>
             </td></tr>
             </table></form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">ADD SUBJECT</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;ADD",
                    className: 'btn-success',
                    callback: function(){
                        if (ValidateItems(popupfrm)===false) return false;
                        AddSubject_Perform(popupfrm._SBJT.value, popupfrm._DEPTIDX.value);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_SBJT").focus();
        });

        if (_DEPTIDX!=='')
            popupfrm._DEPTIDX.value = _DEPTIDX;
    }

    function ValidateItems(frm)
    {
        if (frm._SBJT.value.isEmpty())
        {
            frm._SBJT.focus();
            Swal.fire({title:"ERROR", text: "Subject name is not entered!!", icon:"error"});

            return false;
        }
        else if (frm._DEPTIDX.value.isEmpty())
        {
            frm._DEPTIDX.focus();
            Swal.fire({title:"ERROR", text: "Department Name is not selected!!", icon:"error"});

            return false;
        }
        return true;
    }
</script>
<?php
}
?>

<script class="init">
$(document).ready(function() {
	DataTable_Subjects = $("#subjects").DataTable({
		processing: true,
		serverSide: true,
        lengthMenu: [ 30, 50, 75, 100, 150, 300, 500 ],
		ajax: "ssps/m_subjects_ssps.php",
		fnInitComplete: function(oSettings, json) {
		  // Add "Clear Filter" button to Filter
		  let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
		  btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
		  $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
		   $('#' + oSettings.sTableId).dataTable().fnFilter('');
		  });
		},
		columns: [
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
			{ data: 'Idx' },
<?php
}
?>
			{ data: 'Subject' },
			{ data: 'DeptName' },
			{ data: 'Date' },
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
			{ data: '' } // used for representing menu options
<?php
}
?>
		],
		columnDefs: [
            {
                targets: '_all',
                className: 'dt-center'
            },
            {
                targets  : 'no-sort',
                orderable: false,
            }
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
		,{
            targets: -1,
            data: null,
            orderable: false,
            defaultContent: "<div style=\"width:100%;text-align:center;\"><button id=\"modify\" class=\"btn btn-danger btn-xs glyphicon glyphicon-wrench\" style=\"min-height: 20px;\"></button>&nbsp;<button id=\"remove\" class=\"btn btn-danger btn-xs glyphicon glyphicon-remove\" style=\"min-height: 20px;\"></button></div>"
		}
<?php
}
?>
        ]
	});
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
    async_commons.setDataTable(DataTable_Subjects);

	$('#subjects tbody').on( 'click', '#remove', function () {
		const data = DataTable_Subjects.row( $(this).parents('tr') ).data();
		RemoveSubject(data.Idx, data.Subject);
	} );

	$('#subjects tbody').on( 'click', '#modify', function () {
        const data = DataTable_Subjects.row( $(this).parents('tr') ).data();
		ModifySubject(data.Idx, data.Subject, data.DeptIdx);
	} );
<?php
}
?>
} );

</script>


<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSE SUBJECTS</span>&nbsp;</p>
	</div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
			<td width="80%"></td>
			<td width="20%" align="right">
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
                <button class="btn btn-danger btn-sm" onclick="AddSubject();return false;">ADD SUBJECT</button>
<?php
}
?>
            </td>
		</tr>
		</table>

		<div class="CSSTable_SSPSLIST">
		<table id="subjects" class="display" style="border-spacing:0; padding:0; width:100%;">
		<thead>
			<tr>
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
				<th>IDX</th>
<?php
}
?>
                <th>COURSE SUBJECT</th>
				<th>DEPARTMENT NAME</th>
				<th>ADDED DATE</th>
<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
				<th class="no-sort">OPERATION</th>
<?php
}
?>
			</tr>
		</thead>
		</table>
		</div>
	</div>
</div>


<?php include('footer.php');?>

