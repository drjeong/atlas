<?php
/**
 * Create Course Binder PDF file
 * Description: It requires latex to be installed on the server.
 *      Check necessary components in LatexTemplate.php under php_include
 * Author: Dong Hyun Jeong
 *
 * 02/27/2024 - initial version created
 *
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';

// Increase execution time limits
set_time_limit(300);  // 5 minutes (adjust as needed)
ini_set('max_execution_time', 300);
ini_set('memory_limit', '512M');  // Increase if handling large PDFs

//$AvailableCourseIdx = 1320;
//$AcademicYear = '2025-2026';

$ForceRegenerate = false;
$AvailableCourseIdx='';
$AcademicYear = '';
if ( isset($_POST['_AVC']) ) $AvailableCourseIdx = filter_var(trim($_POST['_AVC']), FILTER_VALIDATE_INT);
if ( isset($_POST['_AY']) ) $AcademicYear = trim($_POST['_AY']);
if ( isset($_POST['_FORCE']) ) $ForceRegenerate = trim($_POST['_FORCE']);

// Verify that required values are valid
if (!$AvailableCourseIdx || !$AcademicYear) {
    exit('Invalid parameters');
}

require_once(__DIR__ . '/../config.php');
$ASSESSMENT_PDF_PATH = __DIRECTORY_ABETASSESSMENTS__ . "$AcademicYear". DIRECTORY_SEPARATOR ;
$ABETSYLLABUS_PDF_PATH = __DIRECTORY_ABETSYLLABI__ . "$AcademicYear". DIRECTORY_SEPARATOR ;
$COURSESYLLABUS_PDF_PATH = __DIRECTORY_COURSEBI__ . "$AcademicYear". DIRECTORY_SEPARATOR ;
$INSTRUCTIONAL_MATERIALS_PDF_PATH = __DIRECTORY_INSTRUCTIONAL_MATERIALS__ . "$AcademicYear". DIRECTORY_SEPARATOR ;
$COURSEASSESSMENT_SAMPLES_PDF_PATH = __DIRECTORY_COURSEASSIGNMENT_SAMPLES__ . "$AcademicYear". DIRECTORY_SEPARATOR ;
$COURSEBINDER_PDF_PATH = __DIRECTORY_COURSEBINDERS__ . "$AcademicYear". DIRECTORY_SEPARATOR ;

$UNIV_LOGO_PATH = __UNIV_LOGO_PATH__;

$CourseBinderPDF_FileName = 'coursebinder_';

require_once(__DIR__ . '/php_include/listfunc.php');
require_once('./php_include/LatexTemplate.php');
require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();
$data = array();

$BinderUpdated = false;
//----------------------------------------------------------------------------------------
// Fetch Course Info
try
{
    $Query = "CALL SP_CreatePDF_FetchAvailableCourseInfo(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx]);

    if (!$result || $DBCONNECTION->num_rows() === 0) {
        throw new Exception('No course data found');
    }

    $row = $DBCONNECTION->fetch_assoc();

    // Safely get values with null coalescing
    $Semester = $row['Semester'] ?? '';
    $CourseCRN = $row['CRN'] ?? '';
    $CourseSubject = $row['Subject'] ?? '';
    $CourseNum = $row['Num'] ?? '';
    $CourseTitle = $row['Title'] ?? '';
    $CourseCredits = $row['Credits'] ?? '';
    $InstructorName = $row['Instructor'] ?? '';
    $Degree = $row['Degree'] ?? '';
    $BinderUpdated = $row['BinderUpdated'] == '1';

    if ($ForceRegenerate)
        $BinderUpdated = true; // force to regenerate PDF

    // Convert to lowercase once
    $lowercase_values = [
        'degree' => strtolower($Degree),
        'subject' => strtolower($CourseSubject),
        'num' => strtolower($CourseNum),
        'semester' => strtolower($Semester)
    ];

    // Build filenames using consistent pattern
    $filename_parts = [
        'semester' => str_replace(' ', '_', $lowercase_values['semester']),
        'subject' => str_replace(' ', '_', $lowercase_values['subject']),
        'num' => str_replace(' ', '_', $lowercase_values['num']),
        'crn' => 'crn' . str_replace(' ', '_', $CourseCRN)
    ];

    // Create base filename string
    $base_filename = implode('_', $filename_parts);

    // Generate specific filenames
    $CourseBinderPDF_FileName = "{$CourseBinderPDF_FileName}{$base_filename}.pdf";
    $CourseSyllabusPDF_FileName = "syllabus_{$base_filename}.pdf";

    // Generate ABET filename with its specific pattern
    $abet_filename_parts = [
        str_replace(' ', '-', $AcademicYear),
        str_replace(' ', '_', $lowercase_values['degree']),
        str_replace(' ', '_', $lowercase_values['subject']),
        str_replace(' ', '_', $lowercase_values['num'])
    ];
    $AbetSyllabusPDF_FileName = 'abet_syllabus_' . implode('_', $abet_filename_parts) . '.pdf';
    $course_title = trim(sprintf('%s %s %s', $CourseSubject, $CourseNum, $CourseTitle));

    $data = [
        'logo' => $UNIV_LOGO_PATH,
        'assessmentpath' => $ASSESSMENT_PDF_PATH,
        'courseinfo' => $CourseCRN,
        'coursetitle' => LatexTemplate::plainTextToLatex($course_title),
        'coursesemester' => LatexTemplate::replaceSpecialCharacters($Semester),
        'courseCRN' => LatexTemplate::replaceSpecialCharacters($CourseCRN),
        'courseinstructor' => LatexTemplate::plainTextToLatex($InstructorName),
        'coursesyllabus' => $COURSESYLLABUS_PDF_PATH . $CourseSyllabusPDF_FileName,
        'abetcoursesyllabus' => $ABETSYLLABUS_PDF_PATH . $AbetSyllabusPDF_FileName
    ];

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();

    echo "0x00000500";  // other DB error
    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500'
    ]));
    exit;

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
    exit;
}

// previously created course binder can be downloadable.
if ($BinderUpdated === false) {
    $pdf_f = $COURSEBINDER_PDF_PATH . $CourseBinderPDF_FileName;
//    error_log($pdf_f);

    if (file_exists($pdf_f)) {
        if (ob_get_level()) {
            ob_end_clean();
        }

        header('Content-Type: application/pdf');
        header('Content-Length: ' . filesize($pdf_f));
        header('Content-Disposition: attachment; filename="' . $CourseBinderPDF_FileName . '"');
        header('Cache-Control: private, must-revalidate');

        $handle = fopen($pdf_f, 'rb');
        fpassthru($handle);
        fclose($handle);
        exit;
    }
}

//----------------------------------------------------------------------------------------
// Fetch Available Course Instructional Materials
try {
    $Query = "CALL SP_CreatePDF_FetchAvailableCourseIMs(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AvailableCourseIdx
    ]);

    $InstructionalMaterials = [];
    if ($result && $DBCONNECTION->num_rows() > 0) {
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $materialType = $row['MaterialType'] ?? '';

            // Create the array for this material type if it doesn't exist
            if (!isset($InstructionalMaterials[$materialType])) {
                $InstructionalMaterials[$materialType] = [];
            }

            $materialType = LatexTemplate::replaceSpecialCharacters($materialType);

            // instructional_material_2024_fall_apct_341_crn17459_lecture_notes_1.pdf
            $InstructionalMaterials[$materialType][] = [
                'MaterialType' => $materialType,
                'MaterialSample' => $INSTRUCTIONAL_MATERIALS_PDF_PATH . $row['MaterialSample']
            ];
        }
        $data['InstructionalMaterials'] = $InstructionalMaterials;
    }

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();

    echo "0x00000500";  // other DB error
    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500'
    ]));
    exit;
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
    exit;
}


//----------------------------------------------------------------------------------------
// Fetch Available Course Assessment Materials
try {
    $Query = "CALL SP_CreatePDF_FetchAvailableCourseAMs(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [
        $AvailableCourseIdx
    ]);

    $CourseAssessmentMaterials = [];
    if ($result && $DBCONNECTION->num_rows() > 0) {
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $assessmentType = $row['AssmntType'] ?? '';

            // Create the array for this material type if it doesn't exist
            if (!isset($CourseAssessmentMaterials[$assessmentType])) {
                $CourseAssessmentMaterials[$assessmentType] = [];
            }

            $CourseAssessmentMaterials[$assessmentType][] = [
                'AssmntType' => LatexTemplate::replaceSpecialCharacters($assessmentType),
                'AssmntNum' => LatexTemplate::replaceSpecialCharacters($row['AssmntNum'] ?? ''),
                'AssmntSample' => $COURSEASSESSMENT_SAMPLES_PDF_PATH . $row['AssmntSample'],
                'StudentSample1' => ($row['StudentSample1'] === null) ? '' : ($COURSEASSESSMENT_SAMPLES_PDF_PATH . $row['StudentSample1']),
                'StudentSample2' => ($row['StudentSample2'] === null) ? '' : ($COURSEASSESSMENT_SAMPLES_PDF_PATH . $row['StudentSample2']),
                'StudentSample3' => ($row['StudentSample3'] === null) ? '' : ($COURSEASSESSMENT_SAMPLES_PDF_PATH . $row['StudentSample3'])
            ];
        }
        $data['CourseAssessmentMaterials'] = $CourseAssessmentMaterials;
    }
} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();

    echo "0x00000500";  // other DB error
    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500'
    ]));
    exit;
} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
    exit;
}

//if (!isset($data['InstructionalMaterials'])) {
//    echo ('0x4356723');    // Error
//    exit;
//}
//
//if (!isset($data['CourseAssessmentMaterials'])) {
//    echo ('0x4356724');    // Error
//    exit;
//}

if (!isset($data['InstructionalMaterials']) && !isset($data['CourseAssessmentMaterials'])) {
    echo ('0x3234234');    // Error
    exit;
}

try {
    require_once 'php_include/mail_attachment.php';
    require_once('./php_include/LatexTemplate.php');

    LatexTemplate::createToCPDF(
        $data,
        'create_coursebinder_pdf.tex',
        $CourseBinderPDF_FileName, 1/*0:screen / 1:download*/,
        $COURSEBINDER_PDF_PATH  // save the generated pdf into the course binder folder
    );

    $Query = "CALL SP_UpdateCourseBinderCreation(?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($Query, [$AvailableCourseIdx]);

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();

    echo "0x00000500";  // other DB error
    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500'
    ]));
    exit;

} catch(Exception $e) {
    require_once 'php_include/mail_attachment.php';
    NotifyAdminByEmail('Error: Create PDF', $e -> getMessage());

    error_log($e -> getMessage());

    echo ('0x23894723');    // Error
    exit;
}

