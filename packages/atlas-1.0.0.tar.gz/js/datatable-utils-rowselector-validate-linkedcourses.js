// This class requires to have DataTableRowSelector

class DatatableUtilsRowselectorValidateLinkedCourses extends DataTableRowSelector {
    constructor(tableId, options = {}) {
        // Call parent constructor
        super(tableId, {
            ...options,
            // Default validation fields (can be overridden)
            validationFields: {
                semester: 'SemesterTxt',
                studentOutcomes: 'StudentOutcomes',
                performanceIndicators: 'PerformanceIndicators',
                instructor: 'Instructor',
                ...(options.validationFields || {})
            }
        });

        // Bind new methods
        this.validateSelection = this.validateSelection.bind(this);
        this.validateSelectionSilent = this.validateSelectionSilent.bind(this);
        this.handleSelectDeselectWithValidation = this.handleSelectDeselectWithValidation.bind(this);
        this.handleSelectAllWithValidation = this.handleSelectAllWithValidation.bind(this);

        // Flag to prevent validation loops
        this.isValidating = false;
    }

    /**
     * Validates if a new row can be selected based on existing selections
     */
    validateSelection(newRowData, existingSelectedData = null) {
        // Get currently selected rows if not provided
        const currentlySelected = existingSelectedData || this.dataTable.rows({ selected: true }).data().toArray();

        // If no rows selected yet, allow selection
        if (currentlySelected.length === 0) {
            return true;
        }

        // Get first selected row data
        const firstSelectedData = currentlySelected[0];
        const fields = this.options.validationFields;

        // console.log('Validating:', newRowData);
        // console.log('Against:', firstSelectedData);

        // Validation 1: Check Semester
        const firstSemester = (firstSelectedData[fields.semester] || '').trim();
        const newSemester = (newRowData[fields.semester] || '').trim();

        if (firstSemester !== newSemester) {
            Swal.fire({
                title: "SEMESTER MISMATCH",
                html: `All selected courses must be from the same semester.<br><br>
               <strong>Currently selected:</strong> ${firstSemester}<br>
               <strong>Attempting to select:</strong> ${newRowData.Subject} ${newRowData.Num} (${newSemester})<br><br>
               This course will not be selected.`,
                icon: "warning",
                confirmButtonText: 'OK'
            });
            return false;
        }

        // Validation 2: Check Instructor
        const firstInstructor = (firstSelectedData[fields.instructor] || '').trim();
        const newInstructor = (newRowData[fields.instructor] || '').trim();

        if (firstInstructor !== newInstructor) {
            Swal.fire({
                title: "INSTRUCTOR MISMATCH",
                html: `All selected courses must have the same instructor.<br><br>
               <strong>Currently selected:</strong> ${firstInstructor || 'None'}<br>
               <strong>Attempting to select:</strong> ${newRowData.Subject} ${newRowData.Num}<br>
               <strong>Instructor:</strong> ${newInstructor || 'None'}<br><br>
               This course will not be selected.`,
                icon: "warning",
                confirmButtonText: 'OK'
            });
            return false;
        }

        // Validation 3: Check Student Outcomes
        const firstSO = (firstSelectedData[fields.studentOutcomes] || '').trim();
        const newSO = (newRowData[fields.studentOutcomes] || '').trim();

        if (firstSO !== newSO) {
            Swal.fire({
                title: "STUDENT OUTCOMES MISMATCH",
                html: `All selected courses must have the same Student Outcomes.<br><br>
               <strong>Currently selected:</strong> ${firstSO || 'None'}<br>
               <strong>Attempting to select:</strong> ${newRowData.Subject} ${newRowData.Num}<br>
               <strong>Has:</strong> ${newSO || 'None'}<br><br>
               This course will not be selected.`,
                icon: "warning",
                confirmButtonText: 'OK'
            });
            return false;
        }

        // Validation 4: Check Performance Indicators
        const firstPI = (firstSelectedData[fields.performanceIndicators] || '').trim();
        const newPI = (newRowData[fields.performanceIndicators] || '').trim();

        if (firstPI !== newPI) {
            Swal.fire({
                title: "PERFORMANCE INDICATORS MISMATCH",
                html: `All selected courses must have the same Performance Indicators.<br><br>
               <strong>Currently selected:</strong> ${firstPI || 'None'}<br>
               <strong>Attempting to select:</strong> ${newRowData.Subject} ${newRowData.Num}<br>
               <strong>Has:</strong> ${newPI || 'None'}<br><br>
               This course will not be selected.`,
                icon: "warning",
                confirmButtonText: 'OK'
            });
            return false;
        }

        return true;
    }

    /**
     * Validates without showing alerts (for bulk operations)
     */
    validateSelectionSilent(firstRowData, newRowData) {
        const fields = this.options.validationFields;

        const firstSemester = (firstRowData[fields.semester] || '').trim();
        const newSemester = (newRowData[fields.semester] || '').trim();
        if (firstSemester !== newSemester) return false;

        const firstInstructor = (firstRowData[fields.instructor] || '').trim();
        const newInstructor = (newRowData[fields.instructor] || '').trim();
        if (firstInstructor !== newInstructor) return false;

        const firstSO = (firstRowData[fields.studentOutcomes] || '').trim();
        const newSO = (newRowData[fields.studentOutcomes] || '').trim();
        if (firstSO !== newSO) return false;

        const firstPI = (firstRowData[fields.performanceIndicators] || '').trim();
        const newPI = (newRowData[fields.performanceIndicators] || '').trim();
        if (firstPI !== newPI) return false;

        return true;
    }

    /**
     * Override handleSelectDeselect to add validation
     */
    handleSelectDeselectWithValidation(e, dt, type, indexes) {
        // Prevent recursive calls
        if (this.isValidating) return;

        // console.log('Event type:', e.type, 'Type:', type, 'Indexes:', indexes);

        // Only validate on 'select' events for rows
        if (e.type === 'select' && type === 'row') {
            this.isValidating = true;

            // Get all currently selected rows (including the one just selected)
            const allSelected = this.dataTable.rows({ selected: true }).data().toArray();

            // console.log('Total selected:', allSelected.length);
            // console.log('All selected data:', allSelected);

            // If more than one row is selected, validate the newest selection
            if (allSelected.length > 1) {
                // The last item in allSelected should be the newly selected row
                const newRowData = allSelected[allSelected.length - 1];
                const previousSelections = allSelected.slice(0, -1);

                // console.log('New row:', newRowData);
                // console.log('Previous selections:', previousSelections);

                // Validate against the first selected row
                if (!this.validateSelection(newRowData, previousSelections)) {
                    // Validation failed - deselect the row
                    this.dataTable.row(indexes[0]).deselect();
                    this.isValidating = false;
                    this.updateSelectedCount();
                    if (this.showSelectedOnly) {
                        this.dataTable.draw();
                    }
                    return;
                }
            }

            this.isValidating = false;
        }

        // Call parent's handler for updating UI
        this.updateSelectedCount();
        if (this.showSelectedOnly) {
            this.dataTable.draw();
        }
    }

    /**
     * Override select all handler to add validation
     */
    handleSelectAllWithValidation(e) {
        if (!this.dataTable) return;

        const tr = $(e.target).closest("tr");
        const wasSelected = tr.hasClass("selected");
        tr.toggleClass("selected");

        if (!wasSelected) {
            // Selecting all - validate each row
            const currentPageRows = this.dataTable.rows({ page: 'current' });
            const allData = currentPageRows.data().toArray();

            if (allData.length === 0) return;

            // Deselect all first
            this.dataTable.rows().deselect();

            // Select first row
            const firstRowData = allData[0];
            const firstRowNode = currentPageRows.nodes()[0];
            this.dataTable.row(firstRowNode).select();

            let skippedCount = 0;

            // Validate and select remaining rows
            for (let i = 1; i < allData.length; i++) {
                if (this.validateSelectionSilent(firstRowData, allData[i])) {
                    this.dataTable.row(currentPageRows.nodes()[i]).select();
                } else {
                    skippedCount++;
                }
            }

            if (skippedCount > 0) {
                Swal.fire({
                    title: "PARTIAL SELECTION",
                    html: `${skippedCount} course(s) were not selected because they have different:<br>
                 - Semesters<br>
                 - Instructors<br>
                 - Student Outcomes<br>
                 - Performance Indicators<br><br>
                 Only matching courses have been selected.`,
                    icon: "info"
                });
            }
        } else {
            // Deselecting all
            this.dataTable.rows({ page: 'current' }).deselect();
        }

        this.updateSelectedCount();
        if (this.showSelectedOnly) {
            this.dataTable.draw();
        }
    }

    /**
     * Override attachEventHandlers to use validation-enabled handlers
     */
    attachEventHandlers() {
        // Toggle button handler (use parent's)
        $(`#${this.options.toggleButtonId}`).on('click', this.handleToggleSelected);

        // Selection change handler WITH VALIDATION (override)
        $(document).on('select.dt deselect.dt', `#${this.tableId}`, this.handleSelectDeselectWithValidation);

        // Select all handler with validation (override)
        $(`#${this.tableId}`).on('click', '.toggle-all', this.handleSelectAllWithValidation);

        // Page change handler (use parent's)
        this.dataTable.on('page.dt', this.handlePageChange);
    }
}