<?php
/**
 * Duplicate Abet Course
 * Description: duplicating courses' student outcomes, performance indicators, and syllabus.
 * Author: Dong Hyun Jeong
 *
 * 03/30/2021 - initial version created
 * 09/22/2024 - Bug fix - creating duplicated syllabus
 *
 */


include_once 'session_handler.php';


$AcademicYearIdx='';
$JSONData='';
if (array_key_exists('ay', $_POST) && array_key_exists('data', $_POST) )
{
    $AcademicYearIdx = trim($_POST['ay']);
    $JSONData = trim($_POST['data']);
}
else
{
    // unwanted illegal entry
    echo "0x00000000";
    exit;
}

$AcademicProgram = (isset($_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']))?$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']:'';
if ($AcademicYearIdx=="" || $JSONData=="" || $AcademicProgram==""){
    // no required information
    echo "0x00000101";
    exit;
}

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $AcademicYearIdx = filter_var($AcademicYearIdx, FILTER_VALIDATE_INT);
    if ($AcademicYearIdx === false) {
        throw new Exception('Invalid Academic Year format');
    }

    $data = json_decode($JSONData, true);

    $MultiQuery = "";
    // Access the data
    for ($i = 0; $i < count($data); $i++) {

        $tmp_data = trim($data[$i]['course']);
        if (!empty($tmp_data)) {
            $courseInfo = explode(" ", $data[$i]['course']);
            $subject = $courseInfo[0];
            $num = $courseInfo[1];
            $MultiQuery .= "CALL SP_RemoveBatchPIs($AcademicYearIdx, $AcademicProgram, '$subject', '$num');";

            // Using for loop to iterate through outcomes
            for ($j = 0; $j < count($data[$i]['outcomes']); $j++) {
                $outcomeInfo = explode("-", $data[$i]['outcomes'][$j]);
                $so_tmp = $outcomeInfo[0];
                $performance_indicator = $outcomeInfo[1];

                $letters = preg_replace('/[0-9]/', '', $so_tmp); // "SO"
                $numbers = preg_replace('/[^0-9]/', '', $so_tmp); // "1"

                $student_outcome = $letters . ' ' . $numbers;

                $MultiQuery .= "CALL SP_AddBatchPIs($AcademicYearIdx, $AcademicProgram, '$subject', '$num', '$student_outcome', '$performance_indicator');";
            }
        }
    }
//    error_log($MultiQuery);
//    echo ($MultiQuery); exit;
    $DBCONNECTION->sendmultiquery($MultiQuery);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {
    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    echo "0x00000500";  // other DB error
    
    // Log the detailed error information
    error_log(json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'errorCode' => '0x00000500',
        'query' => $MultiQuery
    ]));

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

