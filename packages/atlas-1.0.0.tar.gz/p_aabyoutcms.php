<?php
/**
 * Program Assessment Assignments By Courses
 * File: p_aabycrs.php
 * Description: Listing program assessment assignments by courses.
 *
 * 05/04/2021 - Fix error when displaying assignment & assignment description.
 * 
 */

include('header.php');

?>


<?php
// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection(false);

$SOIdx=null;
if (isset($_POST['_SOIDX'])) {
    $SOIdx = trim($_POST['_SOIDX']); // user changed
}
if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

?>
<script type="text/javascript">

    function fetchassessmentassignments(soidx, ayear)
    {
        let form = document.createElement("form");
        form.method = "POST";
        form.action = "p_aabyoutcms.php";

        let element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=ayear;
        element.name="_AY";
        form.appendChild(element);

        element = document.createElement("input");
        element.setAttribute("type", "hidden");
        element.value=soidx;
        element.name="_SOIDX";
        form.appendChild(element);

        document.body.appendChild(form);
        form.submit();
    }

    $(document).ready(function() {

        // Add event listener to the select element
        $("#_AY").on('change', function() {
            document.academicyear.submit();
        });
    });

</script>
<div class="pagebacklayout">
    <div class="row">
        <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">ASSESSMENT ASSIGNMENTS BY STUDENT OUTCOME</p>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <?php include('control_allprograms.php'); ?>
    </div>

    <div class="pagebacklayout_inner_noborder">
        <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
            <tr>
                <td style="width:30%;">
                    <?php echo($AcademicYearSelection);?>
                </td>
                <td style="width:10%"></td>
                <td style="width:60%; text-align: right">
                </td>
            </tr>
        </table>

        <?php
        $SO_Description = '';

        require_once(__DIR__ . '/php_include/dbconnection_class.php');
        $DBCONNECTION = new Dbconnection();
        $AbetCourseAvailable = false;

        $Query = "SELECT `Idx`, `SO`, `Description` FROM `StudentOutcomes` AS `STNTOUTCMS` WHERE `AcademicProgram`='".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' ";
        if ($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] != "all") $Query .= " AND `AcademicYear`='".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."'";
        $Query .= " ORDER BY `SO`";

        $outcomesList = '';
        $DBCONNECTION->sendquery($Query);
        while ($row = $DBCONNECTION->fetch_assoc())
        {
            $AbetCourseAvailable = true;

            if ($SOIdx == null)
                $SOIdx = $row['Idx'];
            $SO = isset($row['SO']) ? $row['SO'] : 'N/A';
            $Desc = isset($row['Description']) ? $row['Description'] : '';
            $outcomesList .= '<a href="#" class="list-group-item list-group-item-action bg-light';
            if ($SOIdx == $row['Idx']) {
                $outcomesList .= ' active ';
                $SO_Description = "&nbsp;<span style=\"font-size: 12pt;\">$SO - $Desc</span>";    // save selected SO description to be displayed on the top of the page.
            }
            $outcomesList .= '" title="'.$Desc.'" ';
            $outcomesList .= 'onclick="fetchassessmentassignments(\''.$row['Idx'].'\', \''.$_SESSION['ATLAS_SELECTED_ACADEMICYEAR'].'\');">'.$SO.'</a>';
        }

        if ($AbetCourseAvailable == false){
            // Show full-width message when no student outcomes available
            echo <<<HTML
        <div class='col-md-12'>
            <div class="alert alert-info text-center" role="alert" style="padding: 40px; margin: 20px 0;">
                <h4 class="alert-heading">No Student Outcomes Available</h4>
                <p class="mb-0">There are currently no student outcomes available for the selected academic year and program.</p>
                <hr>
                <p class="mb-0">Please select a different academic year or contact your administrator if you believe this is an error.</p>
            </div>
        </div>
HTML;
        } else {
            // Show normal two-column layout when outcomes exist
            echo <<<HTML
        <div class='col-md-2'>
            <!-- Sidebar -->
            <div class="list-group list-group-flush">
                $outcomesList
            </div>
            <!-- /#sidebar-wrapper -->
        </div>

        <div class='col-md-10'>
            <!-- Page Content -->
            <div id="pagebacklayout_inner_noborder">
                <div class="CSSTable_ROUNDEDCORDER">
HTML;

            echo ($SO_Description);

            /////////////////////////////////////////////////////////////////////////////////
            // select abet course assessment information

            $Query = "CALL SP_FetchAbetCourseAssessmentsBySO('$SOIdx', '".$_SESSION['ATLAS_SELECTED_ACADEMICYEAR']."', '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."' )";
            $DBCONNECTION->sendquery($Query);

            $hasData = false;
            $tableContent = '';

            while ($row = $DBCONNECTION->fetch_assoc()) {
                $hasData = true;

                $ABCIdx = isset($row['ABCIdx']) ? $row['ABCIdx'] : '';
                $AVCIdx = isset($row['AVCIdx']) ? $row['AVCIdx'] : '';
                $SO_array = isset($row['SO']) ? explode('|', $row['SO']) : array();
                $Instructor = isset($row['Instructor']) ? $row['Instructor'] : 'N/A';
                $CourseNo = isset($row['CourseNo']) ? $row['CourseNo'] : 'N/A';
                $Title = isset($row['Title']) ? $row['Title'] : 'N/A';
                $Credits = isset($row['Credits']) ? $row['Credits'] : 'N/A';
                $Semester = isset($row['Semester']) ? $row['Semester'] : 'N/A';
                $AssignmentType_array = isset($row['AssignmentType']) ? explode('|', $row['AssignmentType']) : array();

                for ($i = 0; $i < count($SO_array); $i++) {
                    $SO = $SO_array[$i];

                    $tableContent .= <<<HTML
                    <tr style="border-spacing: 3px;">
                        <td style="width:30%;">
                             <p>
                                $CourseNo $Title<br/>
                                Semester: $Semester<br/>
                                Credit Hours: $Credits<br/>
                                Professor: $Instructor
                            </p>
                        </td>
                        <td style="width:70%;">
HTML;
                    $hasAssignments = false;
                    foreach ($AssignmentType_array as $AssignmentType) {
                        $AT_array = explode(':', $AssignmentType);
                        if (count($AT_array) > 1) {
                            if ($SO == $AT_array[0]) // if SO is matched with the SO appeared in the left pane.
                            {
                                $hasAssignments = true;
                                $Assignment = isset($AT_array[2]) ? $AT_array[2] : '';
                                $Assignment_Description = isset($AT_array[3]) ? $AT_array[3] : '';
                                $tableContent .= '<p><b>' . $Assignment . '</b><br/> ' . $Assignment_Description . '</p>';
                            }
                        }
                    }

                    if (!$hasAssignments) {
                        $tableContent .= '<p><em>No assessment assignments available</em></p>';
                    }

                    $tableContent .= '</td>';
                    $tableContent .= '</tr>';
                }
            }

            if (!$hasData) {
                echo <<<HTML
                    <div class="alert alert-warning text-center" role="alert" style="padding: 30px; margin: 20px 0;">
                        <h4 class="alert-heading">No Assessment Assignment Data Available</h4>
                        <p class="mb-0">There are no assessment assignments for the selected student outcome and academic year.</p>
                    </div>
HTML;
            } else {
                echo <<<HTML
                    <table class="display">
HTML;
                echo $tableContent;
                echo <<<HTML
                    </table>
HTML;
            }

            echo <<<HTML
                </div>
            </div>
            <!-- /#page-content-wrapper -->
        </div>
HTML;
        }

        unset($DBCONNECTION);
        ?>

    </div>
</div>

<?php include('footer.php');?>

