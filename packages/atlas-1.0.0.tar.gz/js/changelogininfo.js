/**
 * Change Login Information
 * Description: Reset login information
 * Author: Dong Hyun Jeong
 *
 * 06/30/2021 - initial version created
 */


// Function to send an update request via AJAX
function UpdateInfo(OPWD, NPWD) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "changelogininfo_save.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                const response = xhr.responseText.trim();
                switch (response) {
                    case "0x00201000":
                        Swal.fire({
                            title: "ERROR",
                            text: "Current password does not match!",
                            icon: "error"
                        }).then(() => {
                            passwordchange(OPWD, NPWD);
                        });
                        break;
                    case "0x11111111":
                        Swal.fire({
                            title: "Updated!",
                            html: "Password has been updated successfully!! Please log in again!!",
                            icon: "success"
                        }).then(() => {
                            window.location.href = "index.php";
                        });
                        break;
                    default:
                        Swal.fire({
                            title: "ERROR",
                            text: "Unexpected error occurred. Please contact the system administrator!",
                            icon: "error"
                        });
                        break;
                }
            } else {
                Swal.fire({
                    title: "ERROR",
                    text: "Network error. Please try again later.",
                    icon: "error"
                });
            }
        }
    };

    const params = new URLSearchParams({
        _OPWD: OPWD,
        _NPWD: NPWD
    }).toString();

    xhr.send(params);
}

// Function to validate password input
function CheckValidation() {
    const form = document.passwordchagnefrm;
    const oldPassword = form.oldpassword.value.trim();
    const newPassword = form.newpassword.value.trim();
    const confirmPassword = form.newpasswordagain.value.trim();

    if (!oldPassword) {
        form.oldpassword.focus();
        Swal.fire({
            title: "ERROR",
            html: "<h5>Current password is not entered!!</h5>",
            icon: "error"
        });
        return false;
    }

    if (!newPassword) {
        form.newpassword.focus();
        Swal.fire({
            title: "ERROR",
            html: "<h5>New password is not entered!!</h5>",
            icon: "error"
        });
        return false;
    }

    if (!confirmPassword) {
        form.newpasswordagain.focus();
        Swal.fire({
            title: "ERROR",
            html: "<h5>Re-enter new password!!</h5>",
            icon: "error"
        });
        return false;
    }

    if (newPassword !== confirmPassword) {
        form.newpasswordagain.focus();
        Swal.fire({
            title: "ERROR",
            html: "<h5>New password and re-entered password do not match!!</h5>",
            icon: "error"
        });
        return false;
    }

    return true;
}

// Function to display the password change dialog
function passwordchange(oldpassword = '', newpassword = '') {
    const content = `
    <form name="passwordchagnefrm" id="passwordchagnefrm">
        <table width="100%" cellspacing="0" cellpadding="0" border="0" style="font-size:10pt;">
            <tr style="height:25px;">
                <td style="text-align:right;"><span style="color:red;">*</span>YOUR CURRENT PASSWORD:&nbsp;</td>
                <td align="left">
                    <input id="oldpassword" name="oldpassword" type="password" placeholder="password" autocomplete="off"
                        style="width:250px;font-size:10pt;border-style:solid;border-width:1px;" />
                </td>
            </tr>
            <tr style="height:25px;">
                <td style="text-align:right;"><span style="color:red;">*</span>CHOOSE A NEW PASSWORD:&nbsp;</td>
                <td align="left">
                    <input id="newpassword" name="newpassword" type="password" placeholder="newpassword"
                        style="width:250px;font-size:10pt;border-style:solid;border-width:1px;" />
                </td>
            </tr>
            <tr style="height:25px;">
                <td style="text-align:right;"><span style="color:red;">*</span>RE-ENTER NEW PASSWORD:&nbsp;</td>
                <td align="left">
                    <input id="newpasswordagain" name="newpasswordagain" type="password" placeholder="newpasswordagain"
                        style="width:250px;font-size:10pt;border-style:solid;border-width:1px;" />
                </td>
            </tr>
        </table>
    </form>`;

    createModalDialog({
        title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">CHANGE PASSWORD</span>',
        message: content,
        onEscape: true,
        buttons: {
            ok: {
                label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;CHANGE",
                className: 'btn-success',
                callback: function () {
                    if (!CheckValidation()) {
                        return false;
                    }

                    const form = document.passwordchagnefrm;
                    UpdateInfo(form.oldpassword.value.trim(), form.newpassword.value.trim());
                    return true; // Close dialog
                }
            },
            cancel: {
                label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CANCEL",
                className: 'btn-default'
            }
        }
    }).on('shown.bs.modal', function () {
        document.getElementById("oldpassword").focus();
    });
}


// Function to display the password change dialogF
function passwordreset(oldpassword = '', newpassword = '') {
    const content = `
    <form name="passwordchagnefrm" id="passwordchagnefrm">
        <table width="100%" cellspacing="0" cellpadding="0" border="0" style="font-size:10pt;">
            <tr style="height:25px;">
                <td style="text-align:right;"><span style="color:red;">*</span>YOUR TEMPORARY PASSWORD:&nbsp;</td>
                <td align="left">
                    <input id="oldpassword" name="oldpassword" type="password" placeholder="password" autocomplete="off"
                        style="width:250px;font-size:10pt;border-style:solid;border-width:1px;" />
                </td>
            </tr>
            <tr style="height:25px;">
                <td style="text-align:right;"><span style="color:red;">*</span>CHOOSE A NEW PASSWORD:&nbsp;</td>
                <td align="left">
                    <input id="newpassword" name="newpassword" type="password" placeholder="newpassword"
                        style="width:250px;font-size:10pt;border-style:solid;border-width:1px;" />
                </td>
            </tr>
            <tr style="height:25px;">
                <td style="text-align:right;"><span style="color:red;">*</span>RE-ENTER NEW PASSWORD:&nbsp;</td>
                <td align="left">
                    <input id="newpasswordagain" name="newpasswordagain" type="password" placeholder="newpasswordagain"
                        style="width:250px;font-size:10pt;border-style:solid;border-width:1px;" />
                </td>
            </tr>
        </table>
    </form>`;

    createModalDialog({
        title: '<span class="glyphicon glyphicon-edit" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">CREATE NEW PASSWORD</span>',
        message: content,
        backdrop: 'static',  // Prevent closing by clicking outside
        keyboard: false,     // Prevent closing with ESC key
        closeButton: false,  // Remove the X close button
        onEscape: false,     // Disable ESC key
        buttons: {
            ok: {
                label: "<span class='glyphicon glyphicon-ok'></span>&nbsp;CHANGE",
                className: 'btn-success',
                callback: function () {
                    if (!CheckValidation()) {
                        return false;
                    }

                    const form = document.passwordchagnefrm;
                    UpdateInfo(form.oldpassword.value.trim(), form.newpassword.value.trim());
                    return true; // Close dialog
                }
            }
            // Removed the cancel button
        }
    }).on('shown.bs.modal', function () {
        document.getElementById("oldpassword").focus();
    });
}