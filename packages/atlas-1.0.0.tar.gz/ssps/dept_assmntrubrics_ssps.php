<?php
/**
 * Listing assessment rubrics
 * File: dept_assmntrubrics_ssps.php
 * Description: listing assessment rubrics
 *
 *
 * 10/08/2024 -- Adding revision comments and approval info
 */
include_once 'session_handler.php';


$AcademicYear='';
if (array_key_exists('_AY', $_GET)) {
    $AcademicYear = trim($_GET['_AY']);
    $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'] = $AcademicYear;
}

// DB table to use
$table = 'AssessmentMasterRubrics';
$joinQuery = "FROM `{$table}` AS `AR` INNER JOIN `AcademicYears` AS `AYS` ON (`AR`.`AcademicYear`=`AYS`.`Idx`) INNER JOIN `AcademicPrograms` AS `AP` ON (`AR`.`AcademicProgram` = `AP`.`Idx`) LEFT JOIN `GeneralPerformanceIndicators` AS `GPI` ON (`GPI`.`Idx` = `AR`.`GPIIdx`) LEFT JOIN `StudentOutcomes` AS `SO` ON (`SO`.`Idx` = `GPI`.`SOIdx`)";

// Table's primary key
$primaryKey = '`AR`.`Idx`';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes + the primary key column for the id
$columns = array(
    array('db' => '`AR`.`Idx`', 'dt' => 'DT_RowId', 'field' => 'DT_RowId', 'as' => 'DT_RowId', 'formatter' => function( $d, $row ) {
        // Technically a DOM id cannot start with an integer, so we prefix
        // a string. This can also be useful if you have multiple tables
        // to ensure that the id is unique with a different prefix
        return 'row_'.$row[0];
    }
    ),
    array( 'db' => '`AR`.`Idx`', 'dt' => 'Idx', 'field' => 'Idx', 'as' => 'Idx'),
    array( 'db' => '`AR`.`AcademicYear`', 'dt' => 'AcademicYear', 'field' => 'AcademicYear', 'as' => 'AcademicYear'),
    array( 'db' => '`AYS`.`AcademicYear`', 'dt' => 'AcademicYearInfo', 'field' => 'AcademicYearInfo', 'as' => 'AcademicYearInfo'),
    array( 'db' => '`AR`.`GPIIdx`', 'dt' => 'GPIIdx', 'field' => 'GPIIdx', 'as' => 'GPIIdx'),
    array( 'db' => '`GPI`.`GPI`', 'dt' => 'GPI', 'field' => 'GPI', 'as' => 'GPI'),
    array( 'db' => '`SO`.`SO`', 'dt' => 'SO', 'field' => 'SO', 'as' => 'SO'),
    array( 'db' => '`AR`.`LevelofAttainment`', 'dt' => 'LOA', 'field' => 'LOA', 'as' => 'LOA'),
    array( 'db' => 'CONCAT_WS(\'-\',`SO`.`SO`, `GPI`.`GPI`, `AR`.`LevelofAttainment`)', 'dt' => 'LOATXT', 'field' => 'LOATXT', 'as' => 'LOATXT'),
    array( 'db' => '`AR`.`Description`', 'dt' => 'Description', 'field' => 'Description', 'as' => 'Description'),
    array( 'db' => '`AR`.`Comments`', 'dt' => 'Comments', 'field' => 'Comments', 'as' => 'Comments'),
    array( 'db' => '`AR`.`Approval`', 'dt' => 'Approval', 'field' => 'Approval', 'as' => 'Approval'),
    array( 'db' => '`AR`.`TobeRemoved`', 'dt' => 'TobeRemoved', 'field' => 'TobeRemoved', 'as' => 'TobeRemoved'),
    array( 'db' => '`AR`.`AcademicProgram`', 'dt' => 'AcademicProgram', 'field' => 'AcademicProgram', 'as' => 'AcademicProgram')
);

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
require( 'ssp.join.class.php' );

$extraWhere = "`AR`.`AcademicProgram` = '".$_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']."'";

if ($AcademicYear != "" && $AcademicYear != "all") $extraWhere .= " AND `AR`.`AcademicYear`='".$AcademicYear."'";

require_once(__DIR__ . '/../php_include/dbconnection.php');
echo json_encode(
    SSP::joinquery( $_GET, getSqlConnAttributes(), $table, $primaryKey, $columns, $joinQuery, $extraWhere)
);

