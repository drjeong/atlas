<?php
/**
 * Create Course Assessment Master Rubrics Difference PDF file
 * Description: It requires latex to be installed on the server.
 *      Check necessary components in LatexTemplate.php under php_include
 * Author: Dong Hyun Jeong
 *
 * 10/25/2024 - initial version created
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'checker_sessiontimeout.php';


$_AY1 = '';
$_AY2 = '';

if (array_key_exists('_AY1', $_GET)
    && array_key_exists('_AY2', $_GET) )
{
    $_AY1 = trim($_GET['_AY1']);
    $_AY2 = trim($_GET['_AY2']);
}
else {
    // illegal entry
    exit;
}


require_once ('./php_include/dbconnection_class.php');
$DBCONNECTION = new Dbconnection();
$Data= array();

//----------------------------------------------------------------------------------------
// Initialize variables with default empty string
$data = null;

// Fetching abet syllabus information for different versions
$results = $DBCONNECTION->callStoredProcedure('SP_FetchAssmntRubrics_DiffInfo', [$_AY1, $_AY2, $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM']]);

// Check if results are returned
$data = null;
$_AY1Text = '';
$_AY2Text = '';
$AcademicProgramText = '';
if ($results) {
    // Fetch and display the results
    while ($row = $results->fetch_assoc()) {
        $data[] = $row;
        if ($_AY1Text == ''){
            $_AY1Text = $row['AcademicYear_1'];
            $_AY2Text = $row['AcademicYear_2'];
            $AcademicProgramText = $row['Name'] . " (".$row['Degree'].")";
        }
    }
}

//print_r($data);
//exit;

$AcademicProgramText_Tmp = $AcademicProgramText;
$AcademicProgramText_Tmp = str_replace(" ","_",strtolower($AcademicProgramText_Tmp));
$AcademicProgramText_Tmp = str_replace("(","_",strtolower($AcademicProgramText_Tmp));
$AcademicProgramText_Tmp = str_replace(")","_",strtolower($AcademicProgramText_Tmp));

$PDF_FileName = 'abet_mr';
$PDF_FileName .= '_'. $AcademicProgramText_Tmp;
$PDF_FileName .= '_'. str_replace(" ","_",strtolower($_AY1Text));
$PDF_FileName .= '_'. str_replace(" ","_",strtolower($_AY2Text));
$PDF_FileName .= '_diff.pdf';

$data['logo'] = __UNIV_COLLEGE_LOGO_PATH__;
$data['academicyear1'] = $_AY1Text;
$data['academicyear2'] = $_AY2Text;
$data['AcademicProgramText'] = $AcademicProgramText;

require_once(__DIR__ . '/php_include/listfunc.php');

try {
    require_once(__DIR__ . '/php_include/mail_attachment.php');
    require_once(__DIR__ . '/php_include/LatexTemplate.php');

    foreach ($data as $key => &$row) {
        // Check if the current element is a performance indicators by verifying the presence of 'SO'
        if (!is_array($row) || !isset($row['SO'])) {
            continue;
        }
        $row['Comments_1'] = LatexTemplate::replaceSpecialCharacters(html_entity_decode($row['Comments_1']));
        $row['Comments_2'] = LatexTemplate::replaceSpecialCharacters(html_entity_decode($row['Comments_2']));
        $row['Approval_1'] = LatexTemplate::replaceSpecialCharacters(html_entity_decode($row['Approval_1']));
        $row['Approval_2'] = LatexTemplate::replaceSpecialCharacters(html_entity_decode($row['Approval_2']));
        $row['Description_1'] = html_entity_decode($row['Description_1']);
        $row['Description_2'] = html_entity_decode($row['Description_2']);

        if ($row['TobeRemoved_1'] == 1 || $row['TobeRemoved_2'] == 1) {
            if ($row['TobeRemoved_1'] == 1) {
                $row['Description_1'] = '\fcolorbox{yellow}{yellow}{\parbox{\linewidth}{\sout{' . $row['Description_1'] . '}}}';
            }
            if ($row['TobeRemoved_2'] == 1) {
                $row['Description_2'] = '\fcolorbox{yellow}{yellow}{\parbox{\linewidth}{\sout{' . $row['Description_2'] . '}}}';
            }
        } else {
            list($row['Description_1'], $row['Description_2']) = highlightDifferencesLatex($row['Description_1'], $row['Description_2']);
        }

    }
//    print_r($data);exit;

    LatexTemplate::createPDF($data, 'create_assmntrubrics_diff_pdf.tex', $PDF_FileName, 1/*0:screen / 1:download*/);

} catch(Exception $e) {
//    require_once 'php_include/mail_attachment.php';
//    NotifyAdminByEmail('Error: Create MASTER Syllabus PDF', $e -> getMessage());
//
//    error_log($e -> getMessage());
    echo $e -> getMessage();
    echo ('0x23894723');    // Error
    exit;
}


