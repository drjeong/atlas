<?php
/**
 * Management of Syllabus of Master Courses
 * Description: Linking the selected syllabus to another one.
 * Author: Dong Hyun Jeong
 *
 * 01/02/2025 - initial version created
 *
 */

include_once 'session_handler.php';

$TargetSyllabusIndex = (isset($_POST['id'])) ? trim($_POST['id']) : '';
$SelectedSyllabusIndex = (isset($_POST['as'])) ? trim($_POST['as']) : '';

if ($TargetSyllabusIndex==='' || $SelectedSyllabusIndex==='') { echo "0x00000011"; exit; }

//--------------------------------- DB PROCESS ------------------------------------------------------
try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Validate inputs
    $TargetSyllabusIndex = filter_var($TargetSyllabusIndex, FILTER_VALIDATE_INT);
    if ($TargetSyllabusIndex === false) {
        throw new Exception('Invalid Index format');
    }
    $SelectedSyllabusIndex = filter_var($SelectedSyllabusIndex, FILTER_VALIDATE_INT);
    if ($SelectedSyllabusIndex === false) {
        throw new Exception('Invalid Index format');
    }

    /////////////////////////////////////////////////////////////////////////////////
    // insert PI
    $query = "CALL SP_CopySyllabusInfo(?, ?);";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$TargetSyllabusIndex, $SelectedSyllabusIndex]);

    echo "0x11111111";

} catch (mysqli_sql_exception $e) {

    // Check the error message for specific error codes
    $errorMessage = $e->getMessage();
    if (strpos($errorMessage, '0x00300011') !== false) {
        echo '0x00300011';  // item not found
    }
    else {
        echo "0x00000500";  // other DB error
        // Log the detailed error information
        error_log(json_encode([
            'success' => false,
            'error' => $e->getMessage(),
            'errorCode' => '0x00000500'
        ]));
    }

} catch (Exception $e) {
    error_log($e->getMessage()); //Boring error messages from anything else!
    echo "0x00000000";
}

