<?php
/**
 * Management of Available Courses
 * Description: managing available courses
 * Author: Dong Hyun Jeong
 *
 * 02/21/2022 - initial version created
 * 03/28/2024 - disable all courses selection
 */

//include('checker_programdirector.php');
include('header.php');

include_once ('./php_include/semester_helpers.php');
require_once(__DIR__ . '/../config.php');

// fetch academic year selection
require_once('inc_academicsemester_selection.php');
$Semester = getTodaysBannerSemesterCode();
$AcademicSemesterSelection = AcademicSemesterSelection($Semester);

// Fetch academic program data and Convert to JSON for JavaScript
include('inc_academicprograminfo_data.php');
$AcademicProgramsJSON = json_encode(AcademicProgramSelection());
//echo ($Semester);
?>

<script src="js/datatable-utils-search.min.js"></script>
<script src="js/datatable-utils-rowselector.min.js?v=0.0.001"></script>
<script src="js/datatable-utils-columnvisibility.min.js?v=0.0.004"></script>

<script src="/toolbox/ckeditor_4.4.5_full/ckeditor.js"></script>

<script type="text/javascript">
    // Constants
    const ErrorCodes = {
        SUCCESS: '0x11111111',
        CANNOT_CONNECT_SERVER: '0x00041000',
        INFORMATION_NOT_FOUND: '0x00061000',
        INCORRECT_OPERATION: '0x00000102'
    };
</script>

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
?>
<script type="text/javascript">
<?php
if (__COURSE_LISTING_METHOD__ === 'BANNER9') {
?>
    async function FetchAvailableCourses_Perform(p_term, p_text) {
        try {
            const result = await async_commons.makeApiCall('m_avcourses_fetch_parsecourses.php', {
                p_term: p_term,
                p_text: p_text
            }, true);

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable();
                    await async_commons.showSuccessMessage_reloadPage('UPDATED', 'All available courses are fetched successfully!', 2000, true);
                    break;
                }
                case ErrorCodes.CANNOT_CONNECT_SERVER: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `Cannot connect to the server!`
                    );
                    break;
                }
                case ErrorCodes.INFORMATION_NOT_FOUND: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `Information not found on the server!`
                    );
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    function FetchAvailableCourses()
    {
        // ====================================================================
        // FETCH SUBJECT LIST FROM SERVER
        // ====================================================================

        // First, fetch the subject list from the database via AJAX
        $.ajax({
            url: 'm_avcourses_get_subject_list.php',  // PHP file that returns the subject list
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                // Check if we got a valid response
                if (response.success && response.subjectList) {
                    // Display the modal with the subject list
                    showFetchCoursesDialog(response.subjectList);
                } else {
                    // Error fetching subject list
                    Swal.fire({
                        title: "ERROR",
                        text: "Unable to load subject list. Please try again later.",
                        icon: "error"
                    });
                }
            },
            error: function() {
                // AJAX request failed
                Swal.fire({
                    title: "ERROR",
                    text: "Unable to connect to the databse server. Please try again later.",
                    icon: "error"
                });
            }
        });
    }

    /**
     * Display the fetch courses dialog with subject list notification
     *
     * @param {string} subjectList - Comma-separated list of subject names
     */
    function showFetchCoursesDialog(subjectList)
    {
        // Format the subject list for display (replace commas with better formatting)
        const subjectListFormatted = subjectList.replace(/,/g, ', ');

        const formContent = `
        <form name="popupfrm" id="popupfrm">
            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                <tr>
                    <td colspan="2">
                        <div style="font-size:10pt; margin-bottom:15px;">
                            By clicking the "UPDATE" button below, it fetches all available courses
                            in the selected semester automatically.
                        </div>

                        <!-- NOTIFICATION MESSAGE ABOUT SUBJECT FILTERING -->
                        <div style="background-color:#FFF9E6; border:1px solid #FFD700; border-radius:4px; padding:12px; margin-bottom:15px;">
                            <div style="font-size:10pt; color:#856404;">
                                <span class="glyphicon glyphicon-info-sign" style="color:#FFD700; margin-right:8px;"></span>
                                <strong>Note:</strong> Only courses from the following subject areas will be fetched:<br>
                                <div style="margin-top:8px; margin-left:24px; font-style:italic;">
                                    ${subjectListFormatted}
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="text-align:right; vertical-align:middle;">
                        <span style="font-size:10pt;">SEMESTER&nbsp;:&nbsp;</span>
                    </td>
                    <td>
                        <select name="p_term" id="termSelect" style="width:420px;font-size:10pt;">
                            <?php include('m_avcourses_semesterinfo.php');?>
                        </select>
                    </td>
                </tr>
            </table>
        </form>
    `;

        createModalDialog({
            title: `
            <span class="glyphicon glyphicon-download" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>
            <span style="font-size:16pt;font-weight:bold;">FETCH &amp; UPDATE AVAILABLE COURSES</span>
        `,
            message: formContent,
            buttons: {
                ok: {
                    label: '<span class="glyphicon glyphicon-ok"></span>&nbsp;FETCH & UPDATE',
                    className: 'btn-success',
                    callback: function(){
                        // Get selected semester value
                        const selectedTerm = popupfrm.p_term.value;
                        const termSelect = document.getElementById('termSelect');
                        const selectedText = termSelect.options[termSelect.selectedIndex].text.replace(/\s*\(View Only\)\s*/g, '').trim();

                        // Check for server connection error
                        if (selectedTerm === "0x00000000") {
                            Swal.fire({
                                title: "ERROR",
                                text: "Unable to connect to the server. Please try again later.",
                                icon: "error"
                            });
                            return false;
                        }

                        // Validate semester selection
                        if (!selectedTerm) {
                            Swal.fire({
                                title: "ERROR",
                                text: "Please select a semester.",
                                icon: "error"
                            });
                            return false;
                        }

                        // Proceed with fetching courses
                        FetchAvailableCourses_Perform(selectedTerm, selectedText);
                    }
                },
                cancel: {
                    label: '<span class="glyphicon glyphicon-remove"></span>&nbsp;CANCEL',
                    className: 'btn-default',
                    callback: function(){
                        // User cancelled - no action needed
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            // Modal is now visible
        });
    }
<?php
} else { // Manual course listing - no fetch functionality needed

}
?>

</script>
<?php
}
?>

<script>
    // Global DataTable variables
    var DataTable_AvailableCourseList;
    var DataTable_ClassRosterList;
    var rowSelector_DataTable_ClassRosterList;
    var AcademicPrograms = <?php echo $AcademicProgramsJSON; ?>;

    // Function to parse CSV content
    function parseCSV(csvText) {
        const lines = [];
        let currentLine = '';
        let inQuotes = false;

        // Parse the CSV respecting quoted fields
        for (let i = 0; i < csvText.length; i++) {
            const char = csvText[i];
            const nextChar = csvText[i + 1];

            if (char === '"') {
                if (inQuotes && nextChar === '"') {
                    // Escaped quote
                    currentLine += '"';
                    i++; // Skip next quote
                } else {
                    // Toggle quote state
                    inQuotes = !inQuotes;
                }
            } else if (char === '\n' && !inQuotes) {
                // End of line
                if (currentLine.trim()) {
                    lines.push(currentLine);
                }
                currentLine = '';
            } else {
                currentLine += char;
            }
        }

        // Add last line if exists
        if (currentLine.trim()) {
            lines.push(currentLine);
        }

        return lines;
    }

    // Function to parse a single CSV line into fields
    function parseCSVLine(line) {
        const fields = [];
        let currentField = '';
        let inQuotes = false;

        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            const nextChar = line[i + 1];

            if (char === '"') {
                if (inQuotes && nextChar === '"') {
                    // Escaped quote
                    currentField += '"';
                    i++; // Skip next quote
                } else {
                    // Toggle quote state
                    inQuotes = !inQuotes;
                }
            } else if (char === ',' && !inQuotes) {
                // Field separator
                fields.push(currentField.trim());
                currentField = '';
            } else {
                currentField += char;
            }
        }

        // Add last field
        fields.push(currentField.trim());

        return fields;
    }

    // Function to extract Name and Major from CSV
    async function extractStudentData(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = function(e) {
                try {
                    const csvText = e.target.result;
                    const lines = csvText.split('\n').filter(line => line.trim());

                    // Find the header row (the one with "Name" and "Major" in any columns)
                    let headerIndex = -1;
                    let headers = [];
                    let nameIndex = -1;
                    let majorIndex = -1;

                    for (let i = 0; i < lines.length; i++) {
                        const fields = parseCSVLine(lines[i]);

                        // Check if this line contains both "Name" and "Major" headers (case-insensitive)
                        const tempNameIndex = fields.findIndex(field =>
                            field.trim().toLowerCase() === 'name'
                        );
                        const tempMajorIndex = fields.findIndex(field =>
                            field.trim().toLowerCase() === 'major'
                        );

                        if (tempNameIndex !== -1 && tempMajorIndex !== -1) {
                            headerIndex = i;
                            headers = fields;
                            nameIndex = tempNameIndex;
                            majorIndex = tempMajorIndex;
                            break;
                        }
                    }

                    if (headerIndex === -1) {
                        const error = new Error('CSV header row not found. Expected columns: "Name" and "Major"');
                        error.code = '0x0000';
                        reject(error);
                        return;
                    }

                    // Extract student data
                    const students = [];
                    for (let i = headerIndex + 1; i < lines.length; i++) {
                        const fields = parseCSVLine(lines[i]);

                        // Ensure the row has enough columns and name is not empty
                        if (fields.length > Math.max(nameIndex, majorIndex) &&
                            fields[nameIndex] &&
                            fields[nameIndex].trim()) {

                            const name = fields[nameIndex].trim();
                            const major = fields[majorIndex] ? fields[majorIndex].trim() : '';

                            // Find matching academic program using the fuzzy matching function
                            const academicMatch = major ? findAcademicProgram(major) : null;

                            students.push({
                                name: name,
                                major: major,
                                academicProgramIdx: academicMatch ? academicMatch.Idx : null,
                                academicProgram: academicMatch ? academicMatch.AcademicProgram : null,
                                degree: academicMatch ? academicMatch.AcademicDegree : null
                            });
                        }
                    }

                    if (students.length === 0) {
                        const error = new Error('No valid student data found in CSV file');
                        error.code = '0x0001';
                        reject(error);
                        return;
                    }

                    resolve(students);
                } catch (error) {
                    // Add error code if not already present
                    if (!error.code) {
                        error.code = '0x0002';
                    }
                    reject(error);
                }
            };

            reader.onerror = function() {
                const error = new Error('Failed to read file');
                error.code = '0x0003';
                reject(error);
            };

            reader.readAsText(file);
        });
    }

    async function DropUndropStudentsFromRoster(avcIdx, studentNos, operation) {
        try {
            const result = await async_commons.makeApiCall('m_avcourses_classroster_operations_ajax.php', {
                action: operation,
                avcIdx: avcIdx,
                studentNos: studentNos
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    rowSelector_DataTable_ClassRosterList.clearAllSelections();
                    await async_commons.reloadDataTable(DataTable_ClassRosterList);
                    await async_commons.showSuccessMessage_reloadPage('SUCCESS', 'Class roster information has been changed successfully!', 2000, false);
                    break;
                }
                case ErrorCodes.CANNOT_CONNECT_SERVER: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `Cannot connect to the server!`
                    );
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    async function removeStudentsFromRoster(avcIdx) {
        try {
            const result = await async_commons.makeApiCall('m_avcourses_classroster_remove_ajax.php', {
                avcIdx: avcIdx
            });

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.reloadDataTable(DataTable_ClassRosterList);
                    await async_commons.showSuccessMessage_reloadPage('REMOVED', 'All students have been removed from the roster.', 2000, false);
                    break;
                }
                case ErrorCodes.CANNOT_CONNECT_SERVER: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `Cannot connect to the server!`
                    );
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            await async_commons.handleError(error);
        }
    }

    // Add this new function after the updateClassRoster function
    async function updateEnrollmentCount(avcIdx, currentEnrollment) {
        const formContent = `
        <form name="enrollmentForm" id="enrollmentForm" onsubmit="return false;">
            <div style="margin-bottom: 20px;">
                <div class="input-group" style="width:100%;">
                    <span class="input-group-addon" style="width:200px;">Current Enrollment Count</span>
                    <input type="text" class="input-sm form-control" value="${currentEnrollment}" readonly style="background-color: #f5f5f5;">
                </div>
            </div>
            <div style="margin-bottom: 20px;">
                <div class="input-group" style="width:100%;">
                    <span class="input-group-addon" style="width:200px;">New Enrollment Count<span style="color:red">*</span></span>
                    <input type="number" name="newEnrollment" id="newEnrollment" class="input-sm form-control" min="0" value="${currentEnrollment}" required>
                </div>
                <div style="margin-top: 10px; padding: 10px; background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 4px;">
                    <small><strong>Note:</strong> This will update the actual enrollment count for this course. Make sure the number is accurate.</small>
                </div>
            </div>
        </form>
    `;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-edit" style="font-size:16pt;color:#C9DAE1;"></span>&nbsp;<span style="font-size:14pt;font-weight: bold;">EDIT ENROLLMENT COUNT</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> UPDATE",
                    className: 'btn-success',
                    callback: function(){
                        const newEnrollment = parseInt(enrollmentForm.newEnrollment.value);

                        if (isNaN(newEnrollment) || newEnrollment < 0) {
                            Swal.fire({
                                title: "ERROR",
                                text: "Please enter a valid enrollment count (0 or greater)!",
                                icon: "error"
                            });
                            return false;
                        }

                        if (newEnrollment === currentEnrollment) {
                            Swal.fire({
                                title: "No Changes",
                                text: "The enrollment count is the same as before.",
                                icon: "info"
                            });
                            return false;
                        }

                        // Confirm the update
                        Swal.fire({
                            title: 'Confirm Update',
                            html: `Are you sure you want to update the enrollment count from <strong>${currentEnrollment}</strong> to <strong>${newEnrollment}</strong>?`,
                            icon: 'question',
                            showCancelButton: true,
                            confirmButtonColor: '#28a745',
                            cancelButtonColor: '#6c757d',
                            confirmButtonText: 'Yes, update it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                saveEnrollmentCount(avcIdx, newEnrollment);
                            }
                        });

                        return false;
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal', function(){
            $('#newEnrollment').focus().select();
        });
    }

    // Add this new function to save the enrollment count
    async function saveEnrollmentCount(avcIdx, newEnrollment) {
        try {
            showFullPageSpinner();

            const result = await async_commons.makeApiCall('m_avcourses_update_enrollment_ajax.php', {
                avcIdx: avcIdx,
                enrollment: newEnrollment
            });

            hideFullPageSpinner();

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    await async_commons.showSuccessMessage('SUCCESS', 'Enrollment count updated successfully!');

                    // Reload the main DataTable to reflect changes
                    if (typeof DataTable_Courses !== 'undefined') {
                        await async_commons.reloadDataTable(DataTable_Courses);
                    }

                    // Reload class roster if it's open
                    if (typeof DataTable_ClassRosterList !== 'undefined') {
                        await async_commons.reloadDataTable(DataTable_ClassRosterList);
                    }

                    break;
                }
                case ErrorCodes.CANNOT_CONNECT_SERVER: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `Cannot connect to the server!`
                    );
                    break;
                }
                case '0x00000001': {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `Invalid parameters provided!`
                    );
                    break;
                }
                default: {
                    throw new Error('Unexpected server response: ' + code);
                }
            }
        } catch (error) {
            hideFullPageSpinner();
            await async_commons.handleError(error);
        }
    }

    function updateClassRoster(avcIdx, enrollment, crsinfo)
    {
        const formContent =
            `<form name="popupfrm" id="popupfrm" onsubmit="return false;">
        <style>
            .dropped-student {
                background-color: #ffebee !important;
                color: #999 !important;
                text-decoration: line-through;
            }
            .dropped-student:hover {
                background-color: #ffcdd2 !important;
            }
            .new-student {
                background-color: #e8f5e9 !important;
            }
            .new-student:hover {
                background-color: #c8e6c9 !important;
            }
            .hidden-roster-button {
                display: none !important;
            }
        </style>
        <div class="CSSTable_SSPSLIST" style="min-height:370px;">
            <table id="classrosterlist" class="display" style="border-spacing:0; padding:0; width:100%;">
                <thead>
                <tr>
                    <th class="no-sort" style="width:40px;"></th>
                    <th style="width:50px;">NO.</th>
                    <th>STUDENT NAME</th>
                    <th>MAJOR</th>
                    <th>ACADEMIC PROGRAM</th>
                    <th>DEGREE</th>
                </tr>
                </thead>
                <tfoot>
                <tr>
                    <th></th>
                    <th>NO.</th>
                    <th>STUDENT NAME</th>
                    <th>MAJOR</th>
                    <th>ACADEMIC PROGRAM</th>
                    <th>DEGREE</th>
                </tr>
                </tfoot>
            </table>
        </div>
        </form>`;
        rowSelector_DataTable_ClassRosterList = new DataTableRowSelector('classrosterlist', {
            counterId: 'selectedCount',
            toggleButtonId: 'toggleSelected',
            itemName: 'student'
        });
        // Variable to store pending roster data
        let pendingRosterData = null;
        createModalDialog({
            className: "dialogWidth60p",
            title: '<div style="text-align: left;">' +
                '<span class="glyphicon glyphicon-education" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;' +
                '<span style="font-size:16pt;font-weight: bold;">UPDATE CLASS ROSTER</span><br>' +
                '<span style="font-size:13pt;color:#666;font-weight:normal;margin-top:5px;display:inline-block;margin-left:30px;">' + crsinfo + ' </span>' +
                '</div>',
            message: formContent,
            buttons: {
                <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
                upload: {
                    label: "<span class='glyphicon glyphicon-upload'></span> UPLOAD ROSTER",
                    className: 'btn-info pull-left',
                    callback: function(){
                        // Check if there's existing data
                        let allStudents = DataTable_ClassRosterList.rows().data().toArray();
                        if (allStudents.length > 0) {
                            Swal.fire({
                                title: "Cannot Upload",
                                html: "There is existing class roster data.<br><br>Please use <strong>REMOVE ALL</strong> to clear the roster first before uploading a new file.",
                                icon: "warning",
                                confirmButtonText: "OK"
                            });
                            return false;
                        }

                        uploadClassRosterFile(avcIdx, enrollment, function(students) {
                            pendingRosterData = students;
                            previewClassRosterData(students);
                            const modal = $('.modal.in').last();
                            const uploadBtn = modal.find('.modal-footer button[data-button="upload"]');
                            uploadBtn.hide();
                            const saveBtn = modal.find('.modal-footer button[data-button="saveRoster"]');
                            saveBtn.removeClass('hidden-roster-button'); // Remove the hidden class
                            saveBtn.show();
                            saveBtn.prop('disabled', false);
                            saveBtn.removeClass('btn-default').addClass('btn-success');
                            const cancelUploadBtn = modal.find('.modal-footer button[data-button="cancelUpload"]');
                            cancelUploadBtn.removeClass('hidden-roster-button'); // Remove the hidden class
                            cancelUploadBtn.show();
                            modal.find('.modal-footer button[data-button="drop"]').hide();
                            modal.find('.modal-footer button[data-button="remove"]').hide();
                        });
                        return false;
                    }
                },
                editEnrollment: {
                    label: "<span class='glyphicon glyphicon-edit'></span> EDIT ENROLLMENT",
                    className: 'btn-warning pull-left',
                    callback: function(){
                        updateEnrollmentCount(avcIdx, enrollment);
                        return false;
                    }
                },
                saveRoster: {
                    label: "<span class='glyphicon glyphicon-floppy-disk'></span> SAVE ROSTER",
                    className: 'btn-success pull-left hidden-roster-button', // Add hidden class
                    callback: function(){
                        if (!pendingRosterData) {
                            Swal.fire({
                                title: "ERROR",
                                text: "No roster data to save. Please upload a file first.",
                                icon: "error"
                            });
                            return false;
                        }
                        Swal.fire({
                            title: 'Confirm Save',
                            html: `You are about to save <strong>${pendingRosterData.length}</strong> student(s) to the roster.<br><br>Do you want to proceed?`,
                            icon: 'question',
                            showCancelButton: true,
                            confirmButtonColor: '#28a745',
                            cancelButtonColor: '#6c757d',
                            confirmButtonText: 'Yes, save it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                saveClassRosterData(avcIdx, enrollment, pendingRosterData);
                            }
                        });
                        return false;
                    }
                },
                cancelUpload: {
                    label: "<span class='glyphicon glyphicon-ban-circle'></span> CANCEL UPLOAD",
                    className: 'btn-warning pull-left hidden-roster-button',
                    callback: function(){
                        Swal.fire({
                            title: 'Cancel Upload?',
                            text: 'This will discard the uploaded roster data and return to the current roster.',
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#f0ad4e',
                            cancelButtonColor: '#6c757d',
                            confirmButtonText: 'Yes, cancel it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                pendingRosterData = null;
                                DataTable_ClassRosterList.ajax.reload(function() {
                                    const modal = $('.modal.in').last();
                                    updateDropRemoveButtonStates(modal);
                                });
                                const modal = $('.modal.in').last();
                                const uploadBtn = modal.find('.modal-footer button[data-button="upload"]');
                                uploadBtn.show();
                                const saveBtn = modal.find('.modal-footer button[data-button="saveRoster"]');
                                saveBtn.hide();
                                saveBtn.addClass('hidden-roster-button'); // Add the hidden class back
                                saveBtn.prop('disabled', true);
                                saveBtn.removeClass('btn-success').addClass('btn-default');
                                const cancelUploadBtn = modal.find('.modal-footer button[data-button="cancelUpload"]');
                                cancelUploadBtn.hide();
                                cancelUploadBtn.addClass('hidden-roster-button'); // Add the hidden class back
                                modal.find('.modal-footer button[data-button="drop"]').show();
                                modal.find('.modal-footer button[data-button="remove"]').show();
                            }
                        });
                        return false;
                    }
                },
                drop: {
                    label: "<span class='glyphicon glyphicon-trash'></span> DROP / UNDROP SELECTED",
                    className: 'btn-danger',
                    callback: function(){
                        let allStudents = DataTable_ClassRosterList.rows().data().toArray();
                        if (!allStudents.length) {
                            Swal.fire({
                                title: "No Students",
                                text: "There are no students to drop/undrop from this roster.",
                                icon: "info"
                            });
                            return false;
                        }
                        let selected = rowSelector_DataTable_ClassRosterList.getSelectedData();
                        if (!selected.length) {
                            Swal.fire({
                                title: "ERROR",
                                text: "You need to select at least one student!",
                                icon: "error"
                            });
                            return false;
                        }
                        let activeStudents = selected.filter(student => student.IsDropped !== 1);
                        let droppedStudents = selected.filter(student => student.IsDropped === 1);
                        let action = '';
                        let studentsToProcess = [];
                        let confirmText = '';
                        let confirmButton = '';
                        if (activeStudents.length > 0 && droppedStudents.length === 0) {
                            action = 'drop';
                            studentsToProcess = activeStudents;
                            confirmText = `You are about to drop ${activeStudents.length} student(s) from the roster.`;
                            confirmButton = 'Yes, drop them!';
                        } else if (droppedStudents.length > 0 && activeStudents.length === 0) {
                            action = 'undrop';
                            studentsToProcess = droppedStudents;
                            confirmText = `You are about to restore ${droppedStudents.length} student(s) to the roster.`;
                            confirmButton = 'Yes, restore them!';
                        } else {
                            Swal.fire({
                                title: "ERROR",
                                text: "You cannot drop and restore students at the same time. Please select either active students to drop OR dropped students to restore.",
                                icon: "error"
                            });
                            return false;
                        }
                        Swal.fire({
                            title: 'Are you sure?',
                            text: confirmText,
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: action === 'drop' ? '#d33' : '#28a745',
                            cancelButtonColor: '#3085d6',
                            confirmButtonText: confirmButton
                        }).then((result) => {
                            if (result.isConfirmed) {
                                const studentNos = studentsToProcess.map(student => student.StudentNo).join('|');
                                DropUndropStudentsFromRoster(avcIdx, studentNos, action);
                            }
                        });
                        return false;
                    }
                },
                remove: {
                    label: "<span class='glyphicon glyphicon-trash'></span> REMOVE ALL",
                    className: 'btn-danger',
                    callback: function(){
                        let allStudents = DataTable_ClassRosterList.rows().data().toArray();
                        if (!allStudents.length) {
                            Swal.fire({
                                title: "No Students",
                                text: "There are no students to remove from this roster.",
                                icon: "info"
                            });
                            return false;
                        }
                        Swal.fire({
                            title: 'Are you sure?',
                            html: `<strong>WARNING:</strong> You are about to remove <strong>all student(s)</strong> from the roster.<br><br>This will clear the class roster!`,
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d33',
                            cancelButtonColor: '#3085d6',
                            confirmButtonText: 'Yes, remove ALL students!',
                            cancelButtonText: 'Cancel'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                removeStudentsFromRoster(avcIdx);
                            }
                        });
                        return false;
                    }
                },
                <?php } ?>
                close: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CLOSE",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal', function(){
            const modal = $(this);
            // Add data attributes to buttons for easy selection
            modal.find('.modal-footer button').each(function() {
                const buttonText = $(this).text().trim();
                if (buttonText.includes('UPLOAD ROSTER')) {
                    $(this).attr('data-button', 'upload');
                } else if (buttonText.includes('SAVE ROSTER')) {
                    $(this).attr('data-button', 'saveRoster');
                } else if (buttonText.includes('CANCEL UPLOAD')) {
                    $(this).attr('data-button', 'cancelUpload');
                } else if (buttonText.includes('DROP / UNDROP')) {
                    $(this).attr('data-button', 'drop');
                } else if (buttonText.includes('REMOVE ALL')) {
                    $(this).attr('data-button', 'remove');
                }
            });
            // Disable SAVE ROSTER button initially
            const saveBtn = modal.find('.modal-footer button[data-button="saveRoster"]');
            saveBtn.prop('disabled', true);
            // Check if there's data and update DROP/REMOVE button states
            updateDropRemoveButtonStates(modal);
            // Add event listener for DataTable draw event to update button states
            DataTable_ClassRosterList.on('draw.dt', function() {
                updateDropRemoveButtonStates(modal);
            });
        });

        // Helper function to update DROP/REMOVE button states based on data availability
        function updateDropRemoveButtonStates(modal) {
            const hasData = DataTable_ClassRosterList.rows().data().length > 0;
            const dropBtn = modal.find('.modal-footer button[data-button="drop"]');
            const removeBtn = modal.find('.modal-footer button[data-button="remove"]');

            dropBtn.prop('disabled', !hasData);
            removeBtn.prop('disabled', !hasData);
        }

        // Update previewClassRosterData to use the student data directly
        function previewClassRosterData(students) {
            // Clear the current data and load preview
            DataTable_ClassRosterList.clear();

            students.forEach((student, index) => {
                DataTable_ClassRosterList.row.add({
                    DT_RowId: `preview_${index}`,
                    StudentNo: index + 1,
                    StudentName: student.name,
                    StudentMajor: student.major,
                    AcademicProgramName: student.academicProgram || 'N/A',
                    Degree: student.degree || 'N/A',
                    AcademicProgramIdx: student.academicProgramIdx,
                    IsDropped: 0,
                    IsPreview: true
                });
            });

            DataTable_ClassRosterList.draw();
        }

        DataTable_ClassRosterList = $("#classrosterlist").DataTable({
            processing: true,
            serverSide: false,
            iDisplayLength: 10,
            lengthChange: false,
            select: {
                style: 'multi',
                selector: 'td'
            },
            dom: `<"row"<"col-sm-6"><"col-sm-6"<"pull-right"B>>>t<"row"<"col-sm-6"<"filterControls">><"col-sm-6"p>>`,
            initComplete: function() {
                rowSelector_DataTable_ClassRosterList.init(DataTable_ClassRosterList);
            },
            ajax: `ssps/m_avcourses_classroster_ssps.php?_AVCIDX=${avcIdx}`,
            order: [[ 1, 'asc' ]],
            fnDrawCallback: function() {
                $('#classrosterlist tr td:nth-child(1)').css('text-align', 'center');
                $('#classrosterlist tr td:nth-child(2)').css('text-align', 'center');

                rowSelector_DataTable_ClassRosterList.updateSelectedCount();
            },
            columns: [
                {
                    data: 'DT_RowId',
                    render: function ( data, type, full, meta ) {
                        return '';
                    }
                },
                { data: 'StudentNo' },
                {
                    data: 'StudentName',
                    render: function(data, type, full, meta) {
                        let html = data;
                        if (full.IsDropped === 1) {
                            html += ' <span class="label label-danger">DROPPED</span>';
                        }
                        if (full.IsPreview === true) {
                            html += ' <span class="label label-success">NEW</span>';
                        }
                        return html;
                    }
                },
                { data: 'StudentMajor' },
                { data: 'AcademicProgramName' },
                { data: 'Degree' }
            ],
            columnDefs: [
                {
                    orderable: false,
                    className: 'select-checkbox',
                    targets: 0
                },
                {
                    targets: 'no-sort',
                    orderable: false,
                }
            ],
            buttons: [
                {
                    extend: 'excelHtml5',
                    title: `CLASS ROSTER ${crsinfo}`,
                    text: '<i class="fa fa-file-excel-o"></i> EXPORT TO EXCEL',
                    className: 'btn btn-xs',
                    attr: {
                        style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                    },
                    exportOptions: {
                        columns: [ 1, 2, 3, 4, 5 ],
                        modifier: {
                            selected: null
                        }
                    }
                }
            ],
            createdRow: function(row, data, dataIndex) {
                if (data.IsDropped === 1) {
                    $(row).addClass('dropped-student');
                }
                if (data.IsPreview === true) {
                    $(row).addClass('new-student');
                }
            }
        });

        new DataTableSearch('#classrosterlist', DataTable_ClassRosterList, ShowResetBtn=false);
    }


    // Use Levenshtein distance for better fuzzy matching
    function levenshteinDistance(str1, str2) {
        const matrix = [];

        for (let i = 0; i <= str2.length; i++) {
            matrix[i] = [i];
        }

        for (let j = 0; j <= str1.length; j++) {
            matrix[0][j] = j;
        }

        for (let i = 1; i <= str2.length; i++) {
            for (let j = 1; j <= str1.length; j++) {
                if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1,
                        matrix[i][j - 1] + 1,
                        matrix[i - 1][j] + 1
                    );
                }
            }
        }

        return matrix[str2.length][str1.length];
    }

    // Even better: Similarity score based approach
    function findAcademicProgram(major) {
        if (!major) return null;

        // Normalize the major string
        const normalizedMajor = major.toLowerCase().trim()
            .replace(/\(bs\)/gi, '')
            .replace(/\(ms\)/gi, '')
            .replace(/bachelor of science/gi, '')
            .replace(/\s*-\s*bs$/gi, '')
            .replace(/\s+/g, ' ')
            .trim();

        let bestMatch = null;
        let highestScore = 0;

        AcademicPrograms.forEach(program => {
            const programName = program.AcademicProgram.toLowerCase();
            const degree = program.AcademicDegree.toLowerCase();

            // Calculate similarity score
            let score = 0;

            // Exact match gets highest score
            if (normalizedMajor === programName) {
                score = 100;
            }
            // Check if degree code matches
            else if (normalizedMajor.includes(degree) || degree.includes(normalizedMajor)) {
                score = 90;
            }
            // Check word-by-word match
            else {
                const majorWords = normalizedMajor.split(' ');
                const programWords = programName.split(' ');

                let matchedWords = 0;
                programWords.forEach(programWord => {
                    majorWords.forEach(majorWord => {
                        // Exact word match
                        if (majorWord === programWord) {
                            matchedWords += 2;
                        }
                        // Partial match (at least 4 chars and 70% similarity)
                        else if (majorWord.length >= 4 && programWord.length >= 4) {
                            const maxLen = Math.max(majorWord.length, programWord.length);
                            const distance = levenshteinDistance(majorWord, programWord);
                            const similarity = (maxLen - distance) / maxLen;

                            if (similarity >= 0.7) {
                                matchedWords += similarity * 1.5;
                            }
                        }
                    });
                });

                // Calculate percentage of words matched
                score = (matchedWords / programWords.length) * 50;
            }

            // Update best match if this score is higher
            if (score > highestScore && score >= 30) { // Minimum 30% similarity required
                highestScore = score;
                bestMatch = program;
            }
        });

        return bestMatch;
    }

    async function uploadClassRosterFile(avcIdx, enrollment, onSuccessCallback) {
        const formContent =
            `<form enctype="multipart/form-data" name="popupfrm" id="popupfrm">
         <input type="hidden" name="_AVCIDX" size="30" value="${avcIdx}">
         <input type="hidden" name="_ENROLLMENT" size="30" value="${enrollment}">
         <table style="border-spacing:0; padding:0; width:100%;">
         <tr><td colspan="2"><div class="input-group" style="width:100%">
          <div class="input-group" style="width:100%"><span class="input-group-addon" style="width:230px;">Class Roster<span style="color:red">* (CSV only, MAX: 2MB)</span></span>
          <input type="file" name="_FILE" id="_FILE" class="input-sm form-control" value="" placeholder="Select CSV File" accept=".csv" required>
          </div>
          <div class="alert alert-info" style="margin-top: 10px; margin-bottom: 0;">
            <strong>CSV Format:</strong> The file must contain columns: <code>Name</code> and <code>Major</code><br>
            <strong>Note:</strong> Upload the roster to preview. You can review and then save it.
          </div>
         </div></td></tr>
         </table>
        </form>`;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-upload" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">UPLOAD CLASS ROSTER</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> UPLOAD & VERIFY",
                    className: 'btn-success',
                    callback: function(){
                        const popupForm = document.getElementById('popupfrm');
                        const fileInput = document.getElementById('_FILE');

                        if (!fileInput || fileInput.files.length === 0)
                        {
                            if (fileInput) fileInput.focus();
                            Swal.fire({title:"ERROR", text: "File is not selected!!", icon:"error"});
                            return false;
                        }
                        if (!FileSizeValidation('_FILE')) return false;

                        uploadClassRosterFileProcess_verify(avcIdx, enrollment, onSuccessCallback);
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                    }
                }
            }
        }).on('shown.bs.modal',function(){
            $("#_FILE").focus();
        });
    }


    async function uploadClassRosterFileProcess_verify(avcIdx, enrollment, onSuccessCallback) {
        try {
            showFullPageSpinner();

            const fileInput = document.getElementById('_FILE');
            const csvFile = fileInput.files[0];

            // Parse CSV and extract student data WITH academic program matching
            const students = await extractStudentData(csvFile);

            hideFullPageSpinner();

            if (students.length === 0) {
                await Swal.fire({
                    title: "ERROR",
                    text: "No student data found in the CSV file!",
                    icon: "error"
                });
                return;
            }

            // Store the complete student data globally
            pendingRosterData = students;

            // Store reference to the upload dialog before showing verification
            const uploadDialog = $('.modal').last();

            // Show verification dialog
            await Swal.fire({
                title: "Roster Verified",
                html: `
                <div style="text-align: left;">
                    <p><strong>Students found in CSV:</strong> ${students.length}</p>
                    <hr>
                    <p style="color: #28a745;">The file has been successfully parsed. Review the data in the table and click "SAVE ROSTER" to save to the database.</p>
                </div>
            `,
                icon: "success"
            });

            // Close only the upload dialog (the last/top modal)
            uploadDialog.modal('hide');

            // Call the success callback to update the main dialog
            if (onSuccessCallback) {
                onSuccessCallback(students);
            }

        } catch (error) {
            hideFullPageSpinner();
            await async_commons.handleError(error.code, error.message);
        }
    }

    // Update the saveClassRosterData to include academic program info
    async function saveClassRosterData(avcIdx, enrollment, students) {
        try {
            showFullPageSpinner();

            // Prepare student data with academic program information
            const studentData = students.map(student => ({
                name: student.name,
                major: student.major,
                academicProgramIdx: student.academicProgramIdx,
                academicProgram: student.academicProgram,
                degree: student.degree
            }));

            const result = await async_commons.makeApiCall('m_avcourses_classroster_upload_ajax.php', {
                _AVCIDX: avcIdx,
                _ENROLLMENT: enrollment,
                studentData: JSON.stringify(studentData)
            });

            hideFullPageSpinner();

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS: {
                    // Reset state
                    pendingRosterData = null;

                    // Reset button states
                    const modal = $('.modal.in').last();
                    const saveBtn = modal.find('.modal-footer button[data-button="saveRoster"]');
                    saveBtn.prop('disabled', true);
                    saveBtn.removeClass('btn-success').addClass('btn-default');

                    // Hide cancel upload button
                    modal.find('.modal-footer button[data-button="cancelUpload"]').hide();
                    modal.find('.modal-footer button[data-button="saveRoster"]').hide();

                    // Show drop/remove buttons
                    modal.find('.modal-footer button[data-button="upload"]').show();
                    modal.find('.modal-footer button[data-button="drop"]').show();
                    modal.find('.modal-footer button[data-button="remove"]').show();

                    rowSelector_DataTable_ClassRosterList.clearAllSelections();
                    await async_commons.reloadDataTable(DataTable_ClassRosterList);
                    await async_commons.showSuccessMessage('SUCCESS', 'Class roster has been saved successfully!');

                    break;
                }
                case ErrorCodes.CANNOT_CONNECT_SERVER: {
                    await async_commons.showErrorMessage(
                        'ERROR',
                        `Cannot connect to the server!`
                    );
                    break;
                }
                default: {
                    throw new Error('Unexpected server response');
                }
            }
        } catch (error) {
            hideFullPageSpinner();
            await async_commons.handleError(error);
        }
    }

    //---------------------------------------------------------------------------------------------
    async function downloadSyllabus(SyllabusIndex, apIdx, Subject, Num) {
        try {
            const blob = await async_commons.makeApiCall('create_abetsyllabus_pdf.php', {
                _idx: SyllabusIndex,
                _ap: apIdx
            }, true, 'blob');

            if (blob.type === "application/pdf") {
                const link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);

                let AssessmentPDF_FileName = 'abet_syllabus';
                AssessmentPDF_FileName += '_' + String(Subject).toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '_' + String(Num).toLowerCase().replace(/ /g, '_');
                AssessmentPDF_FileName += '.pdf';

                link.download = AssessmentPDF_FileName;
                link.click();

                // Clean up
                setTimeout(() => {
                    window.URL.revokeObjectURL(link.href);
                }, 100);

                await async_commons.showSuccessMessage('SUCCESS', 'PDF downloaded successfully!');
            } else {
                throw new Error('Invalid file type received');
            }
        } catch (error) {
            await async_commons.handleError(error);
        } finally {
        }
    }

<?php
if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] || $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS']) {
?>
    async function RemoveSelectedCourses() {
        // Check if DataTable is empty
        if (DataTable_Courses.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses and convert to array
        const selected = DataTable_Courses.rows({ selected: true }).data().toArray();

        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses to remove first!",
                icon: "error"
            });
            return;
        }

        // Create a map of course indices to course data for later lookup
        const courseMap = {};
        const courseIndices = [];

        selected.forEach(course => {
            courseMap[course.AVCIdx] = course;
            courseIndices.push(course.AVCIdx);
        });

        // Build course list for confirmation
        let courseList = '<ul style="max-height: 200px; overflow-y: auto; text-align: left; font-size: 14px;">';
        selected.forEach(course => {
            courseList += `<li><strong>${course.Subject}${course.Num}</strong> - ${course.Title} (${course.SemesterTxt})</li>`;
        });
        courseList += '</ul>';

        // Confirm deletion
        const result = await Swal.fire({
            title: 'Remove Selected Courses?',
            html: `<div style="margin-bottom: 15px; font-size: 14px;">
                <strong>WARNING:</strong> You are about to remove <strong>${selected.length}</strong> course(s):
               </div>
               ${courseList}
               <div style="margin-top: 15px; padding: 10px; background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 4px; font-size: 13px;">
                <strong>Note:</strong> This will permanently delete the courses and all associated data (class rosters, instructors, etc.).
               </div>`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, remove them!',
            cancelButtonText: 'Cancel'
        });

        if (!result.isConfirmed) {
            return;
        }

        try {
            showFullPageSpinner();

            const apiResult = await async_commons.makeApiCall('m_avcourses_remove_ajax.php', {
                courseIndices: courseIndices.join(',')
            });

            hideFullPageSpinner();

            // Parse JSON response
            let response;
            try {
                response = JSON.parse(apiResult);
            } catch (e) {
                throw new Error('Invalid server response');
            }

            // Clear selections and reload table
            DataTable_Courses.rows({ selected: true }).deselect();
            await async_commons.reloadDataTable(DataTable_Courses);

            // Handle different scenarios
            if (response.status === 'all_success') {
                // All courses removed successfully
                await Swal.fire({
                    title: 'SUCCESS',
                    html: `<div style="font-size: 14px;"><strong>${response.successCount}</strong> course(s) removed successfully!</div>`,
                    icon: 'success'
                });

            } else if (response.status === 'partial_success') {
                // Some succeeded, some failed
                let successList = `
                <div style="margin-bottom: 15px;">
                    <strong style="color: #28a745; font-size: 14px;">Successfully Removed:</strong>
                    <ul style="text-align: left; margin-top: 8px; font-size: 13px; line-height: 1.6;">`;

                response.successful.forEach(idx => {
                    const course = courseMap[idx];
                    successList += `<li><strong>${course.Subject}${course.Num}</strong> - ${course.Title} <span style="color: #666;">(${course.SemesterTxt})</span></li>`;
                });
                successList += '</ul></div>';

                let failList = `
                <div>
                    <strong style="color: #dc3545; font-size: 14px;">Failed to Remove:</strong>
                    <ul style="text-align: left; margin-top: 8px; font-size: 13px; line-height: 1.6;">`;

                response.failed.forEach(fail => {
                    const course = courseMap[fail.idx];
                    failList += `<li>
                    <strong>${course.Subject}${course.Num}</strong> - ${course.Title}
                    <br><span style="font-size: 12px; color: #666; font-style: italic;">Reason: ${fail.error}</span>
                </li>`;
                });
                failList += '</ul></div>';

                await Swal.fire({
                    title: 'PARTIAL SUCCESS',
                    html: `<div style="text-align: left;">
                        <p style="font-size: 14px; margin-bottom: 15px;">
                            <strong>${response.successCount}</strong> course(s) removed,
                            <strong>${response.failCount}</strong> failed.
                        </p>
                        <hr style="margin: 15px 0; border-top: 1px solid #ddd;">
                        ${successList}
                        <hr style="margin: 15px 0; border-top: 1px solid #ddd;">
                        ${failList}
                       </div>`,
                    icon: 'warning',
                    width: '650px',
                    customClass: {
                        popup: 'swal-custom-popup'
                    }
                });

            } else if (response.status === 'all_failed') {
                // All courses failed
                let failList = `
                <div>
                    <strong style="font-size: 14px;">Failed Courses:</strong>
                    <ul style="text-align: left; margin-top: 8px; font-size: 13px; line-height: 1.6;">`;

                response.failed.forEach(fail => {
                    const course = courseMap[fail.idx];
                    failList += `<li>
                    <strong>${course.Subject}${course.Num}</strong> - ${course.Title}
                    <br><span style="font-size: 12px; color: #666; font-style: italic;">Reason: ${fail.error}</span>
                </li>`;
                });
                failList += '</ul></div>';

                await Swal.fire({
                    title: 'ERROR',
                    html: `<div style="text-align: left;">
                        <p style="font-size: 14px; margin-bottom: 15px;">
                            All <strong>${response.failCount}</strong> course(s) failed to be removed.
                        </p>
                        <hr style="margin: 15px 0; border-top: 1px solid #ddd;">
                        ${failList}
                       </div>`,
                    icon: 'error',
                    width: '650px',
                    customClass: {
                        popup: 'swal-custom-popup'
                    }
                });

            } else {
                // Handle error responses
                const errorMessages = {
                    '0x00000000': 'Unauthorized access!',
                    '0x00000001': 'Invalid parameters provided!',
                    '0x00000500': 'Database error occurred!'
                };

                const errorMsg = errorMessages[response.error] || 'An unexpected error occurred!';
                await async_commons.showErrorMessage('ERROR', errorMsg);
            }

        } catch (error) {
            hideFullPageSpinner();
            await async_commons.handleError(error);
        }
    }

    // Email ABET Syllabus function with CKEditor
    async function EmailABETSyllabus() {
        // Check if DataTable is empty
        if (DataTable_Courses.data().length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "No courses available in the list!",
                icon: "error"
            });
            return;
        }

        // Get selected courses and convert to array
        const selected = DataTable_Courses.rows({ selected: true }).data().toArray();

        if (selected.length === 0) {
            Swal.fire({
                title: "ERROR",
                text: "Please select courses first!",
                icon: "error"
            });
            return;
        }

        try {
            // Collect ABET syllabus data for all selected courses
            const abetSyllabusData = [];

            for (let i = 0; i < selected.length; i++) {
                const item = selected[i];

                // Check if there's valid syllabus data
                if (item.SyllabusData && item.SyllabusData.trim() !== '') {
                    // Split by comma to handle multiple syllabi
                    const syllabusItems = item.SyllabusData.split(', ');

                    // Process each syllabus item
                    syllabusItems.forEach(syllabusItem => {
                        // Extract AbetSyllabusIdx and AcademicProgramIdx from each item
                        const parts = syllabusItem.split('|');
                        const abetSyllabusIdx = parts[0] || null;
                        const academicProgramIdx = parts[1] || null;
                        const academicDegree = parts[2] || null;

                        // Add if valid
                        if (abetSyllabusIdx && abetSyllabusIdx !== '') {
                            abetSyllabusData.push({
                                abetSyllabusIdx: abetSyllabusIdx,
                                academicProgramIdx: academicProgramIdx,
                                academicYearIdx: item.AcademicYearIdx,
                                academicYearInfo: item.AcademicYearInfo,
                                academicDegreeInfo: academicDegree,
                                semester: item.SemesterTxt,
                                subject: item.Subject,
                                num: item.Num,
                                title: item.Title,
                                instructor: item.Instructor,
                                email: item.InstructorEmail
                            });
                        }
                    });
                }
            }

            if (abetSyllabusData.length === 0) {
                Swal.fire({
                    title: "ERROR",
                    text: "No ABET syllabus found for selected courses!",
                    icon: "error"
                });
                return;
            }

            // Group ABET syllabus by instructor email
            const groupedByInstructor = {};

            abetSyllabusData.forEach(syllabus => {
                const instructorEmail = syllabus.email;

                if (!groupedByInstructor[instructorEmail]) {
                    groupedByInstructor[instructorEmail] = {
                        instructor: syllabus.instructor,
                        email: syllabus.email,
                        courses: []
                    };
                }

                groupedByInstructor[instructorEmail].courses.push({
                    abetSyllabusIdx: syllabus.abetSyllabusIdx,
                    academicProgramIdx: syllabus.academicProgramIdx,
                    academicYearIdx: syllabus.academicYearIdx,
                    academicYearInfo: syllabus.academicYearInfo,
                    academicDegreeInfo: syllabus.academicDegreeInfo,
                    semester: syllabus.semester,
                    subject: syllabus.subject,
                    num: syllabus.num,
                    title: syllabus.title
                });
            });

            // Generate course list for preview
            let courseListPreview = '<ul style="max-height: 150px; overflow-y: auto; margin: 10px 0; font-size: 12px;">';
            abetSyllabusData.forEach(course => {
                courseListPreview += `<li><strong>${course.subject}${course.num}</strong> - ${course.title} (${course.semester}) [${course.academicYearInfo}]</li>`;
            });
            courseListPreview += '</ul>';

            // Default email content
            const defaultSubject = 'Master Syllabus for Your Courses';
            const defaultMessage = `<p>Dear Prof. [INSTRUCTOR_NAME],</p>

                <p>Please find attached the master syllabus for your courses:</p>

                <p>[COURSE_LIST]</p>

                <p>The master syllabus PDF(s) are provided for your reference. Note that multiple syllabus may be included if a course is offered across different degree programs.</p>

                <p>Ensure that your course syllabus aligns with the corresponding syllabus. If you intend to adopt a new required textbook, contact the Curriculum Committee to submit a textbook revision proposal.</p>

                <p>Thank you for your continued support of our ABET accreditation process.</p>

                <p>Best regards,<br>
                ABET Assessment Team</p>`;

            // Create form content for the modal
            const formContent = `
        <form name="emailCustomizationForm" id="emailCustomizationForm" method="" onsubmit="return false;">
            <div style="margin-bottom: 20px;">
                <strong>Selected Courses (${abetSyllabusData.length} courses for ${Object.keys(groupedByInstructor).length} instructor(s)):</strong>
                ${courseListPreview}
            </div>

            <div class="input-group" style="width:100%; margin-bottom: 15px;">
                <span class="input-group-addon" style="width:150px;">Email Subject<span style="color:red">*</span></span>
                <input type="text" name="_emailSubject" id="_emailSubject" class="input-sm form-control" value="${defaultSubject}" required>
            </div>

            <div class="input-group" style="width:100%; margin-bottom: 15px;">
                <span class="input-group-addon" style="width:150px;">CC Emails</span>
                <input type="text" name="_ccEmails" id="_ccEmails" class="input-sm form-control" value="<?php echo($_SESSION['ATLAS_LOGIN_USEREMAIL']);?>" placeholder="email1@domain.com, email2@domain.com">
                <div id="ccEmailError" style="color: red; font-size: 11px; margin-top: 3px; display: none;"></div>
            </div>

            <div style="margin-bottom: 15px;">
                <label for="_emailMessage" style="display: block; margin-bottom: 5px; font-weight: bold;">Email Message<span style="color:red">*</span>:</label>
                <div style="font-size: 11px; color: #666; margin-bottom: 5px;">
                    <strong>Required placeholders:</strong> [INSTRUCTOR_NAME] and [COURSE_LIST] - these will be replaced with actual data for each instructor. Do not remove these.
                </div>
                <textarea name="_emailMessage" id="_emailMessage" rows="12" class="form-control" style="width: 100%;" required>${defaultMessage}</textarea>
                <div id="placeholderError" style="color: red; font-size: 11px; margin-top: 3px; display: none;"></div>
            </div>
        </form>`;

            // Show the modal dialog
            createModalDialog({
                largeSize: true,
                className: "dialogWide",
                title: '<span class="glyphicon glyphicon-envelope" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;<span style="font-size:16pt;font-weight: bold;">CUSTOMIZE EMAIL</span>',
                message: formContent,
                buttons: {
                    ok: {
                        label: "<span class='glyphicon glyphicon-send'></span> SEND EMAILS",
                        className: 'btn-success',
                        callback: function(){
                            const subject = emailCustomizationForm._emailSubject.value.trim();
                            const ccEmails = emailCustomizationForm._ccEmails.value.trim();

                            // Get CKEditor content safely
                            let message = '';
                            if (CKEDITOR.instances['_emailMessage'] && CKEDITOR.instances['_emailMessage'].getData) {
                                message = CKEDITOR.instances['_emailMessage'].getData().trim();
                            }

                            // Clear previous error messages
                            document.getElementById('ccEmailError').style.display = 'none';
                            document.getElementById('placeholderError').style.display = 'none';

                            // Validate subject
                            if (!subject) {
                                Swal.fire({
                                    title: "Validation Error",
                                    text: "Please enter an email subject!",
                                    icon: "error"
                                });
                                return false;
                            }

                            // Validate message
                            if (!message) {
                                Swal.fire({
                                    title: "Validation Error",
                                    text: "Please enter an email message!",
                                    icon: "error"
                                });
                                return false;
                            }

                            // Validate required placeholders
                            if (!message.includes('[INSTRUCTOR_NAME]') || !message.includes('[COURSE_LIST]')) {
                                document.getElementById('placeholderError').textContent =
                                    'Email message must contain both [INSTRUCTOR_NAME] and [COURSE_LIST] placeholders!';
                                document.getElementById('placeholderError').style.display = 'block';

                                Swal.fire({
                                    title: "Validation Error",
                                    text: "Email message must contain both [INSTRUCTOR_NAME] and [COURSE_LIST] placeholders!",
                                    icon: "error"
                                });
                                return false;
                            }

                            // Validate CC emails if provided
                            if (ccEmails) {
                                const emailValidation = validateCCEmails(ccEmails);
                                if (!emailValidation.isValid) {
                                    document.getElementById('ccEmailError').textContent = emailValidation.error;
                                    document.getElementById('ccEmailError').style.display = 'block';

                                    Swal.fire({
                                        title: "Validation Error",
                                        text: emailValidation.error,
                                        icon: "error"
                                    });
                                    return false;
                                }
                            }

                            // Clean up CKEditor before sending
                            safelyDestroyCKEditor('_emailMessage');

                            // Send emails with custom data
                            sendEmailsWithCustomData(groupedByInstructor, abetSyllabusData, subject, ccEmails, message);
                            return true;
                        }
                    },
                    cancel: {
                        label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                        className: 'btn-default',
                        callback: function(){
                            // Clean up on cancel
                            safelyDestroyCKEditor('_emailMessage');
                        }
                    }
                }
            }).on('shown.bs.modal', function(){
                // Safely destroy any existing CKEditor instance
                safelyDestroyCKEditor('_emailMessage');

                // Calculate available height
                const modalHeight = $(this).find('.modal-body').height();
                const headerHeight = 250; // Height of form elements except textarea
                let editorHeight = modalHeight - headerHeight;

                // Set a minimum reasonable height
                editorHeight = Math.max(editorHeight, 300);

                // Apply the height directly to the textarea
                $('#_emailMessage').css('height', editorHeight + 'px');

                // Initialize CKEditor with explicit height setting and error handling
                CKEDITOR.replace('_emailMessage', {
                    toolbar: [
                        ['Bold', 'Italic', 'Underline', '-', 'NumberedList', 'BulletedList'],
                        ['FontSize', 'TextColor', 'BGColor', '-', 'Link'],
                        ['Undo', 'Redo']
                    ],
                    height: editorHeight + 'px',
                    allowedContent: true,
                    enterMode: CKEDITOR.ENTER_P,
                    shiftEnterMode: CKEDITOR.ENTER_BR,

                    // Add event listeners
                    on: {
                        instanceReady: function(evt) {
                            // Focus on the editor after it's ready
                            evt.editor.focus();
                        },
                        change: function(evt) {
                            // Real-time validation for placeholders
                            const content = evt.editor.getData();
                            const errorDiv = document.getElementById('placeholderError');

                            if (content && (!content.includes('[INSTRUCTOR_NAME]') || !content.includes('[COURSE_LIST]'))) {
                                errorDiv.textContent = 'Email message must contain both [INSTRUCTOR_NAME] and [COURSE_LIST] placeholders!';
                                errorDiv.style.display = 'block';
                            } else {
                                errorDiv.style.display = 'none';
                            }
                        }
                    }
                });

                // Add a window resize handler for responsiveness
                $(window).on('resize.ckeditor', function() {
                    if (CKEDITOR.instances['_emailMessage'] && CKEDITOR.instances['_emailMessage'].resize) {
                        const newModalHeight = $('.modal-body').height();
                        const newEditorHeight = Math.max(newModalHeight - headerHeight, 300);
                        CKEDITOR.instances['_emailMessage'].resize('100%', newEditorHeight);
                    }
                });

                // Clean up on modal close
                $(this).on('hidden.bs.modal', function() {
                    $(window).off('resize.ckeditor');
                    safelyDestroyCKEditor('_emailMessage');
                });

                // Focus on subject field initially
                $("#_emailSubject").focus();

                // Add real-time validation for CC emails
                $('#_ccEmails').on('input', function() {
                    const ccEmails = this.value.trim();
                    const errorDiv = document.getElementById('ccEmailError');

                    if (ccEmails) {
                        const validation = validateCCEmails(ccEmails);
                        if (!validation.isValid) {
                            errorDiv.textContent = validation.error;
                            errorDiv.style.display = 'block';
                        } else {
                            errorDiv.style.display = 'none';
                        }
                    } else {
                        errorDiv.style.display = 'none';
                    }
                });
            });

        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                title: "ERROR",
                text: "An error occurred while preparing the email dialog!",
                icon: "error"
            });
        }
    }

<?php
}
?>
    // Helper function to safely destroy CKEditor instances
    function safelyDestroyCKEditor(instanceName) {
        try {
            if (CKEDITOR.instances &&
                CKEDITOR.instances[instanceName] &&
                CKEDITOR.instances[instanceName].destroy &&
                typeof CKEDITOR.instances[instanceName].destroy === 'function') {
                CKEDITOR.instances[instanceName].destroy(true); // true means "no DOM cleanup" which avoids some errors
            }
        } catch (e) {
            console.log('CKEditor cleanup error:', e);
            // Continue despite error
        }

        // Extra safety: check if it's still there and force remove from instances object
        if (CKEDITOR.instances && CKEDITOR.instances[instanceName]) {
            delete CKEDITOR.instances[instanceName];
        }
    }

    // Function to validate CC email addresses
    function validateCCEmails(ccEmails) {
        // Regular expression for email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Split emails by comma and clean up
        const emailArray = ccEmails.split(',').map(email => email.trim()).filter(email => email.length > 0);

        if (emailArray.length === 0) {
            return { isValid: true }; // Empty is valid
        }

        const invalidEmails = [];

        for (let email of emailArray) {
            if (!emailRegex.test(email)) {
                invalidEmails.push(email);
            }
        }

        if (invalidEmails.length > 0) {
            return {
                isValid: false,
                error: `Invalid email format(s): ${invalidEmails.join(', ')}`
            };
        }

        // Check for duplicate emails
        const uniqueEmails = [...new Set(emailArray)];
        if (uniqueEmails.length !== emailArray.length) {
            return {
                isValid: false,
                error: 'Duplicate email addresses found in CC list'
            };
        }

        return { isValid: true };
    }

    // Separate function to handle the actual email sending
    async function sendEmailsWithCustomData(groupedByInstructor, abetSyllabusData, subject, ccEmails, message) {
        try {
            // Show progress dialog
            Swal.fire({
                title: 'Processing...',
                html: `
                <div style="margin: 20px 0;">
                    <div style="font-size: 14px; margin-bottom: 10px;">Sending Master syllabus emails...</div>
                    <div style="width: 100%; background-color: #e0e0e0; border-radius: 10px; overflow: hidden;">
                        <div id="progress-bar" style="width: 0%; height: 30px; background-color: #3085d6; transition: width 0.3s; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                            <span id="progress-text">0%</span>
                        </div>
                    </div>
                    <div id="progress-status" style="margin-top: 10px; font-size: 12px; color: #666;">Preparing emails...</div>
                </div>
            `,
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // Helper function to update progress
            function updateProgress(current, total, status) {
                const percent = Math.round((current / total) * 100);
                const progressBar = document.getElementById('progress-bar');
                const progressText = document.getElementById('progress-text');
                const progressStatus = document.getElementById('progress-status');

                if (progressBar) progressBar.style.width = percent + '%';
                if (progressText) progressText.textContent = percent + '%';
                if (progressStatus) progressStatus.textContent = status;
            }

            const totalInstructors = Object.keys(groupedByInstructor).length;
            updateProgress(1, 1, `Sending emails to ${totalInstructors} instructor(s)...`);

            // Send email with grouped ABET syllabus
            const formData = new FormData();
            formData.append('instructorData', JSON.stringify(groupedByInstructor));
            formData.append('emailSubject', subject);
            formData.append('ccEmails', ccEmails);
            formData.append('emailMessage', message);

            const response = await fetch('m_avcourses_sendabetsyllabusemail.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                const instructorCount = Object.keys(groupedByInstructor).length;
                Swal.fire({
                    title: "Success",
                    text: `Master syllabus for ${abetSyllabusData.length} course(s) sent to ${instructorCount} instructor(s)!`,
                    icon: "success"
                });

                // Uncheck all selected rows
                DataTable_Courses.rows({ selected: true }).deselect();

            } else {
                Swal.fire({
                    title: "ERROR",
                    text: result.message || "Failed to send emails!",
                    icon: "error"
                });
            }

        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                title: "ERROR",
                text: "An error occurred while sending master syllabi!",
                icon: "error"
            });
        }
    }

    <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
    async function ManageCourseInstructors(avcIdx, crsinfo) {
        const formContent = `
        <form name="instructorForm" id="instructorForm" onsubmit="return false;">
            <style>
                .instructor-row {
                    margin-bottom: 10px;
                    padding: 12px;
                    background: #f8f9fa;
                    border: 1px solid #dee2e6;
                    border-radius: 4px;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                .instructor-info {
                    flex: 1;
                    display: flex;
                    gap: 10px;
                    align-items: center;
                }
                .instructor-name {
                    flex: 1;
                    font-weight: 500;
                }
                .instructor-email {
                    flex: 1;
                    color: #666;
                }
                .instructor-actions {
                    display: flex;
                    gap: 5px;
                }
                .primary-badge {
                    background: #28a745;
                    color: white;
                    padding: 3px 10px;
                    border-radius: 3px;
                    font-size: 11px;
                    font-weight: bold;
                }
                .no-instructors-msg {
                    padding: 20px;
                    text-align: center;
                    color: #999;
                    font-style: italic;
                }
                .user-search-item {
                    cursor: pointer;
                    transition: background-color 0.2s;
                    padding: 8px;
                    border-bottom: 1px solid #dee2e6;
                }
                .user-search-item:hover {
                    background-color: #f8f9fa;
                }
                #searchResults {
                    max-height: 300px;
                    overflow-y: auto;
                    border: 1px solid #dee2e6;
                    border-radius: 4px;
                    margin-top: 10px;
                }
                #searchResults:empty {
                    border: none;
                }
                #selectedInstructor {
                    margin-top: 10px;
                }
            </style>

            <div style="margin-bottom: 20px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h4 style="margin: 0; color: #333;">
                        <span class="glyphicon glyphicon-user"></span> Course Instructors
                    </h4>
                    <button type="button" class="btn btn-primary btn-sm" id="addInstructorBtn">
                        <span class="glyphicon glyphicon-plus"></span> Add Instructor
                    </button>
                </div>
                <div id="instructorsList"></div>
            </div>
        </form>
    `;

        createModalDialog({
            className: "dialogWidth60p",
            title: '<div style="text-align: left;">' +
                '<span class="glyphicon glyphicon-user" style="font-size:20pt;color:#C9DAE1;vertical-align:top;"></span>&nbsp;' +
                '<span style="font-size:16pt;font-weight: bold;">MANAGE INSTRUCTORS</span><br>' +
                '<span style="font-size:13pt;color:#666;font-weight:normal;margin-top:5px;display:inline-block;margin-left:30px;">' + crsinfo + '</span>' +
                '</div>',
            message: formContent,
            buttons: {
                close: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CLOSE",
                    className: 'btn-default',
                    callback: function(){
                        // Reload the main DataTable to reflect changes
                        if (typeof DataTable_Courses !== 'undefined') {
                            DataTable_Courses.ajax.reload(null, false);
                        }
                    }
                }
            }
        }).on('shown.bs.modal', function(){
            // Load existing instructors
            loadInstructors(avcIdx);

            // Add instructor button handler
            $('#addInstructorBtn').off('click').on('click', function() {
                showAddInstructorDialog(avcIdx);
            });
        });
    }

    // Function to load and display instructors
    async function loadInstructors(avcIdx) {
        try {
            const result = await async_commons.makeApiCall('m_avcourses_instructors_fetch.php', {
                avcIdx: avcIdx
            });

            const data = JSON.parse(result);

            if (data.success) {
                displayInstructors(data.instructors, avcIdx);
            } else {
                throw new Error(data.message || 'Failed to load instructors');
            }
        } catch (error) {
            console.error('Error loading instructors:', error);
            $('#instructorsList').html('<div class="alert alert-danger">Failed to load instructors</div>');
        }
    }

    // Function to display instructors list
    function displayInstructors(instructors, avcIdx) {
        const container = $('#instructorsList');

        if (!instructors || instructors.length === 0) {
            container.html('<div class="no-instructors-msg">No instructors assigned to this course yet.</div>');
            return;
        }

        let html = '';
        instructors.forEach(instructor => {
            html += `
            <div class="instructor-row" data-instructor-idx="${instructor.Idx}">
                <div class="instructor-info">
                    <div class="instructor-name">
                        <strong>${instructor.InstructorName}</strong>
                        ${instructor.IsPrimary == 1 ? '<span class="primary-badge">PRIMARY</span>' : ''}
                    </div>
                    <div class="instructor-email">
                        <span class="glyphicon glyphicon-envelope"></span> ${instructor.InstructorEmail || 'No email'}
                    </div>
                </div>
                <div class="instructor-actions">
                    ${instructor.IsPrimary != 1 ?
                `<button class="btn btn-success btn-xs" onclick="setPrimaryInstructor(${avcIdx}, ${instructor.UserIdx}); return false;" title="Set as Primary">
                            <span class="glyphicon glyphicon-star"></span>
                        </button>` : ''}
                    <button class="btn btn-danger btn-xs" onclick="removeInstructor(${avcIdx}, ${instructor.Idx}); return false;" title="Remove">
                        <span class="glyphicon glyphicon-trash"></span>
                    </button>
                </div>
            </div>
        `;
        });

        container.html(html);
    }

    // Variables for instructor selection
    let selectedUserId = null;
    let searchTimeout = null;

    // Function to show add instructor dialog with user search
    function showAddInstructorDialog(avcIdx) {
        const formContent = `
        <form name="addInstructorForm" id="addInstructorForm">
            <div class="input-group" style="width:100%; margin-bottom: 15px;">
                <span class="input-group-addon" style="width:150px;">Search Instructor<span style="color:red">*</span></span>
                <input type="text" name="instructorSearch" id="instructorSearch" class="input-sm form-control" placeholder="Type name or email to search..." autocomplete="off">
            </div>
            <div id="searchResults"></div>
            <div id="selectedInstructor" class="alert alert-info" style="display: none;">
                <strong>Selected:</strong> <span id="selectedInstructorName"></span>
                <button type="button" class="btn btn-xs btn-default pull-right" id="clearSelection">
                    <span class="glyphicon glyphicon-remove"></span>
                </button>
            </div>
            <div class="checkbox" style="margin-left: 10px;">
                <label>
                    <input type="checkbox" name="isPrimary" id="isPrimary"> Set as primary instructor
                </label>
            </div>
        </form>
    `;

        createModalDialog({
            title: '<span class="glyphicon glyphicon-plus" style="font-size:16pt;color:#C9DAE1;"></span>&nbsp;<span style="font-size:14pt;font-weight: bold;">ADD INSTRUCTOR</span>',
            message: formContent,
            buttons: {
                ok: {
                    label: "<span class='glyphicon glyphicon-ok'></span> ADD",
                    className: 'btn-success',
                    callback: function(){
                        if (!selectedUserId) {
                            Swal.fire({
                                title: "ERROR",
                                text: "Please select an instructor from the search results!",
                                icon: "error"
                            });
                            return false;
                        }

                        const isPrimary = $('#isPrimary').is(':checked') ? 1 : 0;
                        addInstructor(avcIdx, selectedUserId, isPrimary);
                        return true;
                    }
                },
                cancel: {
                    label: "<span class='glyphicon glyphicon-remove'></span> CANCEL",
                    className: 'btn-default',
                    callback: function(){
                        selectedUserId = null;
                    }
                }
            }
        }).on('shown.bs.modal', function(){
            $('#instructorSearch').focus();

            // Search functionality
            $('#instructorSearch').on('input', function() {
                const searchTerm = $(this).val().trim();

                clearTimeout(searchTimeout);

                if (searchTerm.length < 2) {
                    $('#searchResults').empty();
                    return;
                }

                searchTimeout = setTimeout(() => {
                    searchUsers(searchTerm, avcIdx);
                }, 300);
            });

            // Clear selection
            $('#clearSelection').on('click', function() {
                selectedUserId = null;
                $('#selectedInstructor').hide();
                $('#instructorSearch').val('').focus();
            });
        });
    }

    // Search users function
    async function searchUsers(searchTerm, avcIdx) {
        try {
            const result = await async_commons.makeApiCall('m_avcourses_instructors_search_users.php', {
                searchTerm: searchTerm,
                avcIdx: avcIdx
            });

            const data = JSON.parse(result);

            if (data.success) {
                displaySearchResults(data.users);
            } else {
                $('#searchResults').html(`
                <div class="alert alert-warning" style="margin: 10px 0;">
                    ${data.message || 'No users found'}
                </div>
            `);
            }
        } catch (error) {
            console.error('Error searching users:', error);
            $('#searchResults').html(`
            <div class="alert alert-danger" style="margin: 10px 0;">
                Error searching users
            </div>
        `);
        }
    }

    // Display search results
    function displaySearchResults(users) {
        const resultsContainer = $('#searchResults');
        resultsContainer.empty();

        if (users.length === 0) {
            resultsContainer.html(`
            <div class="alert alert-info" style="margin: 10px 0;">
                No users found matching your search
            </div>
        `);
            return;
        }

        users.forEach(user => {
            const userItem = $(`
            <div class="user-search-item" data-user-id="${user.Idx}">
                <div style="font-weight: bold;">${escapeHtml(user.Name)}</div>
                <small style="color: #666;">${escapeHtml(user.Email)}</small>
            </div>
        `);

            userItem.on('click', function() {
                selectUser(user);
            });

            resultsContainer.append(userItem);
        });
    }

    // Select user
    function selectUser(user) {
        selectedUserId = user.Idx;
        $('#selectedInstructorName').text(`${user.Name} (${user.Email})`);
        $('#selectedInstructor').show();
        $('#searchResults').empty();
        $('#instructorSearch').val('');
    }

    // Helper function to escape HTML
    function escapeHtml(text) {
        if (!text) return '';
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(text).replace(/[&<>"']/g, m => map[m]);
    }

    // Function to add instructor
    async function addInstructor(avcIdx, userIdx, isPrimary) {
        try {
            showFullPageSpinner();

            const result = await async_commons.makeApiCall('m_avcourses_instructors_add.php', {
                avcIdx: avcIdx,
                userIdx: userIdx,
                isPrimary: isPrimary
            });

            hideFullPageSpinner();

            const code = result.trim();
            switch (code) {
                case ErrorCodes.SUCCESS:
                    await async_commons.showSuccessMessage('SUCCESS', 'Instructor added successfully!');
                    loadInstructors(avcIdx);
                    selectedUserId = null;
                    break;
                case '0x00000001':
                    await async_commons.showErrorMessage('ERROR', 'Invalid parameters provided!');
                    break;
                case '0x00000002':
                    await async_commons.showErrorMessage('ERROR', 'This instructor is already assigned to this course!');
                    break;
                case ErrorCodes.CANNOT_CONNECT_SERVER:
                    await async_commons.showErrorMessage('ERROR', 'Cannot connect to the server!');
                    break;
                default:
                    throw new Error('Unexpected server response: ' + code);
            }
        } catch (error) {
            hideFullPageSpinner();
            await async_commons.handleError(error);
        }
    }

    // Function to set primary instructor
    async function setPrimaryInstructor(avcIdx, userIdx) {
        try {
            const result = await Swal.fire({
                title: 'Set as Primary?',
                text: 'This will set this instructor as the primary instructor for the course.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#28a745',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, set as primary!'
            });

            if (!result.isConfirmed) return;

            const apiResult = await async_commons.makeApiCall(
                'm_avcourses_instructors_setprimary.php',
                {
                    avcIdx: avcIdx,
                    userIdx: userIdx
                },
                true
            );

            const code = apiResult.trim();
            switch (code) {
                case ErrorCodes.SUCCESS:
                    await async_commons.showSuccessMessage('SUCCESS', 'Primary instructor updated!');
                    loadInstructors(avcIdx);
                    break;
                case ErrorCodes.CANNOT_CONNECT_SERVER:
                    await async_commons.showErrorMessage('ERROR', 'Cannot connect to the server!');
                    break;
                default:
                    throw new Error('Unexpected server response: ' + code);
            }
        } catch (error) {
            hideFullPageSpinner();
            await async_commons.handleError(error);
        }
    }

    // Function to remove instructor
    async function removeInstructor(avcIdx, instructorIdx) {
        try {
            const result = await Swal.fire({
                title: 'Remove Instructor?',
                text: 'Are you sure you want to remove this instructor from the course?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, remove it!'
            });

            if (!result.isConfirmed) return;

            const apiResult = await async_commons.makeApiCall(
                'm_avcourses_instructors_remove.php',
                {instructorIdx: instructorIdx},
                true
            );

            const code = apiResult.trim();
            switch (code) {
                case ErrorCodes.SUCCESS:
                    await async_commons.showSuccessMessage('SUCCESS', 'Instructor removed successfully!');
                    loadInstructors(avcIdx);
                    break;
                case ErrorCodes.CANNOT_CONNECT_SERVER:
                    await async_commons.showErrorMessage('ERROR', 'Cannot connect to the server!');
                    break;
                default:
                    throw new Error('Unexpected server response: ' + code);
            }
        } catch (error) {
            hideFullPageSpinner();
            await async_commons.handleError(error);
        }
    }
    <?php } ?>

</script>

<script class="init">
    const szURL = 'ssps/m_avcourses_ssps.php?_SM=';

    $(document).ready(function() {
        DataTable_Courses = $("#courseinfo").DataTable({
            dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
            processing: true,
            serverSide: true,
            select: {
                style: 'multi'
            },
            lengthMenu: [ 50, 100, 150, 300 ],
            search: {
                regex: true
            },
            fnInitComplete: function(oSettings, json) {
                let btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                btnClear.appendTo($('#' + oSettings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                $('#' + oSettings.sTableId + '_wrapper .btnClearDataTableFilter').click(function () {
                    $('#' + oSettings.sTableId).dataTable().fnFilter('');
                });

                // Column visibility
                new DataTableColumnVisibility(DataTable_Courses, oSettings.sTableId, {
                    skipColumns: ['operation', '']  // must be lowercase letters
                }).build();
            },
            ajax: szURL + "<?php echo($Semester);?>",
            oLanguage: {"sInfoFiltered": ""},
            columns: [
                {
                    data: null,
                    className: "select-checkbox text-center",
                    defaultContent: "",
                    orderable: false,
                    width: "30px"
                },
                { data: 'SemesterTxt', className: 'text-center'},
                { data: 'CRN', className: 'text-center'},
                { data: 'Subject', className: 'text-center'},
                { data: 'Num', className: 'text-center'},
                { data: 'Title', className: 'text-center'},
                { data: 'Credits', className: 'text-center'},
                { data: 'Days', className: 'text-center'},
                { data: 'Times', className: 'text-center'},
                { data: 'Location', className: 'text-center'},
                <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
                {
                    data: 'Instructor',
                    render: function (data, type, full, meta) {
                        if (type === 'export') {
                            return data;
                        }

                        let instructorText = data || 'No Instructor';

                        return '<div style="display: flex; align-items: center; gap: 8px;">' +
                            '<span style="flex: 1;">' + instructorText + '</span>' +
                            '<button class="btn-manage-instructors btn btn-info btn-xs glyphicon glyphicon-plus" ' +
                            'data-avcourse-idx="' + full.AVCIdx + '" ' +
                            'data-crsinfo="' + full.SemesterTxt + ' - ' + full.CRN + ' - ' + full.Subject + ' '+ full.Num + ' '+ full.Title + '" ' +
                            'alt="Manage Instructors" ' +
                            'title="Manage Instructors" ' +
                            'style="min-height: 22px; white-space: nowrap;"></button>' +
                            '</div>';
                    }
                },
                <?php } else { ?>
                { data: 'Instructor' },
                <?php } ?>
                {
                    data: 'Capacity',
                    className: 'text-center'
                },
                {
                    data: 'Actual',
                    className: 'text-center',
                    render: function (data, type, full, meta) {
                        if (type === 'export') {
                            return data;
                        }

                        let count = parseInt(data) || 0;
                        let hasClassRoster = full.ClassRoster === 1; // Check if ClassRoster exists

                        // Choose icon and color based on ClassRoster existence
                        let iconClass = hasClassRoster ? 'glyphicon-education' : 'glyphicon-upload';
                        let btnClass = hasClassRoster ? 'btn-success' : 'btn-warning';
                        let titleText = hasClassRoster ? 'Update Class Roster' : 'Create Class Roster';

                        return '<button class="btn-update-roster btn ' + btnClass + ' btn-xs glyphicon ' + iconClass + '" ' +
                            'data-avcourse-idx="' + full.AVCIdx + '" ' +
                            'data-enrollment="' + full.Actual + '" ' +
                            'data-crsinfo="' + full.SemesterTxt + ' - ' + full.CRN + ' - ' + full.Subject + ' '+ full.Num + ' '+ full.Title + '" ' +
                            'alt="' + titleText + '" ' +
                            'title="' + titleText + '" ' +
                            'style="min-height: 20px; min-width: 110px;">&nbsp;' + count + ' Students</button>';
                    }
                },
                {
                    data: 'SyllabusData',
                    orderable: false,
                    className: 'text-center',
                    render: function (data, type, full, meta) {
                        if (type === 'export') {
                            return data && data.trim() !== '' ? 'Yes' : 'No';
                        }

                        if (!data || data.trim() === '') {
                            return '<span class="text-muted">N/A</span>';
                        }

                        // Split by comma to get multiple syllabus items
                        let syllabusItems = data.split(', ');
                        let buttons = [];

                        syllabusItems.forEach(function(item) {
                            // Split each item by pipe to get Idx and AcademicProgram
                            let parts = item.split('|');
                            let syllabusIdx = parts[0];
                            let academicProgramIdx = parts[1] || '';

                            if (syllabusIdx && syllabusIdx !== '') {
                                buttons.push(
                                    '<button class="btn-download-syllabus btn btn-success btn-xs glyphicon glyphicon-floppy-save" ' +
                                    'data-idx="' + syllabusIdx + '" ' +
                                    'data-program="' + academicProgramIdx + '" ' +
                                    'data-subject="' + full.Subject + '" ' +
                                    'data-num="' + full.Num + '" ' +
                                    'alt="Download Syllabus" ' +
                                    'title="Download Syllabus " ' +
                                    'style="min-height: 20px; margin: 2px;"></button>'
                                );
                            }
                        });

                        return buttons.length > 0 ? buttons.join(' ') : '<span class="text-muted">N/A</span>';
                    }
                }
            ],
            order: [[ 1, 'desc' ], [ 2, 'asc' ]],
            fnDrawCallback: function() {
                // Reset toggle-all checkbox state when page changes
                $('#courseinfo thead .toggle-all').removeClass('selected');
            },
            columnDefs: [ {
                targets  : 'no-sort',
                orderable: false,
            }],
            buttons: [ {
                extend: 'excelHtml5',
                title: 'All Available Courses',
                text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                className: 'btn btn-xs',
                attr: {
                    style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff; margin-left:8px;'
                },
                exportOptions: {
                    columns: ':not(:last-child)'   // exclude last column
                }
            }]
        });

        async_commons.setDataTable(DataTable_Courses);

        $('#courseinfo').on('click', '.toggle-all', function() {
            $(this).toggleClass("selected");
            if ($(this).hasClass("selected")) {
                DataTable_Courses.rows({ page: 'current' }).select();
            }
            else {
                DataTable_Courses.rows({ page: 'current' }).deselect();
            }
        });

        <?php if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) { ?>
        $('#courseinfo').on('click', '.btn-manage-instructors', function(e) {
            e.preventDefault();
            e.stopPropagation();

            const avcIdx = $(this).data('avcourse-idx');
            const crsinfo = $(this).data('crsinfo');
            ManageCourseInstructors(avcIdx, crsinfo);
            return false;
        });
        <?php } ?>

        $("#_SM").on('change', function() {
            const tmpURL = szURL + this.value;
            DataTable_Courses.ajax.url(tmpURL).load();
        });

        new DataTableSearch('#courseinfo', DataTable_Courses);

        $('#courseinfo').on('click', '.btn-update-roster', function(e) {
            e.preventDefault();
            e.stopPropagation();

            const avcIdx = $(this).data('avcourse-idx');
            const enrollment = $(this).data('enrollment');
            const crsinfo = $(this).data('crsinfo');
            updateClassRoster(avcIdx, enrollment, crsinfo);
            return false;
        });

        $('#courseinfo').on('click', '.btn-download-syllabus', function() {
            const syllabusIdx = $(this).data('idx');
            const subject = $(this).data('subject');
            const num = $(this).data('num');
            const apIdx = $(this).data('program');
            downloadSyllabus(syllabusIdx, apIdx, subject, num);
            return false;
        });
    });
</script>


<div class="pagebacklayout">
	<div style="width:100%;">
		<p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">&nbsp;ALL AVAILABLE COURSES</span>&nbsp;</p>
	</div>

	<div class="pagebacklayout_inner_noborder">
		<table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
		<tr>
			<td style="width:30%">
                <?php echo($AcademicSemesterSelection);?>
            </td>
			<td style="width:70%; text-align:right">
                <?php
                if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] || $_SESSION['ATLAS_ACCESSCNTL_PROGRAM_DIRECTORS']) {
                ?>
                <button class="btn btn-primary btn-sm glyphicon glyphicon-envelope" onclick="EmailABETSyllabus();return false;">&nbsp;EMAIL SYLLABUS</button>
                <?php
                }
                ?>

                <?php
                if ($_SESSION['ATLAS_LOGIN_SYSADMIN'] === true) {
                ?>
                <button class="btn btn-warning btn-sm glyphicon glyphicon-trash" onclick="RemoveSelectedCourses(); return false;">&nbsp;REMOVE SELECTED</button>
                <button class="btn btn-danger btn-sm glyphicon glyphicon-download" onclick="FetchAvailableCourses(); return false;">&nbsp;FETCH &amp; UPDATE ALL AVAILABLE COURSES</button>
                <?php
                }
                ?>
            </td>
		</tr>
		</table>

		<div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
		<table id="courseinfo" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
            <thead>
            <tr>
                <th class="toggle-all" style="width:3px; "></th>
                <th>SEM</th>
                <th>CRN</th>
                <th>SUBJ</th>
                <th>NUM</th>
                <th>TITLE</th>
                <th>CREDITS</th>
                <th>DAYS</th>
                <th>TIMES</th>
                <th>LOCATION</th>
                <th>INSTRUCTOR</th>
                <th>CAPACITY</th>
                <th>ACTUAL</th>
                <th>MASTER SYLLABUS</th>
            </tr>
            </thead>
            <thead id="serachbox" class="filters">
			<tr>
                <th></th>
				<th>SEM</th>
				<th>CRN</th>
				<th>SUBJ</th>
				<th>NUM</th>
				<th>TITLE</th>
				<th>CREDITS</th>
				<th>DAYS</th>
				<th>TIMES</th>
				<th>LOCATION</th>
				<th>INSTRUCTOR</th>
				<th>CAPACITY</th>
				<th>ACTUAL</th>
                <th>MASTER SYLLABUS</th>
			</tr>
            </thead>
            <tfoot>
                <tr>
                    <th></th>
                    <th>SEM</th>
                    <th>CRN</th>
                    <th>SUBJ</th>
                    <th>NUM</th>
                    <th>TITLE</th>
                    <th>CREDITS</th>
                    <th>DAYS</th>
                    <th>TIMES</th>
                    <th>LOCATION</th>
                    <th>INSTRUCTOR</th>
                    <th>CAPACITY</th>
                    <th>ACTUAL</th>
                    <th>MASTER SYLLABUS</th>
                </tr>
            </tfoot>
		</table>
		</div>

        <table style="width:98%; border-spacing:0; padding:0; margin:auto; font-size:8pt;">
            <tr>
                <td>
                    <span style="color:red;font-weight:bold;"></span></td>
                <td style="text-align:right;">
                    <span class="btn-download-syllabus btn btn-success btn-xs glyphicon glyphicon-floppy-save" style="pointer-events: none;"></span>: Upload Master (ABET) Syllabus
                    <span class="btn-download-syllabus btn btn-success btn-xs glyphicon glyphicon-education" style="pointer-events: none;"></span>: Update Class Roster
                    <span class="btn-download-syllabus btn btn-warning btn-xs glyphicon glyphicon-upload" style="pointer-events: none;"></span>: Upload Class Roster
                </td>
            </tr>
        </table>
    </div>
</div>

<?php include('footer.php'); ?>

