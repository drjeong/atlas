<?php
include_once 'session_handler.php';

$instructorIdx = isset($_POST['instructorIdx']) ? intval($_POST['instructorIdx']) : 0;
$instructorName = isset($_POST['instructorName']) ? trim($_POST['instructorName']) : '';
$instructorEmail = isset($_POST['instructorEmail']) ? trim($_POST['instructorEmail']) : '';

if ($instructorIdx <= 0 || empty($instructorName)) {
    echo "0x00000001"; // Invalid parameters
    exit;
}

try {
    require_once(__DIR__ . '/php_include/dbconnection_class.php');
    $DBCONNECTION = new Dbconnection();

    // Get the AVCourseIdx before updating
    $query = "SELECT `AVCourseIdx` FROM `AVCoursesInstructors` WHERE `Idx` = ?";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$instructorIdx]);
    $row = $result->fetch_assoc();

    if (!$row) {
        echo "0x00000001"; // Invalid parameters
        exit;
    }

    $avcIdx = $row['AVCourseIdx'];

    // Update instructor
    $updateQuery = "UPDATE `AVCoursesInstructors` 
                   SET `Instructor` = ?, `InstructorEmail` = ? 
                   WHERE `Idx` = ?";
    $DBCONNECTION->prepare_execute_catch_error($updateQuery, [$instructorName, $instructorEmail, $instructorIdx]);

    // Update the Instructor field in AVCourses table
    updateCourseInstructorField($DBCONNECTION, $avcIdx);

    echo "0x11111111"; // Success

} catch (mysqli_sql_exception $e) {
    error_log("Error updating instructor: " . $e->getMessage());
    echo "0x00000500"; // Database error
} catch (Exception $e) {
    error_log("Error updating instructor: " . $e->getMessage());
    echo "0x00000000"; // General error
}

function updateCourseInstructorField($DBCONNECTION, $avcIdx) {
    // Get all instructors for this course
    $query = "SELECT `Instructor`, `InstructorEmail`, `IsPrimary` 
              FROM `AVCoursesInstructors` 
              WHERE `AVCourseIdx` = ? 
              ORDER BY `IsPrimary` DESC, `Instructor` ASC";
    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$avcIdx]);

    $instructorNames = [];
    $primaryEmail = '';

    while ($row = $result->fetch_assoc()) {
        $instructorNames[] = $row['Instructor'];
        if ($row['IsPrimary'] == 1 && empty($primaryEmail)) {
            $primaryEmail = $row['InstructorEmail'];
        }
    }

    $instructorString = implode(', ', $instructorNames);

    // Update AVCourses table
    $updateQuery = "UPDATE `AVCourses` 
                   SET `Instructor` = ?, `InstructorEmail` = ? 
                   WHERE `Idx` = ?";
    $DBCONNECTION->prepare_execute_catch_error($updateQuery, [$instructorString, $primaryEmail, $avcIdx]);
}
?>