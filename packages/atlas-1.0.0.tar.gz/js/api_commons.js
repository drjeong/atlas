/**
 * API Commons Module
 * Version 0.0.101
 *
 * Provides reusable UI components and validation utilities:
 * - createModalDialog: Creates customizable Bootstrap modal dialogs
 * - preventEditing: Locks form fields to prevent modifications
 * - FileSizeValidation: Validates uploaded file sizes
 *
 * Dependencies:
 * - jQuery
 * - Bootstrap 3
 * - Bootbox.js
 * - SweetAlert2 (Swal)
 * - jQuery UI (for draggable functionality)
 */

/**
 * Creates a customizable modal dialog using Bootbox
 *
 * @param {Object} options - Configuration options for the modal
 * @param {string} [options.title=''] - Modal title (can include HTML)
 * @param {string} [options.message=''] - Modal body content (can include HTML)
 * @param {string} [options.width='600px'] - Modal width (only applies when centered=true)
 * @param {boolean} [options.centered=true] - Whether to center the modal on screen
 * @param {boolean} [options.fullScreen=false] - Whether to make modal full screen (100%)
 * @param {boolean} [options.largeSize=false] - Whether to make modal 90% of viewport
 * @param {boolean} [options.mediumSize=false] - Whether to make modal 60% of viewport
 * @param {Object} [options.buttons=null] - Custom button configuration (uses OK/Cancel if null)
 * @param {Function} [options.onShow=null] - Callback function when modal is shown
 * @param {Function} [options.onHide=null] - Callback function when modal is hidden
 * @param {Object} [options.otherOptions] - Additional Bootbox options
 * @returns {jQuery} The modal dialog jQuery object
 *
 * @example
 * createModalDialog({
 *     title: 'Confirmation',
 *     message: 'Are you sure?',
 *     buttons: {
 *         confirm: { label: 'Yes', className: 'btn-success' },
 *         cancel: { label: 'No', className: 'btn-default' }
 *     }
 * });
 */
function createModalDialog({
							   title = '',
							   message = '',
							   width = '600px',
							   centered = true,
							   fullScreen = false,
							   largeSize = false,
							   mediumSize = false,
							   buttons = null,
							   onShow = null,
							   onHide = null,
							   ...otherOptions
						   } = {}) {
	// Generate unique ID for modal-specific styles to avoid conflicts
	const styleId = `modal-style-${Date.now()}`;

	// Apply full screen styling (100% viewport)
	if (fullScreen) {
		const styles = `
            <style id="${styleId}">
                /* Position modal to fill entire viewport */
                .bootbox .modal-dialog {
                    position: fixed !important;
                    top: 0 !important;
                    left: 0 !important;
                    right: 0 !important;
                    bottom: 0 !important;
                    margin: 0 !important;
                    width: 100% !important;
                    height: 100% !important;
                    max-width: none !important;
                    transform: none !important;
                }
                
                /* Stretch modal content to fill dialog */
                .bootbox .modal-content {
                    position: absolute !important;
                    top: 0 !important;
                    left: 0 !important;
                    right: 0 !important;
                    bottom: 0 !important;
                    border-radius: 0 !important;
                    height: 100% !important;
                    max-height: 100% !important;
                    overflow: hidden !important;
                }
                
                /* Fixed header at top */
                .bootbox .modal-header {
                    padding: 15px 20px !important;
                }
                
                /* Scrollable body between header and footer */
                .bootbox .modal-body {
                    position: absolute !important;
                    top: 70px !important;
                    bottom: 70px !important;
                    left: 0 !important;
                    right: 0 !important;
                    overflow-y: auto !important;
                    max-height: none !important;
                }
                
                /* Fixed footer at bottom */
                .bootbox .modal-footer {
                    position: absolute !important;
                    bottom: 0 !important;
                    left: 0 !important;
                    right: 0 !important;
                    padding: 15px 20px !important;
                }
            </style>
        `;
		document.head.insertAdjacentHTML('beforeend', styles);
	}
	// Apply large size styling (90% viewport with scrolling)
	else if (largeSize) {
		const styles = `
        <style id="${styleId}">
            /* Size modal to 90% of viewport with 5% margins */
            .bootbox .modal-dialog {
                width: 90% !important;
                height: 90% !important;
                max-width: 90% !important;
                max-height: 90% !important;
                margin: 5% auto !important;
            }
            
            /* Make content fill dialog height */
            .bootbox .modal-content {
                height: 100% !important;
            }
            
            /* Scrollable body (subtract ~120px for header/footer) */
            .bootbox .modal-body {
                height: calc(100% - 120px) !important;
                max-height: none !important;
                overflow-y: auto !important;
            }
            
            /* Ensure CKEditor is visible (fix for some display issues) */
            .cke {
                visibility: visible !important;
            }
        </style>
    `;
		document.head.insertAdjacentHTML('beforeend', styles);
	}
	// Apply medium size styling (60% viewport with scrolling)
	else if (mediumSize) {
		const styles = `
        <style id="${styleId}">
            /* Size modal to 60% of viewport with 5% margins */
            .bootbox .modal-dialog {
                width: 60% !important;
                height: 60% !important;
                max-width: 60% !important;
                max-height: 60% !important;
                margin: 5% auto !important;
            }
            
            /* Make content fill dialog height */
            .bootbox .modal-content {
                height: 100% !important;
            }
            
            /* Scrollable body (subtract ~120px for header/footer) */
            .bootbox .modal-body {
                height: calc(100% - 120px) !important;
                max-height: none !important;
                overflow-y: auto !important;
            }
            
            /* Ensure CKEditor is visible (fix for some display issues) */
            .cke {
                visibility: visible !important;
            }
        </style>
    `;
		document.head.insertAdjacentHTML('beforeend', styles);
	}
	// Apply centered positioning with custom width
	else if (centered) {
		const styles = `
            <style id="${styleId}">
                /* Center modal at 40% from top, 50% from left */
                .bootbox .modal-dialog {
                    position: fixed !important;
                    top: 40% !important;
                    left: 50% !important;
                    transform: translate(-50%, -50%) !important;
                    margin: 0 !important;
                    width: ${width};
                }

                /* Responsive: use 95% width on mobile devices */
                @media (max-width: 768px) {
                    .bootbox .modal-dialog {
                        width: 95% !important;
                    }
                }
            </style>
        `;
		document.head.insertAdjacentHTML('beforeend', styles);
	}

	// Define default OK/Cancel buttons with Bootstrap glyphicons
	const defaultButtons = {
		ok: {
			label: '<span class="glyphicon glyphicon-ok"></span>&nbsp;OK',
			className: 'btn-success'
		},
		cancel: {
			label: '<span class="glyphicon glyphicon-remove"></span>&nbsp;CANCEL',
			className: 'btn-default'
		}
	};

	// Merge options with defaults
	const dialogOptions = {
		title,
		message: message || '',  // Prevent null message
		buttons: buttons || defaultButtons,
		onEscape: false,  // Disable ESC key to close
		backdrop: 'static',  // Disable clicking outside to close
		...otherOptions
	};

	// Create the modal using Bootbox
	const dialog = bootbox.dialog(dialogOptions);

	// Event: When modal is fully shown
	dialog.on('shown.bs.modal', function() {
		// Remove aria-hidden for accessibility
		$(this).removeAttr('aria-hidden');

		// Execute custom onShow callback if provided
		if (onShow) {
			onShow();
		}
	});

	// Event: When modal is about to hide
	dialog.on('hide.bs.modal', function() {
		// Remove aria-modal for accessibility
		$(this).removeAttr('aria-modal');
	});

	// Event: When modal is fully hidden
	dialog.on('hidden.bs.modal', function() {
		// Remove aria-modal for accessibility
		$(this).removeAttr('aria-modal');

		// Clean up custom styles for this modal
		if (centered || fullScreen || largeSize) {
			const styleElement = document.getElementById(styleId);
			if (styleElement) {
				styleElement.remove();
			}
		}

		// Execute custom onHide callback if provided
		if (onHide) {
			onHide();
		}
	});

	// Fix accessibility attributes on close button
	dialog.find('.close')
		.on('mousedown', function(e) {
			$(this).removeAttr('aria-hidden');
		})
		.on('click', function(e) {
			$(this).removeAttr('aria-modal');
		});

	// Make modal draggable (except for fullscreen and large size modals)
	if (!fullScreen && !largeSize) {
		dialog.find('.modal-content').draggable({
			'handle': ".modal-header"  // Drag by header only
		}).find('.modal-header').css({
			'cursor': 'move'  // Show move cursor on header
		});
	}

	return dialog;
}

/**
 * Prevents editing of form fields and displays a warning when user attempts to modify them.
 * Makes fields readonly/disabled while maintaining their visual appearance.
 *
 * @param {string} selector - CSS selector for targeted elements (e.g., '.my-class', '#myId', 'input')
 *
 * @example
 * preventEditing('.locked-field');
 * preventEditing('#student-name, #student-id');
 */
function preventEditing(selector) {
	$(document).ready(function() {
		// Find all elements matching the selector
		const $elements = $(selector);

		// Warn if no elements found
		if ($elements.length === 0) {
			console.warn("preventEditing: No elements found matching selector", selector);
			return;
		}

		// Remove any previous styles to avoid conflicts
		$("#prevent-edit-styles").remove();

		// Process each matched element
		$elements.each(function() {
			const $el = $(this);

			// Store original values to restore if user tries to change
			if ($el.is('input[type="checkbox"], input[type="radio"]')) {
				$el.data('original-checked', $el.prop('checked'));
			} else {
				$el.data('original-value', $el.val());
			}

			// Add identification class
			$el.addClass('prevent-edit-field');

			// Store original background color before making readonly
			const originalBg = $el.css('background-color');
			$el.data('original-bg', originalBg);

			// Make text inputs and textareas readonly
			if ($el.is('input, textarea') &&
				!$el.is('input[type="checkbox"], input[type="radio"]')) {
				$el.prop('readonly', true);

				// Ensure readonly doesn't change background (browser default behavior)
				$el.css('background-color', originalBg || 'white');
			}
			// Disable selects, checkboxes, and radio buttons
			else if ($el.is('select, input[type="checkbox"], input[type="radio"]')) {
				$el.prop('disabled', true);

				// Prevent disabled opacity change (keep opaque)
				if (!$el.data('opacity-fixed')) {
					$el.css('opacity', '1');
					$el.data('opacity-fixed', true);
				}
			}
		});

		// Add CSS to change cursor and maintain appearance
		$("<style id='prevent-edit-styles'>")
			.text(`
                /* Show not-allowed cursor on all protected fields */
                .prevent-edit-field { 
                    cursor: not-allowed !important; 
                }
                /* Maintain white background and full opacity for readonly fields */
                .prevent-edit-field[readonly] {
                    background-color: white !important;
                    opacity: 1 !important;
                }
                /* Maintain white background and full opacity for disabled fields */
                .prevent-edit-field:disabled {
                    background-color: white !important;
                    opacity: 1 !important;
                }
            `)
			.appendTo("head");

		// Prevent input changes on text fields and textareas
		$elements.filter('input:not([type="checkbox"]):not([type="radio"]), textarea')
			.on('input keydown', function(e) {
				// Allow navigation keys only
				if (e.key === 'Tab' || e.key.startsWith('Arrow') ||
					(e.ctrlKey && e.key === 'c')) {  // Allow Ctrl+C (copy)
					return true;
				}

				// Prevent the input change
				e.preventDefault();
				e.stopPropagation();

				// Restore original value
				$(this).val($(this).data('original-value'));

				// Ensure background stays original color
				const bg = $(this).data('original-bg') || 'white';
				$(this).css('background-color', bg);

				// Show warning to user
				showWarning();

				return false;
			});

		// Prevent form submissions
		$elements.closest('form').on('submit', function(e) {
			e.preventDefault();
			return false;
		});

		// Prevent paste, cut, and drag operations
		$elements.on('paste cut dragover drop', function(e) {
			e.preventDefault();
			showWarning();
			return false;
		});

		// Prevent clicks on selects, checkboxes, and radio buttons
		$elements.on('click mousedown', function(e) {
			if ($(this).is('select, input[type="checkbox"], input[type="radio"]')) {
				e.preventDefault();
				e.stopPropagation();
				showWarning();
				return false;
			}
		});

		/**
		 * Displays a warning message using SweetAlert2
		 * @private
		 */
		function showWarning() {
			Swal.fire({
				title: "Editing Not Allowed",
				text: "You cannot modify this field.",
				icon: "warning",
				confirmButtonText: "OK"
			});
		}
	});
}

/**
 * Validates that uploaded file(s) do not exceed the maximum size limit.
 * Shows a spinner during validation and displays an error alert if any file is too large.
 *
 * @param {string} id - The ID of the file input element (without # prefix)
 * @param {number} [maxSize=2] - Maximum file size in MB (default: 2)
 * @param {string} [text=null] - Custom error message (uses default if null)
 * @returns {boolean} True if validation passes, false if any file exceeds limit
 *
 * @example
 * // Basic usage with 2MB limit
 * FileSizeValidation('fileInput');
 *
 * // Custom 5MB limit with custom message
 * FileSizeValidation('myFile', 5, 'File must be under 5MB!');
 */
function FileSizeValidation(id, maxSize = 2, text = null) {
	let spinner = null;

	try {
		// Show loading spinner if FullPageSpinner class is available
		if (typeof FullPageSpinner !== 'undefined') {
			spinner = new FullPageSpinner();
		}

		// Convert MB to KB for comparison
		const MAX_FILE_SIZE_MB = maxSize;
		const MAX_FILE_SIZE_KB = MAX_FILE_SIZE_MB * 1024;

		// Get the file input element
		const fileInput = document.getElementById(id);

		// Validate that element exists
		if (!fileInput) {
			throw new Error(`File input element with ID '${id}' not found`);
		}

		// Check each selected file
		if (fileInput.files.length > 0) {
			for (const file of fileInput.files) {
				// Calculate file size in KB
				const fileSizeKB = Math.round(file.size / 1024);

				// Check if file exceeds maximum size
				if (fileSizeKB >= MAX_FILE_SIZE_KB) {
					// Show error with helpful compression tip
					Swal.fire({
						title: "ERROR",
						html: `
							<p>${text || `File size is too big (MAX: ${MAX_FILE_SIZE_MB}MB)!`}</p>
							<div style="background-color: #fff3cd; border: 1px solid #ffc107; border-radius: 6px; padding: 12px 16px; font-family: sans-serif; margin-top: 12px; text-align: left;">
								<div style="color: #e63946; font-weight: bold; margin-bottom: 6px;">⚠️ NOTICE:</div>
								<div style="color: #333; font-size:10pt;">
									Need to reduce PDF file size? Use the website shown below:<br>
									<a href="https://www.adobe.com/acrobat/online/compress-pdf.html" target="_blank"
									   style="color: #0066cc; text-decoration: none; word-break: break-all;">
										https://www.adobe.com/acrobat/online/compress-pdf.html
									</a>
								</div>
							</div>
						`,
						icon: "error"
					}).then(() => {
						// Return focus to file input after closing alert
						fileInput.focus();
					});
					return false;
				}
			}
		}

		// All files passed validation
		return true;

	} catch (error) {
		// Log error and show user-friendly message
		console.error('FileSizeValidation error:', error);

		Swal.fire({
			title: "ERROR",
			text: "An error occurred while validating the file. Please try again.",
			icon: "error"
		});

		return false;

	} finally {
		// Always clean up spinner, whether validation succeeded or failed
		if (spinner) {
			spinner.destroy();
		}
	}
}

/**
 * Converts a UTC datetime string to local timezone in YYYY-MM-DD HH:MM:SS format.
 *
 * Takes a datetime string from the database (stored in UTC) and converts it to the
 * user's local timezone while maintaining the same display format. Returns 'Never'
 * for null, empty, or zero dates.
 *
 * @param {string} utcDateString - The UTC datetime string from database (e.g., '2026-05-11 13:18:47')
 * @returns {string} Formatted local datetime string in YYYY-MM-DD HH:MM:SS format, or 'Never' if invalid
 *
 * @example
 * // Database stores: '2026-05-11 13:18:47' (UTC)
 * // User in Eastern timezone (UTC-4) sees:
 * formatLocalDateTime('2026-05-11 13:18:47');
 * // Returns: '2026-05-11 09:18:47'
 *
 * @example
 * // Handle null or empty dates
 * formatLocalDateTime(null);
 * // Returns: ''
 *
 * @example
 * // Usage in DataTables column render
 * {
 *     "data": 'LastLogin',
 *     "render": function(data, type, row) {
 *         if (type === 'display') {
 *             return formatLocalDateTime(data);
 *         }
 *         return data;
 *     }
 * }
 */
function formatLocalDateTime(utcDateString) {
	// Check for null, undefined, empty string, or MySQL zero date
	if (!utcDateString || utcDateString === '0000-00-00 00:00:00') {
		return '';
	}

	// Parse the UTC datetime string and convert to local Date object
	// Appending ' UTC' ensures proper timezone interpretation
	const date = new Date(utcDateString + ' UTC');

	// Extract date components in local timezone
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');  // Months are 0-indexed
	const day = String(date.getDate()).padStart(2, '0');
	const hours = String(date.getHours()).padStart(2, '0');
	const minutes = String(date.getMinutes()).padStart(2, '0');
	const seconds = String(date.getSeconds()).padStart(2, '0');

	// Return formatted string: YYYY-MM-DD HH:MM:SS
	return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
}


/**
 * Downloads a course binder PDF with optional force regeneration.
 *
 * Prompts the user to download a course binder PDF, with an option to force
 * regeneration (ignoring cached versions). Makes an API call to generate/retrieve
 * the PDF and handles various error cases including missing materials and server errors.
 * Requires async_commons.makeApiCall to be loaded and SweetAlert2 (Swal) for dialogs.
 *
 * @param {string} avcIdx - The AVC index identifier
 * @param {string} abtcIdx - The ABTC index identifier
 * @param {string} ap - The AP parameter
 * @param {string} ay - The AY parameter
 * @param {string} semesterText - The semester text (e.g., 'Spring 2021')
 * @param {string} courseSubject - The course subject code (e.g., 'CSCI')
 * @param {string} courseNum - The course number (e.g., '353')
 * @param {string} crn - The course CRN (e.g., '21629')
 * @param {Object} [options] - Optional configuration
 * @param {boolean} [options.showForceRegenerate=true] - Whether to show the force regenerate option in the dialog
 * @returns {Promise<boolean>} Returns true if download successful, false otherwise
 *
 * @example
 * // Basic usage with default options (shows force regenerate checkbox)
 * await downloadCourseBinderPDF(
 *     '12345',
 *     '67890',
 *     'AP001',
 *     '2021',
 *     'Spring 2021',
 *     'CSCI',
 *     '353',
 *     '21629'
 * );
 *
 * @example
 * // Hide force regenerate option
 * await downloadCourseBinderPDF(
 *     '12345',
 *     '67890',
 *     'AP001',
 *     '2021',
 *     'Spring 2021',
 *     'CSCI',
 *     '353',
 *     '21629',
 *     { showForceRegenerate: false }
 * );
 *
 * @example
 * // Usage in an onclick handler
 * <button onclick="downloadCourseBinderPDF('<?php echo $_AVCIDX; ?>', ...)">
 *     Download Course Binder
 * </button>
 *
 * @throws {Error} If async_commons is not loaded or API call fails
 */
async function downloadCourseBinderPDF(avcIdx, abtcIdx, ap, ay, semesterText, courseSubject, courseNum, crn, options = {}) {
	try {
		// Destructure options with defaults
		const { showForceRegenerate = true } = options;

		// Check if async_commons is loaded and available
		if (typeof async_commons === 'undefined' || !async_commons.makeApiCall) {
			throw new Error('Required library async_commons is not loaded. Please refresh the page and try again.');
		}

		// Check if SweetAlert2 is loaded
		if (typeof Swal === 'undefined') {
			throw new Error('Required library SweetAlert2 is not loaded. Please refresh the page and try again.');
		}

		// Build dialog HTML based on options
		let dialogHtml = '';

		if (showForceRegenerate) {
			dialogHtml = `
		<p>Choose how to download the course binder:</p>
		<div style="margin-top: 15px; padding: 10px; background-color: #f0f0f0; border-radius: 5px;">
			<label style="display: flex; align-items: center; cursor: pointer;">
				<input type="checkbox" id="force-regenerate" style="margin-right: 8px; width: 18px; height: 18px; cursor: pointer;">
				<span style="font-size: 0.95em;">Force regenerate PDF (ignore cached version)</span>
			</label>
		</div>
	`;
		} else {
			dialogHtml = '<p>Download the course binder PDF?</p>';
		}

		// Show confirmation dialog with optional force regenerate checkbox
		const confirmation = await Swal.fire({
			title: 'Download Course Binder',
			html: dialogHtml,
			icon: 'question',
			showCancelButton: true,
			confirmButtonText: 'Download',
			cancelButtonText: 'Cancel',
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			reverseButtons: true,
			preConfirm: () => {
				const forceRegenerate = showForceRegenerate
					? document.getElementById('force-regenerate')?.checked || false
					: false;
				return { forceRegenerate };
			}
		});

		// If user cancels, exit early
		if (!confirmation.isConfirmed) {
			return false;
		}

		const forceRegenerate = confirmation.value.forceRegenerate;

		// Prepare API parameters
		const param = {
			_AVC: avcIdx,
			_ABTC: abtcIdx,
			_AP: ap,
			_AY: ay,
			_FORCE: forceRegenerate ? "1" : "0"
		};

		// Show loading indicator while generating/fetching PDF
		Swal.fire({
			title: 'Generating PDF',
			html: forceRegenerate ?
				'<p>Regenerating course binder...</p>' :
				'<p>Loading course binder...</p>',
			allowOutsideClick: false,
			allowEscapeKey: false,
			showConfirmButton: false,
			didOpen: () => {
				Swal.showLoading();
			}
		});

		// Make API call to generate/retrieve PDF
		const blob = await async_commons.makeApiCall(
			'create_coursebinder_pdf.php',
			param,
			false, // no spinner (we're using Swal loading instead)
			'blob', // type parameter (not responseType)
			false // no timeout
		);

		// Close loading dialog
		Swal.close();

		// Validate that we received a Blob response
		if (blob instanceof Blob) {
			if (blob.type === "application/pdf") {
				// Successfully received PDF - create download link
				const link = document.createElement('a');
				link.href = window.URL.createObjectURL(blob);

				// Generate filename: coursebinder_2021_spring_csci_353_crn21629.pdf
				const semesterLower = semesterText.toLowerCase().replace(/\s+/g, '_');
				const subjectLower = courseSubject.toLowerCase().replace(/\s+/g, '_');
				const numLower = courseNum.toLowerCase().replace(/\s+/g, '_');
				const crnClean = crn.replace(/\s+/g, '_');

				const fileName = `coursebinder_${semesterLower}_${subjectLower}_${numLower}_crn${crnClean}.pdf`;
				link.download = fileName;

				// Trigger download
				link.click();

				// Clean up object URL after a short delay
				setTimeout(() => {
					window.URL.revokeObjectURL(link.href);
				}, 100);

				// Show success message
				await Swal.fire({
					title: "Success",
					text: "Course binder downloaded successfully!",
					icon: "success",
					timer: 2000,
					showConfirmButton: false
				});

				return true;

			} else if (blob.type === "text/html") {
				// Server returned an error code as HTML text
				const htmlContent = await blob.text();

				// Handle specific error codes returned by the server
				switch (htmlContent) {
					case "0x4356723":
						await Swal.fire({
							title: "ERROR",
							text: "Please upload instructional materials!",
							icon: "error",
							timer: 2000
						});
						break;
					case "0x4356724":
						await Swal.fire({
							title: "ERROR",
							text: "Please upload course assignment materials!",
							icon: "error",
							timer: 2000
						});
						break;
					case "0x3234234":
						await Swal.fire({
							title: "ERROR",
							text: "Course binder is not available yet!",
							icon: "error",
							timer: 2000
						});
						break;
					default:
						await Swal.fire({
							title: "ERROR",
							text: "Unexpected error found. Please contact the system administrator!",
							icon: "error"
						});
						break;
				}

				return false;

			} else {
				// Unknown blob type received
				await Swal.fire({
					title: "ERROR",
					text: "Unknown error found. Please contact the system administrator!",
					icon: "error"
				});

				return false;
			}
		} else {
			// Response was not a Blob
			await Swal.fire({
				title: "ERROR",
				text: "Unexpected response type from server",
				icon: "error"
			});

			return false;
		}

	} catch (error) {
		// Handle any errors that occurred during the process
		// Close any open dialogs first
		Swal.close();

		// Show error message to user
		await Swal.fire({
			title: "ERROR",
			text: error.message || "Failed to download PDF. Please try again.",
			icon: "error"
		});

		return false;
	}
}
/**
 * Downloads an assessment report PDF with optional force regeneration.
 *
 * Prompts the user to download an assessment report PDF, with an option to force
 * regeneration (ignoring cached versions). Makes an API call to generate/retrieve
 * the PDF and handles various error cases including unavailable reports and server errors.
 * Requires async_commons.makeApiCall to be loaded and SweetAlert2 (Swal) for dialogs.
 *
 * @param {string} avcIdx - The AVC index identifier
 * @param {string} abtcIdx - The ABTC index identifier
 * @param {string} ap - The AP parameter
 * @param {string} ay - The AY parameter
 * @param {string} semesterText - The semester text (e.g., 'Spring 2021')
 * @param {string} courseSubject - The course subject code (e.g., 'CSCI')
 * @param {string} courseNum - The course number (e.g., '353')
 * @param {string} crn - The course CRN (e.g., '21629')
 * @param {Object} [options] - Optional configuration
 * @param {boolean} [options.showForceRegenerate=true] - Whether to show the force regenerate option in the dialog
 * @returns {Promise<boolean>} Returns true if download successful, false otherwise
 *
 * @example
 * // Basic usage with default options (shows force regenerate checkbox)
 * await downloadAssessmentReport(
 *     '12345',
 *     '67890',
 *     'AP001',
 *     '2021',
 *     'Spring 2021',
 *     'CSCI',
 *     '353',
 *     '21629'
 * );
 *
 * @example
 * // Hide force regenerate option
 * await downloadAssessmentReport(
 *     '12345',
 *     '67890',
 *     'AP001',
 *     '2021',
 *     'Spring 2021',
 *     'CSCI',
 *     '353',
 *     '21629',
 *     { showForceRegenerate: false }
 * );
 *
 * @example
 * // Usage in an onclick handler
 * <button onclick="downloadAssessmentReport('<?php echo $_AVCIDX; ?>', ...)">
 *     Download Assessment Report
 * </button>
 *
 * @throws {Error} If async_commons is not loaded or API call fails
 */
async function downloadAssessmentReport(avcIdx, abtcIdx, ap, ay, semesterText, courseSubject, courseNum, crn, options = {}) {
	try {
		// Destructure options with defaults
		const { showForceRegenerate = true } = options;

		// Check if async_commons is loaded and available
		if (typeof async_commons === 'undefined' || !async_commons.makeApiCall) {
			throw new Error('Required library async_commons is not loaded. Please refresh the page and try again.');
		}

		// Check if SweetAlert2 is loaded
		if (typeof Swal === 'undefined') {
			throw new Error('Required library SweetAlert2 is not loaded. Please refresh the page and try again.');
		}

		// Build dialog HTML based on options
		let dialogHtml = '';

		if (showForceRegenerate) {
			dialogHtml = `
				<p>Choose how to download the assessment report:</p>
				<div style="margin-top: 15px; padding: 10px; background-color: #f0f0f0; border-radius: 5px;">
					<label style="display: flex; align-items: center; cursor: pointer;">
						<input type="checkbox" id="force-regenerate" style="margin-right: 8px; width: 18px; height: 18px; cursor: pointer;">
						<span style="font-size: 0.95em;">Force regenerate PDF (ignore cached version)</span>
					</label>
				</div>
			`;
		} else {
			dialogHtml = '<p>Download the assessment report PDF?</p>';
		}

		// Show confirmation dialog with optional force regenerate checkbox
		const confirmation = await Swal.fire({
			title: 'Download Assessment Report',
			html: dialogHtml,
			icon: 'question',
			showCancelButton: true,
			confirmButtonText: 'Download',
			cancelButtonText: 'Cancel',
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			reverseButtons: true,
			preConfirm: () => {
				const forceRegenerate = showForceRegenerate
					? document.getElementById('force-regenerate')?.checked || false
					: false;
				return { forceRegenerate };
			}
		});

		// If user cancels, exit early
		if (!confirmation.isConfirmed) {
			return false;
		}

		const forceRegenerate = confirmation.value.forceRegenerate;

		// Prepare API parameters
		const param = {
			_AVC: avcIdx,
			_ABTC: abtcIdx,
			_AP: ap,
			_AY: ay,
			_FORCE: forceRegenerate ? "1" : "0"
		};

		// Show loading indicator while generating/fetching PDF
		Swal.fire({
			title: 'Generating PDF',
			html: forceRegenerate ?
				'<p>Regenerating assessment report...</p>' :
				'<p>Loading assessment report...</p>',
			allowOutsideClick: false,
			allowEscapeKey: false,
			showConfirmButton: false,
			didOpen: () => {
				Swal.showLoading();
			}
		});

		// Make API call to generate/retrieve PDF
		const blob = await async_commons.makeApiCall(
			'create_assessment_pdf.php',
			param,
			false, // no spinner (we're using Swal loading instead)
			'blob', // type parameter (not responseType)
			false // no timeout
		);

		// Close loading dialog
		Swal.close();

		// Validate that we received a Blob response
		if (blob instanceof Blob) {
			if (blob.type === "application/pdf") {
				// Successfully received PDF - create download link
				const link = document.createElement('a');
				link.href = window.URL.createObjectURL(blob);

				// Generate filename: assessment_2021_spring_csci_353_crn21629.pdf
				const semesterLower = semesterText.toLowerCase().replace(/\s+/g, '_');
				const subjectLower = courseSubject.toLowerCase().replace(/\s+/g, '_');
				const numLower = courseNum.toLowerCase().replace(/\s+/g, '_');
				const crnClean = crn.replace(/\s+/g, '_');

				const fileName = `assessment_${semesterLower}_${subjectLower}_${numLower}_crn${crnClean}.pdf`;
				link.download = fileName;

				// Trigger download
				link.click();

				// Clean up object URL after a short delay
				setTimeout(() => {
					window.URL.revokeObjectURL(link.href);
				}, 100);

				// Show success message
				await Swal.fire({
					title: "Success",
					text: "Assessment report downloaded successfully!",
					icon: "success",
					timer: 2000,
					showConfirmButton: false
				});

				return true;

			} else if (blob.type === "text/html") {
				// Server returned an error code as HTML text
				const htmlContent = await blob.text();

				// Handle specific error codes returned by the server
				switch (htmlContent) {
					case "0x3234234":
						await Swal.fire({
							title: "ERROR",
							text: "Course assessment PDF is not available yet!",
							icon: "error",
							timer: 2000
						});
						break;
					default:
						await Swal.fire({
							title: "ERROR",
							text: "Unexpected error found. Please contact the system administrator!",
							icon: "error"
						});
						break;
				}

				return false;

			} else {
				// Unknown blob type received
				await Swal.fire({
					title: "ERROR",
					text: "Unknown error found. Please contact the system administrator!",
					icon: "error"
				});

				return false;
			}
		} else {
			// Response was not a Blob
			await Swal.fire({
				title: "ERROR",
				text: "Unexpected response type from server",
				icon: "error"
			});

			return false;
		}

	} catch (error) {
		// Handle any errors that occurred during the process
		// Close any open dialogs first
		Swal.close();

		// Show error message to user
		await Swal.fire({
			title: "ERROR",
			text: error.message || "Failed to download PDF. Please try again.",
			icon: "error"
		});

		return false;
	}
}