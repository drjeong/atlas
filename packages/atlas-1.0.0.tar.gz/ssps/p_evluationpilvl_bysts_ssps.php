<?php
/**
 * Evaluation of Performance Indicators by Level
 *
 * 12/14/2025 - initial version created
 * 02/03/2026 - added student count and attainment metrics
 * 06/07/2026 - refactored to use performance_indicator_helpers
 * 06/11/2026 - added dual attainment thresholds (>=2.0 and >=3.0)
 *
 */
include_once 'session_handler.php';
?>

<?php
require_once('../php_include/dbconnection_class.php');
require_once('performance_indicator_helpers.php');

// Get parameters from session
$IN_AcademicYear = $_SESSION['ATLAS_SELECTED_ACADEMICYEAR'];
$IN_AcademicProgram = $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'];

// Handle academic years - convert from array to string if needed
if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
    $academicYears = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
    if (!is_array($academicYears)) {
        $academicYears = array(intval($academicYears));
    }
} else {
    $academicYears = array(intval($IN_AcademicYear));
}

if (empty($academicYears)) {
    $academicYears = array(intval($IN_AcademicYear));
}

// Convert to comma-separated string for SQL queries
$IN_AcademicYears = implode(',', array_map('intval', $academicYears));

// Level mapping function
function getLevelName($levelNumber) {
    $levelMap = array(
        '1' => 'Introductory',
        '2' => 'Practice',
        '3' => 'Mastery'
    );
    return isset($levelMap[$levelNumber]) ? $levelMap[$levelNumber] : $levelNumber;
}

// Get level filter from GET parameter (optional)
$levelFilter = isset($_GET['level']) ? $_GET['level'] : 'All';

// Initialize database connection
$DBCONNECTION = new Dbconnection();
$Data = array();

// Initialize variables
$studentOutcomes = array();
$courses = array();
$levels = array();

// Query to get all Student Outcomes and their GPIs for the program
$soQuery = "
    SELECT DISTINCT
        STNTOUTCMS.SO,
        STNTOUTCMS.Description AS SODescription,
        GPIS.Idx AS GPIIdx,
        GPIS.GPI AS GPICode
    FROM StudentOutcomes AS STNTOUTCMS
    INNER JOIN GeneralPerformanceIndicators AS GPIS ON (STNTOUTCMS.Idx = GPIS.SOIdx)
    WHERE GPIS.AcademicProgram = {$IN_AcademicProgram}
    AND GPIS.AcademicYear IN ({$IN_AcademicYears})
    AND GPIS.TobeRemoved = 0
    ORDER BY STNTOUTCMS.SO, GPIS.GPI
";

$soResults = $DBCONNECTION->sendquery($soQuery);

if ($soResults) {
    while ($row = $soResults->fetch_assoc()) {
        $soKey = $row['SO'];
        if (!isset($studentOutcomes[$soKey])) {
            $studentOutcomes[$soKey] = array(
                'description' => $row['SODescription'],
                'gpis' => array()
            );
        }
        $studentOutcomes[$soKey]['gpis'][] = array(
            'gpiIdx' => $row['GPIIdx'],
            'code' => $row['GPICode']
        );
    }
}

// Query to get distinct levels first
$levelQuery = "
    SELECT DISTINCT ABETCRSES.Level
    FROM AbetCourses AS ABETCRSES
    WHERE ABETCRSES.AcademicProgram = {$IN_AcademicProgram}
    AND ABETCRSES.AcademicYear IN ({$IN_AcademicYears})
    AND ABETCRSES.Level IS NOT NULL
    AND ABETCRSES.Level != ''
    ORDER BY ABETCRSES.Level
";

$levelResults = $DBCONNECTION->sendquery($levelQuery);
if ($levelResults) {
    while ($row = $levelResults->fetch_assoc()) {
        if (!empty($row['Level'])) {
            $levelNumber = $row['Level'];
            $levelName = getLevelName($levelNumber);
            // Store both the number (for filtering) and name (for display)
            $levels[] = array(
                'value' => $levelNumber,
                'label' => $levelName
            );
        }
    }
}

// Convert level filter name to number if needed
$levelFilterNumber = null;
if ($levelFilter !== 'All') {
    if ($levelFilter === 'Introductory') {
        $levelFilterNumber = '1';
    } elseif ($levelFilter === 'Practice') {
        $levelFilterNumber = '2';
    } elseif ($levelFilter === 'Mastery') {
        $levelFilterNumber = '3';
    } else {
        // If it's already a number
        $levelFilterNumber = $levelFilter;
    }
}

// Ensure all courses have been analyzed and saved
$saveResults = analyzeAndSavePerformanceIndicators(
    $DBCONNECTION,
    $IN_AcademicProgram,
    $academicYears,
    false,  // Don't force recalculate - skip if already exists
    null,   // No requirement filter
    $levelFilterNumber  // Pass level filter
);

// Get the saved data from database
$savedCourses = getSavedPerformanceIndicators(
    $DBCONNECTION,
    $IN_AcademicProgram,
    $academicYears,
    null,  // No requirement filter
    $levelFilterNumber  // Pass level filter
);

// Process saved courses and aggregate by CourseNo (consolidate multiple offerings)
$aggregatedCourses = array();

foreach ($savedCourses as $courseKey => $courseData) {
    $courseNo = $courseData['courseNo'];

    // Initialize if first time seeing this course number
    if (!isset($aggregatedCourses[$courseNo])) {
        $aggregatedCourses[$courseNo] = array(
            'courseNo' => $courseData['courseNo'],
            'title' => $courseData['title'],
            'level' => getLevelName($courseData['level']),
            'levelNumber' => $courseData['level'],
            'rawScores' => array() // Will store all individual scores to calculate averages
        );
    }

    // Aggregate scores from all course offerings with same course number
    foreach ($courseData['indicators'] as $indicator) {
        $gpiIdx = $indicator['gpiIdx'];

        // Find which SO this belongs to
        $soKey = null;
        foreach ($studentOutcomes as $tempSoKey => $soData) {
            foreach ($soData['gpis'] as $gpiInfo) {
                if ($gpiInfo['gpiIdx'] == $gpiIdx) {
                    $soKey = $tempSoKey;
                    break 2;
                }
            }
        }

        if ($soKey !== null) {
            if (!isset($aggregatedCourses[$courseNo]['rawScores'][$soKey])) {
                $aggregatedCourses[$courseNo]['rawScores'][$soKey] = array();
            }
            if (!isset($aggregatedCourses[$courseNo]['rawScores'][$soKey][$gpiIdx])) {
                $aggregatedCourses[$courseNo]['rawScores'][$soKey][$gpiIdx] = array();
            }

            // Store the aggregate data for this offering
            $aggregatedCourses[$courseNo]['rawScores'][$soKey][$gpiIdx][] = array(
                'avg' => $indicator['avg'],
                'total' => $indicator['total'],
                'topFifty' => $indicator['topFifty'],        // Students >= 2.0
                'topTwentyFive' => $indicator['topTwentyFive']  // Students >= 3.0
            );
        }
    }
}

// Calculate final averages and counts across all offerings
foreach ($aggregatedCourses as $courseNo => $courseData) {
    $courses[$courseNo] = array(
        'courseNo' => $courseData['courseNo'],
        'title' => $courseData['title'],
        'level' => $courseData['level'],
        'levelNumber' => $courseData['levelNumber'],
        'scores' => array(),
        'counts' => array(),
        'above2' => array(),  // Count of students >= 2.0
        'above3' => array()   // Count of students >= 3.0
    );

    foreach ($courseData['rawScores'] as $soKey => $gpiData) {
        $courses[$courseNo]['scores'][$soKey] = array();
        $courses[$courseNo]['counts'][$soKey] = array();
        $courses[$courseNo]['above2'][$soKey] = array();  // NEW
        $courses[$courseNo]['above3'][$soKey] = array();

        foreach ($gpiData as $gpiIdx => $offeringsData) {
            // Aggregate across multiple offerings
            $totalWeightedSum = 0;
            $totalStudents = 0;
            $totalAbove2 = 0;  // Students >= 2.0
            $totalAbove3 = 0;  // Students >= 3.0

            foreach ($offeringsData as $offering) {
                $totalWeightedSum += $offering['avg'] * $offering['total'];
                $totalStudents += $offering['total'];

                // topFifty = students >= 2.0
                $totalAbove2 += $offering['topFifty'];

                // topTwentyFive = students >= 3.0
                $totalAbove3 += $offering['topTwentyFive'];
            }

            // Calculate overall average
            $overallAvg = $totalStudents > 0 ? $totalWeightedSum / $totalStudents : 0;

            $courses[$courseNo]['scores'][$soKey][$gpiIdx] = round($overallAvg, 2);
            $courses[$courseNo]['counts'][$soKey][$gpiIdx] = $totalStudents;
            $courses[$courseNo]['above2'][$soKey][$gpiIdx] = $totalAbove2;  // NEW
            $courses[$courseNo]['above3'][$soKey][$gpiIdx] = $totalAbove3;
        }
    }
}

// Build the response data
$data = array();
foreach ($courses as $course) {
    $row = array(
        'level' => $course['level'], // Display name (Introductory, Practice, Mastery)
        'levelNumber' => $course['levelNumber'], // Original number for sorting
        'courseNo' => $course['courseNo'],
        'title' => $course['title']
    );

    foreach ($studentOutcomes as $soKey => $soData) {
        foreach ($soData['gpis'] as $gpiInfo) {
            $gpiIdx = $gpiInfo['gpiIdx'];
            $columnKey = 'SO' . $soKey . '_GPI' . $gpiIdx;
            $countKey = $columnKey . '_count';
            $above2Key = $columnKey . '_above2';  // NEW
            $above3Key = $columnKey . '_above3';

            // Add average score
            $row[$columnKey] = isset($course['scores'][$soKey][$gpiIdx])
                ? $course['scores'][$soKey][$gpiIdx]
                : '';

            // Add student count
            $row[$countKey] = isset($course['counts'][$soKey][$gpiIdx])
                ? $course['counts'][$soKey][$gpiIdx]
                : 0;

            // Add count of students scoring >= 2.0
            $row[$above2Key] = isset($course['above2'][$soKey][$gpiIdx])
                ? $course['above2'][$soKey][$gpiIdx]
                : 0;

            // Add count of students scoring >= 3.0
            $row[$above3Key] = isset($course['above3'][$soKey][$gpiIdx])
                ? $course['above3'][$soKey][$gpiIdx]
                : 0;
        }
    }

    $data[] = $row;
}

// Prepare final response
$Data['data'] = $data;
$Data['studentOutcomes'] = $studentOutcomes;
$Data['levels'] = $levels;

header('Content-Type: application/json');
echo json_encode($Data);