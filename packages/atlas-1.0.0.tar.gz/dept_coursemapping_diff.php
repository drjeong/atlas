<?php
/**
 * Abet courses
 * Description: Listing course mapping differences across programs
 * Author: Dong Hyun Jeong
 *
 * 02/07/2025 - initial version created
 */

//include('checker_programdirector.php');
include('header.php');
?>


<?php

if (array_key_exists('CH_APR', $_POST)) {
    $_SESSION['ATLAS_ACCESSCNTL_SELECTEDPROGRAM'] = trim($_POST['CH_APR']); // program selection is changed
}

// fetch academic year selection
require_once('inc_academicyear_selection.php');
$AcademicYearSelection = AcademicYearSelection();

?>

    <script src="js/datatable-utils-search.min.js"></script>

    <!-- Updated HTML/JavaScript file with enhanced analysis -->
    <script class="init">
        $(document).ready(function() {
            const SelectedAcademicYear = document.academicyear._AY.options[document.academicyear._AY.selectedIndex].value;
            const szURL = 'ssps/dept_coursemapping_diff_ssps.php?_AY=';
            let showOnlyUnmatched = false;

            // Helper function to safely get the academic year text
            function getAcademicYearText() {
                try {
                    if (document.forms["academicyear"]) {
                        return document.forms["academicyear"]["_AY"].options[document.forms["academicyear"]["_AY"].selectedIndex].text;
                    }
                    return '';
                } catch(e) {
                    return '';
                }
            }

            // Function to analyze and display detailed discrepancies
            function analyzeDiscrepancies(row) {
                const currentSOs = row.StudentOutcomes ? row.StudentOutcomes.split(',').map(s => s.trim()).sort() : [];
                const currentPIs = row.PIs ? row.PIs.split(',').map(s => s.trim()).filter(s => s.includes('-')).sort() : [];

                let html = '<div style="font-size: 12px; padding: 15px;">';

                // Course header - more compact
                html += `<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px; border-radius: 6px; margin-bottom: 15px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.15);">`;
                html += `<div style="font-size: 14px; font-weight: bold; margin-bottom: 5px;">${row.Subject} ${row.Num}: ${row.Title}</div>`;
                html += `<div style="font-size: 11px; opacity: 0.9;">Academic Year: ${row.AcademicYearInfo}</div>`;
                html += `</div>`;

                // Current program info - condensed
                html += `<div style="background: #e3f2fd; padding: 12px; border-radius: 6px; margin-bottom: 15px; border-left: 3px solid #1976d2;">`;
                html += `<div style="font-size: 13px; font-weight: 600; color: #1976d2; margin-bottom: 8px;">📊 ${row.AcademicProgramName}</div>`;
                html += `<div style="display: flex; gap: 20px; font-size: 11px;">`;
                html += `<div><strong>SOs:</strong> <span style="color: #666;">${currentSOs.length > 0 ? currentSOs.join(', ') : 'None'}</span></div>`;
                html += `<div><strong>PIs:</strong> <span style="color: #666;">${currentPIs.length > 0 ? currentPIs.join(', ') : 'None'}</span></div>`;
                html += `</div></div>`;

                // Check if we have other programs
                if (row.OtherPrograms) {
                    const otherPrograms = row.OtherPrograms.split(';').map(s => s.trim()).filter(s => s);

                    if (otherPrograms.length > 0) {
                        const programsData = [];
                        const otherSOsMap = {};
                        const otherPIsMap = {};

                        if (row.OtherSOs) {
                            const soEntries = row.OtherSOs.split(';').map(s => s.trim()).filter(s => s);
                            soEntries.forEach(entry => {
                                const match = entry.match(/^(.+?):\s*\[(.+?)\]$/);
                                if (match) {
                                    otherSOsMap[match[1]] = match[2];
                                }
                            });
                        }

                        if (row.OtherPIs) {
                            const piEntries = row.OtherPIs.split(';').map(s => s.trim()).filter(s => s);
                            piEntries.forEach(entry => {
                                const match = entry.match(/^(.+?):\s*\[(.+?)\]$/);
                                if (match) {
                                    otherPIsMap[match[1]] = match[2];
                                }
                            });
                        }

                        const allSOs = new Set(currentSOs);
                        const allPIs = new Set(currentPIs);

                        otherPrograms.forEach(programFull => {
                            const programName = programFull.replace(/\s*\([^)]*\)$/, '');
                            const outcomes = otherSOsMap[programName];
                            const indicators = otherPIsMap[programName];

                            const otherSOs = outcomes ? outcomes.split(',').map(s => s.trim()).sort() : currentSOs;
                            const otherPIs = indicators ? indicators.split(',').map(s => s.trim()).filter(s => s.includes('-')).sort() : currentPIs;

                            otherSOs.forEach(so => allSOs.add(so));
                            otherPIs.forEach(pi => allPIs.add(pi));

                            programsData.push({
                                name: programFull,
                                shortName: programName,
                                sos: otherSOs,
                                pis: otherPIs
                            });
                        });

                        const sortedSOs = Array.from(allSOs).sort();
                        const sortedPIs = Array.from(allPIs).sort();

                        // Compact comparison section
                        html += `<div style="margin-top: 0;">`;
                        html += `<div style="font-size: 13px; font-weight: 600; color: #d32f2f; margin-bottom: 12px; padding-bottom: 8px; border-bottom: 2px solid #ffcdd2;">📋 Program Comparison</div>`;

                        // Two-column layout for SO and PI tables
                        html += `<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; max-height: 450px; overflow-y: auto;">`;

                        // Student Outcomes Column
                        if (sortedSOs.length > 0) {
                            html += `<div>`;
                            html += `<div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px; background: #f5f5f5; padding: 6px 8px; border-radius: 4px;">Student Outcomes (SOs)</div>`;
                            html += `<table style="width: 100%; border-collapse: collapse; font-size: 11px; background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.08);">`;
                            html += `<thead><tr style="background: #fafafa;">`;
                            html += `<th style="padding: 6px 8px; text-align: left; border: 1px solid #e0e0e0; font-weight: 600; font-size: 10px;">Program</th>`;
                            sortedSOs.forEach(so => {
                                html += `<th style="padding: 6px 4px; text-align: center; border: 1px solid #e0e0e0; font-weight: 600; font-size: 10px; min-width: 40px;">${so}</th>`;
                            });
                            html += `</tr></thead><tbody>`;

                            // Current program row
                            html += `<tr style="background: #e3f2fd;">`;
                            html += `<td style="padding: 6px 8px; border: 1px solid #e0e0e0; font-weight: 600; font-size: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 120px;" title="${row.AcademicProgramName}">${row.AcademicProgramName}</td>`;
                            sortedSOs.forEach(so => {
                                const hasIt = currentSOs.includes(so);
                                html += `<td style="padding: 6px 4px; text-align: center; border: 1px solid #e0e0e0;">`;
                                html += hasIt ? '<span style="color: #4caf50; font-size: 14px;">✓</span>' : '<span style="color: #f44336; font-size: 14px;">−</span>';
                                html += `</td>`;
                            });
                            html += `</tr>`;

                            // Other programs rows
                            programsData.forEach(prog => {
                                const hasDiff = prog.sos.some(so => !currentSOs.includes(so)) || currentSOs.some(so => !prog.sos.includes(so));
                                html += `<tr style="background: ${hasDiff ? '#ffebee' : '#e8f5e9'};">`;
                                html += `<td style="padding: 6px 8px; border: 1px solid #e0e0e0; font-weight: 500; font-size: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 120px;" title="${prog.name}">${prog.name}</td>`;
                                sortedSOs.forEach(so => {
                                    const hasIt = prog.sos.includes(so);
                                    html += `<td style="padding: 6px 4px; text-align: center; border: 1px solid #e0e0e0;">`;
                                    html += hasIt ? '<span style="color: #4caf50; font-size: 14px;">✓</span>' : '<span style="color: #f44336; font-size: 14px;">−</span>';
                                    html += `</td>`;
                                });
                                html += `</tr>`;
                            });

                            html += `</tbody></table>`;
                            html += `</div>`;
                        }

                        // Performance Indicators Column
                        if (sortedPIs.length > 0) {
                            html += `<div>`;
                            html += `<div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px; background: #f5f5f5; padding: 6px 8px; border-radius: 4px;">Performance Indicators (PIs)</div>`;
                            html += `<table style="width: 100%; border-collapse: collapse; font-size: 11px; background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.08);">`;
                            html += `<thead><tr style="background: #fafafa;">`;
                            html += `<th style="padding: 6px 8px; text-align: left; border: 1px solid #e0e0e0; font-weight: 600; font-size: 10px;">Program</th>`;
                            sortedPIs.forEach(pi => {
                                html += `<th style="padding: 6px 4px; text-align: center; border: 1px solid #e0e0e0; font-weight: 600; font-size: 10px; min-width: 45px;">${pi}</th>`;
                            });
                            html += `</tr></thead><tbody>`;

                            // Current program row
                            html += `<tr style="background: #e3f2fd;">`;
                            html += `<td style="padding: 6px 8px; border: 1px solid #e0e0e0; font-weight: 600; font-size: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 120px;" title="${row.AcademicProgramName}">${row.AcademicProgramName}</td>`;
                            sortedPIs.forEach(pi => {
                                const hasIt = currentPIs.includes(pi);
                                html += `<td style="padding: 6px 4px; text-align: center; border: 1px solid #e0e0e0;">`;
                                html += hasIt ? '<span style="color: #4caf50; font-size: 14px;">✓</span>' : '<span style="color: #f44336; font-size: 14px;">−</span>';
                                html += `</td>`;
                            });
                            html += `</tr>`;

                            // Other programs rows
                            programsData.forEach(prog => {
                                const hasDiff = prog.pis.some(pi => !currentPIs.includes(pi)) || currentPIs.some(pi => !prog.pis.includes(pi));
                                html += `<tr style="background: ${hasDiff ? '#ffebee' : '#e8f5e9'};">`;
                                html += `<td style="padding: 6px 8px; border: 1px solid #e0e0e0; font-weight: 500; font-size: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 120px;" title="${prog.name}">${prog.name}</td>`;
                                sortedPIs.forEach(pi => {
                                    const hasIt = prog.pis.includes(pi);
                                    html += `<td style="padding: 6px 4px; text-align: center; border: 1px solid #e0e0e0;">`;
                                    html += hasIt ? '<span style="color: #4caf50; font-size: 14px;">✓</span>' : '<span style="color: #f44336; font-size: 14px;">−</span>';
                                    html += `</td>`;
                                });
                                html += `</tr>`;
                            });

                            html += `</tbody></table>`;
                            html += `</div>`;
                        }

                        html += `</div>`; // End grid

                        // Compact Legend
                        html += `<div style="margin-top: 12px; padding: 8px 10px; background: #fafafa; border-radius: 4px; font-size: 10px; border-left: 3px solid #9e9e9e;">`;
                        html += `<strong>Legend:</strong> `;
                        html += `<span style="color: #4caf50; margin: 0 6px;">✓ Has</span>`;
                        html += `<span style="color: #f44336; margin: 0 6px;">− Missing</span>`;
                        html += `</div>`;

                        html += `</div>`;
                    }
                } else {
                    html += `<div style="margin-top: 10px; padding: 12px; background: #f5f5f5; border-radius: 4px; text-align: center;">`;
                    html += `<em style="color: #666; font-size: 11px;"><i class="glyphicon glyphicon-info-sign"></i> This course is not offered by other programs</em>`;
                    html += `</div>`;
                }

                html += '</div>';
                return html;
            }

            DataTable_CrsMappingList = $("#CrsMappings").DataTable({
                dom: 'lBfrtip',  // l=length, B=buttons, f=filter, r=processing, t=table, i=info, p=paging
                stateSave: true,
                processing: true,
                serverSide: true,
                lengthMenu: [30, 50, 100, 150, 200, 300, 400],
                ajax: {
                    url: `${szURL}<?php echo($_SESSION['ATLAS_SELECTED_ACADEMICYEAR']);?>`,
                    type: 'GET',
                    data: function(d) {
                        // Add custom parameter for filtering
                        d.showOnlyUnmatched = showOnlyUnmatched;
                        return d;
                    }
                },
                oLanguage: {
                    sInfoFiltered: ""
                },
                order: [[0, "asc"], [1, "asc"], [2, "asc"]],
                ordering: false,

                columns: [
                    { data: 'AcademicYearInfo', className: 'text-center' },
                    { data: 'Subject', className: 'text-center' },
                    { data: 'Num', className: 'text-center' },
                    { data: 'Title', className: 'text-left' },
                    { data: 'AcademicProgramName', className: 'text-left' },
                    {
                        data: 'StudentOutcomes',
                        className: 'text-left',
                        render: (data, type, row) => {
                            if (!data) return '<em class="text-muted">None</em>';
                            const outcomes = data.split(',').map(s => s.trim());
                            return `<span class="badge" style="background: #2196f3; margin-right: 3px; font-size: 11px;">${outcomes.length}</span> ${outcomes.join(', ')}`;
                        }
                    },
                    {
                        data: 'PIs',
                        className: 'text-left',
                        render: (data, type, row) => {
                            if (!data) return '<em class="text-muted">None</em>';
                            const pis = data.split(",")
                                .filter(item => item.includes("-"))
                                .map(item => item.trim());
                            return `<span class="badge" style="background: #4caf50; margin-right: 3px; font-size: 11px;">${pis.length}</span> ${pis.join(', ')}`;
                        }
                    },
                    {
                        data: 'HasDiscrepancy',
                        className: 'text-center',
                        render: (data, type, row) => {
                            // Always show View Details button if there are other programs
                            if (row.OtherPrograms && row.OtherPrograms.length > 0) {
                                if (data === 1) {
                                    return `<span class="label label-danger" style="font-size: 11px; cursor: pointer;"
                    onclick="showDiscrepancyDetails(${row.Idx})">
                    <i class="glyphicon glyphicon-exclamation-sign"></i> View Details
                    </span>`;
                                } else {
                                    return `<span class="label label-success" style="font-size: 11px; cursor: pointer;"
                    onclick="showDiscrepancyDetails(${row.Idx})">
                    <i class="glyphicon glyphicon-ok"></i> View Details
                    </span>`;
                                }
                            }
                            return '<span class="label label-default" style="font-size: 11px;"><i class="glyphicon glyphicon-minus"></i> N/A</span>';
                        }
                    },
                    {
                        data: 'OtherPrograms',
                        className: 'text-left',
                        render: (data, type, row) => {
                            if (!data) return '<em class="text-muted">None</em>';
                            const programs = data.split(';').map(p => p.trim()).filter(p => p);
                            return `<span class="badge" style="background: #ff9800; margin-right: 3px; font-size: 11px;">${programs.length}</span> ${programs.join('<br>')}`;
                        }
                    }
                ],

                fnInitComplete: function(settings) {
                    const btnClear = $('<button class="btnClearDataTableFilter" style="height:26px;">CLEAR</button>');
                    btnClear.appendTo($('#' + settings.sTableId).parents('.dataTables_wrapper').find('.dataTables_filter'));
                    btnClear.click(() => $('#' + settings.sTableId).dataTable().fnFilter(''));

                    // Add summary statistics
                    updateSummaryStats();
                },

                rowCallback: function(row, data, index) {
                    const groupKey = `${data.AcademicYearInfo}-${data.Subject}-${data.Num}-${data.Title}`;
                    $(row).attr('data-group-key', groupKey);
                    $(row).attr('data-row-idx', data.Idx);

                    if (data.HasDiscrepancy === 1) {
                        $(row).css('background-color', '#fff3cd');
                        $(row).css('border-left', '4px solid #ff9800');
                    }
                },

                fnDrawCallback: function() {
                    this.api().state.clear();

                    const cellWidths = {
                        1: '80px',
                        2: '60px'
                    };
                    const minWidths = {
                        3: '200px',
                        4: '150px',
                        5: '150px',
                        6: '150px',
                        7: '120px',
                        8: '180px'
                    };

                    Object.entries(cellWidths).forEach(([col, width]) => {
                        $(`#CrsMappings tr td:nth-child(${col})`).css('width', width);
                    });
                    Object.entries(minWidths).forEach(([col, width]) => {
                        $(`#CrsMappings tr td:nth-child(${col})`).css('min-width', width);
                    });

                    const groupedRows = {};
                    $('#CrsMappings tbody tr').each(function() {
                        const groupKey = $(this).attr('data-group-key');
                        const rowIdx = $(this).attr('data-row-idx');
                        const rowData = DataTable_CrsMappingList.rows().data().toArray().find(r => r.Idx == rowIdx);
                        const hasDiscrepancy = rowData ? rowData.HasDiscrepancy === 1 : false;

                        if (!hasDiscrepancy) {
                            if (!groupedRows[groupKey]) {
                                groupedRows[groupKey] = [];
                            }
                            groupedRows[groupKey].push(this);
                        }
                    });

                    const colors = [
                        '#f0f8ff', '#fff5ee', '#f0fff0', '#ffe4e1',
                        '#f0ffff', '#fff0f5', '#f5f5dc'
                    ];

                    let colorIndex = 0;
                    Object.keys(groupedRows).forEach(groupKey => {
                        const rows = groupedRows[groupKey];
                        if (rows.length > 1) {
                            const color = colors[colorIndex % colors.length];
                            rows.forEach(row => {
                                $(row).css('background-color', color);
                            });
                            colorIndex++;
                        }
                    });
                },

                columnDefs: [
                    {
                        targets: '_all',
                        orderable: false
                    }
                ],

                buttons: [
                    {
                        extend: 'pdfHtml5',
                        orientation: 'landscape',
                        title: function() {
                            return `SO/PI DISCREPANCIES ANALYSIS (${getAcademicYearText()})`;
                        },
                        text: '<span class="glyphicon glyphicon-floppy-save"></span> PDF',
                        className: 'btn btn-xs',
                        attr: {
                            style: 'height:25px; line-height:1.5; font-size:11px; background-color:#d9534f; border-color:#d43f3a; color:#fff; margin-left:8px;'
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 8]
                        },
                        customize: doc => {
                            doc.styles.tableHeader.fontSize = 8;
                            doc.defaultStyle.fontSize = 7;
                            doc.pageSize = 'LETTER';
                            doc.pageMargins = [20, 20, 20, 20];
                            doc.content[1].table.widths = ['8%', '7%', '7%', '18%', '15%', '15%', '15%', '15%'];
                            doc.styles.tableHeader.alignment = 'left';
                            doc.styles.tableBodyEven = doc.styles.tableBodyOdd;
                            doc.styles.tableHeader.bold = true;
                        },
                        pageSize: 'LETTER'
                    },
                    {
                        extend: 'excelHtml5',
                        title: function() {
                            return `SO/PI DISCREPANCIES ANALYSIS (${getAcademicYearText()})`;
                        },
                        text: '<span class="glyphicon glyphicon-floppy-save"></span> EXCEL',
                        className: 'btn btn-xs',
                        attr: {
                            style: 'height:25px; line-height:1.5; font-size:11px; background-color:#28a745; border-color:#28a745; color:#fff;'
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 8]
                        }
                    }
                ]
            });


            // Update the DataTable's search function to filter unmatched rows
            $.fn.dataTable.ext.search.push(
                function(settings, data, dataIndex) {
                    // Only apply to our specific table
                    if (settings.nTable.id !== 'CrsMappings') {
                        return true;
                    }

                    // If not filtering, show all
                    if (!showOnlyUnmatched) {
                        return true;
                    }

                    // Get the actual row data
                    const table = $('#CrsMappings').DataTable();
                    const rowData = table.row(dataIndex).data();

                    // Show rows with discrepancies
                    return rowData.HasDiscrepancy === 1;
                }
            );

            // Function to update summary statistics
            function updateSummaryStats() {
                const allData = DataTable_CrsMappingList.rows({search: 'applied'}).data().toArray();

                const totalCourses = allData.length;
                const coursesWithDiscrepancies = allData.filter(r => r.HasDiscrepancy === 1).length;
                const coursesMatching = totalCourses - coursesWithDiscrepancies;
                const discrepancyRate = totalCourses > 0 ? ((coursesWithDiscrepancies / totalCourses) * 100).toFixed(1) : 0;

                // Count unique course codes (Subject + Num)
                const uniqueCourses = new Set(allData.map(r => `${r.Subject} ${r.Num}`)).size;

                // Count programs involved
                const programs = new Set(allData.map(r => r.AcademicProgramName)).size;

                $('#summaryStats').html(`
                    <div style="display: flex; gap: 10px; flex-wrap: wrap; justify-content: center;">
                        <div style="background: #2196f3; color: white; padding: 8px 15px; border-radius: 6px; text-align: center; min-width: 120px;">
                            <div style="font-size: 20px; font-weight: bold;">${totalCourses}</div>
                            <div style="font-size: 10px; margin-top: 3px;">Total Instances</div>
                        </div>
                        <div style="background: #4caf50; color: white; padding: 8px 15px; border-radius: 6px; text-align: center; min-width: 120px;">
                            <div style="font-size: 20px; font-weight: bold;">${uniqueCourses}</div>
                            <div style="font-size: 10px; margin-top: 3px;">Unique Courses</div>
                        </div>
                        <div style="background: #ff9800; color: white; padding: 8px 15px; border-radius: 6px; text-align: center; min-width: 120px;">
                            <div style="font-size: 20px; font-weight: bold;">${programs}</div>
                            <div style="font-size: 10px; margin-top: 3px;">Programs</div>
                        </div>
                        <div style="background: #f44336; color: white; padding: 8px 15px; border-radius: 6px; text-align: center; min-width: 120px;">
                            <div style="font-size: 20px; font-weight: bold;">${coursesWithDiscrepancies}</div>
                            <div style="font-size: 10px; margin-top: 3px;">Discrepancies</div>
                        </div>
                        <div style="background: #9c27b0; color: white; padding: 8px 15px; border-radius: 6px; text-align: center; min-width: 120px;">
                            <div style="font-size: 20px; font-weight: bold;">${discrepancyRate}%</div>
                            <div style="font-size: 10px; margin-top: 3px;">Discrepancy Rate</div>
                        </div>
                        <div style="background: #4caf50; color: white; padding: 8px 15px; border-radius: 6px; text-align: center; min-width: 120px;">
                            <div style="font-size: 20px; font-weight: bold;">${coursesMatching}</div>
                            <div style="font-size: 10px; margin-top: 3px;">Matching</div>
                        </div>
                    </div>
                `);
            }

            // Global function to show discrepancy details
            window.showDiscrepancyDetails = function(rowIdx) {
                const allData = DataTable_CrsMappingList.rows().data().toArray();
                const rowData = allData.find(r => r.Idx === rowIdx);

                if (!rowData) return;

                const detailsHtml = analyzeDiscrepancies(rowData);

                createModalDialog({
                    title: '<span class="glyphicon glyphicon-search" style="font-size:18pt;color:#667eea;vertical-align:middle;"></span>&nbsp;<span style="font-size:15pt;font-weight: 600;">DETAILED ANALYSIS</span>',
                    message: detailsHtml,
                    buttons: {
                        ok: {
                            label: "<span class='glyphicon glyphicon-remove'></span>&nbsp;CLOSE",
                            className: 'btn-primary',
                            callback: function(){
                                // Just close the modal
                            }
                        }
                    }
                }).on('shown.bs.modal', function(){
                    // Compact modal size
                    $(this).find('.modal-dialog').css({
                        'width': '950px',
                        'max-width': '95%'
                    });
                    $(this).find('.modal-body').css({
                        'max-height': '600px',
                        'overflow-y': 'auto'
                    });
                });
            };

            $("#_AY").on('change', function() {
                const tmpURL = szURL + this.value;
                DataTable_CrsMappingList.ajax.url(tmpURL).load(function() {
                    // This callback runs AFTER the data is loaded
                    updateSummaryStats();
                });
            });

            if (typeof DataTableSearch !== 'undefined') {
                new DataTableSearch('#CrsMappings', DataTable_CrsMappingList);
            }

            if (typeof async_commons !== 'undefined') {
                async_commons.setDataTable(DataTable_CrsMappingList);
            }

            $('#btnFilterUnmatched').on('click', function() {
                showOnlyUnmatched = !showOnlyUnmatched;

                if (showOnlyUnmatched) {
                    $(this).html('<i class="glyphicon glyphicon-filter"></i> Show All');
                    $(this).removeClass('btn-warning').addClass('btn-info');
                } else {
                    $(this).html('<i class="glyphicon glyphicon-filter"></i> Show Only Unmatched');
                    $(this).removeClass('btn-info').addClass('btn-warning');
                }

                // Reload the table with the new filter
                DataTable_CrsMappingList.ajax.reload();
            });
        });
    </script>

    <div class="pagebacklayout">
        <div style="width:100%;">
            <p style="margin-top:0.2in;text-align:center;"><span class="largeheadline">COURSE MAPPING - SO/PI MISMATCH ANALYSIS ACROSS PROGRAMS</span></p>
        </div>

        <div class="pagebacklayout_inner_noborder">
            <!-- Summary Statistics Dashboard -->
            <div id="summaryStats" style="margin-bottom: 20px; padding: 20px; background: #f8f9fa; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <div style="text-align: center; color: #666;">Loading statistics...</div>
            </div>

            <table style="border-spacing:0; padding:0; width:100%; margin-bottom:0.1in;">
                <tr>
                    <td style="width:20%; min-width:350px;">
                        <?php echo($AcademicYearSelection);?>
                    </td>
                    <td style="width:5%"></td>
                    <td style="width:75%; text-align: right">
                        <button id="btnFilterUnmatched" class="btn btn-warning" style="padding: 8px 12px; margin: 0; margin-right: 5px; font-size: 13px; vertical-align: middle;">
                            <i class="glyphicon glyphicon-filter"></i> Show Only Unmatched
                        </button>
                        <div class="alert alert-info" style="display: inline-block; padding: 8px 12px; margin: 0; font-size: 13px; vertical-align: middle;">
                            <i class="glyphicon glyphicon-info-sign"></i>
                            <strong>Legend:</strong>
                            <span class="label label-danger" style="font-size: 11px; margin-left: 8px;"><i class="glyphicon glyphicon-exclamation-sign"></i> Discrepancy</span>
                            <span style="margin: 0 5px;">|</span>
                            <span class="label label-success" style="font-size: 11px;"><i class="glyphicon glyphicon-ok"></i> Match</span>
                            <span style="margin: 0 5px;">|</span>
                            <span class="badge" style="background: #2196f3; font-size: 10px;">Count</span>
                        </div>
                    </td>
                </tr>
            </table>

            <div class="CSSTable_SSPSLIST" style="display: inline-block; margin: 0 auto; overflow-x: auto;">
                <table id="CrsMappings" class="display break-word" style="border-spacing:0; padding:0; width:100%;">
                    <thead>
                    <tr>
                        <th style="width:80px">ACADEMIC YEAR</th>
                        <th>SUBJECT</th>
                        <th>NUMBER</th>
                        <th>TITLE</th>
                        <th>PROGRAM</th>
                        <th>STUDENT OUTCOMES</th>
                        <th>PERFORMANCE INDICATORS</th>
                        <th style="width:120px">STATUS</th>
                        <th>OTHER PROGRAMS</th>
                    </tr>
                    </thead>
                    <thead id="serachbox" class="filters">
                    <tr>
                        <th>ACADEMIC YEAR</th>
                        <th>SUBJECT</th>
                        <th>NUMBER</th>
                        <th>TITLE</th>
                        <th>PROGRAM</th>
                        <th>STUDENT OUTCOMES</th>
                        <th>PERFORMANCE INDICATORS</th>
                        <th>STATUS</th>
                        <th>OTHER PROGRAMS</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr>
                        <th>ACADEMIC YEAR</th>
                        <th>SUBJECT</th>
                        <th>NUMBER</th>
                        <th>TITLE</th>
                        <th>PROGRAM</th>
                        <th>STUDENT OUTCOMES</th>
                        <th>PERFORMANCE INDICATORS</th>
                        <th>STATUS</th>
                        <th>OTHER PROGRAMS</th>
                    </tr>
                    </tfoot>
                </table>
            </div>

            <table style="width:98%; border-spacing:0; padding:0; margin:auto; margin-top: 15px; font-size:9pt;">
                <tr>
                    <td>
                        <div class="alert alert-info" style="margin: 0; padding: 10px;">
                            <strong><i class="glyphicon glyphicon-info-sign"></i> How to Use:</strong>
                            <ul style="margin: 5px 0 0 20px; padding: 0;">
                                <li>Click on <span class="label label-danger" style="font-size: 10px;">View Details</span> or <span class="label label-success" style="font-size: 10px;">View Details</span> to see a comprehensive comparison between programs</li>
                                <li>Courses with discrepancies are highlighted in yellow with an orange left border</li>
                                <li>Badges show the count of items (Student Outcomes, Performance Indicators, Programs)</li>
                                <li>Use the search boxes to filter by specific courses, programs, or outcomes</li>
                                <li>Programs with matching SO/PI mappings will also appear in the comparison table</li>
                            </ul>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <style>
        .modal-dialog .detailed-analysis-content table {
            border-radius: 4px;
            overflow: hidden;
        }

        .modal-dialog .detailed-analysis-content table tr:hover {
            opacity: 0.9;
        }

        .modal-dialog .detailed-analysis-content table th {
            white-space: nowrap;
        }

        /* Override any modal size restrictions */
        .modal-dialog.modal-lg {
            width: 1000px;
            max-width: 95%;
        }
    </style>


<?php include('footer.php');?>