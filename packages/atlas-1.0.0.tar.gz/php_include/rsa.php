<?php

//////////////////////////////////////////////////
// generating key
// openssl genrsa -out rsa_1024_priv.pem 1024
// openssl rsa -pubout -in rsa_1024_priv.pem -out rsa_1024_pub.pem
// adding read-only permission to keys
// sudo chmod 444 *.pem

function DecryptData($encrypted_msg){
    require_once(__DIR__ . '/../../config.php');
	$private_key = openssl_pkey_get_private(file_get_contents(__KEY_PRIVATE));
	openssl_private_decrypt(base64_decode($encrypted_msg), $decripted_msg, $private_key);

	return($decripted_msg);
}

function GetPublicKey(){
    require_once(__DIR__ . '/../../config.php');
    $public_key = trim(file_get_contents(__KEY_PUBLIC));
    return ($public_key);
}
