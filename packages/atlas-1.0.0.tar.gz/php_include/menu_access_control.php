<?php
class MenuAccessControl {
    private $db;
    private $userIdx;
    private $isSystemAdmin;
    private $accessibleMenus = [];

    public function __construct($dbConnection, $userIdx) {
        $this->db = $dbConnection;
        $this->userIdx = intval($userIdx);
        $this->checkSystemAdmin();
        $this->loadAccessibleMenus();
    }

    private function checkSystemAdmin() {
        $query = "SELECT SystemAdmin FROM UserAccounts WHERE Idx = ?";
        $result = $this->db->prepare_execute($query, [$this->userIdx]);

        if ($result) {
            $row = $result->fetch_assoc();
            $this->isSystemAdmin = ($row && $row['SystemAdmin'] == '1');
        } else {
            $this->isSystemAdmin = false;
        }
    }

    private function loadAccessibleMenus() {
        // System admins have access to all menus
        if ($this->isSystemAdmin) {
            $this->accessibleMenus = ['*']; // Wildcard for all access
            return;
        }

        // Get user's submenu group permissions
        $query = "
            SELECT DISTINCT MenuGroupCode 
            FROM UserMenuPermissions 
            WHERE UserIdx = ?
        ";
        $result = $this->db->prepare_execute($query, [$this->userIdx]);

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $this->accessibleMenus[] = $row['MenuGroupCode'];
            }
        }
    }

    public function getAccessibleMenus() {
        return $this->accessibleMenus;
    }

    public function hasAccessToSubmenuGroup($groupCode) {
        // System admins have all access
        if ($this->isSystemAdmin) {
            return true;
        }

        // Check for wildcard
        if (in_array('*', $this->accessibleMenus)) {
            return true;
        }

        // Check if group is in accessible list
        return in_array($groupCode, $this->accessibleMenus);
    }
}
?>