<?php
session_start();
header('Content-Type: application/json');

require_once(__DIR__ . '/php_include/dbconnection_class.php');

try {
    $DBCONNECTION = new Dbconnection();

    $gpi = $_POST['gpi'] ?? '';
    $program = $_POST['program'] ?? '';
    $academicYear = $_POST['academicYear'] ?? '';

    if (empty($gpi) || empty($program)) {
        throw new Exception('Missing required parameters');
    }

    $courses = [];
    $totalScore = 0;
    $totalStudents = 0;

    // Determine academic year to query
    if ($academicYear === 'Overall') {
        // Get all academic years from session
        if (isset($_SESSION['ATLAS_SELECTED_ACADEMICYEARS']) && is_array($_SESSION['ATLAS_SELECTED_ACADEMICYEARS'])) {
            $academicYearIndices = $_SESSION['ATLAS_SELECTED_ACADEMICYEARS'];
        } else {
            $academicYearIndices = [intval($_SESSION['ATLAS_SELECTED_ACADEMICYEAR'])];
        }
        $academicYearsStr = implode(',', array_map('intval', $academicYearIndices));
    } else {
        // Specific year - lookup the year index
        $yearQuery = "SELECT Idx FROM AcademicYears WHERE AcademicYear = ?";
        $yearResult = $DBCONNECTION->prepare_execute_catch_error($yearQuery, [$academicYear]);

        if ($yearResult && $DBCONNECTION->num_rows() > 0) {
            $yearRow = $DBCONNECTION->fetch_assoc();
            $academicYearsStr = intval($yearRow['Idx']);
        } else {
            throw new Exception('Academic year not found');
        }
    }

    // Query Analyzed_PerformanceIndicators table directly
    $query = "
        SELECT 
            API.AbetCourseIdx,
            API.AvailableCourseIdx,
            API.TOTAL,
            API.AVG,
            AVCRSES.CourseNo,
            AVCRSES.Crn,
            AVCRSES.Title AS CourseName,
            AYS.AcademicYear
        FROM `Analyzed_PerformanceIndicators` AS `API`
        INNER JOIN `AbetCourses` AS `ABETCRSES` ON (API.AbetCourseIdx = ABETCRSES.Idx)
        INNER JOIN `AcademicYears` AS `AYS` ON (ABETCRSES.AcademicYear = AYS.Idx)
        INNER JOIN `AVCourses` AS `AVCRSES` ON (API.AvailableCourseIdx = AVCRSES.Idx)
        WHERE API.GPI = ?
          AND ABETCRSES.AcademicProgram = ?
          AND ABETCRSES.AcademicYear IN ($academicYearsStr)
          AND API.TOTAL > 0
        ORDER BY AVCRSES.CourseNo, AVCRSES.Crn
    ";

    $result = $DBCONNECTION->prepare_execute_catch_error($query, [$gpi, $program]);

    if ($result && $DBCONNECTION->num_rows() > 0) {
        while ($row = $DBCONNECTION->fetch_assoc()) {
            $studentCount = intval($row['TOTAL']);
            $avgScore = floatval($row['AVG']);
            $courseTotal = $avgScore * $studentCount;

            $totalScore += $courseTotal;
            $totalStudents += $studentCount;

            $courses[] = [
                'courseNo' => $row['CourseNo'],
                'crn' => $row['Crn'],
                'courseName' => $row['CourseName'],
                'academicYear' => $row['AcademicYear'],
                'students' => $studentCount,
                'avgScore' => number_format($avgScore, 2),
                'totalScore' => number_format($courseTotal, 2)
            ];
        }
    }

    echo json_encode([
        'success' => true,
        'courses' => $courses,
        'totalScore' => number_format($totalScore, 2),
        'totalStudents' => $totalStudents
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
